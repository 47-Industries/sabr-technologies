#!/usr/bin/env bash
# Leon Trading Desk feed loop — pulls every 60s, runs detached.
cd /opt/leon-brain/trading-desk
while true; do
  /usr/bin/python3 feed.py >> logs/cron.log 2>&1
  sleep 60
done
