#!/usr/bin/env python3
"""
Leon Trading Desk — grader / paper backtester (paper mode, milestone 2).
Replays the full tick history through the same fast/slow MA crossover the
live signal uses, opens a paper LONG on an up-cross, closes it on a
down-cross, and scores every CLOSED trade by its real return. Writes a
scorecard to logs/scorecard.json and appends closed trades to
logs/trades.jsonl. No money — this is the receipts layer that has to earn
the swagger before a cent is ever at risk.
"""
import json, os, datetime

BASE = "/opt/leon-brain/trading-desk"
TICKS = f"{BASE}/logs/ticks.jsonl"
TRADES = f"{BASE}/logs/trades.jsonl"
SCORE = f"{BASE}/logs/scorecard.json"
PRODUCTS = ["BTC-USD", "ETH-USD", "SOL-USD"]
FAST, SLOW = 5, 20

def load_series(product):
    xs = []
    with open(TICKS) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            p = r.get("prices", {}).get(product)
            if p is not None:
                xs.append((r.get("ts"), float(p)))
    return xs

def sma(vals, n, i):
    if i + 1 < n:
        return None
    return sum(vals[i - n + 1: i + 1]) / n

def backtest(product):
    series = load_series(product)
    prices = [p for _, p in series]
    times = [t for t, _ in series]
    trades = []
    in_pos = False
    entry_px = entry_t = None
    prev_state = None
    for i in range(len(prices)):
        f, s = sma(prices, FAST, i), sma(prices, SLOW, i)
        if f is None or s is None:
            continue
        state = "long" if f > s else "flat"
        if prev_state is not None and state != prev_state:
            if state == "long" and not in_pos:
                in_pos, entry_px, entry_t = True, prices[i], times[i]
            elif state == "flat" and in_pos:
                ret = (prices[i] - entry_px) / entry_px
                trades.append({"product": product, "entry_t": entry_t,
                               "exit_t": times[i], "entry": entry_px,
                               "exit": prices[i], "ret_pct": round(ret * 100, 4),
                               "win": ret > 0})
                in_pos = False
        prev_state = state
    open_pos = None
    if in_pos:
        ret = (prices[-1] - entry_px) / entry_px
        open_pos = {"product": product, "entry_t": entry_t, "entry": entry_px,
                    "mark": prices[-1], "unreal_pct": round(ret * 100, 4)}
    return trades, open_pos

def main():
    all_trades, open_positions, per_product = [], [], {}
    for prod in PRODUCTS:
        trades, open_pos = backtest(prod)
        all_trades += trades
        if open_pos:
            open_positions.append(open_pos)
        wins = sum(1 for t in trades if t["win"])
        tot = sum(t["ret_pct"] for t in trades)
        per_product[prod] = {"closed_trades": len(trades),
                             "wins": wins,
                             "win_rate": round(wins / len(trades) * 100, 1) if trades else None,
                             "sum_ret_pct": round(tot, 4),
                             "avg_ret_pct": round(tot / len(trades), 4) if trades else None}
    n = len(all_trades)
    wins = sum(1 for t in all_trades if t["win"])
    tot = sum(t["ret_pct"] for t in all_trades)
    scorecard = {
        "generated": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "strategy": f"MA crossover fast={FAST} slow={SLOW}, paper long-only",
        "overall": {"closed_trades": n, "wins": wins,
                    "win_rate_pct": round(wins / n * 100, 1) if n else None,
                    "sum_ret_pct": round(tot, 4),
                    "avg_ret_pct": round(tot / n, 4) if n else None,
                    "expectancy_note": "avg return per closed paper trade, fees excluded"},
        "per_product": per_product,
        "open_positions": open_positions,
    }
    with open(TRADES, "w") as f:
        for t in all_trades:
            f.write(json.dumps(t) + "\n")
    with open(SCORE, "w") as f:
        json.dump(scorecard, f, indent=2)
    print(json.dumps(scorecard, indent=2))

if __name__ == "__main__":
    main()
