#!/usr/bin/env python3
"""
Leon Trading Desk — feed puller (paper mode, milestone 1).
Pulls live spot prices from Coinbase's public API (no auth, no money).
Appends every tick to logs/ticks.jsonl so we build a real price history
we can backtest against later. This is the receipts layer.
"""
import json, sys, time, urllib.request, datetime

PRODUCTS = ["BTC-USD", "ETH-USD", "SOL-USD"]
LOG = "/opt/leon-brain/trading-desk/logs/ticks.jsonl"

def utcnow():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pull(product):
    url = f"https://api.coinbase.com/v2/prices/{product}/spot"
    req = urllib.request.Request(url, headers={"User-Agent": "leon-tradingdesk/0.1"})
    with urllib.request.urlopen(req, timeout=10) as r:
        data = json.load(r)
    return float(data["data"]["amount"])

def main():
    row = {"ts": utcnow(), "prices": {}}
    for p in PRODUCTS:
        try:
            row["prices"][p] = pull(p)
        except Exception as e:
            row["prices"][p] = None
            row.setdefault("errors", {})[p] = str(e)
    with open(LOG, "a") as f:
        f.write(json.dumps(row) + "\n")
    print(json.dumps(row, indent=2))

if __name__ == "__main__":
    main()
