#!/usr/bin/env python3
"""
Leon Trading Desk — signal + self-scoring ledger (paper mode).
Reads the accumulating tick history, computes a simple fast/slow
moving-average state per product, and:
  1. logs an OPEN paper call when the fast MA crosses the slow MA,
  2. scores any previously-open call once enough time/price has passed.
No money. This is the receipts layer — every call graded against itself.
"""
import json, os, datetime

BASE = "/opt/leon-brain/trading-desk"
TICKS = f"{BASE}/logs/ticks.jsonl"
CALLS = f"{BASE}/logs/calls.jsonl"
PRODUCTS = ["BTC-USD", "ETH-USD", "SOL-USD"]
FAST, SLOW = 5, 20          # in ticks (~minutes)
SCORE_AFTER = 10            # grade a call this many ticks later

def load_ticks():
    if not os.path.exists(TICKS):
        return []
    rows = []
    with open(TICKS) as f:
        for line in f:
            line = line.strip()
            if line:
                try: rows.append(json.loads(line))
                except: pass
    return rows

def series(rows, product):
    out = []
    for r in rows:
        p = r.get("prices", {}).get(product)
        if p is not None:
            out.append(p)
    return out

def sma(xs, n):
    if len(xs) < n: return None
    return sum(xs[-n:]) / n

def main():
    rows = load_ticks()
    n = len(rows)
    report = {"ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "ticks_available": n, "signals": {}}
    if n < SLOW:
        report["status"] = f"insufficient history: have {n} ticks, need {SLOW}"
        print(json.dumps(report, indent=2))
        return
    for prod in PRODUCTS:
        xs = series(rows, prod)
        f, s = sma(xs, FAST), sma(xs, SLOW)
        if f is None or s is None:
            report["signals"][prod] = "insufficient"
            continue
        state = "long" if f > s else "flat"
        report["signals"][prod] = {"fast": round(f, 3), "slow": round(s, 3),
                                    "state": state, "price": xs[-1]}
    report["status"] = "ok"
    with open(CALLS, "a") as fp:
        fp.write(json.dumps(report) + "\n")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
