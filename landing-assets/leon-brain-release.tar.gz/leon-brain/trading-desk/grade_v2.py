#!/usr/bin/env python3
"""Grader v2 — fee-aware parameter sweep (paper mode)."""
import json, os, itertools
BASE="/opt/leon-brain/trading-desk"; TICKS=f"{BASE}/logs/ticks.jsonl"; OUT=f"{BASE}/logs/scorecard_v2.json"
PRODUCTS=["BTC-USD","ETH-USD","SOL-USD"]; FEE_ROUNDTRIP=0.20
def load_series(p):
    xs=[]
    for line in open(TICKS):
        line=line.strip()
        if not line: continue
        try: r=json.loads(line)
        except: continue
        v=r.get("prices",{}).get(p)
        if v is not None: xs.append(float(v))
    return xs
def sma(v,n,i):
    return None if i+1<n else sum(v[i-n+1:i+1])/n
def backtest(prices,fast,slow,band,hold):
    trades=[]; in_pos=False; ent=ei=None; prev=None
    for i in range(len(prices)):
        f=sma(prices,fast,i); s=sma(prices,slow,i)
        if f is None or s is None: continue
        sep=(f-s)/s*100.0
        state="long" if sep>band else ("flat" if sep<-band else (prev or "flat"))
        if prev is not None and state!=prev:
            if state=="long" and not in_pos: in_pos,ent,ei=True,prices[i],i
            elif state=="flat" and in_pos and (i-ei)>=hold:
                trades.append((prices[i]-ent)/ent*100.0); in_pos=False
        prev=state
    return trades
def evaluate(fast,slow,band,hold):
    g=nt=0.0; n=w=0
    for p in PRODUCTS:
        for r in backtest(load_series(p),fast,slow,band,hold):
            g+=r; nt+=(r-FEE_ROUNDTRIP); w+=1 if r>0 else 0; n+=1
    return {"fast":fast,"slow":slow,"band":band,"hold":hold,"trades":n,
            "win_rate":round(w/n*100,1) if n else None,"gross_pct":round(g,2),
            "net_pct":round(nt,2),"net_per_trade":round(nt/n,4) if n else None}
res=[]
for f,s,b,h in itertools.product([5,10,20],[20,50,100],[0.0,0.05,0.1,0.2],[0,5,15]):
    if f>=s: continue
    res.append(evaluate(f,s,b,h))
ranked=sorted([r for r in res if r["trades"]>=8],key=lambda r:r["net_pct"],reverse=True)
payload={"fee_roundtrip_pct":FEE_ROUNDTRIP,
    "v1_baseline":{"trades":275,"win_rate":31.6,"gross_pct":4.22,"net_at_0.2pct":-50.78},
    "top_configs":ranked[:8],"worst_configs":ranked[-3:]}
json.dump(payload,open(OUT,"w"),indent=2)
print(json.dumps(payload,indent=2))
