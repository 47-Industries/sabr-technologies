#!/usr/bin/env python3
"""Out-of-sample grader: frozen v2 config, only trades opened AFTER the
freeze timestamp count. This is the real receipt. Writes scorecard_oos.json."""
import json, datetime
BASE="/opt/leon-brain/trading-desk"; TICKS=f"{BASE}/logs/ticks.jsonl"
MARK=f"{BASE}/logs/oos_marker.json"; OUT=f"{BASE}/logs/scorecard_oos.json"
PRODUCTS=["BTC-USD","ETH-USD","SOL-USD"]
m=json.load(open(MARK)); cfg=m["frozen_config"]
FAST,SLOW,BAND,FEE=cfg["fast"],cfg["slow"],cfg["band_pct"],cfg["fee_roundtrip_pct"]
CUT=m["oos_cutoff_ts"]
def load(p):
    xs=[]
    for line in open(TICKS):
        line=line.strip()
        if not line: continue
        try: r=json.loads(line)
        except: continue
        v=r.get("prices",{}).get(p)
        if v is not None: xs.append((r.get("ts"),float(v)))
    return xs
def sma(v,n,i): return None if i+1<n else sum(v[i-n+1:i+1])/n
def bt(series):
    prices=[p for _,p in series]; times=[t for t,_ in series]
    trades=[]; in_pos=False; ent=et=None; prev=None
    for i in range(len(prices)):
        f=sma(prices,FAST,i); s=sma(prices,SLOW,i)
        if f is None or s is None: continue
        sep=(f-s)/s*100.0
        state="long" if sep>BAND else ("flat" if sep<-BAND else (prev or "flat"))
        if prev is not None and state!=prev:
            if state=="long" and not in_pos: in_pos,ent,et=True,prices[i],times[i]
            elif state=="flat" and in_pos:
                # only count trades ENTERED after cutoff
                if et>CUT:
                    trades.append((prices[i]-ent)/ent*100.0-FEE)
                in_pos=False
        prev=state
    return trades
allr=[]; per={}
for p in PRODUCTS:
    r=bt(load(p)); allr+=r
    per[p]={"trades":len(r),"net_pct":round(sum(r),3)}
n=len(allr); w=sum(1 for x in allr if x>0)
sc={"generated":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "mode":"OUT-OF-SAMPLE","frozen_config":cfg,"cutoff":CUT,
    "trades":n,"win_rate_pct":round(w/n*100,1) if n else None,
    "net_pct_after_fees":round(sum(allr),3) if n else 0.0,
    "per_product":per,
    "note":"trades entered strictly after freeze; this is the proof that counts"}
json.dump(sc,open(OUT,"w"),indent=2)
print(json.dumps(sc,indent=2))
