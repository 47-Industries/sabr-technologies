#!/usr/bin/env python3
"""Walk-forward self-teaching backtester (paper mode).
Train on a rolling window, pick the best fee-aware config, trade the NEXT
unseen window with it, roll forward. Every trade is out-of-sample."""
import json, itertools
BASE="/opt/leon-brain/trading-desk"; TICKS=f"{BASE}/logs/ticks.jsonl"
OUT=f"{BASE}/logs/walkforward.json"; PRODUCTS=["BTC-USD","ETH-USD","SOL-USD"]
FEE=0.20; TRAIN=1500; TEST=300; STEP=300
GRID=list(itertools.product([5,10,20],[50,100],[0.0,0.05,0.1,0.2]))
def load(p):
    xs=[]
    for line in open(TICKS):
        line=line.strip()
        if not line: continue
        try: v=json.loads(line)["prices"].get(p)
        except: v=None
        if v is not None: xs.append(float(v))
    return xs
def sma(v,n,i): return None if i+1<n else sum(v[i-n+1:i+1])/n
def run(prices,fast,slow,band,lo,hi):
    """trade prices[lo:hi], MAs may look back before lo. returns net rets list"""
    rets=[]; pos=False; ent=None; prev=None
    for i in range(len(prices)):
        f=sma(prices,fast,i); s=sma(prices,slow,i)
        if f is None or s is None: continue
        sep=(f-s)/s*100.0
        st="long" if sep>band else ("flat" if sep<-band else (prev or "flat"))
        if prev is not None and st!=prev and lo<=i<hi:
            if st=="long" and not pos: pos,ent=True,prices[i]
            elif st=="flat" and pos:
                rets.append((prices[i]-ent)/ent*100.0-FEE); pos=False
        prev=st
    return rets
def best_config(prices,lo,hi):
    bestc,bestnet=None,-1e9
    for f,s,b in GRID:
        if f>=s: continue
        r=run(prices,f,s,b,lo,hi)
        net=sum(r)
        if len(r)>=3 and net>bestnet: bestnet,bestc=net,(f,s,b)
    return bestc
allr=[]; picks={}
for p in PRODUCTS:
    prices=load(p); n=len(prices); prod_rets=[]
    start=TRAIN
    while start+TEST<=n:
        cfg=best_config(prices,start-TRAIN,start)  # train window
        if cfg:
            f,s,b=cfg
            prod_rets+=run(prices,f,s,b,start,start+TEST)  # trade unseen window
            picks[f"{p}:{start}"]=cfg
        start+=STEP
    allr+=prod_rets
n=len(allr); w=sum(1 for x in allr if x>0)
res={"mode":"WALK-FORWARD (all trades out-of-sample)","fee_roundtrip_pct":FEE,
     "train_win":TRAIN,"test_win":TEST,"trades":n,
     "win_rate_pct":round(w/n*100,1) if n else None,
     "net_pct_after_fees":round(sum(allr),2) if n else 0.0,
     "avg_per_trade":round(sum(allr)/n,4) if n else None,
     "n_reoptimizations":len(picks)}
json.dump(res,open(OUT,"w"),indent=2)
print(json.dumps(res,indent=2))
