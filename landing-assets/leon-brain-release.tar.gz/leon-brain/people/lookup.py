#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
PROFILES = Path(__file__).parent / "profiles.json"
ALIASES = {"geo": "gio", "sir": "dean", "boss": "dean", "wes": "wesley", "caria": "caaria", "carria": "caaria"}
def load():
    return json.loads(PROFILES.read_text())["people"]
def find(query, people):
    q = query.lower().strip()
    q = ALIASES.get(q, q)
    if q in people: return [q]
    hits = []
    for key, p in people.items():
        name = p.get("name", "").lower()
        if q in name or any(w == key or w in name.split() for w in re.findall(r"[a-z]+", q)):
            hits.append(key)
    return hits
def render(key, p):
    out = [f"{p['name']} — {p['role']}", f"  relationship: {p.get('relationship_to_dean','')}"]
    for f in ("projects", "deals", "preferences"):
        if p.get(f): out.append(f"  {f}: " + "; ".join(p[f]))
    if p.get("notes"): out.append(f"  notes: {p['notes']}")
    return "\n".join(out)
people = load()
if len(sys.argv) < 2:
    print(f"{len(people)} profiles: " + ", ".join(sorted(people)))
else:
    hits = find(" ".join(sys.argv[1:]), people)
    if not hits: print("No profile found.")
    for k in hits: print(render(k, people[k]) + "\n")
