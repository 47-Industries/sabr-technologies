"""
Leon-native Claude usage — removes the OctoGent dependency.

OctoGent fetched usage by reading the Claude Code OAuth token from
~/.claude/.credentials.json and GETting Anthropic's OAuth usage endpoint
(the "oauth-api" path in octogent's claudeUsage.ts). That is just an
authenticated HTTP GET — no PTY scraping needed — so we do it directly here,
inside Leon's own brain. This runs on the VPS where Leon's cognition burns
tokens, so the dashboard usage panel reflects the real account and works with
OctoGent stopped.

Output schema matches what the dashboard expects (see dashboard renderClaudeUsage
and _usageOffline): {status, fetchedAt, source, planType, primaryUsedPercent,
primaryResetAt, secondaryUsedPercent, secondaryResetAt, sonnetUsedPercent,
sonnetResetAt, extraUsageCostUsed, extraUsageCostLimit}.
"""

import json
import os
import threading
import time
import urllib.request
from datetime import datetime, timezone

_USAGE_URL = "https://api.anthropic.com/api/oauth/usage"
_BETA_HEADER = "oauth-2025-04-20"
_CREDS_PATH = os.path.expanduser("~/.claude/.credentials.json")

_CACHE_TTL_S = 60.0
_lock = threading.Lock()
_cache = {"snapshot": None, "ts": 0.0}


def _read_oauth():
    """(access_token, rate_limit_tier) from ~/.claude/.credentials.json, or (None, None)."""
    try:
        with open(_CREDS_PATH) as f:
            c = json.load(f)
    except Exception:
        return None, None
    oauth = c.get("claudeAiOauth") or c.get("claude_ai_oauth") or {}
    tok = oauth.get("accessToken") or oauth.get("access_token")
    tier = oauth.get("rateLimitTier") or oauth.get("rate_limit_tier")
    return (tok.strip() if isinstance(tok, str) else None), (tier if isinstance(tier, str) else None)


def _infer_plan(tier):
    t = (tier or "").lower()
    if "max" in t:
        return "Claude Max"
    if "pro" in t:
        return "Claude Pro"
    if "team" in t:
        return "Claude Team"
    if "enterprise" in t:
        return "Claude Enterprise"
    return None


def _window(payload, key):
    w = payload.get(key)
    if isinstance(w, dict):
        return w
    rl = payload.get("rate_limits") or payload.get("rateLimits")
    if isinstance(rl, dict):
        w = rl.get(key)
        if isinstance(w, dict):
            return w
    return None


def _pct(w):
    if not w:
        return None
    for k in ("used_percent", "usedPercent", "utilization"):
        v = w.get(k)
        if isinstance(v, (int, float)):
            return round(v)
    return None


def _reset(w):
    if not w:
        return None
    for k in ("reset_at", "resetAt", "resets_at"):
        v = w.get(k)
        if isinstance(v, str) and v.strip():
            return v
    return None


def _map(payload, tier):
    primary = _window(payload, "five_hour")
    weekly = _window(payload, "seven_day") or _window(payload, "seven_day_opus")
    sonnet = _window(payload, "seven_day_sonnet")
    extra = payload.get("extra_usage") or payload.get("extraUsage") or {}
    extra_used = extra_limit = None
    if isinstance(extra, dict) and (extra.get("is_enabled") or extra.get("isEnabled")):
        u = extra.get("used_credits") or extra.get("usedCredits")
        lim = extra.get("monthly_limit") or extra.get("monthlyLimit")
        if isinstance(u, (int, float)) and isinstance(lim, (int, float)):
            extra_used, extra_limit = u / 100.0, lim / 100.0
    return {
        "status": "ok",
        "fetchedAt": datetime.now(timezone.utc).isoformat(),
        "source": "leon-oauth",
        "planType": payload.get("plan_type") or payload.get("planType") or _infer_plan(tier),
        "primaryUsedPercent": _pct(primary),
        "primaryResetAt": _reset(primary),
        "secondaryUsedPercent": _pct(weekly),
        "secondaryResetAt": _reset(weekly),
        "sonnetUsedPercent": _pct(sonnet),
        "sonnetResetAt": _reset(sonnet),
        "extraUsageCostUsed": extra_used,
        "extraUsageCostLimit": extra_limit,
    }


def fetch_usage(timeout=8.0):
    """One live fetch. Returns a snapshot dict (status:'ok') or None on any failure."""
    tok, tier = _read_oauth()
    if not tok:
        return None
    req = urllib.request.Request(
        _USAGE_URL,
        headers={"Authorization": f"Bearer {tok}", "anthropic-beta": _BETA_HEADER},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            payload = json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return None
    try:
        return _map(payload, tier)
    except Exception:
        return None


def get_usage_cached(refresh=False, timeout=8.0):
    """Cached snapshot (60s TTL) so the 60s dashboard poll never hammers the API.
    Returns a dict or None (caller falls back to OctoGent / snapshot file)."""
    now = time.time()
    if not refresh:
        with _lock:
            snap = _cache["snapshot"]
            if snap is not None and (now - _cache["ts"]) < _CACHE_TTL_S:
                return snap
    snap = fetch_usage(timeout=timeout)
    if snap is not None:
        with _lock:
            _cache["snapshot"] = snap
            _cache["ts"] = now
    return snap
