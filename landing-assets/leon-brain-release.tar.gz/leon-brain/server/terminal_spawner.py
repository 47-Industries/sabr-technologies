"""
Terminal spawner abstraction — handles OS-specific terminal spawning.

Supports:
  - Linux: SSH to remote PC and use tmux
  - Windows: HTTP calls to Windows terminal service using ConPTY
  - macOS: (future) native macOS terminal spawning

Routes terminal spawning decisions based on target OS.
"""

import asyncio
import json
import logging
import os
import subprocess
from typing import Optional, Callable, Any

logger = logging.getLogger("leon.terminal_spawner")

# Get target OS from environment
TARGET_OS = os.environ.get("LEON_REMOTE_PC_OS", "linux").lower()
REMOTE_PC_HOST = os.environ.get("LEON_REMOTE_PC_HOST", "deansabr@100.64.191.119")
REMOTE_PC_BASE_URL = os.environ.get("LEON_REMOTE_PC_TERMINAL_URL", "http://100.67.121.44:9101")


class TerminalSpawner:
    """Abstract terminal spawner."""
    
    async def spawn(self, cwd: str, rows: int, cols: int, env: dict) -> str:
        """Spawn a terminal and return session ID."""
        raise NotImplementedError
    
    async def write(self, session_id: str, data: str) -> None:
        """Write data to a terminal."""
        raise NotImplementedError
    
    async def read(self, session_id: str, max_bytes: int = 4096) -> str:
        """Read data from a terminal."""
        raise NotImplementedError
    
    async def resize(self, session_id: str, rows: int, cols: int) -> None:
        """Resize a terminal."""
        raise NotImplementedError
    
    async def close(self, session_id: str) -> None:
        """Close a terminal."""
        raise NotImplementedError


class LinuxSSHSpawner(TerminalSpawner):
    """SSH-based terminal spawning for Linux."""
    
    async def spawn(self, cwd: str, rows: int, cols: int, env: dict) -> str:
        """Spawn a tmux session via SSH."""
        # This is a placeholder — actual implementation would create tmux sessions
        # For now, return a mock session ID
        session_id = f"ssh-{cwd.replace('/', '-')}"
        logger.info(f"[Linux/SSH] Spawning terminal in {cwd} -> {session_id}")
        return session_id
    
    async def write(self, session_id: str, data: str) -> None:
        logger.debug(f"[Linux/SSH] Write to {session_id}: {data[:50]}...")
    
    async def read(self, session_id: str, max_bytes: int = 4096) -> str:
        logger.debug(f"[Linux/SSH] Read from {session_id}")
        return ""
    
    async def resize(self, session_id: str, rows: int, cols: int) -> None:
        logger.debug(f"[Linux/SSH] Resize {session_id} to {rows}x{cols}")
    
    async def close(self, session_id: str) -> None:
        logger.info(f"[Linux/SSH] Close {session_id}")


class WindowsConPTYSpawner(TerminalSpawner):
    """ConPTY-based terminal spawning for Windows via HTTP."""
    
    async def spawn(self, cwd: str, rows: int, cols: int, env: dict) -> str:
        """Spawn a ConPTY terminal via HTTP API."""
        url = f"{REMOTE_PC_BASE_URL}/api/terminal/spawn"
        payload = {
            "cwd": cwd,
            "rows": rows,
            "cols": cols,
            "env": env,
        }
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    data = await resp.json()
                    if resp.status == 200:
                        session_id = data.get("session_id")
                        logger.info(f"[Windows/ConPTY] Spawned terminal in {cwd} -> {session_id}")
                        return session_id
                    else:
                        error = data.get("error", "Unknown error")
                        logger.error(f"[Windows/ConPTY] Spawn failed: {error}")
                        raise Exception(f"Terminal spawn failed: {error}")
        except Exception as e:
            logger.error(f"[Windows/ConPTY] Spawn error: {e}")
            raise
    
    async def write(self, session_id: str, data: str) -> None:
        """Write data to a terminal."""
        url = f"{REMOTE_PC_BASE_URL}/api/terminal/{session_id}/write"
        payload = {"data": data}
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status != 200:
                        error = await resp.text()
                        logger.warning(f"[Windows/ConPTY] Write error: {error}")
        except Exception as e:
            logger.error(f"[Windows/ConPTY] Write error: {e}")
    
    async def read(self, session_id: str, max_bytes: int = 4096) -> str:
        """Read data from a terminal."""
        url = f"{REMOTE_PC_BASE_URL}/api/terminal/{session_id}/read?bytes={max_bytes}"
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        return data.get("data", "")
                    else:
                        logger.warning(f"[Windows/ConPTY] Read error: {resp.status}")
                        return ""
        except Exception as e:
            logger.error(f"[Windows/ConPTY] Read error: {e}")
            return ""
    
    async def resize(self, session_id: str, rows: int, cols: int) -> None:
        """Resize a terminal."""
        url = f"{REMOTE_PC_BASE_URL}/api/terminal/{session_id}/resize"
        payload = {"rows": rows, "cols": cols}
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status != 200:
                        logger.warning(f"[Windows/ConPTY] Resize error: {resp.status}")
        except Exception as e:
            logger.error(f"[Windows/ConPTY] Resize error: {e}")
    
    async def close(self, session_id: str) -> None:
        """Close a terminal."""
        url = f"{REMOTE_PC_BASE_URL}/api/terminal/{session_id}/close"
        
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.post(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    if resp.status == 200:
                        logger.info(f"[Windows/ConPTY] Closed {session_id}")
                    else:
                        logger.warning(f"[Windows/ConPTY] Close error: {resp.status}")
        except Exception as e:
            logger.error(f"[Windows/ConPTY] Close error: {e}")


def get_spawner() -> TerminalSpawner:
    """Get the appropriate spawner for the target OS."""
    if TARGET_OS == "windows":
        logger.info(f"Using Windows ConPTY spawner (target: {REMOTE_PC_BASE_URL})")
        return WindowsConPTYSpawner()
    elif TARGET_OS == "linux":
        logger.info(f"Using Linux SSH spawner (target: {REMOTE_PC_HOST})")
        return LinuxSSHSpawner()
    elif TARGET_OS == "macos":
        logger.warning("macOS spawner not yet implemented, falling back to SSH")
        return LinuxSSHSpawner()
    else:
        logger.warning(f"Unknown target OS: {TARGET_OS}, falling back to SSH")
        return LinuxSSHSpawner()


# Global spawner instance
_spawner: Optional[TerminalSpawner] = None


def spawner() -> TerminalSpawner:
    """Get or create the spawner."""
    global _spawner
    if _spawner is None:
        _spawner = get_spawner()
    return _spawner
