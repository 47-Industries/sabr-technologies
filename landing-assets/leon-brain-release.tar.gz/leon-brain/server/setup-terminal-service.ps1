# Windows Terminal Service Complete Setup
# This script installs dependencies, downloads the service, and runs it

Write-Host "Installing Python dependencies..."
pip install -q pywinpty aiohttp

Write-Host "Creating directory structure..."
$serviceDir = "C:\Users\Mr. Sabr\leon-brain\server"
New-Item -ItemType Directory -Force -Path $serviceDir | Out-Null

Write-Host "Downloading terminal service..."
$url = "$($env:LEON_BRAIN_URL)/windows_terminal_service.py"
$outfile = "$serviceDir\windows_terminal_service.py"
try {
    Invoke-WebRequest -Uri $url -OutFile $outfile -UseBasicParsing -ErrorAction Stop
    Write-Host "Downloaded successfully: $outfile"
} catch {
    Write-Host "Download failed: $_"
    exit 1
}

Write-Host "Starting Windows Terminal Service on port 9101..."
Write-Host "Service will stay running. Press Ctrl+C to stop."
python "$serviceDir\windows_terminal_service.py" --port 9101
