#!/usr/bin/env python3
"""
Terminal integration for dashboard.
Handles spawning and managing terminals via the VPS terminal service.
"""

import asyncio
import logging
import httpx

logger = logging.getLogger("dashboard-terminal")

class TerminalManager:
    def __init__(self, vps_terminal_url="http://127.0.0.1:9102"):
        self.vps_url = vps_terminal_url
        self.sessions = {}  # Track active sessions locally too
    
    async def spawn(self, cwd="/root", shell="/bin/bash"):
        """Spawn a new terminal session."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.post(
                    f"{self.vps_url}/api/terminal/spawn",
                    json={"cwd": cwd, "shell": shell}
                )
                response.raise_for_status()
                data = response.json()
                session_id = data["session_id"]
                self.sessions[session_id] = {
                    "cwd": cwd,
                    "shell": shell,
                    "pid": data["pid"]
                }
                logger.info(f"Spawned terminal {session_id} (PID {data['pid']})")
                return session_id
            except Exception as e:
                logger.error(f"Spawn failed: {e}")
                raise
    
    async def write(self, session_id, data):
        """Write data to a terminal."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.post(
                    f"{self.vps_url}/api/terminal/{session_id}/write",
                    json={"data": data}
                )
                response.raise_for_status()
                return True
            except Exception as e:
                logger.error(f"Write to {session_id} failed: {e}")
                raise
    
    async def read(self, session_id):
        """Read output from a terminal."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.get(
                    f"{self.vps_url}/api/terminal/{session_id}/read"
                )
                response.raise_for_status()
                data = response.json()
                return data.get("output", "")
            except Exception as e:
                logger.error(f"Read from {session_id} failed: {e}")
                raise
    
    async def list(self):
        """List all active terminals."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.get(
                    f"{self.vps_url}/api/terminal/list"
                )
                response.raise_for_status()
                data = response.json()
                return data.get("sessions", [])
            except Exception as e:
                logger.error(f"List terminals failed: {e}")
                raise
    
    async def kill(self, session_id):
        """Kill a terminal session."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.delete(
                    f"{self.vps_url}/api/terminal/{session_id}/kill"
                )
                response.raise_for_status()
                if session_id in self.sessions:
                    del self.sessions[session_id]
                logger.info(f"Killed terminal {session_id}")
                return True
            except Exception as e:
                logger.error(f"Kill terminal {session_id} failed: {e}")
                raise

# For use in dashboard routes
terminal_manager = None

async def get_terminal_manager():
    global terminal_manager
    if not terminal_manager:
        terminal_manager = TerminalManager()
    return terminal_manager

# Example WebSocket handler for terminal in dashboard
async def websocket_terminal_handler(request):
    """Handle terminal WebSocket connections."""
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    
    # Extract session_id from query params
    session_id = request.rel_url.query.get("session_id")
    if not session_id:
        # Spawn new terminal
        manager = await get_terminal_manager()
        try:
            session_id = await manager.spawn()
            await ws.send_json({"type": "spawned", "session_id": session_id})
        except Exception as e:
            await ws.send_json({"type": "error", "message": str(e)})
            await ws.close()
            return ws
    
    manager = await get_terminal_manager()
    
    try:
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                data = json.loads(msg.data)
                cmd = data.get("cmd")
                
                if cmd == "write":
                    await manager.write(session_id, data.get("data", ""))
                elif cmd == "read":
                    output = await manager.read(session_id)
                    await ws.send_json({"type": "output", "data": output})
                elif cmd == "kill":
                    await manager.kill(session_id)
                    await ws.send_json({"type": "killed"})
                    break
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        await ws.close()
    
    return ws
