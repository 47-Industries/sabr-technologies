#!/usr/bin/env python3
"""
Terminal integration for dashboard.
Handles spawning and managing terminals via the VPS terminal service.
"""

import asyncio
import logging
import httpx

logger = logging.getLogger("dashboard-terminal")

class TerminalManager:
    def __init__(self, vps_terminal_url="http://127.0.0.1:9102"):
        self.vps_url = vps_terminal_url
        self.sessions = {}  # Track active sessions locally too
    
    async def spawn(self, cwd="/root", shell="/bin/bash"):
        """Spawn a new terminal session."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.post(
                    f"{self.vps_url}/api/terminal/spawn",
                    json={"cwd": cwd, "shell": shell}
                )
                response.raise_for_status()
                data = response.json()
                session_id = data["session_id"]
                self.sessions[session_id] = {
                    "cwd": cwd,
                    "shell": shell,
                    "pid": data["pid"]
                }
                logger.info(f"Spawned terminal {session_id} (PID {data['pid']})")
                return session_id
            except Exception as e:
                logger.error(f"Spawn failed: {e}")
                raise
    
    async def write(self, session_id, data):
        """Write data to a terminal."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.post(
                    f"{self.vps_url}/api/terminal/{session_id}/write",
                    json={"data": data}
                )
                response.raise_for_status()
                return True
            except Exception as e:
                logger.error(f"Write to {session_id} failed: {e}")
                raise
    
    async def read(self, session_id):
        """Read output from a terminal."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.get(
                    f"{self.vps_url}/api/terminal/{session_id}/read"
                )
                response.raise_for_status()
                data = response.json()
                return data.get("output", "")
            except Exception as e:
                logger.error(f"Read from {session_id} failed: {e}")
                raise
    
    async def list(self):
        """List all active terminals."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.get(
                    f"{self.vps_url}/api/terminal/list"
                )
                response.raise_for_status()
                data = response.json()
                return data.get("sessions", [])
            except Exception as e:
                logger.error(f"List terminals failed: {e}")
                raise
    
    async def kill(self, session_id):
        """Kill a terminal session."""
        async with httpx.AsyncClient(timeout=5.0) as client:
            try:
                response = await client.delete(
                    f"{self.vps_url}/api/terminal/{session_id}/kill"
                )
                response.raise_for_status()
                if session_id in self.sessions:
                    del self.sessions[session_id]
                logger.info(f"Killed terminal {session_id}")
                return True
            except Exception as e:
                logger.error(f"Kill terminal {session_id} failed: {e}")
                raise

# For use in dashboard routes
terminal_manager = None

async def get_terminal_manager():
    global terminal_manager
    if not terminal_manager:
        terminal_manager = TerminalManager()
    return terminal_manager

# NOTE: an aiohttp-style `websocket_terminal_handler` used to live here. It was
# dead scaffolding — nothing in the codebase ever imported this module, aiohttp
# is not a dependency (this server is FastAPI/httpx), and the function
# referenced three names that were never imported (web, aiohttp, json), so it
# would have raised NameError on the first call. Removed rather than "fixed":
# repairing code no caller reaches only makes the next reader think it works.
# The real terminal WebSocket lives in server/routers/, and TerminalManager
# above is the piece worth keeping.
