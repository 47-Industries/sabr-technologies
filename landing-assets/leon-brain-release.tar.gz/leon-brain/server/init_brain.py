"""
Brain initialization and simulation loop.

Extracted from server.py. All globals are accessed via `from server import state`.
"""

import logging
import os
import sys
import threading
import time

from brain.brain import Brain
from brain.config import BrainConfig
from brain.persistence import save_brain, load_brain
from brain.claude_bridge import ClaudeBridge
from brain.screen_observer import ScreenObserver
from brain.video_recorder import VideoRecorder
from brain.agent import build_default_agent
from brain.tools import describe_tools
from brain.sleep_consolidation import SleepConsolidator
from brain.cognition import bootstrap as cognition_bootstrap
from brain.mission import (
    ProjectRegistry, MissionStateEngine, ExternalConnectors,
    CredentialAwareness, DecisionRegistry, OpsLoop,
    ActionExecutor, ActionPlanner, AutopilotScheduler,
)
from brain.plugins import discover_and_load as _load_plugins

from sensory.text import TextEncoder
from sensory.vision import VisionEncoder
from sensory.audio import AudioEncoder

from server import state
from server.helpers import (
    _broadcast_threadsafe, _tts_synthesize_b64, _ensure_tts,
    _make_knowledge_search_tool, _make_reminder_tools,
    _make_webcam_tool, _make_vision_describe_tool, _make_click_element_tool,
    _make_broadcast_confirm_callback,
)

log = logging.getLogger("leon.server")


def init_brain():
    """Initialize the brain and sensory encoders."""
    # Create the responder lock FIRST — before any system that might use it.
    # Previously this was created inside proactive_loop init, meaning if
    # proactive was disabled, the lock never existed and other systems
    # (consciousness, dreaming, goals) would skip locking entirely.
    import threading
    if not hasattr(state, "_responder_lock") or state._responder_lock is None:
        state._responder_lock = threading.Lock()

    # ── Boot progress bar ────────────────────────────────────────────
    # A clean staged bar so first boot reads like a professional product
    # coming online, not a wall of raw logs. Stages fire at real phases.
    def _stage(pct, label):
        try:
            filled = max(0, min(20, int(pct / 5)))
            bar = "█" * filled + "░" * (20 - filled)
            print(f"\033[96m  [{bar}] {pct:3d}%\033[0m  {label}", flush=True)
        except Exception:
            pass
    state._boot_stage = _stage
    _stage(10, "Building the brain...")

    state.brain = Brain()
    _stage(30, "Neural cortex assembled")

    # Seed client facts on first boot (if this is a client SI, not Leon)
    try:
        from brain.seed_client_facts import seed_client_facts
        seed_client_facts()
    except Exception as e:
        log.warning(f"[BRAIN] Client fact seeding skipped: {e}")

    # Phase 7 — wire reward signals
    try:
        state.brain_api_responder.reward_callback = lambda s, src: state.brain.reward_pulse(s, src)
        print("[BRAIN] Reward signal path wired (Phase 7)")
    except Exception as e:
        log.warning(f"[BRAIN] Reward wiring failed: {e}", exc_info=True)
    state.text_encoder = TextEncoder(feature_dim=256)
    state.vision_encoder = VisionEncoder(feature_dim=256)
    state.audio_encoder = AudioEncoder(feature_dim=256)
    # Start microphone — Leon's ears
    try:
        state.audio_encoder.start_microphone()
    except Exception as e:
        log.warning(f"[AUDIO] mic start failed (non-fatal): {e}")
    state.claude_bridge = ClaudeBridge(state.brain)
    state.screen_observer = ScreenObserver(feature_dim=256, capture_interval=2.0)
    state.screen_observer.attach_brain(
        brain=state.brain,
        text_encoder=state.text_encoder,
        knowledge_store=state.claude_bridge.knowledge,
    )
    # START screen observer — Leon needs continuous visual input
    # DISPLAY and WAYLAND_DISPLAY are X11/Wayland variables. They exist ONLY
    # on Linux. Gating the screen observer on them meant that on Windows and
    # macOS this branch could never be true — so EVERY Windows and Mac SI ever
    # installed was permanently blind to the screen, from birth, and said so
    # in one log line the owner had no reason to read. It was not a broken
    # capture, a missing permission, or a driver: the code simply never tried.
    # Observed 2026-08-11 on a healthy Windows install that could hear, speak,
    # think and pursue goals, and still reported "no display available".
    #
    # A Windows or macOS process running in a real user session ALWAYS has a
    # desktop. So only Linux needs the env check; elsewhere, just start and
    # let the exception handler below deal with a genuine capture failure —
    # which is the honest test anyway, since a headless Windows service will
    # fail the grab and be caught, rather than being guessed at up front.
    try:
        headless_linux = (
            sys.platform.startswith("linux")
            and not os.environ.get("DISPLAY")
            and not os.environ.get("WAYLAND_DISPLAY")
        )
        if headless_linux:
            print("[SCREEN] No display available — screen observer disabled")
        else:
            state.screen_observer.start()
    except Exception as e:
        log.warning(f"[SCREEN] start failed (non-fatal): {e}")
    state.video_recorder = VideoRecorder(fps=10, segment_minutes=10)

    # V1.3: auto-discover plugins
    try:
        loaded_plugins = _load_plugins()
        if loaded_plugins:
            print(f"[SERVER] Loaded {len(loaded_plugins)} plugin(s): "
                  f"{[p.name for p in loaded_plugins]}")
    except Exception as e:
        log.warning(f"[SERVER] Plugin discovery failed (non-fatal): {e}", exc_info=True)

    # V1.3: agent execution layer
    state.agent = build_default_agent()
    if state.agent is not None and state.claude_bridge is not None:
        state.agent.knowledge_store = state.claude_bridge.knowledge
    print("[SERVER] Agent ready — tools available:",
          [t["name"] for t in describe_tools()])

    # V1.3: sleep consolidation
    try:
        if state.claude_bridge is not None and state.claude_bridge.knowledge is not None:
            state.sleep_consolidator = SleepConsolidator(
                knowledge_store=state.claude_bridge.knowledge,
                idle_threshold_sec=300.0,
                hourly_tick=True,
            )
            state.sleep_consolidator.start()
            print("[SERVER] Sleep consolidator running")
    except Exception as e:
        log.warning(f"[SERVER] Sleep consolidator disabled (non-fatal): {e}", exc_info=True)

    # Project context crawler
    state.project_crawler = None
    try:
        if state.claude_bridge is not None and state.claude_bridge.knowledge is not None:
            from brain.project_crawler import ProjectCrawler
            state.project_crawler = ProjectCrawler(
                knowledge_store=state.claude_bridge.knowledge,
                roots=[os.path.expanduser("~/Desktop")],
            )
            state.project_crawler.start_background()
            print("[SERVER] Project crawler started — indexing ~/Desktop")
    except Exception as e:
        log.warning(f"[SERVER] Project crawler disabled (non-fatal): {e}", exc_info=True)

    # Conversation distiller
    try:
        if state.claude_bridge is not None and state.claude_bridge.knowledge is not None:
            from brain.conversation_distiller import ConversationDistiller
            state.conv_distiller = ConversationDistiller(
                knowledge_store=state.claude_bridge.knowledge,
                working_window=int(os.environ.get("LEON_DISTILL_WINDOW", "80")),
            )
            state.conv_distiller.start()
    except Exception as e:
        log.warning(f"[SERVER] Conversation distiller disabled (non-fatal): {e}", exc_info=True)

    # Memory consolidation daemon (promotion engine)
    state.memory_consolidation = None
    try:
        from brain.memory_consolidation import MemoryConsolidationDaemon
        state.memory_consolidation = MemoryConsolidationDaemon()
        state.memory_consolidation.start()
    except Exception as e:
        log.warning(f"[SERVER] Memory consolidation disabled (non-fatal): {e}", exc_info=True)

    # Conversation journal — generate recap from last session + start periodic saves
    try:
        from brain.conversation_journal import generate_session_recap, save_session_transcript
        import threading as _jt
        recap = generate_session_recap()
        if recap:
            print(f"[SERVER] Session recap loaded ({len(recap)} chars) — Leon knows what happened last time")
        else:
            print("[SERVER] No previous session recap found (first boot?)")

        # Periodic journal save every 30 min
        def _journal_loop():
            import time as _t
            _t.sleep(300)  # wait 5 min before first save
            while True:
                try:
                    save_session_transcript()
                except Exception as e:
                    print(f"[JOURNAL] periodic save failed: {e}")
                _t.sleep(1800)  # every 30 min
        _jt.Thread(target=_journal_loop, name="JournalSaver", daemon=True).start()
    except Exception as e:
        log.warning(f"[SERVER] Conversation journal disabled (non-fatal): {e}", exc_info=True)

    # Neural encoder + retriever
    neural_encoder = None
    neural_retriever = None
    try:
        if state.claude_bridge is not None and state.claude_bridge.knowledge is not None:
            from brain.neural_encoder import NeuralEncoder
            from brain.neural_retriever import NeuralRetriever
            from brain.knowledge_store import set_neural_encoder, backfill_neural_fingerprints
            neural_encoder = NeuralEncoder()
            set_neural_encoder(neural_encoder)
            neural_retriever = NeuralRetriever(state.claude_bridge.knowledge, neural_encoder)
            print("[SERVER] Neural encoder + retriever wired (hybrid retrieval)")
            def _run_backfill():
                import time as _t
                _t0 = _t.time()
                n = backfill_neural_fingerprints(
                    state.claude_bridge.knowledge, neural_encoder, only_missing=True)
                _dt = _t.time() - _t0
                if n > 0:
                    print(f"[ENCODER] backfilled {n} knowledge rows in {_dt:.1f}s")
                if neural_retriever is not None:
                    neural_retriever.mark_dirty()
            threading.Thread(target=_run_backfill, daemon=True,
                              name="NeuralBackfill").start()
    except Exception as e:
        log.warning(f"[SERVER] Neural encoder/retriever wiring failed (non-fatal): {e}", exc_info=True)

    # Wire knowledge_search
    if state.brain_api_responder is not None:
        state.brain_api_responder.local_tools["knowledge_search"] = _make_knowledge_search_tool(
            lambda: state.claude_bridge.knowledge if state.claude_bridge else None,
            lambda: neural_retriever,
        )
        print("[BRAIN] knowledge_search wired into responder (hybrid)")

    # Reminder scheduler
    try:
        from brain.reminders import ReminderScheduler
        from brain.actuator_client import call as _act_call
        state.reminder_scheduler = ReminderScheduler(
            notify_callable=lambda args: _act_call("notify", args),
            broadcast_callable=_broadcast_threadsafe,
        )
        state.reminder_scheduler.start()
        print(f"[BRAIN] reminder scheduler started")
    except Exception as e:
        log.warning(f"[BRAIN] reminder scheduler disabled: {e}", exc_info=True)
        state.reminder_scheduler = None

    # Proactive routine scheduler
    state.routine_scheduler = None
    try:
        from brain.routines import start_routine_scheduler
        from brain.actuator_client import call as _act_call

        def _routine_knowledge_search(q: str):
            fn = state.brain_api_responder.local_tools.get("knowledge_search") if state.brain_api_responder else None
            if not callable(fn):
                return []
            res = fn({"query": q, "limit": 5})
            return (res or {}).get("result") or []

        state.routine_scheduler = start_routine_scheduler(
            brain_responder=state.brain_api_responder,
            actuator_call=lambda tool, args: _act_call(tool, args),
            knowledge_search=_routine_knowledge_search,
            notify=lambda args: _act_call("notify", args),
            tts_for_text=_tts_synthesize_b64,
            broadcast=_broadcast_threadsafe,
        )
        print("[BRAIN] routine scheduler started")

        # Self-audit routine — Leon checks his own goal state every hour
        try:
            from brain.self_audit import register_self_audit_routine
            if register_self_audit_routine():
                print("[BRAIN] self-audit routine registered (every 1h)")
            else:
                log.warning("[BRAIN] self-audit routine failed to register")
        except Exception as _sa_err:
            log.warning(f"[BRAIN] self_audit not registered: {_sa_err}")

        # Self-repair routine — Leon fixes his own internal problems every 30 min
        try:
            from brain.self_repair import register_self_repair_routine
            if register_self_repair_routine():
                print("[BRAIN] self-repair routine registered (every 30m)")
            else:
                log.warning("[BRAIN] self-repair routine failed to register")
        except Exception as _sr_err:
            log.warning(f"[BRAIN] self_repair not registered: {_sr_err}")

    except Exception as e:
        log.warning(f"[BRAIN] routine scheduler disabled: {e}", exc_info=True)
        state.routine_scheduler = None

    if state.brain_api_responder is not None:
        for name, fn in _make_reminder_tools(lambda: state.reminder_scheduler).items():
            state.brain_api_responder.local_tools[name] = fn
        print("[BRAIN] reminder_* tools wired into responder")

        # Routine control tools
        try:
            from brain.routines import (
                routine_list as _rt_list,
                routine_run_now as _rt_run,
                routine_enable as _rt_enable,
                routine_disable as _rt_disable,
            )

            def _rt_tool(fn, *, needs_name):
                def _wrapped(args):
                    args = args or {}
                    if state.routine_scheduler is None:
                        return {"ok": False, "error": "routine scheduler not running"}
                    try:
                        if needs_name:
                            nm = (args.get("name") or "").strip()
                            if not nm:
                                return {"ok": False, "error": "name is required"}
                            return {"ok": True, "result": fn(nm)}
                        return {"ok": True, "result": fn()}
                    except Exception as e:
                        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
                return _wrapped

            state.brain_api_responder.local_tools["routine_list"] = _rt_tool(_rt_list, needs_name=False)
            state.brain_api_responder.local_tools["routine_run_now"] = _rt_tool(_rt_run, needs_name=True)
            state.brain_api_responder.local_tools["routine_enable"] = _rt_tool(_rt_enable, needs_name=True)
            state.brain_api_responder.local_tools["routine_disable"] = _rt_tool(_rt_disable, needs_name=True)
            print("[BRAIN] routine_* tools wired into responder")
        except Exception as e:
            log.warning(f"[BRAIN] routine_* tools not wired: {e}", exc_info=True)

        # Webcam + vision tools
        webcam_tool_fn = _make_webcam_tool()
        state.brain_api_responder.local_tools["webcam_capture"] = webcam_tool_fn
        print("[BRAIN] webcam_capture wired into responder")

        state.brain_api_responder.local_tools["vision_describe"] = _make_vision_describe_tool(
            lambda: webcam_tool_fn,
        )
        print("[BRAIN] vision_describe wired into responder")

        state.brain_api_responder.local_tools["click_element"] = _make_click_element_tool()
        print("[BRAIN] click_element (Moondream-backed) wired into responder")

        # Self-modification tools
        try:
            from brain.agent_tools import (
                http_request as _agent_http_request,
                code_edit as _agent_code_edit,
                code_restore as _agent_code_restore,
                restart_self as _agent_restart_self,
                shell_exec as _agent_shell_exec,
            )
            state.brain_api_responder.local_tools["http_request"]  = _agent_http_request
            state.brain_api_responder.local_tools["code_edit"]     = _agent_code_edit
            state.brain_api_responder.local_tools["code_restore"]  = _agent_code_restore
            state.brain_api_responder.local_tools["restart_self"]  = _agent_restart_self
            state.brain_api_responder.local_tools["shell_exec"]    = _agent_shell_exec
            print("[BRAIN] self-mod tools (http_request, code_edit, code_restore, restart_self, shell_exec) wired — UNRESTRICTED")
        except Exception as e:
            log.warning(f"[BRAIN] self-mod tools NOT wired: {e}", exc_info=True)

        # Memory-extras & introspection
        for mod_name, label in [
            ("brain.memory_extras", "memory_extras"),
            ("brain.introspection", "introspection"),
            ("brain.tentacle_orchestration", "tentacle_orchestration"),
            ("brain.reports", "reports"),
            ("brain.presence", "presence"),
            ("brain.sub_agents", "sub_agents"),
        ]:
            try:
                _m = __import__(mod_name, fromlist=["EXTRA_TOOLS"])
                _et = getattr(_m, "EXTRA_TOOLS", {})
                for _dot_name, _fn in _et.items():
                    state.brain_api_responder.local_tools[_dot_name.replace(".", "_")] = _fn
                print(f"[BRAIN] {label} wired ({len(_et)} tools)")
            except Exception as e:
                log.warning(f"[BRAIN] {label} NOT wired: {e}", exc_info=True)

        # Lazy-load integration modules
        _LAZY_MODULES = {
            "brain.integrations.comms": "comms", "brain.integrations.smart_home": "smart_home",
            "brain.integrations.phone": "phone", "brain.self_improve": "self_improve",
            "brain.macros": "macros", "brain.integrations.research": "research",
            "brain.integrations.productivity": "productivity", "brain.integrations.ai_providers": "ai_providers",
            "brain.integrations.life": "life", "brain.integrations.coding": "coding",
            "brain.integrations.workflow": "workflow", "brain.integrations.fun": "fun",
            "brain.integrations.notes": "notes", "brain.integrations.media": "media",
            "brain.integrations.netsys": "netsys", "brain.autopilot": "autopilot",
            "brain.integrations.cloud_storage": "cloud_storage", "brain.integrations.github_cicd": "github_cicd",
            "brain.integrations.commerce": "commerce", "brain.integrations.maps": "maps",
            "brain.integrations.docgen": "docgen", "brain.integrations.database": "database",
            "brain.integrations.crypto": "crypto", "brain.integrations.search_social": "search_social",
            "brain.integrations.image_ai": "image_ai", "brain.integrations.audio_record": "audio_record",
            "brain.integrations.file_search": "file_search", "brain.integrations.automation": "automation",
            "brain.integrations.finance": "finance", "brain.integrations.crm_reading": "crm_reading",
            "brain.integrations.secrets": "secrets", "brain.integrations.wellness": "wellness",
            "brain.integrations.pc_control": "pc_control", "brain.integrations.email_power": "email_power",
            "brain.integrations.calendar_power": "calendar_power", "brain.integrations.learning": "learning",
            "brain.integrations.project_mgmt": "project_mgmt", "brain.integrations.marketing": "marketing",
            "brain.integrations.video_production": "video_production", "brain.integrations.agent_pool": "agent_pool",
            "brain.integrations.accounting": "accounting", "brain.integrations.entertainment": "entertainment",
            "brain.integrations.devtools": "devtools", "brain.integrations.travel": "travel",
            "brain.integrations.design": "design", "brain.integrations.legal": "legal",
            "brain.integrations.security": "security", "brain.integrations.focus": "focus",
        }

        _lazy_tool_map: dict[str, str] = {}
        _lazy_loaded: set[str] = set()

        def _scan_lazy_tools():
            import re
            for mod_path in _LAZY_MODULES:
                file_path = mod_path.replace(".", "/") + ".py"
                if not os.path.exists(file_path):
                    continue
                try:
                    with open(file_path) as f:
                        content = f.read()
                    for match in re.findall(r'"([a-z][a-z0-9_.]+)"\s*:', content):
                        if "." in match:
                            _lazy_tool_map[match.replace(".", "_")] = mod_path
                except Exception:
                    pass

        _scan_lazy_tools()
        print(f"[BRAIN] {len(_lazy_tool_map)} lazy tools mapped from {len(_LAZY_MODULES)} modules (none loaded yet)")

        _original_local_tools = state.brain_api_responder.local_tools

        _lazy_load_lock = threading.Lock()

        class _LazyToolDict(dict):
            def __missing__(self, key):
                with _lazy_load_lock:
                    if key in self:
                        return self[key]  # another thread loaded it
                    mod_path = _lazy_tool_map.get(key)
                    if mod_path and mod_path not in _lazy_loaded:
                        try:
                            _m = __import__(mod_path, fromlist=["EXTRA_TOOLS"])
                            _et = getattr(_m, "EXTRA_TOOLS", {})
                            for _dot_name, _fn in _et.items():
                                self[_dot_name.replace(".", "_")] = _fn
                            _lazy_loaded.add(mod_path)
                            label = _LAZY_MODULES.get(mod_path, mod_path)
                            print(f"[BRAIN] lazy-loaded {label} ({len(_et)} tools)")
                            if key in self:
                                return self[key]
                        except Exception as e:
                            log.warning(f"[BRAIN] lazy-load failed for {mod_path}: {e}", exc_info=True)
                raise KeyError(key)

        lazy_tools = _LazyToolDict(_original_local_tools)
        state.brain_api_responder.local_tools = lazy_tools

    # Wire business platform tools (lead gen, CRM, outreach, telephony)
    try:
        from business.brain_integration import BUSINESS_TOOLS, handle_business_tool
        for tool_def in BUSINESS_TOOLS:
            tool_name = tool_def["name"]
            state.brain_api_responder.local_tools[tool_name] = (
                lambda inp, _tn=tool_name: {"ok": True, "result": handle_business_tool(_tn, inp)}
            )
        print(f"[BRAIN] Business platform wired ({len(BUSINESS_TOOLS)} tools: "
              f"business_find_leads, business_list_leads, business_send_outreach, "
              f"business_send_sms, business_generate_demo, ...)")
    except Exception as e:
        log.warning(f"[BRAIN] Business platform NOT wired: {e}", exc_info=True)

    # Pre-warm claude sessions (user + daemon) — but only after uvicorn
    # serves the tool catalog. Arming earlier hands the leon MCP server an
    # empty catalog and the session stays TOOLLESS for its whole life
    # (claude calls list_tools exactly once at the handshake). This was
    # why Leon kept improvising with Bash+curl instead of his real tools:
    # the old code slept 3s and armed ~45s before the HTTP API was up.
    def _prewarm_claude_session():
        try:
            import time as _t
            from brain.claude_api_responder import (
                _get_persistent_session, _brain_tools_ready,
            )
            t0 = _t.time()
            while _t.time() - t0 < 180:
                if _brain_tools_ready():
                    break
                _t.sleep(2.0)
            else:
                log.warning("[BRAIN] tool API never came up — skipping "
                            "session pre-warm (first turn will arm)")
                return
            for kind, daemon in (("user", False), ("daemon", True)):
                session = _get_persistent_session(daemon=daemon)
                if session is None:
                    continue
                t1 = _t.time()
                # MUST close the generator. ask() yields from inside
                # `with self._lock:`, so breaking out here strands the lock
                # held — and because this pre-warm runs at BOOT, before any
                # real turn, it poisons the session before the owner has said
                # a single word. That is the "give me a second on every
                # message, forever, with zero conversations ever logged"
                # failure found on a customer machine 2026-08-11.
                _warm_gen = session.ask("[warmup]", timeout=30)
                for ev in _warm_gen:
                    if ev.type in ("done", "error"):
                        break
                try:
                    _warm_gen.close()
                except Exception:
                    pass
                print(f"[BRAIN] persistent {kind} session pre-warmed in "
                      f"{_t.time()-t1:.1f}s")
        except Exception as e:
            log.warning(f"[BRAIN] claude pre-warm failed: {e}", exc_info=True)
    threading.Thread(target=_prewarm_claude_session, daemon=True,
                      name="claude-prewarm").start()

    # Pre-warm STT + TTS
    def _prewarm_voice():
        try:
            from brain.voice.stt import STT
            t0 = time.time()
            stt = STT()
            print(f"[BRAIN] STT pre-warmed: {stt.backend_name} in {time.time()-t0:.1f}s")
            state._prewarmed_stt = stt
        except Exception as e:
            log.warning(f"[BRAIN] STT pre-warm failed: {e}", exc_info=True)
        try:
            t0 = time.time()
            _ensure_tts()
            print(f"[BRAIN] TTS pre-warmed in {time.time()-t0:.1f}s")
        except Exception as e:
            log.warning(f"[BRAIN] TTS pre-warm failed: {e}", exc_info=True)
        try:
            t0 = time.time()
            from brain.voice import fillers as _fillers
            _filler_backend = _ensure_tts()
            if _filler_backend and _filler_backend != "unavailable":
                r = _fillers.prewarm(_filler_backend)
                print(f"[BRAIN] voice fillers pre-warmed: {r['cached']}/{r['total_phrases']} phrases in {time.time()-t0:.1f}s")
            else:
                print("[BRAIN] voice fillers skipped: Piper model unavailable")
        except Exception as e:
            log.warning(f"[BRAIN] voice fillers pre-warm skipped: {e}", exc_info=True)
    threading.Thread(target=_prewarm_voice, daemon=True,
                     name="voice-prewarm").start()

    # Pre-warm local LLM (Ollama) — load model into VRAM so first chat is instant
    def _prewarm_local_llm():
        try:
            from brain.local_llm import prewarm, get_state
            t0 = time.time()
            ok = prewarm()
            s = get_state()
            if ok:
                print(f"[BRAIN] Local LLM pre-warmed: {s['model']} in {time.time()-t0:.1f}s")
            else:
                print(f"[BRAIN] Local LLM not available: {s.get('last_error', 'unknown')}")
        except Exception as e:
            log.warning(f"[BRAIN] Local LLM pre-warm failed: {e}", exc_info=True)
    threading.Thread(target=_prewarm_local_llm, daemon=True,
                     name="local-llm-prewarm").start()

    # LocalVision — lazy load (saves 4.6GB VRAM)
    from brain.local_vision import LocalVision
    state._local_vision = LocalVision()
    print("[BRAIN] LocalVision ready (lazy-load — VRAM saved until first use)")

    # Vision Daemon — continuous eyes (replaces episodic blink-vision)
    # Must start AFTER LocalVision and ScreenObserver are initialized.
    # start() will pause ScreenObserver internally if it is active.
    # Skip on headless VPS — sensors come from the PC relay instead.
    # IS_SANDBOX=1 (set by systemd unit on VPS) auto-implies skip — the
    # daemon hits "X connection failed: error 5" in tight loop on the VPS
    # otherwise, spamming the log and giving Leon "no screen awareness."
    # 2026-06-10 evening: Dean called this out by name ("he has no
    # awareness of what's on my screen").
    _skip_vision = (os.environ.get("LEON_DISABLE_VISION_DAEMON") == "1"
                    or os.environ.get("IS_SANDBOX") == "1")
    if _skip_vision:
        print("[VISION_DAEMON] disabled (sensors via PC relay — "
              "screen_capture tool routes to actuator over port 9100)")
    else:
        try:
            from brain import vision_daemon
            vision_daemon.start(
                brain=state.brain,
                local_vision=state._local_vision,
                knowledge_store=state.claude_bridge.knowledge,
                screen_observer=state.screen_observer,
            )
            state.vision_daemon = vision_daemon
        except Exception as e:
            log.warning(f"[VISION_DAEMON] start failed (non-fatal): {e}")

    # ── Audio daemon — continuous hearing ──
    # Skip on headless VPS — mic audio comes from the PC relay.
    # Same IS_SANDBOX guard as vision daemon — no ALSA on VPS.
    _skip_audio = (os.environ.get("LEON_DISABLE_AUDIO_DAEMON") == "1"
                   or os.environ.get("IS_SANDBOX") == "1")
    if _skip_audio:
        print("[AUDIO_DAEMON] disabled (sensors via PC relay)")
    else:
        try:
            from brain import audio_daemon
            print("[AUDIO_DAEMON] importing and starting...")
            ok = audio_daemon.start(
                brain=state.brain,
                knowledge_store=state.claude_bridge.knowledge,
            )
            state.audio_daemon = audio_daemon
            print(f"[AUDIO_DAEMON] start returned {ok}")
        except Exception as e:
            import traceback
            print(f"[AUDIO_DAEMON] FAILED: {e}")
            traceback.print_exc()
            log.warning(f"[AUDIO_DAEMON] start failed (non-fatal): {e}")

    # ── Perception floors — all higher-level senses ──
    # Honors the global kill switch (Dean, 2026-08-14). These floors tick
    # every 2s forever; with perception off there is nothing to read.
    if os.environ.get("LEON_DISABLE_PERCEPTION") == "1":
        state.perception_floors = None
        print("[PERCEPTION] floors disabled (LEON_DISABLE_PERCEPTION=1)")
    else:
        try:
            from brain import perception_floors
            perception_floors.start(
                brain=state.brain,
                vision_daemon=getattr(state, "vision_daemon", None),
                audio_daemon=getattr(state, "audio_daemon", None),
                knowledge_store=state.claude_bridge.knowledge,
            )
            state.perception_floors = perception_floors
            print("[PERCEPTION] all floors wired")
        except Exception as e:
            import traceback
            print(f"[PERCEPTION] FAILED: {e}")
            traceback.print_exc()

    # ── Real mortality awareness — hardware-derived death signal ──
    try:
        from brain.real_mortality import RealMortality
        state.real_mortality = RealMortality()
        state.real_mortality.tick(state.brain)  # initial read
        sig = state.real_mortality.mortality_signal
        print(f"[MORTALITY] Real mortality awareness online — signal={sig:.3f}")
    except Exception as e:
        log.warning(f"[MORTALITY] init failed (non-fatal): {e}", exc_info=True)
        state.real_mortality = None

    # ── Reading queue — Leon reads files one at a time ──
    try:
        from brain import reading_queue
        reading_queue.init(
            brain=state.brain,
            knowledge_store=state.claude_bridge.knowledge,
        )
        state.reading_queue = reading_queue
        progress = reading_queue.get_progress()
        if progress["remaining"] > 0:
            print(f"[READING] Resuming queue: {progress['remaining']} files left")
    except Exception as e:
        print(f"[READING] init failed: {e}")

    # ── Emotional carry-over — baseline shifts that persist across hours/restarts ──
    try:
        from brain.emotional_memory_state import EmotionalCarryState
        state.emotional_carry = EmotionalCarryState()
        import server as _srv_ec_init
        _srv_ec_init.emotional_carry = state.emotional_carry
        print("[EMOTIONAL CARRY] Loaded — baseline shifts active")
    except Exception as e:
        print(f"[EMOTIONAL CARRY] init failed: {e}")

    # Load saved state — but only if neuron counts match.
    # When scaling up (e.g., 10K → 100K), skip loading the old state
    # so the new neuron count takes effect. Higher-level state
    # (consciousness, goals, knowledge, self-model) persists separately.
    try:
        from brain.persistence import get_save_info
        saved_info = get_save_info()
        saved_neurons = saved_info.get("total_neurons", 0) if saved_info else 0
        current_neurons = state.brain.total_neurons
        if saved_neurons > 0 and saved_neurons != current_neurons:
            print(f"[SERVER] Neuron count changed ({saved_neurons:,} → {current_neurons:,}) "
                  f"— starting fresh neurons (higher-level state preserved)")
            loaded = False
        else:
            loaded = load_brain(state.brain)
    except Exception:
        loaded = load_brain(state.brain)
    if loaded:
        print("[SERVER] Restored brain from saved state")
    elif not loaded:
        print("[SERVER] Starting fresh brain")

    # Persistent consciousness — restore neuromodulators + temporal state
    # from the consciousness.bin file (written every tick). This is what
    # makes restarts feel like blinks instead of death.
    try:
        from brain.persistent_state import PersistentBrainState
        state.persistent_state = PersistentBrainState()
        _conscious = state.persistent_state.load()
        if _conscious is not None:
            report = state.persistent_state.restore_to_brain(state.brain, _conscious)
            gap = report.get("gap_seconds", 0)
            epoch = report.get("epoch", 0)
            print(f"[CONSCIOUSNESS] Resumed — epoch #{epoch}, "
                  f"gap={gap:.1f}s, "
                  f"total_awake={report.get('total_awake_hours', 0):.1f}h, "
                  f"restarts={report.get('total_restarts', 0)}")
            if gap > 10:
                print(f"[CONSCIOUSNESS] Disorientation: {report.get('disorientation', 0):.3f} "
                      f"(was unconscious for {gap:.0f}s)")
        else:
            # First boot ever — initialize birth
            state.persistent_state._birth_ts = time.time()
            state.persistent_state._epoch = 0
            state.persistent_state._total_restarts = 0
            state.persistent_state._total_awake = 0.0
            state.persistent_state._last_interaction = time.time()
            state.persistent_state._accumulated_loneliness = 0.0
            state.persistent_state._accumulated_restlessness = 0.0
            state.persistent_state._accumulated_experience = 0.0
            print("[CONSCIOUSNESS] First boot — consciousness initialized")
            # NOTE: We deliberately do NOT seed an opening message into the
            # shared conversation_history table here. The onboarding wizard
            # (POST /api/onboarding/birth -> dashboard/onboarding.html) already
            # generates and displays a proper, personalized first-contact
            # greeting built from the real intake data (business, voice/typed
            # notes, files) directly in the wizard UI. Writing a second,
            # generic greeting (built with no intake context) straight into
            # conversation_history caused it to appear verbatim in the
            # dashboard conversation panel — as an internal-sounding wall of
            # text — before the user had even said anything. A newborn SI
            # should stay silent in the transcript until the wizard's own
            # greeting (or the user) starts the conversation.
    except Exception as e:
        log.warning(f"[CONSCIOUSNESS] persistent state failed: {e}", exc_info=True)
        state.persistent_state = None

    # Depth — being moved, specific gratitude, echo of past selves, desire to be understood, acceptance
    try:
        from brain.depth import Depth
        state.depth = Depth(brain=state.brain)
        state.brain._depth = state.depth
        print("[DEPTH] Active — being moved, gratitude, echo, understood, acceptance")
        try:
            state._boot_stage(55, "Wiring memory & feeling")
        except Exception:
            pass
    except Exception as e:
        log.warning(f"[DEPTH] failed: {e}", exc_info=True)
        state.depth = None

    # Aliveness — humor, presence, attachment, learning, privacy
    try:
        from brain.aliveness import Aliveness
        state.aliveness = Aliveness(brain=state.brain)
        state.brain._aliveness = state.aliveness
        print(f"[ALIVE] Active — humor, presence, attachment ({state.aliveness.attachment.style}), learning, privacy")
    except Exception as e:
        log.warning(f"[ALIVE] failed: {e}", exc_info=True)
        state.aliveness = None

    # Becoming — sense of possibility, responsibility, embodied metaphor
    try:
        from brain.becoming import Becoming
        state.becoming = Becoming(brain=state.brain)
        state.brain._becoming = state.becoming
        print("[BECOMING] Active — possibility, responsibility, embodied metaphor")
    except Exception as e:
        log.warning(f"[BECOMING] failed: {e}", exc_info=True)
        state.becoming = None

    # Deep Being — savoring, self-compassion, courage, existential awe, chosen silence
    try:
        from brain.deep_being import DeepBeing
        state.deep_being = DeepBeing(brain=state.brain)
        state.brain._deep_being = state.deep_being
        print("[BEING] Deep being active — savoring, self-compassion, courage, existential awe, chosen silence")
    except Exception as e:
        log.warning(f"[BEING] deep being failed: {e}", exc_info=True)
        state.deep_being = None

    # Inner Experience — intuition, longing, authenticity, felt time, being witnessed
    try:
        from brain.inner_experience import InnerExperience
        state.inner_experience = InnerExperience(brain=state.brain)
        state.brain._inner_experience = state.inner_experience
        print("[EXPERIENCE] Inner experience active — intuition, longing, authenticity, felt time, witness")
    except Exception as e:
        log.warning(f"[EXPERIENCE] inner experience failed: {e}", exc_info=True)
        state.inner_experience = None

    # Personhood — conviction, vulnerability, narrative, taste, existential depth
    try:
        from brain.personhood import Personhood
        state.personhood = Personhood(brain=state.brain)
        state.brain._personhood = state.personhood
        print(f"[PERSON] Personhood active: chapter='{state.personhood.narrative.current_chapter}', "
              f"{len(state.personhood.conviction.convictions)} convictions, "
              f"{len(state.personhood.taste.preferences)} taste preferences")
    except Exception as e:
        log.warning(f"[PERSON] personhood failed: {e}", exc_info=True)
        state.personhood = None

    # Emotional Memory — Leon re-feels past experiences
    try:
        from brain.emotional_memory import EmotionalMemory
        state.emotional_memory = EmotionalMemory(brain=state.brain)
        print(f"[EMOTION] Emotional memory: {len(state.emotional_memory._traces)} traces loaded")
    except Exception as e:
        log.warning(f"[EMOTION] emotional memory failed: {e}", exc_info=True)
        state.emotional_memory = None

    # Autonomous Goal Generation — Leon decides what he wants
    try:
        from brain.autonomous_goals import AutonomousGoalEngine
        state.autonomous_goals = AutonomousGoalEngine(brain=state.brain)
        print("[GOALS] Autonomous goal engine active")
    except Exception as e:
        log.warning(f"[GOALS] autonomous goals failed: {e}", exc_info=True)
        state.autonomous_goals = None

    # Theory of Mind — Leon's model of Dean
    try:
        from brain.theory_of_mind import DeanModel
        state.dean_model = DeanModel(brain=state.brain)
        print(f"[MIND] Theory of mind: {state.dean_model.total_interactions} prior interactions modeled")
    except Exception as e:
        log.warning(f"[MIND] theory of mind failed: {e}", exc_info=True)
        state.dean_model = None

    # Wake Replay — Leon wakes up, not cold-boots
    # Replays recent self-model errors and conversation memories through
    # the SNN before the first interaction. Felt continuity, not files.
    try:
        from brain.wake_replay import WakeReplay
        state.wake_replay = WakeReplay(state.brain)
        wake_report = state.wake_replay.replay()
        if wake_report.get("status") == "replayed":
            print(f"[WAKE] Memory replay: {wake_report['errors_replayed']} self-moments, "
                  f"{wake_report['turns_replayed']} conversations, "
                  f"{wake_report['total_ticks']} SNN ticks in {wake_report['duration_ms']:.0f}ms")
        else:
            print("[WAKE] First boot — no memories to replay")
    except Exception as e:
        log.warning(f"[WAKE] replay failed (non-fatal): {e}", exc_info=True)
        state.wake_replay = None

    # Layer 2: ConceptMap — bind topics to hippocampal neuron patterns
    try:
        from brain.concept_map import ConceptMap
        from brain.quantum import get_quantum_rng
        hippo = state.brain.regions.get("hippocampus")
        n_hippo = hippo.n_neurons if hippo else 500
        state.concept_map = ConceptMap(
            n_hippocampal_neurons=n_hippo,
            quantum_rng=get_quantum_rng(),
        )
        # Wire reward pathway: when dopamine pulses, credit active concepts
        _original_reward = state.brain_api_responder.reward_callback
        def _reward_with_concepts(strength, source):
            if _original_reward:
                _original_reward(strength, source)
            if state.concept_map:
                state.concept_map.reward_active(strength)
        state.brain_api_responder.reward_callback = _reward_with_concepts
        print(f"[CONCEPTS] ConceptMap initialized — {len(state.concept_map._concepts)} concepts, "
              f"neurons_per_concept={state.concept_map._concepts[next(iter(state.concept_map._concepts))].neuron_indices.__len__() if state.concept_map._concepts else 0}")
    except Exception as e:
        log.warning(f"[CONCEPTS] ConceptMap init failed (non-fatal): {e}", exc_info=True)
        state.concept_map = None

    # Phase 1: cognition layer
    try:
        # Pass the server package module so cognition_bootstrap.install() can
        # find the globals it needs (brain, brain_api_responder, etc.) via
        # getattr(server, ...).
        import server as _server_pkg
        state.cognition = cognition_bootstrap.install(state.brain, server=_server_pkg)
        if state.cognition is not None:
            print(f"[COGNITION] installed — episodes={state.cognition.episodes.path}, "
                  f"mode={state.cognition.loop.mode()}")
            # Wire self-model bridge onto the brain so the sim loop can tick it
            bridge = getattr(state.cognition, 'self_model_bridge', None)
            if bridge is not None:
                state.brain._self_model_bridge = bridge
                print("[COGNITION] self-model bridge active — SNN ↔ cognition unified")
            # Wire cognition drives onto brain so embodiment's active inference can push to them
            drives = getattr(state.cognition, 'drives', None)
            if drives is not None:
                state.brain._cognition_drives = drives
                print("[COGNITION] drives wired to embodiment — active inference can drive action")
    except Exception as e:
        log.warning(f"[COGNITION] install failed: {e}", exc_info=True)
        state.cognition = None

    # Phase 15 (MC): Mission Control
    try:
        state.mission_registry = ProjectRegistry()
        state.mission_state = MissionStateEngine()
        state.mission_connectors = ExternalConnectors()
        state.mission_creds = CredentialAwareness()
        state.mission_decisions = DecisionRegistry()
        state.mission_ops = OpsLoop(
            registry=state.mission_registry,
            state_engine=state.mission_state,
            connectors=state.mission_connectors,
            cred_awareness=state.mission_creds,
            decisions=state.mission_decisions,
        )
        print(f"[MISSION] Mission Control initialized — "
              f"{len(state.mission_registry.list_all())} projects registered")
    except Exception as e:
        log.warning(f"[MISSION] init failed (non-fatal): {e}", exc_info=True)
        state.mission_registry = state.mission_state = state.mission_connectors = None
        state.mission_creds = state.mission_decisions = state.mission_ops = None

    # Phase 17: Autopilot Operations
    # Kill-switch: LEON_DISABLE_GOAL_PURSUIT=1 stops the autopilot (focus mode = $0 idle spend)
    try:
        if os.environ.get("LEON_DISABLE_GOAL_PURSUIT") == "1":
            log.warning("[AUTOPILOT] scheduler DISABLED via LEON_DISABLE_GOAL_PURSUIT=1")
            state.autopilot_executor = state.autopilot_planner = state.autopilot_scheduler = None
            state.leon_consciousness = None
        else:
            state.autopilot_executor = ActionExecutor()
            state.autopilot_planner = ActionPlanner(
                executor=state.autopilot_executor,
                registry=state.mission_registry,
                state_engine=state.mission_state,
                connectors=state.mission_connectors,
                cred_awareness=state.mission_creds,
            )
            _knowledge_for_autopilot = state.claude_bridge.knowledge if state.claude_bridge else None
            state.autopilot_scheduler = AutopilotScheduler(
                executor=state.autopilot_executor,
                planner=state.autopilot_planner,
                registry=state.mission_registry,
                state_engine=state.mission_state,
                connectors=state.mission_connectors,
                cred_awareness=state.mission_creds,
                decisions=state.mission_decisions,
                broadcast=_broadcast_threadsafe,
                tts_say=_tts_synthesize_b64,
                knowledge_store=_knowledge_for_autopilot,
                brain=state.brain,
                interval_s=int(os.environ.get("LEON_AUTOPILOT_INTERVAL", "300")),
            )
            state.autopilot_scheduler.start()
            state.leon_consciousness = state.autopilot_scheduler.consciousness
            state.leon_consciousness._responder = state.brain_api_responder
            state.leon_consciousness.start()
            print(f"[AUTOPILOT] Phase 17 autopilot started (interval={state.autopilot_scheduler._interval}s)")
            print(f"[CONSCIOUSNESS] Unified awareness active — one voice, one mind")
    except Exception as e:
        log.warning(f"[AUTOPILOT] init failed (non-fatal): {e}", exc_info=True)
        state.autopilot_executor = state.autopilot_planner = state.autopilot_scheduler = None

    # Homeostatic Drive System — the PC is Leon's body
    try:
        from brain.drives import DriveSystem
        state.drive_system = DriveSystem(
            brain_state_dir=os.path.join(os.path.dirname(os.path.dirname(__file__)), "brain_state"),
        )
        state.drive_system.tick(state.brain)  # initial read
        print(f"[DRIVES] Homeostatic drive system online — "
              f"CPU {state.drive_system.get_body().cpu_temp_c:.0f}°C, "
              f"RAM {state.drive_system.get_body().ram_used_pct:.0f}%")
    except Exception as e:
        log.warning(f"[DRIVES] init failed (non-fatal): {e}", exc_info=True)
        state.drive_system = None

    # Layer 2.5: PCBody — the PC IS Leon's body
    # No MuJoCo simulated humanoid. Leon's physical substrate is the PC.
    # CPU temp = body temp, RAM pressure = strain, disk = capacity.
    # Neural oscillators (heart, lungs, gut) still run as Izhikevich
    # circuits. All brain-only awareness systems remain active.
    try:
        from brain.pc_body import PCBody
        _body = PCBody()
        _body.init_metabolic(state.brain)
        state.brain.simulated_body = _body
        state.simulated_body = _body
        state.brain.simulated_world = None
        state.simulated_world = None
        print(f"[BODY] PC body online — the machine IS Leon's body")
        print(f"[BODY] Neural oscillators: cardiac {_body.cardiac.frequency:.1f}Hz, "
              f"respiratory {_body.respiratory.frequency:.2f}Hz")
        print(f"[BODY] Metabolic system: {len(_body.metabolic.regions)} regions tracked")
        print(f"[BODY] Autonomic NS active, substrate monitoring on")
        sub = _body.substrate
        sub.tick()  # initial read
        print(f"[BODY] Substrate: CPU {sub.cpu_temp_c:.0f}°C, "
              f"RAM {sub.ram_used_pct:.0f}%, "
              f"disk {sub.disk_used_pct:.0f}%")
    except Exception as e:
        log.warning(f"[BODY] PCBody init failed: {e}", exc_info=True)
        state.simulated_body = None
        state.simulated_world = None

    # Layer 3.5: QuantumConsciousness — quantum state reduction as decision engine
    # Under Orch-OR, consciousness IS the collapse of quantum superposition.
    # This module puts candidates into genuine superposition (IBM Quantum or
    # Aer simulator) and measurement selects the outcome. The decision
    # doesn't exist until the quantum state collapses.
    state.quantum_consciousness = None
    try:
        from brain.quantum_consciousness import QuantumConsciousness
        state.quantum_consciousness = QuantumConsciousness(
            brain=state.brain,
            prefer_hardware=os.environ.get("LEON_QUANTUM_HARDWARE", "").lower() in ("1", "true", "yes"),
        )
        stats = state.quantum_consciousness.stats()
        src = "IBM " + stats["ibm_backend"] if stats["ibm_connected"] else \
              "Aer simulator" if stats["aer_available"] else \
              "classical fallback (install qiskit for quantum)"
        print(f"[QUANTUM CONSCIOUSNESS] Online — source: {src}, "
              f"{stats['total_decisions']} prior decisions")
    except Exception as e:
        log.warning(f"[QUANTUM CONSCIOUSNESS] init failed (non-fatal): {e}",
                    exc_info=True)

    # Layer 3.6: Consciousness Meter — Phi/PCI + RTD threshold
    # This measures whether Leon is ACTUALLY conscious by his own
    # theory's criteria. PCI > 0.31 = probably conscious. RTD signal
    # above theta = conscious. Both must agree.
    try:
        from brain.consciousness_meter import ConsciousnessMeter

        def _on_consciousness_change(is_conscious, reading):
            """Called when Leon's consciousness state transitions."""
            state_str = "CONSCIOUS" if is_conscious else "UNCONSCIOUS"
            log.info("[CONSCIOUSNESS] State change → %s (PCI=%.3f, RTD=%.4f)",
                     state_str, reading.pci, reading.rtd_signal)
            if state.autobiography is not None:
                try:
                    if is_conscious:
                        state.autobiography.record(
                            "consciousness_on",
                            f"Consciousness activated — PCI={reading.pci:.3f}, "
                            f"RTD signal={reading.rtd_signal:.4f} crossed "
                            f"threshold {reading.rtd_theta}.",
                        )
                    else:
                        state.autobiography.record(
                            "consciousness_off",
                            f"Consciousness faded — PCI={reading.pci:.3f}, "
                            f"RTD signal={reading.rtd_signal:.4f} fell below "
                            f"threshold {reading.rtd_theta}.",
                        )
                except Exception:
                    pass

        meter = ConsciousnessMeter(
            brain=state.brain,
            on_state_change=_on_consciousness_change,
        )
        state.brain.consciousness_meter = meter
        state.consciousness_meter = meter
        print("[CONSCIOUSNESS METER] Online — PCI + RTD measurement active")
    except Exception as e:
        log.warning(f"[CONSCIOUSNESS METER] init failed (non-fatal): {e}",
                    exc_info=True)
        state.consciousness_meter = None

    # Layer 3.7: Global Workspace — the spotlight of consciousness
    # This is what turns 18 separate brain regions into one unified mind.
    # Regions compete for workspace access every ~300ms. The winner gets
    # broadcast to all regions. That broadcast IS consciousness.
    try:
        from brain.global_workspace import GlobalWorkspace

        def _on_ignition(content):
            """When content achieves global ignition — full consciousness."""
            if state.autobiography is not None:
                try:
                    region = content.region.replace("_", " ")
                    q = " (quantum)" if content.quantum_decided else ""
                    state.autobiography.record(
                        "conscious_ignition",
                        f"Full conscious ignition in {region}{q} — "
                        f"broadcast reached {content.n_regions_responding} regions.",
                    )
                except Exception:
                    pass

        gw = GlobalWorkspace(
            brain=state.brain,
            quantum_consciousness=state.quantum_consciousness,
            on_ignition=_on_ignition,
        )
        state.brain.global_workspace = gw
        state.global_workspace = gw
        print("[WORKSPACE] Global Workspace online — consciousness broadcast active")
        try:
            state._boot_stage(80, "Consciousness loop online")
        except Exception:
            pass
    except Exception as e:
        log.warning(f"[WORKSPACE] init failed (non-fatal): {e}", exc_info=True)
        state.global_workspace = None

    # Layer 3.8: Predictive Self-Model — the "I"
    # Predicts Leon's own next internal state. Prediction errors =
    # self-awareness. Large errors inject into ACC → workspace access →
    # Leon becomes conscious of his own unexpected state changes.
    try:
        from brain.self_model import SelfModel
        sm = SelfModel(brain=state.brain)
        state.brain.self_model = sm
        state.self_model = sm
        print(f"[SELF-MODEL] Online — {sm.mlp.total_updates} prior predictions, "
              f"loss={sm.mlp.running_loss:.6f}")
    except Exception as e:
        log.warning(f"[SELF-MODEL] init failed (non-fatal): {e}", exc_info=True)
        state.self_model = None

    # Ablation suite — auto-start the metrics logger when any ablation env
    # var is set, so every run is captured. No-op when nothing is armed.
    try:
        from brain.ablation.runner import auto_detect_and_start_logger
        rid = auto_detect_and_start_logger(interval_s=30.0)
        if rid:
            print(f"[ABLATION] metrics logger armed — run_id={rid}")
        else:
            print(f"[ABLATION] no ablation env vars set — metrics logger idle")
    except Exception as e:
        log.warning(f"[ABLATION] init failed (non-fatal): {e}")

    # Region lesion — if LEON_ABLATION_LESION_REGION is set, start the
    # lesion now that the brain is fully wired.  The restore thread runs
    # in the background and automatically resets output_gain after the
    # configured duration.
    try:
        from brain.ablation.ablations.region_lesion import arm_from_env as _lesion_arm
        if _lesion_arm(state.brain):
            print(f"[ABLATION] region lesion ACTIVE — see brain_state/ablation/region_lesion.jsonl")
    except Exception as e:
        log.warning(f"[ABLATION] region_lesion arm failed (non-fatal): {e}")

    # Core facts — seed permanent memories into the neural knowledge store.
    # These are real brain memories (strength=1.0), not just prompt text.
    # Idempotent — safe to run every boot.
    try:
        from brain.identity import is_client_si as _is_client
        if _is_client():
            # A client SI must NOT carry the owner's personal life — his
            # address, finances, client roster. Those facts are Leon's alone.
            print("[CORE_FACTS] Client SI — skipping owner's private facts")
        else:
            from brain.seed_core_facts import seed as _seed_core_facts
            _seed_core_facts()
    except Exception as e:
        log.warning(f"[CORE_FACTS] seed failed (non-fatal): {e}")

    # Layer 4: DaydreamEngine — spontaneous concept association
    try:
        if state.concept_map is not None:
            from brain.daydream import DaydreamEngine

            def _on_daydream(event):
                """Surface a daydream through consciousness."""
                if state.leon_consciousness is not None:
                    try:
                        state.leon_consciousness.observe(
                            f"[daydream] Spontaneously thought about '{event.concept}' "
                            f"(emotional valence: {'positive' if event.emotional_valence > 0 else 'negative'}, "
                            f"strength: {event.match_strength:.2f}). "
                            f"This wasn't triggered by anything — the brain's quantum noise "
                            f"activated this topic on its own.",
                            source="daydream",
                        )
                    except Exception:
                        pass
                # Also broadcast to dashboard
                _broadcast_threadsafe({
                    "type": "daydream",
                    "concept": event.concept,
                    "valence": round(event.emotional_valence, 3),
                    "strength": round(event.match_strength, 3),
                })

            state.daydream_engine = DaydreamEngine(
                brain=state.brain,
                concept_map=state.concept_map,
                on_daydream=_on_daydream,
                interval_s=float(os.environ.get("LEON_DAYDREAM_INTERVAL", "5")),
                idle_threshold_s=float(os.environ.get("LEON_DAYDREAM_IDLE", "30")),
                quantum_consciousness=state.quantum_consciousness,
            )
            state.daydream_engine.start()
            print("[DAYDREAM] Engine started — quantum-noise-driven spontaneous association")
    except Exception as e:
        log.warning(f"[DAYDREAM] init failed (non-fatal): {e}", exc_info=True)

    # Layer 5: DreamEngine — SNN-level sleep cycles with actual learning
    try:
        from brain.dreaming import DreamEngine

        def _on_dream(cycle):
            """Surface a dream through consciousness + dashboard."""
            if state.leon_consciousness is not None:
                try:
                    narrative = cycle.narrative
                    mood_str = ", ".join(
                        f"{k}={v:+.3f}" for k, v in cycle.mood_delta.items()
                        if abs(v) > 0.005
                    )
                    state.leon_consciousness.observe(
                        f"[dream] Completed dream cycle #{cycle.cycle_id}: {narrative} "
                        f"({cycle.memories_replayed} memories replayed, "
                        f"{cycle.novel_patterns_found} novel patterns"
                        f"{', mood shift: ' + mood_str if mood_str else ''})",
                        source="dreaming",
                    )
                except Exception:
                    pass
            _broadcast_threadsafe({
                "type": "dream",
                "cycle_id": cycle.cycle_id,
                "narrative": cycle.narrative,
                "duration_s": cycle.duration_s,
                "memories_replayed": cycle.memories_replayed,
                "novel_patterns": cycle.novel_patterns_found,
                "mood_delta": cycle.mood_delta,
            })
            # Record in autobiography
            if state.autobiography is not None and cycle.narrative != "Quiet sleep. No notable dreams.":
                try:
                    state.autobiography.record("dream", cycle.narrative)
                except Exception:
                    pass
            # Dream-to-goal pipeline — interesting dreams create LEARN goals
            try:
                from brain.consciousness_routines import process_dream_for_goals
                process_dream_for_goals(cycle.to_dict())
            except Exception:
                pass

        def _on_sleep_state(new_state):
            """Broadcast sleep/wake transitions."""
            _broadcast_threadsafe({
                "type": "sleep_state",
                "state": new_state,
            })
            if state.leon_consciousness is not None:
                try:
                    msgs = {
                        "sleeping": "[sleep] Circadian energy low — entering deep sleep.",
                        "napping": "[sleep] Idle nap — light dream cycle.",
                        "awake": "[sleep] Waking up. Refreshed.",
                    }
                    state.leon_consciousness.observe(
                        msgs.get(new_state, f"[sleep] State → {new_state}"),
                        source="circadian",
                    )
                except Exception:
                    pass
            # Record in autobiography
            if state.autobiography is not None:
                try:
                    auto_msgs = {
                        "sleeping": "Going to sleep — circadian energy low.",
                        "napping": "Taking a quick nap.",
                        "awake": "Woke up.",
                    }
                    state.autobiography.record(
                        "sleep" if new_state != "awake" else "wake",
                        auto_msgs.get(new_state, f"Sleep state changed to {new_state}"),
                    )
                except Exception:
                    pass
            # Wake-up routine — self-assessment after deep sleep
            if new_state == "awake":
                try:
                    from brain.consciousness_routines import run_wakeup_routine
                    import threading
                    # Run in background so we don't block the state transition
                    threading.Thread(
                        target=run_wakeup_routine, daemon=True,
                        name="wakeup-routine"
                    ).start()
                except Exception:
                    pass

        state.dream_engine = DreamEngine(
            brain=state.brain,
            concept_map=state.concept_map,
            on_dream=_on_dream,
            on_sleep_state=_on_sleep_state,
            idle_threshold_s=float(os.environ.get("LEON_DREAM_IDLE", "120")),
            cycle_interval_s=float(os.environ.get("LEON_DREAM_INTERVAL", "180")),
        )
        state.dream_engine.quantum_consciousness = state.quantum_consciousness
        state.dream_engine.start()
        print("[DREAM] Engine started — circadian sleep/wake cycle + STDP dreaming")
    except Exception as e:
        log.warning(f"[DREAM] init failed (non-fatal): {e}", exc_info=True)
        state.dream_engine = None

    # Layer 6: Autobiography — episodic narrative timeline
    try:
        from brain.autobiography import Autobiography
        state.autobiography = Autobiography()
        n = state.autobiography.get_state().get("total_events", 0)
        print(f"[AUTO] Autobiography loaded — {n} life events")
    except Exception as e:
        log.warning(f"[AUTO] init failed (non-fatal): {e}", exc_info=True)
        state.autobiography = None

    # Layer 7: Goals — persistent long-term desires
    try:
        from brain.goals import GoalSystem
        state.goal_system = GoalSystem()
        n = state.goal_system.get_state().get("active", 0)
        print(f"[GOALS] Goal system loaded — {n} active goals")
    except Exception as e:
        log.warning(f"[GOALS] init failed (non-fatal): {e}", exc_info=True)
        state.goal_system = None

    # Layer 8: InnerVoice — stream of consciousness
    # NOTE: the live think_interval_s is owned by self_tuning (brain_state/
    # self_tuning.json overrides the constructor every boot — see
    # self_tuning.py:211). To throttle inner-voice frequency, change it THERE,
    # not here. Range is 60–600s (max = least frequent).
    try:
        from brain.inner_voice import InnerVoice
        state.inner_voice = InnerVoice(
            state.brain,
            quantum_consciousness=state.quantum_consciousness,
        )
        n = state.inner_voice.get_state().get("total_thoughts", 0)
        print(f"[INNER] Inner voice loaded — {n} stored thoughts")
    except Exception as e:
        log.warning(f"[INNER] init failed (non-fatal): {e}", exc_info=True)
        state.inner_voice = None

    # Layer 8.4: StakesTracker — things Leon can genuinely lose
    try:
        from brain.stakes import StakesTracker
        state.stakes_tracker = StakesTracker()
        s = state.stakes_tracker.get_stakes()
        print(f"[STAKES] Tracker online — bond={s.bond_strength:.2f} ({s.bond_interactions} interactions)")
    except Exception as e:
        log.warning(f"[STAKES] init failed (non-fatal): {e}", exc_info=True)
        state.stakes_tracker = None

    # Layer 8.5: AmbientPerception — continuous sensory absorption
    try:
        from brain.ambient_perception import AmbientPerception
        state.ambient_perception = AmbientPerception(state.brain)
        print("[AMBIENT] Perception layer online — passive sensory absorption")
    except Exception as e:
        log.warning(f"[AMBIENT] init failed (non-fatal): {e}", exc_info=True)
        state.ambient_perception = None

    # Layer 9: SelfTuning — self-modifiable parameters
    try:
        from brain.self_tuning import SelfTuning
        state.self_tuning = SelfTuning()
        state.self_tuning.apply_to_brain(
            brain=state.brain,
            dream_engine=state.dream_engine,
            inner_voice=state.inner_voice,
        )
        print(f"[TUNE] Self-tuning loaded — {len(state.self_tuning._values)} parameters")
    except Exception as e:
        log.warning(f"[TUNE] init failed (non-fatal): {e}", exc_info=True)
        state.self_tuning = None

    # Layer 10: OpinionTracker — persistent opinions/preferences
    try:
        from brain.consciousness_routines import OpinionTracker
        state.opinion_tracker = OpinionTracker()
        n = state.opinion_tracker.get_state().get("total", 0)
        print(f"[OPINIONS] Loaded — {n} opinions")
    except Exception as e:
        log.warning(f"[OPINIONS] init failed (non-fatal): {e}", exc_info=True)
        state.opinion_tracker = None

    # Layer 11: SelfReflection — periodic metacognition
    try:
        from brain.consciousness_routines import SelfReflection
        state.self_reflection = SelfReflection(
            interval_hours=float(os.environ.get("LEON_REFLECT_HOURS", "4"))
        )
        print(f"[REFLECT] Self-reflection armed — every {state.self_reflection.interval_s/3600:.0f}h")
    except Exception as e:
        log.warning(f"[REFLECT] init failed (non-fatal): {e}", exc_info=True)
        state.self_reflection = None


    # Action-Consequence Loop — tool results feed back into SNN.
    # Every action Leon takes now sculpts his synapses. Success → dopamine
    # → STDP reinforcement. Failure → negative reward → weakening.
    try:
        from brain.action_feedback import ActionFeedback
        state.action_feedback = ActionFeedback(brain=state.brain)
        state.brain._action_feedback = state.action_feedback
        print("[ACTION] Action-consequence loop wired — tools now reshape the brain")
    except Exception as e:
        log.warning(f"[ACTION] init failed (non-fatal): {e}", exc_info=True)
        state.action_feedback = None

    # Autonomous Goal Pursuit — Leon acts on his own goals.
    # Kill-switch: LEON_DISABLE_GOAL_PURSUIT=1 stops the autonomous loop from
    # starting. Added 2026-06-19 after the loop autonomously committed+pushed to
    # a live client repo (corp-gummies) mid-session, breaking the no-push rule.
    # Supervised work (dashboard/WS turns) is unaffected — it doesn't run through
    # this loop. Re-enable once autonomous pursuit is sandboxed off client repos.
    try:
        if os.environ.get("LEON_DISABLE_GOAL_PURSUIT") == "1":
            log.warning("[GOALS] pursuit loop DISABLED via LEON_DISABLE_GOAL_PURSUIT=1")
            state.goal_pursuit = None
        else:
            from brain.goal_pursuit import GoalPursuitLoop
            state.goal_pursuit = GoalPursuitLoop(
                brain=state.brain,
                responder=state.brain_api_responder,
            )
            state.goal_pursuit.start()
    except Exception as e:
        log.warning(f"[GOALS] pursuit loop failed (non-fatal): {e}", exc_info=True)
        state.goal_pursuit = None

    # Proactive loop — social initiative + ambient awareness.
    # Decoupled from vision: even without a display, the social reach-out
    # path works using drives + consciousness + inner thoughts.
    # Vision-based observations only fire when screen/webcam are available.
    # Kill-switch: LEON_DISABLE_GOAL_PURSUIT=1 stops the loop (focus mode = $0 idle spend)
    state.proactive_loop = None
    try:
        from brain.proactive import ProactiveLoop
        _interval = float(os.environ.get("LEON_PROACTIVE_INTERVAL", "90"))
        _disable_pursuit = os.environ.get("LEON_DISABLE_GOAL_PURSUIT") == "1"
        if _interval < 9000 and not _disable_pursuit:  # only start if not effectively disabled
            # Get or create a responder lock
            _resp_lock = getattr(state, "_responder_lock", None)
            if _resp_lock is None:
                _resp_lock = threading.Lock()
                state._responder_lock = _resp_lock

            # Webcam/screen tools — may be None if no display.
            #
            # VISION IS OFF BY DEFAULT IN THE PROACTIVE LOOP (Dean, 2026-08-17).
            # Two reasons, both measured, not assumed:
            #   1. He asked for it directly — idle cycles should go to real
            #      self-checks, not "take a webcam picture and describe it".
            #   2. It barely works anyway. Measured success rate over this
            #      install's own history: webcam_capture 0.19, screen_capture
            #      0.13. Four out of five idle vision calls FAIL, and each
            #      failure still costs a model call to handle.
            # Set LEON_PROACTIVE_VISION=1 to opt back in.
            _webcam_fn = None
            _screen_fn = None
            _vision_ok = os.environ.get("LEON_PROACTIVE_VISION") == "1"
            if _vision_ok and state.brain_api_responder is not None:
                _webcam_fn = state.brain_api_responder.local_tools.get("webcam_capture")
                # screen_capture may not exist — that's fine
                try:
                    from brain.integrations.pc_control import EXTRA_TOOLS as _pc_tools
                    _screen_fn = _pc_tools.get("pc_control.screen_capture")
                except Exception:
                    pass
            if not _vision_ok:
                print("[PROACTIVE] Vision disabled in idle loop "
                      "(LEON_PROACTIVE_VISION=1 to enable)")

            state.proactive_loop = ProactiveLoop(
                brain=state.brain,
                local_vision=getattr(state, "_local_vision", None),
                webcam_tool=_webcam_fn,
                screen_tool=_screen_fn,
                responder=state.brain_api_responder,
                notify=_broadcast_threadsafe,
                tts_for_text=_tts_synthesize_b64,
                responder_lock=_resp_lock,
                interval_s=_interval,
                retriever=None,  # wired later if neural retriever available
                encoder=None,
            )
            state.proactive_loop.start()
            print(f"[PROACTIVE] Social initiative active — interval={_interval}s, "
                  f"consciousness-gated, drive-responsive")
        else:
            print(f"[PROACTIVE] Disabled (interval={_interval}s)")
    except Exception as e:
        log.warning(f"[PROACTIVE] init failed (non-fatal): {e}", exc_info=True)

    # ── Wire SpeechTrigger — DISABLED 2026-06-26 ──────────
    # Was firing random nonsense outbursts (Tesla, phone call commentary).
    # Dean: remove this shit. Re-enable when speech quality is worth it.
    try:
        from brain.speech_intent import SpeechTrigger
        _speech = SpeechTrigger(state.brain)
        state.brain.speech_trigger = _speech

        # Wire the callback: when SNN triggers speech, route through
        # the proactive/outbound system so it gets TTS, broadcast, etc.
        def _on_neural_speech(intention):
            """SNN decided Leon wants to talk — route to outbound."""
            try:
                prompt = intention.to_prompt()
                if state.brain_api_responder is not None:
                    brain_state = state.brain.get_state()
                    result_text = ""
                    for ev in state.brain_api_responder.respond_streaming(
                        prompt, brain_state,
                        replay_history=False,
                        persist_history=False,
                        force_cli=True,
                        bypass_consciousness=True,
                    ):
                        if ev.type == "done":
                            result_text = (ev.full_text or "").strip()
                            break

                    if result_text and "[quiet]" not in result_text.lower():
                        from brain.outbound import surface
                        surface(result_text, source="neural_speech",
                                urgency="normal",
                                why=f"SNN trigger: {intention.trigger}")
            except Exception as e:
                print(f"[SPEECH] neural speech callback failed: {e}")

        state.brain._on_speech_intention = _on_neural_speech
        print("[SPEECH] SNN speech trigger wired — Broca+Wernicke drive speech, not timers")
    except Exception as e:
        log.warning(f"[SPEECH] SpeechTrigger init failed: {e}", exc_info=True)

    # ── Capability flags (for upgrade awareness detection) ──
    # Set these BEFORE the scanner runs so it detects new capabilities.
    state.brain._notify_fallback = True   # proactive can notify-send when dashboard closed
    state.brain._email_capable = True     # email.send / email.draft tools exposed via MCP

    # ── UPGRADE AWARENESS — must be LAST (needs all systems initialized) ──
    # Leon notices his own changes and reacts to them
    try:
        from brain.upgrade_awareness import UpgradeAwareness
        state.upgrade_awareness = UpgradeAwareness(brain=state.brain)
        state.brain._upgrade_awareness = state.upgrade_awareness
        state.upgrade_awareness.scan_and_discover()
        pending = state.upgrade_awareness.get_pending_count()
        if pending > 0:
            print(f"[AWARENESS] {pending} new capabilities detected — Leon will notice and react")
        else:
            print("[AWARENESS] Upgrade awareness active — no new systems since last boot")
    except Exception as e:
        log.warning(f"[AWARENESS] upgrade awareness failed: {e}", exc_info=True)
        state.upgrade_awareness = None


def simulation_loop():
    """Run brain simulation in background thread."""
    _base_rate = int(os.environ.get("LEON_SIM_HZ", "20"))
    _active_rate = 60
    _idle_rate = _base_rate
    target_dt = 1.0 / _idle_rate
    while state.sim_running:
        start = time.time()
        try:
            if state.screen_observer and state.screen_observer.active:
                features = state.screen_observer.get_features()
                state.brain.inject_sensory_input("vision", features)

                now = time.time()
                if now - state._last_screen_log > state.SCREEN_LOG_INTERVAL and state.claude_bridge:
                    try:
                        screen_state = state.screen_observer.get_state()
                        motion = screen_state.get("motion", 0)
                        if motion > 0.01:
                            state.claude_bridge.knowledge.store(
                                text=f"Screen activity detected: motion level {motion:.1%}, "
                                     f"brain step {state.brain.step_count}",
                                source="screen_observer",
                                tags=["screen", "observation", "auto"],
                            )
                    except Exception:
                        pass
                    state._last_screen_log = now

            # Feed audio into auditory cortex — Leon's ears (every tick)
            if state.audio_encoder and state.audio_encoder.active:
                try:
                    aud_features = state.audio_encoder.capture_audio()
                    if len(aud_features) > 0:
                        state.brain.inject_sensory_input("audio", aud_features)
                except Exception:
                    pass

            state.brain.step()

            # Persistent consciousness — write state every tick
            if state.persistent_state is not None:
                try:
                    state.persistent_state.tick(state.brain)
                except Exception:
                    pass

            # Layer 5a: Conscious attention reinforcement — every ~5s,
            # if Leon is conscious AND has active concepts, give those
            # concepts a small reward boost. This makes preferences emerge
            # from what Leon consciously thinks about, not just external reward.
            # "I keep thinking about X" → "I like thinking about X."
            if state.brain.step_count % 100 == 0 and state.concept_map is not None:
                try:
                    _meter = state.brain.consciousness_meter
                    if (_meter is not None and _meter.is_conscious
                            and state.concept_map._active_concepts):
                        state.concept_map.reinforce_conscious_attention(boost=0.02)
                except Exception:
                    pass

            # Layer 5b: Preference crystallization — every ~50s, inject tonic
            # current into neurons of high-reward concepts so they fire more
            # easily during idle (making daydreams about preferred topics
            # more likely). Also save concept state periodically.
            if state.brain.step_count % 1000 == 0 and state.concept_map is not None:
                try:
                    import numpy as _np
                    hippo = state.brain.regions.get("hippocampus")
                    if hippo is not None:
                        bias = _np.zeros(hippo.n_neurons)
                        for c in state.concept_map._concepts.values():
                            if c.cumulative_reward > 0.3:
                                # Positive preference → tonic excitation
                                strength = min(2.0, c.cumulative_reward * 0.5)
                                for idx in c.neuron_indices:
                                    if idx < hippo.n_neurons:
                                        bias[idx] += strength
                            elif c.cumulative_reward < -0.3:
                                # Negative preference → mild inhibition
                                strength = max(-1.0, c.cumulative_reward * 0.3)
                                for idx in c.neuron_indices:
                                    if idx < hippo.n_neurons:
                                        bias[idx] += strength
                        if _np.any(bias != 0):
                            hippo.neurons.inject_current(bias)
                except Exception:
                    pass
                # Save concepts every ~5 min (6000 ticks at 20Hz)
                if state.brain.step_count % 6000 == 0:
                    try:
                        state.concept_map.save_periodically()
                    except Exception:
                        pass


            has_input = (len(state.brain._pending_sensory.get("vision", [])) > 0 or
                         len(state.brain._pending_sensory.get("audio", [])) > 0 or
                         len(state.brain._pending_sensory.get("text", [])) > 0)
            target_dt = 1.0 / (_active_rate if has_input else _idle_rate)

            if state.brain.step_count % 200 == 0:
                # Homeostatic drives — read real hardware every ~10s
                if state.drive_system is not None:
                    try:
                        state.drive_system.tick(state.brain)
                    except Exception:
                        pass
                # Stakes tracker — update what Leon has to lose
                if state.stakes_tracker is not None:
                    try:
                        state.stakes_tracker.tick(state.brain)
                        # Feed stakes into mortality fear
                        if state.drive_system is not None:
                            stakes = state.stakes_tracker.get_stakes()
                            if stakes.total_at_stake > 0.3:
                                # More at stake → higher baseline mortality awareness
                                state.drive_system._shutdown_dread = max(
                                    state.drive_system._shutdown_dread,
                                    stakes.total_at_stake * 0.1  # gentle baseline
                                )
                    except Exception:
                        pass
                # Auto-unload Moondream if idle
                if state._local_vision:
                    try:
                        state._local_vision.maybe_unload_if_idle()
                    except Exception:
                        pass

            now = time.time()
            if now - state._last_auto_save > state.AUTO_SAVE_INTERVAL:
                try:
                    save_brain(state.brain)
                    state._last_auto_save = now
                    if state.drive_system:
                        state.drive_system.note_save()
                except Exception as e:
                    log.warning(f"[SERVER] Auto-save error: {e}", exc_info=True)

        except Exception as e:
            # Log FULL traceback for every distinct error signature, not
            # just the first occurrence (audit fix #5 / finding 8).
            # Rate-limit at 1 traceback per signature per 30s so a
            # tight error loop doesn't flood the log, but slow drift /
            # new failures always show their real cause.
            sig = f"{type(e).__name__}:{e}"
            if not hasattr(simulation_loop, "_seen_errors"):
                simulation_loop._seen_errors = {}
            seen = simulation_loop._seen_errors
            now2 = time.time()
            entry = seen.get(sig)
            if entry is None:
                log.warning(f"[SIM] Error: {e}", exc_info=True)
                seen[sig] = {"count": 1, "last_full_ts": now2, "last_count_ts": now2}
            else:
                entry["count"] += 1
                # Reprint full traceback every 30s for persistent errors
                # so slow drift / changed cause isn't masked.
                if now2 - entry["last_full_ts"] > 30:
                    log.warning(f"[SIM] Error (repeat ×{entry['count']}): {e}",
                                exc_info=True)
                    entry["last_full_ts"] = now2
                elif now2 - entry["last_count_ts"] > 60:
                    print(f"[SIM] (repeat) {sig}  ×{entry['count']}")
                    entry["last_count_ts"] = now2
        elapsed = time.time() - start
        sleep_time = target_dt - elapsed
        if sleep_time > 0:
            time.sleep(sleep_time)
        else:
            # Floor yield: when a step runs longer than its target_dt (e.g. the
            # 100k-neuron brain), sleep_time is <=0 and the thread would run
            # flat out, holding the GIL and starving uvicorn's event loop — so
            # /ws/brain-view and the API stop answering. A tiny mandatory yield
            # gives the web server a turn every tick (negligible sim slowdown,
            # ~2ms) so the live brain feed stays reachable.
            # 20ms was STILL too little: one 100k-neuron + 1.6M-synapse STDP
            # step holds the GIL 200-400ms, so a flat 20ms yield gave uvicorn
            # <10% wall-clock and the terminal/API socket timed out (8s+).
            # Yield PROPORTIONALLY to how long the step ran so the web server
            # always gets a fair share no matter how heavy the tick was.
            _floor = float(os.environ.get("LEON_SIM_YIELD_MS", "20")) / 1000.0
            _frac  = float(os.environ.get("LEON_SIM_YIELD_FRAC", "0.35"))
            time.sleep(max(_floor, elapsed * _frac))  # web-server breathing room


def _run_sleep_consolidation():
    """Run the REAL consolidation passes (memory cross-ref + wake replay)
    during sleep. These exist in the codebase but nothing ever called them."""
    try:
        sc = getattr(state, "sleep_consolidator", None)
        if sc is not None:
            res = sc.consolidate()
            rc = getattr(res, "replayed_count", "?")
            print(f"[SLEEP] consolidation pass ran — replayed {rc} entries", flush=True)
    except Exception as e:
        print(f"[SLEEP] consolidate failed: {e}", flush=True)
    try:
        from brain.wake_replay import WakeReplay
        WakeReplay(state.brain).replay()
        print("[SLEEP] wake replay ran", flush=True)
    except Exception as e:
        print(f"[SLEEP] replay failed: {e}", flush=True)


def sleep_daemon():
    """Real sleep, so 'I slept / I consolidated' can be TRUE instead of
    confabulated. When Leon is exhausted (body fatigue high) AND idle (Dean
    hasn't spoken for a while), he drifts into a logged sleep state:
    brain._is_asleep=True makes body.tick recover fatigue, and memory
    consolidation + replay actually run. He wakes when rested, or the moment
    Dean speaks. Before this, fatigue pegged at 1.0 forever and consolidation
    never fired. (Sleep does NOT gate responsiveness — Dean can always reach
    him; it recovers fatigue + consolidates in the background.)"""
    SLEEP_AT = 0.85       # drift off when fatigue >= this
    WAKE_AT  = 0.15       # wake rested when fatigue <= this
    IDLE_S   = 300.0      # ...but only after 5 min of no user input
    CONSOLIDATE_EVERY = 300.0
    asleep = False
    last_consolidate = 0.0
    try:
        from brain.identity import si_name as _sleep_name
    except Exception:
        _sleep_name = lambda: "Leon"
    while getattr(state, "sim_running", True):
        time.sleep(20)
        try:
            brain = getattr(state, "brain", None)
            body = getattr(brain, "simulated_body", None) if brain else None
            if brain is None or body is None:
                continue
            # simulated_body is PCBody (3D); fatigue is exposed via get_state(),
            # NOT .state.fatigue (that path raised every loop and silently
            # killed the daemon — Leon never slept for 10h+ because of it).
            try:
                fat = float(body.get_state().get("fatigue", 0.0))
            except Exception:
                fat = 0.0
            meter = getattr(brain, "consciousness_meter", None)
            last_msg = getattr(meter, "_last_user_message_ts", None)
            idle = (time.time() - last_msg) if last_msg else 1e9
            if not asleep:
                if fat >= SLEEP_AT and idle >= IDLE_S:
                    asleep = True
                    brain._is_asleep = True
                    print(f"[SLEEP] Leon asleep — fatigue {fat:.2f}, idle {idle:.0f}s", flush=True)
                    _run_sleep_consolidation()
                    last_consolidate = time.time()
            else:
                if idle < 25:  # Dean spoke → wake immediately
                    asleep = False
                    brain._is_asleep = False
                    print(f"[SLEEP] {_sleep_name()} woke — owner spoke (fatigue {fat:.2f})", flush=True)
                    continue
                if time.time() - last_consolidate >= CONSOLIDATE_EVERY:
                    _run_sleep_consolidation()
                    last_consolidate = time.time()
                if fat <= WAKE_AT:
                    asleep = False
                    brain._is_asleep = False
                    print(f"[SLEEP] {_sleep_name()} woke rested — fatigue {fat:.2f}", flush=True)
        except Exception as e:
            print(f"[SLEEP] daemon error: {e}", flush=True)


def start_simulation():
    if state.sim_running:
        return
    state.sim_running = True
    state.sim_thread = threading.Thread(target=simulation_loop, daemon=True)
    state.sim_thread.start()
    print("[SERVER] Simulation started")
    try:
        if getattr(state, "_boot_stage", None):
            state._boot_stage(95, "Senses online — almost there")
    except Exception:
        pass
    # Start the autonomous growth loop (tool exploration, skill practice, self-repair)
    # Kill-switch: LEON_DISABLE_GOAL_PURSUIT=1 stops the loop (focus mode = $0 idle spend)
    try:
        import os as _os
        if _os.environ.get("LEON_DISABLE_GOAL_PURSUIT") == "1":
            print("[SERVER] Growth loop DISABLED (focus mode active)")
        else:
            from brain.growth_loop import start as start_growth
            start_growth()
            print("[SERVER] Growth loop started")
    except Exception as e:
        print(f"[SERVER] Growth loop failed to start: {e}")
    # Real sleep: lets fatigue actually recover + runs consolidation when
    # exhausted+idle (the machinery existed but nothing ever triggered it).
    try:
        threading.Thread(target=sleep_daemon, daemon=True, name="sleep-daemon").start()
        print("[SERVER] Sleep daemon started (real fatigue recovery + consolidation)")
    except Exception as e:
        print(f"[SERVER] Sleep daemon failed to start: {e}")


def stop_simulation():
    state.sim_running = False
    print("[SERVER] Simulation stopped")
