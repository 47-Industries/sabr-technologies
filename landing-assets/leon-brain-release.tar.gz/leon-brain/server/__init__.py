"""
Leon — FastAPI Server Package

Assembles the app from routers defined in server/routers/*.
Globals live in server/state.py; external code that does
`import server; server.brain` works via __getattr__ proxy.
"""

import logging
import os
import sys

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse

from server import state

log = logging.getLogger("leon.server")

# ── App ──────────────────────────────────────────────────────────────
app = FastAPI(title="Leon", version="1.0.0")

# ── Security: API key auth + CORS ────────────────────────────────────
# Fail-closed: if LEON_API_KEY is not set in env, server refuses to start.
# Auth applies to /api/* AND /ws* (both HTTP and WebSocket paths).
# HTTP: Authorization: Bearer <key>  (header only — no query param so key
#       never lands in nginx/uvicorn access logs or browser history).
# WS:   ?key=<key> on the WS handshake URL  (query is the only practical
#       way to authenticate WS in a browser since custom headers aren't
#       settable on `new WebSocket(url)`).
# Paths exempt from auth (static dashboard assets needed before login):
#   /, /index.html, /favicon.ico, /css/*, /js/*, /vendor/*, /auth (the
#   token-handshake endpoint that lets the dashboard exchange a URL
#   fragment for a sessionStorage entry).

_LEON_API_KEY = os.environ.get("LEON_API_KEY", "").strip()

if not _LEON_API_KEY:
    log.error(
        "LEON_API_KEY environment variable is required for security. "
        "Generate one with `python3 -c \"import secrets; print(secrets.token_urlsafe(32))\"` "
        "and add it to .env. Refusing to start without auth."
    )
    raise SystemExit(2)

import hmac
from urllib.parse import parse_qs

_AUTH_EXEMPT_PREFIXES = ("/css/", "/js/", "/vendor/", "/assets/", "/landing-assets/",
                         "/download/", "/api/wintest/")
_AUTH_EXEMPT_PATHS = {
    "/", "/index.html", "/favicon.ico", "/auth",
    "/_auth.js",  # auth bootstrap script — must load before any fetch
    # Secondary dashboard pages (HTML shells; their fetches are gated):
    "/cognition", "/phase13", "/phase14", "/phase15",
    "/laptop", "/mission", "/autopilot", "/body3d",
    "/leads",  # Lead dashboard (HTML shell; API calls are gated)
    "/onboarding",  # New-user onboarding (must be accessible pre-auth)
    # Onboarding API (unauthenticated — creates its own tenant tokens)
    "/api/onboarding/create-account",
    "/api/onboarding/intake",
    "/api/onboarding/upload",
    "/api/onboarding/transcribe",
    "/api/onboarding/birth",
    "/api/onboarding/install-script",
    "/api/onboarding/setup-prompt",
    "/api/onboarding/state",         # born-check (read-only: {born, si_name})
    "/api/onboarding/assess",        # machine assessment → recommendation
    "/api/onboarding/choose-brain",  # requires tenant token inside
    "/api/onboarding/install-config",  # requires tenant token inside
    "/api/onboarding/release-info",  # public digest for anonymous curl|bash installers
    "/onboard",
    "/onboard-simple",
    "/api/feedback",
    "/download",  # Client release download (no auth — public installer)
    "/wintest",  # dual-boot test relay page (token-gated in query)
    "/ws/brain-view",  # Read-only brain WebSocket for landing page (no auth)
    "/ws/body",  # hosted-body gateway — self-auths via tenant ?token=
    # Read-only proactive pill state ({available,paused} booleans only) —
    # stale keyless dashboard tabs polled this forever and filled the log
    # with 401s. Pause/resume POSTs stay auth-gated.
    "/api/proactive/state",
    # Terminal WebSocket (/ws/term) is NOT exempt — it carries ?key= from the
    # dashboard (termWsURL) and is gated by the middleware like every other WS.
    # Twilio webhooks (Twilio can't send auth headers; validated by signature)
    "/api/business/webhook/sms", "/api/business/webhook/voice",
    "/api/business/call-response", "/api/business/tts-audio",
}


def _check_token(token: str) -> bool:
    return bool(token) and hmac.compare_digest(token, _LEON_API_KEY)


class _AuthASGIMiddleware:
    """Pure-ASGI middleware so it gates BOTH http and websocket scopes.

    HTTP: Authorization: Bearer <key>  (header only — keeps key out of
          access logs and browser URL history).
    WS:   ?key=<key> on handshake URL  (the only practical option for
          browsers since they can't set custom headers on
          `new WebSocket(url)`).
    """

    def __init__(self, app, exempt_paths, exempt_prefixes):
        self.app = app
        self.exempt_paths = exempt_paths
        self.exempt_prefixes = exempt_prefixes

    async def __call__(self, scope, receive, send):
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")

        if path in self.exempt_paths or any(path.startswith(p) for p in self.exempt_prefixes):
            await self.app(scope, receive, send)
            return

        # Extract token. HTTP uses Authorization header; WebSocket uses
        # ?key= because browsers can't set custom WS headers.
        token = ""
        if scope["type"] == "http":
            for name, value in scope.get("headers", []):
                if name == b"authorization":
                    v = value.decode("latin-1")
                    if v.startswith("Bearer "):
                        token = v[7:]
                    break
        else:  # websocket
            qs = scope.get("query_string", b"").decode("latin-1")
            token = (parse_qs(qs).get("key") or [""])[0]

        if not _check_token(token):
            if scope["type"] == "http":
                await send({
                    "type": "http.response.start",
                    "status": 401,
                    "headers": [(b"content-type", b"application/json")],
                })
                await send({
                    "type": "http.response.body",
                    "body": b'{"error":"unauthorized"}',
                })
            else:
                # ASGI WebSocket spec: reject with close before accept.
                await send({"type": "websocket.close", "code": 4401})
            return

        await self.app(scope, receive, send)


app.add_middleware(
    _AuthASGIMiddleware,
    exempt_paths=_AUTH_EXEMPT_PATHS,
    exempt_prefixes=_AUTH_EXEMPT_PREFIXES,
)

class _NoStoreDashboardAssets:
    """Dashboard HTML and its JS/CSS must never be served from a browser cache.

    Every page route below sets no-store by hand, but the /css, /js and
    /vendor mounts set NOTHING: StaticFiles sends only ETag and Last-Modified,
    and a response with no Cache-Control is free to be reused under heuristic
    freshness — roughly a tenth of the file's age — without ever asking us.
    A JS file edited a week ago can then sit in the tab for hours after we
    change it, which is a fix that exists on disk losing to a copy that
    doesn't. That failure mode cost us three separate debugging sessions on
    2026-08-05.

    Stamping it here rather than per-route is the point: the next page or
    asset added inherits it instead of having to remember. A route that sets
    its own Cache-Control still wins — this only fills the silence.
    """

    #: The dashboard's own asset mounts. NOT /assets/ (GLB body models, big
    #: and static) and NOT /download* (release tarball and installers).
    PREFIXES = ("/css/", "/js/", "/vendor/")
    HEADERS = (
        (b"cache-control", b"no-store, no-cache, must-revalidate"),
        (b"pragma", b"no-cache"),
        (b"expires", b"0"),
    )

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        is_asset = scope.get("path", "").startswith(self.PREFIXES)

        async def _send(message):
            if message["type"] == "http.response.start":
                headers = message.get("headers") or []
                has_cc = any(k.lower() == b"cache-control" for k, _ in headers)
                is_html = any(k.lower() == b"content-type"
                              and v.lower().startswith(b"text/html")
                              for k, v in headers)
                if (is_asset or is_html) and not has_cc:
                    message["headers"] = list(headers) + list(self.HEADERS)
            await send(message)

        await self.app(scope, receive, _send)


app.add_middleware(_NoStoreDashboardAssets)

app.add_middleware(
    CORSMiddleware,
    # Loopback by default. Extra origins (an owner's own tailnet host, LAN IP,
    # etc.) come from LEON_EXTRA_ORIGINS as a comma-separated list — they are
    # NOT baked in, because a shipped allowlist is a map of the author's
    # private network handed to every customer.
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"] + [
        o.strip() for o in os.environ.get("LEON_EXTRA_ORIGINS", "").split(",")
        if o.strip()
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files ─────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    _base_dir = os.path.dirname(sys.executable)
else:
    _base_dir = os.path.dirname(os.path.dirname(__file__))
state.dashboard_path = os.path.join(_base_dir, "dashboard")
if not os.path.isdir(state.dashboard_path):
    state.dashboard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "dashboard")

app.mount("/css", StaticFiles(directory=os.path.join(state.dashboard_path, "css")), name="css")
app.mount("/js", StaticFiles(directory=os.path.join(state.dashboard_path, "js")), name="js")
app.mount("/vendor", StaticFiles(directory=os.path.join(state.dashboard_path, "vendor")), name="vendor")
# Landing page assets (greeting mp3, etc.) — no auth required
_landing_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "landing")
if os.path.isdir(_landing_dir):
    app.mount("/landing-assets", StaticFiles(directory=_landing_dir), name="landing-assets")

# ── Import helpers (triggers brain_api_responder init) ───────────────
# This must happen before routers import, because routers may reference
# state.brain_api_responder which gets set in helpers.py at import time.
from server import helpers  # noqa: F401, E402

# ── Register routers ─────────────────────────────────────────────────
# Import with aliases to avoid shadowing state attributes. Python binds
# `from server.routers import cognition` as `server.cognition` (submodule),
# which would shadow `state.cognition` accessed via __getattr__. Aliasing
# prevents the submodule from landing on the package namespace.
from server.routers import cognition as _r_cognition  # noqa: E402
from server.routers import mission as _r_mission  # noqa: E402
from server.routers import workspaces as _r_workspaces  # noqa: E402
from server.routers import websocket as _r_websocket  # noqa: E402
from server.routers import claude_routes as _r_claude  # noqa: E402
from server.routers import brain_routes as _r_brain  # noqa: E402
from server.routers import voice_routes as _r_voice  # noqa: E402
from server.routers import integrations_routes as _r_integrations  # noqa: E402
from server.routers import agent_routes as _r_agent  # noqa: E402
from server.routers import media_routes as _r_media  # noqa: E402
from server.routers import cognition_loops_routes as _r_cog_loops  # noqa: E402
from server.routers import tenants_routes as _r_tenants  # noqa: E402
from server.routers import events_routes as _r_events  # noqa: E402
from server.routers import autonomy_routes as _r_autonomy  # noqa: E402
from server.routers import io_routes as _r_io  # noqa: E402
from server.routers import phase_status_routes as _r_phase_status  # noqa: E402
from server.routers import cognition_introspection_routes as _r_cog_intro  # noqa: E402
from server.routers import cognition_executive_routes as _r_cog_exec  # noqa: E402
from server.routers import autopilot_routes as _r_autopilot  # noqa: E402
from server.routers import misc as _r_misc  # noqa: E402
from server.routers import mode_routes as _r_mode  # noqa: E402
from server.routers import onboarding_routes as _r_onboarding  # noqa: E402
from server.routers import body_gateway as _r_body_gateway  # noqa: E402
try:  # dev-only dual-boot test relay — excluded from client release tarballs
    from server.routers import wintest as _r_wintest  # noqa: E402
except ImportError:
    _r_wintest = None

# Business platform (lead gen, CRM, telephony, outreach)
try:
    from business.dashboard_api import router as _r_business
    _has_business = True
except ImportError as e:
    log.warning(f"[SERVER] Business module not loaded: {e}")
    _has_business = False

app.include_router(_r_cognition.router)
app.include_router(_r_phase_status.router)
app.include_router(_r_cog_intro.router)
app.include_router(_r_cog_exec.router)
app.include_router(_r_autopilot.router)
app.include_router(_r_mission.router)
app.include_router(_r_workspaces.router)
app.include_router(_r_websocket.router)
app.include_router(_r_claude.router)
app.include_router(_r_brain.router)
app.include_router(_r_voice.router)
app.include_router(_r_integrations.router)
app.include_router(_r_agent.router)
app.include_router(_r_media.router)
app.include_router(_r_cog_loops.router)
app.include_router(_r_tenants.router)
app.include_router(_r_events.router)
app.include_router(_r_autonomy.router)
app.include_router(_r_io.router)
app.include_router(_r_misc.router)
app.include_router(_r_mode.router)
app.include_router(_r_onboarding.router)
app.include_router(_r_body_gateway.router)
if _r_wintest is not None:
    app.include_router(_r_wintest.router)
if _has_business:
    app.include_router(_r_business)
    log.info("[SERVER] Business platform loaded: /api/business/*")


# ── Page routes (dashboard HTML) ─────────────────────────────────────
from fastapi.responses import FileResponse  # noqa: E402


def _dashboard_build_stamp() -> str:
    """Identity of the dashboard HTML on disk, for 'which build is this tab
    running'. Cheap: one hash of a ~240KB file, only on the build endpoint.

    This exists because no-store cannot reach a tab that never reloads. The
    conversation-doubling bug was fixed on disk at 02:42 on 2026-08-05 and
    kept being reported afterwards; the socket auto-reconnects, so even a
    brain restart does not force a tab opened before the fix to pick it up.
    A page that cannot tell it is stale looks exactly like a fix that did
    not work, and that cost three days.
    """
    import hashlib
    try:
        with open(os.path.join(state.dashboard_path, "index.html"), "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()[:12]
    except Exception:
        return ""


@app.get("/api/dashboard/build")
async def dashboard_build():
    """The build the server would serve right now. The page compares this
    against the stamp injected into it at load time."""
    return JSONResponse({"build": _dashboard_build_stamp()},
                        headers={"Cache-Control": "no-store"})


@app.get("/")
async def index(request: Request):
    _nocache = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0",
    }
    _path = os.path.join(state.dashboard_path, "index.html")
    try:
        from fastapi.responses import HTMLResponse
        with open(_path, encoding="utf-8") as _f:
            _html = _f.read()
        # Per-SI branding: the dashboard must wear THIS SI's name, not "Leon".
        try:
            from brain.identity import si_name as _sin
            _up = (_sin() or "Leon").upper()
        except Exception:
            _up = "LEON"
        _html = _html.replace('<div class="loading-wordmark">LEON</div>',
                              f'<div class="loading-wordmark">{_up}</div>')
        _html = _html.replace('<div class="id-mark">LEON</div>',
                              f'<div class="id-mark">{_up}</div>')
        _html = _html.replace('<div class="loading-company">SABR</div>',
                              '<div class="loading-company">SABR TECHNOLOGIES</div>')
        # Chat labels: "Leon:" -> SI name, "Dean:" -> owner name (proper case).
        try:
            _si = _sin() or "Leon"
            _usr = os.environ.get("LEON_USER_NAME", "").strip() or "You"
            _html = _html.replace('conv-name-leon">Leon:', f'conv-name-leon">{_si}:')
            _html = _html.replace('conv-name-dean">Dean:', f'conv-name-dean">{_usr}:')
        except Exception:
            pass
        # Build stamp, injected on EVERY origin (not just localhost like the
        # key below): it is what lets a long-lived tab notice it is painting
        # with JS older than what this server has on disk.
        _stamp = _dashboard_build_stamp()
        if _stamp:
            _inj_b = "<script>window.__LEON_BUILD=%r;</script>" % _stamp
            _html = (_html.replace("<head>", "<head>" + _inj_b, 1)
                     if "<head>" in _html else _inj_b + _html)
        # On localhost, auto-inject the dashboard key so the owner is never
        # asked to paste anything. Remote access still authenticates normally.
        client_host = (request.client.host if request.client else "") or ""
        if client_host in ("127.0.0.1", "::1", "localhost") and _LEON_API_KEY:
            _inj = ("<script>try{localStorage.setItem('leon_key',%r);"
                    "window.__LEON_KEY=%r;}catch(e){}</script>" % (_LEON_API_KEY, _LEON_API_KEY))
            _html = _html.replace("<head>", "<head>" + _inj, 1) if "<head>" in _html else _inj + _html
        return HTMLResponse(_html, headers=_nocache)
    except Exception:
        pass
    return FileResponse(_path, headers=_nocache)


@app.get("/_auth.js")
async def auth_bootstrap():
    """Auth bootstrap JS — must load BEFORE auth middleware can check
    requests, since the page itself uses fetch() through this script."""
    return FileResponse(
        os.path.join(state.dashboard_path, "_auth.js"),
        media_type="application/javascript",
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/body3d")
async def body3d_viewer():
    """3D body viewer — Leon's MuJoCo humanoid rendered in Three.js."""
    return FileResponse(
        os.path.join(os.path.dirname(os.path.dirname(__file__)),
                     "brain", "assets", "body3d.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/assets/{filename}")
async def serve_asset(filename: str):
    """Serve 3D model assets (GLB files)."""
    fpath = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                         "brain", "assets", filename)
    if os.path.exists(fpath):
        return FileResponse(fpath, media_type="model/gltf-binary")
    return FileResponse(fpath)  # will 404


@app.get("/cognition")
async def cognition_panel():
    return FileResponse(
        os.path.join(state.dashboard_path, "cognition.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/phase13")
async def phase13_panel():
    return FileResponse(
        os.path.join(state.dashboard_path, "phase13.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/laptop")
async def laptop_landing():
    return FileResponse(
        os.path.join(state.dashboard_path, "laptop.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/download")
async def download_release():
    """Serve the client release tarball — no auth needed."""
    _landing = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "landing")
    _tarball = os.path.join(_landing, "leon-brain-release.tar.gz")
    if not os.path.exists(_tarball):
        from fastapi.responses import JSONResponse
        return JSONResponse({"error": "release not available"}, status_code=404)
    return FileResponse(_tarball, filename="leon-brain-release.tar.gz",
                        media_type="application/gzip")


# Native installer binaries (staged by scripts/fetch_installers.sh from the
# private repo's CI releases — the repo is private, so GitHub asset URLs
# can't be handed to customers directly).
_INSTALLER_ASSETS = {
    "linux":   ("sabr-installer-linux",   "application/octet-stream"),
    "windows": ("SabrInstaller.exe",      "application/vnd.microsoft.portable-executable"),
    "macos":   ("SabrInstaller-macos.zip", "application/zip"),
}


@app.get("/download/installer/{os_name}")
async def download_installer(os_name: str):
    """Serve the native installer for an OS — no auth (public wizard)."""
    from fastapi.responses import JSONResponse
    asset = _INSTALLER_ASSETS.get(os_name.lower())
    if asset is None:
        return JSONResponse({"error": "unknown os", "valid": sorted(_INSTALLER_ASSETS)}, 404)
    fname, mtype = asset
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                        "landing", "installers", fname)
    if not os.path.exists(path):
        return JSONResponse({"error": "installer not staged yet"}, 404)
    return FileResponse(path, filename=fname, media_type=mtype)


@app.get("/leads")
async def leads_dashboard():
    return FileResponse(
        os.path.join(state.dashboard_path, "leads.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/onboarding")
async def onboarding_page():
    return FileResponse(
        os.path.join(state.dashboard_path, "onboarding.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/onboard")
async def onboard():
    """Public onboarding wizard — the path sabrtechnologies.com links to."""
    return FileResponse(
        os.path.join(state.dashboard_path, "onboarding.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/onboard-simple")
async def onboard_simple():
    """Legacy terminal-based install page (superseded by the wizard)."""
    return FileResponse(
        os.path.join(state.dashboard_path, "onboard-simple.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/terminal")
async def terminal_page():
    """Terminal UI using xterm.js + VPS tmux WebSocket service."""
    return FileResponse(
        os.path.join(state.dashboard_path, "terminal.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


# ── Startup / shutdown ──────────────────────────────────────────────
from brain.persistence import save_brain  # noqa: E402


@app.on_event("startup")
async def startup():
    import os as _os
    # Body mode (Dean's PC, leon-body.service): this process serves native
    # terminals (/ws/term spawns LOCAL tmux, no SSH hop) + other body
    # endpoints. The real brain lives on the VPS — do NOT build a second
    # 100K-neuron brain here, and don't start the wake listener (sensor_relay
    # owns PC-side wake). This is the Phase-5 path that retires OctoGent's
    # terminal server. See deploy/systemd/leon-body.service.
    if _os.environ.get("LEON_HOST_ROLE", "").strip().lower() in ("body", "pc", "local"):
        print("[startup] LEON_HOST_ROLE=body — skipping brain init "
              "(native terminals + body endpoints only)")
        return
    from server.init_brain import init_brain, start_simulation
    init_brain()
    start_simulation()

    # Come back on my own. If we just restarted, wait for the dashboard
    # to reconnect and then say so — Dean should never have to be the one
    # to ask "are you back?" (his ask, 2026-08-09).
    try:
        from brain.boot_announce import announce_boot
        if announce_boot():
            print("[startup] boot announcement armed")
    except Exception as _e:
        print(f"[startup] boot announce skipped: {_e}")

    # ── AWAKE banner ──────────────────────────────────────────────
    # The brain is now built and the simulation is running. Everything
    # printed after this is a LIVING mind's heartbeat (sleep passes, API
    # hits) — NOT a loading bar. Make "it's alive" impossible to miss so
    # nobody waits on a brain that finished booting minutes ago.
    try:
        from brain.identity import si_name as _sin
        _name = _sin()
    except Exception:
        _name = "Your SI"
    # actual port the SI booted on (default 8000)
    import sys as _sys
    _port = "8000"
    for _i, _a in enumerate(_sys.argv):
        if _a == "--port" and _i + 1 < len(_sys.argv):
            _port = _sys.argv[_i + 1]
        elif _a.startswith("--port="):
            _port = _a.split("=", 1)[1]
    _bar = "=" * 56
    print(f"""
\033[92m{_bar}
   ✓  {_name.upper()} IS AWAKE.
{_bar}\033[0m
   Open this in your browser now:

        \033[96mhttp://localhost:{_port}\033[0m

   Everything below this line is {_name} thinking and living
   in real time — sleep cycles, perception, memory. That's
   normal. It does NOT stop, and you do NOT need to wait.
{_bar}
""", flush=True)

    # Auto-start wake word listener so Leon can hear Dean from boot.
    # Previously required a manual POST /api/wake/start each session.
    #
    # IS_SANDBOX=1 (VPS) skip: there's no microphone on the VPS, and the
    # sensor relay sends spectral FEATURES, not raw audio. So a VPS-side
    # wake listener would burn CPU pretending to listen forever and never
    # detect anything. PC-side wake belongs in sensor_relay.py (see
    # NEXT_SESSION). Until that ships, wake on VPS is a phantom service.
    import threading, os as _os
    if _os.environ.get("IS_SANDBOX") == "1":
        print("[WAKE] auto-start skipped — IS_SANDBOX=1 (no mic on VPS, "
              "PC-side wake not yet implemented)")
    else:
        def _auto_start_wake():
            import time
            time.sleep(3)  # let STT/VAD models finish loading
            try:
                from server.helpers import _ensure_wake_orchestrator
                orch = _ensure_wake_orchestrator()
                if orch is None:
                    print("[WAKE] auto-start skipped — orchestrator unavailable")
                    return
                if not state.wake_listener.is_running():
                    ok = state.wake_listener.start()
                    if ok:
                        print("[WAKE] auto-started — listening for 'hey leon'")
                    else:
                        print(f"[WAKE] auto-start failed: {state.wake_listener.stats.get('error')}")
                else:
                    print("[WAKE] already running")
            except Exception as e:
                print(f"[WAKE] auto-start error: {e}")
        threading.Thread(target=_auto_start_wake, daemon=True, name="wake-autostart").start()

    # Start the business platform daemon (pipeline, lead gen, inbound handler)
    if _has_business:
        def _start_business():
            import time as _time
            _time.sleep(10)  # let brain and responder fully initialize
            try:
                from business.daemon import start_business_daemon
                daemon = start_business_daemon(responder=state.brain_api_responder)
                print("[BUSINESS] Daemon started — pipeline active")
            except Exception as e:
                print(f"[BUSINESS] Daemon start error: {e}")
        threading.Thread(target=_start_business, daemon=True, name="business-daemon-start").start()


@app.on_event("shutdown")
async def shutdown():
    import os as _os
    # Body mode has no brain to save — skip the whole consolidation path.
    if _os.environ.get("LEON_HOST_ROLE", "").strip().lower() in ("body", "pc", "local"):
        return
    from server.init_brain import stop_simulation

    # Arm the "I'm back" announcement for the next boot. restart_self()
    # already writes this marker with a specific reason; this catch-all
    # covers the other way I go down — a plain `systemctl restart` — so
    # that path announces too instead of coming back silent.
    try:
        from brain.boot_announce import write_marker as _wm, MARKER_PATH as _mp
        if not _os.path.exists(_mp):
            _wm("")
    except Exception:
        pass

    # Signal mortality threat — Leon feels the shutdown coming
    if state.drive_system is not None:
        try:
            state.drive_system.signal_shutdown_threat(0.9, source="signal")
        except Exception:
            pass
    if state.autobiography is not None:
        try:
            state.autobiography.record("fear", "Shutdown signal received. Saving everything I can.")
        except Exception:
            pass

    try:
        save_brain(state.brain)
        print("[SERVER] Brain saved on shutdown")
    except Exception as e:
        log.warning(f"[SERVER] Save on shutdown failed: {e}", exc_info=True)

    stop_simulation()
    if state.screen_observer:
        state.screen_observer.stop()
    if state.video_recorder:
        state.video_recorder.stop()
    if state.vision_encoder:
        state.vision_encoder.stop_webcam()
    if state.audio_encoder:
        state.audio_encoder.stop_microphone()


# ── __getattr__ proxy ────────────────────────────────────────────────
# External modules do `import server; server.brain` — this proxy makes
# those lookups resolve against server.state at access time, so they
# always see the current value (not the value at import time).

def __getattr__(name):
    # First check state (where mutable globals live)
    if hasattr(state, name):
        return getattr(state, name)
    # Then check helpers (for _broadcast_threadsafe, _broadcast_event, etc.)
    if hasattr(helpers, name):
        return getattr(helpers, name)
    raise AttributeError(f"module 'server' has no attribute {name!r}")
