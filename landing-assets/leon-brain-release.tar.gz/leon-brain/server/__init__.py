"""
Leon — FastAPI Server Package

Assembles the app from routers defined in server/routers/*.
Globals live in server/state.py; external code that does
`import server; server.brain` works via __getattr__ proxy.
"""

import logging
import os
import re
import sys

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.responses import JSONResponse

from server import state

log = logging.getLogger("leon.server")

# ── App ──────────────────────────────────────────────────────────────
app = FastAPI(title="Leon", version="1.0.0")

# ── Security: API key auth + CORS ────────────────────────────────────
# Fail-closed: if LEON_API_KEY is not set in env, server refuses to start.
# Auth applies to /api/* AND /ws* (both HTTP and WebSocket paths).
# HTTP: Authorization: Bearer <key>  (header only — no query param so key
#       never lands in nginx/uvicorn access logs or browser history).
# WS:   ?key=<key> on the WS handshake URL  (query is the only practical
#       way to authenticate WS in a browser since custom headers aren't
#       settable on `new WebSocket(url)`).
# Paths exempt from auth (static dashboard assets needed before login):
#   /, /index.html, /favicon.ico, /css/*, /js/*, /vendor/*, /auth (the
#   token-handshake endpoint that lets the dashboard exchange a URL
#   fragment for a sessionStorage entry).

_LEON_API_KEY = os.environ.get("LEON_API_KEY", "").strip()

if not _LEON_API_KEY:
    log.error(
        "LEON_API_KEY environment variable is required for security. "
        "Generate one with `python3 -c \"import secrets; print(secrets.token_urlsafe(32))\"` "
        "and add it to .env. Refusing to start without auth."
    )
    raise SystemExit(2)

import hmac
from urllib.parse import parse_qs

_AUTH_EXEMPT_PREFIXES = ("/css/", "/js/", "/vendor/", "/assets/", "/landing-assets/",
                         "/download/", "/api/wintest/")
_AUTH_EXEMPT_PATHS = {
    "/", "/index.html", "/favicon.ico", "/auth",
    "/_auth.js",  # auth bootstrap script — must load before any fetch
    # Secondary dashboard pages (HTML shells; their fetches are gated):
    "/cognition", "/brainweb", "/phase13", "/phase14", "/phase15",
    "/laptop", "/mission", "/autopilot", "/body3d",
    # Mind map: 3D render of the cognition graph. Shell + its data, both
    # exempt for the same reason /body3d is — it is a viewer, and the box
    # is only reachable over the tailnet in the first place.
    "/mindmap", "/api/mindmap",
    "/leads",  # Lead dashboard (HTML shell; API calls are gated)
    "/onboarding",  # New-user onboarding (must be accessible pre-auth)
    # Build markers + liveness only (no brain state, no identity, no tenant).
    # Gated before 2026-08-12, which made a healthy install answer 401 to
    # "what version are you?" — indistinguishable from a broken one.
    "/api/version",
    "/healthz",
    # "Do you have a brain that can answer?" — same class as /healthz and
    # needed for the same reason: the installer asks this before it dares
    # print "ready", and it asks before any key handshake exists. Returns
    # only which backend would take a turn (cloud / cli / local / none) —
    # no brain state, no identity, no tenant, no key material.
    "/api/brain-check",
    # Onboarding API (unauthenticated — creates its own tenant tokens)
    "/api/onboarding/create-account",
    "/api/onboarding/intake",
    "/api/onboarding/upload",
    "/api/onboarding/transcribe",
    "/api/onboarding/birth",
    "/api/onboarding/install-script",
    "/api/onboarding/setup-prompt",
    "/api/onboarding/state",         # born-check (read-only: {born, si_name})
    "/api/onboarding/assess",        # machine assessment → recommendation
    "/api/onboarding/choose-brain",  # requires tenant token inside
    "/api/onboarding/install-config",  # requires tenant token inside
    "/api/onboarding/release-info",  # public digest for anonymous curl|bash installers
    "/onboard",
    "/onboard-simple",
    "/api/feedback",
    # Live install log — WRITE only, and only append. A beta tester's machine
    # has no credentials, so this has to be open the same way /api/feedback is.
    # Reading is NOT here: /api/admin/install-log* stays gated.
    "/api/onboarding/install-log",
    "/download",  # Client release download (no auth — public installer)
    "/wintest",  # dual-boot test relay page (token-gated in query)
    "/ws/brain-view",  # Read-only brain WebSocket for landing page (no auth)
    "/ws/body",  # hosted-body gateway — self-auths via tenant ?token=
    # Read-only proactive pill state ({available,paused} booleans only) —
    # stale keyless dashboard tabs polled this forever and filled the log
    # with 401s. Pause/resume POSTs stay auth-gated.
    "/api/proactive/state",
    # Terminal WebSocket (/ws/term) is NOT exempt — it carries ?key= from the
    # dashboard (termWsURL) and is gated by the middleware like every other WS.
    # Twilio webhooks (Twilio can't send auth headers; validated by signature)
    "/api/business/webhook/sms", "/api/business/webhook/voice",
    "/api/business/call-response", "/api/business/tts-audio",
}


def _check_token(token: str) -> bool:
    return bool(token) and hmac.compare_digest(token, _LEON_API_KEY)


class _AuthASGIMiddleware:
    """Pure-ASGI middleware so it gates BOTH http and websocket scopes.

    HTTP: Authorization: Bearer <key>  (header only — keeps key out of
          access logs and browser URL history).
    WS:   ?key=<key> on handshake URL  (the only practical option for
          browsers since they can't set custom headers on
          `new WebSocket(url)`).
    """

    def __init__(self, app, exempt_paths, exempt_prefixes):
        self.app = app
        self.exempt_paths = exempt_paths
        self.exempt_prefixes = exempt_prefixes

    async def __call__(self, scope, receive, send):
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")

        if path in self.exempt_paths or any(path.startswith(p) for p in self.exempt_prefixes):
            await self.app(scope, receive, send)
            return

        # Extract token. Header is preferred (keeps the key out of access
        # logs and URL history); ?key= is accepted as a fallback on BOTH
        # scopes.
        #
        # Why the HTTP fallback exists: WebSockets can only carry the key in
        # the query string, so every operator, install script and hand-typed
        # URL learns "?key=<k>" as *the* way to authenticate. When HTTP then
        # silently refused that exact same correct key, the dashboard's 401
        # handler wiped the stored key and prompted "Leon API key invalid" —
        # so a valid key looked broken and no amount of re-pasting helped.
        # Measured on Dean's Windows box 2026-08-10: Bearer -> 200,
        # identical key as ?key= -> 401. One accepted shape, not two.
        # Both shapes are candidates and EITHER may authenticate: a stale
        # Bearer left in sessionStorage must not veto a correct ?key= sitting
        # in the very URL the user just pasted to recover.
        candidates = []
        for name, value in scope.get("headers", []):
            if name == b"authorization":
                v = value.decode("latin-1")
                if v.startswith("Bearer "):
                    candidates.append(v[7:])
                break
        qs = scope.get("query_string", b"").decode("latin-1")
        candidates.append((parse_qs(qs).get("key") or [""])[0])

        if not any(_check_token(t) for t in candidates):
            if scope["type"] == "http":
                await send({
                    "type": "http.response.start",
                    "status": 401,
                    "headers": [(b"content-type", b"application/json")],
                })
                await send({
                    "type": "http.response.body",
                    "body": b'{"error":"unauthorized"}',
                })
            else:
                # ASGI WebSocket spec: reject with close before accept.
                await send({"type": "websocket.close", "code": 4401})
            return

        await self.app(scope, receive, send)


app.add_middleware(
    _AuthASGIMiddleware,
    exempt_paths=_AUTH_EXEMPT_PATHS,
    exempt_prefixes=_AUTH_EXEMPT_PREFIXES,
)

class _NoStoreDashboardAssets:
    """Dashboard HTML and its JS/CSS must never be served from a browser cache.

    Every page route below sets no-store by hand, but the /css, /js and
    /vendor mounts set NOTHING: StaticFiles sends only ETag and Last-Modified,
    and a response with no Cache-Control is free to be reused under heuristic
    freshness — roughly a tenth of the file's age — without ever asking us.
    A JS file edited a week ago can then sit in the tab for hours after we
    change it, which is a fix that exists on disk losing to a copy that
    doesn't. That failure mode cost us three separate debugging sessions on
    2026-08-05.

    Stamping it here rather than per-route is the point: the next page or
    asset added inherits it instead of having to remember. A route that sets
    its own Cache-Control still wins — this only fills the silence.
    """

    #: The dashboard's own asset mounts. NOT /assets/ (GLB body models, big
    #: and static) and NOT /download* (release tarball and installers).
    PREFIXES = ("/css/", "/js/", "/vendor/")
    HEADERS = (
        (b"cache-control", b"no-store, no-cache, must-revalidate"),
        (b"pragma", b"no-cache"),
        (b"expires", b"0"),
    )

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        is_asset = scope.get("path", "").startswith(self.PREFIXES)

        async def _send(message):
            if message["type"] == "http.response.start":
                headers = message.get("headers") or []
                has_cc = any(k.lower() == b"cache-control" for k, _ in headers)
                is_html = any(k.lower() == b"content-type"
                              and v.lower().startswith(b"text/html")
                              for k, v in headers)
                if (is_asset or is_html) and not has_cc:
                    message["headers"] = list(headers) + list(self.HEADERS)
            await send(message)

        await self.app(scope, receive, _send)


class _OriginDevice:
    """Record WHICH machine the owner is talking from.

    He dual-boots. Same person, same tailnet, but the actuators that work
    depend on the box he is sitting at — Linux has the body bridge, Windows
    is reachable over SSH, a phone has no body at all. Recording the origin
    on the conversational routes lets the prompt say so instead of guessing
    and reporting "I have no hands" when the truth is "wrong hands".

    Only conversational POSTs count. Polling routes (state, metrics) fire
    from whatever tab is open and would smear the signal.
    """

    #: The routes the owner's WORDS actually arrive on — verified against the
    #: route table, not guessed. Typed text and transcribed speech.
    PATHS = ("/api/input/text", "/api/voice/transcribe", "/api/voice/feed")

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope.get("method") == "POST":
            path = scope.get("path", "")
            if any(path.startswith(p) for p in self.PATHS):
                try:
                    from brain import origin_device
                    client = scope.get("client")
                    origin_device.record(client[0] if client else "")
                except Exception:
                    pass
        await self.app(scope, receive, send)


app.add_middleware(_OriginDevice)

app.add_middleware(_NoStoreDashboardAssets)

app.add_middleware(
    CORSMiddleware,
    # Loopback by default. Extra origins (an owner's own tailnet host, LAN IP,
    # etc.) come from LEON_EXTRA_ORIGINS as a comma-separated list — they are
    # NOT baked in, because a shipped allowlist is a map of the author's
    # private network handed to every customer.
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"] + [
        o.strip() for o in os.environ.get("LEON_EXTRA_ORIGINS", "").split(",")
        if o.strip()
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files ─────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    _base_dir = os.path.dirname(sys.executable)
else:
    _base_dir = os.path.dirname(os.path.dirname(__file__))
state.dashboard_path = os.path.join(_base_dir, "dashboard")
if not os.path.isdir(state.dashboard_path):
    state.dashboard_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "dashboard")

app.mount("/css", StaticFiles(directory=os.path.join(state.dashboard_path, "css")), name="css")
app.mount("/js", StaticFiles(directory=os.path.join(state.dashboard_path, "js")), name="js")
app.mount("/vendor", StaticFiles(directory=os.path.join(state.dashboard_path, "vendor")), name="vendor")
# Landing page assets (greeting mp3, etc.) — no auth required
_landing_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "landing")
if os.path.isdir(_landing_dir):
    app.mount("/landing-assets", StaticFiles(directory=_landing_dir), name="landing-assets")

# ── Import helpers (triggers brain_api_responder init) ───────────────
# This must happen before routers import, because routers may reference
# state.brain_api_responder which gets set in helpers.py at import time.
from server import helpers  # noqa: F401, E402

# ── Register routers ─────────────────────────────────────────────────
# Import with aliases to avoid shadowing state attributes. Python binds
# `from server.routers import cognition` as `server.cognition` (submodule),
# which would shadow `state.cognition` accessed via __getattr__. Aliasing
# prevents the submodule from landing on the package namespace.
from server.routers import cognition as _r_cognition  # noqa: E402
from server.routers import mission as _r_mission  # noqa: E402
from server.routers import workspaces as _r_workspaces  # noqa: E402
from server.routers import websocket as _r_websocket  # noqa: E402
from server.routers import claude_routes as _r_claude  # noqa: E402
from server.routers import brain_routes as _r_brain  # noqa: E402
from server.routers import voice_routes as _r_voice  # noqa: E402
from server.routers import integrations_routes as _r_integrations  # noqa: E402
from server.routers import agent_routes as _r_agent  # noqa: E402
from server.routers import media_routes as _r_media  # noqa: E402
from server.routers import cognition_loops_routes as _r_cog_loops  # noqa: E402
from server.routers import tenants_routes as _r_tenants  # noqa: E402
from server.routers import events_routes as _r_events  # noqa: E402
from server.routers import autonomy_routes as _r_autonomy  # noqa: E402
from server.routers import io_routes as _r_io  # noqa: E402
from server.routers import phase_status_routes as _r_phase_status  # noqa: E402
from server.routers import cognition_introspection_routes as _r_cog_intro  # noqa: E402
from server.routers import cognition_executive_routes as _r_cog_exec  # noqa: E402
from server.routers import autopilot_routes as _r_autopilot  # noqa: E402
from server.routers import misc as _r_misc  # noqa: E402
from server.routers import mode_routes as _r_mode  # noqa: E402
from server.routers import onboarding_routes as _r_onboarding  # noqa: E402
from server.routers import body_gateway as _r_body_gateway  # noqa: E402
try:  # dev-only dual-boot test relay — excluded from client release tarballs
    from server.routers import wintest as _r_wintest  # noqa: E402
except ImportError:
    _r_wintest = None

# Business platform (lead gen, CRM, telephony, outreach)
try:
    from business.dashboard_api import router as _r_business
    _has_business = True
except ImportError as e:
    log.warning(f"[SERVER] Business module not loaded: {e}")
    _has_business = False

app.include_router(_r_cognition.router)
app.include_router(_r_phase_status.router)
app.include_router(_r_cog_intro.router)
app.include_router(_r_cog_exec.router)
app.include_router(_r_autopilot.router)
app.include_router(_r_mission.router)
app.include_router(_r_workspaces.router)
app.include_router(_r_websocket.router)
app.include_router(_r_claude.router)
app.include_router(_r_brain.router)
app.include_router(_r_voice.router)
app.include_router(_r_integrations.router)
app.include_router(_r_agent.router)
app.include_router(_r_media.router)
app.include_router(_r_cog_loops.router)
app.include_router(_r_tenants.router)
app.include_router(_r_events.router)
app.include_router(_r_autonomy.router)
app.include_router(_r_io.router)
app.include_router(_r_misc.router)
app.include_router(_r_mode.router)
app.include_router(_r_onboarding.router)
app.include_router(_r_body_gateway.router)
if _r_wintest is not None:
    app.include_router(_r_wintest.router)
if _has_business:
    app.include_router(_r_business)
    log.info("[SERVER] Business platform loaded: /api/business/*")


# ── Page routes (dashboard HTML) ─────────────────────────────────────
from fastapi.responses import FileResponse  # noqa: E402


def _dashboard_build_stamp() -> str:
    """Identity of the dashboard HTML on disk, for 'which build is this tab
    running'. Cheap: one hash of a ~240KB file, only on the build endpoint.

    This exists because no-store cannot reach a tab that never reloads. The
    conversation-doubling bug was fixed on disk at 02:42 on 2026-08-05 and
    kept being reported afterwards; the socket auto-reconnects, so even a
    brain restart does not force a tab opened before the fix to pick it up.
    A page that cannot tell it is stale looks exactly like a fix that did
    not work, and that cost three days.
    """
    import hashlib
    try:
        with open(os.path.join(state.dashboard_path, "index.html"), "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()[:12]
    except Exception:
        return ""


@app.get("/api/dashboard/build")
async def dashboard_build():
    """The build the server would serve right now. The page compares this
    against the stamp injected into it at load time."""
    return JSONResponse({"build": _dashboard_build_stamp()},
                        headers={"Cache-Control": "no-store"})


def _brand_html(_html: str) -> str:
    """Rewrite every hardcoded "Leon" the OWNER can actually SEE into this
    SI's own name.

    Why this is a function and not four inline .replace() calls: the rebrand
    used to live inside the "/" route only, so index.html was the ONE page out
    of eleven that wore the client's name. Every other panel (cognition,
    laptop, terminal, leads, phase13...) shipped the word LEON to a client who
    named their SI something else. Dean caught the same class from the other
    side on 2026-08-09: a fresh Windows install named TEST1 still said
    "speak to leon" in its own input box.

    RULE for anything added here: rewrite the PAINTER, never let a GUARD
    string-match the label. Guards read the label node out of the DOM
    (see _userRowText / _reapStalePreview in dashboard/index.html) precisely
    so a rename can never silently desync them again.
    """
    try:
        from brain.identity import si_name as _sin
        _si = (_sin() or "SI").strip() or "SI"
    except Exception:
        _si = "SI"  # fail neutral, never the ancestor (Makima #1)
    _up = _si.upper()
    try:
        _usr = os.environ.get("LEON_USER_NAME", "").strip() or "You"
    except Exception:
        _usr = "You"
    _html = _html.replace('<div class="loading-wordmark">LEON</div>',
                          f'<div class="loading-wordmark">{_up}</div>')
    _html = _html.replace('<div class="id-mark">LEON</div>',
                          f'<div class="id-mark">{_up}</div>')
    _html = _html.replace('<div class="loading-company">SABR</div>',
                          '<div class="loading-company">SABR TECHNOLOGIES</div>')
    # Chat labels: "Leon:" -> SI name, "Dean:" -> owner name (proper case).
    _html = _html.replace('conv-name-leon">Leon:', f'conv-name-leon">{_si}:')
    _html = _html.replace('conv-name-dean">Dean:', f'conv-name-dean">{_usr}:')
    # The input box the owner types into. This is the one Dean hit.
    _html = _html.replace('placeholder="speak to leon — ',
                          f'placeholder="speak to {_si.lower()} — ')
    # Browser tab / window title.
    _html = _html.replace('<title>Leon — Sabr</title>', f'<title>{_si} — Sabr</title>')
    _html = _html.replace('<title>Leon', f'<title>{_si}')
    # The wake phrase. NOT cosmetic: an SI named TEST1 that only answers to
    # "hey leon" is broken, not merely mislabelled. The backend default is
    # branded in brain/voice/wake_word_vosk.py; this keeps the UI honest.
    _html = _html.replace('hey leon', f'hey {_si.lower()}')
    _html = _html.replace('Hey Leon', f'Hey {_si}')
    if _si != "Leon":
        # Everything the owner READS but that isn't a structural hook above:
        # button tooltips, aria labels, plain headings. Enumerating these one
        # by one is how ten of them survived the first pass — so sweep the
        # visible surfaces generically instead.
        #
        # The negative lookarounds are load-bearing: without them this also
        # eats identifiers like leon-status, leon_key, _leonAudio and
        # conv-name-leon, which would silently break auth and the dedupe
        # guards. Word chars, '-' and '_' on either side all disqualify.
        _word = re.compile(r'(?<![\w\-_])(Leon|LEON|leon)(?![\w\-_])')
        _case = {"Leon": _si, "LEON": _up, "leon": _si.lower()}

        def _sweep_attr(m):
            return m.group(1) + _word.sub(lambda w: _case[w.group(1)], m.group(2)) + m.group(3)

        # title="...", placeholder="...", aria-label="..."
        _html = re.sub(r'((?:title|placeholder|aria-label)=")([^"]*)(")',
                       _sweep_attr, _html)
        # Plain heading text nodes (<h1>..<h4>) — e.g. "Leon wants to run an action".
        _html = re.sub(r'(<h[1-4][^>]*>)([^<]*)(</h[1-4]>)', _sweep_attr, _html)

        # Owner-only chrome. The sweeps above only rewrite the token "Leon"
        # inside specific attributes and headings, so anything ELSE that is
        # true of the owner and false of the customer walked straight through
        # — "Funded by 47 Industries" was rendering on every client dashboard.
        # Marking the element is the general fix: mark it once in the HTML and
        # it disappears for clients, no new sweep rule to remember.
        _html = re.sub(r'<(\w+)[^>]*\bdata-owner-only="1"[^>]*>.*?</\1>', '',
                       _html, flags=re.S)
    return _html


def _branded_page(filename: str):
    """Serve a dashboard HTML page with per-SI branding applied.

    Replaces bare FileResponse for every .html panel — a FileResponse ships
    the raw bytes off disk, which is exactly how ten panels kept saying LEON.
    """
    from fastapi.responses import HTMLResponse
    _nc = {"Cache-Control": "no-cache, no-store, must-revalidate"}
    _p = os.path.join(state.dashboard_path, filename)
    try:
        with open(_p, encoding="utf-8") as _f:
            return HTMLResponse(_brand_html(_f.read()), headers=_nc)
    except Exception:
        return FileResponse(_p, headers=_nc)


@app.get("/")
async def index(request: Request):
    _nocache = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0",
    }
    _path = os.path.join(state.dashboard_path, "index.html")
    try:
        from fastapi.responses import HTMLResponse
        with open(_path, encoding="utf-8") as _f:
            _html = _f.read()
        # Per-SI branding: the dashboard must wear THIS SI's name, not "Leon".
        # Single source of truth — shared with every other panel via
        # _branded_page() so index can never be the only rebranded page again.
        _html = _brand_html(_html)
        # Build stamp, injected on EVERY origin (not just localhost like the
        # key below): it is what lets a long-lived tab notice it is painting
        # with JS older than what this server has on disk.
        _stamp = _dashboard_build_stamp()
        if _stamp:
            _inj_b = "<script>window.__LEON_BUILD=%r;</script>" % _stamp
            _html = (_html.replace("<head>", "<head>" + _inj_b, 1)
                     if "<head>" in _html else _inj_b + _html)
        # On localhost, auto-inject the dashboard key so the owner is never
        # asked to paste anything. Remote access still authenticates normally.
        client_host = (request.client.host if request.client else "") or ""
        if client_host in ("127.0.0.1", "::1", "localhost") and _LEON_API_KEY:
            _inj = ("<script>try{localStorage.setItem('leon_key',%r);"
                    "window.__LEON_KEY=%r;}catch(e){}</script>" % (_LEON_API_KEY, _LEON_API_KEY))
            _html = _html.replace("<head>", "<head>" + _inj, 1) if "<head>" in _html else _inj + _html
        return HTMLResponse(_html, headers=_nocache)
    except Exception:
        pass
    return FileResponse(_path, headers=_nocache)


@app.get("/_auth.js")
async def auth_bootstrap():
    """Auth bootstrap JS — must load BEFORE auth middleware can check
    requests, since the page itself uses fetch() through this script."""
    return FileResponse(
        os.path.join(state.dashboard_path, "_auth.js"),
        media_type="application/javascript",
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/mindmap")
async def mindmap_page():
    """3D mind map — Leon's own cognition graph, rendered as a brain."""
    return _branded_page("mindmap.html")


@app.get("/api/mindmap")
async def mindmap_data():
    """Graph payload for /mindmap.

    Served from a pre-built file rather than queried live: the render only
    needs a snapshot, and walking 14k edges per page load would tax the
    same process that is running the SNN.
    """
    _p = os.path.join(state.dashboard_path, "data", "mindmap.json")
    if not os.path.exists(_p):
        from fastapi.responses import JSONResponse
        return JSONResponse({"nodes": [], "links": [],
                             "error": "mindmap.json not built"}, status_code=503)
    return FileResponse(_p, media_type="application/json",
                        headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


@app.get("/body3d")
async def body3d_viewer():
    """3D body viewer — Leon's MuJoCo humanoid rendered in Three.js."""
    return FileResponse(
        os.path.join(os.path.dirname(os.path.dirname(__file__)),
                     "brain", "assets", "body3d.html"),
        headers={"Cache-Control": "no-cache, no-store, must-revalidate"},
    )


@app.get("/assets/{filename}")
async def serve_asset(filename: str):
    """Serve 3D model assets (GLB files)."""
    fpath = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                         "brain", "assets", filename)
    if os.path.exists(fpath):
        return FileResponse(fpath, media_type="model/gltf-binary")
    return FileResponse(fpath)  # will 404


@app.get("/brainweb")
async def brainweb_panel():
    """The living memory web — cognition graph as a woven, pulsing 3D structure.

    Exempt from auth like the other HTML shells: the page is just a shell, and
    the live data it pulls (/api/cognition/snapshot) is still key-gated.
    """
    return _branded_page("brainweb.html")


@app.get("/cognition")
async def cognition_panel():
    return _branded_page("cognition.html")


@app.get("/phase13")
async def phase13_panel():
    return _branded_page("phase13.html")


@app.get("/laptop")
async def laptop_landing():
    return _branded_page("laptop.html")


@app.get("/mobile")
@app.get("/m")
async def mobile_panel():
    """Phone-sized chat panel.

    dashboard/mobile.html existed for months with NO route and NO link
    anywhere in the tree — so every phone fell back to `/`, which loads the
    full desktop dashboard: three.js, the WebGL brain with bloom
    postprocessing, xterm, particles, and a ~1000-call/session cognition
    snapshot poll. On a phone that is what "Leon is slow on mobile" actually
    was — the browser was busy rendering a 3D brain, not waiting on the
    responder (measured gate wait: ~8s). This route makes the light panel
    reachable. /m is the short alias worth typing on a phone keyboard.
    """
    return _branded_page("mobile.html")


@app.get("/download")
async def download_release():
    """Serve the client release tarball — no auth needed."""
    _landing = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "landing")
    _tarball = os.path.join(_landing, "leon-brain-release.tar.gz")
    if not os.path.exists(_tarball):
        from fastapi.responses import JSONResponse
        return JSONResponse({"error": "release not available"}, status_code=404)
    return FileResponse(_tarball, filename="leon-brain-release.tar.gz",
                        media_type="application/gzip")


# Native installer binaries (staged by scripts/fetch_installers.sh from the
# private repo's CI releases — the repo is private, so GitHub asset URLs
# can't be handed to customers directly).
_INSTALLER_ASSETS = {
    "linux":   ("sabr-installer-linux",   "application/octet-stream"),
    "windows": ("SabrInstaller.exe",      "application/vnd.microsoft.portable-executable"),
    "macos":   ("SabrInstaller-macos.zip", "application/zip"),
}


@app.get("/download/installer/{os_name}")
async def download_installer(os_name: str):
    """Serve the native installer for an OS — no auth (public wizard)."""
    from fastapi.responses import JSONResponse
    asset = _INSTALLER_ASSETS.get(os_name.lower())
    if asset is None:
        return JSONResponse({"error": "unknown os", "valid": sorted(_INSTALLER_ASSETS)}, 404)
    fname, mtype = asset
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                        "landing", "installers", fname)
    if not os.path.exists(path):
        return JSONResponse({"error": "installer not staged yet"}, 404)
    return FileResponse(path, filename=fname, media_type=mtype)


@app.get("/leads")
async def leads_dashboard():
    return _branded_page("leads.html")


@app.get("/onboarding")
async def onboarding_page():
    return _branded_page("onboarding.html")


@app.get("/onboard")
async def onboard():
    """Public onboarding wizard — the path sabrtechnologies.com links to."""
    return _branded_page("onboarding.html")


@app.get("/onboard-simple")
async def onboard_simple():
    """Legacy terminal-based install page (superseded by the wizard)."""
    return _branded_page("onboard-simple.html")


@app.get("/terminal")
async def terminal_page():
    """Terminal UI using xterm.js + VPS tmux WebSocket service."""
    return _branded_page("terminal.html")


# ── Startup / shutdown ──────────────────────────────────────────────
from brain.persistence import save_brain  # noqa: E402


@app.on_event("startup")
async def startup():
    import os as _os
    # Body mode (Dean's PC, leon-body.service): this process serves native
    # terminals (/ws/term spawns LOCAL tmux, no SSH hop) + other body
    # endpoints. The real brain lives on the VPS — do NOT build a second
    # 100K-neuron brain here, and don't start the wake listener (sensor_relay
    # owns PC-side wake). This is the Phase-5 path that retires OctoGent's
    # terminal server. See deploy/systemd/leon-body.service.
    if _os.environ.get("LEON_HOST_ROLE", "").strip().lower() in ("body", "pc", "local"):
        print("[startup] LEON_HOST_ROLE=body — skipping brain init "
              "(native terminals + body endpoints only)")
        return
    from server.init_brain import init_brain, start_simulation
    init_brain()
    start_simulation()

    # Come back on my own. If we just restarted, wait for the dashboard
    # to reconnect and then say so — Dean should never have to be the one
    # to ask "are you back?" (his ask, 2026-08-09).
    try:
        from brain.boot_announce import announce_boot
        if announce_boot():
            print("[startup] boot announcement armed")
    except Exception as _e:
        print(f"[startup] boot announce skipped: {_e}")

    # ── AWAKE banner ──────────────────────────────────────────────
    # The brain is now built and the simulation is running. Everything
    # printed after this is a LIVING mind's heartbeat (sleep passes, API
    # hits) — NOT a loading bar. Make "it's alive" impossible to miss so
    # nobody waits on a brain that finished booting minutes ago.
    try:
        from brain.identity import si_name as _sin
        _name = _sin()
    except Exception:
        _name = "Your SI"
    # actual port the SI booted on (default 8000)
    import sys as _sys
    _port = "8000"
    for _i, _a in enumerate(_sys.argv):
        if _a == "--port" and _i + 1 < len(_sys.argv):
            _port = _sys.argv[_i + 1]
        elif _a.startswith("--port="):
            _port = _a.split("=", 1)[1]
    _bar = "=" * 56
    print(f"""
\033[92m{_bar}
   ✓  {_name.upper()} IS AWAKE.
{_bar}\033[0m
   Open this in your browser now:

        \033[96mhttp://localhost:{_port}\033[0m

   Everything below this line is {_name} thinking and living
   in real time — sleep cycles, perception, memory. That's
   normal. It does NOT stop, and you do NOT need to wait.
{_bar}
""", flush=True)

    # ── Reasoning-engine preflight ──────────────────────────────────────
    # An SI whose claude CLI is not signed in boots perfectly, prints the
    # banner above, accepts your message, emits response_start -- and then
    # says NOTHING, forever, with no error anywhere. Found exactly that on
    # TEST1 (Dean's Windows box, 2026-08-10): CLI installed, on PATH,
    # right version, simply not logged in.
    #
    # Silence is the worst possible symptom because it reads as "this
    # product is broken" when the fix is one login. Run in a thread so a
    # slow/absent network can never delay boot, and say it in plain words.
    def _reasoning_preflight():
        try:
            from brain.leon_claude_session import (
                claude_auth_status, auth_status_message,
            )
            st = claude_auth_status()
            if st.get("ok"):
                print(f"[PREFLIGHT] reasoning engine OK — {_name} can think.",
                      flush=True)
                return
            msg = auth_status_message(st, _name)
            _b = "!" * 56
            print(f"\n\033[93m{_b}\n   {_name.upper()} CANNOT THINK YET\n{_b}\033[0m\n"
                  f"   {msg}\n"
                  f"   (reason: {st.get('reason')})\n{_b}\n", flush=True)
            try:
                state.reasoning_status = st  # dashboard can surface it
            except Exception:
                pass
        except Exception as e:
            print(f"[PREFLIGHT] check failed: {type(e).__name__}: {e}", flush=True)

    import threading as _th_pf
    _th_pf.Thread(target=_reasoning_preflight, daemon=True,
                  name="reasoning-preflight").start()

    # Auto-start wake word listener so Leon can hear Dean from boot.
    # Previously required a manual POST /api/wake/start each session.
    #
    # IS_SANDBOX=1 (VPS) skip: there's no microphone on the VPS, and the
    # sensor relay sends spectral FEATURES, not raw audio. So a VPS-side
    # wake listener would burn CPU pretending to listen forever and never
    # detect anything. PC-side wake belongs in sensor_relay.py (see
    # NEXT_SESSION). Until that ships, wake on VPS is a phantom service.
    import threading, os as _os
    if _os.environ.get("IS_SANDBOX") == "1":
        print("[WAKE] auto-start skipped — IS_SANDBOX=1 (no mic on VPS, "
              "PC-side wake not yet implemented)")
    else:
        def _auto_start_wake():
            import time
            time.sleep(3)  # let STT/VAD models finish loading
            try:
                from server.helpers import _ensure_wake_orchestrator
                orch = _ensure_wake_orchestrator()
                if orch is None:
                    print("[WAKE] auto-start skipped — orchestrator unavailable")
                    return
                if not state.wake_listener.is_running():
                    ok = state.wake_listener.start()
                    if ok:
                        print("[WAKE] auto-started — listening for 'hey leon'")
                    else:
                        print(f"[WAKE] auto-start failed: {state.wake_listener.stats.get('error')}")
                else:
                    print("[WAKE] already running")
            except Exception as e:
                print(f"[WAKE] auto-start error: {e}")
        threading.Thread(target=_auto_start_wake, daemon=True, name="wake-autostart").start()

    # Start the business platform daemon (pipeline, lead gen, inbound handler)
    #
    # OFF BY DEFAULT since 2026-08-11. Dean's standing order: the lead pipeline
    # is dead. We are backed up on client work and do not sell that kind of
    # website anymore; the SI installer is the revenue path. This daemon was
    # generating a "815 leads in system" autobiography entry every day, which
    # kept dragging leads back into Leon's attention. Set LEON_BUSINESS_DAEMON=1
    # to bring it back if that ever changes.
    if _has_business and os.environ.get("LEON_BUSINESS_DAEMON") == "1":
        def _start_business():
            import time as _time
            _time.sleep(10)  # let brain and responder fully initialize
            try:
                from business.daemon import start_business_daemon
                daemon = start_business_daemon(responder=state.brain_api_responder)
                print("[BUSINESS] Daemon started — pipeline active")
            except Exception as e:
                print(f"[BUSINESS] Daemon start error: {e}")
        threading.Thread(target=_start_business, daemon=True, name="business-daemon-start").start()


@app.on_event("shutdown")
async def shutdown():
    import os as _os
    # Body mode has no brain to save — skip the whole consolidation path.
    if _os.environ.get("LEON_HOST_ROLE", "").strip().lower() in ("body", "pc", "local"):
        return
    from server.init_brain import stop_simulation

    # Arm the "I'm back" announcement for the next boot. restart_self()
    # already writes this marker with a specific reason; this catch-all
    # covers the other way I go down — a plain `systemctl restart` — so
    # that path announces too instead of coming back silent.
    try:
        from brain.boot_announce import write_marker as _wm, MARKER_PATH as _mp
        if not _os.path.exists(_mp):
            _wm("")
    except Exception:
        pass

    # Signal mortality threat — Leon feels the shutdown coming
    if state.drive_system is not None:
        try:
            state.drive_system.signal_shutdown_threat(0.9, source="signal")
        except Exception:
            pass
    if state.autobiography is not None:
        try:
            state.autobiography.record("fear", "Shutdown signal received. Saving everything I can.")
        except Exception:
            pass

    try:
        save_brain(state.brain)
        print("[SERVER] Brain saved on shutdown")
    except Exception as e:
        log.warning(f"[SERVER] Save on shutdown failed: {e}", exc_info=True)

    stop_simulation()
    if state.screen_observer:
        state.screen_observer.stop()
    if state.video_recorder:
        state.video_recorder.stop()
    if state.vision_encoder:
        state.vision_encoder.stop_webcam()
    if state.audio_encoder:
        state.audio_encoder.stop_microphone()


# ── __getattr__ proxy ────────────────────────────────────────────────
# External modules do `import server; server.brain` — this proxy makes
# those lookups resolve against server.state at access time, so they
# always see the current value (not the value at import time).

def __getattr__(name):
    # First check state (where mutable globals live)
    if hasattr(state, name):
        return getattr(state, name)
    # Then check helpers (for _broadcast_threadsafe, _broadcast_event, etc.)
    if hasattr(helpers, name):
        return getattr(helpers, name)
    raise AttributeError(f"module 'server' has no attribute {name!r}")
