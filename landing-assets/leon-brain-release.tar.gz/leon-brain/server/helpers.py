"""
Helper / factory functions for the Leon server.

Extracted from the monolithic server.py. All functions access shared
state via `from server import state`.
"""

import asyncio
import base64
import json
import logging
import os
import secrets
import threading
import time
from typing import Any, Dict, Optional

from server import state
from brain.timefmt import fmt as _timefmt

log = logging.getLogger("leon.server")


# ── API responder init (runs at import time) ─────────────────────────

try:
    from brain.claude_api_responder import BrainAPIResponder
    state.brain_api_responder = BrainAPIResponder()
    print(f"[BRAIN] Streaming API responder ready — model={state.brain_api_responder.model}")
except Exception as e:
    log.warning(f"[BRAIN] API responder unavailable, using subprocess fallback: {e}", exc_info=True)


# ── Confirm callback ─────────────────────────────────────────────────

def _resolve_confirm(tool_id: str, approved: bool) -> bool:
    with state._pending_confirms_lock:
        entry = state._pending_confirms.get(tool_id)
        if not entry:
            return False
        entry["approved"] = approved
        entry["event"].set()
        return True


def _make_confirm_callback(send_func):
    def _confirm(tool_name: str, tool_input: Dict[str, Any], risk: str) -> bool:
        tool_id = f"cfm{int(time.time()*1000)}{secrets.token_hex(3)}"
        ev = threading.Event()
        with state._pending_confirms_lock:
            state._pending_confirms[tool_id] = {"event": ev, "approved": False, "ts": time.time()}
        try:
            send_func({
                "type": "brain_tool_confirm_request",
                "confirm_id": tool_id,
                "tool": tool_name,
                "input": json.dumps(tool_input, default=str),
                "risk": risk,
            })
            ev.wait(timeout=30.0)
            with state._pending_confirms_lock:
                entry = state._pending_confirms.pop(tool_id, None)
            return bool(entry and entry.get("approved"))
        except Exception as e:
            with state._pending_confirms_lock:
                state._pending_confirms.pop(tool_id, None)
            log.warning(f"[CONFIRM] error: {e}", exc_info=True)
            return False
    return _confirm


def _make_broadcast_confirm_callback():
    def _confirm(tool_name: str, tool_input: Dict[str, Any], risk: str) -> bool:
        tool_id = f"cfm{int(time.time()*1000)}{secrets.token_hex(3)}"
        ev = threading.Event()
        with state._pending_confirms_lock:
            state._pending_confirms[tool_id] = {"event": ev, "approved": False, "ts": time.time()}
        try:
            _broadcast_threadsafe({
                "type": "brain_tool_confirm_request",
                "confirm_id": tool_id,
                "tool": tool_name,
                "input": json.dumps(tool_input, default=str),
                "risk": risk,
            })
            ev.wait(timeout=30.0)
            with state._pending_confirms_lock:
                entry = state._pending_confirms.pop(tool_id, None)
            return bool(entry and entry.get("approved"))
        except Exception as e:
            with state._pending_confirms_lock:
                state._pending_confirms.pop(tool_id, None)
            log.warning(f"[CONFIRM] error: {e}", exc_info=True)
            return False
    return _confirm


# ── Webcam helpers ───────────────────────────────────────────────────

def _resolve_webcam(req_id: str, payload: Dict[str, Any]) -> bool:
    with state._pending_webcam_lock:
        entry = state._pending_webcam.get(req_id)
        if not entry or entry.get("resolved"):
            return False
        entry["resolved"] = True
        entry["payload"] = payload
        entry["event"].set()
        return True


def _any_webcam_client_ready() -> bool:
    with state._webcam_clients_lock:
        return any(v for v in state._webcam_clients.values())


def _get_cached_webcam_frame(max_age: float = 10.0) -> Optional[Dict[str, Any]]:
    if not state._webcam_frame_cache.get("image_b64"):
        return None
    if time.time() - state._webcam_frame_ts > max_age:
        return None
    return state._webcam_frame_cache


# ── Broadcast ────────────────────────────────────────────────────────

async def _broadcast(msg: dict):
    dead = set()
    for client in list(state.connected_clients):
        try:
            await client.send_json(msg)
        except Exception:
            dead.add(client)
    state.connected_clients.difference_update(dead)


def _broadcast_threadsafe(msg: dict) -> None:
    loop = state._main_event_loop
    if loop is None or loop.is_closed():
        return
    try:
        asyncio.run_coroutine_threadsafe(_broadcast(msg), loop)
    except Exception as e:
        print(f"[WAKE-NOTIFY] broadcast failed: {e}")


async def _broadcast_audio_one(msg: dict):
    """Send an AUDIO frame to a SINGLE live client, not all of them.

    Broadcasting Leon's TTS to every open dashboard tab makes his voice
    double/echo (each tab plays it, slightly offset). Since every tab plays to
    the same speakers, ONE live recipient = one clean playback regardless of how
    many tabs are open — server-authoritative, reload-free. (Bulletproof
    double-voice fix, 2026-06-19.)"""
    dead = set()
    for client in list(state.connected_clients):
        try:
            await client.send_json(msg)
            break  # delivered to one — stop so it doesn't double
        except Exception:
            dead.add(client)
    if dead:
        state.connected_clients.difference_update(dead)


def _broadcast_audio_threadsafe(msg: dict) -> None:
    loop = state._main_event_loop
    if loop is None or loop.is_closed():
        return
    try:
        asyncio.run_coroutine_threadsafe(_broadcast_audio_one(msg), loop)
    except Exception as e:
        print(f"[AUDIO] single-send failed: {e}")


# Alias for presence module
_broadcast_event = _broadcast_threadsafe


def broadcast_activity(category: str, text: str, ttl_ms: int = 10000,
                       agent: str = "", detail: str = "", persist: bool = True) -> None:
    """Broadcast an activity status update to the dashboard Actions panel.

    Categories: 'perception', 'reading', 'thinking', 'goal', 'tool', 'inner',
                'agent'
    TTL: how long the line stays visible (ms). 0 = permanent until replaced.
    Also persists to disk for the activity log panel.

    agent/detail (2026-08-02, Dean's design): sub-agent work rides the SAME
    log rather than getting its own window. `agent` is the name Dean gave it,
    rendered as a clickable chip; `detail` is the long text — the full prompt,
    the full result — that expands in place when he clicks the name. One
    stream, one place to look, no second panel to build or maintain.
    """
    entry = {
        "category": category,
        "text": text,
        "ttl_ms": ttl_ms,
    }
    if agent:
        entry["agent"] = agent
        entry["category"] = category or "agent"
    if detail:
        entry["detail"] = detail
    _broadcast_threadsafe({
        "type": "activity_status",
        "activity": entry,
    })
    # Persist to activity log (fire-and-forget, only when persist=True)
    if persist:
        try:
            _persist_activity(entry)
        except Exception:
            pass


# ── Activity log persistence ──────────────────────────────────────────

import datetime as _dt
from pathlib import Path as _Path

_ACTIVITY_LOG_DIR = _Path(__file__).resolve().parent.parent / "brain_state"
_ACTIVITY_LOG_FILE = _ACTIVITY_LOG_DIR / "activity_log.jsonl"
_ACTIVITY_LOG_LOCK = threading.Lock()
_ACTIVITY_MAX_LINES = 2000  # ring-buffer on disk (global ceiling)
# Per-category ring buffer. Without this, whichever category is noisiest on a
# given machine (inner thoughts, perception events...) floods the file and
# buries every other category forever. Each kind now ages out on its own.
_ACTIVITY_CATEGORY_MAX = 400
_ACTIVITY_CATEGORY_LIMITS = {
    # noisy, low-value-per-line categories get a tighter budget
    "thought": 300,
    "perception": 200,
    "sensor": 200,
}


def _trim_activity_lines(lines: list) -> list:
    """Apply per-category caps then the global cap, preserving order.

    Unparseable lines are treated as their own category so a corrupt line can
    never take the whole log down with it.
    """
    keep_idx = set()
    seen: dict = {}
    # walk newest -> oldest, keeping up to N per category
    for i in range(len(lines) - 1, -1, -1):
        raw = lines[i].strip()
        if not raw:
            continue
        try:
            cat = json.loads(raw).get("category") or "_uncat"
        except Exception:
            cat = "_bad"
        limit = _ACTIVITY_CATEGORY_LIMITS.get(cat, _ACTIVITY_CATEGORY_MAX)
        n = seen.get(cat, 0)
        if n < limit:
            seen[cat] = n + 1
            keep_idx.add(i)
    kept = [lines[i] for i in sorted(keep_idx)]
    if len(kept) > _ACTIVITY_MAX_LINES:
        kept = kept[-_ACTIVITY_MAX_LINES:]
    return kept


_PERSIST_DEDUP: dict = {}
_PERSIST_DEDUP_LOCK = threading.Lock()
_PERSIST_DEDUP_TTL = 60.0

def _persist_activity(entry: dict) -> None:
    """Append one activity entry to the JSONL log file.

    Deduplication: identical (category, text) within 60s is skipped unless
    the entry carries agent detail (sub-agent lines are always unique).
    """
    # Dedup check (the partner SI patch)
    if not entry.get("agent") and not entry.get("detail"):
        _key = (entry.get("category", ""), entry.get("text", ""))
        _now = time.time()
        with _PERSIST_DEDUP_LOCK:
            _last = _PERSIST_DEDUP.get(_key, 0.0)
            if _now - _last < _PERSIST_DEDUP_TTL:
                return
            _PERSIST_DEDUP[_key] = _now
    _ACTIVITY_LOG_DIR.mkdir(parents=True, exist_ok=True)
    record = {
        "ts": _dt.datetime.utcnow().isoformat() + "Z",
        "category": entry.get("category", ""),
        "text": entry.get("text", ""),
    }
    if entry.get("agent"):
        record["agent"] = entry["agent"]
    if entry.get("detail"):
        # Cap it: a runaway agent dumping a megabyte of output must not turn
        # the log file into the thing that fills the disk.
        record["detail"] = str(entry["detail"])[:8000]
    with _ACTIVITY_LOG_LOCK:
        with open(_ACTIVITY_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
        # Trim if too large (keep last _ACTIVITY_MAX_LINES)
        try:
            lines = _ACTIVITY_LOG_FILE.read_text(encoding="utf-8").splitlines()
            if len(lines) > _ACTIVITY_MAX_LINES + 200:
                kept = _trim_activity_lines(lines)
                if kept:
                    _ACTIVITY_LOG_FILE.write_text(
                        "\n".join(kept) + "\n", encoding="utf-8",
                    )
        except Exception:
            pass


def get_activity_history(limit: int = 500) -> list:
    """Return the last `limit` activity log entries."""
    try:
        lines = _ACTIVITY_LOG_FILE.read_text(encoding="utf-8").splitlines()
        entries = []
        for line in lines[-limit:]:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
        return entries
    except FileNotFoundError:
        return []
    except Exception:
        return []


# ── Unified response broadcast gate ──────────────────────────────────
# ALL systems that want to show Leon "talking" (brain_response_start/delta/end)
# MUST call broadcast_response() instead of _broadcast_threadsafe() directly.
# This prevents double responses by enforcing a minimum gap between broadcasts
# AND checking if Dean spoke recently (conversation cooldown).
#
# Systems that use this: proactive, dreaming outreach, consciousness module,
# alive.py briefings, fixer.py, upgrade_awareness, spontaneous thoughts.

_RESPONSE_BROADCAST_LOCK = threading.Lock()
_last_response_broadcast_ts: float = 0.0
_RESPONSE_MIN_GAP_S: float = 10.0  # minimum seconds between unsolicited broadcasts
_RESPONSE_CONVERSATION_COOLDOWN_S: float = 300.0  # suppress if Dean spoke within this


def broadcast_response(text: str, *, source: str = "proactive",
                       user_label: str = "(self-initiated)",
                       audio: bool = True, force: bool = False) -> bool:
    """Unified gate for all unsolicited Leon speech broadcasts.

    Returns True if the message was broadcast, False if suppressed.
    All systems that want Leon to "speak unprompted" should use this
    instead of directly broadcasting brain_response_start/delta/end.

    force=True bypasses the timing/conversation-cooldown gates (1 & 2).
    Use it ONLY for speech that is a direct consequence of a user action
    the user is watching happen — e.g. they just saved an API key and
    expect Leon to react right then. The conscious gate (3) still holds.
    """
    global _last_response_broadcast_ts
    now = time.time()

    with _RESPONSE_BROADCAST_LOCK:
        # Gate 1: Don't broadcast if another unsolicited message was recent
        if not force and now - _last_response_broadcast_ts < _RESPONSE_MIN_GAP_S:
            return False

        # Gate 2: Don't broadcast if Dean spoke recently (conversation active)
        meter = None
        try:
            brain = getattr(state, "brain", None)
            meter = getattr(brain, "consciousness_meter", None) if brain else None
            if not force and meter is not None:
                since_user = now - meter._last_user_message_ts
                if since_user < _RESPONSE_CONVERSATION_COOLDOWN_S:
                    return False
        except Exception:
            pass

        # Gate 3: Must be conscious
        try:
            if meter is not None and not meter.is_conscious:
                return False
        except Exception:
            pass

        _last_response_broadcast_ts = now

    # Passed all gates — broadcast the response
    response_id = f"{source}{int(now * 1000)}"
    _broadcast_threadsafe({
        "type": "brain_response_start",
        "user": user_label,
        "response_id": response_id,
        "from_proactive": True,
        "source": source,
    })
    _broadcast_threadsafe({
        "type": "brain_response_delta",
        "response_id": response_id,
        "text": text,
    })

    # TTS if requested
    if audio:
        try:
            audio_data = _tts_synthesize_b64(text)
            if audio_data:
                # All screens, not a single sink — voice on both devices.
                _broadcast_threadsafe({
                    "type": "brain_audio",
                    "response_id": response_id,
                    "sentence_index": 0,
                    **audio_data,
                })
        except Exception:
            pass

    _broadcast_threadsafe({
        "type": "brain_response_end",
        "response_id": response_id,
        "response": text,
    })
    return True


# ── TTS ──────────────────────────────────────────────────────────────

def _ensure_tts():
    with state._tts_lock:
        if state._tts_instance == "unavailable":
            return None
        if state._tts_instance is not None:
            return state._tts_instance
        prefer = os.environ.get("LEON_TTS_PREFER", "").lower()
        # Kokoro-82M — local neural voice, free, no key, no quota. When
        # explicitly preferred it wins outright: this is the ONE path the
        # server actually speaks through, and wiring Kokoro only into
        # brain/voice/tts.py's LeonTTS order did nothing here (2026-07-29).
        if prefer == "kokoro":
            try:
                from brain.voice.tts import _KokoroTTS
                state._tts_instance = _KokoroTTS()
                print(f"[TTS] Kokoro ready — voice={state._tts_instance.voice}")
                return state._tts_instance
            except Exception as e:
                log.warning(f"[TTS] Kokoro init failed ({e}), falling through")
        # Use ElevenLabs whenever a key is present — don't require the
        # prefer flag to be set, otherwise a client who pasted a key but
        # whose installer never wrote LEON_TTS_PREFER gets silence. Only
        # an explicit prefer=piper/pyttsx3 opts out of the cloud voice.
        if os.environ.get("ELEVENLABS_API_KEY") and prefer not in ("piper", "pyttsx3", "system"):
            _quota_ok = True
            try:
                import urllib.request as _ur
                _req = _ur.Request("https://api.elevenlabs.io/v1/user/subscription",
                                    headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"]})
                with _ur.urlopen(_req, timeout=5) as _resp:
                    _sub = __import__("json").loads(_resp.read())
                    _used = _sub.get("character_count", 0)
                    _limit = _sub.get("character_limit", 1)
                    if _used >= _limit * 0.99:
                        _quota_ok = False
                        print(f"[TTS] ElevenLabs quota exhausted ({_used}/{_limit}) — using Piper")
                    else:
                        print(f"[TTS] ElevenLabs quota: {_limit-_used} chars left")
            except Exception as e:
                # Restricted API keys (scoped to TTS only, no user_read)
                # 401 on the subscription endpoint — that does NOT mean
                # TTS is dead. Dean's 2026-06-11 key is exactly this kind;
                # the old code fell back to Piper here and his voice
                # upgrade silently never happened. Proceed optimistically —
                # _tts_synthesize_b64 swaps to Piper at runtime if actual
                # synthesis fails.
                print(f"[TTS] ElevenLabs quota check unavailable ({e}) — "
                      f"proceeding optimistically")
            if _quota_ok:
                try:
                    from brain.voice.tts import _ElevenLabsTTS
                    state._tts_instance = _ElevenLabsTTS(os.environ.get("ELEVENLABS_VOICE_ID"))
                    print(f"[TTS] ElevenLabs ready — voice={state._tts_instance.voice_id}")
                    return state._tts_instance
                except Exception as e:
                    log.warning(f"[TTS] ElevenLabs init failed ({e}), falling back to Piper")
        if not os.path.exists(state._TTS_MODEL_PATH):
            # Missing model is not the same as "no real voice available":
            # fetch it the way the wake word already fetches its Vosk model.
            # Bounded, opt-outable (LEON_TTS_NO_DOWNLOAD=1), and if it fails
            # we fall through to the system voice exactly as before.
            try:
                from brain.voice.tts import _ensure_piper_model
                _ensure_piper_model(state._TTS_MODEL_PATH)
            except Exception as e:
                print(f"[TTS] Piper voice download errored ({e}) — "
                      f"falling back to the system voice")
        if not os.path.exists(state._TTS_MODEL_PATH):
            # No ElevenLabs and no Piper model — fall back to the free
            # system voice (pyttsx3: NSSpeech on macOS, espeak on Linux,
            # SAPI on Windows) so the SI ALWAYS has a voice. Silence is
            # never an acceptable default.
            try:
                from brain.voice.tts import _Pyttsx3TTS
                state._tts_instance = _Pyttsx3TTS()
                print("[TTS] System voice (pyttsx3) ready — free fallback, no ElevenLabs/Piper")
                return state._tts_instance
            except Exception as e:
                state._tts_instance = "unavailable"
                print(f"[TTS] Piper model missing and system voice unavailable ({e}) — voice disabled")
                return None
        try:
            from brain.voice.tts import _PiperTTS
            state._tts_instance = _PiperTTS(state._TTS_MODEL_PATH)
            print(f"[TTS] Piper ready — voice=en_GB-alan-medium")
        except Exception as e:
            # Last-ditch: system voice before giving up to silence.
            try:
                from brain.voice.tts import _Pyttsx3TTS
                state._tts_instance = _Pyttsx3TTS()
                print(f"[TTS] System voice (pyttsx3) ready — Piper init failed ({e})")
            except Exception:
                state._tts_instance = "unavailable"
                log.warning(f"[TTS] Piper init failed: {e}", exc_info=True)
                return None
    return state._tts_instance


def _strip_markdown_for_speech(text: str) -> str:
    """Remove markdown formatting so TTS reads clean English."""
    import re
    t = text
    t = re.sub(r'\*\*(.+?)\*\*', r'\1', t)   # **bold**
    t = re.sub(r'\*(.+?)\*', r'\1', t)         # *italic*
    t = re.sub(r'__(.+?)__', r'\1', t)         # __bold__
    t = re.sub(r'_(.+?)_', r'\1', t)           # _italic_
    t = re.sub(r'`([^`]+)`', r'\1', t)         # `code`
    t = re.sub(r'```[\s\S]*?```', '', t)        # ```code blocks```
    t = re.sub(r'^#{1,6}\s+', '', t, flags=re.MULTILINE)  # # headers
    t = re.sub(r'^\s*[-*+]\s+', '', t, flags=re.MULTILINE)  # bullet points
    t = re.sub(r'^\s*\d+\.\s+', '', t, flags=re.MULTILINE)  # numbered lists
    # Domains read naturally: "shopspark8.com" → "shopspark8 dot com"
    t = re.sub(r'\b([a-zA-Z0-9-]+)\.(com|net|org|io|ai|dev|app)\b',
               r'\1 dot \2', t)
    return t.strip()


# ── Pronunciation map ─────────────────────────────────────────────────
# Dean's 2026-06-11 complaint: Leon mispronounces names ("Gio", "Sabr",
# acronyms). Word-boundary replacements applied to speech text right
# before synthesis. Leon-editable at runtime: brain_state/
# pronunciations.json (he has file_write); falls back to the repo seed
# at brain/voice/pronunciations_default.json. Mtime-cached.
_pron_cache = {"path": None, "mtime": 0.0, "rules": []}


def _apply_pronunciations(text: str) -> str:
    import re
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    live = os.path.join(root, "brain_state", "pronunciations.json")
    seed = os.path.join(root, "brain", "voice", "pronunciations_default.json")
    path = live if os.path.exists(live) else seed
    try:
        mtime = os.path.getmtime(path)
        if _pron_cache["path"] != path or mtime > _pron_cache["mtime"]:
            with open(path) as f:
                mapping = json.loads(f.read())
            rules = []
            for word, spoken in mapping.items():
                if not word.startswith("_"):  # keys like _comment
                    rules.append((re.compile(rf"\b{re.escape(word)}\b",
                                             re.IGNORECASE), spoken))
            _pron_cache.update(path=path, mtime=mtime, rules=rules)
    except Exception:
        return text
    for rx, spoken in _pron_cache["rules"]:
        text = rx.sub(spoken, text)
    return text


# ── Voice FX ──────────────────────────────────────────────────────────
# Dean (2026-06-11): Leon should "sound more like a robot". The ElevenLabs
# voice is a natural human clone, so the robot character is applied as an
# ffmpeg post-process on the synthesized audio. LEON_VOICE_FX env:
#   off    — raw voice
#   subtle — metallic flanger + tight echo (AI-in-the-room, still warm)
#   robot  — phase-zeroed vocoder (full classic robot)
_VOICE_FX_CHAINS = {
    "subtle": ("flanger=delay=2:depth=1.2:regen=12:width=50:speed=0.6,"
               "aecho=0.85:0.5:5:0.18,highpass=f=90,treble=g=2"),
    "robot": ("afftfilt=real='hypot(re,im)*cos(0)':imag='hypot(re,im)*sin(0)':"
              "win_size=512:overlap=0.75,aecho=0.8:0.5:4:0.2,highpass=f=100"),
}


def _apply_voice_fx(wav_bytes: bytes, sample_rate: int) -> bytes:
    mode = os.environ.get("LEON_VOICE_FX", "off").strip().lower()
    chain = _VOICE_FX_CHAINS.get(mode)
    if not chain:
        return wav_bytes
    try:
        import subprocess
        proc = subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error",
             "-i", "pipe:0", "-af", chain,
             "-ar", str(sample_rate), "-ac", "1",
             "-f", "wav", "-acodec", "pcm_s16le", "pipe:1"],
            input=wav_bytes, capture_output=True, timeout=20,
        )
        if proc.returncode == 0 and len(proc.stdout) > 100:
            return proc.stdout
    except Exception:
        pass
    return wav_bytes  # never block speech on an effect failure


def _tts_synthesize_b64(text: str):
    tts = _ensure_tts()
    if tts is None or not text:
        return None
    # ── FLOOR LOCK — Dean holds the mic, Leon is muted, period. ────────
    # This is the single narrowest waist for "audio about to exist". Every
    # spoken line on the PC is synthesized here, so blocking here defers
    # the line instead of dropping it — it plays the moment he lets go.
    try:
        from brain import audio_daemon as _ad
        _ad.await_floor()
    except Exception:
        pass
    try:
        text = _strip_markdown_for_speech(text)
        text = _apply_pronunciations(text)
        if not text:
            return None
        result = tts.speak(text)
        _fx = _apply_voice_fx(result.wav_bytes, result.sample_rate)
        if _fx is not result.wav_bytes:
            result.wav_bytes = _fx
            # echo tails stretch the clip slightly — recompute for the
            # mic-pause window so Leon doesn't hear his own reverb
            result.duration_sec = max(0.0, (len(_fx) - 44) / 2 / result.sample_rate)
        # ── Publish the speaker-active interval (single owner) ────────
        # This is the ONE place that says "Leon's voice is coming out of
        # the speakers from T to T+duration". brain.voice.audio_gate owns
        # the ledger; every mic path gates its own captured chunks
        # against it by CAPTURE timestamp. Nothing polls this.
        #
        # The duration is the synthesized clip's exact length, so the
        # interval is published closed in one write rather than needing a
        # timer. The dashboard starts playback a few ms after it receives
        # this payload — that skew is exactly what PRE_GUARD/POST_GUARD
        # in audio_gate are for.
        _marker_duration = result.duration_sec
        try:
            from brain.voice import audio_gate as _agate
            _agate.publish_playback(result.duration_sec, text=text,
                                    source="tts")
            # The PC marker must cover until the SPEAKERS go quiet, not
            # until this one clip's length elapses. Synthesis runs far
            # ahead of the serial player, so a 4s marker on sentence ten
            # of a forty-second reply lifted the mic gate half a minute
            # early — that gap is where Leon heard himself and answered
            # himself. Ask the ledger where the queue actually ends.
            try:
                _queue_end = _agate.LEDGER.queued_playback_end()
                _marker_duration = max(result.duration_sec,
                                       _queue_end - time.time())
            except Exception:
                pass
        except Exception:
            # Fall back to the shim so a gate import failure can never
            # leave Leon un-suppressed.
            try:
                from brain import audio_daemon
                audio_daemon.pause_for(result.duration_sec)
            except Exception:
                pass
        # Also pause the PC-side ambient wake loop (sensor_relay) by
        # touching /tmp/leon-tts-active on the PC via the actuator.
        # CRITICAL: set the marker SYNCHRONOUSLY before returning audio
        # data — otherwise the dashboard WebSocket receives and plays the
        # audio through the speakers before the marker exists, and the
        # sensor_relay wake listener hears Leon's own voice.
        try:
            from brain.actuator_client import call as _actuator_call
            import threading as _th
            _wav_b64 = base64.b64encode(result.wav_bytes).decode("ascii")
            _pc_play = os.environ.get("LEON_TTS_PC_PLAYBACK", "1") != "0"
            # Set marker FIRST, synchronously (short timeout — just a file touch)
            try:
                _mk = _actuator_call(
                    "tts.marker_set",
                    {"duration_s": _marker_duration, "cooldown_s": 1.0},
                    timeout=2.0)
                # NEVER go back to `except: pass` here. The actuator answered
                # "unknown tool: tts.marker_set" on every reply for months and
                # this call discarded the answer, so the one thing standing
                # between the SI and hearing its own voice failed completely
                # silently. A returned ok=False is a real failure and has to
                # be as loud as an exception.
                if isinstance(_mk, dict) and not _mk.get("ok", False):
                    print("[TTS] mic gate NOT armed — tts.marker_set failed: "
                          f"{_mk.get('error')!r}. The SI can hear itself.",
                          flush=True)
            except Exception as _e:
                print(f"[TTS] mic gate NOT armed — tts.marker_set raised: "
                      f"{type(_e).__name__}: {_e}. The SI can hear itself.",
                      flush=True)
            # PC-speaker playback disabled — the browser dashboard plays the
            # audio already (after receiving the b64 payload). Playing it again
            # here via the actuator causes double-audio (same clip plays twice,
            # offset). The marker_set above gated the mic; that's enough.
            # (Disabled 2026-07-06 to fix audio duplication on Windows.)
            # if _pc_play:
            #     def _play_audio(wav_b64):
            #         try:
            #             _actuator_call("audio.play",
            #                            {"audio_b64": wav_b64, "format": "wav"},
            #                            timeout=10.0)
            #         except Exception:
            #             pass
            #     _th.Thread(target=_play_audio,
            #                args=(_wav_b64,),
            #                daemon=True,
            #                name="tts-pc-play").start()
        except Exception:
            pass
        return {
            "audio_b64": base64.b64encode(result.wav_bytes).decode("ascii"),
            "sample_rate": result.sample_rate,
            "duration_sec": round(result.duration_sec, 3),
            "backend": result.backend,
        }
    except Exception as e:
        log.warning(f"[TTS] synthesis failed: {e}", exc_info=True)
        # Transient ElevenLabs errors (500, timeout, rate limit) should
        # fall back to Piper for THIS sentence only, not permanently
        # replace the TTS instance. The old code did a permanent swap
        # which made Leon lose his voice mid-conversation (2026-06-23).
        try:
            if (getattr(state._tts_instance, "name", "") == "elevenlabs"
                    and os.path.exists(state._TTS_MODEL_PATH)):
                from brain.voice.tts import _PiperTTS
                _fallback = _PiperTTS(state._TTS_MODEL_PATH)
                print(f"[TTS] ElevenLabs failed ({e}) — using Piper for this sentence only")
                _fb_result = _fallback.speak(text)
                import base64 as _b64fb
                return {
                    "audio_b64": _b64fb.b64encode(_fb_result.wav_bytes).decode("ascii"),
                    "sample_rate": _fb_result.sample_rate,
                    "duration_sec": round(_fb_result.duration_sec, 3),
                    "backend": "piper-fallback",
                }
        except Exception:
            pass
        return None


# ── Vision tool factories ────────────────────────────────────────────

def _make_vision_describe_tool(webcam_tool_getter):
    def _describe(args):
        import time as _t_vd
        source = (args.get("source") or "screen").lower()
        prompt = (args.get("prompt") or "").strip()
        mode = (args.get("mode") or "").strip().lower()

        # ── PC-relay caption first ─────────────────────────────────────
        # On the VPS (IS_SANDBOX=1) the local Moondream path below is DEAD
        # — transformers isn't installed, so this tool errored with
        # ModuleNotFoundError on every call (Leon hit it live 2026-06-11,
        # and it silently broke the dcc47f7 post-action verification
        # chain). But the PC captioner already runs Moondream2 on Dean's
        # GPU and POSTs screen/webcam captions to /api/relay/perception
        # every 8-10s — those land in vision_daemon._state. A fresh relay
        # caption IS Leon's working eyesight: return it directly. It's a
        # generic scene caption rather than an answer to a custom prompt,
        # which is plenty for "did Facebook open?"-style verification.
        if source in ("screen", "webcam"):
            try:
                from brain import vision_daemon as _vd
                with _vd._lock:
                    _cap = _vd._state.get(f"last_{source}_caption", "")
                    _ts = _vd._state.get(f"last_{source}_ts", 0) or 0
                _age = _t_vd.time() - _ts
                if _cap and _age < 90:
                    note = f"PC captioner, {_age:.0f}s old"
                    if prompt:
                        note += (" — generic scene caption, judge your "
                                 "question against it yourself")
                    return {"ok": True, "result": {
                        "source": source,
                        "answer": _cap,
                        "age_s": round(_age, 1),
                        "via": "pc_relay_caption",
                        "note": note,
                    }}
            except Exception:
                pass  # fall through to local vision

        # ── Local Moondream fallback (PC-style hosts only) ────────────
        if state._local_vision is None:
            return {"ok": False, "error":
                    "no fresh PC relay caption (is leon-relay.service "
                    "running on the PC?) and local vision not initialized"}
        if not state._local_vision.available:
            if not state._local_vision.prewarm():
                return {"ok": False, "error":
                        "no fresh PC relay caption (is leon-relay.service "
                        "running on the PC?) and local vision unavailable: "
                        + (state._local_vision.last_error or "moondream2 unavailable")}

        if source == "screen":
            try:
                from brain.actuator_client import call as _act_call
                r = _act_call("screen.capture", {})
            except Exception as e:
                return {"ok": False, "error": f"screen capture failed: {e}"}
            if not r.get("ok"):
                return {"ok": False, "error": r.get("error", "screen capture failed")}
            img_b64 = (r.get("result") or {}).get("image_b64", "")
        elif source == "webcam":
            wc = webcam_tool_getter()
            if wc is None:
                return {"ok": False, "error": "webcam tool not wired"}
            r = wc({})
            if not r.get("ok"):
                return {"ok": False, "error": r.get("error", "webcam capture failed")}
            img_b64 = (r.get("result") or {}).get("image_b64", "")
        else:
            return {"ok": False, "error": f"unknown source: {source!r} (use 'screen' or 'webcam')"}
        if not img_b64:
            return {"ok": False, "error": "empty frame"}

        try:
            img_bytes = base64.b64decode(img_b64)
        except Exception as e:
            return {"ok": False, "error": f"frame decode failed: {e}"}

        if mode == "detect" or (not mode and any(w in prompt.lower()
                for w in ("find ", "detect ", "count ", "locate ", "where is "))):
            target = prompt
            for prefix in ("find ", "detect ", "count ", "locate ", "where is "):
                if target.lower().startswith(prefix):
                    target = target[len(prefix):]
                    break
            r = state._local_vision.detect(img_bytes, target.strip(" ?."))
        elif not prompt or mode == "caption":
            r = state._local_vision.caption(img_bytes, length="normal")
        else:
            r = state._local_vision.query(img_bytes, prompt)
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error", "vision inference failed")}
        return {"ok": True, "result": {
            "source": source,
            "answer": r.get("answer") or r.get("caption") or "",
            "objects": r.get("objects"),
            "latency_s": r.get("latency_s"),
        }}
    return _describe


def _make_click_element_tool():
    import io
    def _click_element(args):
        if state._local_vision is None or not state._local_vision.available:
            if state._local_vision is None or not state._local_vision.prewarm():
                return {"ok": False, "error":
                        "local vision unavailable. Falls back to click_text."}
        description = (args.get("description") or "").strip()
        if not description:
            return {"ok": False, "error": "description is required"}
        occurrence = args.get("occurrence")
        position = (args.get("position") or "").strip().lower()
        button = (args.get("button") or "left").lower()
        if button not in ("left", "right", "middle"):
            return {"ok": False, "error": f"invalid button: {button}"}

        try:
            from brain.actuator_client import call as _act_call
        except Exception as e:
            return {"ok": False, "error": f"actuator import failed: {e}"}
        cap = _act_call("screen.capture", {})
        if not cap.get("ok"):
            return {"ok": False, "error": f"screen capture failed: {cap.get('error')}"}
        img_b64 = (cap.get("result") or {}).get("image_b64", "")
        if not img_b64:
            return {"ok": False, "error": "empty screen capture"}

        cap_w = int(cap["result"].get("width", 0))
        cap_h = int(cap["result"].get("height", 0))
        try:
            from PIL import Image
            pil = Image.open(io.BytesIO(base64.b64decode(img_b64)))
            if not cap_w: cap_w = pil.width
            if not cap_h: cap_h = pil.height
            img_bytes = base64.b64decode(img_b64)
        except Exception as e:
            return {"ok": False, "error": f"image decode failed: {e}"}

        import subprocess, re as _re
        try:
            out = subprocess.check_output(["xrandr", "--listmonitors"], timeout=2).decode()
            real_w = real_h = 0
            for line in out.splitlines()[1:]:
                m = _re.search(r'(\d+)/\d+x(\d+)/\d+\+(\d+)\+(\d+)', line)
                if m:
                    w, h, x, y = map(int, m.groups())
                    real_w = max(real_w, x + w)
                    real_h = max(real_h, y + h)
            if not real_w: real_w = cap_w
            if not real_h: real_h = cap_h
        except Exception:
            real_w, real_h = cap_w, cap_h

        pr = state._local_vision.point(img_bytes, description)
        if not pr.get("ok"):
            return {"ok": False, "error":
                    f"Moondream point failed: {pr.get('error')}"}
        points = pr.get("points", [])
        if not points:
            return {"ok": False, "error":
                    f"Moondream didn't find '{description}'. Try a simpler "
                    f"noun target (e.g. 'video thumbnail' instead of "
                    f"'tesla video in bottom right'), and use the `position` "
                    f"arg for spatial selection. Or fall back to click_text / "
                    f"browser_dom_click."}

        with_px = []
        for p in points:
            px = p["x"] * real_w
            py = p["y"] * real_h
            with_px.append({"nx": p["x"], "ny": p["y"], "px": px, "py": py})

        if position in ("on-left-monitor", "left-monitor"):
            with_px = [p for p in with_px if p["px"] < 1920]
        elif position in ("on-middle-monitor", "middle-monitor"):
            with_px = [p for p in with_px if 1920 <= p["px"] < 3840]
        elif position in ("on-right-monitor", "right-monitor"):
            with_px = [p for p in with_px if p["px"] >= 3840]

        if not with_px:
            return {"ok": False, "error":
                    f"found {len(points)} '{description}' points but none "
                    f"matched position filter '{position}'."}

        if position in ("top-left", "first"):
            with_px.sort(key=lambda p: (p["py"], p["px"]))
        elif position == "top-right":
            with_px.sort(key=lambda p: (p["py"], -p["px"]))
        elif position == "bottom-left":
            with_px.sort(key=lambda p: (-p["py"], p["px"]))
        elif position in ("bottom-right", "last"):
            with_px.sort(key=lambda p: (-p["py"], -p["px"]))
        elif position == "top":
            with_px.sort(key=lambda p: p["py"])
        elif position == "bottom":
            with_px.sort(key=lambda p: -p["py"])
        elif position == "left":
            with_px.sort(key=lambda p: p["px"])
        elif position == "right":
            with_px.sort(key=lambda p: -p["px"])
        elif position == "center":
            cx0, cy0 = real_w / 2, real_h / 2
            with_px.sort(key=lambda p: (p["px"] - cx0) ** 2 + (p["py"] - cy0) ** 2)

        pick_idx = occurrence if occurrence is not None else 0
        if pick_idx >= len(with_px):
            return {"ok": False, "error":
                    f"only {len(with_px)} candidates matched, occurrence={pick_idx} out of range"}

        chosen = with_px[pick_idx]
        cx = int(chosen["px"])
        cy = int(chosen["py"])
        cx = max(0, min(cx, real_w - 1))
        cy = max(0, min(cy, real_h - 1))

        click_r = _act_call("mouse.click", {"x": cx, "y": cy, "button": button})
        if not click_r.get("ok"):
            return {"ok": False, "error":
                    f"click at ({cx},{cy}) failed: {click_r.get('error')}"}

        import time as _time
        _time.sleep(0.4)
        verified = None
        verify_hint = ""
        try:
            cap2 = _act_call("screen.capture", {})
            if cap2.get("ok"):
                img2_b64 = (cap2.get("result") or {}).get("image_b64", "")
                if img2_b64 and img_b64 != img2_b64:
                    verified = True
                    verify_hint = "screen changed after click"
                else:
                    verified = False
                    verify_hint = (
                        f"WARNING: screen unchanged after clicking '{description}' "
                        f"at ({cx},{cy}). The click may not have landed on the "
                        f"right element. Consider retrying with browser_dom_click "
                        f"or click_text for more reliable targeting."
                    )
        except Exception:
            pass

        result = {
            "clicked": {"x": cx, "y": cy, "button": button},
            "description": description,
            "position": position or "first",
            "normalized": {"x": chosen["nx"], "y": chosen["ny"]},
            "total_candidates_pre_filter": len(points),
            "candidates_post_filter": len(with_px),
            "picked_index": pick_idx,
            "image_size": [cap_w, cap_h],
            "screen_size": [real_w, real_h],
            "latency_s": pr.get("latency_s"),
            "backend": "moondream2",
        }
        if verified is not None:
            result["verified"] = verified
            result["verify_hint"] = verify_hint
        return {"ok": True, "result": result}
    return _click_element


def _make_webcam_tool():
    def _capture(args):
        cached = _get_cached_webcam_frame(max_age=10.0)
        if cached and cached.get("image_b64"):
            print(f"[WEBCAM] serving cached frame ({len(cached['image_b64'])//1024}KB, "
                  f"age={time.time()-state._webcam_frame_ts:.1f}s)")
            return {"ok": True, "result": {
                "image_b64": cached["image_b64"],
                "width": cached.get("width"),
                "height": cached.get("height"),
                "format": "jpeg",
                "source": "cache",
            }}

        with state._webcam_clients_lock:
            ready_clients = [k for k, v in state._webcam_clients.items() if v]
            total_clients = len(state._webcam_clients)
        import os as _os_wc
        if _os_wc.environ.get("LEON_VERBOSE") == "1":
            print(f"[WEBCAM] no cached frame — WS capture: {len(ready_clients)} ready / "
                  f"{total_clients} total clients connected")
        if not ready_clients:
            # THE DEFECT (Aiden's "Iris", Windows 11, 2026-08-12): he never
            # opened the local dashboard in a browser — he just talked to
            # his SI — so _webcam_clients was always empty and webcam_capture
            # failed 100% of the time. It failed *silently past* the real
            # camera: leon-actuator/camera_tools.py is a complete,
            # cross-platform (DirectShow/AVFoundation/V4L2), warmup- and
            # black-frame-aware webcam grabber that every install already
            # ships with — but this function never called it. It only ever
            # asked a browser tab's getUserMedia stream, and
            # webcam_capture wasn't even in _TOOL_NAME_MAP, so there was no
            # path from the tool name to the actuator's real implementation
            # at all. Try the OS camera directly through the actuator
            # before giving up; this is the path that actually works for a
            # voice/chat-only customer with no dashboard open.
            try:
                from brain.actuator_client import call as _actuator_call, is_alive as _actuator_alive
                if _actuator_alive(timeout=1.5):
                    act_result = _actuator_call("webcam.capture", args or {}, timeout=20.0)
                    if act_result.get("ok"):
                        r = act_result.get("result", {}) or {}
                        print(f"[WEBCAM] no dashboard client — actuator camera OK "
                              f"({r.get('width')}x{r.get('height')})")
                        r["source"] = "actuator"
                        return {"ok": True, "result": r}
                    print(f"[WEBCAM] no dashboard client — actuator camera also "
                          f"failed: {act_result.get('error')}")
                    from brain.identity import owner_prose as _owner_prose
                    return {"ok": False, "error": (
                        f"couldn't reach the camera: {act_result.get('error')}. "
                        f"You can also open the dashboard and click the camera "
                        f"button on the input bar so {_owner_prose()} can see "
                        f"the browser's camera feed instead."
                    )}
            except Exception as e:
                print(f"[WEBCAM] actuator camera fallback raised: {type(e).__name__}: {e}")
            from brain.identity import owner_prose as _owner_prose
            return {"ok": False, "error": (
                "no dashboard has the webcam enabled and the actuator camera "
                f"isn't reachable either. Ask {_owner_prose()} to click the "
                "camera button on the input bar, or check that the camera "
                "isn't in use by another app."
            )}
        req_id = "wc_" + secrets.token_hex(4)
        ev = threading.Event()
        with state._pending_webcam_lock:
            state._pending_webcam[req_id] = {"event": ev, "resolved": False, "payload": None, "ts": time.time()}
        try:
            _broadcast_threadsafe({
                "type": "webcam_capture_request",
                "request_id": req_id,
            })
            print(f"[WEBCAM] {req_id} broadcast; waiting up to 15s for frame")
            t0 = time.time()
            got = ev.wait(timeout=15.0)
            with state._pending_webcam_lock:
                entry = state._pending_webcam.pop(req_id, None)
            if not got or entry is None or not entry.get("resolved"):
                print(f"[WEBCAM] {req_id} TIMEOUT after {time.time()-t0:.1f}s "
                      f"(resolved={entry.get('resolved') if entry else 'no-entry'})")
                return {"ok": False, "error": "webcam capture timed out — dashboard never responded"}
            payload = entry.get("payload") or {}
            img_b64 = payload.get("image_b64")
            if not img_b64:
                print(f"[WEBCAM] {req_id} EMPTY response from dashboard "
                      f"(width={payload.get('width')}, height={payload.get('height')})")
                return {"ok": False, "error": "webcam returned empty frame — dashboard had no live stream"}
            print(f"[WEBCAM] {req_id} OK — {payload.get('width')}x{payload.get('height')} "
                  f"({len(img_b64)//1024}KB b64) in {time.time()-t0:.1f}s")
            return {"ok": True, "result": {
                "image_b64": img_b64,
                "width":  payload.get("width"),
                "height": payload.get("height"),
                "format": "png",
            }}
        except Exception as e:
            with state._pending_webcam_lock:
                state._pending_webcam.pop(req_id, None)
            log.warning(f"[WEBCAM] {req_id} EXCEPTION: {type(e).__name__}: {e}", exc_info=True)
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return _capture


# ── Reminder tool factories ──────────────────────────────────────────

def _make_reminder_tools(scheduler_getter):
    def _set(args):
        sched = scheduler_getter()
        if sched is None:
            return {"ok": False, "error": "reminder scheduler not running"}
        text = (args.get("text") or "").strip()
        if not text:
            return {"ok": False, "error": "text is required"}
        in_secs = args.get("in_seconds")
        at_iso = args.get("at_iso")
        from brain.identity import si_name as _sn
        title = args.get("title") or _sn()
        try:
            in_secs_f = float(in_secs) if in_secs is not None else None
        except (TypeError, ValueError):
            return {"ok": False, "error": f"in_seconds not numeric: {in_secs!r}"}
        at_unix = None
        if at_iso:
            import datetime as _dt
            try:
                d = _dt.datetime.fromisoformat(str(at_iso))
                at_unix = d.timestamp()
            except Exception:
                return {"ok": False, "error": f"at_iso not valid ISO-8601: {at_iso!r}"}
        if in_secs_f is None and at_unix is None:
            return {"ok": False, "error": "specify in_seconds or at_iso"}
        try:
            rem = sched.add(text=text, in_seconds=in_secs_f, at_unix=at_unix, title=title)
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        import datetime as _dt
        due = _timefmt(_dt.datetime.fromtimestamp(rem.due_ts), "%a %-I:%M %p")
        return {"ok": True, "result": {
            "id": rem.id, "text": rem.text,
            "due_ts": rem.due_ts, "due_human": due,
        }}

    def _list(args):
        sched = scheduler_getter()
        if sched is None:
            return {"ok": False, "error": "reminder scheduler not running"}
        from dataclasses import asdict
        rems = sched.list_active()
        import datetime as _dt
        return {"ok": True, "result": {
            "count": len(rems),
            "active": [
                {**asdict(r),
                 "due_human": _timefmt(_dt.datetime.fromtimestamp(r.due_ts), "%a %-I:%M %p"),
                 "due_in_s": round(r.due_ts - time.time())}
                for r in sorted(rems, key=lambda r: r.due_ts)
            ],
        }}

    def _cancel(args):
        sched = scheduler_getter()
        if sched is None:
            return {"ok": False, "error": "reminder scheduler not running"}
        rid = (args.get("id") or "").strip()
        if not rid:
            return {"ok": False, "error": "id is required"}
        ok = sched.cancel(rid)
        return {"ok": ok, "result": {"id": rid, "cancelled": ok}}

    return {"reminder_set": _set, "reminder_list": _list, "reminder_cancel": _cancel}


# ── Knowledge search tool factory ────────────────────────────────────

def _reconsolidate_from_ids(store, match_ids):
    """Layer 3 — pull emotional fingerprints from recalled memories
    and blend them into the live brain state."""
    if not match_ids or state.brain is None:
        return
    try:
        import sqlite3
        conn = sqlite3.connect(store.db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        placeholders = ",".join("?" * len(match_ids))
        rows = conn.execute(
            f"SELECT emo_dopamine, emo_serotonin, emo_acetylcholine, emo_norepinephrine "
            f"FROM knowledge WHERE id IN ({placeholders})",
            match_ids,
        ).fetchall()
        conn.close()
        fingerprints = []
        for r in rows:
            fp = {
                "dopamine": r["emo_dopamine"],
                "serotonin": r["emo_serotonin"],
                "acetylcholine": r["emo_acetylcholine"],
                "norepinephrine": r["emo_norepinephrine"],
            }
            # Skip untagged entries (default -1)
            if fp["dopamine"] >= 0:
                fingerprints.append(fp)
        if fingerprints:
            state.brain.reconsolidate(fingerprints)
    except Exception:
        pass  # reconsolidation is best-effort


def _make_knowledge_search_tool(get_store, get_retriever=None):
    def _search(args):
        store = get_store()
        if store is None:
            return {"ok": False, "error": "knowledge store not initialized"}
        q = (args.get("query") or "").strip()
        if not q:
            return {"ok": False, "error": "query is required"}
        limit = int(args.get("limit") or 5)
        limit = max(1, min(15, limit))

        retriever = get_retriever() if get_retriever else None
        try:
            if retriever is not None:
                hits = retriever.recall(q, k=limit) or []
                matches = [{
                    "id":        h["id"],
                    "source":    h["source"],
                    "tags":      h["tags"],
                    "text":      h["text"],
                    "timestamp": h["timestamp"],
                    "score":     h.get("score", {}),
                } for h in hits]
                # Layer 3: emotional reconsolidation on recall
                _reconsolidate_from_ids(store, [h["id"] for h in hits if h.get("id")])
                result = {"ok": True, "result": {"query": q, "matches": matches,
                                                  "ranking": "hybrid_neural"}}
                try:
                    from brain.cognition.retrieval_integration import maybe_augment_search_results
                    result = maybe_augment_search_results(q, result)
                except Exception:
                    pass
                return result
            rows = store.search(q, limit=limit) or []
            matches = []
            for row in rows:
                try:
                    row_d = dict(row) if not isinstance(row, dict) else row
                except Exception:
                    row_d = {}
                tags_raw = row_d.get("tags") or ""
                tag_list = [t for t in tags_raw.split(",") if t] if isinstance(tags_raw, str) else list(tags_raw)
                matches.append({
                    "id": row_d.get("id"),
                    "source": row_d.get("source", ""),
                    "tags": tag_list,
                    "text": (row_d.get("text") or "")[:2000],
                    "timestamp": row_d.get("timestamp"),
                })
            # Layer 3: emotional reconsolidation on recall
            _reconsolidate_from_ids(store, [m["id"] for m in matches if m.get("id")])
            result = {"ok": True, "result": {"query": q, "matches": matches,
                                              "ranking": "fts_only"}}
            try:
                from brain.cognition.retrieval_integration import maybe_augment_search_results
                result = maybe_augment_search_results(q, result)
            except Exception:
                pass
            return result
        except Exception as e:
            return {"ok": False, "error": f"search failed: {e}"}
    return _search


# ── Wake orchestrator ────────────────────────────────────────────────

def _ensure_wake_orchestrator():
    # Hard kill switch (2026-08-15). The wake stack only detects
    # wake words it was TRAINED on ("hey leon"/"hey jarvis"); it cannot hear
    # an arbitrary SI name. Rather than ship a feature that answers to the
    # wrong name, the whole stack is off unless someone opts in explicitly.
    # No env var, no listener, no mic thread, no CPU burned pretending.
    if (os.environ.get("LEON_WAKE_ENABLED") or "0").strip().lower() not in ("1", "true", "yes", "on"):
        print("[WAKE] disabled — LEON_WAKE_ENABLED is off (wake word not supported for custom SI names)")
        return None
    if state.wake_orchestrator is not None:
        return state.wake_orchestrator
    if state.brain_api_responder is None:
        print("[WAKE] no API responder — wake mode disabled")
        return None
    backend = (os.environ.get("LEON_WAKE_BACKEND") or "vosk").lower()
    listener = None
    if backend == "vosk":
        try:
            from brain.voice.wake_word_vosk import VoskWakeWordListener
            listener = VoskWakeWordListener()
        except Exception as e:
            log.warning(f"[WAKE] Vosk backend failed ({e}); falling back to openwakeword", exc_info=True)
            backend = "openwakeword"
    if listener is None:
        try:
            from brain.voice.wake_word import WakeWordListener
            listener = WakeWordListener()
        except Exception as e:
            log.warning(f"[WAKE] no backend available: {e}", exc_info=True)
            return None
    try:
        from brain.voice.wake_orchestrator import WakeOrchestrator
    except Exception as e:
        log.warning(f"[WAKE] orchestrator import failed: {e}", exc_info=True)
        return None
    state.wake_listener = listener
    state.wake_orchestrator = WakeOrchestrator(
        listener=state.wake_listener,
        brain=state.brain,
        text_encoder=state.text_encoder,
        responder=state.brain_api_responder,
        notify=_broadcast_threadsafe,
        tts_for_text=_tts_synthesize_b64,
        stt=state._prewarmed_stt,
        confirm_callback=_make_broadcast_confirm_callback(),
        responder_lock=state._responder_lock,
    )
    return state.wake_orchestrator


# ── Voice pipeline ───────────────────────────────────────────────────

def handle_voice_utterance(user_text: str, source: str = "voice",
                           captured_ts: Optional[float] = None) -> str:
    """Route a transcribed utterance through Leon's responder.

    Shared by:
      - server/helpers.py's local VoicePipeline (dashboard mic button)
      - server/routers/io_routes.py /api/relay/heard (PC-side ambient
        wake transcribes the utterance and POSTs it here)

    Broadcasts brain_response_* events to all WS clients so the
    dashboard renders the conversation in real time and TTS plays
    through the connected browser.

    `captured_ts` — when the producer knows the capture instant of the
    audio behind this transcript, passing it upgrades the ingress gate
    from an arrival-window heuristic to THE capture-timestamp rule.
    """
    import time as _t
    # ── Consumer-side self-echo net (rows 15895/15896) ────────────────
    # Every defence used to live on the producer side (sensor_relay's
    # chunk gate / marker bridge on Dean's PC). One producer failure and
    # Leon's own TTS, or a video call on Dean's speakers, was stored as
    # Dean (claude_api_responder.py:3061). This is the last shared point
    # before the responder — and it runs in the process whose audio_gate
    # LEDGER already holds the playback interval and the spoken text.
    try:
        from brain.voice import ingress_gate as _ingress
        _accept, _reason, _score = _ingress.verdict(
            user_text, source=source, captured_ts=captured_ts)
    except Exception as _ig_e:
        # House rule (tests/test_self_echo_no_user_turn.py, fail-CLOSED):
        # an unattributable turn must never become an operator instruction.
        # A dropped real turn costs Dean a repeat; a promoted echo costs an
        # unauthorized action. Quarantine, loudly.
        print(f"[VOICE-GATE] ingress check ERRORED — quarantining turn: {_ig_e}")
        _accept, _reason, _score = False, "check-error", 0.0
    if _accept:
        # Log ACCEPTS too (2026-08-07): an echo that slips through is
        # invisible if only rejections print — Dean's "hey Leon" self-wake
        # was accepted silently and we couldn't tell which path leaked.
        print(f"[VOICE-GATE] accepted ({_reason}, overlap={_score:.2f}, "
              f"source={source}, captured_ts={'yes' if captured_ts else 'no'}): "
              f"{user_text[:90]!r}")
    if not _accept:
        print(f"[VOICE-GATE] REJECTED utterance ({_reason}, overlap={_score:.2f}, "
              f"source={source}): {user_text[:90]!r}")
        _broadcast_threadsafe({
            "type": "wake_transcribed",
            "transcript": user_text,
            "rejected": True,
            "reason": _reason,
        })
        return ""
    try:
        # Mark user activity so full-speed autonomous pursuit YIELDS the responder
        # lock to this voice turn (otherwise pursuit holds it back-to-back and the
        # voice turn is starved → Leon goes "deaf" to Dean mid-grind).
        try:
            _m = getattr(state.brain, "consciousness_meter", None) if state.brain else None
            if _m is not None:
                _m._last_user_message_ts = _t.time()
        except Exception:
            pass
        if state.claude_bridge is not None:
            # Same call shape the dashboard WS path uses — ClaudeBridge has
            # send_observation(), not observe(). The observe() call here
            # AttributeError'd on every wake utterance since P0.2 shipped
            # (2026-06-11 morning), killing the whole wake→response chain.
            state.claude_bridge.send_observation({
                "type": "text",
                "content": user_text,
                "source": source,
            })
        brain_state = state.brain.get_state() if state.brain else {}
        response_id = f"v{int(_t.time()*1000)}"

        _broadcast_threadsafe({
            "type": "brain_response_start",
            "user": user_text,
            "response_id": response_id,
            "from_voice": True,
        })

        # Phase 1.1: streaming filler
        try:
            from brain.voice import fillers as _fillers
            filler = _fillers.get_filler(user_text)
            if filler:
                # Send filler audio to EVERY connected screen (phone + PC),
                # not a single sink — Dean wants Leon's voice on both devices
                # at once. (Was _broadcast_audio_threadsafe, which delivered to
                # one socket and left the other device — and sometimes both —
                # silent. 2026-06-27.)
                _broadcast_threadsafe({
                    "type":           "brain_audio",
                    "response_id":    response_id,
                    "sentence_index": -1,
                    "is_filler":      True,
                    **filler,
                })
        except Exception as _filler_e:
            print(f"[VOICE] filler skipped: {_filler_e}")

        full_text = ""
        sentence_idx = 0
        # ── Serialize against daemon/dashboard turns (THE WEDGE FIX) ──
        # The wake path was the ONE responder path that didn't take
        # _responder_lock, so Dean's voice turn could overlap a background
        # daemon turn → two concurrent `claude -p` subprocesses → the brain
        # wedged (frozen log, pegged core, hung API) on 2026-06-14. Mirror the
        # WS dashboard pattern: try non-blocking; if a turn is already running,
        # abort it (Dean's voice wins) and wait briefly. The finally below
        # GUARANTEES release so a turn can never leak the lock and freeze the
        # brain permanently.
        _rlock = getattr(state, "_responder_lock", None)
        _got_lock = True
        if _rlock is not None:
            # Same newest-message-wins gate as the websocket path — one gate
            # for every input path, or supersession is blind to half the
            # turns (see server/turn_priority.py). Superseded voice turns
            # exit silently: the newer message answers this text too.
            from server.turn_priority import acquire_user_turn
            _status, _texts, _waited = acquire_user_turn(
                _rlock, state.brain_api_responder, user_text)
            if _waited > 0.5 or _status != "go":
                print(f"[VOICE] user turn: {_status} after {_waited:.1f}s")
            if _status in ("superseded", "answered"):
                return ""
            if _status == "timeout":
                print("[VOICE] responder wedged — dropping this turn (no freeze)")
                _broadcast_threadsafe({
                    "type":        "brain_response_end",
                    "response_id": response_id,
                    "response":    "Hang on — give me a second, I'm mid-thought.",
                })
                return "Hang on — give me a second, I'm mid-thought."
            user_text = "\n".join(_texts) if len(_texts) > 1 else _texts[0]
        # Mark this supervised VOICE turn active so the dreaming loop's
        # anti-mid-work-sleep gate (reads _responder_stats) keeps Leon awake
        # during voice-driven work — not just dashboard-text work. Without this,
        # long voice work turns auto-slept him mid-task (2026-06-19).
        try:
            state._responder_stats["is_processing"] = True
        except Exception:
            pass
        # ── Response-level self-hearing gate ──────────────────────────
        # Keep the PC-side wake listener paused for the ENTIRE voice
        # response, not per-sentence. Without this, each inter-sentence
        # gap (marker clears → new sentence hasn't started) lets the mic
        # reopen and Vosk picks up Leon's own speech from the speakers.
        # The per-sentence marker_set in _tts_synthesize_b64 still fires
        # (belt-and-suspenders) but this outer gate prevents gaps.
        _response_marker_alive = True
        def _response_marker_keepalive():
            """Touch the TTS marker every 2s while the response streams."""
            try:
                from brain.actuator_client import call as _ac
            except Exception:
                return
            while _response_marker_alive:
                try:
                    _ac("tts.marker_set",
                        {"duration_s": 5, "cooldown_s": 1.5},
                        timeout=2.0)
                except Exception:
                    pass
                _t.sleep(2)
        import threading as _th_resp
        _mk_thread = _th_resp.Thread(target=_response_marker_keepalive,
                                      daemon=True, name="voice-resp-gate")
        _mk_thread.start()
        try:
            for ev in state.brain_api_responder.respond_streaming(user_text, brain_state, supervised=True):
                # Stop the instant Dean hits Stop — don't broadcast/synthesize
                # straggler events (each leaked sentence would re-trigger TTS).
                if state.brain_api_responder.is_aborting():
                    break
                if ev.type == "model":
                    _broadcast_threadsafe({
                        "type":        "brain_response_model",
                        "response_id": response_id,
                        "model":       ev.model,
                        "tier":        ev.tier,
                    })
                elif ev.type == "delta":
                    _broadcast_threadsafe({
                        "type":        "brain_response_delta",
                        "response_id": response_id,
                        "text":        ev.text,
                    })
                elif ev.type == "sentence":
                    audio = _tts_synthesize_b64(ev.text)
                    if audio:
                        # Broadcast each spoken sentence to ALL screens so the
                        # phone and the PC both speak with Leon's real voice,
                        # no matter which device Dean spoke into. (Was single-
                        # sink _broadcast_audio_threadsafe → only one device,
                        # often the wrong one, got the audio. 2026-06-27.)
                        _broadcast_threadsafe({
                            "type":           "brain_audio",
                            "response_id":    response_id,
                            "sentence_index": sentence_idx,
                            **audio,
                        })
                    sentence_idx += 1
                elif ev.type == "done":
                    full_text = ev.full_text
                    break
                elif ev.type == "error":
                    print(f"[VOICE] stream error: {ev.error}")
                    full_text = full_text or f"(voice stream error: {ev.error})"
                    break
        except Exception as e:
            log.warning(f"[VOICE] respond_streaming failed: {e}", exc_info=True)
            full_text = f"(voice handler error: {e})"
        finally:
            _response_marker_alive = False
            # GUARANTEED release — even on exception/abort — so the lock can
            # never leak and freeze the brain (the 2026-06-14 wedge cause).
            if _got_lock and _rlock is not None:
                try:
                    _rlock.release()
                except Exception:
                    pass
            try:
                state._responder_stats["last_call_ts"] = time.time()
                state._responder_stats["is_processing"] = False
            except Exception:
                pass

        _broadcast_threadsafe({
            "type":        "brain_response_end",
            "response_id": response_id,
            "response":    full_text,
        })
        return full_text
    except Exception as e:
        # This except used to be silent — wake-path failures vanished
        # without a trace (bit us during the 2026-06-11 Fable migration
        # test: POSTs to /api/relay/heard died here invisibly). Always
        # log the full traceback.
        log.warning("[VOICE] handle_voice_utterance failed: %s", e, exc_info=True)
        return f"(voice handler error: {e})"


def _ensure_voice_pipeline():
    """Lazy-init so the voice backends (possibly heavy ML libs) only load when
    someone actually uses the voice API."""
    if state.voice_pipeline is not None:
        return state.voice_pipeline
    from brain.voice import VoicePipeline

    state.voice_pipeline = VoicePipeline(
        on_utterance=handle_voice_utterance,
        tts_prefer=os.environ.get("LEON_TTS_PREFER"),
        tts_piper_model=state._TTS_MODEL_PATH if os.path.exists(state._TTS_MODEL_PATH) else None,
        tts_elevenlabs_voice_id=os.environ.get("ELEVENLABS_VOICE_ID"),
    )
    print(
        f"[VOICE] Pipeline ready — "
        f"VAD={state.voice_pipeline.vad.backend_name} "
        f"STT={state.voice_pipeline.stt.backend_name} "
        f"TTS={state.voice_pipeline.tts.backend_name}"
    )
    return state.voice_pipeline


# ── STT ──────────────────────────────────────────────────────────────

def _ensure_stt():
    with state._stt_lock:
        if state._stt_instance is not None:
            return state._stt_instance
        try:
            from brain.voice.stt import STT
            state._stt_instance = STT()
            print(f"[VOICE] STT ready — backend: {state._stt_instance.backend_name}")
        except Exception as e:
            log.warning(f"[VOICE] STT init failed: {e}", exc_info=True)
            state._stt_instance = None
    return state._stt_instance


def broadcast_agent_activity(agent: str, text: str, detail: str = "",
                             ttl_ms: int = 10000) -> None:
    """One line in the activity log, tagged as belonging to a named sub-agent.

    Convenience wrapper so call sites read as what they are:
        broadcast_agent_activity("scout", "scanning 3 lead sources", long_text)
    """
    broadcast_activity("agent", text, ttl_ms=ttl_ms, agent=agent, detail=detail)
