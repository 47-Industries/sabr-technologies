"""
Main WebSocket handler for real-time brain state streaming.
"""

import asyncio
import logging
import threading
import time

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from brain.config import BrainConfig
from brain.persistence import save_brain, load_brain

from server import state
from server.helpers import (
    _broadcast_threadsafe, _make_confirm_callback, _resolve_confirm,
    _resolve_webcam, _tts_synthesize_b64,
)

log = logging.getLogger("leon.server")
router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    state.connected_clients.add(ws)
    state._main_event_loop = asyncio.get_running_loop()
    print(f"[WS] Client connected ({len(state.connected_clients)} total)")

    # Send initial neuron positions.
    # Binary fast path: get_neuron_positions_binary() returns (meta, blob)
    # where blob is packed Float32 LE positions. We send the meta as a
    # JSON text frame, then the blob as a single binary frame. Total
    # payload ~1.8 MB vs ~8-12 MB for the legacy JSON-of-lists shape.
    # Falls back to legacy JSON `init` if anything in the binary path
    # fails — keeps stale dashboards alive.
    try:
        try:
            meta, blob = state.brain.get_neuron_positions_binary()
            await ws.send_json({"type": "init_meta", **meta})
            await ws.send_bytes(blob)
        except Exception:
            positions = state.brain.get_neuron_positions()
            await ws.send_json({"type": "init", "positions": positions})
    except Exception:
        pass

    update_interval = 1.0 / BrainConfig.WS_UPDATE_RATE

    # Split sender (state broadcast) and receiver (incoming messages) into
    # two concurrent tasks. Previous design polled receive_json with a 1ms
    # timeout from inside the broadcast loop, which cancelled Starlette's
    # WS receiver mid-frame on every tick — dropping tool_confirm /
    # abort_response / webcam_capture_response under any real load.
    async def _sender():
        try:
            while True:
                start = time.time()
                brain_state = state.brain.get_state()

                if state.claude_bridge:
                    brain_state["claude"] = {
                        "connected": True,
                        "interactions": state.claude_bridge._interaction_count,
                    }
                if state.screen_observer:
                    brain_state["screen_observer"] = state.screen_observer.get_state()
                if state.video_recorder:
                    brain_state["video_recorder"] = state.video_recorder.get_state()

                now_ts = time.time()
                brain_state["leon"] = {
                    "call_count":    state._responder_stats["call_count"],
                    "is_processing": state._responder_stats["is_processing"],
                    "session_uptime": round(now_ts - state._responder_stats["session_start"]),
                    "last_call_ago":  round(now_ts - state._responder_stats["last_call_ts"])
                                      if state._responder_stats["last_call_ts"] else None,
                }

                await ws.send_json({"type": "state", "data": brain_state})

                # Feed continuous sensory input
                if state.vision_encoder.active:
                    vis_features = state.vision_encoder.capture_frame()
                    state.brain.inject_sensory_input("vision", vis_features)
                if state.audio_encoder.active:
                    aud_features = state.audio_encoder.capture_audio()
                    state.brain.inject_sensory_input("audio", aud_features)

                elapsed = time.time() - start
                sleep_time = update_interval - elapsed
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
        except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
            return

    async def _receiver():
        try:
            while True:
                msg = await ws.receive_json()
                print(f"[WS] Got message: type={msg.get('type')}")
                if msg.get("type") == "text_input":
                    user_text = msg["text"]
                    features = state.text_encoder.encode(user_text)
                    state.brain.inject_sensory_input("text", features)
                    if state.claude_bridge:
                        state.claude_bridge.send_observation({
                            "type": "text",
                            "content": user_text,
                            "source": "dashboard",
                        })
                    _loop = asyncio.get_running_loop()
                    _ws_ref = ws
                    def _respond_async(text=user_text, loop=_loop, ws_ref=_ws_ref):
                        print(f"[BRAIN] Generating response for: {text[:40]}")
                        state._responder_stats["is_processing"] = True
                        state._responder_stats["call_count"] += 1
                        response_id = f"r{int(time.time()*1000)}"

                        ws_alive = {"value": True}
                        def _send(payload):
                            # Broadcast every turn event — thinking-start, live
                            # deltas, end, AND audio — to ALL connected screens so
                            # the phone and the PC come alive together and BOTH
                            # speak with Leon's real voice, no matter which device
                            # sent the message. (Previously sent only to the
                            # originating socket, so the other screen stayed silent
                            # and lagged behind on a poll.)
                            _broadcast_threadsafe(payload)

                        try:
                            bstate = state.brain.get_state()

                            # Fast path: streaming API
                            if state.brain_api_responder is not None:
                                full = ""
                                _confirm_cb = _make_confirm_callback(_send)
                                # Newest-message-wins admission (see
                                # server/turn_priority.py for both bugs this
                                # replaces). The gate asks the current holder
                                # to yield (abort + preempt_daemon), keeps
                                # exactly ONE turn waiting — this one, until a
                                # newer message supersedes it — and hands the
                                # winner every superseded text to answer in
                                # one reply. The bounce string is reserved for
                                # a genuine wedge at the (long) ceiling, not
                                # for losing a race against stale waiters.
                                from server.turn_priority import acquire_user_turn
                                _wait_note = ("Give me a second — still "
                                              "finishing the last thing.")
                                def _notify_wait(note=_wait_note,
                                                 rid=response_id + "-wait"):
                                    # A complete mini-turn, so no client is
                                    # left holding a dangling typing bubble.
                                    _send({"type": "brain_response_start",
                                           "user": "", "response_id": rid})
                                    _send({"type": "brain_response_delta",
                                           "response_id": rid, "text": note})
                                    _send({"type": "brain_response_end",
                                           "response_id": rid, "response": note})
                                _status, _texts, _waited = acquire_user_turn(
                                    state._responder_lock,
                                    state.brain_api_responder,
                                    text, notify=_notify_wait)
                                if _waited > 0.5 or _status != "go":
                                    print(f"[TURN] user turn: {_status} "
                                          f"after {_waited:.1f}s")
                                if _status in ("superseded", "answered"):
                                    # A newer message from Dean owns the reply
                                    # now (or already delivered it). Saying
                                    # anything here is two voices answering
                                    # one person. is_processing stays with the
                                    # winning turn, which resets it at its end.
                                    return
                                if _status == "timeout":
                                    _send({"type": "brain_response_delta",
                                           "response_id": response_id,
                                           "text": "Something's wrong on my end — give me a second."})
                                    _send({"type": "brain_response_end",
                                           "response_id": response_id,
                                           "response": "Something's wrong on my end — give me a second."})
                                    state._responder_stats["is_processing"] = False
                                    return
                                _got_lock = True
                                # Everything Dean said while the lock was
                                # busy, oldest first, answered as one turn.
                                text = "\n".join(_texts) if len(_texts) > 1 else _texts[0]
                                _send({"type": "brain_response_start",
                                       "user": text, "response_id": response_id})
                                try:
                                  for ev in state.brain_api_responder.respond_streaming(
                                      text, bstate, confirm_callback=_confirm_cb, supervised=True,
                                  ):
                                    # Stop the instant Dean hits Stop — don't
                                    # broadcast/synthesize straggler events (each
                                    # leaked sentence would re-trigger TTS).
                                    if state.brain_api_responder.is_aborting():
                                        break
                                    if ev.type == "model":
                                        _send({"type": "brain_response_model",
                                               "response_id": response_id,
                                               "model": ev.model,
                                               "tier": ev.tier})
                                    elif ev.type == "tool_use":
                                        _send({"type": "brain_tool_use",
                                               "response_id": response_id,
                                               "tool": ev.text,
                                               "tool_id": ev.tool_id,
                                               "risk": ev.risk,
                                               "input": ev.full_text})
                                    elif ev.type == "tool_result":
                                        _send({"type": "brain_tool_result",
                                               "response_id": response_id,
                                               "tool": ev.text,
                                               "tool_id": ev.tool_id,
                                               "summary": ev.full_text})
                                    elif ev.type == "delta":
                                        _send({"type": "brain_response_delta",
                                               "response_id": response_id,
                                               "text": ev.text})
                                    elif ev.type == "sentence":
                                        audio = _tts_synthesize_b64(ev.text)
                                        if audio:
                                            _send({"type": "brain_audio",
                                                   "response_id": response_id,
                                                   "sentence_index": ev.index,
                                                   **audio})
                                    elif ev.type == "done":
                                        full = ev.full_text
                                        _send({"type": "brain_response_end",
                                               "response_id": response_id,
                                               "response": full})
                                        # Record Leon's response in autobiography
                                        if state.autobiography is not None and full:
                                            try:
                                                state.autobiography.record(
                                                    "conversation",
                                                    f"I told Dean: '{full[:120]}'")
                                            except Exception:
                                                pass
                                    elif ev.type == "error":
                                        err = ev.error or ""
                                        if "timeout" in err.lower():
                                            print(f"[BRAIN] turn timed out: {err}")
                                            full = "That took too long, Sir — I'll be faster next time."
                                            _send({"type": "brain_response_delta",
                                                   "response_id": response_id,
                                                   "text": full})
                                            _send({"type": "brain_response_end",
                                                   "response_id": response_id,
                                                   "response": full})
                                            # TTS — speak the timeout message
                                            def _tts_timeout(txt=full, rid=response_id):
                                                audio = _tts_synthesize_b64(txt)
                                                if audio:
                                                    _send({"type": "brain_audio",
                                                           "response_id": rid, **audio})
                                            threading.Thread(target=_tts_timeout, daemon=True).start()
                                            state._responder_stats["last_call_ts"] = time.time()
                                            state._responder_stats["is_processing"] = False
                                            return
                                        if "punted" not in err.lower():
                                            print(f"[BRAIN] API stream error: {err}")
                                        full = state.brain_responder.respond(text, bstate)
                                        _send({"type": "brain_response_delta",
                                               "response_id": response_id,
                                               "text": full})
                                        _send({"type": "brain_response_end",
                                               "response_id": response_id,
                                               "response": full})
                                        def _tts_err(txt=full, rid=response_id):
                                            audio = _tts_synthesize_b64(txt)
                                            if audio:
                                                _send({"type": "brain_audio",
                                                       "response_id": rid, **audio})
                                        threading.Thread(target=_tts_err, daemon=True).start()
                                  state._responder_stats["last_call_ts"] = time.time()
                                  state._responder_stats["is_processing"] = False
                                  print(f"[BRAIN] Streamed response ready: {full[:80]}")
                                  return
                                finally:
                                  if _got_lock:
                                      try: state._responder_lock.release()
                                      except RuntimeError: pass

                            # Slow path: subprocess fallback
                            response = state.brain_responder.respond(text, bstate)
                            state._responder_stats["last_call_ts"] = time.time()
                            state._responder_stats["is_processing"] = False
                            print(f"[BRAIN] Response ready: {response[:80]}")
                            _send({"type": "brain_response",
                                   "user": text, "response": response,
                                   "response_id": response_id,
                                   "audio_pending": True})
                            def _tts_slow(txt=response, rid=response_id):
                                audio = _tts_synthesize_b64(txt)
                                if audio:
                                    _send({"type": "brain_audio",
                                           "response_id": rid, **audio})
                            threading.Thread(target=_tts_slow, daemon=True).start()
                        except Exception as e:
                            state._responder_stats["is_processing"] = False
                            import traceback
                            log.warning(f"[BRAIN] Response error: {e}", exc_info=True)
                            traceback.print_exc()
                    threading.Thread(target=_respond_async, daemon=True).start()
                elif msg.get("type") == "tool_confirm":
                    cid = msg.get("confirm_id") or ""
                    approved = bool(msg.get("approved"))
                    if cid:
                        ok = _resolve_confirm(cid, approved)
                        if not ok:
                            print(f"[CONFIRM] no pending entry for {cid}")
                elif msg.get("type") == "webcam_state":
                    ready = bool(msg.get("ready"))
                    with state._webcam_clients_lock:
                        state._webcam_clients[id(ws)] = ready
                        n_ready = sum(1 for v in state._webcam_clients.values() if v)
                        n_total = len(state._webcam_clients)
                    print(f"[WEBCAM] state from ws={id(ws):x}: ready={ready} "
                          f"(now {n_ready}/{n_total} clients ready)")
                elif msg.get("type") == "webcam_capture_response":
                    rid = msg.get("request_id") or ""
                    payload = {
                        "image_b64": msg.get("image_b64") or "",
                        "width":     msg.get("width"),
                        "height":    msg.get("height"),
                    }
                    if rid:
                        _resolve_webcam(rid, payload)
                elif msg.get("type") == "command":
                    cmd = msg.get("cmd")
                    if cmd == "start_vision":
                        state.vision_encoder.start_webcam()
                    elif cmd == "stop_vision":
                        state.vision_encoder.stop_webcam()
                    elif cmd == "start_audio":
                        state.audio_encoder.start_microphone()
                    elif cmd == "stop_audio":
                        state.audio_encoder.stop_microphone()
                    elif cmd == "start_screen":
                        state.screen_observer.start()
                    elif cmd == "stop_screen":
                        state.screen_observer.stop()
                    elif cmd == "start_video":
                        if state.video_recorder:
                            state.video_recorder.start()
                    elif cmd == "stop_video":
                        if state.video_recorder:
                            state.video_recorder.stop()
                    elif cmd == "abort_response":
                        # Kill Leon's active response mid-stream.
                        # NOTE (2026-08-02 self-review): this is GLOBAL — any
                        # connected client (phone, second tab, stale
                        # reconnect) can abort the one shared responder, even
                        # mid-sentence for a DIFFERENT client's turn. That's
                        # a real suspect for the "cuts me off mid-talk"
                        # reports alongside the multi-socket duplicate-paint
                        # bug. Logging the origin socket here so the next
                        # occurrence can be traced to a specific client
                        # instead of guessed at. Real fix would be scoping
                        # abort to the client that owns the in-flight turn —
                        # deferred, don't want to change abort semantics
                        # unsupervised.
                        if state.brain_api_responder is not None:
                            state.brain_api_responder.abort()
                            state._responder_stats["is_processing"] = False
                            log.info(
                                f"[WS] abort_response from ws={id(ws):x} — "
                                f"killed active response ({len(state.connected_clients)} "
                                f"clients connected)"
                            )
                    elif cmd == "save":
                        save_brain(state.brain)
                    elif cmd == "load":
                        load_brain(state.brain)
        except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
            return

    try:
        sender_task = asyncio.create_task(_sender())
        receiver_task = asyncio.create_task(_receiver())
        done, pending = await asyncio.wait(
            {sender_task, receiver_task}, return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning(f"[WS] Error: {e}", exc_info=True)
    finally:
        state.connected_clients.discard(ws)
        with state._webcam_clients_lock:
            state._webcam_clients.pop(id(ws), None)
        print(f"[WS] Client disconnected ({len(state.connected_clients)} total)")


# ── Read-only brain viewer (landing page, no auth) ────────────
# Sends init positions + state at 10Hz. Accepts no commands.
# Used by the landing page to show the LIVE brain to visitors.

@router.websocket("/ws/brain-view")
async def brain_view_endpoint(ws: WebSocket):
    """Read-only brain visualization stream for the landing page."""
    await ws.accept()
    log.info("[WS] Brain viewer connected")

    # Send neuron positions
    try:
        try:
            meta, blob = state.brain.get_neuron_positions_binary()
            await ws.send_json({"type": "init_meta", **meta})
            await ws.send_bytes(blob)
        except Exception:
            positions = state.brain.get_neuron_positions()
            await ws.send_json({"type": "init", "positions": positions})
    except Exception:
        pass

    # Stream state at 10Hz (half the dashboard rate — saves bandwidth)
    try:
        while True:
            brain_state = state.brain.get_state()
            await ws.send_json({"type": "state", "data": brain_state})
            await asyncio.sleep(0.1)
    except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
        pass
    except Exception as e:
        log.warning(f"[WS] Brain viewer error: {e}")
    finally:
        log.info("[WS] Brain viewer disconnected")
