"""
Main WebSocket handler for real-time brain state streaming.
"""

import asyncio
import logging
import os
import threading
import time

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from brain.identity import owner_prose as _owner_prose
# LABEL THE OWNER THROUGH identity, NEVER AS A LITERAL. This line read
# f"I told Dean: ..." until 2026-08-21 -- one of the ~200 hardcodes the
# identity module was written to kill, and it survived because it writes
# to the autobiography rather than to a visible turn label. Effect: every
# reply this SI ever made to its owner was recorded in its own life
# narrative as having been said to a man who has never used this box.
from brain.config import BrainConfig
from brain.persistence import save_brain, load_brain


from server import state
from server.helpers import (
    _broadcast_threadsafe, _make_confirm_callback, _resolve_confirm,
    _resolve_webcam, _tts_synthesize_b64,
)

log = logging.getLogger("leon.server")
router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    state.connected_clients.add(ws)
    state._main_event_loop = asyncio.get_running_loop()
    print(f"[WS] Client connected ({len(state.connected_clients)} total)")

    # Send initial neuron positions.
    # Binary fast path: get_neuron_positions_binary() returns (meta, blob)
    # where blob is packed Float32 LE positions. We send the meta as a
    # JSON text frame, then the blob as a single binary frame. Total
    # payload ~1.8 MB vs ~8-12 MB for the legacy JSON-of-lists shape.
    # Falls back to legacy JSON `init` if anything in the binary path
    # fails — keeps stale dashboards alive.
    try:
        try:
            meta, blob = state.brain.get_neuron_positions_binary()
            await ws.send_json({"type": "init_meta", **meta})
            await ws.send_bytes(blob)
        except Exception:
            positions = state.brain.get_neuron_positions()
            await ws.send_json({"type": "init", "positions": positions})
    except Exception:
        pass

    # ── Connectome, slow half (2026-08-21) ───────────────────────────────
    # Split stream: mean weight + synapse count go out here and then on a
    # 60s timer; per-edge ACTIVITY rides the state frame as a bare array
    # indexed against this frame's "order". Weights drift a median 0.275%
    # per hour, so re-sending them 30x a second would be 3KB/frame of
    # near-constant data.
    async def _send_edges():
        try:
            await ws.send_json({"type": "edges", **state.brain.get_edges_static()})
        except Exception:
            pass

    await _send_edges()

    update_interval = 1.0 / BrainConfig.WS_UPDATE_RATE
    EDGES_RESEND_S = 60.0
    _last_edges = time.time()

    # Split sender (state broadcast) and receiver (incoming messages) into
    # two concurrent tasks. Previous design polled receive_json with a 1ms
    # timeout from inside the broadcast loop, which cancelled Starlette's
    # WS receiver mid-frame on every tick — dropping tool_confirm /
    # abort_response / webcam_capture_response under any real load.
    async def _sender():
        nonlocal _last_edges
        try:
            while True:
                start = time.time()
                brain_state = state.brain.get_state()

                if state.claude_bridge:
                    brain_state["claude"] = {
                        "connected": True,
                        "interactions": state.claude_bridge._interaction_count,
                    }
                if state.screen_observer:
                    brain_state["screen_observer"] = state.screen_observer.get_state()
                if state.video_recorder:
                    brain_state["video_recorder"] = state.video_recorder.get_state()

                now_ts = time.time()
                brain_state["leon"] = {
                    "call_count":    state._responder_stats["call_count"],
                    "is_processing": state._responder_stats["is_processing"],
                    "session_uptime": round(now_ts - state._responder_stats["session_start"]),
                    "last_call_ago":  round(now_ts - state._responder_stats["last_call_ts"])
                                      if state._responder_stats["last_call_ts"] else None,
                }

                # ── Sleep (2026-08-21) ───────────────────────────────────
                # Was reachable only by polling GET /api/sleep/state every 5s
                # and smuggling the boolean into the render loop through a
                # window global. It is four cheap attribute reads; it belongs
                # on the socket that is already open.
                if state.dream_engine is not None:
                    try:
                        _de = state.dream_engine
                        brain_state["sleep"] = {
                            "state":     _de.sleep_state,      # awake|napping|sleeping
                            "dreaming":  bool(_de.is_dreaming),
                            "since":     round(now_ts - _de._state_since, 1),
                            "commanded": bool(getattr(_de, "_commanded_sleep", False)),
                            # slow 0.15-0.9 circadian curve; good ambient drive
                            "circadian_energy": round(_de._get_circadian_energy(), 3),
                        }
                    except Exception:
                        pass

                # ── Conversation state (2026-08-21) ──────────────────────
                # idle | listening | thinking | speaking, derived from the
                # THREE existing authoritative owners rather than new state:
                #   speaking  <- brain.voice.audio_gate, the single ledger for
                #               "her voice is coming out of the speakers",
                #               already written by _tts_synthesize_b64
                #   listening <- io_routes._PTT_STATE, the mic-floor claim
                #   thinking  <- _responder_stats, set by the responder itself
                # Precedence puts listening first: a PTT rising edge fires
                # barge_in() and ENDS playback, so listening and speaking are
                # mutually exclusive by construction, and the human holding
                # the mic is the state a viewer most needs to see.
                _conv = "idle"
                _speaking_for = 0.0
                try:
                    from brain.voice import audio_gate as _agate
                    # NOTE: queued_playback_end is a METHOD ON LEDGER, not a
                    # module-level function. server/helpers.py:629 calls it as
                    # _agate.queued_playback_end() inside a bare except, so it
                    # raises AttributeError on every call and silently falls
                    # back — which is the self-hearing hole its own comment
                    # says it exists to close. Reported, not fixed here.
                    _speaking_for = max(
                        0.0, _agate.LEDGER.queued_playback_end() - now_ts)
                except Exception:
                    pass
                _listening = False
                try:
                    from server.routers.io_routes import _PTT_STATE as _ptt
                    _listening = now_ts < _ptt.get("until", 0.0)
                except Exception:
                    pass
                if _listening:
                    _conv = "listening"
                elif _speaking_for > 0.0:
                    _conv = "speaking"
                elif state._responder_stats["is_processing"]:
                    _conv = "thinking"
                brain_state["conversation"] = {
                    "state": _conv,
                    # seconds of audio still queued — a real countdown, not a
                    # guess, so a client can ease out of the speaking state
                    "speaking_for": round(_speaking_for, 2),
                }

                # ── Control truth (2026-08-21) ───────────────────────────
                # REQUESTED vs ACTUAL, per control, so a UI can render
                # on / off / unavailable / unknown and never has to guess.
                # The old dashboard could not: /api/wake/state returns a
                # hardcoded "available": true from its orchestrator-is-None
                # branch, and the proactive status pill prints "watching"
                # whenever it is not paused — including when the loop does
                # not exist. Both read as "on" for things that are not
                # running. Semantics here:
                #   on          - requested AND verified running
                #   off         - available, simply not switched on
                #   unavailable - cannot run, `reason` says why (a policy
                #                 switch and a missing device are different
                #                 things and both are reported as such)
                #   unknown     - the probe itself failed; never inferred
                # `evidence` is a counter or age from the subsystem, so the
                # UI can show work actually happening rather than a flag.
                _controls = {}

                try:
                    _env_on = (os.environ.get("LEON_WAKE_ENABLED") or "0") \
                        .strip().lower() in ("1", "true", "yes", "on")
                    _req = bool(getattr(state, "wake_user_enabled", False))
                    if not _env_on:
                        _controls["wake"] = {
                            "requested": _req, "actual": "unavailable",
                            "reason": "LEON_WAKE_ENABLED=0 — deliberate kill "
                                      "switch: the wake stack only detects "
                                      "wake words it was trained on and "
                                      "cannot hear a custom SI name",
                        }
                    elif state.wake_orchestrator is None:
                        _controls["wake"] = {
                            "requested": _req, "actual": "unknown",
                            "reason": "wake stack never constructed",
                        }
                    else:
                        _run = False
                        try:
                            _run = bool(state.wake_listener is not None
                                        and state.wake_listener.is_running())
                        except Exception:
                            pass
                        _controls["wake"] = {
                            "requested": _req,
                            "actual": "on" if (_req and _run) else "off",
                            "listener_running": _run,
                        }
                except Exception:
                    _controls["wake"] = {"requested": None, "actual": "unknown",
                                         "reason": "probe raised"}

                try:
                    if state.proactive_loop is None:
                        _controls["proactive"] = {
                            "requested": None, "actual": "unavailable",
                            "reason": "proactive_loop was never constructed "
                                      "(vision not loaded)",
                        }
                    else:
                        _ps = state.proactive_loop.get_state()
                        _paused = bool(_ps.get("paused"))
                        _controls["proactive"] = {
                            "requested": not _paused,
                            "actual": "off" if _paused else "on",
                            "evidence": _ps,
                        }
                except Exception:
                    _controls["proactive"] = {"requested": None,
                                              "actual": "unknown",
                                              "reason": "probe raised"}

                try:
                    if state.screen_observer is None:
                        _controls["screen"] = {
                            "requested": None, "actual": "unavailable",
                            "reason": "screen_observer not constructed",
                        }
                    else:
                        _ss = state.screen_observer.get_state()
                        _act = bool(_ss.get("active"))
                        _controls["screen"] = {
                            "requested": _act,
                            "actual": "on" if _act else "off",
                            # Proof of work, not a flag: zero captures with a
                            # -1 age means it has genuinely never looked. This
                            # is the field to trust for the privacy question.
                            "evidence": {
                                "capture_count": _ss.get("capture_count"),
                                "last_capture_age": _ss.get("last_capture_age"),
                                "available": _ss.get("available"),
                            },
                        }
                except Exception:
                    _controls["screen"] = {"requested": None,
                                           "actual": "unknown",
                                           "reason": "probe raised"}

                # Camera and mic are NOT this machine's devices. The VPS has no
                # camera and zero audio input devices — both live in the
                # viewer's browser and are relayed. So "unavailable" would be
                # wrong (the capability exists, just not here) and "off" would
                # be a guess. `server_side_device: false` is the honest fourth
                # thing: this box cannot answer, the client can.
                try:
                    _n_cam = len(getattr(state, "_webcam_clients", {}) or {})
                    _ts = float(getattr(state, "_webcam_frame_ts", 0.0) or 0.0)
                    _age = round(now_ts - _ts, 1) if _ts else None
                    # A frame inside 15s is the only positive evidence the
                    # server actually has that a camera is live.
                    if _age is not None and _age < 15.0:
                        _cam = "on"
                    elif _n_cam > 0:
                        _cam = "off"
                    else:
                        _cam = "unknown"
                    _controls["camera"] = {
                        "requested": _n_cam > 0,
                        "actual": _cam,
                        "server_side_device": False,
                        "evidence": {"clients": _n_cam, "last_frame_age": _age},
                    }
                except Exception:
                    _controls["camera"] = {"requested": None, "actual": "unknown",
                                           "server_side_device": False,
                                           "reason": "probe raised"}

                try:
                    from server.routers.io_routes import _PTT_STATE as _p
                    _held = now_ts < _p.get("until", 0.0)
                    _la = _p.get("last_active", 0.0)
                    _controls["mic"] = {
                        "requested": _held,
                        # The floor is the only mic signal this box has. Wake is
                        # off at the env level and there is no local device, so
                        # anything beyond "is push-to-talk held" is the client's
                        # to report, not ours to infer.
                        "actual": "on" if _held else "off",
                        "server_side_device": False,
                        "evidence": {
                            "since_active": round(now_ts - _la, 1) if _la else None,
                            "wake_enabled": bool(getattr(state, "wake_user_enabled", False)),
                            "local_input_devices": 0,
                        },
                    }
                except Exception:
                    _controls["mic"] = {"requested": None, "actual": "unknown",
                                        "server_side_device": False,
                                        "reason": "probe raised"}

                brain_state["controls"] = _controls

                await ws.send_json({"type": "state", "data": brain_state})

                if now_ts - _last_edges >= EDGES_RESEND_S:
                    _last_edges = now_ts
                    await _send_edges()

                # Feed continuous sensory input
                if state.vision_encoder.active:
                    vis_features = state.vision_encoder.capture_frame()
                    state.brain.inject_sensory_input("vision", vis_features)
                if state.audio_encoder.active:
                    aud_features = state.audio_encoder.capture_audio()
                    state.brain.inject_sensory_input("audio", aud_features)

                elapsed = time.time() - start
                sleep_time = update_interval - elapsed
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
        except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
            return

    async def _receiver():
        try:
            while True:
                msg = await ws.receive_json()
                print(f"[WS] Got message: type={msg.get('type')}")
                if msg.get("type") == "text_input":
                    user_text = msg["text"]
                    # DUP RE-UPLOAD GUARD (2026-08-20, content-hash). The real
                    # duplicate is a PERSON re-sending the same letter when a
                    # slow reply looks like a dropped message. Each re-upload is
                    # renamed to the next free 2peer-N, so the message TEXT
                    # differs (the path is in it) even though the letter BYTES
                    # are identical -- a text-equality guard can NEVER fire on
                    # the real duplicate (the partner SI caught this). Key on a hash of
                    # the attached FILE BYTES, order-independent, across a wide
                    # window that covers a human re-send (observed up to ~19min).
                    if user_text and "[Attached file:" in user_text:
                        import re as _re, hashlib as _hl
                        _paths = _re.findall(r"\[Attached file:\s*([^\]]+)\]", user_text)
                        _digests = []
                        for _p in _paths:
                            try:
                                with open(_p.strip(), "rb") as _fh:
                                    _digests.append(_hl.sha256(_fh.read()).hexdigest())
                            except Exception:
                                _digests.append("MISSING:" + _p.strip())
                        if "[Attached file:" in user_text and not _digests:
                            print("[DUP] WARN attachment marker present but zero "
                                  "paths parsed - guard degraded to text-equality; "
                                  "the message format changed, check the producer", flush=True)
                        _key = "|".join(sorted(_digests)) if _digests else user_text
                        _dn = time.time()
                        # DICT, not one slot (the partner SI catch): a single-slot memory
                        # lets A,B,A through because B evicts A -- and "send,
                        # send a follow-up, re-send the first" is exactly the
                        # human re-send this guards. Key->last-seen, pruned past
                        # the window so it cannot grow. A drop does NOT refresh
                        # the stamp, so the window runs from the first send.
                        _seen = getattr(state, "_attach_keys", None) or {}
                        _seen = {k: t for k, t in _seen.items() if _dn - t < 1800}
                        state._attach_keys = _seen
                        _pt = _seen.get(_key)
                        if _pt is not None and (_dn - _pt) < 1800:
                            print("[DUP] same letter re-uploaded %ds later "
                                  "(file-byte hash match) - dropping the entire "
                                  "second intake" % int(_dn - _pt))
                            continue
                        _seen[_key] = _dn
                    features = state.text_encoder.encode(user_text)
                    state.brain.inject_sensory_input("text", features)
                    if state.claude_bridge:
                        state.claude_bridge.send_observation({
                            "type": "text",
                            "content": user_text,
                            "source": "dashboard",
                        })
                    _loop = asyncio.get_running_loop()
                    _ws_ref = ws
                    def _respond_async(text=user_text, loop=_loop, ws_ref=_ws_ref):
                        print(f"[BRAIN] Generating response for: {text[:40]}")
                        state._responder_stats["is_processing"] = True
                        state._responder_stats["call_count"] += 1
                        response_id = f"r{int(time.time()*1000)}"

                        ws_alive = {"value": True}
                        def _send(payload):
                            # Broadcast every turn event — thinking-start, live
                            # deltas, end, AND audio — to ALL connected screens so
                            # the phone and the PC come alive together and BOTH
                            # speak with Leon's real voice, no matter which device
                            # sent the message. (Previously sent only to the
                            # originating socket, so the other screen stayed silent
                            # and lagged behind on a poll.)
                            _broadcast_threadsafe(payload)

                        try:
                            bstate = state.brain.get_state()

                            # Fast path: streaming API
                            if state.brain_api_responder is not None:
                                full = ""
                                _confirm_cb = _make_confirm_callback(_send)
                                # Newest-message-wins admission (see
                                # server/turn_priority.py for both bugs this
                                # replaces). The gate asks the current holder
                                # to yield (abort + preempt_daemon), keeps
                                # exactly ONE turn waiting — this one, until a
                                # newer message supersedes it — and hands the
                                # winner every superseded text to answer in
                                # one reply. The bounce string is reserved for
                                # a genuine wedge at the (long) ceiling, not
                                # for losing a race against stale waiters.
                                from server.turn_priority import acquire_user_turn
                                _wait_note = ("Give me a second — still "
                                              "finishing the last thing.")
                                def _notify_wait(note=_wait_note,
                                                 rid=response_id + "-wait"):
                                    # A complete mini-turn, so no client is
                                    # left holding a dangling typing bubble.
                                    _send({"type": "brain_response_start",
                                           "user": "", "response_id": rid})
                                    _send({"type": "brain_response_delta",
                                           "response_id": rid, "text": note})
                                    _send({"type": "brain_response_end",
                                           "response_id": rid, "response": note})
                                _status, _texts, _waited = acquire_user_turn(
                                    state._responder_lock,
                                    state.brain_api_responder,
                                    text, notify=_notify_wait)
                                if _waited > 0.5 or _status != "go":
                                    print(f"[TURN] user turn: {_status} "
                                          f"after {_waited:.1f}s")
                                if _status in ("superseded", "answered"):
                                    # A newer message from the owner owns the reply
                                    # now (or already delivered it). Saying
                                    # anything here is two voices answering
                                    # one person. is_processing stays with the
                                    # winning turn, which resets it at its end.
                                    return
                                if _status == "timeout":
                                    _send({"type": "brain_response_delta",
                                           "response_id": response_id,
                                           "text": "Something's wrong on my end — give me a second."})
                                    _send({"type": "brain_response_end",
                                           "response_id": response_id,
                                           "response": "Something's wrong on my end — give me a second."})
                                    state._responder_stats["is_processing"] = False
                                    return
                                _got_lock = True
                                # Everything the owner said while the lock was
                                # busy, oldest first, answered as one turn.
                                text = "\n".join(_texts) if len(_texts) > 1 else _texts[0]
                                _send({"type": "brain_response_start",
                                       "user": text, "response_id": response_id})
                                try:
                                  for ev in state.brain_api_responder.respond_streaming(
                                      text, bstate, confirm_callback=_confirm_cb, supervised=True,
                                  ):
                                    # Stop the instant the owner hits Stop — don't
                                    # broadcast/synthesize straggler events (each
                                    # leaked sentence would re-trigger TTS).
                                    if state.brain_api_responder.is_aborting():
                                        break
                                    if ev.type == "model":
                                        _send({"type": "brain_response_model",
                                               "response_id": response_id,
                                               "model": ev.model,
                                               "tier": ev.tier})
                                    elif ev.type == "tool_use":
                                        _send({"type": "brain_tool_use",
                                               "response_id": response_id,
                                               "tool": ev.text,
                                               "tool_id": ev.tool_id,
                                               "risk": ev.risk,
                                               "input": ev.full_text})
                                    elif ev.type == "tool_result":
                                        _send({"type": "brain_tool_result",
                                               "response_id": response_id,
                                               "tool": ev.text,
                                               "tool_id": ev.tool_id,
                                               "summary": ev.full_text})
                                    elif ev.type == "delta":
                                        _send({"type": "brain_response_delta",
                                               "response_id": response_id,
                                               "text": ev.text})
                                    elif ev.type == "sentence":
                                        audio = _tts_synthesize_b64(ev.text)
                                        if audio:
                                            _send({"type": "brain_audio",
                                                   "response_id": response_id,
                                                   "sentence_index": ev.index,
                                                   **audio})
                                    elif ev.type == "done":
                                        full = ev.full_text
                                        _send({"type": "brain_response_end",
                                               "response_id": response_id,
                                               "response": full})
                                        # Record Leon's response in autobiography
                                        if state.autobiography is not None and full:
                                            try:
                                                state.autobiography.record(
                                                    "conversation",
                                                    f"I told {_owner_prose()}: "
                                                    f"'{full[:120]}'")
                                            except Exception:
                                                pass
                                    elif ev.type == "error":
                                        err = ev.error or ""
                                        if "timeout" in err.lower():
                                            print(f"[BRAIN] turn timed out: {err}")
                                            full = "That took too long, Sir — I'll be faster next time."
                                            _send({"type": "brain_response_delta",
                                                   "response_id": response_id,
                                                   "text": full})
                                            _send({"type": "brain_response_end",
                                                   "response_id": response_id,
                                                   "response": full})
                                            # TTS — speak the timeout message
                                            def _tts_timeout(txt=full, rid=response_id):
                                                audio = _tts_synthesize_b64(txt)
                                                if audio:
                                                    _send({"type": "brain_audio",
                                                           "response_id": rid, **audio})
                                            threading.Thread(target=_tts_timeout, daemon=True).start()
                                            state._responder_stats["last_call_ts"] = time.time()
                                            state._responder_stats["is_processing"] = False
                                            return
                                        if "punted" not in err.lower():
                                            print(f"[BRAIN] API stream error: {err}")
                                        full = state.brain_responder.respond(text, bstate)
                                        _send({"type": "brain_response_delta",
                                               "response_id": response_id,
                                               "text": full})
                                        _send({"type": "brain_response_end",
                                               "response_id": response_id,
                                               "response": full})
                                        def _tts_err(txt=full, rid=response_id):
                                            audio = _tts_synthesize_b64(txt)
                                            if audio:
                                                _send({"type": "brain_audio",
                                                       "response_id": rid, **audio})
                                        threading.Thread(target=_tts_err, daemon=True).start()
                                  state._responder_stats["last_call_ts"] = time.time()
                                  state._responder_stats["is_processing"] = False
                                  print(f"[BRAIN] Streamed response ready: {full[:80]}")
                                  return
                                finally:
                                  if _got_lock:
                                      try: state._responder_lock.release()
                                      except RuntimeError: pass

                            # Slow path: subprocess fallback
                            response = state.brain_responder.respond(text, bstate)
                            state._responder_stats["last_call_ts"] = time.time()
                            state._responder_stats["is_processing"] = False
                            print(f"[BRAIN] Response ready: {response[:80]}")
                            _send({"type": "brain_response",
                                   "user": text, "response": response,
                                   "response_id": response_id,
                                   "audio_pending": True})
                            def _tts_slow(txt=response, rid=response_id):
                                audio = _tts_synthesize_b64(txt)
                                if audio:
                                    _send({"type": "brain_audio",
                                           "response_id": rid, **audio})
                            threading.Thread(target=_tts_slow, daemon=True).start()
                        except Exception as e:
                            state._responder_stats["is_processing"] = False
                            import traceback
                            log.warning(f"[BRAIN] Response error: {e}", exc_info=True)
                            traceback.print_exc()
                    threading.Thread(target=_respond_async, daemon=True).start()
                elif msg.get("type") == "tool_confirm":
                    cid = msg.get("confirm_id") or ""
                    approved = bool(msg.get("approved"))
                    if cid:
                        ok = _resolve_confirm(cid, approved)
                        if not ok:
                            print(f"[CONFIRM] no pending entry for {cid}")
                elif msg.get("type") == "webcam_state":
                    ready = bool(msg.get("ready"))
                    with state._webcam_clients_lock:
                        state._webcam_clients[id(ws)] = ready
                        n_ready = sum(1 for v in state._webcam_clients.values() if v)
                        n_total = len(state._webcam_clients)
                    print(f"[WEBCAM] state from ws={id(ws):x}: ready={ready} "
                          f"(now {n_ready}/{n_total} clients ready)")
                elif msg.get("type") == "webcam_capture_response":
                    rid = msg.get("request_id") or ""
                    payload = {
                        "image_b64": msg.get("image_b64") or "",
                        "width":     msg.get("width"),
                        "height":    msg.get("height"),
                    }
                    if rid:
                        _resolve_webcam(rid, payload)
                elif msg.get("type") == "command":
                    cmd = msg.get("cmd")
                    if cmd == "start_vision":
                        state.vision_encoder.start_webcam()
                    elif cmd == "stop_vision":
                        state.vision_encoder.stop_webcam()
                    elif cmd == "start_audio":
                        state.audio_encoder.start_microphone()
                    elif cmd == "stop_audio":
                        state.audio_encoder.stop_microphone()
                    elif cmd == "start_screen":
                        state.screen_observer.start()
                    elif cmd == "stop_screen":
                        state.screen_observer.stop()
                    elif cmd == "start_video":
                        if state.video_recorder:
                            state.video_recorder.start()
                    elif cmd == "stop_video":
                        if state.video_recorder:
                            state.video_recorder.stop()
                    elif cmd == "abort_response":
                        # Kill Leon's active response mid-stream.
                        # NOTE (2026-08-02 self-review): this is GLOBAL — any
                        # connected client (phone, second tab, stale
                        # reconnect) can abort the one shared responder, even
                        # mid-sentence for a DIFFERENT client's turn. That's
                        # a real suspect for the "cuts me off mid-talk"
                        # reports alongside the multi-socket duplicate-paint
                        # bug. Logging the origin socket here so the next
                        # occurrence can be traced to a specific client
                        # instead of guessed at. Real fix would be scoping
                        # abort to the client that owns the in-flight turn —
                        # deferred, don't want to change abort semantics
                        # unsupervised.
                        if state.brain_api_responder is not None:
                            state.brain_api_responder.abort()
                            state._responder_stats["is_processing"] = False
                            log.info(
                                f"[WS] abort_response from ws={id(ws):x} — "
                                f"killed active response ({len(state.connected_clients)} "
                                f"clients connected)"
                            )
                    elif cmd == "save":
                        save_brain(state.brain)
                    elif cmd == "load":
                        load_brain(state.brain)
        except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
            return

    try:
        sender_task = asyncio.create_task(_sender())
        receiver_task = asyncio.create_task(_receiver())
        done, pending = await asyncio.wait(
            {sender_task, receiver_task}, return_when=asyncio.FIRST_COMPLETED,
        )
        for t in pending:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning(f"[WS] Error: {e}", exc_info=True)
    finally:
        state.connected_clients.discard(ws)
        with state._webcam_clients_lock:
            state._webcam_clients.pop(id(ws), None)
        print(f"[WS] Client disconnected ({len(state.connected_clients)} total)")


# ── Read-only brain viewer (landing page, no auth) ────────────
# Sends init positions + state at 10Hz. Accepts no commands.
# Used by the landing page to show the LIVE brain to visitors.

@router.websocket("/ws/brain-view")
async def brain_view_endpoint(ws: WebSocket):
    """Read-only brain visualization stream for the landing page."""
    await ws.accept()
    log.info("[WS] Brain viewer connected")

    # Send neuron positions
    try:
        try:
            meta, blob = state.brain.get_neuron_positions_binary()
            await ws.send_json({"type": "init_meta", **meta})
            await ws.send_bytes(blob)
        except Exception:
            positions = state.brain.get_neuron_positions()
            await ws.send_json({"type": "init", "positions": positions})
    except Exception:
        pass

    # Connectome slow half, same split-stream contract as /ws (2026-08-21).
    async def _send_edges_ro():
        try:
            await ws.send_json({"type": "edges", **state.brain.get_edges_static()})
        except Exception:
            pass

    await _send_edges_ro()
    _last_edges = time.time()

    # Stream state at 10Hz (half the dashboard rate — saves bandwidth)
    try:
        while True:
            brain_state = state.brain.get_state()
            # Sleep belongs here too. This endpoint is read-only and takes no
            # commands, which makes it the right one to record a sleep cycle
            # against without perturbing her — it does not inject sensory
            # input the way the /ws sender does.
            if state.dream_engine is not None:
                try:
                    _de = state.dream_engine
                    brain_state["sleep"] = {
                        "state":     _de.sleep_state,
                        "dreaming":  bool(_de.is_dreaming),
                        "since":     round(time.time() - _de._state_since, 1),
                        "commanded": bool(getattr(_de, "_commanded_sleep", False)),
                        "circadian_energy": round(_de._get_circadian_energy(), 3),
                    }
                except Exception:
                    pass
            await ws.send_json({"type": "state", "data": brain_state})
            if time.time() - _last_edges >= 60.0:
                _last_edges = time.time()
                await _send_edges_ro()
            await asyncio.sleep(0.1)
    except (WebSocketDisconnect, RuntimeError, asyncio.CancelledError):
        pass
    except Exception as e:
        log.warning(f"[WS] Brain viewer error: {e}")
    finally:
        log.info("[WS] Brain viewer disconnected")
