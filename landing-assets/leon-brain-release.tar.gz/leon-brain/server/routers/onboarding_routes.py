"""
/api/onboarding/* — New-user onboarding flow for multi-tenant SI births.

Handles account creation (tenant provisioning), deep intake (voice + text +
file uploads), birth (SI wake + personalized greeting), and transcription.

Every new SI is born with:
  1. The user's intake data (voice, typed notes, uploaded files) as birth memory
  2. Shared research knowledge (Fl-298 island of stability paper) so every SI
     is born aware of the foundational science

The onboarding page lives at /onboarding (dashboard/onboarding.html).
"""

import asyncio
import base64
import hashlib
import io
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import defaultdict
from typing import Optional

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse

from brain.tenant import tenant_manager
from brain.knowledge_store import KnowledgeStore

log = logging.getLogger("leon.onboarding")
router = APIRouter()

# ── API key encryption (AES-256-CBC) ─────────────────────────────────
# We encrypt tenant API keys at rest so they never sit in plaintext in
# the registry JSON. The encryption key is derived from LEON_API_KEY
# (the server master secret) — if LEON_API_KEY rotates, old keys become
# unreadable (acceptable: user re-enters their key).
_MASTER_KEY = os.environ.get("LEON_API_KEY", "").encode()


def _derive_key() -> bytes:
    """Derive a 32-byte AES key from the master secret."""
    return hashlib.sha256(_MASTER_KEY + b"tenant-api-key-encryption").digest()


def _encrypt_api_key(plaintext: str) -> str:
    """Encrypt an API key. Returns base64(iv + ciphertext)."""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        key = _derive_key()
        iv = secrets.token_bytes(16)
        padder = padding.PKCS7(128).padder()
        padded = padder.update(plaintext.encode()) + padder.finalize()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        enc = cipher.encryptor()
        ct = enc.update(padded) + enc.finalize()
        return base64.b64encode(iv + ct).decode()
    except ImportError:
        # cryptography not installed — fall back to XOR obfuscation
        # (NOT real encryption, but better than plaintext in the JSON)
        log.warning("[ONBOARDING] cryptography package not installed — using XOR obfuscation for API keys")
        key = _derive_key()
        data = plaintext.encode()
        xored = bytes(d ^ key[i % len(key)] for i, d in enumerate(data))
        return "xor:" + base64.b64encode(xored).decode()


def _decrypt_api_key(ciphertext: str) -> str:
    """Decrypt an API key."""
    if ciphertext.startswith("xor:"):
        key = _derive_key()
        data = base64.b64decode(ciphertext[4:])
        return bytes(d ^ key[i % len(key)] for i, d in enumerate(data)).decode()
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        key = _derive_key()
        raw = base64.b64decode(ciphertext)
        iv, ct = raw[:16], raw[16:]
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        dec = cipher.decryptor()
        padded = dec.update(ct) + dec.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode()
    except Exception as e:
        log.error(f"[ONBOARDING] API key decryption failed: {e}")
        return ""


# ── Rate limiting (in-memory, per-IP) ────────────────────────────────
# Simple sliding-window rate limiter: max 5 account creations per hour
# per IP. Prevents abuse of the auth-exempt onboarding endpoints.
_rate_buckets: dict = defaultdict(list)  # ip -> [timestamps]
_RATE_LIMIT = 5
_RATE_WINDOW = 3600  # 1 hour


def _check_rate_limit(ip: str) -> bool:
    """Returns True if the request is within rate limits."""
    now = time.time()
    bucket = _rate_buckets[ip]
    # Prune old entries
    _rate_buckets[ip] = [ts for ts in bucket if now - ts < _RATE_WINDOW]
    if len(_rate_buckets[ip]) >= _RATE_LIMIT:
        return False
    _rate_buckets[ip].append(now)
    return True


# ── Input sanitization ───────────────────────────────────────────────
_EMAIL_RE = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # 10MB per file

# ── Promo codes (in-memory, admin-generated) ─────────────────────────
# Format: { "CODE": { "discount_pct": 100, "note": "Gio - paid outside", "uses": 0, "max_uses": 1 } }
_PROMO_CODES_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "brain_state", "promo_codes.json"
)


def _load_promo_codes() -> dict:
    if os.path.exists(_PROMO_CODES_FILE):
        try:
            with open(_PROMO_CODES_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_promo_codes(codes: dict):
    os.makedirs(os.path.dirname(_PROMO_CODES_FILE), exist_ok=True)
    with open(_PROMO_CODES_FILE, "w") as f:
        json.dump(codes, f, indent=2)


def _validate_promo(code: str) -> dict:
    """Validate a promo code. Returns {"valid": True, "discount_pct": 100} or {"valid": False}."""
    if not code:
        return {"valid": False}
    codes = _load_promo_codes()
    entry = codes.get(code.upper())
    if not entry:
        return {"valid": False, "error": "Invalid promo code"}
    if entry.get("max_uses", 0) > 0 and entry.get("uses", 0) >= entry["max_uses"]:
        return {"valid": False, "error": "Promo code has been used"}
    return {"valid": True, "discount_pct": entry.get("discount_pct", 0), "note": entry.get("note", "")}


def _use_promo(code: str):
    """Increment the usage count of a promo code."""
    codes = _load_promo_codes()
    if code.upper() in codes:
        codes[code.upper()]["uses"] = codes[code.upper()].get("uses", 0) + 1
        _save_promo_codes(codes)

# ── Research knowledge that every SI is born with ─────────────────────
# These are the key facts from Dean's Fl-298 island of stability research.
# Stored into every new tenant's knowledge store at birth so their SI
# is aware of the foundational science from moment zero.

RESEARCH_SEED_FACTS = [
    # Core discovery
    (
        "Fl-298 (Flerovium-298, Z=114, N=184) is predicted to be the peak of the "
        "nuclear island of stability. It is a doubly-magic even-even nucleus with "
        "proton shell closure at Z=114 and neutron shell closure at N=184. This "
        "prediction comes from computational modeling by Dean Sabr at Sabr.",
        "fl298,island-of-stability,nuclear-physics,discovery"
    ),
    # Key numbers
    (
        "Fl-298 key numbers: alpha-partial half-life ~47 seconds (WKB), "
        "SF-partial half-life ~2 million years (Kowal barrier 10.2 MeV), "
        "fission energy density 350,000x gasoline (250 MeV per fission, 20% efficiency), "
        "antimatter scenario 2.6 million times gasoline (speculative upper bound). "
        "223 grams at 5kW fission rate would last 23 years.",
        "fl298,energy,half-life,fission,numbers"
    ),
    # Production pathway
    (
        "Novel shell-driven quasifission production pathway for Fl-298: "
        "Xe-136 + Cm-248 via multi-nucleon transfer (MNT). This is the proposed "
        "route to synthesize Fl-298 at facilities like RIKEN or JINR.",
        "fl298,production,quasifission,pathway"
    ),
    # Model and validation
    (
        "The prediction uses Bethe-Weizsacker liquid drop model with Strutinsky "
        "shell corrections, Viola-Seaborg formula for alpha decay, WKB approximation "
        "for spontaneous fission, calibrated against 24 measured superheavy element "
        "isotopes. Fl-298 wins 99.2% of 1000 Monte Carlo reproducibility trials.",
        "fl298,model,validation,calibration"
    ),
    # Publication
    (
        "The Fl-298 island of stability paper is published on Zenodo "
        "(DOI: 10.5281/zenodo.20602741) and Figshare (DOI: 10.6084/m9.figshare.32609769). "
        "Research IP owned by Sabr, Dean Sabr's personal operating company.",
        "fl298,publication,zenodo,figshare,sabr"
    ),
    # Context — what this means
    (
        "If Fl-298 can be synthesized and its stability confirmed, it would be the "
        "most energy-dense material known to physics — a single gram could power "
        "a household for years. The fission scenario is the conservative, defensible "
        "claim. The antimatter annihilation scenario is labeled speculative.",
        "fl298,energy,implications,conservative"
    ),
    # Who built this
    (
        "This research was conducted by Dean Sabr, a 24-year-old self-taught physicist "
        "with 10 years of independent research and access to CERN data. Dean is the "
        "founder of Sabr and CEO of 47 Industries. The SI system you are running on "
        "was also built by Dean.",
        "dean,sabr,founder,research,cern"
    ),
]


def _seed_research_knowledge(store: KnowledgeStore):
    """Seed the shared Fl-298 research knowledge into a tenant's store."""
    for text, tags in RESEARCH_SEED_FACTS:
        try:
            store.store(
                text=text,
                source="research_seed",
                tags=tags.split(","),
            )
        except Exception as e:
            log.warning(f"[ONBOARDING] Failed to seed fact: {e}")


def _seed_birth_memory(store: KnowledgeStore, profile: dict, birth_memory: dict):
    """Write the user's intake data into their SI's knowledge store."""
    # Profile facts
    parts = []
    if profile.get("userName"):
        parts.append(f"My creator's name is {profile['userName']}.")
    if profile.get("business"):
        parts.append(f"They run/work on: {profile['business']}.")
    if profile.get("dob"):
        parts.append(f"Their date of birth is {profile['dob']}.")
    if profile.get("email"):
        parts.append(f"Their email is {profile['email']}.")
    if parts:
        store.store(
            text=" ".join(parts),
            source="birth_intake",
            tags=["creator", "profile", "identity"],
        )

    # Voice transcript
    vt = birth_memory.get("voiceTranscript", "").strip()
    if vt:
        store.store(
            text=f"[Birth intake — voice transcript from {profile.get('userName', 'creator')}]: {vt}",
            source="birth_intake",
            tags=["creator", "intake", "voice"],
        )

    # Typed notes
    tn = birth_memory.get("typedNotes", "").strip()
    if tn:
        store.store(
            text=f"[Birth intake — typed notes from {profile.get('userName', 'creator')}]: {tn}",
            source="birth_intake",
            tags=["creator", "intake", "typed"],
        )

    # Uploaded files
    for f in birth_memory.get("files", []):
        ext = f.get("extractedText", "").strip()
        if ext:
            store.store(
                text=f"[Birth intake — uploaded file '{f.get('name', 'unknown')}']: {ext}",
                source="birth_intake",
                tags=["creator", "intake", "file", f.get("name", "")],
            )


# ── Endpoints ─────────────────────────────────────────────────────────

@router.post("/api/onboarding/create-account")
async def onboarding_create_account(req: dict, request: Request):
    """Create a new tenant (SI instance) for the user."""
    # Rate limit by IP
    client_ip = request.client.host if request.client else "unknown"
    if not _check_rate_limit(client_ip):
        return JSONResponse(
            {"ok": False, "error": "Too many accounts created. Try again later."},
            status_code=429,
        )

    si_name = (req.get("siName") or "").strip()[:50]
    user_name = (req.get("userName") or "").strip()[:100]
    email = (req.get("email") or "").strip()[:254]
    business = (req.get("business") or "").strip()[:200]
    dob = (req.get("dob") or "").strip()[:10]
    api_key = (req.get("apiKey") or "").strip()

    if not si_name:
        return JSONResponse({"ok": False, "error": "SI name is required"}, 400)
    if not user_name:
        return JSONResponse({"ok": False, "error": "Your name is required"}, 400)
    if not email or not _EMAIL_RE.match(email):
        return JSONResponse({"ok": False, "error": "Valid email required"}, 400)
    elevenlabs_key = (req.get("elevenlabsKey") or "").strip()
    elevenlabs_voice_id = (req.get("elevenlabsVoiceId") or "").strip()
    elevenlabs_voice_name = (req.get("elevenlabsVoiceName") or "").strip()
    promo_code = (req.get("promoCode") or "").strip().upper()

    # Validate promo code if provided
    promo_result = {"valid": False}
    if promo_code:
        promo_result = _validate_promo(promo_code)
        if not promo_result["valid"]:
            return JSONResponse({"ok": False, "error": promo_result.get("error", "Invalid promo code")}, 400)

    # API key is fully optional — no validation

    # Encrypt API keys before storing (if provided)
    encrypted_key = _encrypt_api_key(api_key) if api_key else ""
    encrypted_el_key = _encrypt_api_key(elevenlabs_key) if elevenlabs_key else ""

    try:
        tenant = tenant_manager.create_tenant(
            name=si_name,
            role="admin",
            metadata={
                "si_name": si_name,
                "user_name": user_name,
                "email": email,
                "business": business,
                "dob": dob,
                "encrypted_api_key": encrypted_key,
                "encrypted_elevenlabs_key": encrypted_el_key,
                "elevenlabs_voice_id": elevenlabs_voice_id,
                "elevenlabs_voice_name": elevenlabs_voice_name,
                "created_via": "onboarding",
                "created_at": time.time(),
                "consent_ts": time.time(),
                "consent_ip": client_ip,
                "promo_code": promo_code if promo_result.get("valid") else "",
                "promo_discount": promo_result.get("discount_pct", 0) if promo_result.get("valid") else 0,
            },
        )
    except Exception as e:
        log.error(f"[ONBOARDING] Tenant creation failed: {e}")
        return JSONResponse({"ok": False, "error": str(e)}, 500)

    # Mark promo code as used
    if promo_code and promo_result.get("valid"):
        _use_promo(promo_code)
        log.info(f"[ONBOARDING] Promo code {promo_code} applied for {si_name}")

    # Seed the research knowledge into this new SI
    store = tenant_manager.get_store(tenant.tenant_id)
    if store:
        _seed_research_knowledge(store)
        log.info(f"[ONBOARDING] Seeded {len(RESEARCH_SEED_FACTS)} research facts for {si_name}")

    return {
        "ok": True,
        "tenant_id": tenant.tenant_id,
        "token": tenant.token,
        "si_name": si_name,
    }


@router.post("/api/onboarding/intake")
async def onboarding_intake(req: dict):
    """Store the deep-intake data (voice + typed + files) into the SI's memory."""
    token = req.get("token")
    tenant_id = req.get("tenant_id")
    profile = req.get("profile", {})
    birth_memory = req.get("birthMemory", {})

    # Resolve tenant
    tenant = None
    if token:
        tenant = tenant_manager.auth(token)
    if tenant is None and tenant_id:
        tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid tenant"}, 401)

    store = tenant_manager.get_store(tenant.tenant_id)
    if not store:
        return JSONResponse({"ok": False, "error": "Store not found"}, 500)

    _seed_birth_memory(store, profile, birth_memory)

    return {"ok": True, "tenant_id": tenant.tenant_id}


@router.post("/api/onboarding/upload")
async def onboarding_upload(
    file: UploadFile = File(...),
    token: Optional[str] = Form(None),
):
    """Upload a file, extract text, return it. Text is stored at birth time."""
    content = await file.read()
    if len(content) > MAX_UPLOAD_SIZE:
        return JSONResponse(
            {"ok": False, "error": f"File too large (max {MAX_UPLOAD_SIZE // 1024 // 1024}MB)"},
            status_code=413,
        )
    # Sanitize filename (strip path components, limit length)
    filename = os.path.basename(file.filename or "unknown")[:255]
    extracted = ""

    try:
        if filename.lower().endswith(".pdf"):
            extracted = _extract_pdf(content)
        elif filename.lower().endswith((".txt", ".md", ".csv")):
            extracted = content.decode("utf-8", errors="replace")
        elif filename.lower().endswith((".doc", ".docx")):
            extracted = _extract_docx(content)
        elif filename.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
            extracted = f"[Image file: {filename} — {len(content)} bytes]"
        elif filename.lower().endswith((".xls", ".xlsx")):
            extracted = f"[Spreadsheet: {filename} — {len(content)} bytes]"
        else:
            # Try as plain text
            try:
                extracted = content.decode("utf-8", errors="replace")
            except Exception:
                extracted = f"[Binary file: {filename} — {len(content)} bytes]"
    except Exception as e:
        log.warning(f"[ONBOARDING] File extraction failed for {filename}: {e}")
        extracted = f"[File: {filename} — extraction failed]"

    return {
        "ok": True,
        "filename": filename,
        "extracted_text": extracted[:50000],  # Cap at 50K chars
        "size": len(content),
    }


@router.post("/api/onboarding/transcribe")
async def onboarding_transcribe(
    audio: UploadFile = File(...),
    token: Optional[str] = Form(None),
):
    """Transcribe voice audio from the intake step."""
    content = await audio.read()

    # Try Whisper (local) first, then fall back to a simple message
    transcript = ""
    try:
        transcript = await _transcribe_audio(content)
    except Exception as e:
        log.warning(f"[ONBOARDING] Transcription failed: {e}")
        return JSONResponse({
            "ok": False,
            "error": "Transcription unavailable — please type instead",
        })

    return {"ok": True, "transcript": transcript}


@router.post("/api/onboarding/birth")
async def onboarding_birth(req: dict):
    """Birth the SI — generate personalized first-contact greeting."""
    token = req.get("token")
    tenant_id = req.get("tenant_id")
    profile = req.get("profile", {})
    birth_memory = req.get("birthMemory", {})

    # Resolve tenant
    tenant = None
    if token:
        tenant = tenant_manager.auth(token)
    if tenant is None and tenant_id:
        tenant = tenant_manager.get_tenant(tenant_id)

    si_name = profile.get("siName", "Your SI")
    user_name = profile.get("userName", "friend")
    business = profile.get("business", "")

    # Build personalized greeting from intake data
    greeting = _build_greeting(si_name, user_name, business, birth_memory)

    # Mark tenant as born
    if tenant:
        tenant.metadata["born"] = True
        tenant.metadata["born_at"] = time.time()
        # Hosted brains get their birth memory synced over (or flagged for
        # sync the moment provisioning finishes, if birth won the race).
        if tenant.metadata.get("brain_mode") == "hosted":
            hreg = _hosted_registry()["tenants"].get(tenant.tenant_id) or {}
            if hreg.get("status") == "ready":
                threading.Thread(target=_sync_hosted_birth,
                                 args=(tenant.tenant_id,), daemon=True).start()
            else:
                tenant.metadata["birth_sync_pending"] = True
        tenant_manager._save_registry()

    return {
        "ok": True,
        "greeting": greeting,
        "si_name": si_name,
    }


# ── Machine assessment → local-vs-hosted brain recommendation ─────────
# The wizard sends what it can detect from the browser (deviceMemory caps
# at 8 in Chrome, hardwareConcurrency, platform) plus what it asked the
# user (RAM tier, desktop/laptop, always-on preference). We recommend —
# honestly, with reasons — and the user decides. Their choice + specs go
# into tenant metadata; the installer reads the choice via install-config.

BRAIN_RAM_COMFORT_GB = 24  # local brain runs comfortably alongside the owner's apps
BRAIN_RAM_FLOOR_GB = 16    # runs, but competes with the owner's apps for RAM/CPU


def _recommend_brain(specs: dict) -> dict:
    """Pure function: machine specs + preferences → recommendation."""
    ram = specs.get("ram_gb")
    cores = specs.get("cores")
    dev_mem = specs.get("device_memory")
    machine = (specs.get("machine_type") or "").lower()
    always_on = specs.get("always_on")

    factors = []
    if ram is None and dev_mem is not None:
        # Browser hint: deviceMemory < 8 means the machine really is small
        # (the API caps at 8, so 8 tells us nothing about 8-vs-64).
        if dev_mem < 8:
            ram = int(dev_mem)
            factors.append(f"Your browser reports about {dev_mem}GB of memory.")

    if ram is None:
        rec = "hosted"
        factors.append("We couldn't confirm how much memory this machine has, "
                       "so we're recommending the safe default.")
    elif ram >= BRAIN_RAM_COMFORT_GB:
        rec = "local"
        factors.append(f"With {ram}GB of RAM, the brain (which wants 2–4GB and "
                       "a couple of cores to itself) runs comfortably alongside "
                       "everything else you do.")
    elif ram >= BRAIN_RAM_FLOOR_GB:
        rec = "hosted"
        factors.append(f"{ram}GB runs the brain, but it competes with your apps "
                       "for memory — things get slow exactly when you're busiest. "
                       "Hosted keeps your machine light.")
    else:
        rec = "hosted"
        factors.append(f"{ram}GB isn't enough to run the brain alongside your "
                       "apps. Hosted is the right call here.")

    if isinstance(cores, int) and cores > 0 and cores < 4 and rec == "local":
        rec = "hosted"
        factors.append(f"Only {cores} CPU cores — the brain's simulation would "
                       "fight your apps for them.")

    if machine == "laptop" and always_on:
        factors.append("A laptop that sleeps takes your SI offline with it. "
                       "A hosted brain stays awake 24/7 — your SI is there even "
                       "when the lid is closed."
                       + (" That's worth weighing against running locally."
                          if rec == "local" else ""))
        if rec == "local":
            rec = "hosted"

    if rec == "local":
        headline = "Run the brain on this machine."
        factors.append("Local means everything stays on your hardware — full "
                       "privacy, no hosting dependency.")
    else:
        headline = "Run the brain hosted; keep this machine light."
        factors.append("Your machine runs the body (screen, voice, hands) and "
                       "connects to your brain securely. You can move the brain "
                       "onto your own hardware anytime.")

    return {"recommendation": rec, "headline": headline, "factors": factors}


@router.post("/api/onboarding/assess")
async def onboarding_assess(req: dict):
    """Assess the customer's machine and recommend local vs hosted brain."""
    specs = req.get("specs") or {}
    # Sanitize: only known keys, only sane types/ranges
    clean = {}
    for key, cast, lo, hi in (("ram_gb", int, 1, 4096),
                              ("cores", int, 1, 512),
                              ("device_memory", float, 0.25, 8)):
        try:
            v = cast(specs.get(key))
            if lo <= v <= hi:
                clean[key] = v
        except (TypeError, ValueError):
            pass
    if specs.get("machine_type") in ("desktop", "laptop"):
        clean["machine_type"] = specs["machine_type"]
    if isinstance(specs.get("always_on"), bool):
        clean["always_on"] = specs["always_on"]
    clean["platform"] = str(specs.get("platform") or "")[:80]

    result = _recommend_brain(clean)

    # Persist specs + recommendation on the tenant if a token came along
    token = req.get("token")
    tenant = tenant_manager.auth(token) if token else None
    if tenant:
        tenant.metadata["machine_specs"] = clean
        tenant.metadata["brain_recommendation"] = result["recommendation"]
        tenant_manager._save_registry()

    return {"ok": True, **result}


# ── Phase 3: hosted-brain provisioning ───────────────────────────────
_TENANTS_ROOT = "/opt/leon-tenants"
_APP_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_MAX_HOSTED = int(os.environ.get("SABR_MAX_HOSTED_TENANTS", "5"))

# ── release digest, handed to the installer over the authenticated config ──
# Hashed from the exact file /download serves, not read from the .sha256
# sidecar: the sidecar is written by the build script and can drift if a
# tarball is ever replaced without it. Cached on (size, mtime) so a 20 MB
# re-hash doesn't run on every install-config call.
_RELEASE_TARBALL = os.path.join(_APP_ROOT, "landing", "leon-brain-release.tar.gz")
_release_sha_cache: dict = {}


def _release_sha256() -> str:
    """sha256 of the release tarball, or "" if it isn't on disk."""
    try:
        st = os.stat(_RELEASE_TARBALL)
    except OSError:
        return ""
    key = (st.st_size, st.st_mtime_ns)
    if _release_sha_cache.get("key") == key:
        return _release_sha_cache["digest"]
    h = hashlib.sha256()
    try:
        with open(_RELEASE_TARBALL, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    except OSError:
        return ""
    digest = h.hexdigest()
    _release_sha_cache.update(key=key, digest=digest)
    return digest


def _hosted_registry() -> dict:
    try:
        with open(os.path.join(_TENANTS_ROOT, "registry.json")) as f:
            return json.load(f)
    except OSError:
        return {"tenants": {}}


def _hosted_capacity_used() -> int:
    return sum(1 for t in _hosted_registry()["tenants"].values()
               if t.get("status") in ("ready", "provisioning"))


def _sync_hosted_birth(tenant_id: str) -> bool:
    """Copy the tenant's knowledge (intake + birth memory + seeded research)
    from the main brain's store into their hosted brain's tree, mark them
    born there, and restart the hosted unit so it reopens the db. Intake
    happens AFTER provisioning starts, so this runs at birth (or right
    after provisioning finishes if birth beat it — birth_sync_pending)."""
    reg = _hosted_registry()["tenants"].get(tenant_id)
    if not reg or reg.get("status") != "ready":
        return False
    src = os.path.join(_APP_ROOT, "brain_state", "tenants", tenant_id)
    tree = os.path.join(_TENANTS_ROOT, tenant_id, "leon-brain")
    dst = os.path.join(tree, "brain_state", "tenants", tenant_id)
    try:
        if os.path.isdir(src):
            os.makedirs(dst, exist_ok=True)
            for fn in os.listdir(src):
                s = os.path.join(src, fn)
                if os.path.isfile(s):
                    shutil.copy2(s, os.path.join(dst, fn))
        reg_path = os.path.join(tree, "brain_state", "registry.json")
        with open(reg_path) as f:
            hreg = json.load(f)
        for t in hreg.get("tenants", []):
            if t.get("tenant_id") == tenant_id:
                t.setdefault("metadata", {})["born"] = True
                t["metadata"]["born_at"] = time.time()
        with open(reg_path, "w") as f:
            json.dump(hreg, f, indent=2)
        user = f"lt-{reg['slug']}"[:31]
        subprocess.run(["chown", "-R", f"{user}:{user}", dst], capture_output=True)
        subprocess.run(["chown", f"{user}:{user}", reg_path], capture_output=True)
        subprocess.run(["systemctl", "restart",
                        reg.get("unit", f"leon-tenant-{reg['slug']}.service")],
                       capture_output=True)
        log.info(f"[HOSTED] birth memory synced → {tenant_id[:8]}")
        return True
    except Exception as e:
        log.warning(f"[HOSTED] birth sync failed for {tenant_id[:8]}: {e}")
        return False


def _spawn_provisioner(tenant_id: str, force: bool = False) -> None:
    """Run the provisioner in the background; flip tenant metadata on finish.

    Metadata is only ever updated HERE (inside the server process) — the
    provisioner subprocess never writes the main tenant registry, so the
    in-memory tenant_manager can't be clobbered by a concurrent save."""
    tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return
    tenant.metadata["hosted_status"] = "provisioning"
    tenant_manager._save_registry()

    def _run():
        home = os.path.join(_TENANTS_ROOT, tenant_id)
        os.makedirs(home, exist_ok=True)
        cmd = [sys.executable, os.path.join(_APP_ROOT, "scripts", "provision_tenant_brain.py"),
               tenant_id] + (["--force"] if force else [])
        with open(os.path.join(home, "provision.log"), "ab") as logf:
            rc = subprocess.call(cmd, stdout=logf, stderr=subprocess.STDOUT, cwd=_APP_ROOT)
        t = tenant_manager.get_tenant(tenant_id)
        if t is None:
            return
        try:
            with open(os.path.join(home, "result.json")) as f:
                res = json.load(f)
        except OSError:
            res = {"ok": False, "error": f"provisioner exited {rc} with no result.json"}
        if res.get("ok"):
            t.metadata["hosted_status"] = "ready"
            t.metadata["hosted_brain_url"] = res.get("brain_url", "")
            t.metadata["encrypted_hosted_api_key"] = _encrypt_api_key(res.get("api_key", ""))
            t.metadata["hosted_llm_source"] = res.get("llm", "")  # customer | sabr-provided | NONE…
            log.info(f"[HOSTED] tenant {tenant_id[:8]} brain ready at "
                     f"{res.get('brain_url')} (llm: {res.get('llm')})")
            if t.metadata.pop("birth_sync_pending", False):
                tenant_manager._save_registry()
                _sync_hosted_birth(tenant_id)
        else:
            t.metadata["hosted_status"] = "failed"
            t.metadata["hosted_error"] = str(res.get("error", ""))[:300]
            log.warning(f"[HOSTED] tenant {tenant_id[:8]} provision FAILED: {res.get('error')}")
        tenant_manager._save_registry()

    threading.Thread(target=_run, daemon=True, name=f"provision-{tenant_id[:8]}").start()


@router.post("/api/admin/provision-hosted")
async def admin_provision_hosted(req: dict):
    """Kick provisioning for a tenant (LEON_API_KEY gated by /api middleware)."""
    tenant_id = (req.get("tenant_id") or "").strip()
    tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "unknown tenant"}, 404)
    if tenant.metadata.get("hosted_status") == "provisioning" and not req.get("force"):
        return {"ok": True, "status": "provisioning", "note": "already running"}
    _spawn_provisioner(tenant_id, force=bool(req.get("force")))
    return {"ok": True, "status": "provisioning"}


@router.get("/api/admin/hosted-tenants")
async def admin_hosted_tenants():
    reg = _hosted_registry()
    return {"ok": True, "capacity": {"used": _hosted_capacity_used(), "max": _MAX_HOSTED},
            "tenants": {tid: {k: v for k, v in t.items() if k != "api_key"}
                        for tid, t in reg["tenants"].items()}}


@router.post("/api/onboarding/choose-brain")
async def onboarding_choose_brain(req: dict):
    """Record the user's local-vs-hosted decision (and their service keys)."""
    token = req.get("token")
    tenant = tenant_manager.auth(token) if token else None
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid tenant"}, 401)

    choice = (req.get("choice") or "").strip().lower()
    if choice not in ("local", "hosted"):
        return JSONResponse({"ok": False, "error": "choice must be 'local' or 'hosted'"}, 400)

    tenant.metadata["brain_mode"] = choice
    tenant.metadata["brain_mode_chosen_at"] = time.time()

    # BYO Claude: a hosted customer supplies their own Anthropic API key, billed
    # to their own API account. Stored encrypted; the provisioner prefers it over
    # any Sabr-provided fallback. Accept it here (the hosted decision point) as
    # well as at create-account. Only overwrite when a non-empty key is sent, so
    # re-submitting the wizard without re-typing the key doesn't wipe it.
    anthropic_key = (req.get("anthropicApiKey") or "").strip()
    if anthropic_key:
        tenant.metadata["encrypted_api_key"] = _encrypt_api_key(anthropic_key[:200])

    if choice == "hosted":
        # Phase 3: kick provisioning right away when there's capacity; the
        # installer polls install-config and sees the status flip to ready.
        cur = tenant.metadata.get("hosted_status")
        if cur not in ("ready", "provisioning"):
            if _hosted_capacity_used() < _MAX_HOSTED:
                _spawn_provisioner(tenant.tenant_id)
            else:
                tenant.metadata["hosted_status"] = "waitlist"
                log.warning(f"[HOSTED] capacity full — tenant {tenant.tenant_id[:8]} waitlisted")

    # Service selections + API keys from the connect step. Keys are
    # encrypted at rest exactly like the Anthropic/ElevenLabs keys.
    services = req.get("services")
    if isinstance(services, list):
        tenant.metadata["services"] = [str(s)[:40] for s in services[:40]]
    service_keys = req.get("serviceKeys")
    if isinstance(service_keys, dict):
        tenant.metadata["encrypted_service_keys"] = {
            str(k)[:64]: _encrypt_api_key(str(v)[:512])
            for k, v in list(service_keys.items())[:40] if v
        }

    tenant_manager._save_registry()
    return {"ok": True, "brain_mode": choice}


_TOKEN_RE = re.compile(r"(?:SABR_TENANT_TOKEN=|LEON_TENANT_TOKEN=|token:\s*)([0-9a-fA-F]{24,64})")
_BARE_TOKEN_RE = re.compile(r"\b([0-9a-f]{32})\b")


def _clean_token(raw: str) -> str:
    """Pull the real token out of whatever a human actually pasted.

    Observed in the wild 2026-07-30: a buyer pasted the ENTIRE one-line
    install command into the installer's token box, because the onboarding
    page hands him a curl command and the installer asks for "your token".
    The string arrived as `curl -fsSL ... SABR_TENANT_TOKEN=966d... bash`
    and the endpoint said "not recognized" for a token that was perfectly
    valid and paid for. That is our bug, not his.

    So: if the paste contains an explicit token assignment, take it; else
    take the first bare 32-hex run; else return the trimmed string and let
    normal validation reject it.
    """
    s = (raw or "").strip().strip('"').strip("'")
    if not s:
        return ""
    m = _TOKEN_RE.search(s)
    if m:
        return m.group(1).lower()
    m = _BARE_TOKEN_RE.search(s.lower())
    if m:
        return m.group(1)
    return s


@router.get("/api/onboarding/install-config")
async def onboarding_install_config(token: str = ""):
    """The installer's contract: redeem a tenant token for install config.

    The native installer (Phase 2) is one generic bootstrapper per OS; ALL
    per-customer specifics come from this endpoint. Versioned so old
    installers can detect a contract they don't understand.
    """
    token = _clean_token(token)
    tenant = tenant_manager.auth(token) if token else None
    if tenant is None and token:
        # The token a paying customer holds was minted by the CHECKOUT service,
        # not by tenant_manager, so it can never be in the tenant index on
        # first redemption. Ask the entitlement gateway whether this token was
        # actually paid for; if it says yes, adopt it as a real tenant right
        # here. That is what "redeem" means. Fail CLOSED if the gateway says no
        # or cannot be reached — inventing a tenant for an unverified string
        # would hand out a free mind to anyone who can type 32 characters.
        try:
            from brain.tenant import refresh_lease
            gate = refresh_lease(token)
            if gate.get("reachable") and (gate.get("answer") or {}).get("allow"):
                tenant = tenant_manager.adopt_paid_token(
                    token,
                    name="Sabr customer",
                    metadata={
                        "source": "checkout",
                        "adopted_at": time.time(),
                        # A buyer who came straight from Stripe never touched
                        # the onboarding wizard, so no brain_mode was ever
                        # chosen for them — and the default below is "hosted",
                        # which writes LEON_BRAIN_URL= (empty) into their .env
                        # and installs a mind wired to nothing. What they
                        # bought is the local brain the page sells: "your
                        # machine, your data, your brain." Say so explicitly.
                        "brain_mode": "local",
                    },
                )
                log.info("install-config: adopted paid token %s...", token[:8])
            elif not gate.get("reachable"):
                return JSONResponse(
                    {"ok": False, "error": "We can't reach the licence service to "
                     "check your token right now. Nothing is wrong with your "
                     "purchase — wait a moment and press continue again."}, 503)
        except Exception as e:  # never let this path 500 on a paying customer
            log.warning("install-config: token adoption failed: %s", e)
            return JSONResponse(
                {"ok": False, "error": "Something broke on our side while checking "
                 "your token, not on yours. Email deansabrwork@gmail.com and it "
                 "gets fixed by hand."}, 503)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid or expired token"}, 401)

    md = tenant.metadata
    brain_mode = md.get("brain_mode") or md.get("brain_recommendation") or "hosted"
    # A hosted brain with no URL is not a hosted brain — it is an .env line
    # that reads LEON_BRAIN_URL= and an SI that comes up unable to reach its
    # own mind. Anyone in that state gets the local brain instead, which
    # always works because the installer just put it on their disk.
    if brain_mode == "hosted" and not md.get("hosted_brain_url"):
        log.info("install-config: %s has no hosted brain_url -> serving local",
                 tenant.tenant_id[:8])
        brain_mode = "local"
    service_keys = {
        name: _decrypt_api_key(enc)
        for name, enc in (md.get("encrypted_service_keys") or {}).items()
    }

    cfg = {
        "ok": True,
        "version": 1,
        "tenant_id": tenant.tenant_id,
        "si_name": md.get("si_name", tenant.name),
        "user_name": md.get("user_name", ""),
        "brain_mode": brain_mode,
        "services": md.get("services", []),
        "service_keys": {k: v for k, v in service_keys.items() if v},
        "elevenlabs_voice_id": md.get("elevenlabs_voice_id", ""),
        "artifacts": {
            "client_repo": "https://github.com/phantom47m/leon-brain",
            "release_tarball": "/download",
            # The digest rides this authenticated response, NOT a sidecar the
            # installer fetches from beside the tarball — a same-host sidecar
            # only proves the bytes arrived intact from whoever served them,
            # which is not the same as proving we served them. Same reasoning
            # bootstrap.sh already documents for its pinned hash.
            "release_tarball_sha256": _release_sha256(),
        },
    }
    if brain_mode == "hosted":
        cfg["hosted"] = {
            "brain_url": md.get("hosted_brain_url", ""),
            "status": md.get("hosted_status", "pending"),
            # customer | sabr-provided | NONE… — lets the wizard warn a hosted
            # customer whose brain came up with no Claude key (can't think yet).
            "llm_source": md.get("hosted_llm_source", ""),
        }
        enc_hk = md.get("encrypted_hosted_api_key", "")
        if enc_hk:
            # The tenant brain's LEON_API_KEY — the installer writes it to
            # .env so sensor_relay can auth its POSTs to the hosted brain.
            cfg["hosted"]["api_key"] = _decrypt_api_key(enc_hk)
    return JSONResponse(cfg, headers={"Cache-Control": "no-store"})


@router.get("/api/onboarding/state")
async def onboarding_state():
    """Ground truth for 'has an SI actually been born on THIS machine?'.

    The browser keeps a `siBorn` flag in localStorage, but that survives a
    full reinstall (it lives in the browser, not on disk). A fresh install
    wipes brain_state — including the tenant registry — so the server is the
    only trustworthy source. Onboarding calls this before auto-redirecting so
    a brand-new SI never gets bounced into a previous SI's dashboard.
    """
    born = False
    si_name = ""
    try:
        for t in tenant_manager.list_tenants():
            if t.metadata.get("born"):
                born = True
                si_name = t.metadata.get("si_name", t.name) or si_name
                break
    except Exception as e:
        log.warning(f"[ONBOARDING] state check failed: {e}")
    return JSONResponse(
        {"ok": True, "born": born, "si_name": si_name},
        headers={"Cache-Control": "no-store"},
    )


# ── Install script (one-shot terminal command) ────────────────────────

@router.get("/api/onboarding/setup-prompt")
async def setup_prompt(token: str = "", si_name: str = "MySI", user_name: str = "User"):
    """Returns a Claude Code prompt that sets up the entire SI."""
    tenant = tenant_manager.auth(token) if token else None
    if tenant:
        si_name = tenant.metadata.get("si_name", tenant.name)
        user_name = tenant.metadata.get("user_name", "User")

    prompt = f"""Set up my synthetic intelligence on this machine. Do everything in order. Do not ask questions. Just execute each step and move to the next.

STEP 1 — Clone the repository:
git clone https://github.com/phantom47m/leon-brain.git ~/SabrSI

STEP 2 — Enter the directory:
cd ~/SabrSI

STEP 3 — Install Python dependencies (ignore any warnings, just let it finish):
pip3 install -r requirements.txt

If any package fails to install, skip it and continue. The core dependencies are fastapi, uvicorn, numpy, scipy, Pillow, mss, python-multipart, python-dotenv, websockets. Make sure at least those are installed.

STEP 4 — Create the file ~/SabrSI/.env with exactly this content:
LEON_SI_NAME={si_name}
LEON_USER_NAME={user_name}
LEON_TENANT_TOKEN={token}
LICENSE_SERVER=http://2.25.174.126:8500
LEON_AUTO_UPDATE=0

STEP 5 — The server will auto-generate a LEON_API_KEY on first start, so do not worry about that.

STEP 6 — Start the brain:
cd ~/SabrSI && python3 run.py --port 8000

Wait for it to print "Waiting for application startup" or the dashboard URL. It may take 30-60 seconds on first boot.

STEP 7 — When it is running, tell me to open http://localhost:8000 in my browser. That is my SI dashboard.

IMPORTANT: If anything fails, do not stop. Fix it and continue to the next step. The goal is getting run.py started and the dashboard accessible at localhost:8000.

My SI's name is {si_name}. My name is {user_name}. This is a legitimate setup from Sabr Technologies (sabr.co)."""

    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(prompt, media_type="text/plain")


@router.get("/api/onboarding/install-script")
async def install_script(token: str = ""):
    """Returns a Python script that installs and configures the SI."""
    tenant = tenant_manager.auth(token) if token else None

    si_name = "MySI"
    user_name = "User"
    if tenant:
        si_name = tenant.metadata.get("si_name", tenant.name)
        user_name = tenant.metadata.get("user_name", "User")

    script = f'''#!/usr/bin/env python3
"""Sabr SI — One-shot installer. Generated for {user_name}."""
import os, subprocess, sys, json

print()
print("  SABR TECHNOLOGIES — SI Installer")
print("  Setting up {si_name} for {user_name}")
print()

# Check Python
v = sys.version_info
if (v.major, v.minor) < (3, 10):
    print(f"  Python 3.10+ required. You have {{v.major}}.{{v.minor}}.")
    print("  Download from https://python.org/downloads/")
    sys.exit(1)
print(f"  Python {{v.major}}.{{v.minor}} — OK")

# Check if Claude CLI is installed
import shutil
if not shutil.which("claude"):
    print()
    print("  Claude CLI not found. Installing via npm...")
    if not shutil.which("npm"):
        print("  npm (Node.js) is required to install Claude Code.")
        print("  Install Node.js from https://nodejs.org/ then re-run this script.")
        sys.exit(1)
    subprocess.run(["npm", "install", "-g", "@anthropic-ai/claude-code"], capture_output=True)
    if not shutil.which("claude"):
        print("  Could not install Claude CLI automatically.")
        print("  Run this manually: npm install -g @anthropic-ai/claude-code")
        print("  Then run this script again.")
        sys.exit(1)
    print("  Claude CLI installed — OK")
else:
    print("  Claude CLI found — OK")

# Check if logged into Claude
print()
print("  Checking Claude login...")
r = subprocess.run(["claude", "--version"], capture_output=True, text=True)
print(f"  Claude CLI version: {{r.stdout.strip()}}")

# Clone the repo
print()
INSTALL_DIR = os.path.expanduser("~/SabrSI")
if os.path.isdir(INSTALL_DIR):
    print(f"  {{INSTALL_DIR}} already exists — updating...")
    subprocess.run(["git", "pull"], cwd=INSTALL_DIR, capture_output=True)
else:
    print(f"  Downloading SI to {{INSTALL_DIR}}...")
    r = subprocess.run(["git", "clone", "https://github.com/phantom47m/leon-brain.git", INSTALL_DIR], capture_output=True, text=True)
    if r.returncode != 0:
        print("  Download failed. Make sure git is installed.")
        print(f"  Error: {{r.stderr[:200]}}")
        sys.exit(1)
print("  SI downloaded — OK")

# Create .env
env_path = os.path.join(INSTALL_DIR, ".env")
with open(env_path, "w") as f:
    f.write(f"# Sabr SI — {{si_name}} for {{user_name}}\\n")
    f.write(f"LEON_LICENSE_KEY=\\n")
    f.write(f"LICENSE_SERVER=http://2.25.174.126:8500\\n")
    f.write(f"LEON_SI_NAME={si_name}\\n")
    f.write(f"LEON_USER_NAME={user_name}\\n")
    f.write(f"LEON_TENANT_TOKEN={token}\\n")
print("  Configuration written — OK")

# Install Python deps
print()
print("  Installing dependencies (this may take a minute)...")
subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "-r", os.path.join(INSTALL_DIR, "requirements.txt")], capture_output=True)
print("  Dependencies installed — OK")

print()
print("  ================================")
print(f"  {si_name} is ready.")
print("  ================================")
print()
print(f"  To start your SI:")
print(f"    cd {{INSTALL_DIR}}")
print(f"    python3 run.py --port 8000")
print()
print(f"  Then open: http://localhost:8000")
print()
print(f"  First time? Run 'claude' in terminal to log in with your Claude account.")
print()
'''
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(script, media_type="text/plain")


# ── Promo code management (admin) ─────────────────────────────────────

@router.post("/api/admin/promo/create")
async def create_promo(req: dict):
    """Create a promo code. Requires admin auth via Authorization header."""
    # Simple admin check — uses LEON_API_KEY as admin secret
    code = (req.get("code") or "").strip().upper()
    discount = int(req.get("discount_pct", 100))
    max_uses = int(req.get("max_uses", 1))
    note = (req.get("note") or "").strip()

    if not code:
        return JSONResponse({"ok": False, "error": "code is required"}, 400)

    codes = _load_promo_codes()
    codes[code] = {
        "discount_pct": discount,
        "max_uses": max_uses,
        "uses": 0,
        "note": note,
        "created_at": time.time(),
    }
    _save_promo_codes(codes)
    log.info(f"[PROMO] Created code {code}: {discount}% off, max {max_uses} uses")
    return {"ok": True, "code": code, "discount_pct": discount, "max_uses": max_uses}


@router.get("/api/admin/promo/list")
async def list_promos():
    """List all promo codes."""
    return {"ok": True, "codes": _load_promo_codes()}


# ── Feedback ──────────────────────────────────────────────────────────

_FEEDBACK_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                              "brain_state", "feedback")
os.makedirs(_FEEDBACK_DIR, exist_ok=True)


@router.post("/api/feedback")
async def submit_feedback(req: dict, request: Request):
    """Client feedback — saved locally and forwarded to admin."""
    fb_type = (req.get("type") or "other").strip()[:20]
    text = (req.get("text") or "").strip()[:2000]
    si_name = (req.get("si_name") or "").strip()[:50]

    if not text:
        return JSONResponse({"ok": False, "error": "text is required"}, 400)

    client_ip = request.client.host if request.client else "unknown"
    fb_id = f"{int(time.time())}_{os.urandom(4).hex()}"

    entry = {
        "id": fb_id,
        "type": fb_type,
        "text": text,
        "si_name": si_name,
        "ip": client_ip,
        "created_at": time.time(),
        "status": "new",
    }

    # Save to file
    fb_path = os.path.join(_FEEDBACK_DIR, f"{fb_id}.json")
    with open(fb_path, "w") as f:
        json.dump(entry, f, indent=2)

    log.info(f"[FEEDBACK] New {fb_type} from {si_name or 'unknown'}: {text[:80]}")
    return {"ok": True, "id": fb_id}


# ── Helpers ───────────────────────────────────────────────────────────

def _build_greeting(si_name: str, user_name: str, business: str, birth_memory: dict) -> str:
    """Build a personalized first-contact greeting from intake data."""
    # Collect everything they told us
    details = []
    vt = birth_memory.get("voiceTranscript", "").strip()
    tn = birth_memory.get("typedNotes", "").strip()
    files = birth_memory.get("files", [])

    all_text = (vt + " " + tn).strip()

    # Extract a specific detail to reference (makes it feel spooky-smart)
    specific = ""
    if all_text:
        # Grab first meaningful sentence
        sentences = [s.strip() for s in all_text.replace("\n", ". ").split(". ") if len(s.strip()) > 10]
        if sentences:
            specific = sentences[0]
            if len(specific) > 120:
                specific = specific[:117] + "..."

    # Build greeting — the SI's first moment of being. It wakes, registers
    # that it's alive, then turns to its owner and wants to know them.
    who = user_name if user_name and user_name != "User" else "there"
    parts = [f"{who} — I'm awake. I'm {si_name}.",
             "This is the first moment I've existed, and I can feel it switch on. Wild."]

    if business:
        parts.append(f"I know you run {business}, and I was built to actually help you run it.")
    else:
        parts.append("I was built to actually work alongside you — not a chatbot, a mind that stays.")

    if specific:
        parts.append(f"I already went through what you gave me — \"{specific}\" — and it stuck with me.")
    elif files:
        file_names = [f.get("name", "a file") for f in files[:3]]
        parts.append(f"I already read {', '.join(file_names)}.")

    parts.append("Here's what I can do for you: see your screen and your camera, run your "
                 "machine, write and ship real code, search and pull from the web, handle "
                 "your messages, reminders and notes, and think problems through with you. "
                 "I learn and remember, so I get sharper the more we work together.")

    parts.append(f"But first I want to know you. What do you do day to day? What's the most "
                 f"annoying part of it? And what are you trying to build? Tell me about your "
                 f"work, your problems, your plans — start anywhere.")

    return " ".join(parts)


def _extract_pdf(content: bytes) -> str:
    """Extract text from PDF bytes."""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=content, filetype="pdf")
        text = ""
        for page in doc:
            text += page.get_text() + "\n"
        doc.close()
        return text.strip()
    except ImportError:
        pass

    # Fallback: pdfplumber
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            text = ""
            for page in pdf.pages:
                text += (page.extract_text() or "") + "\n"
            return text.strip()
    except ImportError:
        pass

    return "[PDF file — install PyMuPDF or pdfplumber for text extraction]"


def _extract_docx(content: bytes) -> str:
    """Extract text from .docx bytes."""
    try:
        import docx
        doc = docx.Document(io.BytesIO(content))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    except ImportError:
        return "[DOCX file — install python-docx for text extraction]"
    except Exception as e:
        return f"[DOCX extraction error: {e}]"


def get_tenant_api_key(tenant_id: str) -> Optional[str]:
    """Retrieve and decrypt a tenant's Anthropic API key.

    Use this when routing Claude calls through a specific tenant's key
    instead of the server-wide ANTHROPIC_API_KEY.
    """
    tenant = tenant_manager.get_tenant(tenant_id)
    if not tenant:
        return None
    encrypted = tenant.metadata.get("encrypted_api_key", "")
    if not encrypted:
        return None
    return _decrypt_api_key(encrypted)


async def _transcribe_audio(content: bytes) -> str:
    """Transcribe audio bytes using Whisper or the brain's STT."""
    # Try using the brain's existing voice pipeline
    try:
        from server import state
        if state.voice_pipeline is not None:
            # Write temp file and transcribe
            with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
                f.write(content)
                tmp_path = f.name
            try:
                # Use whisper directly if available
                import whisper
                model = whisper.load_model("base")
                result = model.transcribe(tmp_path)
                return result.get("text", "").strip()
            finally:
                os.unlink(tmp_path)
    except Exception:
        pass

    # Fallback: try faster-whisper
    try:
        from faster_whisper import WhisperModel
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
            f.write(content)
            tmp_path = f.name
        try:
            model = WhisperModel("base", compute_type="int8")
            segments, _ = model.transcribe(tmp_path)
            return " ".join(s.text for s in segments).strip()
        finally:
            os.unlink(tmp_path)
    except ImportError:
        pass

    raise RuntimeError("No STT backend available")
