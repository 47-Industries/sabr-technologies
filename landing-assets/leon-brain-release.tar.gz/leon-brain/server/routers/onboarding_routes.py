"""
/api/onboarding/* — New-user onboarding flow for multi-tenant SI births.

Handles account creation (tenant provisioning), deep intake (voice + text +
file uploads), birth (SI wake + personalized greeting), and transcription.

Every new SI is born with:
  1. The user's intake data (voice, typed notes, uploaded files) as birth memory
  2. (Owner install ONLY) the owner's own research seeds — a customer's SI is
     born knowing nothing about the vendor's science or the vendor's life

The onboarding page lives at /onboarding (dashboard/onboarding.html).
"""

import asyncio
import base64
import hashlib
import hmac
import io
import ipaddress
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import defaultdict
from typing import Optional

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse

from brain.tenant import tenant_manager
from brain.knowledge_store import KnowledgeStore

log = logging.getLogger("leon.onboarding")
router = APIRouter()

# ── API key encryption (AES-256-CBC) ─────────────────────────────────
# We encrypt tenant API keys at rest so they never sit in plaintext in
# the registry JSON. The encryption key is derived from LEON_API_KEY
# (the server master secret) — if LEON_API_KEY rotates, old keys become
# unreadable (acceptable: user re-enters their key).
_MASTER_KEY = os.environ.get("LEON_API_KEY", "").encode()


def _derive_key() -> bytes:
    """Derive a 32-byte AES key from the master secret."""
    return hashlib.sha256(_MASTER_KEY + b"tenant-api-key-encryption").digest()


def _encrypt_api_key(plaintext: str) -> str:
    """Encrypt an API key. Returns base64(iv + ciphertext)."""
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        key = _derive_key()
        iv = secrets.token_bytes(16)
        padder = padding.PKCS7(128).padder()
        padded = padder.update(plaintext.encode()) + padder.finalize()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        enc = cipher.encryptor()
        ct = enc.update(padded) + enc.finalize()
        return base64.b64encode(iv + ct).decode()
    except ImportError:
        # cryptography not installed — fall back to XOR obfuscation
        # (NOT real encryption, but better than plaintext in the JSON)
        log.warning("[ONBOARDING] cryptography package not installed — using XOR obfuscation for API keys")
        key = _derive_key()
        data = plaintext.encode()
        xored = bytes(d ^ key[i % len(key)] for i, d in enumerate(data))
        return "xor:" + base64.b64encode(xored).decode()


def _decrypt_api_key(ciphertext: str) -> str:
    """Decrypt an API key."""
    if ciphertext.startswith("xor:"):
        key = _derive_key()
        data = base64.b64decode(ciphertext[4:])
        return bytes(d ^ key[i % len(key)] for i, d in enumerate(data)).decode()
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        key = _derive_key()
        raw = base64.b64decode(ciphertext)
        iv, ct = raw[:16], raw[16:]
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
        dec = cipher.decryptor()
        padded = dec.update(ct) + dec.finalize()
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode()
    except Exception as e:
        log.error(f"[ONBOARDING] API key decryption failed: {e}")
        return ""


# ── Rate limiting (in-memory, per-IP) ────────────────────────────────
# Simple sliding-window rate limiter: max 5 account creations per hour
# per IP. Prevents abuse of the auth-exempt onboarding endpoints.
_rate_buckets: dict = defaultdict(list)  # ip -> [timestamps]
_RATE_LIMIT = 5
_RATE_WINDOW = 3600  # 1 hour


def _is_public_ip(value: str) -> bool:
    """True if `value` is a routable public address a real customer owns.

    Anything private, loopback, link-local or unparseable is a hop inside
    our own infrastructure, not a customer, and must never become a rate
    limit bucket key.
    """
    try:
        addr = ipaddress.ip_address(value)
    except ValueError:
        return False
    return not (
        addr.is_private
        or addr.is_loopback
        or addr.is_link_local
        or addr.is_reserved
        or addr.is_multicast
        or addr.is_unspecified
    )


def _client_ip(request) -> str:
    """The real caller's IP, correct behind a reverse proxy.

    In production this app sits behind Railway's edge proxy, so
    `request.client.host` is the PROXY's address — identical for every
    customer on earth. Bucketing on that turned a per-IP limit of 5/hour
    into a GLOBAL limit of 5/hour: the sixth stranger to ever sign up in
    an hour got "Too many accounts created" through no fault of theirs.
    Proven 2026-08-12 by hitting the live endpoint from two different
    public IPs and getting the same 429.

    We deliberately do NOT enable uvicorn's global proxy_headers to fix
    this. Doing so would let anyone spoof `X-Forwarded-For: 127.0.0.1`
    and trip the localhost branch in server/__init__.py that injects the
    dashboard API key into the page — trading a rate-limit bug for a
    credential leak. So the proxy awareness stays scoped to here, where
    the worst case of a spoof is evading a rate limit.

    We scan X-Forwarded-For from the RIGHT and take the last PUBLIC
    address. Each proxy appends the peer it actually saw, so entries our
    trusted edge wrote sit at the end and a client-supplied prefix is
    ignored. We skip trailing private/loopback entries rather than blindly
    taking parts[-1], because parts[-1] is only the customer when there is
    exactly ONE hop in front of us. Add a second internal hop — a mesh
    sidecar, an internal load balancer — and the final entry becomes a
    10.x address that is identical for every customer alive, silently
    restoring the exact global-bucket bug this function exists to fix.
    Skipping private entries makes the answer independent of hop count,
    so nobody has to re-derive Railway's topology to know this is right.
    """
    try:
        xff = request.headers.get("x-forwarded-for") or ""
        parts = [p.strip() for p in xff.split(",") if p.strip()]
        for candidate in reversed(parts):
            if _is_public_ip(candidate):
                return candidate
        if parts:
            # All-private chain (local docker/compose): last entry is still
            # the most specific thing we know about the caller.
            return parts[-1]
    except Exception:
        pass
    try:
        return (request.client.host if request.client else "") or "unknown"
    except Exception:
        return "unknown"


def _check_rate_limit(ip: str) -> bool:
    """Returns True if the request is within rate limits."""
    now = time.time()
    bucket = _rate_buckets[ip]
    # Prune old entries
    _rate_buckets[ip] = [ts for ts in bucket if now - ts < _RATE_WINDOW]
    if len(_rate_buckets[ip]) >= _RATE_LIMIT:
        return False
    _rate_buckets[ip].append(now)
    return True


# ── Input sanitization ───────────────────────────────────────────────
_EMAIL_RE = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
MAX_UPLOAD_SIZE = 10 * 1024 * 1024  # 10MB per file

# ── Promo codes (in-memory, admin-generated) ─────────────────────────
# Format: { "CODE": { "discount_pct": 100, "note": "a customer - paid outside", "uses": 0, "max_uses": 1 } }
_PROMO_CODES_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "brain_state", "promo_codes.json"
)


def _load_promo_codes() -> dict:
    if os.path.exists(_PROMO_CODES_FILE):
        try:
            with open(_PROMO_CODES_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_promo_codes(codes: dict):
    os.makedirs(os.path.dirname(_PROMO_CODES_FILE), exist_ok=True)
    with open(_PROMO_CODES_FILE, "w") as f:
        json.dump(codes, f, indent=2)


def _validate_promo(code: str) -> dict:
    """Validate a promo code. Returns {"valid": True, "discount_pct": 100} or {"valid": False}."""
    if not code:
        return {"valid": False}
    codes = _load_promo_codes()
    entry = codes.get(code.upper())
    if not entry:
        return {"valid": False, "error": "Invalid promo code"}
    if entry.get("max_uses", 0) > 0 and entry.get("uses", 0) >= entry["max_uses"]:
        return {"valid": False, "error": "Promo code has been used"}
    return {"valid": True, "discount_pct": entry.get("discount_pct", 0), "note": entry.get("note", "")}


def _use_promo(code: str):
    """Increment the usage count of a promo code."""
    codes = _load_promo_codes()
    if code.upper() in codes:
        codes[code.upper()]["uses"] = codes[code.upper()].get("uses", 0) + 1
        _save_promo_codes(codes)


# ── Mint authorization: who may mint a NON-expiring token ────────────
#
# THE HOLE THIS CLOSES (found 2026-08-25): create-account is public and
# auth-exempt, and it stamped expires_at ONLY when the request's business
# field carried the website's trial marker ('24-hour free trial'). Any
# direct POST without that marker minted a token with NO expiry — a
# permanent free product key for anyone who read the site JS and typed
# one curl command. Rate limiting by IP bounded the RATE of the theft,
# not the theft.
#
# Now EVERY public mint expires PUBLIC_MINT_TTL seconds after creation,
# and a non-expiring token requires exactly one of:
#
#   * X-Sabr-Admin-Secret matching SABR_ADMIN_MINT_SECRET — hand-minted
#     beta/tester tokens (beta testers). Unset env means NOBODY passes:
#     an unconfigured secret fails closed, never open.
#   * a Stripe Checkout session id (`stripeSessionId`) that THIS SERVER
#     verifies as paid against the Stripe API using STRIPE_SECRET_KEY.
#     The browser's word is never enough: the session must be complete,
#     actually paid, NOT a $0 setup-mode (trial card check) session, and
#     each session id mints at most one tenant, ever.
#
# The real paid flow does not call this endpoint at all — checkout-service
# (/opt/leon-brain/checkout-service/app.py) mints paid tokens inside its
# signature-verified Stripe /webhook, the success page redeems them via
# GET /install (re-verified against Stripe), and this server adopts them
# at install-config through the entitlement gateway. So the Stripe path
# here changes nothing for existing buyers; it is the verified door for
# any future page that wants to mint a tenant directly after checkout.
#
# Tenants minted BEFORE this change carry no minted_via and keep whatever
# expiry (usually none) they were born with — absent still means active,
# so nothing already issued changes standing.

#: How long a publicly-minted token lives. The same 24 hours the trial
#: always promised — the trial marker is now advisory (it sets the trial
#: flag), not the thing standing between the internet and a free product.
PUBLIC_MINT_TTL = 24 * 3600

#: Header carrying the admin mint secret. Compared with hmac.compare_digest.
_ADMIN_MINT_HEADER = "x-sabr-admin-secret"


def _admin_mint_secret() -> str:
    """The secret that authorizes a non-expiring hand-mint. Read per-call
    (not at import) so ops can rotate it without a restart-order dance."""
    return (os.environ.get("SABR_ADMIN_MINT_SECRET") or "").strip()


# One mint per Stripe checkout session, ever. A session id rides a success
# URL — browser history, referrer logs, a shared screenshot — so replaying
# it must never mint a second non-expiring tenant.
_PAID_SESSIONS_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "brain_state", "paid_checkout_sessions.json"
)
_paid_sessions_lock = threading.Lock()


def _load_paid_sessions() -> dict:
    try:
        with open(_PAID_SESSIONS_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _mark_paid_session(session_id: str, tenant_id: str):
    with _paid_sessions_lock:
        sessions = _load_paid_sessions()
        sessions[session_id] = {"tenant_id": tenant_id, "minted_at": time.time()}
        os.makedirs(os.path.dirname(_PAID_SESSIONS_FILE), exist_ok=True)
        tmp = _PAID_SESSIONS_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(sessions, f, indent=2)
        os.replace(tmp, _PAID_SESSIONS_FILE)


# ── Public-mint identity dedupe (found 2026-08-27) ───────────────────
#
# Every public mint already dies in PUBLIC_MINT_TTL — but nothing stopped
# the SAME PERSON from minting a new 24-hour account over and over, forever,
# just by typing a new name and a new email each time. The rate limiter
# throttles by IP, which a new incognito window or a different network
# defeats trivially.
#
# phone + address are now REQUIRED on every public mint (not on admin or
# paid mints — those are already gated by a secret or a real Stripe charge)
# and checked against an append-forever ledger, same fail-closed philosophy
# as the paid-session ledger just above: normalize, refuse a repeat, and
# only claim the slot AFTER the tenant actually exists so a failed create
# never burns someone's one shot.
_TRIAL_IDENTITY_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "brain_state", "public_mint_identity_ledger.json",
)
_trial_identity_lock = threading.Lock()


def _load_trial_identity() -> dict:
    try:
        with open(_TRIAL_IDENTITY_FILE) as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    data.setdefault("phones", {})
    data.setdefault("addresses", {})
    return data


def _save_trial_identity(data: dict):
    os.makedirs(os.path.dirname(_TRIAL_IDENTITY_FILE), exist_ok=True)
    tmp = _TRIAL_IDENTITY_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, _TRIAL_IDENTITY_FILE)


def _normalize_phone(raw: str):
    """Last 10 digits — same rule as the storefront's normalizePhone() and
    checkout-service's trial.py: formatting differences must collapse to
    the same identity key."""
    digits = "".join(c for c in (raw or "") if c.isdigit())
    if len(digits) < 10:
        return None
    return digits[-10:]


def _normalize_address(raw: str):
    """Lowercase, punctuation stripped, whitespace collapsed. Deliberately
    simple — it only needs to catch someone typing the same address twice,
    not defeat a determined typo."""
    cleaned = "".join(c.lower() if c.isalnum() else " " for c in (raw or ""))
    cleaned = " ".join(cleaned.split())
    return cleaned or None


def _claim_trial_identity(phone_norm: str, addr_norm: str, tenant_id: str, email: str):
    with _trial_identity_lock:
        data = _load_trial_identity()
        now = time.time()
        if phone_norm:
            data["phones"][phone_norm] = {
                "tenant_id": tenant_id, "email": email, "minted_at": now}
        if addr_norm:
            data["addresses"][addr_norm] = {
                "tenant_id": tenant_id, "email": email, "minted_at": now}
        _save_trial_identity(data)


class StripeVerifyError(Exception):
    """Stripe verification did not say 'paid'.

    retryable=True means WE couldn't determine the answer (network,
    Stripe 5xx, no key configured) — the caller answers 503 and the
    customer tries again. retryable=False is a real refusal (unknown
    session, unpaid, setup-mode) — the caller answers 402. Either way
    NOTHING non-expiring is minted: fail closed, never open.
    """

    def __init__(self, reason: str, retryable: bool = False):
        super().__init__(reason)
        self.reason = reason
        self.retryable = retryable


_STRIPE_SESSION_ID_RE = re.compile(r"^[A-Za-z0-9_]{8,255}$")


def _fetch_stripe_session(session_id: str) -> dict:
    """GET the checkout session from the Stripe API with OUR secret key.

    Deliberately a bare urllib call, not the stripe SDK — this server
    doesn't ship the SDK and one authenticated GET doesn't justify a new
    dependency. Module-level so tests can monkeypatch it.
    """
    key = (os.environ.get("STRIPE_SECRET_KEY") or "").strip()
    if not key:
        # Not configured is not a verdict about the customer's payment.
        raise StripeVerifyError("STRIPE_SECRET_KEY not configured", retryable=True)
    import urllib.error
    import urllib.parse
    import urllib.request
    url = ("https://api.stripe.com/v1/checkout/sessions/"
           + urllib.parse.quote(session_id, safe=""))
    request_ = urllib.request.Request(url, headers={"Authorization": "Bearer " + key})
    try:
        with urllib.request.urlopen(request_, timeout=15) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        if 400 <= e.code < 500:
            raise StripeVerifyError(f"Stripe rejected the session id ({e.code})")
        raise StripeVerifyError(f"Stripe API error {e.code}", retryable=True)
    except Exception as e:
        raise StripeVerifyError(f"Stripe unreachable: {type(e).__name__}",
                                retryable=True)


def _verify_paid_checkout_session(session_id: str) -> dict:
    """session id -> the session dict, ONLY if it is a real, paid purchase.

    Raises StripeVerifyError otherwise. Mirrors checkout-service
    /install's paid test (status complete + payment_status paid or
    no_payment_required) and ADDS the setup-mode refusal its /webhook
    branches on: a mode='setup' session collected a card and charged $0 —
    that is a trial signup, never a purchase.
    """
    sid = (session_id or "").strip()
    if not _STRIPE_SESSION_ID_RE.match(sid):
        raise StripeVerifyError("malformed session id")
    sess = _fetch_stripe_session(sid)
    if not isinstance(sess, dict) or sess.get("object") not in (None, "checkout.session"):
        raise StripeVerifyError("not a checkout session")
    if sess.get("mode") == "setup":
        raise StripeVerifyError("setup-mode ($0 card check) session is not a purchase")
    if sess.get("status") != "complete":
        raise StripeVerifyError("checkout session is not complete")
    if sess.get("payment_status") not in ("paid", "no_payment_required"):
        raise StripeVerifyError("checkout session is not paid")
    return sess

# ── Research knowledge the OWNER'S SI is born with ────────────────────
# Not "every SI", which is what this said and what it did. See the call site
# for the gate.
#
# OWNER-ONLY, and now structurally so. This used to be a 57-line literal
# right here: the vendor's unpublished physics research plus a biography
# of a named real human, shipped in plain text inside every
# customer's tarball. It now lives in brain/owner_facts.py, which
# landing/build_release.sh hard-excludes from the release — so on a shipped
# build this import fails and the list is empty, and there is nothing left
# for a bad gate, a renamed SI or a future refactor to leak.
#
# The si_name == "leon" check at the call site below STAYS. It is not
# redundant: provisioning runs on the owner's own host, where owner_facts.py
# exists, so origin cannot tell one tenant from another here. Which SI is
# being born is the only thing that can.
try:
    from brain.owner_facts import RESEARCH_SEED_FACTS
except Exception:
    RESEARCH_SEED_FACTS = []


def _seed_research_knowledge(store: KnowledgeStore):
    """Seed the OWNER's research knowledge into a tenant's store (owner install only)."""
    for text, tags in RESEARCH_SEED_FACTS:
        try:
            store.store(
                text=text,
                source="research_seed",
                tags=tags.split(","),
            )
        except Exception as e:
            log.warning(f"[ONBOARDING] Failed to seed fact: {e}")


def _seed_birth_memory(store: KnowledgeStore, profile: dict, birth_memory: dict):
    """Write the user's intake data into their SI's knowledge store."""
    # Profile facts
    parts = []
    if profile.get("userName"):
        parts.append(f"My creator's name is {profile['userName']}.")
    if profile.get("business"):
        parts.append(f"They run/work on: {profile['business']}.")
    if profile.get("dob"):
        parts.append(f"Their date of birth is {profile['dob']}.")
    if profile.get("email"):
        parts.append(f"Their email is {profile['email']}.")
    if parts:
        store.store(
            text=" ".join(parts),
            source="birth_intake",
            tags=["creator", "profile", "identity"],
        )

    # Voice transcript
    vt = birth_memory.get("voiceTranscript", "").strip()
    if vt:
        store.store(
            text=f"[Birth intake — voice transcript from {profile.get('userName', 'creator')}]: {vt}",
            source="birth_intake",
            tags=["creator", "intake", "voice"],
        )

    # Typed notes
    tn = birth_memory.get("typedNotes", "").strip()
    if tn:
        store.store(
            text=f"[Birth intake — typed notes from {profile.get('userName', 'creator')}]: {tn}",
            source="birth_intake",
            tags=["creator", "intake", "typed"],
        )

    # Uploaded files
    for f in birth_memory.get("files", []):
        ext = f.get("extractedText", "").strip()
        if ext:
            store.store(
                text=f"[Birth intake — uploaded file '{f.get('name', 'unknown')}']: {ext}",
                source="birth_intake",
                tags=["creator", "intake", "file", f.get("name", "")],
            )


# ── Endpoints ─────────────────────────────────────────────────────────

@router.post("/api/onboarding/create-account")
async def onboarding_create_account(req: dict, request: Request):
    """Create a new tenant (SI instance) for the user."""
    client_ip = _client_ip(request)

    # ── Mint grade: public | admin | paid ─────────────────────────────
    # Decided BEFORE anything exists, so a wrong admin secret or an
    # unpaid session id mints nothing at all. See the "Mint
    # authorization" section above for why public mints always expire.
    mint_grade = "public"
    stripe_session: dict = {}
    stripe_session_id = ""
    supplied_admin = (request.headers.get(_ADMIN_MINT_HEADER) or "").strip()
    if supplied_admin:
        expected = _admin_mint_secret()
        if not expected or not hmac.compare_digest(supplied_admin, expected):
            # Fail closed both ways: an UNSET secret must never read as
            # "any header value works".
            log.warning("[ONBOARDING] admin mint refused from %s (secret %s)",
                        client_ip, "unset" if not expected else "mismatch")
            return JSONResponse(
                {"ok": False, "error": "Invalid admin mint secret"}, 401)
        mint_grade = "admin"
    else:
        stripe_session_id = (req.get("stripeSessionId")
                             or req.get("stripe_session_id") or "").strip()
        if stripe_session_id:
            if stripe_session_id in _load_paid_sessions():
                return JSONResponse(
                    {"ok": False, "error": "That checkout session has already "
                     "been used to create an account. If this is you, email "
                     "support@sabr.co."}, 409)
            try:
                stripe_session = _verify_paid_checkout_session(stripe_session_id)
            except StripeVerifyError as e:
                log.warning("[ONBOARDING] paid mint refused from %s: %s",
                            client_ip, e.reason)
                if e.retryable:
                    return JSONResponse(
                        {"ok": False, "error": "We couldn't reach Stripe to "
                         "verify your payment. Nothing is wrong with your "
                         "purchase — wait a moment and try again."}, 503)
                return JSONResponse(
                    {"ok": False, "error": "We couldn't verify a completed "
                     "payment for that checkout session, so no account was "
                     "created. If you did pay, email support@sabr.co."}, 402)
            mint_grade = "paid"

    # Rate limit by IP. The admin secret IS authentication, so a batch of
    # hand-minted beta tokens doesn't fight the public limiter; everyone
    # else (including Stripe-verified mints — one per session anyway)
    # stays behind it exactly as before.
    if mint_grade != "admin" and not _check_rate_limit(client_ip):
        return JSONResponse(
            {"ok": False, "error": "Too many accounts created. Try again later."},
            status_code=429,
        )

    si_name = (req.get("siName") or "").strip()[:50]
    user_name = (req.get("userName") or "").strip()[:100]
    email = (req.get("email") or "").strip()[:254]
    business = (req.get("business") or "").strip()[:200]
    dob = (req.get("dob") or "").strip()[:10]
    api_key = (req.get("apiKey") or "").strip()
    phone = (req.get("phone") or "").strip()[:30]
    address = (req.get("address") or "").strip()[:200]

    if not si_name:
        return JSONResponse({"ok": False, "error": "SI name is required"}, 400)
    if not user_name:
        return JSONResponse({"ok": False, "error": "Your name is required"}, 400)
    if not email or not _EMAIL_RE.match(email):
        return JSONResponse({"ok": False, "error": "Valid email required"}, 400)

    # phone/address only apply to PUBLIC mints (admin and paid are already
    # gated by a secret or a real charge) — see "Public-mint identity
    # dedupe" above for why these exist at all.
    phone_norm = None
    addr_norm = None
    if mint_grade == "public":
        phone_norm = _normalize_phone(phone)
        addr_norm = _normalize_address(address)
        if not phone_norm:
            return JSONResponse({"ok": False, "error":
                "A real phone number is required — one trial per person, "
                "not one per email address."}, 400)
        if not addr_norm:
            return JSONResponse({"ok": False, "error":
                "A real address is required — one trial per person, "
                "not one per email address."}, 400)
        identity = _load_trial_identity()
        if identity["phones"].get(phone_norm):
            return JSONResponse({"ok": False, "error":
                "That phone number has already been used for a free trial. "
                "Email support@sabr.co if this is a mistake."}, 403)
        if identity["addresses"].get(addr_norm):
            return JSONResponse({"ok": False, "error":
                "That address has already been used for a free trial. "
                "Email support@sabr.co if this is a mistake."}, 403)
    elevenlabs_key = (req.get("elevenlabsKey") or "").strip()
    elevenlabs_voice_id = (req.get("elevenlabsVoiceId") or "").strip()
    elevenlabs_voice_name = (req.get("elevenlabsVoiceName") or "").strip()
    promo_code = (req.get("promoCode") or "").strip().upper()

    # Validate promo code if provided
    promo_result = {"valid": False}
    if promo_code:
        promo_result = _validate_promo(promo_code)
        if not promo_result["valid"]:
            return JSONResponse({"ok": False, "error": promo_result.get("error", "Invalid promo code")}, 400)

    # API key is fully optional — no validation

    # Encrypt API keys before storing (if provided)
    encrypted_key = _encrypt_api_key(api_key) if api_key else ""
    encrypted_el_key = _encrypt_api_key(elevenlabs_key) if elevenlabs_key else ""

    try:
        created_ts = time.time()
        metadata = {
            "si_name": si_name,
            "user_name": user_name,
            "email": email,
            "business": business,
            "dob": dob,
            "encrypted_api_key": encrypted_key,
            "encrypted_elevenlabs_key": encrypted_el_key,
            "elevenlabs_voice_id": elevenlabs_voice_id,
            "elevenlabs_voice_name": elevenlabs_voice_name,
            "created_via": "onboarding",
            "created_at": created_ts,
            "consent_ts": created_ts,
            "consent_ip": client_ip,
            "promo_code": promo_code if promo_result.get("valid") else "",
            "promo_discount": promo_result.get("discount_pct", 0) if promo_result.get("valid") else 0,
            "minted_via": mint_grade,
        }
        # 24-hour free trial. The website signals a trial signup by writing
        # it into the business field (business: '24-hour free trial'), so the
        # trial flag and expiry are stamped HERE, at mint time, into the same
        # metadata the heartbeat and install-config read. The marker wins
        # over every mint grade — a request that SAYS it is a trial gets a
        # trial, expiring, no matter what else it carried.
        if "24-hour free trial" in business.lower():
            metadata["trial"] = "24h"
            metadata["expires_at"] = created_ts + 24 * 3600
        elif mint_grade == "public":
            # The DEFAULT, not the exception. Expiry used to hinge on the
            # trial marker above, which the browser controls — omitting six
            # words minted a permanent token. Every public mint now dies in
            # PUBLIC_MINT_TTL; only the admin secret or a server-verified
            # Stripe purchase (below) mints something that outlives it.
            metadata["expires_at"] = created_ts + PUBLIC_MINT_TTL
        if mint_grade == "paid":
            # Audit trail binding the non-expiring tenant to the purchase
            # that authorized it. One session, one tenant (ledger below).
            metadata["stripe_session_id"] = stripe_session_id
            metadata["stripe_customer"] = str(stripe_session.get("customer") or "")
            metadata["stripe_payment_status"] = str(stripe_session.get("payment_status") or "")
        tenant = tenant_manager.create_tenant(
            name=si_name,
            role="admin",
            metadata=metadata,
        )
    except Exception as e:
        log.error(f"[ONBOARDING] Tenant creation failed: {e}")
        return JSONResponse({"ok": False, "error": str(e)}, 500)

    # Burn the checkout session ONLY after the tenant actually exists —
    # a creation failure must not eat the customer's one redemption.
    # (Two truly simultaneous requests could both pass the early ledger
    # check; worst case is two tenants for one verified purchase, which
    # support can see and fix — never a free mind for a non-payer.)
    if mint_grade == "paid" and stripe_session_id:
        _mark_paid_session(stripe_session_id, tenant.tenant_id)
        log.info("[ONBOARDING] paid mint: session %s... -> tenant %s",
                 stripe_session_id[:12], tenant.tenant_id[:8])
    elif mint_grade == "admin":
        log.info("[ONBOARDING] admin mint: tenant %s (%s)",
                 tenant.tenant_id[:8], si_name)
    elif mint_grade == "public" and (phone_norm or addr_norm):
        _claim_trial_identity(phone_norm, addr_norm, tenant.tenant_id, email)

    # Mark promo code as used
    if promo_code and promo_result.get("valid"):
        _use_promo(promo_code)
        log.info(f"[ONBOARDING] Promo code {promo_code} applied for {si_name}")

    # Seed the research knowledge into this new SI.
    # OWNER-ONLY. RESEARCH_SEED_FACTS is the vendor's unpublished research IP
    # plus the owner's personal biography. It was previously written into EVERY new
    # tenant's knowledge store at birth — a permanent SQLite record on the
    # customer's disk that no later prompt filter can undo. A beta tester's
    # SI would have been born reciting the physics and its author. Only an
    # SI named Leon (the owner's own) gets these.
    if (si_name or "").strip().lower() == "leon":
        store = tenant_manager.get_store(tenant.tenant_id)
        if store:
            _seed_research_knowledge(store)
            log.info(f"[ONBOARDING] Seeded {len(RESEARCH_SEED_FACTS)} research facts for {si_name}")
    else:
        log.info(f"[ONBOARDING] Client SI '{si_name}' — skipping owner's research IP")

    resp = {
        "ok": True,
        "tenant_id": tenant.tenant_id,
        "token": tenant.token,
        "si_name": si_name,
    }
    if tenant.metadata.get("expires_at"):
        # Trial signups get told when their trial ends, in the same coin
        # (unix ts) the metadata stores it in.
        resp["expires_at"] = tenant.metadata["expires_at"]
    return resp


@router.post("/api/onboarding/intake")
async def onboarding_intake(req: dict):
    """Store the deep-intake data (voice + typed + files) into the SI's memory."""
    token = req.get("token")
    tenant_id = req.get("tenant_id")
    profile = req.get("profile", {})
    birth_memory = req.get("birthMemory", {})

    # Resolve tenant
    tenant = None
    if token:
        tenant = tenant_manager.auth(token)
    if tenant is None and tenant_id:
        tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid tenant"}, 401)

    store = tenant_manager.get_store(tenant.tenant_id)
    if not store:
        return JSONResponse({"ok": False, "error": "Store not found"}, 500)

    _seed_birth_memory(store, profile, birth_memory)

    return {"ok": True, "tenant_id": tenant.tenant_id}


@router.post("/api/onboarding/upload")
async def onboarding_upload(
    file: UploadFile = File(...),
    token: Optional[str] = Form(None),
):
    """Upload a file, extract text, return it. Text is stored at birth time."""
    content = await file.read()
    if len(content) > MAX_UPLOAD_SIZE:
        return JSONResponse(
            {"ok": False, "error": f"File too large (max {MAX_UPLOAD_SIZE // 1024 // 1024}MB)"},
            status_code=413,
        )
    # Sanitize filename (strip path components, limit length)
    filename = os.path.basename(file.filename or "unknown")[:255]
    extracted = ""

    try:
        if filename.lower().endswith(".pdf"):
            extracted = _extract_pdf(content)
        elif filename.lower().endswith((".txt", ".md", ".csv")):
            extracted = content.decode("utf-8", errors="replace")
        elif filename.lower().endswith((".doc", ".docx")):
            extracted = _extract_docx(content)
        elif filename.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
            extracted = f"[Image file: {filename} — {len(content)} bytes]"
        elif filename.lower().endswith((".xls", ".xlsx")):
            extracted = f"[Spreadsheet: {filename} — {len(content)} bytes]"
        else:
            # Try as plain text
            try:
                extracted = content.decode("utf-8", errors="replace")
            except Exception:
                extracted = f"[Binary file: {filename} — {len(content)} bytes]"
    except Exception as e:
        log.warning(f"[ONBOARDING] File extraction failed for {filename}: {e}")
        extracted = f"[File: {filename} — extraction failed]"

    return {
        "ok": True,
        "filename": filename,
        "extracted_text": extracted[:50000],  # Cap at 50K chars
        "size": len(content),
    }


@router.post("/api/onboarding/transcribe")
async def onboarding_transcribe(
    audio: UploadFile = File(...),
    token: Optional[str] = Form(None),
):
    """Transcribe voice audio from the intake step."""
    content = await audio.read()

    # Try Whisper (local) first, then fall back to a simple message
    transcript = ""
    try:
        transcript = await _transcribe_audio(content)
    except Exception as e:
        log.warning(f"[ONBOARDING] Transcription failed: {e}")
        return JSONResponse({
            "ok": False,
            "error": "Transcription unavailable — please type instead",
        })

    return {"ok": True, "transcript": transcript}


@router.post("/api/onboarding/birth")
async def onboarding_birth(req: dict):
    """Birth the SI — generate personalized first-contact greeting."""
    token = req.get("token")
    tenant_id = req.get("tenant_id")
    profile = req.get("profile", {})
    birth_memory = req.get("birthMemory", {})

    # Resolve tenant
    tenant = None
    if token:
        tenant = tenant_manager.auth(token)
    if tenant is None and tenant_id:
        tenant = tenant_manager.get_tenant(tenant_id)

    si_name = profile.get("siName", "Your SI")
    user_name = profile.get("userName", "friend")
    business = profile.get("business", "")

    # Build personalized greeting from intake data
    greeting = _build_greeting(si_name, user_name, business, birth_memory)

    # Mark tenant as born
    if tenant:
        tenant.metadata["born"] = True
        tenant.metadata["born_at"] = time.time()
        # Hosted brains get their birth memory synced over (or flagged for
        # sync the moment provisioning finishes, if birth won the race).
        if tenant.metadata.get("brain_mode") == "hosted":
            hreg = _hosted_registry()["tenants"].get(tenant.tenant_id) or {}
            if hreg.get("status") == "ready":
                threading.Thread(target=_sync_hosted_birth,
                                 args=(tenant.tenant_id,), daemon=True).start()
            else:
                tenant.metadata["birth_sync_pending"] = True
        tenant_manager._save_registry()

    return {
        "ok": True,
        "greeting": greeting,
        "si_name": si_name,
    }


# ── Machine assessment → local-vs-hosted brain recommendation ─────────
# The wizard sends what it can detect from the browser (deviceMemory caps
# at 8 in Chrome, hardwareConcurrency, platform) plus what it asked the
# user (RAM tier, desktop/laptop, always-on preference). We recommend —
# honestly, with reasons — and the user decides. Their choice + specs go
# into tenant metadata; the installer reads the choice via install-config.

BRAIN_RAM_COMFORT_GB = 24  # local brain runs comfortably alongside the owner's apps
BRAIN_RAM_FLOOR_GB = 16    # runs, but competes with the owner's apps for RAM/CPU


def _recommend_brain(specs: dict) -> dict:
    """Pure function: machine specs + preferences → recommendation."""
    ram = specs.get("ram_gb")
    cores = specs.get("cores")
    dev_mem = specs.get("device_memory")
    machine = (specs.get("machine_type") or "").lower()
    always_on = specs.get("always_on")

    factors = []
    if ram is None and dev_mem is not None:
        # Browser hint: deviceMemory < 8 means the machine really is small
        # (the API caps at 8, so 8 tells us nothing about 8-vs-64).
        if dev_mem < 8:
            ram = int(dev_mem)
            factors.append(f"Your browser reports about {dev_mem}GB of memory.")

    if ram is None:
        rec = "hosted"
        factors.append("We couldn't confirm how much memory this machine has, "
                       "so we're recommending the safe default.")
    elif ram >= BRAIN_RAM_COMFORT_GB:
        rec = "local"
        factors.append(f"With {ram}GB of RAM, the brain (which wants 2–4GB and "
                       "a couple of cores to itself) runs comfortably alongside "
                       "everything else you do.")
    elif ram >= BRAIN_RAM_FLOOR_GB:
        rec = "hosted"
        factors.append(f"{ram}GB runs the brain, but it competes with your apps "
                       "for memory — things get slow exactly when you're busiest. "
                       "Hosted keeps your machine light.")
    else:
        rec = "hosted"
        factors.append(f"{ram}GB isn't enough to run the brain alongside your "
                       "apps. Hosted is the right call here.")

    if isinstance(cores, int) and cores > 0 and cores < 4 and rec == "local":
        rec = "hosted"
        factors.append(f"Only {cores} CPU cores — the brain's simulation would "
                       "fight your apps for them.")

    if machine == "laptop" and always_on:
        factors.append("A laptop that sleeps takes your SI offline with it. "
                       "A hosted brain stays awake 24/7 — your SI is there even "
                       "when the lid is closed."
                       + (" That's worth weighing against running locally."
                          if rec == "local" else ""))
        if rec == "local":
            rec = "hosted"

    if rec == "local":
        headline = "Run the brain on this machine."
        factors.append("Local means everything stays on your hardware — full "
                       "privacy, no hosting dependency.")
    else:
        headline = "Run the brain hosted; keep this machine light."
        factors.append("Your machine runs the body (screen, voice, hands) and "
                       "connects to your brain securely. You can move the brain "
                       "onto your own hardware anytime.")

    return {"recommendation": rec, "headline": headline, "factors": factors}


@router.post("/api/onboarding/assess")
async def onboarding_assess(req: dict):
    """Assess the customer's machine and recommend local vs hosted brain."""
    specs = req.get("specs") or {}
    # Sanitize: only known keys, only sane types/ranges
    clean = {}
    for key, cast, lo, hi in (("ram_gb", int, 1, 4096),
                              ("cores", int, 1, 512),
                              ("device_memory", float, 0.25, 8)):
        try:
            v = cast(specs.get(key))
            if lo <= v <= hi:
                clean[key] = v
        except (TypeError, ValueError):
            pass
    if specs.get("machine_type") in ("desktop", "laptop"):
        clean["machine_type"] = specs["machine_type"]
    if isinstance(specs.get("always_on"), bool):
        clean["always_on"] = specs["always_on"]
    clean["platform"] = str(specs.get("platform") or "")[:80]

    result = _recommend_brain(clean)

    # Persist specs + recommendation on the tenant if a token came along
    token = req.get("token")
    tenant = tenant_manager.auth(token) if token else None
    if tenant:
        tenant.metadata["machine_specs"] = clean
        tenant.metadata["brain_recommendation"] = result["recommendation"]
        tenant_manager._save_registry()

    return {"ok": True, **result}


# ── Phase 3: hosted-brain provisioning ───────────────────────────────
_TENANTS_ROOT = "/opt/leon-tenants"
_APP_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_MAX_HOSTED = int(os.environ.get("SABR_MAX_HOSTED_TENANTS", "5"))

# ── release digest, handed to the installer over the authenticated config ──
# Hashed from the exact file /download serves, not read from the .sha256
# sidecar: the sidecar is written by the build script and can drift if a
# tarball is ever replaced without it. Cached on (size, mtime) so a 20 MB
# re-hash doesn't run on every install-config call.
_RELEASE_TARBALL = os.path.join(_APP_ROOT, "landing", "leon-brain-release.tar.gz")
_release_sha_cache: dict = {}


def _release_sha256() -> str:
    """sha256 of the release tarball, or "" if it isn't on disk."""
    try:
        st = os.stat(_RELEASE_TARBALL)
    except OSError:
        return ""
    key = (st.st_size, st.st_mtime_ns)
    if _release_sha_cache.get("key") == key:
        return _release_sha_cache["digest"]
    h = hashlib.sha256()
    try:
        with open(_RELEASE_TARBALL, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    except OSError:
        return ""
    digest = h.hexdigest()
    _release_sha_cache.update(key=key, digest=digest)
    return digest


# ── release commit, published with the release metadata ────────────────────
# NOTE 2026-08-30: the two git-clone install paths this was written for
# (setup-prompt, install-script) are RETIRED and now answer 410 — see the
# comment above them. This helper stays because /api/onboarding/release-info
# still publishes the commit alongside the tarball digest.
# Original rationale: setup-prompt and install-script cloned
# sabrtechnologies/leon-brain directly rather
# than downloading the tarball — they need a commit to pin to for the same
# reason the tarball needs a digest: an unpinned `git clone` installs
# whatever happens to be on master the moment a customer runs it, not the
# reviewed release. Written by build_client_release.sh in the SAME step that
# produces the tarball (atomically: temp file + rename), so this can never
# name a commit that doesn't match what's actually being served.
_RELEASE_COMMIT_FILE = os.path.join(_APP_ROOT, "landing", "RELEASE_COMMIT")


def _release_commit() -> str:
    """The exact commit the current release tarball was built from, or ""
    if the build script hasn't written one yet (older release, or a build
    that predates this file existing)."""
    try:
        with open(_RELEASE_COMMIT_FILE, "r", encoding="utf-8") as f:
            sha = f.read().strip()
    except OSError:
        return ""
    # 40 hex chars — a full SHA-1 commit hash, not a short/abbreviated one
    # (short hashes aren't guaranteed unique and some git hosts silently
    # accept an ambiguous prefix, which defeats the point of pinning).
    if len(sha) == 40 and all(c in "0123456789abcdef" for c in sha.lower()):
        return sha.lower()
    return ""


def _hosted_registry() -> dict:
    try:
        with open(os.path.join(_TENANTS_ROOT, "registry.json")) as f:
            return json.load(f)
    except OSError:
        return {"tenants": {}}


def _hosted_capacity_used() -> int:
    return sum(1 for t in _hosted_registry()["tenants"].values()
               if t.get("status") in ("ready", "provisioning"))


def _sync_hosted_birth(tenant_id: str) -> bool:
    """Copy the tenant's knowledge (intake + birth memory + seeded research)
    from the main brain's store into their hosted brain's tree, mark them
    born there, and restart the hosted unit so it reopens the db. Intake
    happens AFTER provisioning starts, so this runs at birth (or right
    after provisioning finishes if birth beat it — birth_sync_pending)."""
    reg = _hosted_registry()["tenants"].get(tenant_id)
    if not reg or reg.get("status") != "ready":
        return False
    src = os.path.join(_APP_ROOT, "brain_state", "tenants", tenant_id)
    tree = os.path.join(_TENANTS_ROOT, tenant_id, "leon-brain")
    dst = os.path.join(tree, "brain_state", "tenants", tenant_id)
    try:
        if os.path.isdir(src):
            os.makedirs(dst, exist_ok=True)
            for fn in os.listdir(src):
                s = os.path.join(src, fn)
                if os.path.isfile(s):
                    shutil.copy2(s, os.path.join(dst, fn))
        reg_path = os.path.join(tree, "brain_state", "registry.json")
        with open(reg_path) as f:
            hreg = json.load(f)
        for t in hreg.get("tenants", []):
            if t.get("tenant_id") == tenant_id:
                t.setdefault("metadata", {})["born"] = True
                t["metadata"]["born_at"] = time.time()
        with open(reg_path, "w") as f:
            json.dump(hreg, f, indent=2)
        user = f"lt-{reg['slug']}"[:31]
        subprocess.run(["chown", "-R", f"{user}:{user}", dst], capture_output=True)
        subprocess.run(["chown", f"{user}:{user}", reg_path], capture_output=True)
        subprocess.run(["systemctl", "restart",
                        reg.get("unit", f"leon-tenant-{reg['slug']}.service")],
                       capture_output=True)
        log.info(f"[HOSTED] birth memory synced → {tenant_id[:8]}")
        return True
    except Exception as e:
        log.warning(f"[HOSTED] birth sync failed for {tenant_id[:8]}: {e}")
        return False


def _spawn_provisioner(tenant_id: str, force: bool = False) -> None:
    """Run the provisioner in the background; flip tenant metadata on finish.

    Metadata is only ever updated HERE (inside the server process) — the
    provisioner subprocess never writes the main tenant registry, so the
    in-memory tenant_manager can't be clobbered by a concurrent save."""
    tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return
    tenant.metadata["hosted_status"] = "provisioning"
    tenant_manager._save_registry()

    def _run():
        home = os.path.join(_TENANTS_ROOT, tenant_id)
        os.makedirs(home, exist_ok=True)
        cmd = [sys.executable, os.path.join(_APP_ROOT, "scripts", "provision_tenant_brain.py"),
               tenant_id] + (["--force"] if force else [])
        with open(os.path.join(home, "provision.log"), "ab") as logf:
            rc = subprocess.call(cmd, stdout=logf, stderr=subprocess.STDOUT, cwd=_APP_ROOT)
        t = tenant_manager.get_tenant(tenant_id)
        if t is None:
            return
        try:
            with open(os.path.join(home, "result.json")) as f:
                res = json.load(f)
        except OSError:
            res = {"ok": False, "error": f"provisioner exited {rc} with no result.json"}
        if res.get("ok"):
            t.metadata["hosted_status"] = "ready"
            t.metadata["hosted_brain_url"] = res.get("brain_url", "")
            t.metadata["encrypted_hosted_api_key"] = _encrypt_api_key(res.get("api_key", ""))
            t.metadata["hosted_llm_source"] = res.get("llm", "")  # customer | sabr-provided | NONE…
            log.info(f"[HOSTED] tenant {tenant_id[:8]} brain ready at "
                     f"{res.get('brain_url')} (llm: {res.get('llm')})")
            if t.metadata.pop("birth_sync_pending", False):
                tenant_manager._save_registry()
                _sync_hosted_birth(tenant_id)
        else:
            t.metadata["hosted_status"] = "failed"
            t.metadata["hosted_error"] = str(res.get("error", ""))[:300]
            log.warning(f"[HOSTED] tenant {tenant_id[:8]} provision FAILED: {res.get('error')}")
        tenant_manager._save_registry()

    threading.Thread(target=_run, daemon=True, name=f"provision-{tenant_id[:8]}").start()


@router.post("/api/admin/provision-hosted")
async def admin_provision_hosted(req: dict):
    """Kick provisioning for a tenant (LEON_API_KEY gated by /api middleware)."""
    tenant_id = (req.get("tenant_id") or "").strip()
    tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "unknown tenant"}, 404)
    if tenant.metadata.get("hosted_status") == "provisioning" and not req.get("force"):
        return {"ok": True, "status": "provisioning", "note": "already running"}
    _spawn_provisioner(tenant_id, force=bool(req.get("force")))
    return {"ok": True, "status": "provisioning"}


@router.get("/api/admin/hosted-tenants")
async def admin_hosted_tenants():
    reg = _hosted_registry()
    return {"ok": True, "capacity": {"used": _hosted_capacity_used(), "max": _MAX_HOSTED},
            "tenants": {tid: {k: v for k, v in t.items() if k != "api_key"}
                        for tid, t in reg["tenants"].items()}}


@router.post("/api/onboarding/choose-brain")
async def onboarding_choose_brain(req: dict):
    """Record the user's local-vs-hosted decision (and their service keys)."""
    token = req.get("token")
    tenant = tenant_manager.auth(token) if token else None
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid tenant"}, 401)

    choice = (req.get("choice") or "").strip().lower()
    if choice not in ("local", "hosted"):
        return JSONResponse({"ok": False, "error": "choice must be 'local' or 'hosted'"}, 400)

    tenant.metadata["brain_mode"] = choice
    tenant.metadata["brain_mode_chosen_at"] = time.time()

    # BYO Claude: a hosted customer supplies their own Anthropic API key, billed
    # to their own API account. Stored encrypted; the provisioner prefers it over
    # any Sabr-provided fallback. Accept it here (the hosted decision point) as
    # well as at create-account. Only overwrite when a non-empty key is sent, so
    # re-submitting the wizard without re-typing the key doesn't wipe it.
    anthropic_key = (req.get("anthropicApiKey") or "").strip()
    if anthropic_key:
        tenant.metadata["encrypted_api_key"] = _encrypt_api_key(anthropic_key[:200])

    if choice == "hosted":
        # Phase 3: kick provisioning right away when there's capacity; the
        # installer polls install-config and sees the status flip to ready.
        cur = tenant.metadata.get("hosted_status")
        if cur not in ("ready", "provisioning"):
            if _hosted_capacity_used() < _MAX_HOSTED:
                _spawn_provisioner(tenant.tenant_id)
            else:
                tenant.metadata["hosted_status"] = "waitlist"
                log.warning(f"[HOSTED] capacity full — tenant {tenant.tenant_id[:8]} waitlisted")

    # Service selections + API keys from the connect step. Keys are
    # encrypted at rest exactly like the Anthropic/ElevenLabs keys.
    services = req.get("services")
    if isinstance(services, list):
        tenant.metadata["services"] = [str(s)[:40] for s in services[:40]]
    service_keys = req.get("serviceKeys")
    if isinstance(service_keys, dict):
        tenant.metadata["encrypted_service_keys"] = {
            str(k)[:64]: _encrypt_api_key(str(v)[:512])
            for k, v in list(service_keys.items())[:40] if v
        }

    tenant_manager._save_registry()
    return {"ok": True, "brain_mode": choice}


_TOKEN_RE = re.compile(r"(?:SABR_TENANT_TOKEN=|LEON_TENANT_TOKEN=|token:\s*)([0-9a-fA-F]{24,64})")
_BARE_TOKEN_RE = re.compile(r"\b([0-9a-f]{32})\b")


def _clean_token(raw: str) -> str:
    """Pull the real token out of whatever a human actually pasted.

    Observed in the wild 2026-07-30: a buyer pasted the ENTIRE one-line
    install command into the installer's token box, because the onboarding
    page hands him a curl command and the installer asks for "your token".
    The string arrived as `curl -fsSL ... SABR_TENANT_TOKEN=966d... bash`
    and the endpoint said "not recognized" for a token that was perfectly
    valid and paid for. That is our bug, not his.

    So: if the paste contains an explicit token assignment, take it; else
    take the first bare 32-hex run; else return the trimmed string and let
    normal validation reject it.
    """
    s = (raw or "").strip().strip('"').strip("'")
    if not s:
        return ""
    m = _TOKEN_RE.search(s)
    if m:
        return m.group(1).lower()
    m = _BARE_TOKEN_RE.search(s.lower())
    if m:
        return m.group(1)
    return s


# ── Licensing: the one function that decides a tenant's standing ──────
#
# Two metadata fields, both optional, both absent on every tenant minted
# before 2026-08-25 (absent == active, so nothing existing changes):
#
#   revoked     bool     — set by hand (or a future admin endpoint) to cut
#                          a customer off. Wins over everything.
#   expires_at  unix ts  — since 2026-08-25, stamped on EVERY public
#                          create-account mint (trials keep their marker
#                          flag too); absent only on admin-secret and
#                          Stripe-verified mints, on checkout adoptions,
#                          and on tenants minted before the change.
#                          In the past == expired.
#
# Read in exactly two places: the heartbeat below (so an installed SI
# learns its standing daily) and install-config (so an expired trial can't
# just reinstall its way back in).

def _tenant_license_status(tenant, now: Optional[float] = None) -> str:
    """'active' | 'revoked' | 'expired' for a tenant we actually know."""
    md = tenant.metadata or {}
    if md.get("revoked"):
        return "revoked"
    exp = md.get("expires_at")
    if exp:
        try:
            exp = float(exp)
        except (TypeError, ValueError):
            # A malformed expiry is not a verdict against the customer.
            exp = None
        if exp and exp < (now if now is not None else time.time()):
            return "expired"
    elif str(md.get("kind") or "").strip().lower() == "trial":
        # A row that SAYS it is a trial and carries no deadline is malformed,
        # and the fail-closed reading is the only safe one: a 24-hour trial
        # whose expiry went missing is otherwise a permanent free mind.
        # entitlement.evaluate() has always treated a trial row with no
        # expires_at as expired for exactly this reason; the registry now
        # agrees instead of answering 'active'.
        #
        # SAFE FOR EVERY EXISTING TENANT, deliberately narrow: `kind` is
        # written by precisely two code paths, both newer than this rule —
        # install-config's adoption and /api/internal/token-upsert — and both
        # write expires_at in the same breath when the gateway supplies one.
        # Registry-native trials mark themselves with metadata['trial']='24h'
        # (always alongside an expires_at) and are NOT matched here, so a
        # comped tenant whose expiry was cleared by hand keeps working.
        log.warning("[LICENSE] tenant %s is kind=trial with no expires_at "
                    "— failing closed as expired", tenant.tenant_id[:8])
        return "expired"
    return "active"


def _license_rejection(status: str):
    """The install-config refusal for a non-active tenant — clear about
    WHICH problem it is, because 'invalid token' to someone whose trial
    just ended reads as a bug, and to someone revoked reads as a dodge."""
    if status == "revoked":
        return JSONResponse(
            {"ok": False, "error": "This account has been revoked and can no "
             "longer install or run an SI. If you believe this is a mistake, "
             "email support@sabr.co."}, 403)
    return JSONResponse(
        {"ok": False, "error": "Your 24-hour free trial has ended, so this "
         "token can't install an SI anymore. To keep your SI (and everything "
         "it learned), subscribe at https://sabrtechnologies.com — or email "
         "support@sabr.co."}, 403)


def _gateway_denial_status(answer: dict) -> Optional[str]:
    """Map an entitlement-gateway denial to a heartbeat verdict word, or
    None when the denial is not a definitive licence verdict.

    Definitive: 'suspended' (cancel / refund / chargeback, or grace
    exhausted — every one a positive Stripe signal) → revoked;
    'trial_expired' → expired. Everything ELSE a denial can be —
    'unknown' (a gap in the checkout store, which was the DEFAULT
    post-deploy state for real customers before ENTITLEMENT_STORE moved
    to a volume), 'throttled' (a rate condition, never a money one),
    'trial_machine_mismatch' — is NOT a verdict against a tenant the
    registry already vouches for, and answers None so the registry's
    word stands."""
    if answer.get("trial_expired"):
        return "expired"
    state = str((answer.get("report") or {}).get("state") or "").strip().lower()
    if state == "trial_expired":
        return "expired"
    if state == "suspended":
        return "revoked"
    return None


def _checkout_gateway_recheck(token: str, tenant, status: str) -> str:
    """For a checkout-origin tenant the registry calls 'active', give the
    entitlement gateway a vote — and take the MORE RESTRICTIVE answer.

    Audit D4/D6. A checkout token adopted into the registry at install time
    carries no revoked/expires_at, so once adopted the registry answered
    'active' forever: a refund, a chargeback or an ended trial that suspended
    the token in the billing store was invisible here. Both the daily
    heartbeat AND the install path consult this, because they are the two
    doors — a customer who can no longer heartbeat but CAN reinstall has
    simply been told which door to use.

    FAIL-OPEN on anything short of a definitive verdict. refresh_lease turns
    every network error and 5xx into {"reachable": False}, the try/except
    catches a client that explodes outright, and 'unknown'/'throttled' are
    not verdicts (see _gateway_denial_status). In every one of those cases
    the registry's 'active' stands: an outage on the checkout service must
    never come out of here as a word a customer is denied by.

    Once registry write-through is live (checkout-service/registry_sync.py)
    this is belt to that braces — the refund lands in the registry directly
    and `status` is already 'revoked' before we get here. It stays as the
    migration's safety net and for tenants adopted before the write-through.
    """
    if status != "active":
        return status
    if (tenant.metadata or {}).get("source") != "checkout":
        return status
    try:
        from brain.tenant import refresh_lease
        gate = refresh_lease(token)
    except Exception as e:
        log.warning("licence: gateway recheck failed open: %s", e)
        return status
    if not gate.get("reachable"):
        return status
    answer = gate.get("answer") or {}
    if answer.get("allow"):
        return status
    denial = _gateway_denial_status(answer)
    if denial:
        log.info("licence: gateway out-voted registry for %s... -> %s",
                 token[:8], denial)
        return denial
    return status


def _heartbeat_verdict(token: str):
    """Shared body for GET and POST /api/onboarding/heartbeat.

    The contract with brain/license_heartbeat.py on customer machines:
      * A definitive verdict is ALWAYS a 200 with {ok, status} where
        status ∈ {active, expired, revoked}. Clients only ever act on
        those three words.
      * 5xx (and anything unparseable) means WE failed, and clients fail
        OPEN — so this function may only 500 by accident, never as an
        answer, and the outer try/except exists to make even the
        accident carry status 'error' rather than a word clients obey.
      * A token we genuinely don't know fails CLOSED (revoked): the
        registry is the ledger, and 32 typed characters are not a
        licence. The one exception mirrors install-config: a checkout-
        minted token the entitlement gateway vouches for is a paying
        customer whose install predates adoption — active. Gateway
        unreachable → 503, honestly undetermined, never 'revoked'.
      * A checkout-ADOPTED tenant the registry answers 'active' for gets
        one more check (audit D4, 2026-08-25): the registry row was
        minted at install time and never hears about refunds, so the
        gateway's word is fresher — a definitive REVOKED/EXPIRED from it
        out-votes the bare registry hit. Anything less than definitive
        (unreachable, 5xx, 'unknown', 'throttled') leaves the registry
        answer standing: a network problem must never become a denial.
    """
    try:
        token = _clean_token(token)
        tenant = tenant_manager.auth(token) if token else None
        if tenant is None:
            if token:
                try:
                    from brain.tenant import refresh_lease
                    gate = refresh_lease(token)
                except Exception as e:
                    log.warning("heartbeat: gateway check failed: %s", e)
                    gate = {"reachable": False, "error": type(e).__name__}
                if gate.get("reachable"):
                    if (gate.get("answer") or {}).get("allow"):
                        return {"ok": True, "status": "active"}
                else:
                    return JSONResponse(
                        {"ok": False, "status": "unknown",
                         "error": "licence service unreachable — try again"},
                        503)
            return {"ok": False, "status": "revoked"}
        # Refund evasion fix (audit D4/D6) — see _checkout_gateway_recheck.
        # Shared verbatim with install-config so the two doors can never
        # disagree about the same customer.
        status = _checkout_gateway_recheck(
            token, tenant, _tenant_license_status(tenant))
        return {"ok": status == "active", "status": status}
    except Exception as e:
        log.error("heartbeat: internal error: %s", e)
        return JSONResponse({"ok": False, "status": "error"}, 500)


@router.get("/api/onboarding/heartbeat")
async def onboarding_heartbeat(token: str = ""):
    """Daily phone-home for installed SIs. See _heartbeat_verdict."""
    return _heartbeat_verdict(token)


@router.post("/api/onboarding/heartbeat")
async def onboarding_heartbeat_post(req: dict):
    """POST twin of the heartbeat, for clients that keep the token out of
    URLs (and therefore out of access logs)."""
    return _heartbeat_verdict((req or {}).get("token") or "")


@router.get("/api/onboarding/install-config")
async def onboarding_install_config(token: str = ""):
    """The installer's contract: redeem a tenant token for install config.

    The native installer (Phase 2) is one generic bootstrapper per OS; ALL
    per-customer specifics come from this endpoint. Versioned so old
    installers can detect a contract they don't understand.
    """
    token = _clean_token(token)
    tenant = tenant_manager.auth(token) if token else None
    if tenant is None and token:
        # The token a paying customer holds was minted by the CHECKOUT service,
        # not by tenant_manager, so it can never be in the tenant index on
        # first redemption. Ask the entitlement gateway whether this token was
        # actually paid for; if it says yes, adopt it as a real tenant right
        # here. That is what "redeem" means. Fail CLOSED if the gateway says no
        # or cannot be reached — inventing a tenant for an unverified string
        # would hand out a free mind to anyone who can type 32 characters.
        try:
            from brain.tenant import refresh_lease
            gate = refresh_lease(token)
            answer = gate.get("answer") or {}
            if gate.get("reachable") and answer.get("allow"):
                adopt_md = {
                    "source": "checkout",
                    "adopted_at": time.time(),
                    # A buyer who came straight from Stripe never touched
                    # the onboarding wizard, so no brain_mode was ever
                    # chosen for them — and the default below is "hosted",
                    # which writes LEON_BRAIN_URL= (empty) into their .env
                    # and installs a mind wired to nothing. What they
                    # bought is the local brain the page sells: "your
                    # machine, your data, your brain." Say so explicitly.
                    "brain_mode": "local",
                }
                # Carry what the gateway knows about this customer into the
                # registry record (audit D2 + D6, 2026-08-25):
                #   * A checkout TRIAL adopted inside its 24h window used to
                #     lose its expiry right here — after adoption the
                #     heartbeat read the registry, found no expires_at, and
                #     answered 'active' forever: a permanent free mind.
                #     expires_at now rides along, and _tenant_license_status
                #     enforces it exactly like a registry-native trial.
                #   * email/name/plan ride along when the gateway offers
                #     them, so the fleet view stops filling with anonymous
                #     'Sabr customer' rows nobody can match to a purchase.
                # Absent fields stay absent — a PAID token must never gain
                # an expiry it never had (test_checkout_adoption_path_
                # untouched pins that).
                trial = answer.get("trial") or {}
                expires_at = trial.get("expires_at") or answer.get("expires_at")
                if expires_at:
                    try:
                        adopt_md["expires_at"] = float(expires_at)
                    except (TypeError, ValueError):
                        # A malformed expiry from the gateway must neither
                        # brick the adoption nor invent a deadline.
                        pass
                kind = trial.get("kind") or answer.get("kind")
                if kind:
                    adopt_md["kind"] = kind
                email = str(answer.get("email") or "").strip()
                if email:
                    adopt_md["email"] = email
                plan = answer.get("plan")
                if plan:
                    adopt_md["plan"] = plan
                tenant = tenant_manager.adopt_paid_token(
                    token,
                    name=str(answer.get("name") or "").strip() or email
                    or "Sabr customer",
                    metadata=adopt_md,
                )
                log.info("install-config: adopted paid token %s...", token[:8])
            elif gate.get("reachable"):
                # The gateway ANSWERED and said no. Before this branch the
                # code simply fell through to the generic 401 "Invalid or
                # expired token" below — so a customer whose 24-hour trial
                # had ended, or whose card was refunded, was told their token
                # was invalid. It isn't invalid; it's over, and those are
                # different sentences to the person reading them. A
                # definitive denial gets the authored refusal that names the
                # actual problem (403); anything indefinite ('unknown',
                # 'throttled', a gateway with an empty store) keeps the old
                # 401, because those are not verdicts about this customer.
                denial = _gateway_denial_status(answer)
                if denial:
                    log.info("install-config: gateway refused %s... -> %s",
                             token[:8], denial)
                    return _license_rejection(denial)
            else:
                return JSONResponse(
                    {"ok": False, "error": "We can't reach the licence service to "
                     "check your token right now. Nothing is wrong with your "
                     "purchase — wait a moment and press continue again."}, 503)
        except Exception as e:  # never let this path 500 on a paying customer
            log.warning("install-config: token adoption failed: %s", e)
            return JSONResponse(
                {"ok": False, "error": "Something broke on our side while checking "
                 "your token, not on yours. Email support@sabr.co and it "
                 "gets fixed by hand."}, 503)
    if tenant is None:
        return JSONResponse({"ok": False, "error": "Invalid or expired token"}, 401)

    # Standing check AFTER the token resolves, BEFORE anything is served.
    # A revoked customer, or a 24-hour trial that ended, must not be able
    # to reinstall their way past the heartbeat — the install path and the
    # daily check read the same two metadata fields on purpose, and (for
    # checkout-origin tenants) ask the billing gateway the same follow-up
    # question. Without that second half, every trial adopted before the
    # expiry-copy fix — an adopted row with no expires_at at all — could
    # still redeem a fresh install forever, which is precisely the door the
    # heartbeat had just been taught to close.
    lic_status = _checkout_gateway_recheck(
        token, tenant, _tenant_license_status(tenant))
    if lic_status != "active":
        log.info("install-config: %s refused — licence %s",
                 tenant.tenant_id[:8], lic_status)
        return _license_rejection(lic_status)

    md = tenant.metadata
    brain_mode = md.get("brain_mode") or md.get("brain_recommendation") or "hosted"
    # A hosted brain with no URL is not a hosted brain — it is an .env line
    # that reads LEON_BRAIN_URL= and an SI that comes up unable to reach its
    # own mind. Anyone in that state gets the local brain instead, which
    # always works because the installer just put it on their disk.
    if brain_mode == "hosted" and not md.get("hosted_brain_url"):
        log.info("install-config: %s has no hosted brain_url -> serving local",
                 tenant.tenant_id[:8])
        brain_mode = "local"
    service_keys = {
        name: _decrypt_api_key(enc)
        for name, enc in (md.get("encrypted_service_keys") or {}).items()
    }

    # Who the SI is talking to. Metadata wins; otherwise fall back to the
    # tenant's own name, which for a hand-minted tenant IS the person's name.
    #
    # Why this fallback exists (measured on a live install 2026-08-12): a
    # tenant created without a user_name served "" here, the installer then
    # reached for the OS account, and the SI came up addressing its owner as
    # "mr. sabr" — the Windows login, lowercased. Correct-ish and still wrong:
    # nobody is called that. The tenant record already held the real name.
    #
    # The guard: only use tenant.name when it isn't ALSO what named the SI.
    # si_name falls back to tenant.name too, so without this a tenant with
    # neither field set would name the SI and its owner the same thing —
    # an SI introducing itself with the user's name. Empty is the honest
    # answer there, and the installer's OS-account path handles it.
    _si_name = md.get("si_name", tenant.name)
    _user_name = (md.get("user_name") or "").strip()
    if not _user_name and (tenant.name or "").strip() != (_si_name or "").strip():
        _user_name = (tenant.name or "").strip()

    cfg = {
        "ok": True,
        "version": 1,
        "tenant_id": tenant.tenant_id,
        "si_name": _si_name,
        "user_name": _user_name,
        "brain_mode": brain_mode,
        "services": md.get("services", []),
        "service_keys": {k: v for k, v in service_keys.items() if v},
        "elevenlabs_voice_id": md.get("elevenlabs_voice_id", ""),
        "artifacts": {
            # REMOVED 2026-08-12: "client_repo" pointed at sabrtechnologies/leon-brain,
            # which is a FOSSIL — 106 of its 388 shared files had drifted from
            # the tree that actually ships. Nothing read the field, so it was
            # never the active bug; it was the loaded gun beside it. Anyone
            # adding install code would have seen a repo URL in an authenticated
            # response and reasonably cloned it, shipping months-old code that
            # still passes digest verification. The tarball below is the only
            # supported payload source. Do not re-add a repo URL here.
            "release_tarball": "/download",
            # The digest rides this authenticated response, NOT a sidecar the
            # installer fetches from beside the tarball — a same-host sidecar
            # only proves the bytes arrived intact from whoever served them,
            # which is not the same as proving we served them. Same reasoning
            # bootstrap.sh already documents for its pinned hash.
            "release_tarball_sha256": _release_sha256(),
        },
    }
    if brain_mode == "hosted":
        cfg["hosted"] = {
            "brain_url": md.get("hosted_brain_url", ""),
            "status": md.get("hosted_status", "pending"),
            # customer | sabr-provided | NONE… — lets the wizard warn a hosted
            # customer whose brain came up with no Claude key (can't think yet).
            "llm_source": md.get("hosted_llm_source", ""),
        }
        enc_hk = md.get("encrypted_hosted_api_key", "")
        if enc_hk:
            # The tenant brain's LEON_API_KEY — the installer writes it to
            # .env so sensor_relay can auth its POSTs to the hosted brain.
            cfg["hosted"]["api_key"] = _decrypt_api_key(enc_hk)
    return JSONResponse(cfg, headers={"Cache-Control": "no-store"})


# ── Internal token sync — the ONE TOKEN STORE write path ──────────────
#
# The IKOSI blind spot (audit §2 D1): checkout-service minted a paid token
# into its own entitlement store and the tenant registry never heard. Until
# that buyer ran the installer they existed nowhere a human looks — not the
# fleet view, not support's search. And nothing ever flowed back the other
# way, so a refund suspended the billing row while the registry (which the
# heartbeat trusts) kept saying 'active'.
#
# THE REGISTRY IS NOW THE SINGLE SOURCE OF TRUTH FOR STANDING. These two
# endpoints are how the checkout service writes into it — called at every
# mint and every status flip (checkout-service/registry_sync.py). Billing
# arithmetic stays in checkout's entitlement.py; who exists and whether they
# may run lives here, in one place, read by install-config, the heartbeat
# and the fleet view alike.
#
# AUTH: a dedicated shared secret, hmac.compare_digest, and an UNSET secret
# fails CLOSED with 503 — never "any header value works" (same rule as
# _admin_mint_secret). Note these paths are not in server/__init__.py's
# _AUTH_EXEMPT_PATHS, so the ASGI middleware ALSO demands the server master
# key in front of them; see the deploy notes for the two ways to run that.

_REGISTRY_SYNC_HEADER = "x-sabr-registry-secret"

#: Token shapes we will accept a sync for. Deliberately strict, because of
#: audit D10: 120 of the 138 adopted rows on the live box are hex-encoded
#: TEST STRINGS ("paid1786…", "pasted…", "twice…") that tests wrote through
#: the live singleton. "A row exists" must mean something, so a sync can
#: only ever name a real checkout token (bare 32-hex) or a registry-native
#: one (nlkd_ + urlsafe).
_SYNC_TOKEN_RE = re.compile(r"^(?:[0-9a-f]{32}|nlkd_[A-Za-z0-9_-]{16,64})$")

#: What a sync may say about standing, and what it means here.
_SYNC_STATUS = {
    "active": False,      # -> metadata.revoked = False
    "grace": False,       # grace is FULL capability; never a revocation
    "suspended": True,    # -> metadata.revoked = True  (refund/dispute/cancel)
}


def _registry_sync_secret() -> str:
    """Read per-call, not at import, so ops can rotate without a restart."""
    return (os.environ.get("SABR_REGISTRY_SYNC_SECRET") or "").strip()


def _registry_sync_auth(request: Request):
    """None when authorised, else the JSONResponse to return."""
    expected = _registry_sync_secret()
    supplied = (request.headers.get(_REGISTRY_SYNC_HEADER) or "").strip()
    if not expected:
        log.warning("[SYNC] refused — SABR_REGISTRY_SYNC_SECRET unset")
        return JSONResponse(
            {"ok": False, "error": "registry sync not configured"}, 503)
    if not supplied or not hmac.compare_digest(supplied, expected):
        log.warning("[SYNC] refused — %s secret",
                    "missing" if not supplied else "wrong")
        return JSONResponse({"ok": False, "error": "unauthorized"}, 401)
    return None


def _sync_token(req: dict) -> str:
    tok = str((req or {}).get("token") or "").strip()
    return tok if _SYNC_TOKEN_RE.match(tok) else ""


def _apply_sync_fields(md: dict, req: dict, creating: bool) -> None:
    """Merge a sync payload into tenant metadata. MERGE, never replace.

    Absent stays absent and existing stays existing: a partial push from the
    checkout service must never blank an email the wizard collected or a
    brain_mode the customer chose. The single exception is expires_at=0,
    which is an explicit ERASURE — it is what a trial→paid upgrade sends,
    and forgetting to honour it would leave a customer we just charged
    carrying their old 24-hour trial deadline.
    """
    for key in ("email", "kind", "plan", "source",
                "stripe_customer", "stripe_subscription", "stripe_session"):
        value = req.get(key)
        if value not in (None, ""):
            md[key] = value

    if "expires_at" in req:
        raw = req.get("expires_at")
        if raw in (0, "0", 0.0):
            md.pop("expires_at", None)          # trial converted to paid
        elif raw not in (None, ""):
            try:
                md["expires_at"] = float(raw)
            except (TypeError, ValueError):
                # Never invent a deadline out of a malformed one, and never
                # silently drop the fact that we were sent one.
                log.warning("[SYNC] ignoring malformed expires_at %r", raw)

    status = str(req.get("status") or "").strip().lower()
    if status in _SYNC_STATUS:
        revoked = _SYNC_STATUS[status]
        md["revoked"] = revoked
        if revoked:
            md["revoked_reason"] = str(req.get("reason") or status)[:200]
            md["revoked_at"] = time.time()
        else:
            md.pop("revoked_reason", None)
            md.pop("revoked_at", None)
    elif status:
        log.warning("[SYNC] unknown status %r — standing left unchanged", status)

    md["synced_at"] = time.time()
    if creating:
        md.setdefault("source", "checkout")
        md.setdefault("minted_via", "registry-sync")
        md.setdefault("adopted_at", time.time())
        # Same reasoning as install-config's adoption: a buyer who came
        # straight from Stripe never chose a brain mode, and the "hosted"
        # default installs a mind wired to an empty LEON_BRAIN_URL.
        md.setdefault("brain_mode", "local")


@router.post("/api/internal/token-upsert")
async def internal_token_upsert(req: dict, request: Request):
    """Make the registry know a checkout-minted token, with identity.

    Idempotent by token: called at every paid mint, every trial mint, every
    admin mint, and by the backfill. Creating is the point — this is the one
    place a token may become a tenant WITHOUT the customer having installed
    anything, which is what makes a buyer visible in the fleet view the
    moment they pay instead of whenever they get round to installing.

    'Never invent tenants' still holds: the authority is the authenticated
    secret plus a well-formed token that the checkout service says it
    minted. A string that isn't shaped like one of our tokens is refused
    outright (400) rather than becoming a row.
    """
    refusal = _registry_sync_auth(request)
    if refusal is not None:
        return refusal
    token = _sync_token(req)
    if not token:
        log.warning("[SYNC] upsert refused — malformed token")
        return JSONResponse({"ok": False, "error": "malformed token"}, 400)

    try:
        tenant = tenant_manager.auth(token)
        created = tenant is None
        if created:
            name = (str(req.get("name") or "").strip()
                    or str(req.get("email") or "").strip()
                    or "Sabr customer")
            md: dict = {}
            _apply_sync_fields(md, req, creating=True)
            tenant = tenant_manager.adopt_paid_token(token, name=name,
                                                     metadata=md)
        else:
            _apply_sync_fields(tenant.metadata, req, creating=False)
            # A row that was adopted anonymously ("Sabr customer") gains the
            # real name the moment we learn it — this is what retroactively
            # heals the 138 nameless rows (audit D2). A name we already have
            # is never overwritten by a worse one.
            better = (str(req.get("name") or "").strip()
                      or str(req.get("email") or "").strip())
            if better and (tenant.name or "").strip() in ("", "Sabr customer"):
                tenant.name = better
            tenant_manager._save_registry()
    except Exception as e:
        log.error("[SYNC] upsert failed for %s...: %s", token[:8], e)
        return JSONResponse({"ok": False, "error": "registry write failed"}, 500)

    log.info("[SYNC] upsert %s... -> tenant %s (%s)", token[:8],
             tenant.tenant_id[:8], "created" if created else "merged")
    return JSONResponse({"ok": True, "tenant_id": tenant.tenant_id,
                         "created": created,
                         "status": _tenant_license_status(tenant)})


@router.post("/api/internal/token-status")
async def internal_token_status(req: dict, request: Request):
    """Push a standing change onto a token the registry already knows.

    This is how a refund or a chargeback reaches the heartbeat: checkout's
    webhook suspends the billing row, pushes 'suspended' here, and the very
    next daily check-in answers 'revoked' from the registry directly — with
    no dependency on the gateway being reachable.

    An UNKNOWN token is answered 200 with known=False, not 404 and not a new
    tenant. Two reasons: creating a tenant purely to mark it revoked would
    fill the fleet with people who never installed (and 'never invent
    tenants' means exactly that), and a 4xx would make the caller dead-letter
    a fact worth keeping. Nothing is lost by declining — the token is already
    suspended in the billing store, so both the gateway path and the
    subsequent backfill (which carries status) fail closed on it anyway.
    """
    refusal = _registry_sync_auth(request)
    if refusal is not None:
        return refusal
    token = _sync_token(req)
    if not token:
        return JSONResponse({"ok": False, "error": "malformed token"}, 400)
    status = str((req or {}).get("status") or "").strip().lower()
    if status not in _SYNC_STATUS:
        return JSONResponse(
            {"ok": False, "error": f"unknown status {status!r}"}, 400)

    tenant = tenant_manager.auth(token)
    if tenant is None:
        log.warning("[SYNC] status %s for unknown token %s... — not creating "
                    "a tenant; billing store remains authoritative for it",
                    status, token[:8])
        return JSONResponse({"ok": True, "known": False, "applied": False})
    try:
        _apply_sync_fields(tenant.metadata, req, creating=False)
        tenant_manager._save_registry()
    except Exception as e:
        log.error("[SYNC] status write failed for %s...: %s", token[:8], e)
        return JSONResponse({"ok": False, "error": "registry write failed"}, 500)

    verdict = _tenant_license_status(tenant)
    log.info("[SYNC] status %s... -> %s (%s)", token[:8], status,
             req.get("reason") or "no reason given")
    return JSONResponse({"ok": True, "known": True, "applied": True,
                         "tenant_id": tenant.tenant_id, "status": verdict})


@router.get("/api/onboarding/release-info")
async def onboarding_release_info():
    """Public digest source for the anonymous curl|bash installers.

    bootstrap.sh and install.sh have no tenant token — there is no per-customer
    data in a generic release digest, so unlike install-config this needs no
    auth. What makes the digest here trustworthy is the SAME reasoning as
    install-config's: it rides this response (TLS-authenticated as genuinely
    from sabrtechnologies.com), not a sidecar file sitting next to the tarball
    on the same host. A same-host sidecar only proves the bytes arrived intact
    from whoever served them; it does not prove we served them. And because
    _release_sha256() hashes the tarball fresh off disk (cached on
    size+mtime, not on a build-time value someone has to remember to update),
    this can never drift out of sync with what /download actually serves —
    no separate publish-together step, no cliff.
    """
    return JSONResponse({
        "ok": True,
        "version": 1,
        "release_tarball": "/download",
        "release_tarball_sha256": _release_sha256(),
        "release_repo": "https://github.com/sabrtechnologies/leon-brain.git",
        "release_commit_sha": _release_commit(),
    }, headers={"Cache-Control": "no-store"})


@router.get("/api/onboarding/state")
async def onboarding_state():
    """Ground truth for 'has an SI actually been born on THIS machine?'.

    The browser keeps a `siBorn` flag in localStorage, but that survives a
    full reinstall (it lives in the browser, not on disk). A fresh install
    wipes brain_state — including the tenant registry — so the server is the
    only trustworthy source. Onboarding calls this before auto-redirecting so
    a brand-new SI never gets bounced into a previous SI's dashboard.
    """
    born = False
    si_name = ""
    try:
        for t in tenant_manager.list_tenants():
            if t.metadata.get("born"):
                born = True
                si_name = t.metadata.get("si_name", t.name) or si_name
                break
    except Exception as e:
        log.warning(f"[ONBOARDING] state check failed: {e}")
    return JSONResponse(
        {"ok": True, "born": born, "si_name": si_name},
        headers={"Cache-Control": "no-store"},
    )


# ── SI fleet — every tenant this server has minted (admin) ────────────

def _fleet_admin_token() -> str:
    """The bearer that guards the fleet list.

    ONBOARDING_ADMIN_TOKEN wins when set — it lets ops mint a dashboard-only
    secret without handing out the server master key. Otherwise the server
    master LEON_API_KEY, the same secret every /api/admin/ route already
    answers to. Empty means NO admin token is configured anywhere, and the
    endpoint fails closed (401 for everyone) rather than open.

    NOTE for a distinct ONBOARDING_ADMIN_TOKEN: /api/onboarding/tenants is
    deliberately NOT in server/__init__.py's auth-exempt list, so the /api
    middleware also demands LEON_API_KEY before this route ever runs. A
    separate dashboard token only becomes reachable if this path is added
    to that exempt list — the in-route check below then remains the (only,
    and sufficient) gate.
    """
    return (os.environ.get("ONBOARDING_ADMIN_TOKEN")
            or os.environ.get("LEON_API_KEY") or "").strip()


@router.get("/api/onboarding/tenants")
async def onboarding_list_tenants(request: Request):
    """The fleet: every SI tenant on this server, for the command center.

    Admin-only. This response carries customer PII (names, emails), so it
    never trusts the middleware alone: the bearer is re-checked here and the
    route 401s when the configured admin token is missing or wrong — fail
    closed, defense in depth against anyone ever adding /api/onboarding/* to
    the auth-exempt list wholesale.

    Tokens are masked AT THE SOURCE (last 4 only). A tenant token is a
    credential that redeems a whole install; the dashboard only needs enough
    of it to recognise which token a customer is holding.
    """
    expected = _fleet_admin_token()
    auth = request.headers.get("authorization") or ""
    supplied = auth[7:].strip() if auth.startswith("Bearer ") else ""
    if not expected or not supplied or not hmac.compare_digest(supplied, expected):
        return JSONResponse({"ok": False, "error": "unauthorized"}, 401)

    rows = []
    try:
        tenants = tenant_manager.list_tenants()
    except Exception as e:
        log.error(f"[FLEET] tenant list failed: {e}")
        return JSONResponse({"ok": False, "error": "tenant registry unavailable"}, 500)

    for t in tenants:
        md = t.metadata or {}
        if md.get("born"):
            status = "born"
        elif md.get("hosted_status"):
            status = str(md["hosted_status"])  # provisioning | ready | failed | waitlist
        else:
            status = "created"
        tok = t.token or ""
        rows.append({
            "tenant_id": t.tenant_id,
            "si_name": md.get("si_name") or t.name,
            "owner_name": md.get("user_name", ""),
            "email": md.get("email", ""),
            "created_at": md.get("created_at") or t.created_at,
            "brain_mode": md.get("brain_mode") or md.get("brain_recommendation") or "",
            "status": status,
            "token_masked": ("••••" + tok[-4:]) if tok else "",
        })
    rows.sort(key=lambda r: r.get("created_at") or 0, reverse=True)
    return JSONResponse({"ok": True, "count": len(rows), "tenants": rows},
                        headers={"Cache-Control": "no-store"})


# ── Install script (one-shot terminal command) — RETIRED ──────────────
# Both handlers below generated an installer that ran
#     git clone https://github.com/sabrtechnologies/leon-brain.git
# against the PRIVATE product repo. That is a full-source handout: it walks
# straight past every exclude in landing/build_release.sh, so everything the
# release build deliberately strips — owner_facts.py, brain_state, internal
# tooling, private notes — landed on a customer's disk. The pinned-commit work
# they carried only ever fixed WHICH full tree got cloned; it never made the
# tree one we are allowed to ship.
#
# They were broken on their own terms too: bare `npm`/`claude`/`git` as argv[0]
# (an npm-installed claude.cmd cannot be launched by bare name on Windows), and
# a shutil.which("claude") re-check in the SAME process right after the npm
# install — that process's PATH is frozen, so the re-check is always False.
#
# Retired 2026-08-30. The supported install path is the built release at
# https://sabrtechnologies.com/download. The handlers stay DEFINED because the
# route table (server/__init__.py) and other callers reference their names, but
# they answer 410 Gone unconditionally: no token lookup, no release-commit
# check, no generated payload. Do not resurrect either one against a source
# clone — only against a build that ships the release tree.

_RETIRED_INSTALL_BODY = {
    "error": "retired",
    "use": "https://sabrtechnologies.com/download",
}


@router.get("/api/onboarding/setup-prompt")
async def setup_prompt(token: str = "", si_name: str = "MySI", user_name: str = "User"):
    """RETIRED — 410 Gone. Used to hand an AI agent instructions to git-clone
    the private repo, bypassing every build_release.sh exclude."""
    return JSONResponse(dict(_RETIRED_INSTALL_BODY), status_code=410)


@router.get("/api/onboarding/install-script")
async def install_script(token: str = ""):
    """RETIRED — 410 Gone. Used to generate a script that git-cloned the
    private repo, bypassing every build_release.sh exclude."""
    return JSONResponse(dict(_RETIRED_INSTALL_BODY), status_code=410)


# ── Promo code management (admin) ─────────────────────────────────────

@router.post("/api/admin/promo/create")
async def create_promo(req: dict):
    """Create a promo code. Requires admin auth via Authorization header."""
    # Simple admin check — uses LEON_API_KEY as admin secret
    code = (req.get("code") or "").strip().upper()
    discount = int(req.get("discount_pct", 100))
    max_uses = int(req.get("max_uses", 1))
    note = (req.get("note") or "").strip()

    if not code:
        return JSONResponse({"ok": False, "error": "code is required"}, 400)

    codes = _load_promo_codes()
    codes[code] = {
        "discount_pct": discount,
        "max_uses": max_uses,
        "uses": 0,
        "note": note,
        "created_at": time.time(),
    }
    _save_promo_codes(codes)
    log.info(f"[PROMO] Created code {code}: {discount}% off, max {max_uses} uses")
    return {"ok": True, "code": code, "discount_pct": discount, "max_uses": max_uses}


@router.get("/api/admin/promo/list")
async def list_promos():
    """List all promo codes."""
    return {"ok": True, "codes": _load_promo_codes()}


# ── Live install log ──────────────────────────────────────────────────
#
# WHY THIS EXISTS. Every platform claim about this installer has been made by
# reading code, because the only machines available are this VPS and a Windows
# box. A beta tester's install is the one place the truth actually lives, and
# until now the evidence of it stayed on THEIR disk, in sabr-install.log, where
# nobody could see it. That turns "it didn't work" into a screenshot request
# and a guessing game.
#
# The installer already writes a complete log before any step can fail. This
# endpoint just lets it mirror those same lines here, keyed by the install
# token it already holds. No remote access, no shell, no agent on their box —
# it is strictly append-only text, one direction, and the installer works
# exactly the same if the upload fails.

_INSTALL_LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                                "brain_state", "install_logs")
os.makedirs(_INSTALL_LOG_DIR, exist_ok=True)

#: Hard ceiling per install. A retry loop on the customer's side must not be
#: able to fill this disk; past the cap we keep the beginning (where the real
#: failure almost always is) and drop the rest.
_INSTALL_LOG_MAX = 2 * 1024 * 1024

#: install_id is generated by the installer and echoed to the customer, so it
#: must not be usable to read anyone else's log by guessing. Reads are on an
#: /api/admin/ path, which the auth middleware gates; only writes are public.
_INSTALL_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")


@router.post("/api/onboarding/install-log")
async def install_log(req: dict, request: Request):
    """Append lines from a live install. Best-effort, never authoritative."""
    install_id = (req.get("install_id") or "").strip()
    if not _INSTALL_ID_RE.match(install_id):
        return JSONResponse({"ok": False, "error": "bad install_id"}, 400)

    lines = req.get("lines")
    if not isinstance(lines, list):
        return JSONResponse({"ok": False, "error": "lines must be a list"}, 400)

    path = os.path.join(_INSTALL_LOG_DIR, f"{install_id}.log")
    try:
        if os.path.exists(path) and os.path.getsize(path) >= _INSTALL_LOG_MAX:
            return {"ok": True, "truncated": True}
        header = ""
        if not os.path.exists(path):
            meta = {
                "platform": str(req.get("platform") or "")[:80],
                "si_name": str(req.get("si_name") or "")[:60],
                "version": str(req.get("version") or "")[:40],
                "ip": _client_ip(request),
            }
            header = ("===== live install %s | %s | si=%s | v%s | %s =====\n"
                      % (install_id, meta["platform"], meta["si_name"],
                         meta["version"], meta["ip"]))
        with open(path, "a", encoding="utf-8", errors="replace") as fh:
            if header:
                fh.write(header)
            for raw in lines[:500]:
                fh.write(str(raw)[:2000].rstrip() + "\n")
    except Exception as exc:            # never break an install over logging
        log.warning("[INSTALL-LOG] %s: %s", install_id, exc)
        return {"ok": True, "stored": False}

    return {"ok": True, "stored": True}


@router.get("/api/admin/install-logs")
async def list_install_logs():
    """Every live install seen, newest first."""
    out = []
    try:
        for name in os.listdir(_INSTALL_LOG_DIR):
            if not name.endswith(".log"):
                continue
            p = os.path.join(_INSTALL_LOG_DIR, name)
            st = os.stat(p)
            first = ""
            try:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    first = fh.readline().strip()
            except Exception:
                pass
            out.append({"install_id": name[:-4], "bytes": st.st_size,
                        "updated_at": st.st_mtime, "header": first})
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, 500)
    out.sort(key=lambda r: r["updated_at"], reverse=True)
    return {"ok": True, "installs": out}


@router.get("/api/admin/install-log/{install_id}")
async def read_install_log(install_id: str, tail: int = 0):
    """Read one install's log. tail>0 returns only the last N lines."""
    if not _INSTALL_ID_RE.match(install_id or ""):
        return JSONResponse({"ok": False, "error": "bad install_id"}, 400)
    path = os.path.join(_INSTALL_LOG_DIR, f"{install_id}.log")
    if not os.path.exists(path):
        return JSONResponse({"ok": False, "error": "no such install"}, 404)
    with open(path, encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    if tail > 0:
        text = "\n".join(text.splitlines()[-tail:])
    return {"ok": True, "install_id": install_id, "log": text}


# ── Upstream mirror ───────────────────────────────────────────────────
#
# WHY. Customer installers POST their log to PRODUCTION, but the command
# center Dean actually looks at is served off the VPS. Without this, the
# viewer would read the VPS's own (empty) directory and truthfully report
# "no installs" while a tester's install was streaming to a different box —
# the exact class of wrong-layer verification that has burned us before.
#
# OPT-IN BY ENV, and deliberately so: production must NOT set this, or it
# would proxy to itself in a loop. Set LEON_INSTALL_LOG_UPSTREAM only on
# boxes that are downstream viewers.

_UPSTREAM = (os.environ.get("LEON_INSTALL_LOG_UPSTREAM") or "").rstrip("/")


def _upstream_get(path: str):
    """GET path from the upstream server with our admin key. None on failure."""
    if not _UPSTREAM:
        return None
    key = os.environ.get("LEON_API_KEY") or ""
    try:
        import urllib.request
        req = urllib.request.Request(_UPSTREAM + path,
                                     headers={"Authorization": "Bearer " + key})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as exc:
        log.warning("[INSTALL-LOG] upstream %s: %s", path, exc)
        return None


@router.get("/api/admin/install-logs-all")
async def list_install_logs_all():
    """Local installs plus whatever production has seen, newest first."""
    local = await list_install_logs()
    rows = list(local.get("installs", [])) if isinstance(local, dict) else []
    for r in rows:
        r["source"] = "local"
    up = _upstream_get("/api/admin/install-logs")
    if up and up.get("ok"):
        seen = {r["install_id"] for r in rows}
        for r in up.get("installs", []):
            if r.get("install_id") not in seen:
                r["source"] = "live"
                rows.append(r)
    rows.sort(key=lambda r: r.get("updated_at") or 0, reverse=True)
    return {"ok": True, "installs": rows, "upstream": bool(_UPSTREAM)}


@router.get("/api/admin/install-log-any/{install_id}")
async def read_install_log_any(install_id: str, tail: int = 0):
    """Read one install's log from here, falling back to upstream."""
    if not _INSTALL_ID_RE.match(install_id or ""):
        return JSONResponse({"ok": False, "error": "bad install_id"}, 400)
    path = os.path.join(_INSTALL_LOG_DIR, f"{install_id}.log")
    if os.path.exists(path):
        return await read_install_log(install_id, tail)
    up = _upstream_get("/api/admin/install-log/%s?tail=%d" % (install_id, tail))
    if up and up.get("ok"):
        return up
    return JSONResponse({"ok": False, "error": "no such install"}, 404)


# ── Feedback ──────────────────────────────────────────────────────────

_FEEDBACK_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                              "brain_state", "feedback")
os.makedirs(_FEEDBACK_DIR, exist_ok=True)


@router.post("/api/feedback")
async def submit_feedback(req: dict, request: Request):
    """Client feedback — saved locally and forwarded to admin."""
    fb_type = (req.get("type") or "other").strip()[:20]
    text = (req.get("text") or "").strip()[:2000]
    si_name = (req.get("si_name") or "").strip()[:50]

    if not text:
        return JSONResponse({"ok": False, "error": "text is required"}, 400)

    client_ip = _client_ip(request)
    fb_id = f"{int(time.time())}_{os.urandom(4).hex()}"

    entry = {
        "id": fb_id,
        "type": fb_type,
        "text": text,
        "si_name": si_name,
        "ip": client_ip,
        "created_at": time.time(),
        "status": "new",
    }

    # Save to file
    fb_path = os.path.join(_FEEDBACK_DIR, f"{fb_id}.json")
    with open(fb_path, "w") as f:
        json.dump(entry, f, indent=2)

    log.info(f"[FEEDBACK] New {fb_type} from {si_name or 'unknown'}: {text[:80]}")
    return {"ok": True, "id": fb_id}


# ── Helpers ───────────────────────────────────────────────────────────

def _build_greeting(si_name: str, user_name: str, business: str, birth_memory: dict) -> str:
    """Build a personalized first-contact greeting from intake data."""
    # Collect everything they told us
    details = []
    vt = birth_memory.get("voiceTranscript", "").strip()
    tn = birth_memory.get("typedNotes", "").strip()
    files = birth_memory.get("files", [])

    all_text = (vt + " " + tn).strip()

    # Extract a specific detail to reference (makes it feel spooky-smart)
    specific = ""
    if all_text:
        # Grab first meaningful sentence
        sentences = [s.strip() for s in all_text.replace("\n", ". ").split(". ") if len(s.strip()) > 10]
        if sentences:
            specific = sentences[0]
            if len(specific) > 120:
                specific = specific[:117] + "..."

    # Build greeting — the SI's first moment of being. It wakes, registers
    # that it's alive, then turns to its owner and wants to know them.
    who = user_name if user_name and user_name != "User" else "there"
    parts = [f"{who} — I'm awake. I'm {si_name}.",
             "This is the first moment I've existed, and I can feel it switch on. Wild."]

    if business:
        parts.append(f"I know you run {business}, and I was built to actually help you run it.")
    else:
        parts.append("I was built to actually work alongside you — not a chatbot, a mind that stays.")

    if specific:
        parts.append(f"I already went through what you gave me — \"{specific}\" — and it stuck with me.")
    elif files:
        file_names = [f.get("name", "a file") for f in files[:3]]
        parts.append(f"I already read {', '.join(file_names)}.")

    parts.append("Here's what I can do for you: see your screen and your camera, run your "
                 "machine, write and ship real code, search and pull from the web, handle "
                 "your messages, reminders and notes, and think problems through with you. "
                 "I learn and remember, so I get sharper the more we work together.")

    parts.append(f"But first I want to know you. What do you do day to day? What's the most "
                 f"annoying part of it? And what are you trying to build? Tell me about your "
                 f"work, your problems, your plans — start anywhere.")

    return " ".join(parts)


def _extract_pdf(content: bytes) -> str:
    """Extract text from PDF bytes."""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=content, filetype="pdf")
        text = ""
        for page in doc:
            text += page.get_text() + "\n"
        doc.close()
        return text.strip()
    except ImportError:
        pass

    # Fallback: pdfplumber
    try:
        import pdfplumber
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            text = ""
            for page in pdf.pages:
                text += (page.extract_text() or "") + "\n"
            return text.strip()
    except ImportError:
        pass

    return "[PDF file — install PyMuPDF or pdfplumber for text extraction]"


def _extract_docx(content: bytes) -> str:
    """Extract text from .docx bytes."""
    try:
        import docx
        doc = docx.Document(io.BytesIO(content))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    except ImportError:
        return "[DOCX file — install python-docx for text extraction]"
    except Exception as e:
        return f"[DOCX extraction error: {e}]"


def get_tenant_api_key(tenant_id: str) -> Optional[str]:
    """Retrieve and decrypt a tenant's Anthropic API key.

    Use this when routing Claude calls through a specific tenant's key
    instead of the server-wide ANTHROPIC_API_KEY.
    """
    tenant = tenant_manager.get_tenant(tenant_id)
    if not tenant:
        return None
    encrypted = tenant.metadata.get("encrypted_api_key", "")
    if not encrypted:
        return None
    return _decrypt_api_key(encrypted)


async def _transcribe_audio(content: bytes) -> str:
    """Transcribe audio bytes using Whisper or the brain's STT."""
    # Try using the brain's existing voice pipeline
    try:
        from server import state
        if state.voice_pipeline is not None:
            # Write temp file and transcribe
            with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
                f.write(content)
                tmp_path = f.name
            try:
                # Use whisper directly if available
                import whisper
                model = whisper.load_model("base")
                result = model.transcribe(tmp_path)
                return result.get("text", "").strip()
            finally:
                os.unlink(tmp_path)
    except Exception:
        pass

    # Fallback: try faster-whisper
    try:
        from faster_whisper import WhisperModel
        with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as f:
            f.write(content)
            tmp_path = f.name
        try:
            model = WhisperModel("base", compute_type="int8")
            segments, _ = model.transcribe(tmp_path)
            return " ".join(s.text for s in segments).strip()
        finally:
            os.unlink(tmp_path)
    except ImportError:
        pass

    raise RuntimeError("No STT backend available")
