"""/ws/body — outbound-connection gateway for hosted-brain bodies.

A customer machine running run_body.py dials OUT to this endpoint and
holds the socket open; the brain sends tool calls DOWN it and gets
results back. This is the NAT-friendly inverse of Dean's own setup
(reverse SSH tunnel + pc_relay): customers never expose a port.

Wire protocol (JSON text frames):
  brain → body:  {"type": "tool_call", "id": str, "tool": str, "args": {}}
  body → brain:  {"type": "tool_result", "id": str, "result": {...}}

Auth: ?token=<tenant token> (the same token the installer wrote to .env).
One live connection per tenant — a new connection replaces the old one.
"""

import asyncio
import json
import logging
import uuid
from typing import Dict, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from brain.tenant import tenant_manager

log = logging.getLogger("leon.body_gateway")
router = APIRouter()

_TOOL_TIMEOUT = 60.0

# tenant_id → live connection state
_bodies: Dict[str, "BodyConn"] = {}


class BodyConn:
    def __init__(self, tenant_id: str, ws: WebSocket):
        self.tenant_id = tenant_id
        self.ws = ws
        self.pending: Dict[str, asyncio.Future] = {}

    async def call(self, tool: str, args: Optional[dict] = None) -> dict:
        call_id = uuid.uuid4().hex
        fut = asyncio.get_running_loop().create_future()
        self.pending[call_id] = fut
        try:
            await self.ws.send_text(json.dumps(
                {"type": "tool_call", "id": call_id, "tool": tool,
                 "args": args or {}}))
            return await asyncio.wait_for(fut, timeout=_TOOL_TIMEOUT)
        except asyncio.TimeoutError:
            return {"ok": False, "error": f"body did not answer within {_TOOL_TIMEOUT:.0f}s"}
        finally:
            self.pending.pop(call_id, None)


def body_online(tenant_id: str) -> bool:
    return tenant_id in _bodies


async def call_body_tool(tenant_id: str, tool: str, args: Optional[dict] = None) -> dict:
    """Public API for the (Phase 3) multi-tenant brain: run a tool on a
    customer's body. Returns {ok: False, error} if the body is offline."""
    conn = _bodies.get(tenant_id)
    if conn is None:
        return {"ok": False, "error": "body offline"}
    return await conn.call(tool, args)


@router.websocket("/ws/body")
async def ws_body(ws: WebSocket):
    # Prefer the Authorization header — the query string is written to the
    # reverse proxy's access log on every reconnect, and this token is the
    # body's permanent credential. Query param remains only for bodies
    # installed before the header change; remove once none are left.
    auth_header = ws.headers.get("authorization", "")
    if auth_header.lower().startswith("bearer "):
        token = auth_header[7:].strip()
    else:
        token = ws.query_params.get("token", "")
    tenant = tenant_manager.auth(token) if token else None
    if tenant is None:
        await ws.close(code=4401)
        return
    await ws.accept()

    old = _bodies.get(tenant.tenant_id)
    if old is not None:
        try:
            await old.ws.close(code=4000)  # replaced by newer connection
        except Exception:
            pass
    conn = BodyConn(tenant.tenant_id, ws)
    _bodies[tenant.tenant_id] = conn
    log.info(f"[BODY-GW] {tenant.metadata.get('si_name', tenant.name)} body connected")

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except ValueError:
                continue
            if msg.get("type") == "tool_result":
                fut = conn.pending.get(msg.get("id", ""))
                if fut is not None and not fut.done():
                    fut.set_result(msg.get("result") or {})
    except WebSocketDisconnect:
        pass
    except Exception as e:
        log.warning(f"[BODY-GW] connection error for {tenant.tenant_id}: {e}")
    finally:
        if _bodies.get(tenant.tenant_id) is conn:
            del _bodies[tenant.tenant_id]
        log.info(f"[BODY-GW] {tenant.tenant_id} body disconnected")


# ── Admin/debug: run a tool on a connected body (LEON_API_KEY gated by
# the /api/* middleware). This is also how Phase-3 provisioning will
# smoke-test a customer's body right after install.
@router.post("/api/admin/body-tool")
async def admin_body_tool(req: dict):
    tenant_id = (req.get("tenant_id") or "").strip()
    if not tenant_id:
        return {"ok": False, "error": "tenant_id required"}
    return await call_body_tool(tenant_id, req.get("tool", ""), req.get("args") or {})


@router.get("/api/admin/bodies")
async def admin_bodies():
    return {"ok": True, "online": sorted(_bodies.keys())}
