"""
/api/brain/* + /api/state + /api/positions + /api/body — brain
persistence, save/load, backups, lock state, and raw state surfaces.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import logging

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from brain.persistence import (
    save_brain, load_brain, get_save_info,
    list_backups, restore_backup, is_save_locked, get_lock_reason, unlock_save,
)

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Brain persistence
# =============================================================================

@router.post("/api/brain/save")
async def save_state_endpoint():
    try:
        save_brain(state.brain)
        return {"status": "saved", "step": state.brain.step_count}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/api/brain/load")
async def load_state_endpoint():
    from server.init_brain import stop_simulation, start_simulation
    try:
        stop_simulation()
        success = load_brain(state.brain)
        start_simulation()
        return {"status": "loaded" if success else "no_save_found", "step": state.brain.step_count}
    except Exception as e:
        start_simulation()
        return JSONResponse({"error": str(e)}, status_code=500)


@router.get("/api/brain/save-info")
async def save_info():
    info = get_save_info()
    if info:
        return JSONResponse(info)
    return JSONResponse({"saved": False})


@router.get("/api/brain/backups")
async def brain_backups():
    return JSONResponse({
        "backups": list_backups(),
        "save_locked": is_save_locked(),
        "lock_reason": get_lock_reason(),
    })


@router.post("/api/brain/restore-backup")
async def brain_restore_backup(data: dict):
    from server.init_brain import stop_simulation, init_brain, start_simulation
    name = data.get("name", "")
    if not name:
        return JSONResponse({"error": "name field required"}, status_code=400)
    try:
        stop_simulation()
        success = restore_backup(name)
        if success:
            init_brain()
            start_simulation()
            return {"status": "restored", "backup": name, "step": state.brain.step_count}
        else:
            start_simulation()
            return JSONResponse({"error": "Backup not found"}, status_code=404)
    except Exception as e:
        start_simulation()
        return JSONResponse({"error": str(e)}, status_code=500)


@router.post("/api/brain/unlock")
async def brain_unlock(data: dict = None):
    data = data or {}
    if not data.get("confirm", False):
        return JSONResponse({
            "error": "Confirmation required",
            "message": "Pass {'confirm': true} to acknowledge you want to overwrite preserved state.",
            "lock_reason": get_lock_reason(),
        }, status_code=400)
    unlock_save(user_consent=True)
    return {"status": "unlocked", "warning": "Next save will overwrite preserved state"}


@router.get("/api/brain/lock-status")
async def brain_lock_status():
    return JSONResponse({
        "locked": is_save_locked(),
        "reason": get_lock_reason(),
    })


# =============================================================================
# Brain state surface
# =============================================================================

@router.get("/api/state")
async def get_state():
    d = state.brain.get_state()
    # Reasoning-engine health, so "no claude on PATH" is visible here instead
    # of only inside a log file (Aiden's box ran 12h with zero reasoning and
    # nothing in the UI showed it).
    try:
        from brain import engine_health
        if isinstance(d, dict):
            eng = engine_health.snapshot()
            d["engine"] = eng
            d["engine_ok"] = eng.get("ok")
    except Exception:
        pass
    return JSONResponse(d)


@router.get("/api/positions")
async def get_positions():
    positions = state.brain.get_neuron_positions()
    return JSONResponse({"positions": positions})


@router.get("/api/body")
async def get_body():
    """Full body state for 3D viewer — joint angles, vitals, emotions, prompt."""
    body = state.brain.simulated_body
    if body is None:
        return JSONResponse({"error": "no body"}, status_code=404)
    try:
        body_state = body.get_state()
        if hasattr(body, 'joint_positions'):
            body_state["joint_positions"] = body.joint_positions.tolist()
        if hasattr(body, 'data') and body.data is not None:
            body_state["root_pos"] = [float(body.data.qpos[0]),
                                       float(body.data.qpos[1]), 0.0]
            body_state["root_yaw"] = float(body.data.qpos[2])
        if hasattr(body, 'respiratory'):
            body_state["breath_phase"] = float(body.respiratory.phase)
        if hasattr(body, 'cardiac'):
            body_state["heart_phase"] = float(body.cardiac.phase)
        if hasattr(body, 'proprioceptive_drift'):
            body_state["restlessness"] = float(body.proprioceptive_drift.restlessness)
        if hasattr(body, 'social_signal'):
            body_state["social_signal"] = float(body.social_signal)
        body_state["_prompt"] = body.for_prompt()
    except Exception as e:
        body_state = {"error": str(e)}
    return JSONResponse(body_state)
