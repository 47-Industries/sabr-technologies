"""
I/O surfaces: webcam frame push, text/vision/audio input from dashboard,
sensor-relay audio + screen from Dean's PC.

These all share the theme of "external state arriving at the brain".
The sensor_relay routes are the heaviest path — they get pinged
multiple times per second once Dean's PC is connected.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged. NB: /api/input/text + /api/input/audio/* + /api/input/vision/*
are ALSO declared in server/routers/workspaces.py — FastAPI routes the
first-registered hit, so the workspaces.py copies still take priority
for traffic. The misc.py copies were latent. Leaving the duplicates as
they were (pre-existing condition); this extract doesn't change which
one wins.
"""

import logging
import re
import time

from fastapi import APIRouter

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()

# ── Reflex-path salience (relay perception) ──────────────────────────
# A person entering/leaving frame or an alarming screen must surface into
# attention immediately; everything else stays ambient background.
_PERSON_RX = re.compile(
    r"\b(person|man|woman|face|dean|someone|people|guy|figure)\b", re.I)
_ALERT_RX = re.compile(
    r"\b(error|crash|traceback|exception|failed|warning dialog|alert|"
    r"blue screen|frozen)\b", re.I)


def _caption_novelty(prev: str, cur: str) -> float:
    """Word-set turnover between consecutive captions of one source, 0..1."""
    a, b = set(prev.lower().split()), set(cur.lower().split())
    if not a:
        return 0.6 if b else 0.0
    if not b:
        return 0.0
    return 1.0 - len(a & b) / max(1, len(a | b))


# ── presence debounce ────────────────────────────────────────────────────
# "Someone appeared / left" is the single highest-novelty signal we emit
# (0.9 — straight past the reflex threshold, into attention and memory), and
# it was decided by ONE frame of a captioner that is explicitly low-trust.
# When Dean's hair falls forward over his face while he looks at his phone,
# the caption stops saying "person" and Leon concludes he left the room —
# then reasons out loud on top of it. He has corrected this more than once.
#
# So a disagreeing frame is a CANDIDATE, not a fact: presence has to hold
# across consecutive captures before it counts as a transition. Appearing is
# confirmed faster than leaving, deliberately — being slow to notice someone
# walk in is rude, while being slow to declare someone gone is just careful.
_PRESENCE_CONFIRM = {"appeared": 2, "left": 3}
_presence = {"stable": None, "pending": None, "count": 0}


def _presence_transition(now_present: bool) -> bool:
    """True only on a CONFIRMED flip in presence. Pure apart from its own
    module state, so it can be tested without a brain or a camera."""
    st = _presence
    if st["stable"] is None:            # first ever reading: adopt, don't fire
        st["stable"] = now_present
        st["pending"], st["count"] = None, 0
        return False
    if now_present == st["stable"]:     # agrees with what we believe: reset
        st["pending"], st["count"] = None, 0
        return False
    if st["pending"] != now_present:    # first frame of disagreement
        st["pending"], st["count"] = now_present, 1
    else:
        st["count"] += 1
    need = _PRESENCE_CONFIRM["appeared" if now_present else "left"]
    if st["count"] >= need:
        st["stable"] = now_present
        st["pending"], st["count"] = None, 0
        return True
    return False


# =============================================================================
# Webcam frame cache + visual cortex injection
# =============================================================================

@router.post("/api/webcam/frame")
async def webcam_push_frame(data: dict):
    state._webcam_frame_cache = {
        "image_b64": data.get("image_b64", ""),
        "width": data.get("width"),
        "height": data.get("height"),
    }
    state._webcam_frame_ts = time.time()

    # Feed webcam frame directly into visual cortex — Leon's eyes.
    if state.brain is not None:
        try:
            import numpy as np
            b64 = data.get("image_b64", "")
            if b64 and len(b64) > 100:
                h = hash(b64[:200])
                v1 = state.brain.regions.get("visual_cortex")
                if v1 is not None:
                    n = v1.n_neurons
                    features = np.zeros(n, dtype=np.float32)
                    for i in range(n // 8):
                        idx = (h + i * 3571) % n
                        features[idx] = 5.0 + (h % 10)
                    v1.neurons.inject_current(features)
        except Exception:
            pass

    if state.ambient_perception is not None:
        try:
            state.ambient_perception.note_visual_input()
        except Exception:
            pass

    return {"ok": True}


# =============================================================================
# Input API (dashboard side)
# =============================================================================

@router.post("/api/input/text")
async def input_text(data: dict):
    text = data.get("text", "")
    features = []
    if text:
        features = state.text_encoder.encode(text)
        state.brain.inject_sensory_input("text", features)
        if state.claude_bridge:
            state.claude_bridge.send_observation({
                "type": "text",
                "content": text,
                "source": "user",
            })
    return {"status": "ok", "encoded_dim": len(features) if text else 0}


@router.post("/api/input/vision/start")
async def start_vision():
    success = state.vision_encoder.start_webcam()
    return {"status": "started" if success else "unavailable"}


@router.post("/api/input/vision/stop")
async def stop_vision():
    state.vision_encoder.stop_webcam()
    return {"status": "stopped"}


@router.post("/api/input/audio/start")
async def start_audio():
    success = state.audio_encoder.start_microphone()
    return {"status": "started" if success else "unavailable"}


@router.post("/api/input/audio/stop")
async def stop_audio():
    state.audio_encoder.stop_microphone()
    return {"status": "stopped"}


# =============================================================================
# Sensor Relay (PC body → VPS brain)
# =============================================================================

@router.post("/api/relay/audio")
async def relay_audio(data: dict):
    """Receive audio features from the sensor relay on Dean's PC."""
    if state.brain is None:
        return {"ok": False, "error": "no brain"}
    try:
        import numpy as np
        features = np.array(data.get("features", []), dtype=np.float32)
        rms = data.get("rms", 0.0)
        # Live-voice stamp — lets proactive/outbound yield while Dean is
        # mid-sentence (the wake/STT path only reports finished utterances).
        try:
            from brain import audio_daemon
            audio_daemon.note_room_voice(float(rms))
        except Exception:
            pass
        if len(features) > 0 and rms > 0.005:
            state.brain.inject_sensory_input("audio", features)
            # Routed through request_neuromod_delta so the sim thread
            # owns the read-modify-write (audit fix #4).
            if rms > 0.03:
                state.brain.request_neuromod_delta("acetylcholine", 0.03, cap=1.0)
    except Exception:
        pass
    return {"ok": True}


@router.post("/api/relay/screen")
async def relay_screen(data: dict):
    """Receive screen capture from the sensor relay on Dean's PC."""
    if state.brain is None:
        return {"ok": False, "error": "no brain"}
    try:
        import numpy as np
        import base64
        from PIL import Image
        import io

        b64 = data.get("image_b64", "")
        if not b64 or len(b64) < 100:
            return {"ok": False}

        img_bytes = base64.b64decode(b64)
        img = Image.open(io.BytesIO(img_bytes)).convert("L")
        img = img.resize((64, 48))
        pixels = np.array(img, dtype=np.float32) / 255.0
        visual_vec = pixels.flatten()[:256]
        if len(visual_vec) < 256:
            visual_vec = np.pad(visual_vec, (0, 256 - len(visual_vec)))

        state.brain.inject_sensory_input("vision", visual_vec)

        monitor = data.get("monitor", 1)
        from brain import vision_daemon
        with vision_daemon._lock:
            vision_daemon._state["active_monitor"] = monitor
            vision_daemon._state["last_screen_ts"] = time.time()
            vision_daemon._state["screen_captures"] += 1
    except Exception:
        pass
    return {"ok": True}


@router.post("/api/relay/perception")
async def relay_perception(data: dict):
    """Receive caption from PC-side Moondream2 captioner.

    The sensor relay on the PC runs Moondream2 locally (GPU, free),
    captions the screen or webcam, and POSTs the text here. This
    populates vision_daemon._state["last_screen_caption"] or
    ["last_webcam_caption"] so the proactive watch on the VPS can
    compute novelty and satisfy the "speak up for" triggers (Dean
    returning, visible emotion, etc.) without needing a local GPU.
    """
    caption = (data.get("caption") or "").strip()
    if not caption:
        return {"ok": False, "error": "empty caption"}
    source = (data.get("source") or "screen").strip().lower()
    prev_caption = ""
    try:
        from brain import vision_daemon
        with vision_daemon._lock:
            if source == "webcam":
                prev_caption = vision_daemon._state.get("last_webcam_caption") or ""
                vision_daemon._state["last_webcam_caption"] = caption
                vision_daemon._state["last_webcam_ts"] = time.time()
                vision_daemon._state["webcam_captures"] += 1
            else:
                monitor = data.get("monitor", 1)
                prev_caption = vision_daemon._state.get("last_screen_caption") or ""
                vision_daemon._state["last_screen_caption"] = caption
                vision_daemon._state["last_screen_ts"] = time.time()
                vision_daemon._state["active_monitor"] = monitor
                vision_daemon._state["screen_changes"] += 1
    except Exception as e:
        log.warning("relay_perception error: %s", e)
        return {"ok": False, "error": str(e)}

    # Show it in the Activity Log, same as a local-camera install does.
    # WHY (Dean, 2026-08-11): exact sibling of the hearing gap fixed above in
    # relay_transcript. On a machine that runs the brain locally,
    # brain/vision_daemon.py emits broadcast_activity("perception", ...) for
    # every look, so the log shows PERCEPTION lines. That daemon needs a real
    # display and camera, so it is hard-disabled on the VPS (init_brain.py
    # skips it on LEON_DISABLE_VISION_DAEMON / IS_SANDBOX — it otherwise
    # tight-loops on "X connection failed: error 5"). Captions instead arrive
    # here from the PC-side Moondream2 relay, and this path never logged them.
    # Net effect Dean actually saw: his local Windows install showed perception
    # and hearing lines, his VPS-backed Linux one showed neither, and it read
    # as "Windows is a newer build." It was the same build; two relay ingress
    # paths just had no logging. Both do now.
    try:
        from server.helpers import broadcast_activity
        _label = "Saw" if source == "webcam" else "Screen"
        broadcast_activity("perception", f"{_label}: {caption[:60]}", 8000)
    except Exception:
        pass  # logging must never break the actual perception path

    # Event-driven scene refresh — the "What you're seeing" prompt line
    # updates the moment a caption changes instead of minutes later on
    # the proactive poll (Leon's self-reported ~4-min perception lag).
    if state.ambient_perception is not None:
        try:
            state.ambient_perception.refresh_scene()
        except Exception:
            pass
    # Reflex path — salient sights surface into attention NOW instead of
    # waiting for the ~45s proactive poll. Looking must be a reflex, not
    # a tool decision (Dean, 2026-06-12). Salience = someone appears or
    # leaves the webcam, an alert-looking screen, or the scene turning
    # over hard between consecutive captions.
    novelty = _caption_novelty(prev_caption, caption)
    if source == "webcam":
        # Debounced: one frame that disagrees is a candidate, not a departure.
        if _presence_transition(bool(_PERSON_RX.search(caption))):
            novelty = max(novelty, 0.9)  # someone appeared / left, confirmed
    if _ALERT_RX.search(caption):
        novelty = max(novelty, 0.8)
    if novelty >= 0.55 and state.ambient_perception is not None:
        try:
            state.ambient_perception.observe(
                webcam=caption if source == "webcam" else "",
                screen=caption if source != "webcam" else "",
                novelty=novelty,
            )
        except Exception:
            pass
        # Salient sights also become (clearly-branded) memories again —
        # knowledge_store prefixes low-trust sources at the choke point.
        try:
            kb = state.claude_bridge.knowledge if state.claude_bridge else None
            if kb is not None:
                kb.store(
                    text=caption,
                    source="vision_daemon" if source == "webcam" else "screen_observer",
                    metadata={"novelty": round(novelty, 3), "via": "relay_reflex"},
                )
        except Exception:
            pass
    return {"ok": True, "source": source, "caption_len": len(caption),
            "novelty": round(novelty, 3)}


@router.post("/api/relay/heard")
async def relay_heard(data: dict):
    """Receive a transcribed utterance from PC-side ambient wake.

    The sensor relay on Dean's PC runs a Vosk wake listener ("hey leon"),
    captures the follow-up utterance, runs faster-whisper STT locally on
    the PC GPU, and POSTs the resulting text here. We route it through
    the same handler the dashboard mic button uses, so Leon's responder
    streams, TTS plays, and the dashboard shows the conversation.
    """
    # MASTER SWITCH (Dean, 2026-08-07): if the dashboard wake button is off,
    # "hey leon" does not work, period. The PC-side Vosk loop fires regardless
    # of the button (it woke on Leon's OWN TTS saying his name while the
    # button was off) — so the server enforces the rule at the door.
    if not getattr(state, "wake_user_enabled", False):
        log.info("[WAKE-SWITCH] relay/heard dropped — wake button is OFF: %r",
                 (data.get("text") or "")[:80])
        return {"ok": False, "rejected": True, "reason": "wake-button-off"}
    text = (data.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "empty text"}
    if state.brain_api_responder is None:
        return {"ok": False, "error": "responder not ready"}

    # Optional: capture instant of the audio behind this transcript. The
    # relay may send it (epoch seconds); when present the ingress gate
    # applies the capture-timestamp rule instead of the arrival window.
    try:
        captured_ts = float(data["captured_ts"]) if data.get("captured_ts") else None
    except (TypeError, ValueError):
        captured_ts = None

    # Show it in the Activity Log, same as a local-mic install does.
    # WHY (Dean, 2026-08-11): on a machine that runs the brain locally,
    # brain/audio_daemon.py emits broadcast_activity("hearing", ...) and the
    # log shows a HEARING line for every utterance. That daemon needs real
    # mic hardware, so it never runs on the VPS (/dev/snd has no pcm device)
    # — meaning the VPS-backed dashboard silently had no hearing lines at all
    # while a local Windows install did. That read as "Windows is a newer
    # version". It wasn't; this path just never logged. Now it does, so both
    # kinds of install show the same thing.
    try:
        from server.helpers import broadcast_activity
        broadcast_activity("hearing", f'Heard: "{text[:60]}"', 8000)
    except Exception:
        pass  # logging must never break the actual hearing path

    # Run the responder in a background thread — don't block the POST
    # while Leon streams + TTS plays (can take 5-30s).
    try:
        from server.helpers import handle_voice_utterance
        import threading

        def _run():
            try:
                handle_voice_utterance(text, source="wake",
                                       captured_ts=captured_ts)
            except Exception as e:
                log.warning("relay_heard handler error: %s", e)

        threading.Thread(target=_run, daemon=True, name="wake-respond").start()
    except Exception as e:
        log.warning("relay_heard dispatch error: %s", e)
        return {"ok": False, "error": str(e)}
    return {"ok": True, "text_len": len(text)}


@router.post("/api/relay/wake")
async def relay_wake(data: dict):
    """PC wake listener fired ('hey leon' / 'leon') or finished transcribing.
    Broadcast to the dashboard so it shows the pulsing 'listening' tag in real
    time. phase='triggered' on wake-fire, phase='transcribed' once STT is done.
    (The Vosk listener in sensor_relay._wake_loop posts here — that path bypasses
    the wake_orchestrator, so without this the dashboard never lit up.)"""
    from server.helpers import _broadcast_threadsafe
    # MASTER SWITCH: wake button off → no wake UI events either. Keeps the
    # dashboard from flashing 'listening' for a wake the server will drop.
    if not getattr(state, "wake_user_enabled", False):
        return {"ok": False, "rejected": True, "reason": "wake-button-off"}
    phase = data.get("phase", "triggered")
    if phase == "transcribed":
        _broadcast_threadsafe({
            "type": "wake_transcribed",
            "transcript": data.get("transcript", ""),
            "rejected": bool(data.get("rejected", False)),
        })
    else:
        _broadcast_threadsafe({
            "type": "wake_triggered",
            "wake_word": data.get("wake_word", "leon"),
            "score": float(data.get("score", 1.0) or 1.0),
        })
    return {"ok": True}


# ── Push-to-talk floor control ────────────────────────────────────────────
# The wake listener was disabled 2026-06-23 for three reasons. Self-hearing
# was already solved by the TTS marker gate. The one that stayed broken:
# Dean holds Space on the dashboard AND the always-on Vosk listener hears the
# same words, so one utterance becomes two competing inputs and Leon cuts him
# off mid-sentence. Fix: the dashboard claims the mic floor while the key is
# held, and the PC-side wake loop stands down for exactly that window.
# Same shape as the TTS marker — a short-lived claim with a stale timeout,
# so a dropped browser tab can never wedge the listener off permanently.
#
# 2026-08-02: the boolean alone was NOT enough. Vosk endpoints an utterance
# AFTER the speaker stops — i.e. after key-up — so the tail of the sentence
# Dean just spoke into the browser was still being transcribed and POSTed to
# /api/relay/heard as its own brand-new message ("you heard me"). A 0.5s poll
# could also miss a short hold entirely, between samples. So we publish the
# release time too, as an age (clock-skew-proof), and the relay treats any
# utterance overlapping a recent hold as already-heard.
_PTT_STATE = {"until": 0.0, "last_active": 0.0}


@router.post("/api/relay/ptt")
async def relay_ptt(data: dict):
    """Dashboard claims/releases the mic floor. active=true on key-down,
    false on key-up. Holds are capped at 30s so a lost key-up self-heals."""
    import time as _t
    active = bool(data.get("active", False))
    now = _t.time()
    # Rising edge only. The dashboard re-asserts the claim every 10s while
    # the mic is open; re-firing the barge-in on each refresh would keep
    # truncating any interval Leon opened during the hold, and THAT is a
    # self-hearing hole (his audio would stop being gated mid-sentence).
    rising = active and not (now < _PTT_STATE["until"])
    _PTT_STATE["until"] = (now + 30.0) if active else 0.0
    # Stamped on BOTH edges: key-up is the moment that matters most, because
    # the audio Vosk is still holding was spoken just before it.
    _PTT_STATE["last_active"] = now
    # Same claim, second consumer: while Dean holds the floor, NOTHING
    # unsolicited may speak. The wake listener standing down was never the
    # whole problem — proactive/goal/outbound lines were still firing on top
    # of him because their only gate was relayed mic energy, which goes quiet
    # the moment the browser takes the mic.
    try:
        from brain import audio_daemon as _ad
        if active:
            _ad.hold_floor()
        else:
            _ad.release_floor()
        # Barge-in: the dashboard has just stopped Leon's playback. Push-to-
        # talk audio is NOT exempt from the mic gate — instead the speaker
        # interval ENDS here, at stop + SINK_DRAIN_S, so what is still
        # draining out of the speakers stays gated and everything Dean says
        # after it passes the one timestamp rule normally.
        if rising:
            _ad.barge_in(stop_ts=now)
    except Exception:
        pass
    return {"ok": True, "active": active}


@router.get("/api/relay/ptt")
async def relay_ptt_state():
    """Polled ~2x/sec by sensor_relay._wake_loop. Cheap by design: the wake
    listener must never block on the network to decide whether to listen.

    since_active = seconds since the floor was last held or released. Sent as
    an age rather than a timestamp so the PC and VPS clocks never have to
    agree. 1e9 means "never held this boot".
    """
    import time as _t
    now = _t.time()
    la = _PTT_STATE["last_active"]
    # Piggy-back the sentences Leon has just SPOKEN onto this existing poll.
    # The PC-side wake listener uses them for the clock-free half of echo
    # rejection ("did I just say the words I think I heard?"). Text only —
    # the speaker-active INTERVALS reach the relay through the PC-local TTS
    # marker file, whose mtime is on the PC's own clock, so the two machines
    # never have to agree on the time.
    spoken = []
    try:
        from brain.voice import audio_gate as _agate
        spoken = _agate.LEDGER.recent_speech(15.0)[-6:]
    except Exception:
        pass
    return {
        "active": now < _PTT_STATE["until"],
        "since_active": (now - la) if la else 1e9,
        "spoken": spoken,
        # Master wake switch (dashboard button). The relay can use this to
        # stand its Vosk loop down at the source; the server enforces it at
        # /api/relay/heard and /api/relay/wake regardless.
        "wake_enabled": bool(getattr(state, "wake_user_enabled", False)),
    }


_PTT_SOURCE = {"ok": False, "reason": "not reported yet", "devices": "", "at": 0.0}


@router.post("/api/relay/mic-toggle")
async def relay_mic_toggle(data: dict):
    """Dean pressed the remapped wheel-click on his PC.

    His remapper grabs the physical button and injects a synthetic Space to
    whatever holds KEYBOARD focus — so when the dashboard is merely visible,
    the browser sees neither the button nor the key. The relay reads the
    input device directly and calls this instead.

    We broadcast rather than reply: the dashboard already holds a live
    websocket whether or not its window is focused, and a socket event needs
    no focus. That is the entire reason this route exists.
    """
    import time as _t
    from server.helpers import _broadcast_threadsafe
    payload = {"type": "mic_toggle", "source": (data or {}).get("source", "wheel"),
               "at": _t.time()}
    # NOT queued if nobody is listening. A toggle that fires minutes later,
    # when a tab happens to reopen, is an unannounced hot mic — the one
    # failure mode here that is worse than the button not working.
    listeners = len(getattr(state, "connected_clients", ()) or ())
    if listeners:
        _broadcast_threadsafe(payload)
    else:
        log.info("[PTT] wheel toggle dropped — no dashboard socket connected")
    return {"ok": True, "delivered_to": listeners}


@router.post("/api/relay/ptt-source")
async def relay_ptt_source(data: dict):
    """The relay reports, once at startup, whether it can see the device.

    Dean never opens a terminal, so a silent failure here is invisible to
    him: the button just does nothing, exactly as before. This makes the
    reason retrievable without one.
    """
    import time as _t
    _PTT_SOURCE.update({
        "ok": bool((data or {}).get("ok")),
        "reason": (data or {}).get("reason", ""),
        "devices": (data or {}).get("devices", ""),
        "at": _t.time(),
    })
    log.info("[PTT] source: %s", _PTT_SOURCE)
    return {"ok": True}


@router.get("/api/relay/ptt-source")
async def relay_ptt_source_state():
    return dict(_PTT_SOURCE)


@router.get("/api/webcam/last-frame")
async def webcam_last_frame():
    """Return the most recent webcam frame cached by the dashboard.

    The dashboard browser (right monitor, Brave) holds /dev/video0 and
    pushes frames to /api/webcam/frame. The PC-side captioner cannot
    open the camera directly (browser holds it exclusively), so it
    pulls from this cache instead.
    """
    cache = state._webcam_frame_cache or {}
    if not cache.get("image_b64"):
        return {"ok": False, "error": "no webcam frame cached"}
    age_s = time.time() - (state._webcam_frame_ts or 0)
    if age_s > 15.0:
        return {"ok": False, "error": "stale frame", "age_s": round(age_s, 1)}
    return {
        "ok": True,
        "image_b64": cache.get("image_b64", ""),
        "width": cache.get("width"),
        "height": cache.get("height"),
        "age_s": round(age_s, 2),
    }
