"""
Miscellaneous routes: claude, brain, agent, control, tenants, screen,
video, voice, events, security, benchmarks, sleep, plugins, wake,
reminders, routines, proactive, presence, webcam, projects.
"""

import asyncio
import json
import logging
import os
import re
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Header, Query, Request
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse

from brain.persistence import (
    save_brain, load_brain, get_save_info,
    list_backups, restore_backup, is_save_locked, get_lock_reason, unlock_save,
)
from brain.tools import describe_tools, call_tool, tool_history, tool_stats
from brain.tenant import tenant_manager
from brain.security import audit_log, rate_limiter
from brain import benchmarks as bench_mod
from brain.events import event_bus, webhook_manager
from brain.plugins import list_plugins

from server import state
from server.helpers import (
    _broadcast_threadsafe, _tts_synthesize_b64,
    _ensure_voice_pipeline, _ensure_wake_orchestrator,
)

log = logging.getLogger("leon.server")
router = APIRouter()

# Install root — this file is <root>/server/routers/misc.py.
_INSTALL_ROOT = Path(__file__).resolve().parents[2]


def _read_install_marker(name: str) -> str:
    """Read a small marker file from the install root, or "" if unavailable.

    Never raises. A version probe that crashes is worse than one that says
    "unknown", because support scripts and the updater branch on it.
    """
    try:
        p = _INSTALL_ROOT / name
        if not p.exists():
            return ""
        return p.read_text(encoding="utf-8", errors="replace").strip()
    except Exception:
        return ""


def _parse_markers() -> Dict[str, Any]:
    """Parse VERSION + .sabr-release into a flat dict of known fields."""
    out: Dict[str, Any] = {
        "version": "unknown", "commit": "", "built_at": "",
        "release_sha256": "", "installed_at": "",
    }
    raw = _read_install_marker("VERSION")
    if raw:
        out["version"] = raw
        # "Sabr SI commit:  <sha> date:    <iso>"
        m = re.search(r"commit:\s*(\S+)", raw)
        if m:
            out["commit"] = m.group(1)
        m = re.search(r"date:\s*(\S+)", raw)
        if m:
            out["built_at"] = m.group(1)
    for line in _read_install_marker(".sabr-release").splitlines():
        if "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        if k in ("release_sha256", "installed_at"):
            out[k] = v.strip()
    return out


# =============================================================================
# Version / liveness (public, read-only)
# =============================================================================
#
# WHY THESE ARE UNAUTHENTICATED:
#
# Mission win-condition #4 is "every install can say what version it is."
# A CLI `--version` already existed, but nothing served it over HTTP — and
# because the auth middleware gates unknown paths before FastAPI can 404,
# GET /api/version answered 401 on a healthy install. Measured on a live
# Windows install 2026-08-12: the SI was fully up, dashboard serving, and
# the version probe still came back "unauthorized". That reads to a customer
# (and to our own updater and support scripts) as a broken or unlicensed
# install rather than a missing route.
#
# These two return build markers and liveness only — no brain state, no
# identity, no user name, no tenant token, nothing about who owns the box.
# That is the entire reason they are safe to expose without a key.

@router.get("/api/version")
async def api_version():
    info = _parse_markers()
    info["ok"] = True
    return info


@router.get("/healthz")
async def healthz():
    return {"ok": True, "status": "alive"}


@router.get("/api/brain-check")
async def brain_check():
    """Can this SI actually produce a reply? Answering the port is not enough.

    Written after Aiden's install (2026-08-12): the installer polled the HTTP
    port, got a 200, and printed "Iris is ready." The port was up. The brain
    behind it was not — no Anthropic key, no `claude` binary, and the local
    model pinned in a mode forbidden from answering. Every message he typed
    died. "It listens on 8000" and "it can talk" are different claims, and the
    installer was only ever checking the first one.

    Cheap and side-effect free on purpose: this reports which brain would take
    a turn, not the result of taking one.
    """
    cloud_key = bool((os.environ.get("ANTHROPIC_API_KEY") or "").strip())
    # Binary presence via the SAME resolver the runtime spawns with — which()
    # alone said "OK" for an npm claude.cmd CreateProcess can't launch and for
    # a CLI that was never signed in (Aiden, twice).
    try:
        from brain import engine_health as _eh
        _exe = _eh.resolve(refresh=True)
        cli = _exe != "claude"
        _engine = _eh.snapshot()
    except Exception:
        import shutil as _sh
        cli = _sh.which("claude") is not None
        _engine = None
    # The honest probe (does `claude -p ping` answer?) — computed at boot by
    # the preflight and refreshed on failures. Presence is not ability.
    _reason = None
    try:
        from server import state as _st
        _rs = getattr(_st, "reasoning_status", None)
        if isinstance(_rs, dict) and not _rs.get("ok", True):
            _reason = _rs.get("reason") or "engine_failed"
    except Exception:
        pass
    if _engine and _engine.get("ok") is False:
        _reason = _reason or ("cli_" + (_engine.get("last_error_kind") or "failed"))
    local_mode, local_up, sole = "unknown", False, False
    try:
        from brain import local_llm as _l
        local_mode = _l.LOCAL_LLM_MODE
        sole = bool(getattr(_l, "LOCAL_LLM_SOLE_BRAIN", False))
        if local_mode != "off":
            local_up = bool(_l.is_available())
    except Exception as exc:
        local_mode = f"error: {exc}"

    if cli and _reason and not cloud_key:
        # Binary is there but it cannot answer (not signed in, not launchable,
        # timing out). Report it as NOT ready — the installer's last gate
        # trusts this flag and would otherwise print "<name> is ready."
        brain, ok = f"cli-{_reason}", False
    elif cloud_key or cli:
        brain, ok = ("cloud" if cloud_key else "cli"), True
    elif local_up and local_mode in ("chat", "only"):
        brain, ok = "local", True
    elif local_up:
        # The exact Aiden case: a model that is loaded and reachable but gated
        # off from conversation, with nothing to escalate to.
        brain, ok = "local-but-gated", False
    else:
        brain, ok = "none", False

    return {"ok": ok, "brain": brain, "cloud_key": cloud_key,
            "claude_cli": cli, "local_mode": local_mode,
            "local_available": local_up, "sole_brain": sole,
            "engine": _engine, "engine_reason": _reason}


# =============================================================================
# Auth Handshake (token bootstrap for dashboard)
# =============================================================================

@router.get("/auth")
async def auth_handshake(request: Request):
    """Token handshake endpoint for localhost development.
    Returns an HTML page that stores the API key in sessionStorage.
    """
    from fastapi.responses import HTMLResponse

    api_key = os.environ.get("LEON_API_KEY", "").strip()

    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Sabr Auth</title>
</head>
<body style="background:#000;color:#0f0;font-family:monospace;padding:20px;">
    <p>Authenticating...</p>
    <script>
        (function() {{
            var apiKey = "{api_key}";
            if (apiKey) {{
                sessionStorage.setItem("leon_key", apiKey);
                localStorage.setItem("leon_key", apiKey);
                console.log("API key stored");
            }}
            setTimeout(function() {{
                window.location.replace("/");
            }}, 100);
        }})();
    </script>
</body>
</html>"""
    return HTMLResponse(content=html)


@router.get("/api/get-auth-key")
async def get_auth_key(request: Request):
    """Get API key for localhost/development (no auth required).
    This endpoint is NOT exempt from auth in the middleware, so it will
    always return 401 unless we add it to the exempt list. But we can
    provide a fallback in the dashboard JS.
    """
    # This will only work if the request passes auth, which it won't without
    # the key. So this endpoint isn't actually useful. Use /auth instead.
    api_key = os.environ.get("LEON_API_KEY", "").strip()
    return {"key": api_key}


# =============================================================================
# Activity Log
# =============================================================================

@router.get("/api/activity")
async def get_activity(limit: int = Query(500, ge=1, le=2000)):
    from server.helpers import get_activity_history
    return get_activity_history(limit)


@router.get("/api/growth/stats")
async def growth_stats():
    """Leon's autonomous growth statistics."""
    result = {}
    try:
        from brain.tool_explorer import get_exploration_stats
        result["exploration"] = get_exploration_stats()
    except Exception:
        result["exploration"] = {}
    try:
        from brain.failure_memory import get_summary
        result["failures"] = get_summary()
    except Exception:
        result["failures"] = {}
    try:
        from brain.credential_audit import audit
        report = audit()
        result["credentials"] = {
            "configured": report.get("configured_count", 0),
            "missing": report.get("missing_count", 0),
            "missing_high_value": report.get("missing_high_value", []),
        }
    except Exception:
        result["credentials"] = {}
    try:
        from brain.persistent_goals import get_all
        result["goals"] = get_all()
    except Exception:
        result["goals"] = {}
    try:
        from brain.skill_practice import get_skill_health
        result["skill_health"] = get_skill_health()
    except Exception:
        result["skill_health"] = {}
    return result


# =============================================================================
# Control API
# =============================================================================

@router.post("/api/control/pause")
async def pause():
    from server.init_brain import stop_simulation
    stop_simulation()
    return {"status": "paused"}


@router.post("/api/control/resume")
async def resume():
    from server.init_brain import start_simulation
    start_simulation()
    return {"status": "running"}


@router.post("/api/control/reset")
async def reset():
    from server.init_brain import stop_simulation, init_brain, start_simulation
    stop_simulation()
    init_brain()
    start_simulation()
    return {"status": "reset"}


# Claude routes moved to server/routers/claude_routes.py (2026-06-08).


# Screen + video routes moved to server/routers/media_routes.py (2026-06-08).


# =============================================================================
# Persistence API
# =============================================================================

# Brain persistence + /api/state + /api/positions + /api/body moved to
# server/routers/brain_routes.py (2026-06-08).


# Agent / leon / local_llm tool routes moved to server/routers/agent_routes.py (2026-06-08).


# =============================================================================
# Multi-Tenant Brain Management
# =============================================================================

# Tenants/channels/audit/security routes moved to
# server/routers/tenants_routes.py (2026-06-08).


# =============================================================================
# Benchmarks
# =============================================================================

@router.get("/api/benchmarks")
async def benchmarks_latest():
    latest = bench_mod.load_results()
    if latest is None:
        return {"ok": False, "error": "No benchmark results yet. POST /api/benchmarks/run to generate."}
    return {"ok": True, "results": latest}


@router.post("/api/benchmarks/run")
async def benchmarks_run():
    r = bench_mod.run_all()
    path = bench_mod.save_results(r)
    return {
        "ok": True, "saved_to": path,
        "results": r.to_dict(),
        "markdown": bench_mod.render_markdown(r),
    }


@router.get("/api/benchmarks/markdown")
async def benchmarks_markdown():
    latest = bench_mod.load_results()
    if latest is None:
        return JSONResponse({"ok": False, "error": "No results yet"})
    r = bench_mod.BenchmarkResults(**{
        k: latest.get(k, {}) for k in
        ["memory_recall", "query_latency", "action_success",
         "discrimination", "hardware"]
    })
    r.ran_at = latest.get("ran_at", 0)
    r.duration_sec = latest.get("duration_sec", 0)
    return {"markdown": bench_mod.render_markdown(r)}


# Sleep/dream/autobiography/goals/inner_voice/self_tuning/stakes/ambient/opinions
# moved to server/routers/cognition_loops_routes.py (2026-06-08).


# Webhooks/events/plugins moved to server/routers/events_routes.py.
# Projects/wake/ablation/reminders/routines/presence/proactive/abort
# moved to server/routers/autonomy_routes.py.
# Webcam/input/relay moved to server/routers/io_routes.py.
# All 2026-06-08.
