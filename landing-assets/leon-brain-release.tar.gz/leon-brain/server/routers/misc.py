"""
Miscellaneous routes: claude, brain, agent, control, tenants, screen,
video, voice, events, security, benchmarks, sleep, plugins, wake,
reminders, routines, proactive, presence, webcam, projects.
"""

import asyncio
import json
import logging
import os
import threading
import time
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Header, Query, Request
from fastapi.responses import JSONResponse, FileResponse, StreamingResponse

from brain.persistence import (
    save_brain, load_brain, get_save_info,
    list_backups, restore_backup, is_save_locked, get_lock_reason, unlock_save,
)
from brain.tools import describe_tools, call_tool, tool_history, tool_stats
from brain.tenant import tenant_manager
from brain.security import audit_log, rate_limiter
from brain import benchmarks as bench_mod
from brain.events import event_bus, webhook_manager
from brain.plugins import list_plugins

from server import state
from server.helpers import (
    _broadcast_threadsafe, _tts_synthesize_b64,
    _ensure_voice_pipeline, _ensure_wake_orchestrator,
)

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Auth Handshake (token bootstrap for dashboard)
# =============================================================================

@router.get("/auth")
async def auth_handshake(request: Request):
    """Token handshake endpoint for localhost development.
    Returns an HTML page that stores the API key in sessionStorage.
    """
    from fastapi.responses import HTMLResponse

    api_key = os.environ.get("LEON_API_KEY", "").strip()

    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Sabr Auth</title>
</head>
<body style="background:#000;color:#0f0;font-family:monospace;padding:20px;">
    <p>Authenticating...</p>
    <script>
        (function() {{
            var apiKey = "{api_key}";
            if (apiKey) {{
                sessionStorage.setItem("leon_key", apiKey);
                localStorage.setItem("leon_key", apiKey);
                console.log("API key stored");
            }}
            setTimeout(function() {{
                window.location.replace("/");
            }}, 100);
        }})();
    </script>
</body>
</html>"""
    return HTMLResponse(content=html)


@router.get("/api/get-auth-key")
async def get_auth_key(request: Request):
    """Get API key for localhost/development (no auth required).
    This endpoint is NOT exempt from auth in the middleware, so it will
    always return 401 unless we add it to the exempt list. But we can
    provide a fallback in the dashboard JS.
    """
    # This will only work if the request passes auth, which it won't without
    # the key. So this endpoint isn't actually useful. Use /auth instead.
    api_key = os.environ.get("LEON_API_KEY", "").strip()
    return {"key": api_key}


# =============================================================================
# Activity Log
# =============================================================================

@router.get("/api/activity")
async def get_activity(limit: int = Query(500, ge=1, le=2000)):
    from server.helpers import get_activity_history
    return get_activity_history(limit)


@router.get("/api/growth/stats")
async def growth_stats():
    """Leon's autonomous growth statistics."""
    result = {}
    try:
        from brain.tool_explorer import get_exploration_stats
        result["exploration"] = get_exploration_stats()
    except Exception:
        result["exploration"] = {}
    try:
        from brain.failure_memory import get_summary
        result["failures"] = get_summary()
    except Exception:
        result["failures"] = {}
    try:
        from brain.credential_audit import audit
        report = audit()
        result["credentials"] = {
            "configured": report.get("configured_count", 0),
            "missing": report.get("missing_count", 0),
            "missing_high_value": report.get("missing_high_value", []),
        }
    except Exception:
        result["credentials"] = {}
    try:
        from brain.persistent_goals import get_all
        result["goals"] = get_all()
    except Exception:
        result["goals"] = {}
    try:
        from brain.skill_practice import get_skill_health
        result["skill_health"] = get_skill_health()
    except Exception:
        result["skill_health"] = {}
    return result


# =============================================================================
# Control API
# =============================================================================

@router.post("/api/control/pause")
async def pause():
    from server.init_brain import stop_simulation
    stop_simulation()
    return {"status": "paused"}


@router.post("/api/control/resume")
async def resume():
    from server.init_brain import start_simulation
    start_simulation()
    return {"status": "running"}


@router.post("/api/control/reset")
async def reset():
    from server.init_brain import stop_simulation, init_brain, start_simulation
    stop_simulation()
    init_brain()
    start_simulation()
    return {"status": "reset"}


# Claude routes moved to server/routers/claude_routes.py (2026-06-08).


# Screen + video routes moved to server/routers/media_routes.py (2026-06-08).


# =============================================================================
# Persistence API
# =============================================================================

# Brain persistence + /api/state + /api/positions + /api/body moved to
# server/routers/brain_routes.py (2026-06-08).


# Agent / leon / local_llm tool routes moved to server/routers/agent_routes.py (2026-06-08).


# =============================================================================
# Multi-Tenant Brain Management
# =============================================================================

# Tenants/channels/audit/security routes moved to
# server/routers/tenants_routes.py (2026-06-08).


# =============================================================================
# Benchmarks
# =============================================================================

@router.get("/api/benchmarks")
async def benchmarks_latest():
    latest = bench_mod.load_results()
    if latest is None:
        return {"ok": False, "error": "No benchmark results yet. POST /api/benchmarks/run to generate."}
    return {"ok": True, "results": latest}


@router.post("/api/benchmarks/run")
async def benchmarks_run():
    r = bench_mod.run_all()
    path = bench_mod.save_results(r)
    return {
        "ok": True, "saved_to": path,
        "results": r.to_dict(),
        "markdown": bench_mod.render_markdown(r),
    }


@router.get("/api/benchmarks/markdown")
async def benchmarks_markdown():
    latest = bench_mod.load_results()
    if latest is None:
        return JSONResponse({"ok": False, "error": "No results yet"})
    r = bench_mod.BenchmarkResults(**{
        k: latest.get(k, {}) for k in
        ["memory_recall", "query_latency", "action_success",
         "discrimination", "hardware"]
    })
    r.ran_at = latest.get("ran_at", 0)
    r.duration_sec = latest.get("duration_sec", 0)
    return {"markdown": bench_mod.render_markdown(r)}


# Sleep/dream/autobiography/goals/inner_voice/self_tuning/stakes/ambient/opinions
# moved to server/routers/cognition_loops_routes.py (2026-06-08).


# Webhooks/events/plugins moved to server/routers/events_routes.py.
# Projects/wake/ablation/reminders/routines/presence/proactive/abort
# moved to server/routers/autonomy_routes.py.
# Webcam/input/relay moved to server/routers/io_routes.py.
# All 2026-06-08.
