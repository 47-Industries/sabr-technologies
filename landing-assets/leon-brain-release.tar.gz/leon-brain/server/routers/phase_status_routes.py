"""
/api/cognition/phase{13,14,15}/status + /phase14 + /phase15 page routes.

The three "phase rollup" endpoints summarize what's installed and live
across Leon's cognition subsystems for a given milestone. They're
read-only diagnostic surfaces — handy for the phase dashboards but
don't drive any state.

The /phase13 HTML page route lives in server/__init__.py (was added
before cognition.py existed). /phase14 + /phase15 came later and ended
up in cognition.py; moving them here too keeps the three phases
grouped.

Extracted from cognition.py 2026-06-08 per architecture review. Behavior
unchanged. Imports + the _require_cognition guard match what cognition.py
uses today.
"""

import logging
import os

from fastapi import APIRouter
from fastapi.responses import JSONResponse, FileResponse

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


def _require_cognition():
    if state.cognition is None:
        return JSONResponse(
            {"ok": False, "error": "cognition layer not installed (LEON_COGNITION=off?)"},
            status_code=503,
        )
    return None


# =============================================================================
# Phase 15 — proposals + providers + soak + tool compression
# =============================================================================

@router.get("/api/cognition/phase15/status")
async def cognition_phase15_status():
    """Phase 15 rollup — proposals, providers, soak, tool compression."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    out = {"ok": True}
    # Proposals
    r = getattr(cognition, "reflection", None)
    if r is not None and hasattr(r, "proposal_stats"):
        try:
            out["proposals"] = {
                "stats": r.proposal_stats(),
                "open_count": len(r.proposals(status="open", limit=200)),
            }
        except Exception as e:
            out["proposals"] = {"error": str(e)[:120]}
    # Providers
    pr = getattr(cognition, "providers", None)
    if pr is not None:
        try:
            out["providers"] = {
                "fallback_enabled": pr.fallback_enabled(),
                "states": pr.all(),
            }
        except Exception as e:
            out["providers"] = {"error": str(e)[:120]}
    # Tool compression
    tc = getattr(cognition, "tool_classifier", None)
    if tc is not None and hasattr(tc, "hidden_count"):
        try:
            out["tool_compression"] = tc.hidden_count()
        except Exception as e:
            out["tool_compression"] = {"error": str(e)[:120]}
    # Soak summary (last 7d)
    if r is not None and hasattr(r, "soak_summary"):
        try:
            out["soak_7d"] = r.soak_summary(days=7)
        except Exception as e:
            out["soak_7d"] = {"error": str(e)[:120]}
    # Self-repair simulate gating wired?
    sr = getattr(cognition, "self_repair", None)
    if sr is not None:
        out["self_repair_simulate_gating"] = bool(getattr(sr, "executive", None))
    return JSONResponse(out)


@router.get("/phase15")
async def phase15_panel():
    """Phase 15 — proposal queue + soak metrics + provider state."""
    # Was a bare FileResponse — shipped the hardcoded title/H1
    # "Leon — Phase 15 Adaptation Loop" untouched. Route through
    # server._branded_page() like every other panel. Deferred import avoids
    # a circular import at module load time (server/__init__.py imports
    # this router).
    from server import _branded_page
    return _branded_page("phase15.html")


# =============================================================================
# Phase 14 — executive authority + tool classifier + reflection + skills
# =============================================================================

@router.get("/api/cognition/phase14/status")
async def cognition_phase14_status():
    """Phase 14 rollup — executive authority, procedural, classifier, reflection."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    out = {"ok": True}
    # Tool classifier
    tc = getattr(cognition, "tool_classifier", None)
    if tc is not None:
        try:
            snap = tc.classify_all()
            out["tool_classifier"] = {
                "installed": True,
                "summary": snap.get("summary"),
                "total_tools_known": snap.get("total_tools_known"),
                "preferred_top5": snap.get("preferred", [])[:5],
            }
        except Exception as e:
            out["tool_classifier"] = {"installed": True, "error": str(e)[:120]}
    else:
        out["tool_classifier"] = {"installed": False}
    # Executive
    exe = getattr(cognition, "executive", None)
    if exe is not None:
        out["executive"] = {
            "installed": True,
            "counters": exe.counters() if hasattr(exe, "counters") else {},
            "authoritative_flag": os.environ.get("LEON_EXECUTIVE_AUTHORITATIVE", "off"),
        }
    else:
        out["executive"] = {"installed": False}
    # Reflection
    r = getattr(cognition, "reflection", None)
    if r is not None:
        try:
            out["reflection"] = {
                "installed": True,
                "running": r.is_running(),
                "stats": r.stats(),
            }
        except Exception as e:
            out["reflection"] = {"installed": True, "error": str(e)[:120]}
    else:
        out["reflection"] = {"installed": False}
    # Skills state machine
    sk = getattr(cognition, "skills", None)
    if sk is not None and hasattr(sk, "state_summary"):
        try:
            out["skills"] = {
                "installed": True,
                "stats": sk.stats(),
                "by_state": sk.state_summary(),
            }
        except Exception as e:
            out["skills"] = {"installed": True, "error": str(e)[:120]}
    # Awareness session
    aw = getattr(cognition, "awareness", None)
    if aw is not None and hasattr(aw, "session"):
        try:
            out["awareness_session"] = aw.session()
        except Exception as e:
            out["awareness_session"] = {"error": str(e)[:120]}
    return JSONResponse(out)


@router.get("/phase14")
async def phase14_panel():
    """Phase 14 dashboard — executive routing + tool classification + reflection."""
    # Was a bare FileResponse — shipped the hardcoded title/H1
    # "Leon — Phase 14 Executive + Procedural" untouched. Route through
    # server._branded_page() like every other panel. Deferred import avoids
    # a circular import at module load time (server/__init__.py imports
    # this router).
    from server import _branded_page
    return _branded_page("phase14.html")


# =============================================================================
# Phase 13 — broad subsystem rollup (executive/reflex/awareness/tool_health/
# watchdog/probes/self_repair/lessons/skills/suggestions)
# =============================================================================

@router.get("/api/cognition/phase13/status")
async def cognition_phase13_status():
    """One-shot summary of every Phase 13 subsystem."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    out = {"ok": True}
    for name in ("executive", "reflex", "awareness", "tool_health",
                 "watchdog", "probes", "self_repair", "lessons",
                 "skills", "suggestions"):
        h = getattr(cognition, name, None)
        if h is None:
            out[name] = {"installed": False}
            continue
        info = {"installed": True}
        if hasattr(h, "is_running"):
            try:
                info["running"] = bool(h.is_running())
            except Exception:
                pass
        if name == "tool_health":
            try:
                info["summary"] = h.summary()
            except Exception:
                pass
        if name == "self_repair":
            try:
                info["stats"] = h.stats()
            except Exception:
                pass
        if name == "lessons":
            try:
                info["stats"] = h.stats()
            except Exception:
                pass
        if name == "skills":
            try:
                info["stats"] = h.stats()
            except Exception:
                pass
        if name == "watchdog":
            try:
                rep = h.report() or {}
                info["overall"] = rep.get("overall")
            except Exception:
                pass
        if name == "awareness":
            try:
                snap = h.snapshot_dict() or {}
                info["active_app"] = snap.get("active_app")
                info["is_idle"] = snap.get("is_idle")
            except Exception:
                pass
        if name == "executive":
            try:
                info["last"] = h.last()
            except Exception:
                pass
        out[name] = info
    return JSONResponse(out)
