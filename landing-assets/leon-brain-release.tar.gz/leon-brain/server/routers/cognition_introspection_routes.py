"""
/api/cognition/{awareness,watchdog,probes,self_repair,lessons,reflection}/*
— the "Leon watching itself" surface. Awareness tracks active app +
idle state; watchdog reports on subsystem health; probes are scheduled
checks; self_repair is the patch history; lessons are persistent
preference rules; reflection is the workflow-detection + insight stream.

Extracted from cognition.py 2026-06-08 per architecture review.
Behavior unchanged. _require_cognition + _phase13_missing helpers
duplicated locally to avoid circular imports.
"""

import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


def _require_cognition():
    if state.cognition is None:
        return JSONResponse(
            {"ok": False, "error": "cognition layer not installed (LEON_COGNITION=off?)"},
            status_code=503,
        )
    return None


def _phase13_missing(attr: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    if getattr(state.cognition, attr, None) is None:
        return JSONResponse({"ok": False, "error": f"{attr} not installed"}, status_code=503)
    return None


# =============================================================================
# Awareness
# =============================================================================

@router.get("/api/cognition/awareness")
async def cognition_awareness():
    miss = _phase13_missing("awareness")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "snapshot": state.cognition.awareness.snapshot_dict(),
        "history": state.cognition.awareness.history(n=20),
        "running": state.cognition.awareness.is_running(),
    })


@router.post("/api/cognition/awareness/tick")
async def cognition_awareness_tick():
    miss = _phase13_missing("awareness")
    if miss is not None:
        return miss
    s = state.cognition.awareness.tick_now()
    return JSONResponse({"ok": True, "snapshot": s.to_dict()})


@router.get("/api/cognition/awareness/session")
async def cognition_awareness_session():
    miss = _phase13_missing("awareness")
    if miss is not None:
        return miss
    if not hasattr(state.cognition.awareness, "session"):
        return JSONResponse({"ok": False,
                              "error": "session tracking not available"})
    return JSONResponse({"ok": True, "session": state.cognition.awareness.session()})


# =============================================================================
# Watchdog
# =============================================================================

@router.get("/api/cognition/watchdog")
async def cognition_watchdog():
    miss = _phase13_missing("watchdog")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "report": state.cognition.watchdog.report()})


@router.post("/api/cognition/watchdog/tick")
async def cognition_watchdog_tick():
    miss = _phase13_missing("watchdog")
    if miss is not None:
        return miss
    rep = state.cognition.watchdog.tick_now()
    return JSONResponse({"ok": True, "report": rep.to_dict()})


# =============================================================================
# Probes (scheduled diagnostic checks)
# =============================================================================

@router.get("/api/cognition/probes")
async def cognition_probes():
    miss = _phase13_missing("probes")
    if miss is not None:
        return miss
    last = state.cognition.probes.last()
    return JSONResponse({
        "ok": True,
        "registered": state.cognition.probes.list_probes(),
        "last": (last.__dict__ if last else None),
        "running": state.cognition.probes.is_running(),
    })


@router.post("/api/cognition/probes/tick")
async def cognition_probes_tick():
    miss = _phase13_missing("probes")
    if miss is not None:
        return miss
    res = state.cognition.probes.tick_now()
    return JSONResponse({"ok": True, "result": (res.__dict__ if res else None)})


# =============================================================================
# Self-repair (patch history)
# =============================================================================

@router.get("/api/cognition/self_repair")
async def cognition_self_repair(limit: int = 50):
    miss = _phase13_missing("self_repair")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "stats": state.cognition.self_repair.stats(),
        "recent": [p.to_dict() for p in state.cognition.self_repair.recent(limit=limit)],
    })


# =============================================================================
# Lessons (persistent preference rules)
# =============================================================================

@router.get("/api/cognition/lessons")
async def cognition_lessons_list(text: str = "", limit: int = 50):
    miss = _phase13_missing("lessons")
    if miss is not None:
        return miss
    ls = state.cognition.lessons
    if text:
        rows = [L.to_dict() for L in ls.relevant(text=text, limit=limit)]
    else:
        rows = [L.to_dict() for L in ls.all(limit=limit)]
    return JSONResponse({"ok": True, "stats": ls.stats(), "rows": rows})


@router.post("/api/cognition/lessons/add")
async def cognition_lessons_add(req: Request):
    miss = _phase13_missing("lessons")
    if miss is not None:
        return miss
    try:
        body = await req.json()
    except Exception:
        body = {}
    text = (body.get("text") or "").strip()
    polarity = body.get("polarity", "dont")
    scope = body.get("scope", "global")
    source = body.get("source", "api")
    L = state.cognition.lessons.add(text=text, polarity=polarity,
                                    scope=scope, source=source)
    if L is None:
        return JSONResponse({"ok": False, "error": "lesson rejected"}, status_code=400)
    return JSONResponse({"ok": True, "lesson": L.to_dict()})


@router.delete("/api/cognition/lessons/{lid}")
async def cognition_lessons_remove(lid: int):
    miss = _phase13_missing("lessons")
    if miss is not None:
        return miss
    return JSONResponse({"ok": state.cognition.lessons.remove(int(lid))})


# =============================================================================
# Reflection (workflow detection + insight stream)
# =============================================================================

@router.get("/api/cognition/reflection/recent")
async def cognition_reflection_recent(n: int = 30, kind: str = ""):
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    return JSONResponse({
        "ok": True,
        "stats": state.cognition.reflection.stats(),
        "rows": state.cognition.reflection.recent(limit=n, kind=(kind or None)),
    })


@router.post("/api/cognition/reflection/tick")
async def cognition_reflection_tick():
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    out = state.cognition.reflection.tick_now()
    return JSONResponse({"ok": True,
                          "generated": [i.to_dict() for i in out]})


@router.post("/api/cognition/reflection/detect_workflows")
async def cognition_workflows_detect():
    miss = _phase13_missing("reflection")
    if miss is not None:
        return miss
    out = state.cognition.reflection.detect_workflows()
    return JSONResponse({"ok": True, "generated": [p.to_dict() for p in out]})
