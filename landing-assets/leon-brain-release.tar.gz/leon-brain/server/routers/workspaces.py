"""
Workspace / terminal / session management routes.

Extracted from the monolithic server.py — covers:
  - Forever-session helpers and /api/workspaces
  - Claude usage proxy (/api/claude/usage via Octogent)
  - Tmux terminal capture, send, launch, wrapup, kill
  - PTY-backed WebSocket terminal (/ws/term/{window})
  - ANSI processing / line-color injection for xterm.js
  - Voice transcription (/api/voice/transcribe)
  - File upload (/api/upload)
  - Folder color persistence (/api/folder-color)
  - Session CRUD: rename, color, move, folder rename, create
  - Path listing autocomplete (/api/path/list)
  - Sensory input routes (/api/input/text, vision, audio)
"""

import asyncio
import json
import logging
import os
import re
import shutil
import struct
import subprocess
import threading
import time
import uuid

# fcntl / pty / termios are Unix-only. On Windows these do not exist and an
# unconditional import kills the ENTIRE server at boot (this router is imported
# eagerly by server/__init__.py). They are only used by the tmux terminal
# websocket below, which is a dashboard convenience, not the SI. Guard them and
# degrade that one feature instead of taking the whole process down.
try:
    import fcntl
    import pty
    import termios
    HAS_PTY = True
except ImportError:  # pragma: no cover - Windows
    fcntl = None
    pty = None
    termios = None
    HAS_PTY = False

from fastapi import APIRouter, Request, UploadFile, File, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

from server import state
from server.helpers import _ensure_stt

from server.terminal_spawner import spawner
from server.windows_terminal_handler import handle_windows_terminal

log = logging.getLogger("leon.server")

router = APIRouter()

# =============================================================================
# Forever-session helpers
# =============================================================================

_FOREVER_PATH = os.path.expanduser("~/.openclaw/forever-sessions.json")
_FOLDER_COLORS_PATH = os.path.expanduser("~/.openclaw/folder-colors.json")
_OCTOGENT_STATE = os.path.expanduser("~/octogent-test/.octogent/state")
_TMUX_SESSION = "agents"

# Split-brain: when Leon's brain runs on VPS, terminals SSH through to
# Dean's PC via Tailscale to access the real tmux sessions + project dirs.
_REMOTE_PC_HOST = os.environ.get("LEON_REMOTE_PC_HOST", "")

# LEON_HOST_ROLE: "brain" → this process is the VPS brain (SSH back to
# PC for tmux), "body" → this is the PC. Defaults: if env set, trust it;
# otherwise fall back to the legacy heuristic (no owner home + uid 0)
# for backward compat with hosts that haven't been updated.
# Audit fix: removes the foot-gun where any non-Dean root user is
# mis-detected as the VPS.
_HOST_ROLE = os.environ.get("LEON_HOST_ROLE", "").strip().lower()
if _HOST_ROLE in ("brain", "vps"):
    _IS_VPS = True
elif _HOST_ROLE in ("body", "pc", "local"):
    _IS_VPS = False
else:
    _IS_VPS = (
        not os.path.exists(os.path.expanduser("~" + os.environ.get("LEON_OWNER_ACCOUNT", "_nobody_")))
        and hasattr(os, "getuid")
        and os.getuid() == 0
    )
_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\][^\x07]*\x07|\x1b[()][AB012]")

def _group_order() -> list:
    """Sort priority for workspace group headings in the dashboard.

    Only a sort key — a name not in this list still renders, it just sorts
    last. The owner's two company groups used to be literals here, naming his
    holdco and his client roster in a file that ships to every customer while
    doing nothing for them: nobody else has tmux groups by those names, so
    the entries were dead weight on every install but his.
    brain/origin.py returns () on any shipped build.
    """
    order = ["System"]
    try:
        from brain.origin import owner_workspace_groups
        order += list(owner_workspace_groups())
    except Exception:
        pass
    return order + [
        "Personal Research",
        "Personal Handmade Projects",
        "Private Server",
    ]


_GROUP_ORDER = _group_order()


def _tmux(*args, timeout=5):
    try:
        # Always use local tmux, whether on VPS or PC.
        # The brain manages its own session (on VPS) independent of the PC.
        # This allows terminals to work regardless of whether the PC is booted
        # into Linux or Windows, and removes the SSH dependency.
        cmd = ["tmux", *args]
        return subprocess.check_output(
            cmd,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            text=True,
        )
    except Exception:
        return None


_KEEPER_CGROUP_PROCS = (
    "/sys/fs/cgroup/system.slice/agents-tmux-keeper.service/cgroup.procs"
)


def _pid_descendants(pid):
    """Return [pid, ...all descendants], parents before children."""
    out = [pid]
    frontier = [pid]
    seen = {pid}
    while frontier:
        nxt = []
        for p in frontier:
            try:
                with open("/proc/%d/task/%d/children" % (p, p)) as fh:
                    kids = [int(x) for x in fh.read().split()]
            except (OSError, ValueError):
                continue
            for k in kids:
                if k not in seen:
                    seen.add(k)
                    out.append(k)
                    nxt.append(k)
        frontier = nxt
    return out


def _reparent_tmux_to_keeper():
    """Move the tmux server out of leon.service's cgroup and into the keeper's.

    leon.service restarts destroy their own cgroup, which kills every process in
    it -- including the tmux server and therefore all of Dean's terminals.
    agents-tmux-keeper.service exists solely to hold them somewhere systemd will
    not sweep. Nothing ever joined it, so this does the joining.

    Children spawned after the move inherit the keeper cgroup, so future windows
    and panes are protected without further work. Best-effort and silent: a
    failure here must never break terminal launch.
    """
    if not os.path.exists(_KEEPER_CGROUP_PROCS):
        return False
    try:
        srv = subprocess.run(
            ["tmux", "display-message", "-p", "#{pid}"],
            capture_output=True, text=True, timeout=5,
        )
        if srv.returncode != 0 or not srv.stdout.strip():
            return False
        root = int(srv.stdout.strip())
    except Exception:
        return False

    try:
        with open("/proc/%d/cgroup" % root) as fh:
            if "agents-tmux-keeper" in fh.read():
                return True  # already safe
    except OSError:
        return False

    moved = 0
    for pid in _pid_descendants(root):
        try:
            with open(_KEEPER_CGROUP_PROCS, "w") as fh:
                fh.write("%d\n" % pid)
            moved += 1
        except OSError:
            continue  # exited, or kernel refused -- keep going
    try:
        log.info("[WORKSPACES] tmux reparented to keeper cgroup (%d procs)", moved)
    except Exception:
        pass
    return moved > 0


def _ensure_agents_session():
    """Guarantee the base `agents` tmux session exists locally.

    Every browser terminal attaches an ephemeral view session grouped onto
    `agents`, and term_launch creates windows inside it. On a fresh boot the
    tmux server isn't running yet and `agents` was never created, so both
    paths fail and the dashboard just shows a bare "WebSocket Error" with no
    cause. Creating it here idempotently is the missing bootstrap. Safe to
    call on every launch/attach — a no-op once the session is up.
    """
    try:
        has = subprocess.run(
            ["tmux", "has-session", "-t", _TMUX_SESSION],
            capture_output=True, timeout=5,
        )
        if has.returncode == 0:
            _reparent_tmux_to_keeper()
            return True
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", _TMUX_SESSION,
             "-n", "home", "-c", os.path.expanduser("~")],
            capture_output=True, timeout=5,
        )
        # Verify it actually came up.
        chk = subprocess.run(
            ["tmux", "has-session", "-t", _TMUX_SESSION],
            capture_output=True, timeout=5,
        )
        if chk.returncode == 0:
            _reparent_tmux_to_keeper()
            return True
        return False
    except Exception:
        return False


def _live_windows():
    out = _tmux("list-windows", "-t", _TMUX_SESSION, "-F", "#{window_name}")
    if not out:
        return set()
    return {ln.strip() for ln in out.split("\n") if ln.strip()}


def _load_forever():
    try:
        with open(_FOREVER_PATH) as f:
            return json.load(f).get("forever", [])
    except Exception:
        return []


def _save_forever(sessions):
    """Write the sessions array back, preserving any other top-level keys."""
    try:
        with open(_FOREVER_PATH) as f:
            doc = json.load(f)
    except Exception:
        doc = {}
    doc["forever"] = sessions
    tmp = _FOREVER_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)
    os.replace(tmp, _FOREVER_PATH)


def _load_folder_colors():
    try:
        with open(_FOLDER_COLORS_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_folder_colors(colors):
    tmp = _FOLDER_COLORS_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(colors, f, indent=2, ensure_ascii=False)
    os.replace(tmp, _FOLDER_COLORS_PATH)


def _slugify_window(name: str) -> str:
    """Match claude-launch's slug rule: lowercase, spaces->dashes, max 20 chars."""
    s = re.sub(r"[^A-Za-z0-9\s-]", "", name).strip().lower()
    s = re.sub(r"\s+", "-", s)
    s = re.sub(r"-+", "-", s)
    return s[:20] or "session"


# =============================================================================
# /api/workspaces
# =============================================================================

@router.get("/api/workspaces")
async def get_workspaces():
    """Mirror the user's exact forever-session hierarchy from ~/.openclaw."""
    sessions = _load_forever()
    colors = _load_folder_colors()
    live = _live_windows()

    # Build nested tree from the slash-separated group paths
    tree = {}
    for s in sessions:
        group = s.get("group") or "Other"
        parts = group.split("/")
        cursor = tree
        for i, part in enumerate(parts):
            full = "/".join(parts[: i + 1])
            if part not in cursor:
                cursor[part] = {
                    "name": part,
                    "path": full,
                    "color": colors.get(full),
                    "items": [],
                    "children": {},
                }
            if i == len(parts) - 1:
                wn = s["windowName"]
                cursor[part]["items"].append({
                    "windowName": wn,
                    "displayName": s["displayName"],
                    "path": s.get("path", ""),
                    "color": s.get("color"),  # per-session color override
                    "live": wn in live,
                })
            cursor = cursor[part]["children"]

    def to_list(d, ordered=False):
        items = list(d.values())
        if ordered:
            items.sort(key=lambda n: (
                _GROUP_ORDER.index(n["name"]) if n["name"] in _GROUP_ORDER else len(_GROUP_ORDER),
                n["name"],
            ))
        else:
            items.sort(key=lambda n: n["name"])
        for n in items:
            n["children"] = to_list(n["children"])
        return items

    groups = to_list(tree, ordered=True)
    return JSONResponse({
        "groups": groups,
        "live_count": len(live),
        "total": len(sessions),
    })


# =============================================================================
# Octogent / Claude usage proxy
# =============================================================================

# Octogent's local API does a fresh OAuth fetch on every GET. Talking
# to it directly gives live data; falling back to the cached snapshot
# file keeps the panel populated when Octogent is down.
_OCTOGENT_API_URL = "http://127.0.0.1:8787/api/claude/usage"


def _fetch_octogent_usage_blocking(timeout: float = 4.0):
    """Hit Octogent's API for a fresh snapshot. Returns parsed JSON or None."""
    import urllib.request
    try:
        req = urllib.request.Request(_OCTOGENT_API_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if 200 <= resp.status < 300:
                return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception:
        return None
    return None


def _read_snapshot_file():
    snapshot = os.path.join(_OCTOGENT_STATE, "claude-usage-snapshot.json")
    try:
        with open(snapshot) as f:
            data = json.load(f)
            data["source"] = data.get("source") or "snapshot-file"
            data["stale"] = True
            return data
    except Exception as e:
        # No live data AND no snapshot — speak the same schema the dashboard
        # expects (status:"error"), keeping `available` too for older clients.
        return {"status": "error", "available": False, "error": str(e)}


@router.get("/api/claude/usage")
async def get_claude_usage(refresh: bool = False):
    """Real Claude usage. Leon-native FIRST (reads the OAuth token and queries
    Anthropic's usage API directly — no OctoGent), then legacy OctoGent API,
    then OctoGent's cached snapshot file. `?refresh=1` forces a live fetch +
    longer timeout. The native path is what survives OctoGent retirement."""
    timeout = 8.0 if refresh else 3.5
    loop = asyncio.get_running_loop()

    # 1. Leon-native (no OctoGent dependency).
    try:
        from server import claude_usage as _cu
        data = await loop.run_in_executor(None, _cu.get_usage_cached, refresh, timeout)
        if data is not None:
            return JSONResponse(data)
    except Exception:
        pass

    # 2. Legacy OctoGent local API (only reachable where OctoGent runs).
    data = await loop.run_in_executor(None, _fetch_octogent_usage_blocking, timeout)
    if data is not None:
        return JSONResponse(data)

    # 3. OctoGent's cached snapshot file, flagged stale.
    return JSONResponse(_read_snapshot_file())


# =============================================================================
# ANSI processing / line-color injection for xterm.js
# =============================================================================

_BLANK_RUN_RE     = re.compile(r"\n{2,}")
_DIVIDER_LINE_RE  = re.compile(r"^─{20,}\s*$", re.MULTILINE)
_EMPTY_PROMPT_RE  = re.compile(r"^❯\s*$", re.MULTILINE)
# Statusline: any line containing `ctx N%` and a /-command, plus the
# `bypass permissions` line right below. Permissive on the in-between chars
# because the in-box version has - chars merged in from the box border.
_STATUSLINE_RE    = re.compile(
    r"^[^\n]*ctx\s*\d+%[^\n]*?(?:/loop|/usage|/powerup)[^\n]*\n[^\n]*bypass permissions[^\n]*",
    re.MULTILINE,
)
# Lines that are MOSTLY - chars (50%+) but not pure - -- these are the
# top/bottom of a Claude box that has content embedded in them.
_DASH_HEAVY_RE    = re.compile(r"^[\s─–—-]*$", re.MULTILINE)

# Claude Code's renderer inserts decorative "wrap-marker" chars between
# words (any single byte wrapped in colored escapes like
# \x1b[38;5;186m<char>\x1b[39m). When ANSI is stripped these become literal
# letters/digits/symbols that mangle text -- `running off the right` ends up
# as `runningtoff7the<right`. We catch the colored single-char chunks and
# replace each with a space *before* general ANSI stripping.
_INTERWORD_DECO_RE = re.compile(
    rb"\x1b\[38;5;\d+m.\x1b\[39m"
)

# For server-side line classification we need to look at lines after stripping
# ANSI sequences. These are scoped to that classification step only.
_ANSI_STRIP_FOR_TEST = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]")
_USER_LINE_TEST_RE  = re.compile(r"^\s*[❯>]")
_THINK_LINE_TEST_RE = re.compile(r"^\s*\S\s+\w+(?:\s+for\s|…|\.\.\.)")

# 256-color sequences for our overrides (rendered natively by xterm.js).
# Whole-line overrides strip inner fg codes so our color wins.
_INNER_FG_STRIP_RE = re.compile(r"\x1b\[(?:38;5;\d+|3[0-79]|39)m")
_USER_FG  = "\x1b[38;5;87m"    # bright cyan  (user-input lines)
_THINK_FG = "\x1b[38;5;213m"   # bright pink  (thinking lines)
_FG_RESET = "\x1b[39m"

# Substring patterns for status-bar elements (bypass / ctx).
# Applied to ANSI-stripped text so ANSI codes can't interfere with matching.
_BYPASS_ON_PAT  = re.compile(r"(bypass permissions on)", re.IGNORECASE)
_BYPASS_OFF_PAT = re.compile(r"(bypass permissions off)", re.IGNORECASE)
_CTX_WARN_PAT   = re.compile(r"(⚠\s*ctx\s*\d+%[^\n]*?LOG\s*&\s*RESTART)")
_CTX_OK_PAT     = re.compile(r"(ctx\s*\d+%)")
_BYPASS_ON_FG   = "\x1b[38;5;196m"  # bright red
_BYPASS_OFF_FG  = "\x1b[37m"         # white
_CTX_WARN_FG    = "\x1b[38;5;220m"  # yellow
_CTX_OK_FG      = "\x1b[38;5;78m"   # green


def _inject_line_colors(text: str) -> str:
    """Recolor user-input, thinking, bypass, and ctx lines via ANSI for xterm.js."""
    out_lines = []
    for line in text.split("\n"):
        stripped = _ANSI_STRIP_FOR_TEST.sub("", line)
        if _USER_LINE_TEST_RE.match(stripped):
            # Whole-line cyan; strip inner fg so our color wins
            line = _USER_FG + _INNER_FG_STRIP_RE.sub("", line) + _FG_RESET
        elif _THINK_LINE_TEST_RE.match(stripped):
            # Whole-line pink
            line = _THINK_FG + _INNER_FG_STRIP_RE.sub("", line) + _FG_RESET
        elif _BYPASS_ON_PAT.search(stripped):
            # Substring red; work on clean text (status bar ANSI is noisy anyway)
            line = _BYPASS_ON_PAT.sub(_BYPASS_ON_FG + r"\1" + _FG_RESET, stripped)
        elif _BYPASS_OFF_PAT.search(stripped):
            line = _BYPASS_OFF_PAT.sub(_BYPASS_OFF_FG + r"\1" + _FG_RESET, stripped)
        elif _CTX_WARN_PAT.search(stripped):
            line = _CTX_WARN_PAT.sub(_CTX_WARN_FG + r"\1" + _FG_RESET, stripped)
        elif _CTX_OK_PAT.search(stripped):
            line = _CTX_OK_PAT.sub(_CTX_OK_FG + r"\1" + _FG_RESET, stripped)
        out_lines.append(line)
    return "\n".join(out_lines)


# =============================================================================
# Terminal capture / send / launch / wrapup / kill
# =============================================================================

def _validate_window(window: str):
    """Reject window names that don't match the tmux-safe allowlist."""
    if not re.match(r"^[A-Za-z0-9_-]{1,64}$", window):
        return JSONResponse({"error": "invalid window name"}, status_code=400)
    return None


@router.get("/api/term/{window}/capture")
async def term_capture(window: str, lines: int = 200):
    """Capture last N lines of a tmux pane and clean it for xterm.js.

    Pipeline:
      -e            -> preserve ANSI escape sequences (xterm renders natively).
      -J            -> join wrapped lines.
      strip interword decorations -> remove Claude Code's single-char colored
                      wrap-markers that would appear as literal letters.
      NBSP -> space  -> fixes non-breaking spaces that block word-wrap.
      rstrip        -> drop tmux's trailing-space padding.
      inject colors -> custom ANSI for user-input (cyan), thinking (pink),
                      bypass on (red), bypass off (white), ctx (green/yellow).
    """
    if (err := _validate_window(window)): return err
    # -e: preserve escape sequences so we can target Claude Code's wrap-marker
    # decorations specifically before stripping the rest.
    out = _tmux(
        "capture-pane", "-t", f"{_TMUX_SESSION}:{window}",
        "-p", "-e", "-J", "-S", f"-{lines}",
    )
    if out is None:
        # tmux command failed -- but maybe just transient. If the window
        # actually still exists, report alive with empty/transient flag so
        # the UI doesn't flash "session ended" on a 2s timeout glitch.
        if window in _live_windows():
            return JSONResponse({"alive": True, "content": "", "transient": True})
        return JSONResponse({"alive": False, "content": ""})

    # Strip the buggy Claude Code interword wrap-marker decorations
    # (single colored bytes between words that look like literal letters).
    raw = out.encode("utf-8", errors="replace")
    raw = _INTERWORD_DECO_RE.sub(b" ", raw)
    text = raw.decode("utf-8", errors="replace")

    # Replace U+00A0 NBSP with regular space.
    text = text.replace("\u00a0", " ")

    # Trim trailing whitespace per line and strip outer blank lines.
    text = "\n".join(ln.rstrip() for ln in text.split("\n"))
    text = text.strip("\n")

    # Inject custom colors for user-input lines (cyan) + thinking lines (pink)
    # so xterm.js renders them with our preferred styling on top of Claude
    # CLI's native rendering. We strip ANSI to test the line, then wrap the
    # ORIGINAL line (with its existing escape codes) in our color sequence.
    text = _inject_line_colors(text)

    return JSONResponse({"alive": True, "content": text})


@router.post("/api/term/{window}/send")
async def term_send(window: str, data: dict):
    """Send text + optional control key to a live tmux pane."""
    if (err := _validate_window(window)): return err
    keys = data.get("keys", "")
    suffix = data.get("suffix", "Enter")  # 'Enter', 'Tab', 'Up', 'C-c', '' for nothing
    args = ["send-keys", "-t", f"{_TMUX_SESSION}:{window}"]
    if keys:
        args.extend(["-l", keys])      # -l = literal, no key parsing
    res1 = _tmux(*args) if keys else ""
    if suffix:
        # second call sends the special key without -l
        args2 = ["send-keys", "-t", f"{_TMUX_SESSION}:{window}", suffix]
        res2 = _tmux(*args2)
    else:
        res2 = ""
    return JSONResponse({"ok": res1 is not None and res2 is not None})


@router.post("/api/term/{window}/launch")
async def term_launch(window: str):
    """Spawn a fresh tmux window for a forever-session and auto-start Claude.

    Mirrors `claude-launch` behavior: prefer claude-nomouse (strips mouse
    escapes), fall back to claude. Use `-d` so attached agent clients don't
    get yanked into the new window.
    """
    if (err := _validate_window(window)): return err
    sessions = _load_forever()
    cfg = next((s for s in sessions if s["windowName"] == window), None)
    if not cfg:
        return JSONResponse({"error": "unknown forever-session"}, status_code=404)
    if window in _live_windows():
        return JSONResponse({"ok": True, "already_live": True})

    # On a client machine the session runs locally — so tmux must be present.
    # Without this guard a missing tmux just returns ok:False with no reason,
    # and the button looks dead. Report the real cause and the one-line fix.
    if not _IS_VPS and not shutil.which("tmux"):
        return JSONResponse(
            {"ok": False, "error": "tmux not installed",
             "hint": "Install it: macOS `brew install tmux`, Debian/Ubuntu "
                     "`sudo apt-get install -y tmux`. Then retry Launch Session."},
            status_code=503,
        )

    path = cfg.get("path") or os.path.expanduser("~")

    # Resolve which claude binary to use (matches claude-launch logic)
    claude_cmd = "claude"
    for cand in ("claude-nomouse", "claude"):
        if shutil.which(cand):
            claude_cmd = cand
            break

    # Bootstrap the base session if this is the first terminal since boot,
    # otherwise `new-window -t agents:` has nothing to attach to.
    _ensure_agents_session()

    out = _tmux("new-window", "-d", "-t", f"{_TMUX_SESSION}:",
                "-n", window, "-c", path, claude_cmd)
    return JSONResponse({"ok": out is not None, "command": claude_cmd})


_WRAPUP_PROMPT = (
    "Please save and wrap up this session: write a brief session log "
    "(what we did, what's done, what's still open), save important context to the "
    "appropriate file, then reply 'Wrap-up complete.'"
)


@router.post("/api/term/{window}/wrapup")
async def term_wrapup(window: str):
    """Send a save-and-wrap-up prompt to the live Claude session."""
    if (err := _validate_window(window)): return err
    if window not in _live_windows():
        return JSONResponse({"error": "session not live"}, status_code=400)
    target = f"{_TMUX_SESSION}:{window}"
    # ROUTED THROUGH THE GATE 2026-08-03 — this was an HTTP route that wrote a
    # prompt and pressed Enter with no cursor check, no permission-mode check
    # and no payload class. The sharpest of the four ungated doors.
    from brain.mission.terminal_loop import TerminalWatcher
    _gated = TerminalWatcher().send(target.split(":")[-1], _WRAPUP_PROMPT)
    r1 = r2 = type("R", (), {"returncode": 0 if _gated else 1,
                             "stdout": "", "stderr": "" if _gated else "gate refused"})()
    return JSONResponse({"ok": r1 is not None and r2 is not None})


@router.post("/api/term/{window}/kill")
async def term_kill(window: str):
    if (err := _validate_window(window)): return err
    """Kill the tmux window for this forever-session."""
    out = _tmux("kill-window", "-t", f"{_TMUX_SESSION}:{window}")
    return JSONResponse({"ok": out is not None})


# =============================================================================
# Real PTY-backed terminal: WebSocket bridges xterm.js <-> tmux pane.
#
# Each browser terminal opens /ws/term/{window}. Server spawns
# `tmux attach-session` in a Python PTY, attached to an EPHEMERAL per-tab
# grouped session (leon-view-<uuid>) pointed at `agents`. The session is
# created on connect and killed on disconnect — no persistence, no keeper
# script, no destroy-unattached games. Per-tab uuids mean two tabs viewing
# the same window get independent scroll/copy-mode state.
#
# Protocol (matches Octogent's so xterm wiring stays clean):
#   server -> client: raw bytes (xterm.write directly)
#   client -> server: JSON text {type:"input", data:"..."} or
#                                {type:"resize", rows:N, cols:N}
# =============================================================================


def _set_pty_size(fd: int, rows: int, cols: int) -> None:
    if not HAS_PTY:
        return
    try:
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    except Exception:
        pass


_WINDOW_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")



@router.websocket("/ws/term/{window}")
async def ws_term(websocket: WebSocket, window: str):
    """Terminal: Connect to tmux window created by /api/term/{window}/launch.

    Attaches an ephemeral tmux view session to the real tmux window
    (in the agents session), so multiple dashboard tabs can view the same
    window with independent copy-mode and scrollback.
    """
    # Validate `window` BEFORE accepting the WS
    if not _WINDOW_NAME_RE.match(window):
        await websocket.close(code=4400, reason="invalid window name")
        return
    await websocket.accept()

    if not HAS_PTY:
        await websocket.send_text(
            "Terminal panes are unavailable on this platform.\r\n"
        )
        await websocket.close()
        return

    # Check that the tmux window exists before we try to attach
    if window not in _live_windows():
        await websocket.send_text(f"Terminal window '{window}' is not running.\r\n")
        await websocket.send_text("Click 'Launch Session' to start it.\r\n")
        await websocket.close()
        return

    # Create ephemeral per-tab view session so each browser tab gets independent
    # scrollback and copy-mode state, but all attached to the same window.
    view_session = f"leon-view-{uuid.uuid4().hex[:8]}"
    attached_fd = None
    attached_proc = None
    proc = None

    try:
        # Ensure base session exists
        _ensure_agents_session()

        # Grouped session: shares agents' windows but has its OWN current
        # window. Attaching straight to `agents:<window>` is the duplication
        # bug — every client of one session shares the active window, so a
        # second dashboard tab switched ALL tabs to its window and mirrored
        # input everywhere. The grouped view session is what the docstring
        # always promised; killed on disconnect below.
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", view_session,
             "-t", _TMUX_SESSION],
            capture_output=True, timeout=5,
        )
        subprocess.run(
            ["tmux", "select-window", "-t", f"{view_session}:{window}"],
            capture_output=True, timeout=5,
        )

        # Spawn tmux attach in a Python PTY so we can interactively manage it
        attached_proc = pty.openpty()
        attached_fd = attached_proc[0]

        # Set non-blocking mode with fcntl
        fcntl.fcntl(attached_fd, fcntl.F_SETFL, os.O_NONBLOCK)

        # Set up environment for the PTY with proper terminal support
        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["LANG"] = "en_US.UTF-8"

        # Attach to the per-tab view session (NOT the shared agents session)
        proc = subprocess.Popen(
            ["tmux", "attach-session", "-t", view_session],
            stdin=attached_proc[1],
            stdout=attached_proc[1],
            stderr=attached_proc[1],
            preexec_fn=os.setsid,
            env=env,
        )

        await websocket.send_text(f"Attached to {window}\r\n")

        # Bidirectional proxy: browser input ↔ tmux PTY
        async def read_pty():
            """Read from tmux PTY and send to browser."""
            loop = asyncio.get_event_loop()
            while True:
                try:
                    # Read non-blocking from PTY
                    data = await loop.run_in_executor(None, os.read, attached_fd, 4096)
                    if data:
                        await websocket.send_text(data.decode("utf-8", errors="replace"))
                    else:
                        break
                except BlockingIOError:
                    await asyncio.sleep(0.05)
                except Exception as e:
                    log.error(f"PTY read error: {e}")
                    break

        async def write_pty():
            """Read from browser WebSocket and write to tmux PTY."""
            try:
                while True:
                    msg = await websocket.receive()
                    if msg.get("type") == "websocket.disconnect":
                        return

                    if msg.get("text"):
                        try:
                            data = json.loads(msg["text"])
                            if data.get("type") == "input":
                                text = data.get("data", "")
                                os.write(attached_fd, text.encode("utf-8"))
                            elif data.get("type") == "resize":
                                rows = data.get("rows", 40)
                                cols = data.get("cols", 120)
                                _set_pty_size(attached_fd, rows, cols)
                        except Exception:
                            pass
            except WebSocketDisconnect:
                pass

        # Run both directions concurrently. FIRST_COMPLETED, not gather:
        # when the browser disconnects, write_pty returns but read_pty
        # would spin forever on an idle pane (BlockingIOError → sleep),
        # so gather never returned and the finally-cleanup never ran —
        # leaking one attached tmux client + view session per closed tab.
        _t_read = asyncio.create_task(read_pty())
        _t_write = asyncio.create_task(write_pty())
        _done, _pending = await asyncio.wait(
            {_t_read, _t_write}, return_when=asyncio.FIRST_COMPLETED
        )
        for _t in _pending:
            _t.cancel()
        await asyncio.gather(*_pending, return_exceptions=True)

    except Exception as e:
        log.error(f"Terminal attach error: {e}")
        try:
            await websocket.send_text(f"Error: {e}\r\n")
            await websocket.close()
        except Exception:
            pass
    finally:
        # Clean up PTY and process
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), 15)
                proc.wait(timeout=2)
            except Exception:
                pass

        # Kill the ephemeral view session — grouped sessions do NOT die with
        # their client, and leaked leon-view-* sessions accumulate forever.
        try:
            subprocess.run(
                ["tmux", "kill-session", "-t", view_session],
                capture_output=True, timeout=5,
            )
        except Exception:
            pass

        if attached_fd is not None:
            try:
                os.close(attached_fd)
            except Exception:
                pass

        try:
            await websocket.close()
        except Exception:
            pass

# =============================================================================
# Voice transcription
# =============================================================================

_FFMPEG_CACHE = []


def _resolve_ffmpeg():
    """Return a usable ffmpeg executable path, or None.

    2026-08-10: this endpoint hard-called bare "ffmpeg" and 500'd on every
    Windows install, because Windows ships no ffmpeg and the installer never
    added one. Symptom Dean saw for days: press the mic button in the
    dashboard -> "error". The always-on mic daemon worked fine the whole time,
    which is what made it confusing -- the daemon reads raw PCM straight off
    the sound card and never needs a decoder. Only THIS path does, because the
    browser's MediaRecorder hands us webm/opus.

    Order: system ffmpeg (fastest, usually present on Linux/mac) -> the static
    binary bundled by the imageio-ffmpeg wheel (pip-installable, no admin, all
    three platforms). Result is cached; resolution is a few ms but this runs
    on every utterance.
    """
    if _FFMPEG_CACHE:
        return _FFMPEG_CACHE[0]
    found = shutil.which("ffmpeg")
    if not found:
        try:
            import imageio_ffmpeg
            cand = imageio_ffmpeg.get_ffmpeg_exe()
            if cand and os.path.exists(cand):
                found = cand
        except Exception:
            found = None
    if found:
        _FFMPEG_CACHE.append(found)
    return found


@router.post("/api/voice/transcribe")
async def voice_transcribe(request: Request):
    """Accept a raw audio blob (webm/ogg/wav), transcribe, return text.
    The frontend uses MediaRecorder which produces webm/opus by default."""
    import tempfile
    body = await request.body()
    if not body:
        return JSONResponse({"error": "empty body"}, status_code=400)

    stt = _ensure_stt()
    if stt is None:
        return JSONResponse({"error": "no STT backend installed"}, status_code=503)

    # Save the blob and convert to 16kHz mono WAV via ffmpeg (handles webm/opus).
    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as src:
        src.write(body)
        src_path = src.name
    wav_path = src_path.replace(".webm", ".wav")

    ffmpeg_bin = _resolve_ffmpeg()
    if ffmpeg_bin is None:
        return JSONResponse(
            {"error": "ffmpeg not available — cannot decode browser audio. "
                      "Install with: pip install imageio-ffmpeg"},
            status_code=503)

    try:
        ff = subprocess.run(
            [ffmpeg_bin, "-y", "-i", src_path, "-ac", "1", "-ar", "16000",
             "-acodec", "pcm_s16le", wav_path],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15,
        )
        if ff.returncode != 0:
            return JSONResponse({"error": "ffmpeg conversion failed"}, status_code=500)
        # Read PCM16 frames
        import wave
        with wave.open(wav_path, "rb") as wf:
            pcm = wf.readframes(wf.getnframes())
            sr = wf.getframerate()
        result = stt.transcribe(pcm, sample_rate=sr)
        return JSONResponse({
            "text": (result.text or "").strip(),
            "duration": getattr(result, "duration_sec", None),
        })
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        for p in (src_path, wav_path):
            try: os.unlink(p)
            except Exception: pass


# =============================================================================
# File upload
# =============================================================================

_UPLOAD_DIR = os.path.expanduser("~/Desktop/leon-uploads")
_SAFE_NAME_RE = re.compile(r"[^\w.\- ]")


@router.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    """Receive a dropped file, save to ~/Desktop/leon-uploads, return absolute path."""
    os.makedirs(_UPLOAD_DIR, exist_ok=True)
    raw_name = file.filename or "upload.bin"
    safe = _SAFE_NAME_RE.sub("_", raw_name).strip().lstrip(".") or "upload.bin"

    save_path = os.path.join(_UPLOAD_DIR, safe)
    if os.path.exists(save_path):
        base, ext = os.path.splitext(safe)
        i = 1
        while os.path.exists(save_path):
            save_path = os.path.join(_UPLOAD_DIR, f"{base}-{i}{ext}")
            i += 1

    try:
        with open(save_path, "wb") as f:
            while True:
                chunk = await file.read(1 << 20)  # 1 MB chunks
                if not chunk:
                    break
                f.write(chunk)
        size = os.path.getsize(save_path)
        return JSONResponse({"path": save_path, "size": size, "name": os.path.basename(save_path)})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# =============================================================================
# Folder color
# =============================================================================

_HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")


def _valid_hex(color) -> bool:
    """Colors are rendered into inline style attributes on the dashboard, so
    only well-formed hex values are allowed to be stored — this stops a
    crafted value from becoming persistent XSS on every device that loads."""
    return isinstance(color, str) and bool(_HEX_COLOR_RE.match(color))


@router.post("/api/folder-color")
async def folder_color(data: dict):
    """Update folder color in ~/.openclaw/folder-colors.json."""
    path = data.get("path")
    color = data.get("color")
    if not path or not color:
        return JSONResponse({"error": "missing path or color"}, status_code=400)
    if not _valid_hex(color):
        return JSONResponse({"error": "invalid color (expected hex like #ff00c8)"}, status_code=400)
    try:
        colors = _load_folder_colors()
        colors[path] = color
        _save_folder_colors(colors)
        return JSONResponse({"ok": True})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# =============================================================================
# Workspace management -- rename / recolor / move / create sessions and folders.
# All ops mutate ~/.openclaw/forever-sessions.json (the canonical registry) and
# ~/.openclaw/folder-colors.json. Tmux side effects (rename-window, new-window)
# happen here so the UI and runtime stay in sync.
# =============================================================================

@router.post("/api/session/{window}/rename")
async def session_rename(window: str, data: dict):
    """Rename a session -- updates display name and optionally the windowName.
    If windowName changes, the live tmux window is renamed to match."""
    new_display = data.get("displayName")
    new_window  = data.get("windowName")  # optional
    sessions = _load_forever()
    found = next((s for s in sessions if s["windowName"] == window), None)
    if not found:
        return JSONResponse({"error": "unknown session"}, status_code=404)
    if new_display:
        found["displayName"] = new_display.strip()
    if new_window and new_window != window:
        new_window = _slugify_window(new_window)
        if any(s["windowName"] == new_window for s in sessions):
            return JSONResponse({"error": "windowName already in use"}, status_code=409)
        found["windowName"] = new_window
        # Rename the live tmux window if it exists
        if window in _live_windows():
            _tmux("rename-window", "-t", f"{_TMUX_SESSION}:{window}", new_window)
    _save_forever(sessions)
    return JSONResponse({"ok": True, "windowName": found["windowName"]})


@router.post("/api/session/{window}/delete")
async def session_delete(window: str):
    """Delete a session outright: kill its tmux window if live, then drop
    it from the forever registry so it disappears from the workspace tree
    (Quit only kills the window and leaves the entry relaunchable)."""
    if (err := _validate_window(window)): return err
    sessions = _load_forever()
    if not any(s["windowName"] == window for s in sessions):
        return JSONResponse({"error": "unknown session"}, status_code=404)
    if window in _live_windows():
        _tmux("kill-window", "-t", f"{_TMUX_SESSION}:{window}")
    _save_forever([s for s in sessions if s["windowName"] != window])
    return JSONResponse({"ok": True})


@router.post("/api/session/{window}/color")
async def session_color(window: str, data: dict):
    """Set a per-session color override. Pass `null` to clear."""
    color = data.get("color")
    if color and not _valid_hex(color):
        return JSONResponse({"error": "invalid color (expected hex like #ff00c8)"}, status_code=400)
    sessions = _load_forever()
    found = next((s for s in sessions if s["windowName"] == window), None)
    if not found:
        return JSONResponse({"error": "unknown session"}, status_code=404)
    if color:
        found["color"] = color
    else:
        found.pop("color", None)
    _save_forever(sessions)
    return JSONResponse({"ok": True})


@router.post("/api/session/{window}/move")
async def session_move(window: str, data: dict):
    """Move a session into a folder (slash-separated for nesting)."""
    group = (data.get("group") or "").strip()
    if not group:
        return JSONResponse({"error": "missing group"}, status_code=400)
    sessions = _load_forever()
    found = next((s for s in sessions if s["windowName"] == window), None)
    if not found:
        return JSONResponse({"error": "unknown session"}, status_code=404)
    found["group"] = group
    _save_forever(sessions)
    return JSONResponse({"ok": True})


@router.post("/api/folder/rename")
async def folder_rename(data: dict):
    """Rename a folder by updating every session whose group starts with the
    old path, plus the folder-colors entry. Affects nested children too."""
    old_path = (data.get("oldPath") or "").strip()
    new_path = (data.get("newPath") or "").strip()
    if not old_path or not new_path or old_path == new_path:
        return JSONResponse({"error": "missing/identical paths"}, status_code=400)

    sessions = _load_forever()
    changed = 0
    for s in sessions:
        g = s.get("group") or ""
        if g == old_path:
            s["group"] = new_path
            changed += 1
        elif g.startswith(old_path + "/"):
            s["group"] = new_path + g[len(old_path):]
            changed += 1
    _save_forever(sessions)

    # Migrate folder-colors entries
    colors = _load_folder_colors()
    new_colors = {}
    for k, v in colors.items():
        if k == old_path:
            new_colors[new_path] = v
        elif k.startswith(old_path + "/"):
            new_colors[new_path + k[len(old_path):]] = v
        else:
            new_colors[k] = v
    _save_folder_colors(new_colors)
    return JSONResponse({"ok": True, "renamed": changed})


@router.post("/api/session/create")
async def session_create(data: dict):
    """Create a new forever-session, optionally launching its tmux window now.
    If `path` is omitted/empty, auto-create ~/Desktop/<windowName> for it."""
    display  = (data.get("displayName") or "").strip()
    path     = (data.get("path") or "").strip()
    group    = (data.get("group") or "Other").strip()
    color    = data.get("color")
    launch   = bool(data.get("launch", True))
    if not display:
        return JSONResponse({"error": "missing displayName"}, status_code=400)

    # Generate a unique windowName
    sessions = _load_forever()
    existing = {s["windowName"] for s in sessions}
    base = _slugify_window(display)
    window_name = base
    n = 2
    while window_name in existing:
        window_name = f"{base}-{n}"[:20]
        n += 1

    # Resolve path -- auto-create if not provided
    if path:
        path = os.path.expanduser(path)
        if not os.path.isdir(path):
            return JSONResponse({"error": f"path is not a directory: {path}"}, status_code=400)
    else:
        path = os.path.expanduser(f"~/Desktop/{window_name}")
        try:
            os.makedirs(path, exist_ok=True)
        except Exception as e:
            return JSONResponse({"error": f"failed to create {path}: {e}"}, status_code=500)

    entry = {
        "windowName": window_name,
        "displayName": display,
        "path": path,
        "group": group,
    }
    if color:
        entry["color"] = color
    sessions.append(entry)
    _save_forever(sessions)

    # When a new session is created with a color inside a folder that has no
    # color of its own yet, adopt that color for the folder too. Without this
    # the session gets the color but the workspace/folder dot stays grey — the
    # exact mismatch Dean hit. Never stomp an existing folder color.
    if color and group and group != "Other":
        try:
            colors = _load_folder_colors()
            if not colors.get(group):
                colors[group] = color
                _save_folder_colors(colors)
        except Exception:
            pass

    launched = False
    launch_error = None
    if launch:
        # Same guard as /api/term/{window}/launch (below). On a client machine
        # (not the VPS brain) tmux must actually be present to spawn anything.
        # Without this check, a missing tmux made _tmux() swallow a
        # FileNotFoundError and return None, this branch silently set
        # launched=False, and the endpoint still answered 200 {"ok": true} —
        # so the create button appeared to do nothing on Windows, where tmux
        # doesn't exist at all. The session record was actually saved (see
        # above); only the "start it now" step failed, invisibly.
        if not _IS_VPS and not shutil.which("tmux"):
            launch_error = (
                "Session saved, but the terminal could not be started: tmux "
                "is not installed on this machine. Install it (macOS: "
                "`brew install tmux`; Debian/Ubuntu: `sudo apt-get install -y "
                "tmux`) and click Launch Session — or on Windows, use a "
                "ConPTY-based terminal service, which this build does not "
                "have wired up yet."
            )
        else:
            claude_cmd = "claude"
            for cand in ("claude-nomouse", "claude"):
                if shutil.which(cand):
                    claude_cmd = cand
                    break
            out = _tmux("new-window", "-d", "-t", f"{_TMUX_SESSION}:",
                        "-n", window_name, "-c", path, claude_cmd)
            launched = out is not None
            if not launched:
                launch_error = "tmux failed to launch the session window."

    return JSONResponse({
        "ok": True,
        "windowName": window_name,
        "launched": launched,
        "launch_error": launch_error,
    })


# =============================================================================
# Path listing autocomplete
# =============================================================================

@router.get("/api/path/list")
async def path_list(prefix: str = "~"):
    """Lightweight directory autocomplete for the New Session form.
    Returns subdirectories under `prefix`. No file content, no recursion."""
    home = os.path.realpath(os.path.expanduser("~"))

    def _within_home(p):
        # Autocomplete is confined to the user's home tree — never enumerate
        # the whole filesystem (/etc, /root, /). realpath defeats ../ escapes.
        try:
            rp = os.path.realpath(p)
            return rp == home or rp.startswith(home + os.sep)
        except Exception:
            return False

    base = os.path.expanduser(prefix)
    if os.path.isdir(base) and not _within_home(base):
        return JSONResponse({"items": []})
    if not os.path.isdir(base):
        # Try treating the prefix as a partial path: list its parent and filter
        parent = os.path.dirname(base) or "/"
        leaf = os.path.basename(base).lower()
        if not os.path.isdir(parent) or not _within_home(parent):
            return JSONResponse({"items": []})
        try:
            names = sorted(
                n for n in os.listdir(parent)
                if not n.startswith(".") and n.lower().startswith(leaf)
                and os.path.isdir(os.path.join(parent, n))
            )
        except Exception:
            return JSONResponse({"items": []})
        return JSONResponse({"items": [{
            "name": n, "path": os.path.join(parent, n),
        } for n in names[:40]]})
    try:
        names = sorted(
            n for n in os.listdir(base)
            if not n.startswith(".") and os.path.isdir(os.path.join(base, n))
        )
    except Exception:
        return JSONResponse({"items": []})
    return JSONResponse({"items": [{
        "name": n, "path": os.path.join(base, n),
    } for n in names[:80]]})


# Sensory input routes (/api/input/*) moved to server/routers/io_routes.py
# (2026-06-08). io_routes.py is the canonical home; these were
# duplicates that had been silently overshadowed by FastAPI's
# first-registered-wins behavior.
