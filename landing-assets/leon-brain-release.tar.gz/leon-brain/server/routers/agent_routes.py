"""
/api/agent/* + /api/leon/* + /api/local_llm/* — unified tool dispatcher
(local registry + actuator client) with per-tool TTL cache, plus the
agent planner and run history.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged. The undo_apply_last RCE hardening from audit fix C4 lives
in brain/introspection.py — this router only EXPOSES the dispatcher.
"""

import asyncio
import json
import logging
import threading
import time
from typing import Dict, Optional

from fastapi import APIRouter

from brain.tools import describe_tools, call_tool, tool_history

from server import state

log = logging.getLogger("leon.server")
router = APIRouter()


# =============================================================================
# Agent: tool registry + single-tool invocation
# =============================================================================

@router.get("/api/agent/tools")
async def agent_list_tools():
    return {
        "tools": describe_tools(),
        "count": len(describe_tools()),
    }


@router.post("/api/agent/tool")
async def agent_call_single_tool(req: dict):
    tool = req.get("tool")
    args = req.get("args", {}) or {}
    if not tool:
        return {"ok": False, "error": "Missing 'tool' in request"}
    result = call_tool(tool, args)
    return result.to_dict()


@router.get("/api/local_llm/status")
async def local_llm_status():
    try:
        from brain import local_llm
        return local_llm.get_state()
    except Exception as e:
        return {"available": False, "error": f"{type(e).__name__}: {e}"}


# =============================================================================
# Unified Leon tool surface: local + actuator + registry
# =============================================================================

@router.get("/api/leon/tools")
async def leon_unified_tools():
    from brain.actuator_client import ANTHROPIC_TOOLS, TOOL_RISK
    out = []
    seen = set()
    for t in ANTHROPIC_TOOLS:
        out.append({
            "name": t["name"],
            "description": t["description"],
            "input_schema": t.get("input_schema", {"type": "object", "properties": {}}),
            "risk": TOOL_RISK.get(t["name"], "medium"),
            "source": "actuator+local",
        })
        seen.add(t["name"])
    for spec in describe_tools():
        mcp_name = spec["name"].replace(".", "_")
        if mcp_name in seen:
            continue
        props = {k: {"type": "string", "description": v} for k, v in (spec.get("params") or {}).items()}
        out.append({
            "name": mcp_name,
            "description": spec["description"],
            "input_schema": {
                "type": "object",
                "properties": props,
                "required": spec.get("required", []),
                "additionalProperties": False,
            },
            "risk": "high" if spec.get("dangerous") else "low",
            "source": "registry",
            "_registry_name": spec["name"],
        })
        seen.add(mcp_name)
    return {"tools": out, "count": len(out)}


# Per-tool TTL cache
_TOOL_CACHE_TTL: Dict[str, float] = {
    "window_list": 3.0, "screen_capture": 1.0, "vision_describe": 2.0,
    "knowledge_search": 30.0, "file_read": 5.0, "file_list": 5.0,
    "clipboard_paste": 2.0, "reminder_list": 5.0, "webcam_capture": 1.0,
}
_tool_cache: Dict[str, "tuple[float, dict]"] = {}
_TOOL_CACHE_MAX = 64
_tool_cache_lock = threading.Lock()


def _tool_cache_key(name: str, args: dict) -> str:
    try:
        return f"{name}|{json.dumps(args, sort_keys=True)}"
    except Exception:
        return f"{name}|{repr(args)}"


def _tool_cache_get(name: str, args: dict) -> Optional[dict]:
    ttl = _TOOL_CACHE_TTL.get(name)
    if not ttl:
        return None
    key = _tool_cache_key(name, args)
    with _tool_cache_lock:
        entry = _tool_cache.get(key)
        if not entry:
            return None
        ts, val = entry
        if time.time() - ts > ttl:
            _tool_cache.pop(key, None)
            return None
        out = dict(val)
        out["cached"] = True
        out["cached_age_s"] = round(time.time() - ts, 2)
        return out


def _tool_cache_put(name: str, args: dict, value: dict) -> None:
    if name not in _TOOL_CACHE_TTL:
        return
    if not value.get("ok"):
        return
    key = _tool_cache_key(name, args)
    with _tool_cache_lock:
        _tool_cache[key] = (time.time(), value)
        if len(_tool_cache) > _TOOL_CACHE_MAX:
            oldest = min(_tool_cache.items(), key=lambda kv: kv[1][0])[0]
            _tool_cache.pop(oldest, None)


def _log_and_cache(name: str, args: dict, response: dict) -> None:
    """Cache the result AND record tool usage. Every tool call (CLI/MCP + API)
    funnels through here; logging only at the API responder missed the CLI path,
    so tool_learning.jsonl was never written → "skill practice 0/0 top tools"."""
    _tool_cache_put(name, args, value=response)
    try:
        if isinstance(response, dict) and response.get("ok"):
            from brain.reflex_learning import log_tool_use
            log_tool_use(name)
    except Exception:
        pass


@router.post("/api/leon/tool")
async def leon_unified_call(req: dict):
    name = req.get("tool")
    args = req.get("args", {}) or {}
    if not name:
        return {"ok": False, "error": "Missing 'tool'"}

    cached = _tool_cache_get(name, args)
    if cached is not None:
        return cached

    from brain.actuator_client import _TOOL_NAME_MAP, ANTHROPIC_TOOLS, execute_anthropic_tool, is_alive

    try:
        lt = getattr(state.brain_api_responder, "local_tools", None) if state.brain_api_responder else None
    except Exception:
        lt = None
    # Resolve via lt[name], NOT `name in lt`: local_tools is a _LazyToolDict
    # whose __missing__ lazy-imports integration modules (email_*, cal_*,
    # finance_*, crm_*, …) on first access. `in`/`__contains__` does NOT
    # fire __missing__, so the old `name in lt` check reported every
    # not-yet-loaded integration tool as absent — they fell through to the
    # PC actuator, which returned "unknown tool", and Leon's email/calendar/
    # finance/etc. commands silently failed. Root-caused 2026-06-13.
    _local_fn = None
    if lt is not None:
        try:
            _local_fn = lt[name]          # triggers lazy-load on miss
        except KeyError:
            _local_fn = None              # genuinely not a brain-local tool
        except Exception as e:
            log = __import__("logging").getLogger("leon.server")
            log.warning("local_tools lazy-load for %s failed: %s", name, e)
            _local_fn = None
    if _local_fn is not None:
        try:
            # OFF THE EVENT LOOP. THIS ENDPOINT IS `async def`, AND EVERY
            # BRAIN-LOCAL TOOL IS SYNCHRONOUS -- shell_exec is a bare
            # subprocess.run with a timeout that can legitimately be 300s.
            # Calling it directly here parks the ONE uvicorn event loop inside
            # select() for the whole command, so for those five minutes this
            # process answers NOTHING: not /api/health, not the dashboard, and
            # not /api/onboarding/install-config -- the screen where a paying
            # customer pastes their install token.
            #
            # MEASURED 2026-08-12, live on sabrtechnologies.com (this box
            # serves it): 12 of 12 health probes hung while a test run was in
            # flight. Caddy answered static in 12ms; every proxied route timed
            # out at zero bytes. py-spy on the main thread showed exactly this
            # frame -> subprocess.run -> select. The "production outage" was
            # self-inflicted: an SI doing a long tool call takes its own owner
            # -- and its own checkout page -- offline for the duration, with no
            # error, no log line, and no way for the customer to tell the
            # difference from the server being down.
            #
            # A thread, not an async rewrite: the tools are sync by design and
            # there are dozens of them. run_in_executor is the pattern already
            # used in autonomy_routes, autopilot_routes and workspaces.
            _loop = asyncio.get_running_loop()
            value = await _loop.run_in_executor(None, _local_fn, args)
            ok = True
            if isinstance(value, dict) and "ok" in value:
                ok = bool(value["ok"])
            response = {"ok": ok, "tool": name, "value": value, "source": "local"}
            _log_and_cache(name, args, response)
            return response
        except Exception as e:
            import traceback as _tb
            return {"ok": False, "tool": name, "error": f"{type(e).__name__}: {e}",
                    "trace": _tb.format_exc()[:2000], "source": "local"}

    if name in _TOOL_NAME_MAP:
        # self.* tools run in-process (consciousness/health) — they must
        # work even when the PC actuator is down; that's exactly when a
        # health check matters most.
        if (not _TOOL_NAME_MAP[name].startswith("self.")) and not is_alive():
            return {"ok": False, "tool": name, "error": "actuator socket not alive", "source": "actuator"}
        result = execute_anthropic_tool(name, args)
        response = {"ok": bool(result.get("ok", False)), "tool": name, "value": result, "source": "actuator"}
        _log_and_cache(name, args, response)
        return response

    for try_name in (name, name.replace("_", ".", 1), name.replace("_", ".")):
        spec = None
        for s in describe_tools():
            if s["name"] == try_name:
                spec = s
                break
        if spec:
            result = call_tool(try_name, args)
            response = {"ok": result.ok, "tool": name, "value": result.value, "error": result.error, "source": "registry"}
            _log_and_cache(name, args, response)
            return response

    return {"ok": False, "tool": name, "error": f"unknown tool: {name}"}


# =============================================================================
# Agent: plan / runs / history
# =============================================================================

@router.post("/api/agent/plan")
async def agent_run_plan(req: dict):
    from brain.agent import plan_from_json
    if state.agent is None:
        return {"ok": False, "error": "Agent not initialized"}
    goal = req.get("goal", "")
    plan_raw = req.get("plan", [])
    if not isinstance(plan_raw, list) or not plan_raw:
        return {"ok": False, "error": "plan must be a non-empty list"}
    try:
        plan = plan_from_json(plan_raw)
    except Exception as e:
        return {"ok": False, "error": f"Invalid plan: {e}"}
    run = state.agent.run_plan(goal, plan)
    return run.to_dict()


@router.get("/api/agent/runs")
async def agent_recent_runs(limit: int = 20):
    if state.agent is None:
        return {"runs": []}
    return {"runs": state.agent.recent(limit=limit)}


@router.get("/api/agent/run/{run_id}")
async def agent_get_run(run_id: str):
    if state.agent is None:
        return {"ok": False, "error": "Agent not initialized"}
    run = state.agent.get_run(run_id)
    if run is None:
        return {"ok": False, "error": "run not found"}
    return run.to_dict()


@router.get("/api/agent/stats")
async def agent_stats_endpoint():
    if state.agent is None:
        return {"ok": False, "error": "Agent not initialized"}
    return state.agent.stats()


# ── Spawned sub-agents (the Agents tab in the dashboard) ─────────────

@router.get("/api/agents")
async def spawned_agents_list(limit: int = 40):
    """Every sub-agent Leon spawned, newest first. Powers the Agents tab."""
    try:
        from brain import agent_registry
        return agent_registry.list_agents(limit=limit)
    except Exception as e:
        return {"agents": [], "total": 0, "live_count": 0, "error": str(e)}


@router.get("/api/agents/{agent_id}")
async def spawned_agent_detail(agent_id: str):
    try:
        from brain import agent_registry
        rec = agent_registry.get_agent(agent_id)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    if rec is None:
        return {"ok": False, "error": "agent not found"}
    return {"ok": True, "agent": rec}


@router.get("/api/agents/{agent_id}/transcript")
async def spawned_agent_transcript(agent_id: str, since: int = 0):
    """The agent's FULL live transcript — what it is actually doing, in English.

    Powers the slide-out detail panel. `since` is a byte offset the client
    already has, so polling is incremental instead of re-sending the whole
    log every second: the client sends back the `next` it was given.
    """
    try:
        from brain import sub_agents
        from brain import agent_registry
    except Exception as e:
        return {"ok": False, "error": str(e)}

    try:
        rec = agent_registry.get_agent(agent_id)
    except Exception:
        rec = None

    full = sub_agents.read_transcript(agent_id)
    # `since` is an offset into the text we previously served. If the log was
    # truncated/rotated under us (since > len), fall back to sending it all
    # rather than silently returning nothing forever.
    if since and 0 < since <= len(full):
        chunk = full[since:]
    else:
        chunk = full
        since = 0

    return {
        "ok": True,
        "id": agent_id,
        "name": (rec or {}).get("name", ""),
        "status": (rec or {}).get("status", ""),
        "chunk": chunk,
        "next": len(full),
        "empty": not full,
    }


@router.post("/api/agents/clear")
async def spawned_agents_clear():
    try:
        from brain import agent_registry
        return {"ok": True, "removed": agent_registry.clear_finished()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@router.get("/api/agent/tool-history")
async def agent_tool_history(limit: int = 100):
    return {"history": tool_history(limit=limit)}
