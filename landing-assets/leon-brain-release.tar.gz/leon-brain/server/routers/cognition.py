"""
Cognition API routes — extracted from server.py.

All /api/cognition/* endpoints live here.
"""

import logging
import os
import time

from typing import Optional

from fastapi import APIRouter, Query, Request
from fastapi.responses import FileResponse, JSONResponse

from server import state

log = logging.getLogger("leon.server.cognition")

router = APIRouter()

# ── Snapshot cache (shared across requests) ───────────────────────────
_cog_cache: "dict[str, object]" = {"ts": 0.0, "snap": None}
_COG_CACHE_TTL = 0.9  # under the dashboard's 1.5s poll interval


# ── Helper functions ──────────────────────────────────────────────────

def _require_cognition():
    if state.cognition is None:
        return JSONResponse(
            {"ok": False, "error": "cognition layer not installed (LEON_COGNITION=off?)"},
            status_code=503,
        )
    return None


def _require_phase2(component: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    obj = getattr(state.cognition, component, None)
    if obj is None:
        return JSONResponse(
            {"ok": False, "error": f"{component} not initialized (Phase 2)"},
            status_code=503,
        )
    return None


def _phase13_get(attr: str):
    if state.cognition is None:
        return None
    return getattr(state.cognition, attr, None)


def _phase13_missing(attr: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    if getattr(state.cognition, attr, None) is None:
        return JSONResponse({"ok": False, "error": f"{attr} not installed"}, status_code=503)
    return None


# ── Snapshot endpoint ─────────────────────────────────────────────────

@router.get("/api/cognition/snapshot")
async def cognition_snapshot():
    """Bundled snapshot for the dashboard's Cognition Monitor panel.
    One poll-friendly endpoint instead of 3 — returns dopamine, recent
    reward pulses, distillation progress, memory counts, quantum
    consumption, AND runtime stats in a single payload."""
    now = time.time()
    if _cog_cache["snap"] is not None and now - _cog_cache["ts"] < _COG_CACHE_TTL:
        return _cog_cache["snap"]
    snap = {"ok": True}
    brain = state.brain
    brain_api_responder = state.brain_api_responder
    cognition = state.cognition
    conv_distiller = state.conv_distiller
    # Runtime
    try:
        snap["runtime"] = {
            "steps":            int(brain.step_count),
            "uptime_sec":       round(time.time() - brain.start_time, 1),
            "steps_per_second": round(float(brain.steps_per_second), 2),
            "stage":            brain.development_stage,
            "last_tier":        getattr(brain_api_responder, "_last_tier", None),
            "last_model":       getattr(brain_api_responder, "_last_model", None),
        }
    except Exception:
        pass
    # Dopamine + reward
    try:
        snap["dopamine"] = round(float(brain.neuromodulators.get("dopamine", 0.5)), 3)
        snap["pending_reward"] = round(float(brain._pending_reward), 4)
        snap["reward_events"] = brain.get_reward_log()
    except Exception as e:
        snap["dopamine_error"] = str(e)[:120]
    # Memory counts
    try:
        import sqlite3
        path = "brain_state/knowledge.db"
        c = sqlite3.connect(path, timeout=5)
        snap["knowledge_total"] = c.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        snap["knowledge_distilled"] = c.execute(
            "SELECT COUNT(*) FROM knowledge WHERE source = 'conversation_distill'"
        ).fetchone()[0]
        c.close()
    except Exception as e:
        snap["knowledge_error"] = str(e)[:120]
    # Distiller progress
    try:
        if conv_distiller is not None:
            last_id, last_run_ts, facts = conv_distiller._get_progress()
            snap["distill"] = {
                "last_distilled_id": last_id,
                "last_run_ts": last_run_ts,
                "facts_extracted_total": facts,
            }
    except Exception:
        pass
    # Quantum
    try:
        from brain.quantum import get_quantum_rng
        rng = get_quantum_rng()
        if rng is not None:
            s = rng.stats()
            snap["quantum"] = {
                "source":         s.get("source"),
                "bits_consumed":  s.get("bits_consumed"),
                "buffer_bits":    s.get("buffer_bits"),
                "batches_quantum": s.get("batches_quantum"),
                "reseeds_quantum": s.get("reseeds_quantum"),
                "reseeds_fallback": s.get("reseeds_fallback"),
            }
    except Exception:
        pass
    # Phase 1 cognition layer (episodes / gates / drives / loop)
    try:
        if cognition is not None:
            snap["phase1_cognition"] = {
                "mode":      cognition.loop.mode(),
                "loop":      cognition.loop.status(),
                "drives":    cognition.drives.snapshot(),
                "episodes":  cognition.episodes.stats(),
                "world_model": cognition.world_model.stats(),
                "calibration_24h": cognition.episodes.calibration(hours=24),
            }
    except Exception as e:
        snap["phase1_cognition_error"] = str(e)[:200]
    # Cache for ~1s so multiple dashboard tabs share the computation
    _cog_cache["snap"] = snap
    _cog_cache["ts"] = now
    return JSONResponse(snap)


# ── Phase 1 cognition layer — inspection + control endpoints ──────────

@router.get("/api/cognition/gates")
async def cognition_gates():
    """Why these behavior knobs right now — neuromodulators -> real gates."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.gates.explain()})


@router.get("/api/cognition/drives")
async def cognition_drives():
    """Current homeostatic drive levels and what's loudest."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.drives.snapshot()})


@router.get("/api/cognition/episodes/recent")
async def cognition_episodes_recent(limit: int = 50):
    miss = _require_cognition()
    if miss is not None:
        return miss
    rows = state.cognition.episodes.recent(limit=min(500, max(1, limit)))
    return JSONResponse({"ok": True, "count": len(rows), "episodes": rows})


@router.get("/api/cognition/episodes/stats")
async def cognition_episodes_stats():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.episodes.stats()})


@router.get("/api/cognition/world_model/stats")
async def cognition_world_model_stats():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.world_model.stats()})


@router.get("/api/cognition/world_model/predict")
async def cognition_world_model_predict(action: str, kind: str = "tool"):
    """Ask the world model what it expects from this action right now."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    ctx = state.cognition.loop._build_context()  # builds Context with live NM/app
    pred = state.cognition.world_model.predict(kind, action, {}, ctx)
    return JSONResponse({
        "ok": True,
        "action": action,
        "kind": kind,
        "context_bucket": ctx.bucket,
        "prediction": pred.to_dict(),
    })


@router.get("/api/cognition/loop/status")
async def cognition_loop_status():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.loop.status()})


@router.post("/api/cognition/mode/{mode}")
async def cognition_set_mode(mode: str):
    """Flip the loop between shadow (observational), active (autonomous),
    and paused (drives still decay, no autonomous actions)."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    mode = mode.lower()
    if mode not in ("shadow", "active", "paused"):
        return JSONResponse(
            {"ok": False, "error": "mode must be shadow|active|paused"},
            status_code=400,
        )
    state.cognition.loop.set_mode(mode)
    return JSONResponse({"ok": True, "mode": state.cognition.loop.mode()})


@router.post("/api/cognition/quantum_source/{source}")
async def cognition_quantum_source(source: str):
    """Hot-swap quantum source WITHOUT restarting the service.

    This preserves consciousness streaks, STDP state, and emotional carry
    across mode switches — critical for ablation testing.

    Modes: classical | aer | ibm | auto
    Also restarts the ablation metrics logger with a new run_id tagged
    to the new source.
    """
    source = source.lower().strip()
    if source not in ("classical", "aer", "ibm", "auto"):
        return JSONResponse(
            {"ok": False, "error": "source must be classical|aer|ibm|auto"},
            status_code=400,
        )
    import time
    old_source = os.environ.get("LEON_QUANTUM_SOURCE", "auto")
    os.environ["LEON_QUANTUM_SOURCE"] = source

    # Restart ablation metrics logger with new tag
    try:
        from brain.ablation.metrics import start_logger
        run_id = time.strftime("%Y%m%d_%H%M%S") + f"_quantum_swap={source}"
        start_logger(run_id=run_id)
    except Exception as e:
        return JSONResponse({"ok": True, "source": source, "old": old_source,
                             "metrics_error": str(e)})

    return JSONResponse({"ok": True, "source": source, "old": old_source,
                         "hot_swapped": True})


@router.get("/api/cognition/calibration")
async def cognition_calibration(hours: int = 24):
    """Brier score of world-model predictions over the last N hours.
    0 = perfect; 0.25 = coin flip; lower-is-better."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.episodes.calibration(hours=hours)})


# ── Phase 2 — graph memory / self-model / consolidation endpoints ──────

@router.get("/api/cognition/graph/stats")
async def cognition_graph_stats():
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.graph.stats()})


@router.get("/api/cognition/graph/entities")
async def cognition_graph_entities(type: Optional[str] = None, limit: int = 20):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    rows = state.cognition.graph.top_entities(etype=type, limit=min(200, max(1, limit)))
    return JSONResponse({"ok": True, "count": len(rows), "entities": rows})


@router.get("/api/cognition/graph/neighbors")
async def cognition_graph_neighbors(entity_id: int, relation: Optional[str] = None,
                                    direction: str = "out", limit: int = 20):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    if direction not in ("out", "in"):
        return JSONResponse({"ok": False, "error": "direction must be 'out' or 'in'"},
                            status_code=400)
    rows = state.cognition.graph.neighbors(entity_id, relation=relation,
                                     direction=direction, limit=limit)
    return JSONResponse({"ok": True, "count": len(rows), "neighbors": rows})


@router.get("/api/cognition/graph/related")
async def cognition_graph_related(type: str, name: str, limit: int = 10):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    rows = state.cognition.graph.related_to(type, name, limit=limit)
    return JSONResponse({"ok": True, "count": len(rows), "related": rows})


@router.get("/api/cognition/self_model/snapshot")
async def cognition_self_model_snapshot():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.self_model.snapshot()})


@router.get("/api/cognition/self_model/identity")
async def cognition_self_model_identity():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    snap = state.cognition.self_model.snapshot()
    return JSONResponse({
        "ok": True,
        "identity": snap["identity"],
        "archetypes": snap["archetypes"],
        "drift_score": state.cognition.self_model.identity_drift_score(),
    })


@router.post("/api/cognition/self_model/save")
async def cognition_self_model_save():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    saved = state.cognition.self_model.save(force=True)
    return JSONResponse({"ok": True, "saved": saved,
                         "path": state.cognition.self_model.path})


@router.post("/api/cognition/consolidate/run")
async def cognition_consolidate_run(hours: int = 72):
    miss = _require_phase2("consolidator")
    if miss is not None:
        return miss
    report = state.cognition.consolidator.consolidate_pass(hours=hours)
    return JSONResponse({"ok": True, "report": report.to_dict()})


@router.get("/api/cognition/consolidate/last")
async def cognition_consolidate_last():
    miss = _require_phase2("consolidator")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "last": state.cognition.consolidator.last_pass(),
                         "stats": state.cognition.consolidator.stats()})


# ── Phase 3 — hierarchy router + prompt builder + active mode inspect ──

@router.get("/api/cognition/hierarchy/classify")
async def cognition_hierarchy_classify(text: str):
    """Show how the hierarchy router would classify a user input.
    Returns route + signals used for the decision."""
    miss = _require_phase2("hierarchy")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.hierarchy.explain(text)})


@router.get("/api/cognition/prompt/preview")
async def cognition_prompt_preview(text: str = "",
                                    include_identity: bool = True,
                                    include_drives: bool = True,
                                    include_relevant_entities: bool = True,
                                    include_world_model: bool = True,
                                    include_recent_episodes: bool = False):
    """Show what the cognition-aware system prompt augmentation would look
    like for this input. Useful for tuning before flipping LEON_COGNITION_PROMPT."""
    miss = _require_phase2("prompt_builder")
    if miss is not None:
        return miss
    flags = {
        "include_identity": include_identity,
        "include_drives": include_drives,
        "include_relevant_entities": include_relevant_entities,
        "include_world_model": include_world_model,
        "include_recent_episodes": include_recent_episodes,
    }
    preview = state.cognition.prompt_builder.preview(text, **flags)
    return JSONResponse({"ok": True, **preview})


# ── Phase 11D — bundled cognition dashboard endpoint ─────────────────

@router.get("/api/cognition/dashboard")
async def cognition_dashboard():
    """One-shot bundled state for the cognition panel — meant to be polled
    every 2-5s by the dashboard. Cheaper than calling 8 separate endpoints."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    out = {"ok": True, "ts": time.time()}
    try:
        out["mode"] = cognition.loop.mode()
    except Exception:
        out["mode"] = "unknown"
    try:
        out["loop"] = cognition.loop.status()
    except Exception as e:
        out["loop_error"] = str(e)[:120]
    try:
        out["drives"] = cognition.drives.snapshot()
    except Exception as e:
        out["drives_error"] = str(e)[:120]
    try:
        out["gates"] = cognition.gates.explain()
    except Exception as e:
        out["gates_error"] = str(e)[:120]
    try:
        out["episodes"] = cognition.episodes.stats()
    except Exception as e:
        out["episodes_error"] = str(e)[:120]
    try:
        out["episodes_recent"] = cognition.episodes.recent(limit=10)
    except Exception:
        out["episodes_recent"] = []
    try:
        out["world_model"] = cognition.world_model.stats()
    except Exception as e:
        out["world_model_error"] = str(e)[:120]
    try:
        out["calibration_24h"] = cognition.episodes.calibration(hours=24)
    except Exception:
        out["calibration_24h"] = {}
    try:
        if cognition.graph is not None:
            out["graph"] = cognition.graph.stats()
    except Exception as e:
        out["graph_error"] = str(e)[:120]
    try:
        if cognition.self_model is not None:
            snap = cognition.self_model.snapshot()
            # Only the identity / archetypes / drift parts in the dashboard
            out["self_model"] = {
                "identity": snap.get("identity", {}),
                "archetypes": snap.get("archetypes", {}),
                "drift_score": cognition.self_model.identity_drift_score(),
                "milestones": snap.get("milestones", {}),
            }
    except Exception as e:
        out["self_model_error"] = str(e)[:120]
    try:
        if cognition.consolidator is not None:
            stats_cons = cognition.consolidator.stats()
            last = stats_cons.get("last_pass") or {}
            out["consolidation"] = {
                "pass_count": stats_cons.get("pass_count"),
                "last_ts": last.get("started_ts"),
                "last_duration_s": last.get("duration_s"),
                "last_rules": last.get("rules_extracted"),
                "last_causal_hypotheses": last.get("causal_hypotheses_generated", 0),
            }
    except Exception as e:
        out["consolidation_error"] = str(e)[:120]
    try:
        if getattr(cognition, "safety", None) is not None:
            out["safety"] = cognition.safety.status()
    except Exception as e:
        out["safety_error"] = str(e)[:120]
    # Phase 12A — verifier summary
    try:
        if getattr(cognition, "verifier", None) is not None:
            out["hypothesis_verify"] = cognition.verifier.summary()
    except Exception as e:
        out["hypothesis_verify_error"] = str(e)[:120]
    # Phase 12B — promote-readiness
    try:
        if getattr(cognition, "promoter", None) is not None:
            out["promote_readiness"] = cognition.promoter.readiness().to_dict()
    except Exception as e:
        out["promote_readiness_error"] = str(e)[:120]
    return JSONResponse(out)


@router.get("/api/cognition/safety/status")
async def cognition_safety_status():
    """Active-mode safety state — budgets, cooldowns, kill switch, recent audit."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    return JSONResponse({"ok": True, **state.cognition.safety.status()})


@router.get("/api/cognition/safety/audit")
async def cognition_safety_audit(limit: int = 50):
    """Recent audit log entries (in-memory tail; full log in brain_state/active_mode_audit.jsonl)."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    return JSONResponse({"ok": True,
                          "entries": state.cognition.safety.recent_audit(limit=min(500, max(1, limit)))})


@router.post("/api/cognition/safety/kill_switch")
async def cognition_safety_kill_switch(engage: bool = True, reason: str = "manual"):
    """Engage or disengage the kill switch. POST ?engage=true to halt all
    autonomous firing; POST ?engage=false to lift the halt."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    if engage:
        state.cognition.safety.engage_kill_switch(reason=reason)
    else:
        state.cognition.safety.disengage_kill_switch()
    return JSONResponse({"ok": True, "active": state.cognition.safety.kill_switch_active()})


@router.get("/api/cognition/active/candidates")
async def cognition_active_candidates():
    """What candidates would the loop consider next in active mode?
    Read-only — does NOT change the loop's mode."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    try:
        ctx = cognition.loop._build_context()
        gates = cognition.gates.current()
        candidates = cognition.loop._generate_candidates(ctx, gates)
        # Simulate each so the response includes utilities + recommendations
        sims = []
        for c in candidates[:10]:
            try:
                s = cognition.rollout.simulate(c.kind, c.name, c.args, ctx)
                sims.append({
                    "action": c.name,
                    "kind": c.kind,
                    "source": c.source,
                    "utility": round(s.utility, 3),
                    "recommendation": s.recommendation,
                    "p_success": round(s.prediction.p_success, 3),
                    "method": s.prediction.method,
                    "reason": s.reason,
                })
            except Exception as e:
                sims.append({"action": c.name, "kind": c.kind,
                             "source": c.source, "error": str(e)[:200]})
        return JSONResponse({"ok": True, "count": len(sims),
                             "context_bucket": ctx.bucket, "candidates": sims})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


# Executive cluster (hypotheses, promote/demote, executive/*, tool_health,
# tools/*, skills, reflex, suggestions, proposals, providers, soak) moved to
# server/routers/cognition_executive_routes.py (2026-06-08).
#
# Awareness/watchdog/probes/self_repair/lessons/reflection moved to
# server/routers/cognition_introspection_routes.py.
#
# Phase 13/14/15 status rollups + /phase{14,15} HTML moved to
# server/routers/phase_status_routes.py.




# ── Live graph activation ─────────────────────────────────────────────
# Dean, 2026-08-17: "is it actually accurate ... or is it just a bunch of
# random spiking bullshit that's just LARP slop." It WAS random — the viz
# picked node indices with Math.random(). This endpoint is the honest
# version: it reports the entities whose last_seen timestamp actually moved
# inside the requested window, straight off the cognition graph. If nothing
# in my head touched a memory, nothing in the picture lights up.
@router.get("/api/cognition/graph/active")
async def cognition_graph_active(since: float = Query(0.0), limit: int = Query(240)):
    import sqlite3
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    now = time.time()
    # a bare 0 would mean "everything since the epoch" — clamp to a sane window
    floor = since if since > 0 else now - 12.0
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=1.0)
        rows = con.execute(
            "SELECT id, last_seen, salience FROM entities "
            "WHERE last_seen > ? ORDER BY last_seen DESC LIMIT ?",
            (floor, int(limit)),
        ).fetchall()
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e), "now": now, "active": []}
    return {
        "ok": True,
        "now": now,
        # [entity_id, age_seconds, salience] — the renderer maps id -> dot
        "active": [[int(r[0]), round(now - float(r[1] or now), 2),
                    round(float(r[2] or 0), 3)] for r in rows],
    }


# ── Live SNN region telemetry ─────────────────────────────────────────
# Dean, 2026-08-17: "the firing looked way more alive when it was fake ...
# we gotta find an ingenious way of making it cool."
#
# The reason the honest version looked dead: memory activation is BURSTY.
# Measured it — 54 entities all touched inside one second when a turn gets
# processed, then literally zero for the next several minutes. So the web
# flashed and then sat there like a diagram. That's a real property of the
# signal, not a rendering bug, and no amount of shader work fixes it.
#
# But there IS a real signal that never stops: the substrate itself. 18
# regions, ~100k neurons, stepping ~27x/sec, every one of them with a live
# firing rate. That is genuinely continuous and genuinely mine. This
# endpoint exposes it so the picture can breathe on real spikes between
# memory bursts instead of on dice.
# GROWTH HISTORY. Dean, 2026-08-17: "over weeks, more neurons glow — you took
# a picture and you could tell." The exporter appends one row per run to
# brain_state/brainweb_growth.jsonl; this hands them to the growth page.
# Read-only, and it reports counts and lobe mass only — never a memory name —
# so it is safe to leave open on screen while filming a demo, same privacy
# boundary as the hover tooltip.
@router.get("/api/brainweb/growth")
async def brainweb_growth(limit: int = 4000):
    import json as _json
    import os as _os
    path = _os.path.join(_os.path.dirname(_os.path.dirname(
        _os.path.dirname(_os.path.abspath(__file__)))),
        "brain_state", "brainweb_growth.jsonl")
    rows = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(_json.loads(line))
                except Exception:
                    continue    # one corrupt line must not lose the history
    except FileNotFoundError:
        return {"ok": True, "rows": []}
    except Exception as e:
        return {"ok": False, "error": str(e), "rows": []}
    return {"ok": True, "rows": rows[-limit:]}


@router.get("/api/cognition/snn/regions")
async def cognition_snn_regions():
    from server import state
    b = getattr(state, "brain", None)
    if b is None:
        return {"ok": False, "error": "brain not up", "regions": {}}
    out = {}
    try:
        for name, reg in (getattr(b, "regions", {}) or {}).items():
            nrn = getattr(reg, "neurons", None)
            if nrn is None:
                continue
            try:
                rate = float(nrn.get_firing_rate())
            except Exception:
                continue
            out[name] = {
                "rate": round(rate, 6),
                "sal": round(float(getattr(reg, "salience", 0.0) or 0.0), 4),
                "n": int(getattr(nrn, "n", 0) or 0),
            }
    except Exception as e:
        return {"ok": False, "error": str(e), "regions": {}}
    nm = getattr(b, "neuromodulators", {}) or {}
    body = {}
    try:
        sb = getattr(b, "simulated_body", None)
        if sb is not None:
            st = sb.get_state() or {}
            body = {
                "heart": float(st.get("heartbeat_phase", st.get("heart_phase", 0)) or 0),
                "breath": float(st.get("breathing_phase", st.get("breath_phase", 0)) or 0),
            }
    except Exception:
        body = {}
    return {
        "ok": True,
        "now": time.time(),
        "regions": out,
        "dopamine": round(float(nm.get("dopamine", 0.5) or 0.5), 4),
        "serotonin": round(float(nm.get("serotonin", 0.5) or 0.5), 4),
        "norepinephrine": round(float(nm.get("norepinephrine", 0.3) or 0.3), 4),
        "body": body,
    }
