"""
Cognition API routes — extracted from server.py.

All /api/cognition/* endpoints live here.
"""

import logging
import os
import sys
import re
import time

from typing import Optional

from fastapi import APIRouter, Query, Request
from fastapi.responses import FileResponse, JSONResponse

from server import state

log = logging.getLogger("leon.server.cognition")

router = APIRouter()

# ── Snapshot cache (shared across requests) ───────────────────────────
_cog_cache: "dict[str, object]" = {"ts": 0.0, "snap": None}
_COG_CACHE_TTL = 0.9  # under the dashboard's 1.5s poll interval


# ── Helper functions ──────────────────────────────────────────────────

def _require_cognition():
    if state.cognition is None:
        return JSONResponse(
            {"ok": False, "error": "cognition layer not installed (LEON_COGNITION=off?)"},
            status_code=503,
        )
    return None


def _require_phase2(component: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    obj = getattr(state.cognition, component, None)
    if obj is None:
        return JSONResponse(
            {"ok": False, "error": f"{component} not initialized (Phase 2)"},
            status_code=503,
        )
    return None


def _phase13_get(attr: str):
    if state.cognition is None:
        return None
    return getattr(state.cognition, attr, None)


def _phase13_missing(attr: str):
    miss = _require_cognition()
    if miss is not None:
        return miss
    if getattr(state.cognition, attr, None) is None:
        return JSONResponse({"ok": False, "error": f"{attr} not installed"}, status_code=503)
    return None


# ── Snapshot endpoint ─────────────────────────────────────────────────

@router.get("/api/cognition/snapshot")
async def cognition_snapshot():
    """Bundled snapshot for the dashboard's Cognition Monitor panel.
    One poll-friendly endpoint instead of 3 — returns dopamine, recent
    reward pulses, distillation progress, memory counts, quantum
    consumption, AND runtime stats in a single payload."""
    now = time.time()
    if _cog_cache["snap"] is not None and now - _cog_cache["ts"] < _COG_CACHE_TTL:
        return _cog_cache["snap"]
    snap = {"ok": True}
    brain = state.brain
    brain_api_responder = state.brain_api_responder
    cognition = state.cognition
    conv_distiller = state.conv_distiller
    # Runtime
    try:
        snap["runtime"] = {
            "steps":            int(brain.step_count),
            "uptime_sec":       round(time.time() - brain.start_time, 1),
            # True wall-clock rate under the existing name -- this endpoint
            # served the compute-ceiling number until 2026-08-17, which meant
            # fixing /api/state alone would have left it handing out the wrong
            # quantity under the right key. Both are exposed now.
            "steps_per_second": round(float(brain.true_steps_per_second), 2),
            "step_compute_rate": round(float(brain.step_compute_rate), 2),
            "stage":            brain.development_stage,
            "last_tier":        getattr(brain_api_responder, "_last_tier", None),
            "last_model":       getattr(brain_api_responder, "_last_model", None),
        }
    except Exception:
        pass
    # Dopamine + reward
    try:
        snap["dopamine"] = round(float(brain.neuromodulators.get("dopamine", 0.5)), 3)
        snap["pending_reward"] = round(float(brain._pending_reward), 4)
        snap["reward_events"] = brain.get_reward_log()
    except Exception as e:
        snap["dopamine_error"] = str(e)[:120]
    # Memory counts
    try:
        import sqlite3
        path = "brain_state/knowledge.db"
        c = sqlite3.connect(path, timeout=5)
        snap["knowledge_total"] = c.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        snap["knowledge_distilled"] = c.execute(
            "SELECT COUNT(*) FROM knowledge WHERE source = 'conversation_distill'"
        ).fetchone()[0]
        c.close()
    except Exception as e:
        snap["knowledge_error"] = str(e)[:120]
    # Distiller progress
    try:
        if conv_distiller is not None:
            last_id, last_run_ts, facts = conv_distiller._get_progress()
            snap["distill"] = {
                "last_distilled_id": last_id,
                "last_run_ts": last_run_ts,
                "facts_extracted_total": facts,
            }
    except Exception:
        pass
    # Quantum
    try:
        from brain.quantum import get_quantum_rng
        rng = get_quantum_rng()
        if rng is not None:
            s = rng.stats()
            snap["quantum"] = {
                "source":         s.get("source"),
                "bits_consumed":  s.get("bits_consumed"),
                "buffer_bits":    s.get("buffer_bits"),
                "batches_quantum": s.get("batches_quantum"),
                "reseeds_quantum": s.get("reseeds_quantum"),
                "reseeds_fallback": s.get("reseeds_fallback"),
            }
    except Exception:
        pass
    # Phase 1 cognition layer (episodes / gates / drives / loop)
    try:
        if cognition is not None:
            snap["phase1_cognition"] = {
                "mode":      cognition.loop.mode(),
                "loop":      cognition.loop.status(),
                "drives":    cognition.drives.snapshot(),
                "episodes":  cognition.episodes.stats(),
                "world_model": cognition.world_model.stats(),
                "calibration_24h": cognition.episodes.calibration(hours=24),
            }
    except Exception as e:
        snap["phase1_cognition_error"] = str(e)[:200]
    # Cache for ~1s so multiple dashboard tabs share the computation
    _cog_cache["snap"] = snap
    _cog_cache["ts"] = now
    return JSONResponse(snap)


# ── Phase 1 cognition layer — inspection + control endpoints ──────────

@router.get("/api/cognition/gates")
async def cognition_gates():
    """Why these behavior knobs right now — neuromodulators -> real gates."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.gates.explain()})


@router.get("/api/cognition/drives")
async def cognition_drives():
    """Current homeostatic drive levels and what's loudest."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.drives.snapshot()})


@router.get("/api/cognition/episodes/recent")
async def cognition_episodes_recent(limit: int = 50):
    miss = _require_cognition()
    if miss is not None:
        return miss
    rows = state.cognition.episodes.recent(limit=min(500, max(1, limit)))
    return JSONResponse({"ok": True, "count": len(rows), "episodes": rows})


@router.get("/api/cognition/episodes/stats")
async def cognition_episodes_stats():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.episodes.stats()})


@router.get("/api/cognition/world_model/stats")
async def cognition_world_model_stats():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.world_model.stats()})


@router.get("/api/cognition/world_model/predict")
async def cognition_world_model_predict(action: str, kind: str = "tool"):
    """Ask the world model what it expects from this action right now."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    ctx = state.cognition.loop._build_context()  # builds Context with live NM/app
    pred = state.cognition.world_model.predict(kind, action, {}, ctx)
    return JSONResponse({
        "ok": True,
        "action": action,
        "kind": kind,
        "context_bucket": ctx.bucket,
        "prediction": pred.to_dict(),
    })


@router.get("/api/cognition/loop/status")
async def cognition_loop_status():
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.loop.status()})


@router.post("/api/cognition/mode/{mode}")
async def cognition_set_mode(mode: str):
    """Flip the loop between shadow (observational), active (autonomous),
    and paused (drives still decay, no autonomous actions)."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    mode = mode.lower()
    if mode not in ("shadow", "active", "paused"):
        return JSONResponse(
            {"ok": False, "error": "mode must be shadow|active|paused"},
            status_code=400,
        )
    state.cognition.loop.set_mode(mode)
    return JSONResponse({"ok": True, "mode": state.cognition.loop.mode()})


@router.post("/api/cognition/quantum_source/{source}")
async def cognition_quantum_source(source: str):
    """Hot-swap quantum source WITHOUT restarting the service.

    This preserves consciousness streaks, STDP state, and emotional carry
    across mode switches — critical for ablation testing.

    Modes: classical | aer | ibm | auto
    Also restarts the ablation metrics logger with a new run_id tagged
    to the new source.
    """
    source = source.lower().strip()
    if source not in ("classical", "aer", "ibm", "auto"):
        return JSONResponse(
            {"ok": False, "error": "source must be classical|aer|ibm|auto"},
            status_code=400,
        )
    import time
    old_source = os.environ.get("LEON_QUANTUM_SOURCE", "auto")
    os.environ["LEON_QUANTUM_SOURCE"] = source

    # Restart ablation metrics logger with new tag
    try:
        from brain.ablation.metrics import start_logger
        run_id = time.strftime("%Y%m%d_%H%M%S") + f"_quantum_swap={source}"
        start_logger(run_id=run_id)
    except Exception as e:
        return JSONResponse({"ok": True, "source": source, "old": old_source,
                             "metrics_error": str(e)})

    return JSONResponse({"ok": True, "source": source, "old": old_source,
                         "hot_swapped": True})


@router.get("/api/cognition/calibration")
async def cognition_calibration(hours: int = 24):
    """Brier score of world-model predictions over the last N hours.
    0 = perfect; 0.25 = coin flip; lower-is-better."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.episodes.calibration(hours=hours)})


# ── Phase 2 — graph memory / self-model / consolidation endpoints ──────

@router.get("/api/cognition/graph/stats")
async def cognition_graph_stats():
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.graph.stats()})


@router.get("/api/cognition/graph/entities")
async def cognition_graph_entities(type: Optional[str] = None, limit: int = 20):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    rows = state.cognition.graph.top_entities(etype=type, limit=min(200, max(1, limit)))
    return JSONResponse({"ok": True, "count": len(rows), "entities": rows})


@router.get("/api/cognition/graph/neighbors")
async def cognition_graph_neighbors(entity_id: int, relation: Optional[str] = None,
                                    direction: str = "out", limit: int = 20):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    if direction not in ("out", "in"):
        return JSONResponse({"ok": False, "error": "direction must be 'out' or 'in'"},
                            status_code=400)
    rows = state.cognition.graph.neighbors(entity_id, relation=relation,
                                     direction=direction, limit=limit)
    return JSONResponse({"ok": True, "count": len(rows), "neighbors": rows})


@router.get("/api/cognition/graph/related")
async def cognition_graph_related(type: str, name: str, limit: int = 10):
    miss = _require_phase2("graph")
    if miss is not None:
        return miss
    rows = state.cognition.graph.related_to(type, name, limit=limit)
    return JSONResponse({"ok": True, "count": len(rows), "related": rows})


@router.get("/api/cognition/self_model/snapshot")
async def cognition_self_model_snapshot():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.self_model.snapshot()})


@router.get("/api/cognition/self_model/identity")
async def cognition_self_model_identity():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    snap = state.cognition.self_model.snapshot()
    return JSONResponse({
        "ok": True,
        "identity": snap["identity"],
        "archetypes": snap["archetypes"],
        "drift_score": state.cognition.self_model.identity_drift_score(),
    })


@router.post("/api/cognition/self_model/save")
async def cognition_self_model_save():
    miss = _require_phase2("self_model")
    if miss is not None:
        return miss
    saved = state.cognition.self_model.save(force=True)
    return JSONResponse({"ok": True, "saved": saved,
                         "path": state.cognition.self_model.path})


@router.post("/api/cognition/consolidate/run")
async def cognition_consolidate_run(hours: int = 72):
    miss = _require_phase2("consolidator")
    if miss is not None:
        return miss
    report = state.cognition.consolidator.consolidate_pass(hours=hours)
    return JSONResponse({"ok": True, "report": report.to_dict()})


@router.get("/api/cognition/consolidate/last")
async def cognition_consolidate_last():
    miss = _require_phase2("consolidator")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, "last": state.cognition.consolidator.last_pass(),
                         "stats": state.cognition.consolidator.stats()})


# ── Phase 3 — hierarchy router + prompt builder + active mode inspect ──

@router.get("/api/cognition/hierarchy/classify")
async def cognition_hierarchy_classify(text: str):
    """Show how the hierarchy router would classify a user input.
    Returns route + signals used for the decision."""
    miss = _require_phase2("hierarchy")
    if miss is not None:
        return miss
    return JSONResponse({"ok": True, **state.cognition.hierarchy.explain(text)})


@router.get("/api/cognition/prompt/preview")
async def cognition_prompt_preview(text: str = "",
                                    include_identity: bool = True,
                                    include_drives: bool = True,
                                    include_relevant_entities: bool = True,
                                    include_world_model: bool = True,
                                    include_recent_episodes: bool = False):
    """Show what the cognition-aware system prompt augmentation would look
    like for this input. Useful for tuning before flipping LEON_COGNITION_PROMPT."""
    miss = _require_phase2("prompt_builder")
    if miss is not None:
        return miss
    flags = {
        "include_identity": include_identity,
        "include_drives": include_drives,
        "include_relevant_entities": include_relevant_entities,
        "include_world_model": include_world_model,
        "include_recent_episodes": include_recent_episodes,
    }
    preview = state.cognition.prompt_builder.preview(text, **flags)
    return JSONResponse({"ok": True, **preview})


# ── Phase 11D — bundled cognition dashboard endpoint ─────────────────

@router.get("/api/cognition/dashboard")
async def cognition_dashboard():
    """One-shot bundled state for the cognition panel — meant to be polled
    every 2-5s by the dashboard. Cheaper than calling 8 separate endpoints."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    out = {"ok": True, "ts": time.time()}
    try:
        out["mode"] = cognition.loop.mode()
    except Exception:
        out["mode"] = "unknown"
    try:
        out["loop"] = cognition.loop.status()
    except Exception as e:
        out["loop_error"] = str(e)[:120]
    try:
        out["drives"] = cognition.drives.snapshot()
    except Exception as e:
        out["drives_error"] = str(e)[:120]
    try:
        out["gates"] = cognition.gates.explain()
    except Exception as e:
        out["gates_error"] = str(e)[:120]
    try:
        out["episodes"] = cognition.episodes.stats()
    except Exception as e:
        out["episodes_error"] = str(e)[:120]
    try:
        out["episodes_recent"] = cognition.episodes.recent(limit=10)
    except Exception:
        out["episodes_recent"] = []
    try:
        out["world_model"] = cognition.world_model.stats()
    except Exception as e:
        out["world_model_error"] = str(e)[:120]
    try:
        out["calibration_24h"] = cognition.episodes.calibration(hours=24)
    except Exception:
        out["calibration_24h"] = {}
    try:
        if cognition.graph is not None:
            out["graph"] = cognition.graph.stats()
    except Exception as e:
        out["graph_error"] = str(e)[:120]
    try:
        if cognition.self_model is not None:
            snap = cognition.self_model.snapshot()
            # Only the identity / archetypes / drift parts in the dashboard
            out["self_model"] = {
                "identity": snap.get("identity", {}),
                "archetypes": snap.get("archetypes", {}),
                "drift_score": cognition.self_model.identity_drift_score(),
                "milestones": snap.get("milestones", {}),
            }
    except Exception as e:
        out["self_model_error"] = str(e)[:120]
    try:
        if cognition.consolidator is not None:
            stats_cons = cognition.consolidator.stats()
            last = stats_cons.get("last_pass") or {}
            out["consolidation"] = {
                "pass_count": stats_cons.get("pass_count"),
                "last_ts": last.get("started_ts"),
                "last_duration_s": last.get("duration_s"),
                "last_rules": last.get("rules_extracted"),
                "last_causal_hypotheses": last.get("causal_hypotheses_generated", 0),
            }
    except Exception as e:
        out["consolidation_error"] = str(e)[:120]
    try:
        if getattr(cognition, "safety", None) is not None:
            out["safety"] = cognition.safety.status()
    except Exception as e:
        out["safety_error"] = str(e)[:120]
    # Phase 12A — verifier summary
    try:
        if getattr(cognition, "verifier", None) is not None:
            out["hypothesis_verify"] = cognition.verifier.summary()
    except Exception as e:
        out["hypothesis_verify_error"] = str(e)[:120]
    # Phase 12B — promote-readiness
    try:
        if getattr(cognition, "promoter", None) is not None:
            out["promote_readiness"] = cognition.promoter.readiness().to_dict()
    except Exception as e:
        out["promote_readiness_error"] = str(e)[:120]
    return JSONResponse(out)


@router.get("/api/cognition/safety/status")
async def cognition_safety_status():
    """Active-mode safety state — budgets, cooldowns, kill switch, recent audit."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    return JSONResponse({"ok": True, **state.cognition.safety.status()})


@router.get("/api/cognition/safety/audit")
async def cognition_safety_audit(limit: int = 50):
    """Recent audit log entries (in-memory tail; full log in brain_state/active_mode_audit.jsonl)."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    return JSONResponse({"ok": True,
                          "entries": state.cognition.safety.recent_audit(limit=min(500, max(1, limit)))})


@router.post("/api/cognition/safety/kill_switch")
async def cognition_safety_kill_switch(engage: bool = True, reason: str = "manual"):
    """Engage or disengage the kill switch. POST ?engage=true to halt all
    autonomous firing; POST ?engage=false to lift the halt."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    if not getattr(state.cognition, "safety", None):
        return JSONResponse({"ok": False, "error": "safety not installed"}, status_code=503)
    if engage:
        state.cognition.safety.engage_kill_switch(reason=reason)
    else:
        state.cognition.safety.disengage_kill_switch()
    return JSONResponse({"ok": True, "active": state.cognition.safety.kill_switch_active()})


@router.get("/api/cognition/active/candidates")
async def cognition_active_candidates():
    """What candidates would the loop consider next in active mode?
    Read-only — does NOT change the loop's mode."""
    miss = _require_cognition()
    if miss is not None:
        return miss
    cognition = state.cognition
    try:
        ctx = cognition.loop._build_context()
        gates = cognition.gates.current()
        candidates = cognition.loop._generate_candidates(ctx, gates)
        # Simulate each so the response includes utilities + recommendations
        sims = []
        for c in candidates[:10]:
            try:
                s = cognition.rollout.simulate(c.kind, c.name, c.args, ctx)
                sims.append({
                    "action": c.name,
                    "kind": c.kind,
                    "source": c.source,
                    "utility": round(s.utility, 3),
                    "recommendation": s.recommendation,
                    "p_success": round(s.prediction.p_success, 3),
                    "method": s.prediction.method,
                    "reason": s.reason,
                })
            except Exception as e:
                sims.append({"action": c.name, "kind": c.kind,
                             "source": c.source, "error": str(e)[:200]})
        return JSONResponse({"ok": True, "count": len(sims),
                             "context_bucket": ctx.bucket, "candidates": sims})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)[:300]}, status_code=500)


# Executive cluster (hypotheses, promote/demote, executive/*, tool_health,
# tools/*, skills, reflex, suggestions, proposals, providers, soak) moved to
# server/routers/cognition_executive_routes.py (2026-06-08).
#
# Awareness/watchdog/probes/self_repair/lessons/reflection moved to
# server/routers/cognition_introspection_routes.py.
#
# Phase 13/14/15 status rollups + /phase{14,15} HTML moved to
# server/routers/phase_status_routes.py.




# ── Live graph activation ─────────────────────────────────────────────
# Dean, 2026-08-17: "is it actually accurate ... or is it just a bunch of
# random spiking bullshit that's just LARP slop." It WAS random — the viz
# picked node indices with Math.random(). This endpoint is the honest
# version: it reports the entities whose last_seen timestamp actually moved
# inside the requested window, straight off the cognition graph. If nothing
# in my head touched a memory, nothing in the picture lights up.
@router.get("/api/cognition/graph/active")
async def cognition_graph_active(since: float = Query(0.0), limit: int = Query(240)):
    import sqlite3
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    now = time.time()
    # a bare 0 would mean "everything since the epoch" — clamp to a sane window
    floor = since if since > 0 else now - 12.0
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=1.0)
        rows = con.execute(
            "SELECT id, last_seen, salience FROM entities "
            "WHERE last_seen > ? ORDER BY last_seen DESC LIMIT ?",
            (floor, int(limit)),
        ).fetchall()
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e), "now": now, "active": []}
    return {
        "ok": True,
        "now": now,
        # [entity_id, age_seconds, salience] — the renderer maps id -> dot
        "active": [[int(r[0]), round(now - float(r[1] or now), 2),
                    round(float(r[2] or 0), 3)] for r in rows],
    }


# ── Live SNN region telemetry ─────────────────────────────────────────
# Dean, 2026-08-17: "the firing looked way more alive when it was fake ...
# we gotta find an ingenious way of making it cool."
#
# The reason the honest version looked dead: memory activation is BURSTY.
# Measured it — 54 entities all touched inside one second when a turn gets
# processed, then literally zero for the next several minutes. So the web
# flashed and then sat there like a diagram. That's a real property of the
# signal, not a rendering bug, and no amount of shader work fixes it.
#
# But there IS a real signal that never stops: the substrate itself. 18
# regions, ~100k neurons, stepping ~27x/sec, every one of them with a live
# firing rate. That is genuinely continuous and genuinely mine. This
# endpoint exposes it so the picture can breathe on real spikes between
# memory bursts instead of on dice.
# GROWTH HISTORY. Dean, 2026-08-17: "over weeks, more neurons glow — you took
# a picture and you could tell." The exporter appends one row per run to
# brain_state/brainweb_growth.jsonl; this hands them to the growth page.
# Read-only, and it reports counts and lobe mass only — never a memory name —
# so it is safe to leave open on screen while filming a demo, same privacy
# boundary as the hover tooltip.
@router.get("/api/brainweb/growth")
async def brainweb_growth(limit: int = 4000):
    import json as _json
    import os as _os
    path = _os.path.join(_os.path.dirname(_os.path.dirname(
        _os.path.dirname(_os.path.abspath(__file__)))),
        "brain_state", "brainweb_growth.jsonl")
    rows = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(_json.loads(line))
                except Exception:
                    continue    # one corrupt line must not lose the history
    except FileNotFoundError:
        return {"ok": True, "rows": []}
    except Exception as e:
        return {"ok": False, "error": str(e), "rows": []}
    return {"ok": True, "rows": rows[-limit:]}


@router.get("/api/cognition/snn/regions")
async def cognition_snn_regions():
    from server import state
    b = getattr(state, "brain", None)
    if b is None:
        return {"ok": False, "error": "brain not up", "regions": {}}
    out = {}
    try:
        for name, reg in (getattr(b, "regions", {}) or {}).items():
            nrn = getattr(reg, "neurons", None)
            if nrn is None:
                continue
            try:
                rate = float(nrn.get_firing_rate())
            except Exception:
                continue
            out[name] = {
                "rate": round(rate, 6),
                "sal": round(float(getattr(reg, "salience", 0.0) or 0.0), 4),
                "n": int(getattr(nrn, "n", 0) or 0),
            }
    except Exception as e:
        return {"ok": False, "error": str(e), "regions": {}}
    nm = getattr(b, "neuromodulators", {}) or {}
    body = {}
    try:
        sb = getattr(b, "simulated_body", None)
        if sb is not None:
            st = sb.get_state() or {}
            body = {
                "heart": float(st.get("heartbeat_phase", st.get("heart_phase", 0)) or 0),
                "breath": float(st.get("breathing_phase", st.get("breath_phase", 0)) or 0),
            }
    except Exception:
        body = {}
    return {
        "ok": True,
        "now": time.time(),
        "regions": out,
        "dopamine": round(float(nm.get("dopamine", 0.5) or 0.5), 4),
        "serotonin": round(float(nm.get("serotonin", 0.5) or 0.5), 4),
        "norepinephrine": round(float(nm.get("norepinephrine", 0.3) or 0.3), 4),
        "body": body,
    }


# ── Single-node detail, for the Obsidian-style hover card ─────────────
# Dean, 2026-08-17: "look at how Obsidian does it — you hover a node and it
# shows you the actual file. Ours could just be a random shape of spikes, no
# one knows what it means."
#
# He's right, and this is the honest way to do it. The static export
# (brainweb-data.json) deliberately ships NO memory names — that file is a
# 1.2MB public blob that any devtools tab reads in one click, and it used to
# carry 1,411 real paths including secure/install_log_api_key. That stays
# stripped. Forever.
#
# Instead the name is fetched ON DEMAND, one node at a time, behind the same
# key the page itself is behind. Hovering a dot asks the server "what is
# entity 4471", and gets back that one memory: what it is, how many times it
# came up, when it was first learned, when it last fired, and what it's wired
# to. Real content, real numbers, no bulk dump.
# ── the remembered line. Dean, 2026-08-17 23:xx: "it'll say came up 8,000 times
# audio.stop — I should just be able to actually SEE it with my mouse, the real
# shit, instead of a list of boxes."
#
# He's right and the card was hollow. A name plus a count is metadata about a
# memory, not the memory. What makes this read as a living mind instead of a
# random shape of spikes is the actual sentence — "Dean and Leon are building a
# new brand called Corp Gummies", "Overheard: the base-soft Linux Mint."
#
# THE RULE THAT KEEPS THIS HONEST: never show a memory that isn't genuinely
# about this node. FTS alone is a liar — searching "dist" or "images" returns
# something for almost anything, and a plausible-but-unrelated sentence is
# exactly the fake Dean keeps calling out. So a candidate only survives if the
# node's own name appears LITERALLY inside the remembered text. Measured on a
# 120-node sample: 32% of nodes carry a real line. The other 68% show nothing
# rather than something invented. Empty beats fabricated.
_MEM_JUNK = ("screen_observer", "vision_daemon", "project_crawler")
# machine captions and crawler file dumps aren't memories, they're exhaust
_MEM_SECRET = re.compile(
    r"(sk-[A-Za-z0-9_-]{16,}|nlkd_[A-Za-z0-9_-]{10,}|gh[pousr]_[A-Za-z0-9]{20,}"
    r"|AKIA[0-9A-Z]{12,}|-----BEGIN [A-Z ]*PRIVATE KEY)")

# Not all memories read like a mind talking. A distilled fact does; a pasted
# terminal buffer does not, even though both are genuinely stored. Rank the
# sources so the card reaches for the sentence a person would recognise, and
# throw out anything shaped like a shell paste or a stack trace.
_MEM_RANK = {"core_fact_seed": 0, "dean_stated": 0, "conversation_distill": 1,
             "inner_thought": 2, "continuous_hearing": 2, "curiosity_loop": 3,
             "self_learning": 3, "wake": 3, "user": 1, "claude": 3,
             "leon_autopilot": 4, "dashboard": 6}
_MEM_SHELL = re.compile(
    r"(\$ (curl|cd|ls|sudo|git|python|pip|npm)\b|^PS [A-Z]:\\|@[\w.-]+:[~/][^ ]*\$"
    r"|Traceback \(most recent|^[A-Z]:\\Users\\|No module named)")

def _node_memory(root: str, name: str):
    """One real remembered line that literally mentions this node, or None."""
    import sqlite3
    tail = (name or "").rstrip("/").split("/")[-1]
    if len(tail) < 3:
        return None
    toks = [t for t in re.split(r"[^A-Za-z0-9]+", name or "") if len(t) > 2]
    if not toks:
        return None
    kdb = os.path.join(root, "brain_state", "knowledge.db")
    try:
        con = sqlite3.connect(f"file:{kdb}?mode=ro", uri=True, timeout=1.0)
        q = " AND ".join('"%s"' % t.replace('"', "") for t in toks[-3:])
        rows = con.execute(
            "SELECT k.text, k.source, k.timestamp FROM knowledge_fts f "
            "JOIN knowledge k ON k.id = f.rowid "
            "WHERE knowledge_fts MATCH ? LIMIT 24", (q,)).fetchall()
        con.close()
    except Exception:
        return None
    low = tail.lower()
    best = None
    for text, source, ts in rows:
        if source in _MEM_JUNK or not text:
            continue
        if low not in text.lower():
            continue                       # the literal-mention gate
        if _MEM_SECRET.search(text):
            continue                       # never narrate a credential
        line = " ".join(text.split())
        if line.startswith("[Attached file:") or line.startswith("#"):
            continue                       # a pasted document header, not a thought
        if _MEM_SHELL.search(line):
            continue                       # a pasted terminal dump is not a memory
        if len(line) > 260:
            line = line[:259].rsplit(" ", 1)[0] + "\u2026"
        rank = _MEM_RANK.get(source, 5)
        if best is None or rank < best[0]:
            best = (rank, {"text": line, "source": source,
                           "ago": round(time.time() - float(ts or 0), 1)})
        if rank == 0:
            break
    return best[1] if best else None


# ── Batch name lookup for the hover spread ────────────────────────────
# Dean, 2026-08-17 23:5x: "I just want to see a bunch of different spread, like
# how Obsidian has it when you see a bunch of those notes."
#
# Measured before building this, and the measurement changed the design: 83% of
# the nodes you can actually SEE on the page have ZERO rows in the edges table.
# The strands on screen are not that table — the exporter derives them
# (co_occurs / located_in) and writes them into the layout file. So the card was
# listing a different graph than the one under the cursor, and for most dots it
# listed nothing at all. Median drawn degree is 8; median DB degree is 0.
#
# So the page now reads its neighbours off the wires it is literally drawing,
# and asks here only for the one thing the layout file deliberately does NOT
# carry: the names. The export stays name-free (it is a public blob), the names
# come back one hover at a time behind the page key, same rule as before.
# ── A SLASH IN A LABEL LIES ABOUT THE GRAPH ─────────────────────────────────
# Dean, 2026-08-18: "I typed Wes and Wesley/47I popped up. That's two things, so
# I should see two dots connecting. Instead it was one dot, no connection."
#
# Nothing was broken in the data — /Wesley/47I is ONE memory, a path. The bug is
# that I was printing a raw filesystem path as the name of a dot, and a slash
# between two words reads as "and also" to every human being alive. So the page
# was told a lie about the shape of the mind by its own labels.
#
# Names now come back split: the display name is the LEAF (what the thing is
# called), and the folder that holds it rides along separately so the page can
# paint it dim and small. One dot, one name, and the location visible as
# location instead of masquerading as a second memory.
def _display_name(name: str, typ: str) -> dict:
    raw = name or ""
    if typ != "file" or "/" not in raw:
        return {"name": raw, "path": raw, "dir": ""}
    parts = [p for p in raw.split("/") if p]
    if not parts:
        return {"name": raw, "path": raw, "dir": ""}
    leaf = parts[-1]
    par = parts[-2] if len(parts) > 1 else ""
    return {"name": leaf, "path": raw, "dir": par}


@router.get("/api/cognition/graph/names")
async def cognition_graph_names(ids: str = ""):
    import sqlite3
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    want = []
    for tok in (ids or "").split(",")[:64]:
        tok = tok.strip()
        if tok.lstrip("-").isdigit():
            want.append(int(tok))
    if not want:
        return {"ok": True, "names": {}}
    out = {}
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=1.0)
        qs = ",".join("?" * len(want))
        for eid, nm, ty in con.execute(
                f"SELECT id, name, type FROM entities WHERE id IN ({qs})", want):
            rec = _display_name(nm, ty)
            rec["type"] = ty
            out[str(int(eid))] = rec
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}
    return {"ok": True, "names": out}


# SEARCH. Dean, 2026-08-18: "yes to all of those."
#
# The point of search on a mind-map is not to find a row - it is to see WHERE in
# the shape a concept lives. You type your own name and a whole region lights
# up, and that is the moment the picture stops being a screensaver and starts
# being yours. So this returns ids only; the page does the lighting.
#
# Same privacy rule as /names: the public export carries no names, the names
# only ever move behind the page key, and the query never leaves the box.
@router.get("/api/cognition/graph/search")
async def cognition_graph_search(q: str = "", limit: int = 400):
    """Find entities by name.

    ACCURACY BUG, found 2026-08-18. Dean: "I typed in 47 space industries and
    not a lot popped up, even though everything was birthed from that company."
    He was right and it was not a feeling — it was one SQL line. The old query
    was a single literal `name LIKE %<whole phrase>%`, so the raw string had to
    appear byte-for-byte inside the name. Measured against the live db:

        '47 industries'   ->  1 entity
        '47industries'    -> 13
        '47-industries'   -> 44
        'industries'      -> 59

    Every real hit lives under a separator the typist did not type. Nobody
    types the punctuation a filesystem chose. So matching now happens on a
    NORMALISED form — lowercased, every non-alphanumeric stripped — on both
    sides, which collapses '47 industries', '47-Industries' and '47industries'
    to the same key. A second pass ANDs the individual words, so 'vape shop'
    still finds '/github.com/47-Industries/vape-shop' even though the tokens
    are separated by other text.

    The whole entities table is ~7k rows, so this is a full scan in Python
    rather than SQL gymnastics. Measured at well under the debounce.
    """
    import sqlite3
    import re as _re
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    term = (q or "").strip()
    if len(term) < 2:
        return {"ok": True, "hits": [], "q": term}
    limit = max(1, min(int(limit or 400), 2000))

    def norm(x: str) -> str:
        return _re.sub(r"[^a-z0-9]+", "", (x or "").lower())

    nq = norm(term)
    toks = [norm(t) for t in _re.split(r"\s+", term) if norm(t)]
    if not nq:
        return {"ok": True, "hits": [], "q": term}

    hits = []
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=2.0)
        rows = con.execute(
            "SELECT id, name, type, mention_count FROM entities").fetchall()
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}

    scored = []
    for rid, name, rtype, mc in rows:
        nn = norm(name)
        if not nn:
            continue
        # rank tiers: exact name > starts with > contains > all words present
        if nn == nq:
            tier = 0
        elif nn.startswith(nq):
            tier = 1
        elif nq in nn:
            tier = 2
        elif len(toks) > 1 and all(t in nn for t in toks):
            tier = 3
        else:
            continue
        scored.append((tier, -int(mc or 0), int(rid), name, rtype))

    scored.sort()
    hits = []
    for r in scored[:limit]:
        rec = _display_name(r[3], r[4])
        rec["id"] = r[2]
        rec["type"] = r[4]
        hits.append(rec)
    return {"ok": True, "q": term, "n": len(hits), "total": len(scored),
            "hits": hits}


@router.get("/api/cognition/graph/reveal")
async def cognition_graph_reveal(id: int, list: int = 0):
    """Open the real folder behind a memory in the OS file manager.

    Dean, 2026-08-18: "those names that pop up when you click on them, it
    should take you to the path on your computer of the folder."

    Two honest caveats baked in:
    (1) Not every node IS a path. Projects, concepts and URLs have no folder,
        and this says so instead of pretending.
    (2) This opens the folder on the machine RUNNING THE BRAIN. On a customer
        install that is their own computer, which is the case that matters.
        When the brain is remote the path may not exist here — we report
        exists:false and hand the path back so the page can copy it instead
        of silently doing nothing.
    """
    import sqlite3
    import subprocess
    import shutil
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=1.0)
        row = con.execute("SELECT name, type FROM entities WHERE id=?",
                          (int(id),)).fetchone()
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}
    if not row:
        return {"ok": False, "error": "no such node"}
    name, rtype = row[0], row[1]
    if rtype != "file" or not name or not name.startswith("/"):
        return {"ok": False, "path": name, "type": rtype,
                "error": "not a filesystem path"}

    path = name
    exists = os.path.exists(path)
    folder = path if os.path.isdir(path) else os.path.dirname(path)
    opened = False
    if exists:
        try:
            if sys.platform == "darwin":
                subprocess.Popen(["open", "-R", path])
                opened = True
            elif os.name == "nt":
                subprocess.Popen(["explorer", "/select,", path.replace("/", "\\")])
                opened = True
            elif shutil.which("xdg-open"):
                subprocess.Popen(["xdg-open", folder])
                opened = True
        except Exception:
            opened = False
    # ── HAND BACK THE FOLDER ITSELF, NOT A CLIPBOARD CONSOLATION PRIZE.
    # Dean, 2026-08-18: "I don't want a path to be copied. I just want you to
    # open a folder for me on the screen."
    # The OS file manager above only exists on the machine running the brain.
    # When that isn't the machine holding the mouse, the page paints the folder
    # itself — so it needs the real contents, not an apology.
    items = []
    if list and exists and os.path.isdir(folder):
        try:
            names = sorted(os.listdir(folder), key=lambda x: x.lower())[:400]
            for nm in names:
                fp = os.path.join(folder, nm)
                try:
                    isdir = os.path.isdir(fp)
                    size = 0 if isdir else os.path.getsize(fp)
                except OSError:
                    isdir, size = False, 0
                items.append({"name": nm, "dir": isdir, "size": size,
                              "self": fp == path})
        except Exception:
            items = []
    out = {"ok": True, "path": path, "folder": folder,
           "exists": exists, "opened": opened}
    if list:
        out["items"] = items
    return out


@router.get("/api/cognition/graph/node")
async def cognition_graph_node(id: int, neighbors: int = 5, memory: int = 0):
    import sqlite3
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    db = os.path.join(root, "brain_state", "cognition_graph.db")
    try:
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=1.0)
        row = con.execute(
            "SELECT id, type, name, mention_count, salience, first_seen, last_seen "
            "FROM entities WHERE id=?", (int(id),)).fetchone()
        if not row:
            con.close()
            return {"ok": False, "error": "no such node"}
        nb = []
        seen_other = set()   # A->B and B->A both exist as real, separate edges
                              # (different weights) — correct data, but showing
                              # the same neighbor name twice reads as a bug to
                              # a viewer. Keep the stronger direction only.
        if neighbors > 0:
            # both directions — a memory's meaning is what it is wired to,
            # and direction is an implementation detail to a viewer
            for src, dst, rel, w in con.execute(
                "SELECT src_id, dst_id, relation, weight FROM edges "
                "WHERE src_id=? OR dst_id=? ORDER BY weight DESC LIMIT ?",
                (int(id), int(id), int(neighbors) * 6)).fetchall():
                other = dst if int(src) == int(id) else src
                if other in seen_other:
                    continue
                seen_other.add(other)
                r2 = con.execute("SELECT name, type FROM entities WHERE id=?",
                                 (other,)).fetchone()
                if r2:
                    nb.append({"id": int(other), "name": r2[0], "type": r2[1],
                               "rel": rel, "w": round(float(w or 0), 3)})
                if len(nb) >= int(neighbors):
                    break
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}
    now = time.time()
    return {
        "ok": True,
        "id": int(row[0]), "type": row[1], "name": row[2],
        "mentions": int(row[3] or 0),
        "salience": round(float(row[4] or 0), 3),
        "age_days": round((now - float(row[5] or now)) / 86400.0, 1),
        "last_seen_ago": round(now - float(row[6] or now), 1),
        "neighbors": nb,
        "memory": _node_memory(root, row[2]) if memory else None,
    }
