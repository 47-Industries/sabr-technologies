"""
/api/tenants/* + /api/channels/* + /api/audit/* + /api/security/* —
multi-tenant brain management, pub/sub channels, append-only audit log,
rate-limit inspection.

Extracted from misc.py 2026-06-08 per architecture review. Behavior
unchanged.
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, Header, Query

from brain.tenant import tenant_manager
from brain.security import audit_log, rate_limiter

log = logging.getLogger("leon.server")
router = APIRouter()


def _extract_token(
    x_nl_tenant_token: Optional[str] = Header(None),
    token: Optional[str] = Query(None),
) -> Optional[str]:
    return x_nl_tenant_token or token


# =============================================================================
# Tenants
# =============================================================================

@router.post("/api/tenants")
async def tenant_create(req: dict):
    name = (req.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    role = req.get("role", "user")
    try:
        t = tenant_manager.create_tenant(
            name=name, role=role, metadata=req.get("metadata", {}),
        )
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": True, "tenant": t.full_dict()}


@router.get("/api/tenants")
async def tenant_list():
    return {"tenants": [t.public_dict() for t in tenant_manager.list_tenants()]}


@router.get("/api/tenants/{tenant_id}")
async def tenant_get(tenant_id: str):
    t = tenant_manager.get_tenant(tenant_id)
    if t is None:
        return {"ok": False, "error": "tenant not found"}
    return t.public_dict()


@router.delete("/api/tenants/{tenant_id}")
async def tenant_delete(tenant_id: str, wipe_data: bool = False):
    ok = tenant_manager.delete_tenant(tenant_id, wipe_data=wipe_data)
    return {"ok": ok}


@router.post("/api/tenants/{tenant_id}/rotate-token")
async def tenant_rotate_token(tenant_id: str):
    token = tenant_manager.rotate_token(tenant_id)
    if token is None:
        return {"ok": False, "error": "tenant not found"}
    return {"ok": True, "new_token": token}


@router.post("/api/tenants/me/remember")
async def tenant_store(req: dict, token: Optional[str] = Depends(_extract_token)):
    try:
        t = tenant_manager.require_role(token, "admin", "user")
    except PermissionError as e:
        return {"ok": False, "error": str(e)}
    text = (req.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    return tenant_manager.store(
        t.tenant_id, text=text,
        source=req.get("source", "tenant"),
        tags=req.get("tags", []),
    )


@router.get("/api/tenants/me/recall")
async def tenant_recall(
    q: str,
    limit: int = 20,
    include_channels: bool = True,
    token: Optional[str] = Depends(_extract_token),
):
    try:
        t = tenant_manager.require_role(token, "admin", "user", "readonly")
    except PermissionError as e:
        return {"ok": False, "error": str(e)}
    results = tenant_manager.recall(
        t.tenant_id, query=q, limit=limit, include_channels=include_channels,
    )
    return {
        "tenant": t.public_dict(),
        "results": results,
        "count": len(results),
    }


@router.get("/api/tenants/stats")
async def tenant_stats():
    return tenant_manager.stats()


# =============================================================================
# Channels (pub/sub between tenants)
# =============================================================================

@router.post("/api/channels")
async def channel_create(req: dict):
    name = (req.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    ch = tenant_manager.create_channel(name=name, description=req.get("description", ""))
    return {"ok": True, "channel": ch.to_dict()}


@router.get("/api/channels")
async def channel_list():
    return {"channels": [c.to_dict() for c in tenant_manager.list_channels()]}


@router.delete("/api/channels/{channel_id}")
async def channel_delete(channel_id: str):
    return {"ok": tenant_manager.delete_channel(channel_id)}


@router.post("/api/channels/{channel_id}/publish")
async def channel_publish(channel_id: str, req: dict,
                          token: Optional[str] = Depends(_extract_token)):
    try:
        t = tenant_manager.require_role(token, "admin", "user")
    except PermissionError as e:
        return {"ok": False, "error": str(e)}
    text = (req.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    return tenant_manager.publish_to_channel(
        channel_id, text=text,
        source=f"tenant:{t.name}",
        tags=req.get("tags", []),
    )


@router.post("/api/channels/{channel_id}/subscribe")
async def channel_subscribe(channel_id: str,
                            token: Optional[str] = Depends(_extract_token)):
    try:
        t = tenant_manager.require_role(token, "admin", "user", "readonly")
    except PermissionError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": tenant_manager.subscribe(t.tenant_id, channel_id)}


@router.post("/api/channels/{channel_id}/unsubscribe")
async def channel_unsubscribe(channel_id: str,
                              token: Optional[str] = Depends(_extract_token)):
    try:
        t = tenant_manager.require_role(token, "admin", "user", "readonly")
    except PermissionError as e:
        return {"ok": False, "error": str(e)}
    return {"ok": tenant_manager.unsubscribe(t.tenant_id, channel_id)}


# =============================================================================
# Audit + rate-limit inspection
# =============================================================================

@router.get("/api/audit/tail")
async def audit_tail(limit: int = 100):
    return {"entries": audit_log.tail(limit)}


@router.get("/api/audit/verify")
async def audit_verify():
    return audit_log.verify_chain()


@router.get("/api/security/rate-limit/{key}")
async def rate_limit_status(key: str):
    return {"key": key, "tokens_remaining": rate_limiter.remaining(key)}
