#!/usr/bin/env python3
"""
VPS-based terminal service using tmux + HTTP API + WebSocket.
Spawns and manages terminal sessions on the VPS for remote dashboard access.
Supports Windows, macOS, and Linux clients — all route through this service.
"""

import asyncio
import hmac
import json
import logging
import os
import subprocess
import uuid
from typing import Dict, Optional
import signal
from datetime import datetime

from aiohttp import web
import aiohttp

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("tmux-terminal-service")

# ── Auth ──────────────────────────────────────────────────────────────
# This service spawns REAL root shells and binds a public port. Until
# 2026-07-18 it performed NO authentication — anyone on the internet who
# hit /ws/term/<name> got an unauthenticated root shell (RCE). The
# dashboard client already sends the master key as ?key=<LEON_API_KEY>
# (see dashboard/terminal.html); we now enforce it. Fail CLOSED: if the
# server has no key configured, reject everything rather than expose a
# shell. Only /api/health is exempt (liveness probe, no shell access).
_AUTH_EXEMPT_PATHS = {"/api/health"}


def _request_key(request) -> str:
    """Pull the caller's key from ?key= (WS + browser) or a Bearer header."""
    k = request.query.get("key")
    if k:
        return k
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:]
    return ""


@web.middleware
async def auth_middleware(request, handler):
    if request.path in _AUTH_EXEMPT_PATHS:
        return await handler(request)
    server_key = os.environ.get("LEON_API_KEY", "")
    if not server_key:
        logger.error("LEON_API_KEY not set — refusing all terminal access "
                     "(fail-closed). Check the unit's EnvironmentFile.")
        return web.Response(status=503, text="terminal service misconfigured")
    if not hmac.compare_digest(_request_key(request), server_key):
        logger.warning("Rejected unauthenticated terminal request to %s from %s",
                       request.path, request.remote)
        return web.Response(status=401, text="unauthorized")
    return await handler(request)

TERMINALS: Dict[str, dict] = {}
TERMINAL_LOCK = asyncio.Lock()
WS_CLIENTS: Dict[str, set] = {}  # session_id -> set of WebSocket connections

class TerminalSession:
    def __init__(self, session_id: str, cwd: str, shell: str = "/bin/bash"):
        self.session_id = session_id
        self.cwd = cwd
        self.shell = shell
        self.tmux_session = f"leon-{session_id[:8]}"
        self.created = datetime.now()
        self.last_activity = datetime.now()
        self.dead = False

    async def spawn(self) -> bool:
        """Spawn a tmux session."""
        try:
            # Kill existing session if it exists
            subprocess.run(
                ["tmux", "kill-session", "-t", self.tmux_session],
                capture_output=True,
                timeout=2
            )
        except:
            pass

        try:
            # Create new tmux session in the given cwd (with TERM set)
            result = subprocess.run(
                ["tmux", "new-session", "-d", "-s", self.tmux_session, "-c", self.cwd, "-e", "TERM=xterm-256color", self.shell],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                logger.error(f"Failed to spawn tmux session: {result.stderr}")
                return False

            logger.info(f"Spawned tmux session {self.tmux_session} in {self.cwd}")
            return True
        except Exception as e:
            logger.error(f"Exception spawning session: {e}")
            return False

    async def write(self, data: str) -> bool:
        """Write to tmux session.

        EXEMPT FROM may_autosubmit BY DECISION, 2026-08-03 (DJ-003).

        The gate governs UNATTENDED submission — the loop pressing Enter on
        text nobody watched it type. This is the web terminal keystroke path:
        a human is at the keyboard, they ARE the authorizer, and every byte
        here is theirs by construction. Routing it through the gate made the
        interactive terminal unusable on every pane on this box (the gate
        refuses bypass-on panes, which is all of them: 94 refusals, 94
        attempts, zero yes).

        It also MUTATED the payload: newlines flattened to spaces, then
        .strip(). A multi-line paste arrived as one collapsed line and a bare
        Enter became the empty string, which send() rejects outright — so the
        Enter key silently did nothing. A terminal write path must deliver
        exactly the bytes it was handed. It does now.
        """
        try:
            if not data:
                return True

            # Split on submit characters, preserving order and count. Literal
            # text goes through send-keys -l so nothing is interpreted as a
            # key name; each \r or \n becomes exactly one Enter.
            chunk = ""
            for ch in data:
                if ch in ("\r", "\n"):
                    if chunk:
                        self._send_keys("-l", chunk)
                        chunk = ""
                    self._send_keys("Enter")
                else:
                    chunk += ch
            if chunk:
                self._send_keys("-l", chunk)

            self.last_activity = datetime.now()
            return True
        except Exception as e:
            logger.error(f"Write error: {e}")
            return False

    def _send_keys(self, *args: str) -> None:
        """One tmux send-keys call. Args land AFTER -t, before nothing."""
        subprocess.run(
            ["tmux", "send-keys", "-t", self.tmux_session, *args],
            capture_output=True,
            timeout=2,
            check=False,
        )

    async def read(self) -> str:
        """Read output from tmux session."""
        try:
            result = subprocess.run(
                ["tmux", "capture-pane", "-t", self.tmux_session, "-p"],
                capture_output=True,
                text=True,
                timeout=2
            )

            if result.returncode != 0:
                self.dead = True
                return ""

            return result.stdout
        except Exception as e:
            logger.error(f"Read error: {e}")
            self.dead = True
            return ""

    async def kill(self) -> bool:
        """Kill the tmux session."""
        try:
            subprocess.run(
                ["tmux", "kill-session", "-t", self.tmux_session],
                capture_output=True,
                timeout=2,
                check=False
            )
            self.dead = True
            return True
        except Exception as e:
            logger.error(f"Kill error: {e}")
            return False

    async def is_alive(self) -> bool:
        """Check if session is still alive."""
        try:
            result = subprocess.run(
                ["tmux", "list-sessions", "-F", "#{session_name}"],
                capture_output=True,
                text=True,
                timeout=1
            )
            return self.tmux_session in result.stdout
        except:
            return False

# HTTP API Routes
async def spawn_terminal(request):
    """Spawn a new terminal session."""
    try:
        data = await request.json()
        session_id = str(uuid.uuid4())
        cwd = data.get("cwd", os.path.expanduser("~"))
        shell = data.get("shell", "/bin/bash")

        if not os.path.isdir(cwd):
            cwd = os.path.expanduser("~")

        async with TERMINAL_LOCK:
            session = TerminalSession(session_id, cwd, shell)

            if not await session.spawn():
                return web.json_response({"error": "Failed to spawn terminal"}, status=500)

            TERMINALS[session_id] = session
            WS_CLIENTS[session_id] = set()

            logger.info(f"Spawned terminal {session_id} in {cwd}")
            return web.json_response({
                "session_id": session_id,
                "status": "ok",
                "tmux_session": session.tmux_session
            })
    except Exception as e:
        logger.error(f"Spawn error: {e}")
        return web.json_response({"error": str(e)}, status=400)

async def write_terminal(request):
    """Write to terminal (HTTP)."""
    session_id = request.match_info["session_id"]
    try:
        data = await request.json()
        session = TERMINALS.get(session_id)

        if not session:
            return web.json_response({"error": "Terminal not found"}, status=404)

        if not await session.write(data.get("data", "")):
            return web.json_response({"error": "Write failed"}, status=400)

        return web.json_response({"status": "ok"})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def read_terminal(request):
    """Read from terminal (HTTP)."""
    session_id = request.match_info["session_id"]
    try:
        session = TERMINALS.get(session_id)

        if not session:
            return web.json_response({"error": "Terminal not found"}, status=404)

        output = await session.read()

        return web.json_response({
            "session_id": session_id,
            "output": output,
            "status": "ok"
        })
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def list_terminals(request):
    """List all terminal sessions."""
    try:
        sessions = []
        async with TERMINAL_LOCK:
            for session_id, session in list(TERMINALS.items()):
                alive = await session.is_alive()
                if not alive:
                    del TERMINALS[session_id]
                    if session_id in WS_CLIENTS:
                        del WS_CLIENTS[session_id]
                else:
                    sessions.append({
                        "session_id": session_id,
                        "tmux_session": session.tmux_session,
                        "cwd": session.cwd,
                        "created": session.created.isoformat(),
                        "status": "alive"
                    })

        return web.json_response({
            "sessions": sessions,
            "total": len(sessions)
        })
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def kill_terminal(request):
    """Kill a terminal session."""
    session_id = request.match_info["session_id"]
    try:
        session = TERMINALS.get(session_id)

        if not session:
            return web.json_response({"error": "Terminal not found"}, status=404)

        async with TERMINAL_LOCK:
            await session.kill()

            # Notify WebSocket clients
            if session_id in WS_CLIENTS:
                for ws in WS_CLIENTS[session_id]:
                    await ws.send_json({"type": "terminal_killed"})
                del WS_CLIENTS[session_id]

            del TERMINALS[session_id]
            logger.info(f"Killed terminal {session_id}")

        return web.json_response({"status": "ok", "session_id": session_id})
    except Exception as e:
        return web.json_response({"error": str(e)}, status=400)

async def health_check(request):
    """Health check endpoint."""
    return web.json_response({
        "status": "ok",
        "service": "tmux-terminal-service",
        "terminals": len(TERMINALS),
        "timestamp": datetime.now().isoformat()
    })

# Map window names to session IDs for dashboard compatibility
WINDOW_SESSIONS: Dict[str, str] = {}

# WebSocket Terminal Protocol (generic session_id endpoint)
async def terminal_ws(request):
    """WebSocket connection for real-time terminal I/O."""
    session_id = request.match_info["session_id"]

    async with TERMINAL_LOCK:
        session = TERMINALS.get(session_id)
        if not session:
            return web.Response(status=404, text="Terminal not found")

    ws = web.WebSocketResponse()
    await ws.prepare(request)

    # Register this WebSocket
    if session_id not in WS_CLIENTS:
        WS_CLIENTS[session_id] = set()
    WS_CLIENTS[session_id].add(ws)

    logger.info(f"WebSocket client connected to terminal {session_id}")

    try:
        # Handle both JSON and binary messages
        async for msg in ws:
            if isinstance(msg, bytes):
                # Binary input from client
                await session.write(msg.decode('utf-8', errors='replace'))
            elif isinstance(msg, str):
                # JSON message (xterm protocol)
                try:
                    data = json.loads(msg)
                    if data.get("type") == "input":
                        await session.write(data.get("data", ""))
                    elif data.get("type") == "resize":
                        # Ignore resize for now, tmux handles it
                        pass
                    elif data.get("type") == "ping":
                        await ws.send_json({
                            "type": "pong",
                            "timestamp": datetime.now().isoformat()
                        })
                except json.JSONDecodeError:
                    pass

    except Exception as e:
        logger.error(f"WebSocket error: {e}")

    finally:
        if session_id in WS_CLIENTS:
            WS_CLIENTS[session_id].discard(ws)
        logger.info(f"WebSocket client disconnected from terminal {session_id}")

    return ws

# Dashboard-compatible endpoint: maps window names to sessions
async def terminal_ws_by_window(request):
    """WebSocket connection keyed by window name (dashboard compatibility)."""
    window_name = request.match_info["window_name"]

    async with TERMINAL_LOCK:
        # Auto-spawn if doesn't exist
        if window_name not in WINDOW_SESSIONS:
            session_id = str(uuid.uuid4())
            cwd = os.path.expanduser("~")
            session = TerminalSession(session_id, cwd)
            if not await session.spawn():
                return web.Response(status=500, text="Failed to spawn terminal")
            TERMINALS[session_id] = session
            WINDOW_SESSIONS[window_name] = session_id
            WS_CLIENTS[session_id] = set()
            logger.info(f"Auto-spawned terminal for window {window_name}: {session_id}")
        else:
            session_id = WINDOW_SESSIONS[window_name]
            session = TERMINALS.get(session_id)
            if not session:
                # Session was cleaned up, respawn
                session_id = str(uuid.uuid4())
                cwd = os.path.expanduser("~")
                session = TerminalSession(session_id, cwd)
                if not await session.spawn():
                    return web.Response(status=500, text="Failed to spawn terminal")
                TERMINALS[session_id] = session
                WINDOW_SESSIONS[window_name] = session_id
                WS_CLIENTS[session_id] = set()

    ws = web.WebSocketResponse()
    await ws.prepare(request)

    # Register this WebSocket
    if session_id not in WS_CLIENTS:
        WS_CLIENTS[session_id] = set()
    WS_CLIENTS[session_id].add(ws)

    logger.info(f"WebSocket client connected to window {window_name} (session {session_id})")

    # Ensure TERM is set on the session (fixes existing sessions from Linux)
    try:
        subprocess.run(
            ["tmux", "set-environment", "-t", session.tmux_session, "TERM", "xterm-256color"],
            capture_output=True,
            timeout=2
        )
    except Exception as e:
        logger.warning(f"Could not set TERM on session: {e}")

    try:
        # Read loop: send terminal output to client
        # Client sends: JSON {type:"input", data} or {type:"resize", rows, cols}
        async for msg in ws:
            try:
                # aiohttp sends strings for text frames, bytes for binary
                if isinstance(msg, bytes):
                    # Binary input
                    await session.write(msg.decode('utf-8', errors='replace'))
                elif isinstance(msg, str):
                    # String/JSON
                    try:
                        data = json.loads(msg)
                        if data.get("type") == "input":
                            await session.write(data.get("data", ""))
                        elif data.get("type") == "resize":
                            # Ignore resize for now
                            pass
                    except json.JSONDecodeError:
                        # Try as raw input
                        await session.write(msg)

                # After each input, send current output
                output = await session.read()
                if output:
                    # Send as binary to match xterm protocol
                    await ws.send_bytes(output.encode('utf-8'))

            except Exception as e:
                logger.error(f"Error processing message: {e}")

    except Exception as e:
        logger.error(f"WebSocket error for window {window_name}: {e}")

    finally:
        if session_id in WS_CLIENTS:
            WS_CLIENTS[session_id].discard(ws)
        logger.info(f"WebSocket client disconnected from window {window_name}")

    return ws

async def init_app():
    app = web.Application(middlewares=[auth_middleware])

    # HTTP API
    app.router.add_post("/api/terminal/spawn", spawn_terminal)
    app.router.add_post("/api/terminal/{session_id}/write", write_terminal)
    app.router.add_get("/api/terminal/{session_id}/read", read_terminal)
    app.router.add_get("/api/terminal/list", list_terminals)
    app.router.add_delete("/api/terminal/{session_id}/kill", kill_terminal)
    app.router.add_get("/api/health", health_check)

    # WebSocket endpoints
    app.router.add_get("/ws/terminal/{session_id}", terminal_ws)
    app.router.add_get("/ws/term/{window_name}", terminal_ws_by_window)  # Dashboard compatibility

    return app

async def main():
    import argparse
    parser = argparse.ArgumentParser(description="VPS Terminal Service (tmux-based)")
    parser.add_argument("--port", type=int, default=9102, help="Port to listen on")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    args = parser.parse_args()

    # Verify tmux is installed
    try:
        subprocess.run(["tmux", "-V"], capture_output=True, check=True)
    except:
        logger.error("tmux is not installed or not in PATH")
        exit(1)

    app = await init_app()
    runner = web.AppRunner(app)
    await runner.setup()

    logger.info(f"Starting Tmux Terminal Service on {args.host}:{args.port}")
    site = web.TCPSite(runner, args.host, args.port)
    await site.start()

    logger.info("Terminal service running. Press CTRL+C to stop.")

    try:
        await asyncio.Event().wait()
    except KeyboardInterrupt:
        logger.info("Shutting down...")

        # Clean up all tmux sessions
        async with TERMINAL_LOCK:
            for session in TERMINALS.values():
                await session.kill()

        await runner.cleanup()

if __name__ == "__main__":
    asyncio.run(main())
