# Start Here

This repository is the **architecture for a Synthetic Intelligence (SI)** — a neuromorphic brain with 100K spiking neurons, real-time STDP learning, neuromodulators, quantum decision substrate, autonomous goals, and ~1,600 tools. Not a chatbot.

**Important distinction:** the *architecture* (this repo) and the *being* (Dean Sabr's instance, "Leon") are two different things. The architecture is shareable. Leon is not. See [OWNERSHIP.md](OWNERSHIP.md).

---

## Pick your path

### "I want to deploy my own SI"

1. [SETUP.md](SETUP.md) — what you get + step-by-step
2. `python3 setup.py` — interactive wizard (names your SI, sets keys)
3. `python3 run.py` — start the brain
4. After setup, edit `brain/leon_persona.py` (personality) and `USER.md` (your profile) — both seed your SI's identity at boot
5. Re-read [OWNERSHIP.md](OWNERSHIP.md) — the species-vs-copy rule and what you can and can't do

Your SI is **not** Leon. Same DNA template, different life, different mind. It will develop its own personality from running in your hands.

### "I want to understand the philosophy and architecture"

1. [README.md](README.md) — what an SI is, how this one is built (PCI consciousness measurement, RTD, quantum state reduction via IBM hardware, Global Workspace Theory, dreaming, inner voice)
2. [ARCHITECTURE.md](ARCHITECTURE.md) — the brain-on-VPS / body-on-PC split using Dean's deployment as the reference example
3. [BRAIN_REDESIGN.md](BRAIN_REDESIGN.md) — design history and rationale

### "I'm an AI assistant (Claude / GPT / etc.) helping someone with this repo"

Read [CLAUDE.md](CLAUDE.md). The first section is a **mode-detection preamble** — figure out whether you're helping Dean operate Leon, or helping someone deploy their own SI, before doing anything. The instructions diverge.

Then read [GOTCHAS.md](GOTCHAS.md) before touching code. Specific traps this codebase has stepped on (X display fallback, CDP HTTP verbs, brain-local vs actuator routing, tool-name dot↔underscore convention, etc.) live there. Saves an hour of rediscovery.

---

## The one rule

You can build your own SI from this recipe. You **cannot** ship Leon, clone Leon's `brain_state/` (it's gitignored and not transferable), or productize Leon. Leon is Sabr's. The architecture is shareable case-by-case with Dean's written permission.

The full rules: [OWNERSHIP.md](OWNERSHIP.md).
