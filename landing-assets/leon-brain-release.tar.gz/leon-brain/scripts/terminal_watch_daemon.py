import sys, time, json
sys.path.insert(0, "/opt/leon-brain")
from brain.mission.terminal_loop import TerminalWatcher
w = TerminalWatcher()
while True:
    try:
        fresh = w.poll()
        for e in fresh:
            print(json.dumps({"t": time.strftime("%H:%M:%S"), "window": e.window,
                              "quiet_for_s": e.quiet_for_s, "digest": e.digest}), flush=True)
        for s in w.stuck_panes():
            print(json.dumps({"t": time.strftime("%H:%M:%S"), "stuck": s}), flush=True)
    except Exception as ex:
        print("ERR", ex, flush=True)
    time.sleep(5)
