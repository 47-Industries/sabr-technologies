#!/usr/bin/env python3
"""
Audit the Railway CLI's local link cache for tree-walk hazards.

WHY THIS EXISTS
---------------
`railway status` / `railway up` do not require a link in the current
directory. The CLI walks UP the directory tree until it finds one. So a link
on a PARENT directory silently arms every unlinked folder beneath it.

On 2026-07-29 this meant `/opt/leon-brain` and `/opt/leon-brain/workspaces`
were both linked to `sabr-technologies` — the live company website — so every
client repo under workspaces/, and every repo cloned there in future, was one
reflexive `railway up` away from deploying over sabrtechnologies.com. Proven,
not assumed: an empty throwaway directory under workspaces/ reported the
website as its project. `/tmp` had the same shape, pointing at Integrity
Network.

The fix was removing the ancestor entries. The DURABLE fix is not remembering
to never link a directory that has repos under it — it's this, run whenever
something new gets linked.

USAGE
-----
    python3 scripts/railway_link_audit.py

Exit 0 = clean. Exit 1 = at least one ancestor link found (the hazard).
Read-only: it never edits the cache. Fixing is a human decision because
removing the wrong entry breaks a real deploy path.
"""

import json
import os
import sys

CONFIG_CANDIDATES = [
    os.path.expanduser("~/.railway/config.json"),
    os.path.expanduser("~/.config/railway/config.json"),
]


def load_links():
    for path in CONFIG_CANDIDATES:
        if os.path.isfile(path):
            with open(path) as fh:
                return path, json.load(fh).get("projects", {})
    return None, None


def main() -> int:
    path, projects = load_links()
    if projects is None:
        print("No Railway link cache found — nothing to audit.")
        return 0

    # Positive control. If the cache parses but is empty, an "absent entry"
    # below would be meaningless rather than reassuring, and this run should
    # not be read as a clean bill of health.
    if not projects:
        print(f"{path} parsed but contains zero links — audit is vacuous.")
        return 0

    paths = sorted(projects)
    hazards = []
    for parent in paths:
        stem = parent.rstrip("/") + "/"
        children = [p for p in paths if p != parent and p.startswith(stem)]
        if children:
            hazards.append((parent, projects[parent].get("name"), children))

    # Shared roots are a hazard even with no linked children, because the
    # things beneath them are unlinked scratch dirs — exactly what inherits.
    SHARED = {"/", "/tmp", "/opt", "/home", "/root", "/var/tmp"}
    for p in paths:
        if p.rstrip("/") in SHARED and not any(h[0] == p for h in hazards):
            hazards.append((p, projects[p].get("name"), []))

    # CAUTION: this cache is shared across machines. Leon's brain runs on the
    # VPS; Dean's PC is a separate box with its own filesystem. A /home/deansabr
    # path is NOT missing just because the VPS can't stat it — it lives on the
    # other machine. Calling those "stale" would be exactly the false-confidence
    # bug this whole audit exists to prevent, so they are reported separately
    # and explicitly as unknown rather than folded in with real absences.
    elsewhere = [p for p in paths if not os.path.isdir(p) and p.startswith("/home/")]
    stale = [p for p in paths if not os.path.isdir(p) and not p.startswith("/home/")]

    print(f"Railway link cache: {path}")
    print(f"  {len(paths)} linked paths.")
    print()

    if stale:
        print("STALE (dir genuinely gone on THIS machine — a hazard if the path is reused):")
        for p in stale:
            print(f"  {p} -> {projects[p].get('name')}")
        print()

    if elsewhere:
        print("NOT CHECKABLE FROM HERE (these live on Dean's PC, not the VPS —")
        print("absence here proves nothing about them):")
        for p in elsewhere:
            print(f"  {p} -> {projects[p].get('name')}")
        print()

    if not hazards:
        print("CLEAN: no link sits above another linked path or on a shared root.")
        print("Any unlinked directory fails safe — `railway up` there is a no-op.")
        return 0

    print("HAZARD: these links are inherited by everything beneath them.")
    print("An unlinked folder under one of these deploys to the named project.")
    print()
    for parent, name, children in hazards:
        print(f"  {parent}")
        print(f"      -> {name}")
        if children:
            print(f"      {len(children)} linked children (they override; unlinked siblings do NOT):")
            for c in children[:5]:
                print(f"        {c}")
            if len(children) > 5:
                print(f"        ... and {len(children) - 5} more")
        else:
            print("      shared root — anything scratch-built underneath inherits this")
        print()

    print("Fix by hand: back up the cache, remove the ancestor entry, then link")
    print("each real project directory explicitly. Verify BOTH directions —")
    print("the hazard folder now reports no project, AND a real deploy path still does.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
