"""
Synthesize positive "hey leon" samples for openWakeWord training.

Training a custom openWakeWord detector needs ~1k-100k positive samples
with varied speakers, prosody, and length. We don't have a thousand
voices — but piper-tts can vary speed (length_scale) and slightly vary
prosody by re-synthesizing with random seeds, which is enough to
bootstrap a basic detector.

Output: brain_state/voice/wake_train/positives/*.wav
        Each is 16kHz mono int16 (the format openWakeWord expects).

Usage:
    python3 scripts/train_hey_leon/synthesize_positives.py \
        --count 500 --voice en_GB-alan-medium --out brain_state/voice/wake_train/positives

Estimated time: ~5min for 500 samples on a modern desktop.
Disk: ~20MB for 500 samples.

After running this, see scripts/train_hey_leon/README.md for the full
training pipeline (download negative-sample embeddings, run training
notebook, export ONNX).
"""

from __future__ import annotations

import argparse
import io
import os
import random
import sys
import wave

import numpy as np


# Variations of the wake phrase. Mixing these in roughly equal shares
# gives the trained classifier a wider notion of "hey leon" — some users
# elide the 'h', drop the comma, etc.
_PHRASES = [
    "hey leon",
    "hey leon.",
    "hey leon,",
    "hey leon, are you there",
    "hey leon, listen up",
    "leon",
    "okay leon",
    "yo leon",
    "ay leon",
]

# Length scale = inverse speed. piper default is 1.0; we bracket this
# range to mimic fast/slow speech.
_LENGTH_SCALES = [0.78, 0.85, 0.92, 1.0, 1.08, 1.18, 1.28]

# Noise scale tweaks prosody randomness. Default 0.667.
_NOISE_SCALES = [0.55, 0.667, 0.75, 0.85]

# Noise W controls phoneme duration variability.
_NOISE_W_SCALES = [0.6, 0.8, 1.0, 1.2]


def _resample_16k(samples: np.ndarray, sr: int) -> np.ndarray:
    if sr == 16000:
        return samples
    new_len = int(len(samples) * 16000 / sr)
    idx = np.linspace(0, len(samples) - 1, new_len)
    return np.interp(idx, np.arange(len(samples)), samples).astype(np.int16)


def synthesize(
    voice_path: str, out_dir: str, count: int = 500, seed: int = 0,
) -> int:
    from piper import PiperVoice
    voice = PiperVoice.load(voice_path)
    rng = random.Random(seed)
    os.makedirs(out_dir, exist_ok=True)
    written = 0
    for i in range(count):
        phrase = rng.choice(_PHRASES)
        length_scale = rng.choice(_LENGTH_SCALES)
        noise_scale = rng.choice(_NOISE_SCALES)
        noise_w = rng.choice(_NOISE_W_SCALES)
        # Re-synthesize at 22050 (piper default) then resample to 16k mono
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            try:
                voice.synthesize_wav(
                    phrase, wf, set_wav_format=True,
                    length_scale=length_scale,
                    noise_scale=noise_scale,
                    noise_w_scale=noise_w,
                )
            except TypeError:
                # Older piper API
                voice.synthesize_wav(phrase, wf, set_wav_format=True)
        buf.seek(0)
        with wave.open(buf, "rb") as wf:
            sr = wf.getframerate()
            nch = wf.getnchannels()
            samples = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16)
            if nch > 1:
                samples = samples.reshape(-1, nch).mean(axis=1).astype(np.int16)
        samples = _resample_16k(samples, sr)
        out_path = os.path.join(out_dir, f"hey_leon_{i:05d}.wav")
        with wave.open(out_path, "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(16000)
            wf.writeframes(samples.tobytes())
        written += 1
        if (i + 1) % 50 == 0:
            print(f"  {i+1}/{count} samples")
    return written


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--count", type=int, default=500,
                    help="Number of positive samples (default 500)")
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    default_voice = os.path.join(project_root, "brain_state/voice/piper/en_GB-alan-medium.onnx")
    ap.add_argument("--voice", default=default_voice,
                    help=f"Path to piper voice .onnx (default: {default_voice})")
    default_out = os.path.join(project_root, "brain_state/voice/wake_train/positives")
    ap.add_argument("--out", default=default_out,
                    help=f"Output directory (default: {default_out})")
    ap.add_argument("--seed", type=int, default=0,
                    help="Random seed for variation choice (default 0)")
    args = ap.parse_args()

    if not os.path.exists(args.voice):
        print(f"voice not found: {args.voice}", file=sys.stderr)
        return 1
    print(f"Synthesizing {args.count} positives with {os.path.basename(args.voice)}")
    print(f"Output: {args.out}")
    n = synthesize(args.voice, args.out, args.count, args.seed)
    print(f"\nDone — {n} samples written.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
