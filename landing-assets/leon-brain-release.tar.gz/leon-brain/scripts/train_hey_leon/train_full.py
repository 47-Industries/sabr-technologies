#!/usr/bin/env python3
"""
Full hey_leon ONNX trainer — the "go bigger" path.

What's different vs train_minimal.py:
  - Multi-voice positives via piper-sample-generator + libritts model
    (replaces the single-voice synthesize_positives.py output)
  - Adversarial negatives generated from phoneme-overlap phrases
    (lets the classifier learn what "hey leon" ISN'T, dramatically
    cuts the always-predict-no degenerate failure mode)
  - MIT room-impulse-response augmentation during feature compute
  - Looser auto_train thresholds (max_negative_weight=100,
    target_fp_per_hour=2.0) so the model actually predicts positives
  - All the prior fixes carried over: DataLoader-wrapped val sets,
    str→float label mapping, scipy<1.15, copied resources, weights_only
    patch on the libritts loader.

Run:
    source ~/openWakeWord-train/venv/bin/activate
    python3 scripts/train_hey_leon/train_full.py
"""

from __future__ import annotations

import logging
import os
import random
import shutil
import sys
import time
from pathlib import Path

TRAIN_REPO = "/home/deansabr/openWakeWord-train"
PIPER_GEN_REPO = "/home/deansabr/openWakeWord-train/piper-sample-generator"
sys.path.insert(0, TRAIN_REPO)
sys.path.insert(0, PIPER_GEN_REPO)

import numpy as np
import torch
from openwakeword.data import (
    augment_clips, mmap_batch_generator, generate_adversarial_texts,
)
from openwakeword.train import Model
from openwakeword.utils import compute_features_from_generator
from generate_samples import generate_samples

PROJECT_ROOT = Path("/home/deansabr/Desktop/Leon-V1.3-SOURCE")
WORK_DIR = PROJECT_ROOT / "brain_state/voice/wake_train/run"
OUTPUT_MODEL_DIR = PROJECT_ROOT / "brain_state/voice/wake_models"
NEGATIVES_FEATURES_DIR = PROJECT_ROOT / "brain_state/voice/wake_train/negatives_features"
RIR_DIR = WORK_DIR / "mit_rirs"

CONFIG = {
    "model_name": "hey_leon",
    "target_phrase": "hey leon",
    "n_positive_train": 4000,
    "n_positive_test": 1000,
    "n_adversarial": 4000,           # adversarial negatives (phoneme overlap)
    "augmentation_rounds": 2,
    "total_length_s": 2.0,
    "sample_rate": 16000,
    "steps": 30000,
    "max_negative_weight": 100,      # was 1500 — too strict, drove model to 0% recall
    "target_fp_per_hour": 2.0,       # was 0.5 — too strict; relax to actually fire
    "batch_n_per_class": {
        "ACAV100M_sample": 512,
        "adversarial_negative": 256,
        "positive": 256,
    },
    "input_shape": (16, 96),
    "layer_size": 32,
}


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler("/tmp/hey_leon_training.log", mode="a"),
            logging.StreamHandler(sys.stdout),
        ],
    )


# ── Step 1: Generate multi-voice positives ──────────────────────────────────
def generate_positives(out_dir: Path, n: int, seed: int = 1):
    """Generate `n` 'hey leon' WAVs into out_dir using piper_sample_generator
    with the libritts multi-voice model. Idempotent — counts existing files
    and only generates the deficit."""
    out_dir.mkdir(parents=True, exist_ok=True)
    existing = len(list(out_dir.glob("*.wav")))
    if existing >= int(n * 0.95):
        logging.info(f"positives already at {existing}/{n} in {out_dir.name}, skipping")
        return
    need = n - existing
    logging.info(f"generating {need} multi-voice 'hey leon' WAVs → {out_dir.name}")
    t0 = time.time()
    # The lib auto-appends an index per file; we just pass a target count.
    generate_samples(
        text=CONFIG["target_phrase"],
        output_dir=str(out_dir),
        max_samples=need,
        batch_size=128,
        # max_speakers=400 → use lots of distinct voices; libritts has ~900
        max_speakers=400,
        slerp_weights=[0.3, 0.5, 0.7],   # mixing weights for voice blending
        length_scales=[0.85, 1.0, 1.15], # speed variation
        noise_scales=[0.5, 0.667, 0.85],
        noise_scale_ws=[0.7, 0.8, 0.9],
        verbose=False,
    )
    n_now = len(list(out_dir.glob("*.wav")))
    logging.info(f"positives now at {n_now} ({time.time()-t0:.0f}s)")


# ── Step 2: Generate adversarial negatives ──────────────────────────────────
def generate_adversarials(out_dir: Path, n: int, seed: int = 2):
    """Use openwakeword.data.generate_adversarial_texts to get phrases that
    sound LIKE 'hey leon' phonetically but aren't, then synthesize WAVs
    for each phrase with piper_sample_generator. The model learns the
    difference, which is what kills false positives without breaking
    recall on the real phrase."""
    out_dir.mkdir(parents=True, exist_ok=True)
    existing = len(list(out_dir.glob("*.wav")))
    if existing >= int(n * 0.95):
        logging.info(f"adversarials already at {existing}/{n} in {out_dir.name}, skipping")
        return

    need = n - existing
    n_phrases = max(50, need // 20)   # ~20 samples per phrase
    logging.info(f"generating {n_phrases} adversarial phrases via phoneme overlap...")
    t0 = time.time()
    phrases = generate_adversarial_texts(input_text=CONFIG["target_phrase"], N=n_phrases)
    logging.info(f"got {len(phrases)} adversarial phrases (e.g., {phrases[:5]})")

    # Synthesize each phrase. piper_sample_generator can take a list of
    # texts directly — it'll cycle through them and balance speakers.
    logging.info(f"synthesizing {need} adversarial WAVs → {out_dir.name}")
    generate_samples(
        text=phrases,
        output_dir=str(out_dir),
        max_samples=need,
        batch_size=128,
        max_speakers=400,
        slerp_weights=[0.3, 0.5, 0.7],
        length_scales=[0.9, 1.0, 1.1],
        noise_scales=[0.5, 0.667, 0.85],
        noise_scale_ws=[0.7, 0.8, 0.9],
        verbose=False,
    )
    n_now = len(list(out_dir.glob("*.wav")))
    logging.info(f"adversarials now at {n_now} ({time.time()-t0:.0f}s)")


# ── Step 3: Compute openwakeword features ──────────────────────────────────
def compute_features(clip_dir: Path, out_npy: Path, augmentation_rounds: int,
                     use_rir: bool = True):
    """Augment + compute features. RIR augmentation pulls from MIT_RIRs;
    no background-noise mixing (we don't have AudioSet/FMA)."""
    if out_npy.exists() and out_npy.stat().st_size > 1_000_000:
        logging.info(f"{out_npy.name} already exists ({out_npy.stat().st_size/1e6:.1f} MB), skipping")
        return
    out_npy.parent.mkdir(parents=True, exist_ok=True)

    clip_paths = [str(p) for p in clip_dir.glob("*.wav")] * augmentation_rounds
    if not clip_paths:
        raise RuntimeError(f"no WAVs in {clip_dir}")
    n_total = len(clip_paths)
    total_length_samples = int(CONFIG["total_length_s"] * CONFIG["sample_rate"])
    logging.info(f"feature compute: {n_total} clips × aug → {out_npy.name}")
    t0 = time.time()
    rir_paths = [str(p) for p in RIR_DIR.glob("*.wav")] if use_rir else []
    gen = augment_clips(
        clip_paths,
        total_length=total_length_samples,
        sr=CONFIG["sample_rate"],
        batch_size=64,
        background_clip_paths=[],         # no AudioSet/FMA tonight
        RIR_paths=rir_paths,
    )
    device = "gpu" if torch.cuda.is_available() else "cpu"
    compute_features_from_generator(
        gen,
        n_total=n_total,
        clip_duration=total_length_samples,
        output_file=str(out_npy),
        device=device,
        ncpu=4,
    )
    logging.info(f"saved {out_npy.name} ({out_npy.stat().st_size/1e6:.1f} MB) in {time.time()-t0:.0f}s")


# ── Step 4: Build val DataLoaders (lessons from train_minimal.py) ─────────
def build_fp_val_loader(fp_val_path: Path, input_frames: int = 16,
                        n_sample: int = 200_000):
    raw = np.load(str(fp_val_path), mmap_mode="r")
    n_take = min(raw.shape[0] - input_frames, n_sample)
    stacked = np.stack(
        [raw[i:i+input_frames] for i in range(n_take)]
    ).astype(np.float32)
    labels = np.zeros(stacked.shape[0], dtype=np.float32)
    ds = torch.utils.data.TensorDataset(
        torch.from_numpy(stacked), torch.from_numpy(labels),
    )
    return torch.utils.data.DataLoader(ds, batch_size=4096, shuffle=False)


def build_balanced_val_loader(pos_features_path: Path, neg_features_path: Path,
                              neg_take: int = 5000):
    pos = np.load(str(pos_features_path), mmap_mode="r").astype(np.float32)
    neg_raw = np.load(str(neg_features_path), mmap_mode="r")
    n_take = min(neg_raw.shape[0], neg_take)
    neg = np.array(neg_raw[:n_take]).astype(np.float32)
    X = np.concatenate([pos, neg], axis=0)
    y = np.concatenate([
        np.ones(pos.shape[0], dtype=np.float32),
        np.zeros(neg.shape[0], dtype=np.float32),
    ])
    ds = torch.utils.data.TensorDataset(
        torch.from_numpy(X), torch.from_numpy(y),
    )
    return torch.utils.data.DataLoader(ds, batch_size=512, shuffle=False)


def torch_wrap(generator):
    """mmap_batch_generator yields (X, y) where y is a string array of class
    names. Map them to {1.0, 0.0} for binary classification."""
    for X, y in generator:
        X_t = torch.from_numpy(np.asarray(X)).float()
        y_num = np.array(
            [1.0 if str(label) == "positive" else 0.0 for label in y],
            dtype=np.float32,
        )
        y_t = torch.from_numpy(y_num)
        yield X_t, y_t


def main() -> int:
    setup_logging()
    logging.info("=" * 60)
    logging.info(f"hey_leon FULL training start: {time.strftime('%c')}")
    logging.info("=" * 60)
    logging.info(f"CUDA: {torch.cuda.is_available()} "
                 f"{torch.cuda.get_device_name(0) if torch.cuda.is_available() else ''}")

    # 1. Generate clips
    pos_train_dir = WORK_DIR / "positive_train"
    pos_test_dir  = WORK_DIR / "positive_test"
    adv_dir       = WORK_DIR / "adversarial"
    generate_positives(pos_train_dir, CONFIG["n_positive_train"], seed=1)
    generate_positives(pos_test_dir,  CONFIG["n_positive_test"],  seed=2)
    generate_adversarials(adv_dir,    CONFIG["n_adversarial"],    seed=3)

    # 2. Compute features
    pos_train_npy = WORK_DIR / "positive_train_features.npy"
    pos_test_npy  = WORK_DIR / "positive_test_features.npy"
    adv_npy       = WORK_DIR / "adversarial_features.npy"
    compute_features(pos_train_dir, pos_train_npy, CONFIG["augmentation_rounds"])
    compute_features(pos_test_dir,  pos_test_npy,  CONFIG["augmentation_rounds"])
    compute_features(adv_dir,       adv_npy,       CONFIG["augmentation_rounds"])

    # 3. Negatives (already downloaded in negatives_features/)
    neg_npy = NEGATIVES_FEATURES_DIR / "openwakeword_features_ACAV100M_2000_hrs_16bit.npy"
    val_fp_npy = NEGATIVES_FEATURES_DIR / "validation_set_features.npy"
    if not neg_npy.exists() or not val_fp_npy.exists():
        raise RuntimeError(f"negative feature files missing under {NEGATIVES_FEATURES_DIR}")

    # 4. Wrap into batch generator + val DataLoaders
    feature_data_files = {
        "ACAV100M_sample": str(neg_npy),
        "adversarial_negative": str(adv_npy),
        "positive": str(pos_train_npy),
    }
    logging.info(f"train batch sizes: {CONFIG['batch_n_per_class']}")
    train_gen = mmap_batch_generator(
        feature_data_files,
        n_per_class=CONFIG["batch_n_per_class"],
        data_transform_funcs=None,
        label_transform_funcs=None,
    )

    logging.info("building balanced X_val DataLoader...")
    val_loader = build_balanced_val_loader(pos_test_npy, neg_npy, neg_take=5000)
    logging.info(f"X_val: {len(val_loader.dataset)} examples, batch={val_loader.batch_size}")

    logging.info("building false-positive validation DataLoader...")
    fp_val_data = build_fp_val_loader(val_fp_npy)
    logging.info(f"fp_val: {len(fp_val_data.dataset)} windows, batch={fp_val_data.batch_size}")

    # 5. Build + train the model
    model = Model(
        n_classes=1,
        input_shape=tuple(CONFIG["input_shape"]),
        model_type="dnn",
        layer_dim=CONFIG["layer_size"],
        n_blocks=1,
    )
    logging.info(f"starting auto_train: steps={CONFIG['steps']} "
                 f"max_negative_weight={CONFIG['max_negative_weight']} "
                 f"target_fp_per_hour={CONFIG['target_fp_per_hour']}")
    model.auto_train(
        X_train=torch_wrap(train_gen),
        X_val=val_loader,
        false_positive_val_data=fp_val_data,
        steps=CONFIG["steps"],
        max_negative_weight=CONFIG["max_negative_weight"],
        target_fp_per_hour=CONFIG["target_fp_per_hour"],
    )

    # 6. Pick best single checkpoint (avoid degenerate-average bug)
    if not model.best_models:
        logging.error("training produced no qualifying checkpoints — try lowering target_fp_per_hour further")
        return 1
    # Sort by recall desc, then by fp count asc — the most "real Jarvis" model
    scored = list(zip(model.best_models, model.best_model_scores))
    scored.sort(key=lambda x: (-x[1].get("val_recall", 0.0), x[1].get("val_n_fp", 1e9)))
    best_model, best_score = scored[0]
    logging.info(f"selected best checkpoint: {best_score}")

    OUTPUT_MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model.export_model(best_model, "hey_leon", str(OUTPUT_MODEL_DIR))
    onnx_path = OUTPUT_MODEL_DIR / "hey_leon.onnx"
    if onnx_path.exists():
        logging.info(f"final model exported: {onnx_path} ({onnx_path.stat().st_size/1e3:.1f} KB)")
    else:
        # Sometimes the export saves into a subdir
        for f in OUTPUT_MODEL_DIR.rglob("hey_leon.onnx"):
            logging.info(f"exported model found at: {f}")
    logging.info("=" * 60)
    logging.info(f"hey_leon FULL training done: {time.strftime('%c')}")
    logging.info("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
