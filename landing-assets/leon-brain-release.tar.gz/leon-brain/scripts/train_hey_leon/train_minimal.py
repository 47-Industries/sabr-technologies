#!/usr/bin/env python3
"""
Minimal hey_leon ONNX trainer.

Skips the parts of the official openWakeWord notebook we don't need:
  - piper-sample-generator (we already have 1000 hand-synthesized positives)
  - AudioSet / FMA / MIT-RIR streaming downloads (no augmentation
    backgrounds — the model still learns the phrase, just slightly
    less robust to noisy environments. Good enough for v1.)
  - Adversarial-negative generation (the ACAV100M features file is
    large enough on its own; adversarials are a refinement)

What it does:
  1. Splits brain_state/voice/wake_train/positives/*.wav into
     train (800) / test (200)
  2. Augments + computes openwakeword features for both → .npy
  3. Loads the negative ACAV100M features (already downloaded)
  4. Calls openwakeword's Model.auto_train()
  5. Picks the best checkpoint, exports to ONNX
  6. Drops the ONNX into brain_state/voice/wake_models/hey_leon.onnx

Run from the venv:
    source ~/openWakeWord-train/venv/bin/activate
    python3 scripts/train_hey_leon/train_minimal.py
"""

from __future__ import annotations

import logging
import os
import random
import shutil
import sys
import time
from pathlib import Path

# Make openwakeword importable from the cloned training repo
TRAIN_REPO = "/home/deansabr/openWakeWord-train"
sys.path.insert(0, TRAIN_REPO)

import numpy as np
import torch
from openwakeword.data import augment_clips, mmap_batch_generator
from openwakeword.train import Model
from openwakeword.utils import compute_features_from_generator

PROJECT_ROOT = Path("/home/deansabr/Desktop/Leon-V1.3-SOURCE")
POSITIVES_DIR = PROJECT_ROOT / "brain_state/voice/wake_train/positives"
WORK_DIR = PROJECT_ROOT / "brain_state/voice/wake_train/run"
OUTPUT_MODEL_DIR = PROJECT_ROOT / "brain_state/voice/wake_models"
NEGATIVES_FEATURES_DIR = PROJECT_ROOT / "brain_state/voice/wake_train/negatives_features"

CONFIG = {
    "model_name": "hey_leon",
    "target_phrase": ["hey leon"],
    "n_samples": 800,                 # positive train target
    "n_samples_val": 200,             # positive test target
    "augmentation_rounds": 4,         # 4x reuse of positives → 3200 train clips
    "total_length_s": 2.0,            # seconds of audio per training example
                                       # (must yield 16 frames of OWW features
                                       #  to match the negative ACAV100M tensor)
    "sample_rate": 16000,
    "steps": 30000,
    "max_negative_weight": 1500,
    "target_fp_per_hour": 0.5,        # 11.3h validation set → allow ~6 false positives total
    "batch_n_per_class": {
        "ACAV100M_sample": 1024,
        "positive": 50,
    },
    "input_shape": (16, 96),
    "layer_size": 32,
}


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler("/tmp/hey_leon_training.log", mode="a"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def split_positives() -> tuple[Path, Path]:
    """Symlink positives into positive_train (n_samples) and positive_test
    (n_samples_val) under WORK_DIR. Idempotent."""
    train_dir = WORK_DIR / "positive_train"
    test_dir = WORK_DIR / "positive_test"
    train_dir.mkdir(parents=True, exist_ok=True)
    test_dir.mkdir(parents=True, exist_ok=True)
    if any(train_dir.iterdir()) and any(test_dir.iterdir()):
        n_tr = sum(1 for _ in train_dir.iterdir())
        n_te = sum(1 for _ in test_dir.iterdir())
        logging.info(f"positives already split: train={n_tr}, test={n_te}")
        return train_dir, test_dir

    all_wavs = sorted(POSITIVES_DIR.glob("*.wav"))
    if not all_wavs:
        raise RuntimeError(f"No positive WAVs found in {POSITIVES_DIR}")
    rng = random.Random(42)
    rng.shuffle(all_wavs)
    train_wavs = all_wavs[: CONFIG["n_samples"]]
    test_wavs = all_wavs[CONFIG["n_samples"]: CONFIG["n_samples"] + CONFIG["n_samples_val"]]
    for w in train_wavs:
        (train_dir / w.name).symlink_to(w)
    for w in test_wavs:
        (test_dir / w.name).symlink_to(w)
    logging.info(f"split positives: train={len(train_wavs)} test={len(test_wavs)}")
    return train_dir, test_dir


def compute_positive_features(positive_dir: Path, output_npy: Path, augmentation_rounds: int) -> None:
    """Augment each positive WAV and compute openwakeword features. Writes to output_npy."""
    if output_npy.exists():
        size_mb = output_npy.stat().st_size / 1e6
        logging.info(f"{output_npy.name} already exists ({size_mb:.1f} MB), skipping recompute")
        return
    output_npy.parent.mkdir(parents=True, exist_ok=True)
    clip_paths = [str(p) for p in positive_dir.glob("*.wav")] * augmentation_rounds
    n_total = len(clip_paths)
    total_length_samples = int(CONFIG["total_length_s"] * CONFIG["sample_rate"])
    logging.info(f"computing features from {n_total} augmented clips → {output_npy.name}")
    gen = augment_clips(
        clip_paths,
        total_length=total_length_samples,
        sr=CONFIG["sample_rate"],
        batch_size=64,
        # No background noise / RIR augmentation — simpler pipeline
        background_clip_paths=[],
        RIR_paths=[],
    )
    device = "gpu" if torch.cuda.is_available() else "cpu"
    compute_features_from_generator(
        gen,
        n_total=n_total,
        clip_duration=total_length_samples,
        output_file=str(output_npy),
        device=device,
        ncpu=4,
    )
    logging.info(f"saved {output_npy} ({output_npy.stat().st_size/1e6:.1f} MB)")


def main() -> int:
    setup_logging()
    logging.info("=" * 60)
    logging.info(f"hey_leon training start: {time.strftime('%c')}")
    logging.info("=" * 60)
    logging.info(f"CUDA: {torch.cuda.is_available()} {torch.cuda.get_device_name(0) if torch.cuda.is_available() else ''}")

    # 1. Split positives 800/200
    train_dir, test_dir = split_positives()

    # 2. Compute positive features
    pos_train_npy = WORK_DIR / "positive_train_features.npy"
    pos_test_npy  = WORK_DIR / "positive_test_features.npy"
    t0 = time.time()
    compute_positive_features(train_dir, pos_train_npy, CONFIG["augmentation_rounds"])
    compute_positive_features(test_dir,  pos_test_npy,  CONFIG["augmentation_rounds"])
    logging.info(f"feature compute took {(time.time()-t0)/60:.1f} min")

    # 3. Find negative features (already downloaded)
    neg_npy = NEGATIVES_FEATURES_DIR / "openwakeword_features_ACAV100M_2000_hrs_16bit.npy"
    val_fp_npy = NEGATIVES_FEATURES_DIR / "validation_set_features.npy"
    if not neg_npy.exists() or not val_fp_npy.exists():
        raise RuntimeError(f"negative feature files missing under {NEGATIVES_FEATURES_DIR}")

    # 4. Set up batch generators
    feature_data_files = {
        "ACAV100M_sample": str(neg_npy),
        "positive": str(pos_train_npy),
    }
    feature_data_files_val = {
        "ACAV100M_sample": str(neg_npy),    # val negatives reuse
        "positive": str(pos_test_npy),
    }
    logging.info(f"train batch sizes: {CONFIG['batch_n_per_class']}")
    train_gen = mmap_batch_generator(
        feature_data_files,
        n_per_class=CONFIG["batch_n_per_class"],
        data_transform_funcs=None,
        label_transform_funcs=None,
    )
    # auto_train wants iterators yielding (X_tensor, y_tensor) pairs.
    # `mmap_batch_generator` returns y as a string array of class names
    # ("positive" / "ACAV100M_sample"); we map to {1.0, 0.0}.
    def _torch_wrap(generator):
        for X, y in generator:
            X_t = torch.from_numpy(np.asarray(X)).float()
            # y is a numpy str array — positives → 1.0, anything else → 0.0
            y_num = np.array(
                [1.0 if str(label) == "positive" else 0.0 for label in y],
                dtype=np.float32,
            )
            y_t = torch.from_numpy(y_num)
            yield X_t, y_t

    # Wrap the false-positive validation data the way the upstream pipeline
    # does: load the (N, 96) features, slice into 16-frame windows, label
    # them all as 0 (negatives), and serve as a DataLoader of (X, y) batches.
    # Without this wrap, auto_train iterates rows of the raw numpy array
    # and crashes the moment it hits step `0.75 * max_steps`.
    def _build_fp_val_loader(fp_val_path: Path, input_frames: int = 16,
                             n_sample: int = 200_000):
        raw = np.load(str(fp_val_path), mmap_mode="r")
        n_windows = raw.shape[0] - input_frames
        if n_windows <= 0:
            raise RuntimeError(f"fp val features too short: shape={raw.shape}")
        n_take = min(n_windows, n_sample)
        stacked = np.stack(
            [raw[i:i+input_frames] for i in range(n_take)]
        ).astype(np.float32)
        labels = np.zeros(stacked.shape[0], dtype=np.float32)
        ds = torch.utils.data.TensorDataset(
            torch.from_numpy(stacked), torch.from_numpy(labels),
        )
        return torch.utils.data.DataLoader(ds, batch_size=4096, shuffle=False)

    # Build a balanced X_val DataLoader from positive_test_features.npy +
    # a chunk of ACAV100M negatives. Same finite-iterable shape required
    # by upstream's `for data in X_val` validation loop.
    def _build_balanced_val_loader(pos_features_path: Path, neg_features_path: Path,
                                   neg_take: int = 5000):
        pos = np.load(str(pos_features_path), mmap_mode="r").astype(np.float32)
        neg_raw = np.load(str(neg_features_path), mmap_mode="r")
        # Negatives are stored as (N, 16, 96) already (per the ACAV100M file)
        # so just take the first chunk
        n_take = min(neg_raw.shape[0], neg_take)
        neg = np.array(neg_raw[:n_take]).astype(np.float32)
        X = np.concatenate([pos, neg], axis=0)
        y = np.concatenate([
            np.ones(pos.shape[0], dtype=np.float32),
            np.zeros(neg.shape[0], dtype=np.float32),
        ])
        ds = torch.utils.data.TensorDataset(
            torch.from_numpy(X), torch.from_numpy(y),
        )
        return torch.utils.data.DataLoader(ds, batch_size=512, shuffle=False)

    # 5. Build + train the model
    model = Model(
        n_classes=1,
        input_shape=tuple(CONFIG["input_shape"]),
        model_type="dnn",
        layer_dim=CONFIG["layer_size"],
        n_blocks=1,
    )
    logging.info(f"model summary:\n{model.summary()}")

    # Build the validation DataLoaders now (helpers were defined above).
    # X_val must be FINITE — upstream's `for data in X_val` validation
    # loop has no break condition. A DataLoader stops when exhausted;
    # an mmap_batch_generator runs forever and hangs the run.
    logging.info("building balanced X_val DataLoader...")
    val_loader = _build_balanced_val_loader(pos_test_npy, neg_npy, neg_take=5000)
    logging.info(f"X_val DataLoader: {len(val_loader.dataset)} examples, "
                 f"batch_size={val_loader.batch_size}")
    # Wrap false-positive validation data as a DataLoader of 16-frame
    # windows (matches upstream's `false_positive_val_data` shape contract).
    logging.info("building false-positive validation DataLoader...")
    fp_val_data = _build_fp_val_loader(val_fp_npy)
    logging.info(f"fp_val DataLoader: {len(fp_val_data.dataset)} windows, "
                 f"batch_size={fp_val_data.batch_size}")

    logging.info(f"starting auto_train: steps={CONFIG['steps']} target_fp_per_hour={CONFIG['target_fp_per_hour']}")
    model.auto_train(
        X_train=_torch_wrap(train_gen),
        X_val=val_loader,                    # finite DataLoader, NOT generator
        false_positive_val_data=fp_val_data, # finite DataLoader, NOT raw npy
        steps=CONFIG["steps"],
        max_negative_weight=CONFIG["max_negative_weight"],
        target_fp_per_hour=CONFIG["target_fp_per_hour"],
    )

    # 6. Average the best checkpoints into one final model + export ONNX
    if not model.best_models:
        logging.error("training produced no qualifying checkpoints — try lowering target_fp_per_hour")
        return 1
    final = model.average_models(model.best_models)
    OUTPUT_MODEL_DIR.mkdir(parents=True, exist_ok=True)
    onnx_path = OUTPUT_MODEL_DIR / "hey_leon.onnx"
    model.export_model(final, "hey_leon", str(OUTPUT_MODEL_DIR))
    logging.info(f"final model exported: {onnx_path}")
    logging.info("=" * 60)
    logging.info(f"hey_leon training done: {time.strftime('%c')}")
    logging.info("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
