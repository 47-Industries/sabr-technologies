# Training a real `hey_leon` openWakeWord model

## Status

**Currently running:** Vosk-based wake detection (the `wake_word_vosk.py`
backend). Works fine, ~5–8% CPU on one core, wakes on "hey leon" or bare
"leon". This is the production path.

**Goal of this directory:** scaffold the training pipeline for a custom
openWakeWord ONNX model so we can drop the heavier Vosk path. A trained
model would give us:

- ~3x lower CPU during idle listening (1–3% vs 5–8%)
- ~500ms faster wake-to-action latency
- No rolling Vosk decoder running 24/7

The tradeoff is training time (2–4 hours overnight on CPU) and dataset
prep (~30 GB of pre-extracted negative-sample embeddings to download).

---

## Pipeline

1. **Synthesize positives** — already scripted, fast.
2. **Download negative-sample embeddings** — manual; one-time download
   from the openWakeWord HuggingFace repo (~30 GB).
3. **Run the training notebook** — official openWakeWord training
   notebook, takes 2–4 hours on a modern CPU.
4. **Drop in the resulting `hey_leon.onnx`** — set `LEON_WAKE_BACKEND=
   openwakeword` and `LEON_WAKE_MODEL_PATH=/path/to/hey_leon.onnx`.

---

## Step 1 — synthesize positives (5 minutes)

```bash
cd ~/Desktop/Leon-V1.3-SOURCE
python3 scripts/train_hey_leon/synthesize_positives.py --count 1000
```

Output: `brain_state/voice/wake_train/positives/*.wav` (1000 16kHz mono
WAVs, ~40MB total). Phrases vary across "hey leon", "okay leon", "yo
leon", "leon" with random length/noise scaling.

For better diversity, run with multiple piper voices:

```bash
# Default voice (en_GB-alan-medium)
python3 scripts/train_hey_leon/synthesize_positives.py --count 600 --seed 1

# Add a second voice if you've downloaded one
python3 scripts/train_hey_leon/synthesize_positives.py \
    --voice brain_state/voice/piper/en_US-amy-medium.onnx \
    --count 400 --seed 2
```

Download more piper voices from
<https://github.com/rhasspy/piper/blob/master/VOICES.md>.

---

## Step 2 — download negative-sample embeddings (one-time, ~30 GB)

openWakeWord's training notebook expects pre-extracted **embeddings**
(not raw audio) for the negative class. They're hosted on HuggingFace:

<https://huggingface.co/datasets/davidscripka/openwakeword_features>

Files needed (per their notebook):

- `audioset_features.npy` (~5 GB)
- `fma_features.npy` (~5 GB)
- `commonvoice_features.npy` (~10 GB)
- `imagined_voice_features.npy` (~5 GB)

```bash
mkdir -p brain_state/voice/wake_train/negatives_features
cd brain_state/voice/wake_train/negatives_features
huggingface-cli download davidscripka/openwakeword_features \
    --include "*.npy" --local-dir .
```

(Install `pip install --user huggingface_hub` if needed.)

---

## Step 3 — run the training notebook

Clone the upstream repo and run the official training notebook:

```bash
git clone https://github.com/dscripka/openWakeWord ~/openWakeWord-train
cd ~/openWakeWord-train
pip install -e ".[train]"
jupyter notebook notebooks/training_models.ipynb
```

Set these in the notebook's config cell:

```python
TARGET_PHRASE = "hey leon"
POSITIVE_DIR = "/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_train/positives"
NEGATIVE_FEATURES_DIR = "/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_train/negatives_features"
N_EPOCHS = 200          # 200 is enough for a recognizable phrase
TARGET_FALSE_POS_PER_HOUR = 0.5
```

Run the notebook end-to-end. It will export `hey_leon.onnx` to a
`models/` folder.

---

## Step 4 — wire it into the listener

```bash
cp ~/openWakeWord-train/models/hey_leon.onnx \
    brain_state/voice/wake_models/hey_leon.onnx
```

Then restart the brain server with:

```bash
LEON_WAKE_BACKEND=openwakeword \
LEON_WAKE_MODEL_PATH=/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_models/hey_leon.onnx \
LEON_WAKE_WORD=hey_leon \
python3 run.py
```

The `WakeWordListener` will load your custom model alongside the bundled
ones, and `[WAKE] listening for 'hey_leon'` will replace the Vosk pill.

---

## Quality bar

A good "hey leon" model should:

- Fire reliably on Dean's actual voice (>95% recall on "hey leon")
- Have <1 false positive per hour of household audio
- Not fire on "alexa", "hey jarvis", or "leo" (close phonemes)

If your trained model has too many false positives, retrain with a
**larger negative set** (add `commonvoice_features.npy` if not already
included) or raise `TARGET_FALSE_POS_PER_HOUR` lower in the notebook.

If recall is low on Dean's voice, generate **a few real recordings** of
Dean saying "hey leon" (~20-50 clips), drop them in the positives dir,
and retrain. Real samples beat synthetic for the target speaker.

---

## Why this isn't done yet

In-session: the negative-sample embeddings download alone is ~30 GB and
the training run is 2–4 hours. Outside session scope. The Vosk path is
the production answer until someone runs this overnight.
