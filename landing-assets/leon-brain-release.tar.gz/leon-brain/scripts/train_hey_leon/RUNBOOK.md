# hey_leon training runbook

Started overnight `2026-05-09 19:54 EDT`. Detached process — survives shell exits.

## Live status (run any of these)

```bash
# Process running?
pgrep -af train_minimal.py | grep -v /bin/bash

# Progress (training shows tqdm bars + per-step val metrics)
tail -50 /tmp/hey_leon_training.log

# Or follow live
tail -f /tmp/hey_leon_training.log

# GPU usage (training keeps the 3070 busy)
nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader

# Did the final ONNX get exported?
ls -la brain_state/voice/wake_models/hey_leon.onnx
```

## What "done" looks like

The final lines of the log will be:

```
[INFO] final model exported: .../brain_state/voice/wake_models/hey_leon.onnx
[INFO] hey_leon training done: <timestamp>
```

And `brain_state/voice/wake_models/hey_leon.onnx` will exist.

## Switching the brain to use the new model

Once `hey_leon.onnx` is present, edit how you launch the brain to set
these env vars:

```bash
LEON_WAKE_BACKEND=openwakeword \
LEON_WAKE_MODEL_PATH=/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_models/hey_leon.onnx \
LEON_WAKE_WORD=hey_leon \
python3 run.py
```

You can do this by creating a small `run_with_custom_wake.sh`:

```bash
#!/bin/bash
cd /home/deansabr/Desktop/Leon-V1.3-SOURCE
export LEON_WAKE_BACKEND=openwakeword
export LEON_WAKE_MODEL_PATH=/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_models/hey_leon.onnx
export LEON_WAKE_WORD=hey_leon
exec python3 run.py
```

## What was actually trained (be honest)

Minimal config, NOT the full upstream pipeline. Specifically:

- **Positives:** 1000 piper-synthesized "hey leon" WAVs (single voice = `en_GB-alan-medium`). 800 train / 200 test. Augmented 4x via audiomentations.
- **Negatives:** ACAV100M_2000_hrs_16bit features (17.3 GB pre-computed openwakeword features from generic audio).
- **Validation false-positive set:** validation_set_features.npy (~11.3 hours of speech/noise/music, also pre-computed).
- **Skipped:** AudioSet/FMA/MIT-RIR augmentation backgrounds, adversarial-negative generation (those would each have added significant download + compute).
- **Steps:** 30,000.
- **Target:** 0.5 false positives per hour at >20% recall.

This is good enough for a proof-of-concept "does Dean's voice trigger reliably". For production-grade noise-robust performance, you'd want to add the augmentation backgrounds and rerun.

## If it didn't produce a qualifying model

The `auto_train` step picks the best checkpoints based on (recall ≥ 20%,
fp/hr ≤ target, accuracy). If no checkpoint meets the bar:

```
[ERROR] training produced no qualifying checkpoints — try lowering target_fp_per_hour
```

Edit `scripts/train_hey_leon/train_minimal.py`, raise `target_fp_per_hour` to e.g. `2.0`, delete the `run/` dir, rerun. Or accept whatever the underlying `model.best_models` list contains and average those manually.

## Restart from the beginning

```bash
rm -rf brain_state/voice/wake_train/run
source ~/openWakeWord-train/venv/bin/activate
python3 scripts/train_hey_leon/train_minimal.py
```

Feature extraction is cached — if `run/positive_*_features.npy` already
exist they get reused, so a rerun mostly skips to training.

## Files / locations

| What | Where |
|---|---|
| Training script | `scripts/train_hey_leon/train_minimal.py` |
| Training log | `/tmp/hey_leon_training.log` |
| Venv | `~/openWakeWord-train/venv` |
| Cloned upstream | `~/openWakeWord-train` (reference only — trains via the pip package + cloned `Model` class) |
| Positive WAVs | `brain_state/voice/wake_train/positives/` (1000 WAVs) |
| Negative features | `brain_state/voice/wake_train/negatives_features/` (17.5 GB) |
| Working dir | `brain_state/voice/wake_train/run/` (positive_train, positive_test, *.npy) |
| Final model | `brain_state/voice/wake_models/hey_leon.onnx` |
