#!/usr/bin/env python3
"""Leon staleness watchdog.

Dreaming consolidates memory INSIDE the running process — it can never
reload code from disk. So a long uptime silently means Leon is running an
older self than the one on disk. This watches for that and says so.

Writes a report to brain_state/staleness.json which the brain reads and
surfaces in Leon's own body state, so he FEELS stale instead of
discovering it three days later in a log.
"""
import json, os, subprocess, time

ROOT = "/opt/leon-brain"
STATE = os.path.join(ROOT, "brain_state", "staleness.json")
# Directories whose .py files are loaded at import time by the brain process.
WATCH = ["brain", "server", "server/routers", "sensory", "tools", "business"]
IGNORE_PARTS = ("__pycache__", "workspaces", "brain_state", "node_modules",
                ".git", "venv", ".venv", "quarantine")


def brain_pid_and_start():
    """Return (pid, start_epoch) of the running run.py brain, or (None, None)."""
    try:
        out = subprocess.run(
            ["ps", "-eo", "pid,lstart,cmd"], capture_output=True, text=True, timeout=15
        ).stdout
    except Exception:
        return None, None
    for line in out.splitlines():
        if "run.py" not in line or "--neurons" not in line:
            continue
        parts = line.split()
        pid = parts[0]
        # lstart is 5 whitespace-separated fields: DOW MON DD HH:MM:SS YYYY
        lstart = " ".join(parts[1:6])
        try:
            started = time.mktime(time.strptime(lstart, "%a %b %d %H:%M:%S %Y"))
        except ValueError:
            return pid, None
        return pid, started
    return None, None


def newer_sources(since):
    """Source files modified after the process booted — code the brain can't see."""
    stale = []
    for rel in WATCH:
        d = os.path.join(ROOT, rel)
        if not os.path.isdir(d):
            continue
        for name in os.listdir(d):
            if not name.endswith(".py"):
                continue
            p = os.path.join(d, name)
            if any(part in p for part in IGNORE_PARTS):
                continue
            try:
                m = os.path.getmtime(p)
            except OSError:
                continue
            if m > since:
                stale.append({"file": os.path.relpath(p, ROOT),
                              "modified": time.strftime("%Y-%m-%d %H:%M",
                                                        time.localtime(m))})
    stale.sort(key=lambda s: s["modified"], reverse=True)
    return stale


def main():
    pid, started = brain_pid_and_start()
    now = time.time()
    if pid is None or started is None:
        report = {"checked": now, "error": "brain process not found"}
    else:
        stale = newer_sources(started)
        report = {
            "checked": now,
            "pid": pid,
            "started": time.strftime("%Y-%m-%d %H:%M", time.localtime(started)),
            "uptime_hours": round((now - started) / 3600, 1),
            "stale_count": len(stale),
            "stale_files": stale[:25],
            # The whole point: a plain-language line Leon can read about himself.
            "verdict": (
                f"STALE — {len(stale)} source file(s) changed since boot. "
                "Restart to run the current code."
                if stale else "current — running code matches disk."
            ),
        }
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    tmp = STATE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(report, f, indent=2)
    os.replace(tmp, STATE)          # atomic — never leave a half-written report
    print(report.get("verdict", report.get("error")))
    for s in report.get("stale_files", [])[:10]:
        print(f"  {s['modified']}  {s['file']}")


if __name__ == "__main__":
    main()
