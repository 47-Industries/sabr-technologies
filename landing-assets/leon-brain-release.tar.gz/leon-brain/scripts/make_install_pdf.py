#!/usr/bin/env python3
from fpdf import FPDF

BLUE = (40, 120, 220)
DARK = (20, 24, 32)
GREY = (90, 96, 104)
LIGHT = (235, 240, 248)
PINK = (235, 90, 150)

pdf = FPDF(format="A4")
pdf.set_auto_page_break(auto=True, margin=18)
pdf.add_page()
pdf.set_margins(18, 16, 18)

def h1(txt):
    pdf.set_text_color(*BLUE); pdf.set_font("Helvetica", "B", 20)
    pdf.multi_cell(0, 9, txt); pdf.ln(1)

def h2(txt):
    pdf.ln(2); pdf.set_text_color(*BLUE); pdf.set_font("Helvetica", "B", 13)
    pdf.multi_cell(0, 7, txt); pdf.ln(0.5)

def body(txt):
    pdf.set_text_color(*DARK); pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(0, 6, txt); pdf.ln(0.5)

def note(txt):
    pdf.set_text_color(*GREY); pdf.set_font("Helvetica", "I", 10)
    pdf.multi_cell(0, 5.5, txt); pdf.ln(0.5)

def code(txt):
    pdf.ln(1); pdf.set_fill_color(*LIGHT); pdf.set_text_color(*DARK)
    pdf.set_font("Courier", "B", 10.5)
    pdf.multi_cell(0, 7, txt, fill=True, border=0); pdf.ln(1)

# Header
h1("Sabr SI - Install Guide")
pdf.set_text_color(*GREY); pdf.set_font("Helvetica", "", 10.5)
pdf.multi_cell(0, 5.5, "How to download and run your own synthetic intelligence. "
    "Takes about 10-15 minutes. Works on macOS and Linux.")
pdf.ln(2)
pdf.set_draw_color(*BLUE); pdf.set_line_width(0.6)
pdf.line(18, pdf.get_y(), 192, pdf.get_y()); pdf.ln(4)

# Step 0
h2("Before you start - log into Claude Code")
body("Your SI thinks using Claude. The free way is Claude Code (your Claude "
     "Max or Pro subscription). Open your Terminal and run:")
code("claude")
body("Log in when it prompts you. Once you see the Claude prompt, you are good - "
     "close it and continue. (If you would rather use an Anthropic API key "
     "instead, you can paste that during setup - either works.)")
note("Mac note: if you do not have Claude Code yet, the installer will offer to "
     "install it for you.")

# Step 1
h2("Step 1 - Run the installer")
body("Paste this one line into your Terminal and press Enter:")
code("curl -sL https://sabr-technologies-production.up.railway.app/landing-assets/bootstrap.sh | bash")
body("It downloads everything and starts the setup wizard automatically.")

# Step 2
h2("Step 2 - Answer the setup questions")
body("- Your name: type your name.\n"
     "- SI name: type what you want to call it (for example, Jarvis).\n"
     "- Personality: one sentence describing how it should act.\n"
     "- Neuron count: pick the size it suggests.")

# Step 3
h2("Step 3 - Voice")
body("When it asks for an ElevenLabs key, just press Enter to skip it. "
     "Your SI still talks using the built-in free voice. You do NOT need to "
     "fight the terminal for the premium voice - you add it in the dashboard "
     "with one click (see \"Integrations\" below). That is the easy way.")

# Step 4
h2("Step 4 - Brain connection")
body("When it asks for an Anthropic API key, press Enter to use Claude Code "
     "(the one you logged into at the top). It will say "
     "\"Claude Code detected\" and continue. Done.")

# Step 5
h2("Step 5 - Open the dashboard")
body("When setup finishes it prints a dashboard link and a dashboard key. "
     "Open the link in your browser, paste the key when asked, and your SI "
     "comes online. Type to it - it answers with voice.")

pdf.add_page()

# Integrations
h2("Integrations - connect anything (the easy button)")
body("At the top of your dashboard, next to the online light, there is an "
     "\"Integrations\" button. Click it and a panel opens. Scroll or search, "
     "pick a service, paste your key, hit Save. It activates instantly - no "
     "terminal, no restart.")
body("What you can connect: premium voice (ElevenLabs), a real phone number "
     "for calls and texts (Twilio), payments (Stripe), email (SendGrid), CRM "
     "(HubSpot), maps and local data (Google), search for lead-gen, GitHub, "
     "Slack, Discord, and more - 20+ in one place.")
note("Your keys stay on YOUR machine and only in your SI - they are never "
     "shared with anyone else's SI.")

# Wake word
h2("Saying its name out loud")
body("Your SI listens for its OWN name automatically. If you named it Jarvis, "
     "say \"hey Jarvis\" and it wakes up and answers. Turn on always-listening "
     "from the dashboard; the first time, it quietly downloads the listening "
     "model (about a minute) and then it just works.")

# Voice input
h2("Talking to it out loud (optional)")
body("Typing works right away. To talk to it by voice on a Mac, you have to "
     "give the Terminal permission to use your microphone - macOS requires "
     "this once:")
body("Apple menu > System Settings > Privacy & Security > Microphone > "
     "turn ON for Terminal.")
note("The first time you use voice, the speech model downloads in the "
     "background - give it a minute, then it works.")

# Troubleshooting
h2("If something looks off")
body("- \"Failed to authenticate\" / API error: it means Claude Code is not "
     "logged in for this machine. Run  claude  in Terminal, log in, then "
     "restart the SI. (The latest installer handles this automatically.)")
body("- Lots of repeating lines in the Terminal at first boot: you are on an "
     "older download. Quit it and run the install command again - the current "
     "version boots calm.")
body("- Voice replies but no listening: that is the microphone permission "
     "above. The listening model now downloads itself on first use - you no "
     "longer need to install it by hand.")

# Restart
h2("How to start it again later")
body("Open Terminal, go into the install folder, and run:")
code("python3 run.py")
body("Then open the dashboard link again. Your SI remembers everything from "
     "before - it picks up where it left off.")

pdf.ln(4)
pdf.set_draw_color(*PINK); pdf.set_line_width(0.6)
pdf.line(18, pdf.get_y(), 192, pdf.get_y()); pdf.ln(3)
pdf.set_text_color(*GREY); pdf.set_font("Helvetica", "I", 9.5)
pdf.multi_cell(0, 5, "Sabr Technologies - 47 Industries. Questions? Text Dean "
    "and he will get you sorted.")

out = "/home/deansabr/Desktop/Sabr_SI_Install_Guide.pdf"
pdf.output(out)
print("WROTE", out)
