#!/usr/bin/env bash
# Watches for Railway issuing the real cert on www.corpgummies.com
LOG=/root/leon-out/corpgummies_cert_watch.log
while true; do
  CN=$(echo | timeout 15 openssl s_client -connect www.corpgummies.com:443 -servername www.corpgummies.com 2>/dev/null | openssl x509 -noout -subject 2>/dev/null)
  TS=$(date -u '+%Y-%m-%d %H:%M:%SZ')
  echo "$TS $CN" >> "$LOG"
  if echo "$CN" | grep -qi "corpgummies"; then
    echo "$TS *** CERT ISSUED — www.corpgummies.com is LIVE ***" >> "$LOG"
    exit 0
  fi
  sleep 300
done
