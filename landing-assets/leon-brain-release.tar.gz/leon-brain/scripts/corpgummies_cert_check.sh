#!/usr/bin/env bash
LOG=/root/leon-out/corpgummies_cert_watch.log
DONE=/root/leon-out/corpgummies_cert_ISSUED
[ -f "$DONE" ] && exit 0
CN=$(echo | timeout 15 openssl s_client -connect www.corpgummies.com:443 -servername www.corpgummies.com 2>/dev/null | openssl x509 -noout -subject 2>/dev/null)
TS=$(date -u '+%Y-%m-%d %H:%M:%SZ')
echo "$TS ${CN:-NO_RESPONSE}" >> "$LOG"
if echo "$CN" | grep -qi "corpgummies"; then
  echo "$TS *** CERT ISSUED - www.corpgummies.com LIVE ***" >> "$LOG"
  touch "$DONE"
fi
