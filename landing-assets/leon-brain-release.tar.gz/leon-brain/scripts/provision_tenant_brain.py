#!/usr/bin/env python3
"""Provision a hosted tenant brain — Phase 3.

Turns one tenant (created by the onboarding wizard, brain_mode=hosted) into
a running, isolated SI brain on this VPS:

    /opt/leon-tenants/<tenant_id>/
        leon-brain/       extracted client release tarball (same bytes a
                          local install gets — max parity with Phase 2)
        venv/             its own Python env
        start.sh          literal port/neurons (systemd ExecStart)
        provision.log     everything this script printed
        result.json       machine-readable outcome for the admin endpoint

Isolation: per-tenant unprivileged user (lt-<slug>), per-tenant systemd
unit (leon-tenant-<slug>.service, MemoryMax), per-tenant subdomain
(<slug>.sabrtechnologies.com via wildcard DNS + a Caddy conf reload).
The tenant's own registry is seeded with the SAME token the customer's
installer received, so their body's /ws/body dial-in authenticates.

Run as root (systemctl/useradd/caddy):  python3 scripts/provision_tenant_brain.py <tenant_id>
Idempotent-ish: re-running a failed provision cleans and retries; a tenant
that is already `ready` is left alone unless --force.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import urllib.request

ROOT = "/opt/leon-brain"
TENANTS_ROOT = "/opt/leon-tenants"
REGISTRY = os.path.join(TENANTS_ROOT, "registry.json")
TARBALL = os.path.join(ROOT, "landing", "leon-brain-release.tar.gz")
CADDY_DIR = "/etc/caddy/conf.d"
DOMAIN = "sabrtechnologies.com"
BIND_ADDRS = "2.25.174.126 2a02:4780:75:e5c7::1"
BASE_PORT = 8101
NEURONS = int(os.environ.get("TENANT_NEURONS", "50000"))
RESERVED_SLUGS = {"www", "api", "mail", "admin", "onboard", "dashboard",
                  "sabr", "leon", "download", "ws"}

sys.path.insert(0, ROOT)


def log(msg: str) -> None:
    print(f"[PROVISION] {msg}", flush=True)


def load_registry() -> dict:
    if os.path.exists(REGISTRY):
        with open(REGISTRY) as f:
            return json.load(f)
    return {"tenants": {}}


def save_registry(reg: dict) -> None:
    os.makedirs(TENANTS_ROOT, exist_ok=True)
    tmp = REGISTRY + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(reg, f, indent=2)
    os.replace(tmp, REGISTRY)


def slugify(name: str, taken: set) -> str:
    s = re.sub(r"-+", "-", re.sub(r"[^a-z0-9-]", "-", (name or "").lower())).strip("-")[:20]
    s = s or "si"
    if s in RESERVED_SLUGS or s in taken:
        base = s
        for i in range(2, 100):
            s = f"{base}-{i}"[:20]
            if s not in RESERVED_SLUGS and s not in taken:
                break
    return s


def alloc_port(reg: dict) -> int:
    used = {t["port"] for t in reg["tenants"].values() if "port" in t}
    port = BASE_PORT
    while port in used or _port_busy(port):
        port += 1
    return port


def _port_busy(port: int) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


def sh(cmd: list, **kw) -> subprocess.CompletedProcess:
    log("$ " + " ".join(cmd))
    return subprocess.run(cmd, check=True, **kw)


def main() -> int:
    force = "--force" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print("usage: provision_tenant_brain.py <tenant_id> [--force]")
        return 2
    tenant_id = args[0]

    from brain.tenant import tenant_manager
    tenant = tenant_manager.get_tenant(tenant_id)
    if tenant is None:
        log(f"FAIL: unknown tenant {tenant_id}")
        return 1
    md = tenant.metadata or {}

    reg = load_registry()
    entry = reg["tenants"].get(tenant_id, {})
    if entry.get("status") == "ready" and not force:
        log("already ready — use --force to reprovision")
        return 0

    home = os.path.join(TENANTS_ROOT, tenant_id)
    tree = os.path.join(home, "leon-brain")
    venv = os.path.join(home, "venv")
    os.makedirs(home, exist_ok=True)
    os.chmod(home, 0o700)  # tenants must not read each other's trees

    taken = {t["slug"] for tid, t in reg["tenants"].items()
             if tid != tenant_id and "slug" in t}
    slug = entry.get("slug") or slugify(md.get("si_name") or tenant.name, taken)
    port = entry.get("port") or alloc_port(reg)
    api_key = entry.get("api_key") or secrets.token_urlsafe(32)
    unit = f"leon-tenant-{slug}.service"
    user = f"lt-{slug}"[:31]
    brain_url = f"https://{slug}.{DOMAIN}"

    reg["tenants"][tenant_id] = {"slug": slug, "port": port, "api_key": api_key,
                                 "status": "provisioning", "si_name": md.get("si_name", ""),
                                 "started_at": time.time()}
    save_registry(reg)

    def fail(why: str) -> int:
        log(f"FAIL: {why}")
        reg["tenants"][tenant_id].update(status="failed", error=why)
        save_registry(reg)
        _write_result(home, ok=False, error=why, slug=slug, port=port)
        return 1

    # 1) Fresh tree from the release tarball (same artifact customers get).
    log(f"extracting release tarball → {tree}")
    if os.path.exists(tree):
        shutil.rmtree(tree)
    with tarfile.open(TARBALL, "r:gz") as tar:
        if hasattr(tarfile, "data_filter"):
            tar.extractall(home, filter="data")
        else:
            tar.extractall(home)

    # 2) Seed the tenant brain's OWN registry with the same token the
    #    customer's installer holds — their body must auth to THIS brain.
    # NOTE: brain/tenant.py's _registry_path() is brain_state/registry.json
    # (brain_state/tenants/ holds only the per-tenant knowledge DBs).
    seed_dir = os.path.join(tree, "brain_state")
    os.makedirs(seed_dir, exist_ok=True)
    with open(os.path.join(seed_dir, "registry.json"), "w") as f:
        json.dump({"tenants": [{
            "tenant_id": tenant.tenant_id,
            "name": tenant.name,
            "role": "admin",
            "token": tenant.token,
            "metadata": {k: md[k] for k in
                         ("si_name", "user_name", "services", "elevenlabs_voice_id")
                         if k in md},
        }], "channels": []}, f, indent=2)

    # 3) .env — identity, keys, and the hosted-mode switches.
    dec_keys = {}
    _decrypt = None
    try:
        from server.routers.onboarding_routes import _decrypt_api_key as _decrypt
        dec_keys = {name: _decrypt(enc)
                    for name, enc in (md.get("encrypted_service_keys") or {}).items()}
    except Exception as e:
        log(f"service-key decrypt skipped: {e}")
    # Anthropic key precedence: the CUSTOMER'S OWN key (BYO — billed to their
    # API account) wins; the Sabr-provided TENANT_ANTHROPIC_API_KEY is only a
    # fallback for a bundled "we supply the brain" tier.
    anthropic_key = ""
    anthropic_key_source = ""
    enc_customer_key = md.get("encrypted_api_key", "")
    if enc_customer_key and _decrypt is not None:
        try:
            anthropic_key = _decrypt(enc_customer_key).strip()
            if anthropic_key:
                anthropic_key_source = "customer"
        except Exception as e:
            log(f"customer anthropic-key decrypt failed: {e}")
    if not anthropic_key:
        anthropic_key = os.environ.get("TENANT_ANTHROPIC_API_KEY", "").strip()
        if not anthropic_key:
            try:
                for line in open("/etc/leon/secrets.env"):
                    if line.startswith("TENANT_ANTHROPIC_API_KEY="):
                        anthropic_key = line.split("=", 1)[1].strip()
            except OSError:
                pass
        if anthropic_key:
            anthropic_key_source = "sabr-provided"
    if anthropic_key_source:
        log(f"anthropic key source: {anthropic_key_source}")
    env_lines = [
        f"# Hosted Sabr SI — {md.get('si_name','')} for {md.get('user_name','')}",
        f"LEON_SI_NAME={md.get('si_name','')}",
        f"LEON_USER_NAME={md.get('user_name','')}",
        f"LEON_API_KEY={api_key}",
        f"LEON_HOSTED_TENANT_ID={tenant_id}",
        "IS_SANDBOX=1",
    ]
    if anthropic_key:
        env_lines.append(f"ANTHROPIC_API_KEY={anthropic_key}")
    else:
        log("WARNING: no Anthropic API key (customer didn't supply one and no "
            "TENANT_ANTHROPIC_API_KEY fallback) — brain boots but cannot think "
            "until a key is added to its .env")
    if md.get("elevenlabs_voice_id"):
        env_lines.append(f"ELEVENLABS_VOICE_ID={md['elevenlabs_voice_id']}")
    for k, v in dec_keys.items():
        if v and k.replace("_", "").isalnum():
            env_lines.append(f"{k}={v}")
    env_path = os.path.join(tree, ".env")
    fd = os.open(env_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write("\n".join(env_lines) + "\n")

    # 4) venv + deps (full requirements, core fallback — python here is
    #    bleeding-edge so some optional wheels may not exist yet).
    log("creating venv + installing deps (this is the slow part)")
    try:
        sh([sys.executable, "-m", "venv", venv], capture_output=True)
        pip = os.path.join(venv, "bin", "pip")
        r = subprocess.run([pip, "install", "-q", "-r",
                            os.path.join(tree, "requirements.txt")],
                           capture_output=True, text=True)
        if r.returncode != 0:
            log("full requirements failed — installing core set "
                f"(tail: {r.stderr.strip().splitlines()[-1] if r.stderr.strip() else '?'})")
            sh([pip, "install", "-q", "numpy", "scipy", "fastapi",
                "uvicorn[standard]", "websockets", "python-multipart",
                "python-dotenv", "Pillow", "mss", "psutil", "anthropic"],
               capture_output=True)
    except subprocess.CalledProcessError as e:
        return fail(f"venv/deps: {e}")

    # 5) Unprivileged user + ownership.
    if subprocess.run(["id", user], capture_output=True).returncode != 0:
        sh(["useradd", "--system", "--no-create-home",
            "--home-dir", home, "--shell", "/usr/bin/nologin", user],
           capture_output=True)
    sh(["chown", "-R", f"{user}:{user}", home], capture_output=True)

    # 6) start.sh + systemd unit.
    start = os.path.join(home, "start.sh")
    with open(start, "w") as f:
        f.write("#!/bin/bash\n"
                f"cd {tree}\n"
                f"exec {venv}/bin/python run.py --neurons {NEURONS} --port {port}\n")
    os.chmod(start, 0o755)
    sh(["chown", f"{user}:{user}", start], capture_output=True)
    with open(f"/etc/systemd/system/{unit}", "w") as f:
        f.write(f"""[Unit]
Description=Sabr hosted SI brain — {md.get('si_name','')} (tenant {tenant_id[:8]})
After=network-online.target

[Service]
User={user}
WorkingDirectory={tree}
Environment=HOME={home}
ExecStart={start}
Restart=on-failure
RestartSec=5
KillSignal=SIGUSR1
MemoryMax=3G
CPUWeight=50

[Install]
WantedBy=multi-user.target
""")
    sh(["systemctl", "daemon-reload"], capture_output=True)
    sh(["systemctl", "enable", "--now", unit], capture_output=True)

    # 7) Health: the brain must answer /api/state with its own key.
    log(f"waiting for brain on :{port} …")
    deadline = time.time() + 120
    ok = False
    while time.time() < deadline:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/api/state",
                                         headers={"Authorization": f"Bearer {api_key}"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status == 200:
                    ok = True
                    break
        except Exception:
            time.sleep(3)
    if not ok:
        j = subprocess.run(["journalctl", "-u", unit, "-n", "5", "--no-pager", "-o", "cat"],
                           capture_output=True, text=True).stdout.strip()
        return fail(f"brain did not answer /api/state within 120s (journal tail: {j[-400:]})")

    # 8) Caddy subdomain → tenant port.
    conf = os.path.join(CADDY_DIR, f"tenant-{slug}.conf")
    with open(conf, "w") as f:
        f.write(f"""{slug}.{DOMAIN} {{
\tbind {BIND_ADDRS}
\treverse_proxy 127.0.0.1:{port}
\tencode gzip
}}
""")
    try:
        sh(["caddy", "validate", "--config", "/etc/caddy/Caddyfile"], capture_output=True)
        sh(["systemctl", "reload", "caddy"], capture_output=True)
    except subprocess.CalledProcessError as e:
        os.unlink(conf)
        return fail(f"caddy config rejected: {e}")

    reg["tenants"][tenant_id].update(status="ready", brain_url=brain_url,
                                     unit=unit, user=user, ready_at=time.time())
    save_registry(reg)
    _write_result(home, ok=True, slug=slug, port=port, api_key=api_key,
                  brain_url=brain_url, unit=unit,
                  llm=anthropic_key_source or "NONE (add ANTHROPIC_API_KEY)")
    log(f"READY — {brain_url} (unit {unit}, port {port})")
    return 0


def _write_result(home: str, **kw) -> None:
    with open(os.path.join(home, "result.json"), "w") as f:
        json.dump(kw, f, indent=2)


if __name__ == "__main__":
    sys.exit(main())
