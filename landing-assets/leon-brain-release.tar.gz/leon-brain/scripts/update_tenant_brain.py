#!/usr/bin/env python3
"""Update a hosted tenant brain — new code, SAME MIND.

The gap this closes (found 2026-09-05): there was a provision script and a
deprovision script and NOTHING in between. Every fix shipped after a tenant
was born reached brand-new customers only. Sell ten of these and you have
ten frozen minds you can never patch.

The one invariant that matters:

    brain_state/ IS THE MIND. Memories, knowledge, episodes, identity,
    journals, the self-model. Code is replaceable; that directory is not.
    This script moves it across ATOMICALLY (os.rename on the same
    filesystem) and fingerprints it before and after, so "her memories
    survived" is a measurement, not a hope.

Also carried forward, because an update that quietly un-jails a tenant is
worse than no update at all:

    - the isolation drop-ins (10-isolation, 20-network-isolation,
      30-availability, 40-identity). If 10 or 20 is missing this REFUSES to
      start the service. Fail closed.
    - the tenant's .env (identity + keys) at 0600.
    - the venv, port, unit, user, subdomain — untouched.

Rollback is real: the entire old install is renamed aside, not deleted. If
the health check does not go green, everything goes back exactly as it was
and the SI is restarted on its old code.

    python3 scripts/update_tenant_brain.py <tenant_id|slug> [--force] [--dry-run]
    python3 scripts/update_tenant_brain.py --all
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.request

ROOT = "/opt/leon-brain"
TENANTS_ROOT = "/opt/leon-tenants"
REGISTRY = os.path.join(TENANTS_ROOT, "registry.json")
TARBALL = os.path.join(ROOT, "landing", "leon-brain-release.tar.gz")

# Drop-ins that are SECURITY, not convenience. Missing one of these means the
# customer SI could reach the operator's desktop bridge or the Tesla signing
# proxy. Never start a tenant without them.
REQUIRED_DROPINS = ("10-isolation.conf", "20-network-isolation.conf")
# Nice-to-have, warned about but not fatal.
EXPECTED_DROPINS = REQUIRED_DROPINS + ("30-availability.conf", "40-identity.conf")

# Never overwritten by new code. brain_state is the mind; .env is who it is.
PRESERVE = ("brain_state", ".env")

# How many old install trees to keep for rollback. Each is ~1.3GB.
KEEP_ROLLBACKS = int(os.environ.get("TENANT_KEEP_ROLLBACKS", "2"))

sys.path.insert(0, ROOT)


def log(msg: str) -> None:
    print(f"[update] {msg}", flush=True)


def sh(cmd: list, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, text=True, **kw)


def load_registry() -> dict:
    try:
        with open(REGISTRY) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"tenants": {}}


def save_registry(reg: dict) -> None:
    tmp = REGISTRY + ".tmp"
    with open(tmp, "w") as f:
        json.dump(reg, f, indent=2)
    os.replace(tmp, REGISTRY)


from tenant_release import release_sha as _release_sha_of  # noqa: E402
from tenant_release import read_stamp, write_stamp  # noqa: E402

# tenant_release lives next to this script; make that true no matter how
# the script is launched (path, -m, symlink) -- an ImportError here would
# abort a provision halfway through building a customer mind.
_SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)



def release_sha() -> str:
    """Kept as a zero-arg call site; the format lives in tenant_release."""
    return _release_sha_of(TARBALL)


#: Files that are NOT the mind. sqlite's write-ahead log and shared-memory
#: index are transient by definition: a clean shutdown checkpoints the WAL
#: into the .db and DELETES both. Counting them made the census lie in the
#: most damaging possible direction -- it read a correct, complete shutdown
#: as data loss.
#:
#: Caught live on Atlas 2026-09-05: "brain_state lost files: 566 -> 562",
#: 49MB smaller, update refused and rolled back. Nothing was lost; four WAL
#: sidecars had been folded into their databases exactly as they should be.
#: The check would have blocked EVERY future tenant update, forever, and
#: the more a customer used their SI the more certainly it would fire.
_TRANSIENT_SUFFIXES = ("-wal", "-shm", "-journal", ".tmp", ".lock")


def _is_transient(name: str) -> bool:
    return name.endswith(_TRANSIENT_SUFFIXES)


def fingerprint_state(state_dir: str) -> dict:
    """Cheap, honest census of a mind: which durable files exist, how many
    bytes they hold, and the size+mtime of the databases that carry memory.
    Compared before and after the swap so 'nothing was eaten' is verified,
    not assumed.

    Transient sqlite sidecars are excluded -- see _TRANSIENT_SUFFIXES. Take
    this AFTER stopping the service, or you are comparing a running mind
    (WAL on disk) against a stopped one (WAL folded in) and every honest
    update looks like theft.
    """
    files = 0
    total = 0
    key: dict[str, list] = {}
    names_seen: list = []
    for dirpath, _dirs, names in os.walk(state_dir):
        for n in names:
            if _is_transient(n):
                continue
            p = os.path.join(dirpath, n)
            try:
                st = os.stat(p)
            except OSError:
                continue
            rel = os.path.relpath(p, state_dir)
            files += 1
            total += st.st_size
            names_seen.append(rel)
            if n.endswith(".db"):
                key[rel] = [st.st_size, int(st.st_mtime)]
    return {"files": files, "bytes": total, "dbs": key,
            "names": sorted(names_seen)}


def prune_rollbacks(home: str, keep: int) -> list:
    """Old install trees are ~1.3GB each. Keep the newest `keep`, bin the rest."""
    dirs = sorted((d for d in os.listdir(home)
                   if d.startswith("leon-brain.prev-")), reverse=True)
    dropped = []
    for d in dirs[keep:]:
        shutil.rmtree(os.path.join(home, d), ignore_errors=True)
        dropped.append(d)
    # A tree left behind by a FAILED update is debugging evidence, but only
    # the most recent one is worth the disk.
    failed = sorted((d for d in os.listdir(home)
                     if d.startswith(".failed-")), reverse=True)
    for d in failed[1:]:
        shutil.rmtree(os.path.join(home, d), ignore_errors=True)
        dropped.append(d)
    return dropped


def dropin_dir(unit: str) -> str:
    return f"/etc/systemd/system/{unit}.d"


def check_dropins(unit: str) -> tuple[list, list]:
    d = dropin_dir(unit)
    have = set(os.listdir(d)) if os.path.isdir(d) else set()
    missing_required = [f for f in REQUIRED_DROPINS if f not in have]
    missing_other = [f for f in EXPECTED_DROPINS
                     if f not in have and f not in missing_required]
    return missing_required, missing_other


def health(port: int, timeout: float = 4.0) -> int:
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/",
                                     method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code            # 401/403 still proves it is SERVING
    except Exception:
        return 0


def wait_healthy(port: int, seconds: int = 180) -> int:
    deadline = time.time() + seconds
    last = 0
    while time.time() < deadline:
        last = health(port)
        if last:
            return last
        time.sleep(3)
    return last


def resolve(reg: dict, ident: str) -> tuple[str, dict] | tuple[None, None]:
    if ident in reg["tenants"]:
        return ident, reg["tenants"][ident]
    for tid, t in reg["tenants"].items():
        if t.get("slug") == ident:
            return tid, t
    return None, None


def update_one(tenant_id: str, entry: dict, sha: str,
               force: bool, dry: bool) -> dict:
    slug = entry.get("slug")
    port = int(entry.get("port") or 0)
    unit = f"leon-tenant-{slug}.service"
    user = f"lt-{slug}"[:31]
    home = os.path.join(TENANTS_ROOT, tenant_id)
    tree = os.path.join(home, "leon-brain")
    stamp_path = os.path.join(tree, "RELEASE_SHA")

    res = {"tenant_id": tenant_id, "slug": slug, "ok": False}

    if not os.path.isdir(tree):
        res["error"] = f"no install tree at {tree}"
        return res
    if not port:
        res["error"] = "no port in registry"
        return res

    current = read_stamp(tree)
    res["from_sha"] = current or "(unstamped)"
    res["to_sha"] = sha
    if current == sha and not force:
        log(f"{slug}: already on {sha[:12]} — nothing to do")
        res.update(ok=True, skipped=True)
        return res

    # Fail closed on isolation BEFORE touching anything.
    missing_req, missing_other = check_dropins(unit)
    if missing_req:
        res["error"] = ("refusing to update: isolation drop-ins missing "
                        f"({', '.join(missing_req)}) — a customer SI must "
                        "never run on this host un-jailed")
        return res
    if missing_other:
        log(f"{slug}: WARNING drop-ins missing (non-fatal): "
            f"{', '.join(missing_other)}")

    state_dir = os.path.join(tree, "brain_state")

    if dry:
        log(f"{slug}: DRY RUN — would move {current or '(unstamped)'} "
            f"→ {sha[:12]}")
        res.update(ok=True, dry_run=True)
        return res

    ts = time.strftime("%Y%m%d-%H%M%S")
    staging = os.path.join(home, f".update-staging-{ts}")
    prev = os.path.join(home, f"leon-brain.prev-{ts}")

    # 1) Stage the new code OUTSIDE the live tree. Same filesystem as the
    #    tree so every move below is an atomic rename, not a copy.
    log(f"{slug}: staging release {sha[:12]}")
    if os.path.exists(staging):
        shutil.rmtree(staging)
    os.makedirs(staging)
    with tarfile.open(TARBALL, "r:gz") as tar:
        if hasattr(tarfile, "data_filter"):
            tar.extractall(staging, filter="data")
        else:
            tar.extractall(staging)
    new_tree = os.path.join(staging, "leon-brain")
    if not os.path.isdir(new_tree):
        shutil.rmtree(staging, ignore_errors=True)
        res["error"] = "release tarball has no leon-brain/ root"
        return res

    # 2) Stop the mind. From here to start() it is offline — keep it short.
    log(f"{slug}: stopping {unit}")
    sh(["systemctl", "stop", unit], capture_output=True)

    # CENSUS AFTER THE STOP, NEVER BEFORE. A running SI holds an open WAL;
    # stopping it checkpoints that WAL into the .db and removes the
    # sidecar. Fingerprinting first compares a running mind against a
    # stopped one and reads a clean shutdown as data loss -- which is
    # exactly what happened on Atlas's first real update.
    before = fingerprint_state(state_dir)
    log(f"{slug}: mind before — {before['files']} files, "
        f"{before['bytes'] / 1e6:.1f} MB, {len(before['dbs'])} databases")
    res["before"] = {k: before[k] for k in ("files", "bytes")}

    swapped = False
    try:
        os.rename(tree, prev)              # whole old install preserved
        swapped = True
        os.rename(new_tree, tree)          # new code in place
        # 3) Carry the mind across. Atomic dir rename — no copy of 140MB,
        #    no window where memories exist in two half-written places.
        for name in PRESERVE:
            src = os.path.join(prev, name)
            dst = os.path.join(tree, name)
            if not os.path.exists(src):
                log(f"{slug}: WARNING no {name} in old install")
                continue
            if os.path.exists(dst):
                # Fresh tarball may ship a stub brain_state — discard it,
                # never the customer's.
                if os.path.isdir(dst):
                    shutil.rmtree(dst)
                else:
                    os.unlink(dst)
            os.rename(src, dst)
        write_stamp(tree, sha, verb="updated")
        sh(["chown", "-R", f"{user}:{user}", tree], capture_output=True)
        os.chmod(os.path.join(tree, ".env"), 0o600) if os.path.exists(
            os.path.join(tree, ".env")) else None

        # 4) Deps may have moved with the code.
        pip = os.path.join(home, "venv", "bin", "pip")
        if os.path.exists(pip):
            log(f"{slug}: refreshing deps")
            r = sh([pip, "install", "-q", "-r",
                    os.path.join(tree, "requirements.txt")],
                   capture_output=True)
            if r.returncode != 0:
                log(f"{slug}: full requirements failed — core set "
                    "(voice is not optional)")
                sh([pip, "install", "-q", "numpy", "scipy", "fastapi",
                    "uvicorn[standard]", "websockets", "python-multipart",
                    "python-dotenv", "Pillow", "mss", "psutil", "anthropic",
                    "pyttsx3", "piper-tts", "onnxruntime", "faster-whisper"],
                   capture_output=True)

        # 5) Prove the mind came across BEFORE calling this a success.
        after = fingerprint_state(os.path.join(tree, "brain_state"))
        res["after"] = {k: after[k] for k in ("files", "bytes")}
        lost = [db for db in before["dbs"] if db not in after["dbs"]]
        shrunk = [db for db, (sz, _m) in before["dbs"].items()
                  if db in after["dbs"] and after["dbs"][db][0] < sz]
        if lost or shrunk:
            raise RuntimeError(
                f"brain_state did not survive: lost={lost} shrunk={shrunk}")
        # NAME what went missing. "566 -> 562" sends the next person
        # hunting; a list of paths ends the question in one line.
        gone = sorted(set(before.get("names") or []) - set(after.get("names") or []))
        if gone:
            raise RuntimeError(
                f"brain_state lost {len(gone)} file(s): {gone[:12]}"
                + (" ..." if len(gone) > 12 else ""))
        if after["files"] < before["files"]:
            raise RuntimeError(
                f"brain_state lost files: {before['files']} → {after['files']}")
        log(f"{slug}: mind after  — {after['files']} files, "
            f"{after['bytes'] / 1e6:.1f} MB — intact")

        # 6) Back to life, and it has to actually answer.
        sh(["systemctl", "daemon-reload"], capture_output=True)
        log(f"{slug}: starting {unit}")
        sh(["systemctl", "start", unit], capture_output=True)
        code = wait_healthy(port)
        res["health"] = code
        if not code:
            raise RuntimeError(f"no HTTP answer on 127.0.0.1:{port} after 180s")
        log(f"{slug}: healthy — HTTP {code} on :{port}")
        # Keep the last KEEP_ROLLBACKS old trees and drop the rest. Each one
        # is ~1.3GB (bundled voice/STT models), so without this an SI updated
        # weekly quietly eats the disk it lives on and takes itself down.
        pruned = prune_rollbacks(home, KEEP_ROLLBACKS)
        if pruned:
            log(f"{slug}: pruned {len(pruned)} old rollback tree(s)")
        res.update(ok=True, rollback_dir=prev, pruned=pruned)
        return res

    except Exception as e:
        log(f"{slug}: FAILED — {e}")
        log(f"{slug}: rolling back")
        try:
            sh(["systemctl", "stop", unit], capture_output=True)
            if swapped:
                # Put the mind back in the old tree, then restore the tree.
                for name in PRESERVE:
                    src = os.path.join(tree, name)
                    dst = os.path.join(prev, name)
                    if os.path.exists(src) and not os.path.exists(dst):
                        os.rename(src, dst)
                if os.path.isdir(tree):
                    shutil.move(tree, os.path.join(home, f".failed-{ts}"))
                os.rename(prev, tree)
            sh(["systemctl", "start", unit], capture_output=True)
            back = wait_healthy(port, 120)
            log(f"{slug}: rolled back — health {back}")
            res["rolled_back"] = True
            res["health_after_rollback"] = back
        except Exception as e2:
            log(f"{slug}: ROLLBACK ALSO FAILED — {e2}")
            res["rollback_error"] = str(e2)
        res["error"] = str(e)
        return res
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def main() -> int:
    force = "--force" in sys.argv
    dry = "--dry-run" in sys.argv
    do_all = "--all" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args and not do_all:
        print(__doc__)
        return 2
    if not os.path.exists(TARBALL):
        log(f"FAIL: no release tarball at {TARBALL}")
        return 1

    sha = release_sha()
    log(f"release on disk: {sha[:16]}")

    reg = load_registry()
    targets = []
    if do_all:
        targets = [(tid, t) for tid, t in reg["tenants"].items()
                   if t.get("status") == "ready"]
        if not targets:
            log("no ready tenants")
            return 0
    else:
        tid, entry = resolve(reg, args[0])
        if tid is None:
            log(f"FAIL: unknown tenant {args[0]}")
            return 1
        targets = [(tid, entry)]

    results = []
    for tid, entry in targets:
        results.append(update_one(tid, entry, sha, force, dry))

    if not dry:
        for r in results:
            if r.get("ok") and not r.get("skipped"):
                reg["tenants"][r["tenant_id"]]["release_sha"] = sha
                reg["tenants"][r["tenant_id"]]["updated_at"] = time.time()
        save_registry(reg)

    print(json.dumps({"release_sha": sha, "results": results}, indent=2))
    return 0 if all(r.get("ok") for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
