#!/bin/bash
# One-shot setup so Dean's MacBook (and any tailnet device) can reach Leon
# + his tmux terminals from anywhere.
#
# What this does:
#   1. installs ttyd (web terminal) — needs sudo
#   2. starts the leon-ttyd user service (exposes tmux `agents` on :7681)
#   3. configures `tailscale serve` to put the dashboard on HTTPS via the
#      tailnet (browsers need HTTPS for mic/clipboard permissions)
#   4. prints the bookmark URLs to use on the MacBook
#
# Re-runnable — safe to run multiple times.
set -e

echo "=== 1. installing ttyd (one-time, requires sudo) ==="
if command -v ttyd >/dev/null 2>&1; then
    echo "    already installed: $(ttyd --version 2>&1 | head -1)"
else
    sudo apt update
    sudo apt install -y ttyd
fi

echo
echo "=== 2. enabling leon-ttyd.service (user mode) ==="
systemctl --user daemon-reload
systemctl --user enable --now leon-ttyd.service
sleep 1
systemctl --user --no-pager status leon-ttyd.service | head -6

echo
echo "=== 3. tailscale serve — dashboard at https://deanspc.tail87b46a.ts.net/ ==="
# Reset so re-runs don't pile up rules
tailscale serve reset 2>/dev/null || true
# Mount the FastAPI app on https root (uses tailscale's auto-TLS cert)
tailscale serve --bg --https=443 --set-path=/ http://127.0.0.1:8000
# Mount ttyd on /term (so we don't need a separate hostname)
tailscale serve --bg --https=443 --set-path=/term http://127.0.0.1:7681
echo
echo "    Active serve config:"
tailscale serve status

echo
echo "==================================================================="
echo "  Setup complete. Bookmark these on your MacBook (Tailscale-on):"
echo
echo "    Landing page  https://deanspc.tail87b46a.ts.net/laptop"
echo "    Dashboard     https://deanspc.tail87b46a.ts.net/"
echo "    Terminals     https://deanspc.tail87b46a.ts.net/term/"
echo
echo "  (Tailnet-only: not exposed publicly. Auth = your Tailscale identity.)"
echo "==================================================================="
