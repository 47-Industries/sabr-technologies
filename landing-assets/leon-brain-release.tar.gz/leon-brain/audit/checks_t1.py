"""T1 checks — release-artifact gates.

T1 operates on the finished object: the tarball that a customer downloads, its
digest sidecars, and the digest pinned into bootstrap.sh.  Where the repo
already has a gate that does this correctly, we SHELL OUT to it rather than
reimplementing it — a second implementation of the leak-scan would drift from
the first and the drift would be invisible.

Reused as-is:
    landing/verify_release.sh   (gates 1/2/3 — filenames, credential shapes, size)
    landing/build_release.sh    (parsed, not executed: it is a builder, and
                                 running it would rewrite the artifact we audit)
"""

from __future__ import annotations

import hashlib
import re
import tarfile
from pathlib import Path

from audit.framework import (BLOCKER, FAIL, MAJOR, MINOR, PASS, SKIP, Ctx,
                             Result, check, grep, new)

TARBALL = "landing/leon-brain-release.tar.gz"


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


@check("SI-ART-001-T1", 1, "landing/bootstrap.sh.sha256 matches the served bootstrap.sh",
       BLOCKER, layer="L1 (artifact bytes)", src="SECURITY §B, SI-ART-001", verified=True)
def check_si_art_001_t1(ctx: Ctx) -> Result:
    meta = check_si_art_001_t1._audit_meta
    boot = ctx.path("landing", "bootstrap.sh")
    side = ctx.path("landing", "bootstrap.sh.sha256")
    if not boot.is_file():
        return new(meta, SKIP, {"bootstrap.sh": "ABSENT"}, "")
    actual = _sha256(boot)
    if not side.is_file():
        return new(meta, FAIL,
                   {"bootstrap.sh.sha256": "ABSENT", "actual_sha256": actual,
                    "bootstrap_bytes": boot.stat().st_size},
                   "Publish a .sha256 sidecar next to bootstrap.sh and regenerate "
                   "it in the same commit that changes bootstrap.sh.")
    declared = (side.read_text().split() or [""])[0].strip()
    ev = {"declared": declared, "actual": actual,
          "bootstrap_bytes": boot.stat().st_size,
          "sidecar_mtime_older_than_script":
              side.stat().st_mtime < boot.stat().st_mtime}
    if declared != actual:
        return new(meta, FAIL, ev,
                   "Regenerate landing/bootstrap.sh.sha256 "
                   f"(sha256sum landing/bootstrap.sh -> {actual}). Anyone "
                   "following the documented verify step sees a mismatch and "
                   "cannot distinguish a stale sidecar from a tampered script.")
    return new(meta, PASS, ev)


@check("SI-ART-002-T1", 1, "Release tarball digest agrees across sidecar and bootstrap pin",
       BLOCKER, layer="L1 (artifact bytes)", src="SI-ART-002", verified=True)
def check_si_art_002_t1(ctx: Ctx) -> Result:
    meta = check_si_art_002_t1._audit_meta
    tb = ctx.path(TARBALL)
    if not tb.is_file():
        return new(meta, SKIP, {"tarball": f"{TARBALL} ABSENT"},
                   "Build a release before running T1 artifact gates.")
    actual = _sha256(tb)
    side_p = ctx.path(TARBALL + ".sha256")
    side = (side_p.read_text().split() or [""])[0].strip() if side_p.is_file() else None
    boot = ctx.read("landing/bootstrap.sh") or ""
    m = re.search(r'EXPECTED_RELEASE_SHA256="([0-9a-f]*)"', boot)
    pinned = m.group(1) if m else None
    ev = {"tarball": str(tb), "bytes": tb.stat().st_size, "actual": actual,
          "sidecar": side or "ABSENT", "bootstrap_pin": pinned or "ABSENT"}
    bad = []
    if side is None or side != actual:
        bad.append("sidecar mismatch/absent")
    if not pinned or pinned != actual:
        bad.append("bootstrap EXPECTED_RELEASE_SHA256 mismatch/absent")
    if bad:
        ev["problems"] = bad
        return new(meta, FAIL, ev,
                   "Re-run landing/build_release.sh so the tarball, its .sha256 "
                   "sidecar and the EXPECTED_RELEASE_SHA256 pin in bootstrap.sh "
                   "are produced together. A drifted pin fails every install's "
                   "digest check.")
    return new(meta, PASS, ev)


@check("SI-ART-003-T1", 1, "Release tarball passes landing/verify_release.sh (reused gate)",
       BLOCKER, layer="L1 (artifact bytes, existing gate)",
       src="SECURITY §B, verify_release.sh", verified=True)
def check_si_art_003_t1(ctx: Ctx) -> Result:
    """Shell out to the repo's own leak gate. We do NOT reimplement it."""
    meta = check_si_art_003_t1._audit_meta
    gate = ctx.path("landing", "verify_release.sh")
    tb = ctx.path(TARBALL)
    if not gate.is_file():
        return new(meta, SKIP, {"verify_release.sh": "ABSENT"},
                   "Restore landing/verify_release.sh; it is the leak gate.")
    if not tb.is_file():
        return new(meta, SKIP, {"tarball": f"{TARBALL} ABSENT"}, "")
    # Passing the file explicitly keeps the gate OFF the network: with no args it
    # curls the two live mirrors, which would make a T1 check network-dependent.
    r = ctx.run(["bash", str(gate), str(tb)], timeout=600)
    ev = {"argv": r["argv"], "rc": r["rc"], "duration_s": r["duration_s"],
          "stdout": r["stdout"][-4000:], "stderr": r["stderr"][-1000:]}
    if not r["ran"]:
        return new(meta, SKIP, ev, "The gate could not be executed at all.")
    # HARNESS sentinel discipline: an empty capture is INVALID, never PASS.
    if not r["stdout"].strip():
        return new(meta, SKIP, ev,
                   "verify_release.sh produced no output; an empty capture cannot "
                   "be read as 'clean' (SI-HARN-002).")
    if r["rc"] != 0 or "DO NOT SHIP" in r["stdout"]:
        return new(meta, FAIL, ev,
                   "The release tarball tripped the repo's own leak gate. Fix the "
                   "excludes in landing/build_release.sh and rebuild; do not "
                   "hand-edit the tarball.")
    return new(meta, PASS, ev)


@check("SI-ART-013-T1", 1, "Release provenance files exist (RELEASE_COMMIT, client builder)",
       MAJOR, layer="L1", src="SI-ART-013", verified=True)
def check_si_art_013_t1(ctx: Ctx) -> Result:
    meta = check_si_art_013_t1._audit_meta
    wanted = {
        "landing/RELEASE_COMMIT": ctx.path("landing", "RELEASE_COMMIT"),
        "landing/build_client_release.sh": ctx.path("landing", "build_client_release.sh"),
    }
    ev = {k: (str(v) if v.exists() else "ABSENT") for k, v in wanted.items()}
    ev["landing_dir_listing_sample"] = sorted(
        p.name for p in ctx.path("landing").glob("*.sh"))
    missing = [k for k, v in wanted.items() if not v.exists()]
    if missing:
        ev["missing"] = missing
        return new(meta, FAIL, ev,
                   "Write landing/RELEASE_COMMIT (the exact source commit of the "
                   "published tarball) during the build, and ship the client "
                   "builder alongside it. Without RELEASE_COMMIT nothing can map "
                   "the served bytes back to a commit.")
    return new(meta, PASS, ev)


@check("SI-ART-015-T1", 1, "Tarball ships the files eleven other checks depend on",
       BLOCKER, layer="L1 (tarball member list)", src="SI-ART-015, UX-25", verified=True)
def check_si_art_015_t1(ctx: Ctx) -> Result:
    meta = check_si_art_015_t1._audit_meta
    tb = ctx.path(TARBALL)
    if not tb.is_file():
        return new(meta, SKIP, {"tarball": f"{TARBALL} ABSENT"}, "")
    with tarfile.open(tb, "r:gz") as tf:
        names = tf.getnames()
    stripped = {n.split("/", 1)[1] if "/" in n else n for n in names}
    required = ["run.py", "tools/doctor.py", "doctor.sh", "doctor.bat",
                "MANIFEST.sha256", "server/__init__.py"]
    present = {r: (r in stripped) for r in required}
    ev = {"tarball_members": len(names),
          "top_level_prefixes": sorted({n.split("/", 1)[0] for n in names})[:5],
          "required_present": present}
    missing = [k for k, v in present.items() if not v]
    if missing:
        ev["missing"] = missing
        return new(meta, FAIL, ev,
                   "Add doctor.sh, doctor.bat and a generated MANIFEST.sha256 to "
                   "the tarball in build_release.sh. A support tool that does not "
                   "ship cannot be run by the customer who needs it.")
    return new(meta, PASS, ev)


@check("SI-HARN-009-T1", 1, "Tests ship with the release they verify",
       MAJOR, layer="L1 (tarball member list)", src="GAP-60, WEAK-41", verified=True)
def check_si_harn_009_t1(ctx: Ctx) -> Result:
    meta = check_si_harn_009_t1._audit_meta
    tb = ctx.path(TARBALL)
    if not tb.is_file():
        return new(meta, SKIP, {"tarball": f"{TARBALL} ABSENT"}, "")
    with tarfile.open(tb, "r:gz") as tf:
        names = tf.getnames()
    tests = [n for n in names if re.search(r"(^|/)tests/", n)]
    sidecar = sorted(ctx.path("landing").glob("*tests*"))
    ev = {"tarball_members": len(names), "test_members": len(tests),
          "test_sample": tests[:5],
          "test_bundle_sidecar_in_landing": [str(p) for p in sidecar] or "ABSENT"}
    if not tests and not sidecar:
        return new(meta, FAIL, ev,
                   "Publish tests/ at the release commit alongside the tarball "
                   "(a sidecar bundle is fine). Today 'what ships' and 'what is "
                   "tested' are different trees, so no T2+ run can be performed "
                   "against the shipped bytes.")
    return new(meta, PASS, ev)


@check("SI-ART-016-T1", 1, "Tarball carries no owner-private files the scrub is expected to remove",
       BLOCKER, layer="L1 (tarball member list)", src="SECURITY-37, gate G15",
       verified=True)
def check_si_art_016_t1(ctx: Ctx) -> Result:
    """Independent of SI-SEC-017: that one compares the two scrub LISTS,
    this one looks at what the artifact actually CONTAINS. If the tarball is
    clean, a missing scrub on the GUI path is harmless; if it is not, the scrub
    is load-bearing and its absence on two paths is a shipping defect."""
    meta = check_si_art_016_t1._audit_meta
    tb = ctx.path(TARBALL)
    if not tb.is_file():
        return new(meta, SKIP, {"tarball": f"{TARBALL} ABSENT"}, "")
    with tarfile.open(tb, "r:gz") as tf:
        infos = [(ti.name, ti.size) for ti in tf.getmembers() if ti.isfile()]
    private = re.compile(
        r"(^|/)(leon_notes\.txt|BUILD_PLAN_EMBODIMENT\.md|NEXT_SESSION\.md|"
        r"OWNERSHIP\.md|GOTCHAS\.md|BRAIN_REDESIGN\.md|SESSION_LOG\.md|"
        r"owner_facts\.py|30d_goals_executive_summary\.md|plan_body_30d\.md|"
        r"plan_client_delivery_30d\.md|plan_consciousness_30d\.md|"
        r"GIO_REBIRTH_HANDOFF\.md|top_interests_analysis\.md|"
        r"audio-learning-log\.md|WHAT_CHANGED_2026-06-14\.md)$|"
        r"(^|/)gio-landscaping/")
    hits = [{"member": n, "bytes": s} for n, s in infos if private.search(n)]
    ev = {"tarball_members": len(infos), "private_members": hits or "none"}
    if hits:
        return new(meta, FAIL, ev,
                   "Exclude these in build_release.sh. Relying on a post-download "
                   "scrub means every path that runs no scrub (GUI, git-clone) "
                   "keeps the owner's private files on a customer's disk.")
    return new(meta, PASS, ev)


@check("SI-UX-015-T1", 1, "An installer asset exists for every advertised OS",
       MAJOR, layer="L1 (asset bytes on disk)", src="UX-40, CROSSOS-30", verified=True)
def check_si_ux_015_t1(ctx: Ctx) -> Result:
    meta = check_si_ux_015_t1._audit_meta
    d = ctx.path("landing", "installers")
    if not d.is_dir():
        return new(meta, FAIL, {"landing/installers": "ABSENT"},
                   "Publish an installer per OS; a missing asset renders a 404 on "
                   "click for that platform's customers.")
    want = {
        "windows": r"\.exe$",
        "linux": r"linux",
        "macos": r"macos\.zip$",
        "macos-intel": r"macos-intel\.zip$",
    }
    files = [p for p in sorted(d.iterdir()) if p.is_file()
             and not p.name.endswith((".pre-fix-bak", ".bak"))]
    ev = {"assets": {p.name: p.stat().st_size for p in files}}
    found, missing = {}, []
    for os_name, pat in want.items():
        cand = [p for p in files if re.search(pat, p.name)]
        big = [p for p in cand if p.stat().st_size > 1_000_000]
        if big:
            found[os_name] = {"file": big[0].name, "bytes": big[0].stat().st_size}
        else:
            missing.append({"os": os_name,
                            "candidates": [{"file": p.name, "bytes": p.stat().st_size}
                                           for p in cand] or "none"})
    ev["per_os"] = found
    ev["missing_or_undersized"] = missing or "none"
    if missing:
        return new(meta, FAIL, ev,
                   "Build and publish the missing installer(s), and make the "
                   "landing page render 'temporarily unavailable' for an absent "
                   "asset rather than linking to a 404.")
    return new(meta, PASS, ev)


@check("SI-ART-017-T1", 1, "build_release.sh's own gates are still wired into the build",
       MAJOR, layer="L0 over the builder (the gates the artifact checks depend on)",
       src="build_release.sh", verified=True)
def check_si_art_017_t1(ctx: Ctx) -> Result:
    """We reuse build_release.sh's gates by AUDITING that they are still there
    and still abort the build. We do not execute it: running the builder would
    replace the very artifact the other T1 checks are auditing."""
    meta = check_si_art_017_t1._audit_meta
    text = ctx.read("landing/build_release.sh")
    if text is None:
        return new(meta, SKIP, {"landing/build_release.sh": "ABSENT"}, "")
    syntax = ctx.run(["bash", "-n", str(ctx.path("landing", "build_release.sh"))])
    gates = {}
    for n, pat in {
        "gate1_filenames": r"gate 1|secret/private files found",
        "gate2_content": r"gate 2|credential shapes found",
        "gate3_size": r"gate 3|ceiling is",
        "gate4_pii": r"gate 4",
        "gate5_windows_paths": r"gate 5|cannot be extracted on Windows",
        "digest_pin": r"EXPECTED_RELEASE_SHA256",
        "errexit": r"set -euo pipefail",
    }.items():
        gates[n] = grep(text, pat, "landing/build_release.sh")[:2] or "ABSENT"
    # A gate that reports but does not `exit 1` is decoration.
    aborts = len(grep(text, r"^\s*echo \"\[FAIL\].*exit 1|exit 1", "landing/build_release.sh"))
    ev = {"gates": gates, "exit_1_sites": aborts,
          "bash_n_rc": syntax["rc"], "bash_n_stderr": syntax["stderr"][-500:]}
    missing = [k for k, v in gates.items() if v == "ABSENT"]
    if missing or aborts == 0 or syntax["rc"] != 0:
        ev["missing_gates"] = missing
        return new(meta, FAIL, ev,
                   "Restore the missing gate(s) in landing/build_release.sh and "
                   "keep every gate's failure branch on `exit 1`. A gate that "
                   "prints [FAIL] and continues ships the leak it just found.")
    return new(meta, PASS, ev)
