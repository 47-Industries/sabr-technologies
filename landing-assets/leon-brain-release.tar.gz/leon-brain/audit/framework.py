"""Audit framework: registry, result type, and the evidence rule.

THE EVIDENCE RULE (the single most important rule in this suite):
    A check that cannot produce evidence reports SKIP, never PASS.

This is enforced mechanically in `finalize()`: a result whose status is PASS
with empty evidence is rewritten to SKIP with a note explaining that the check
could not observe anything.  This kills the entire class of
"`! grep` passed because the path was wrong / the file was missing / the
command errored" false greens that make an audit suite worse than no suite.

Every check is an ordinary function that takes a `Ctx` and returns a `Result`.
They are independently importable and independently callable:

    from audit.checks_t0 import check_si_sec_006_t0
    from audit.framework import Ctx
    print(check_si_sec_006_t0(Ctx()))
"""

from __future__ import annotations

import dataclasses
import subprocess
import time
import traceback
from pathlib import Path
from typing import Callable, Iterable

REPO = Path(__file__).resolve().parent.parent

PASS = "pass"
FAIL = "fail"
SKIP = "skip"
ERROR = "error"

BLOCKER = "blocker"
MAJOR = "major"
MINOR = "minor"


@dataclasses.dataclass
class Ctx:
    """Everything a check is allowed to know about the world.

    `repo` is overridable so the self-test can point checks at a scratch copy
    of the tree with a planted violation, instead of mutating the real repo.
    """

    repo: Path = REPO
    allow_network: bool = False

    def path(self, *parts: str) -> Path:
        return self.repo.joinpath(*parts)

    def read(self, *parts: str) -> str | None:
        """Read a text file, or None if it does not exist / is unreadable.

        Returning None (rather than "") is deliberate: a check must be able to
        tell "file absent" from "file empty", because those are different
        verdicts and conflating them is how absence-assertions go false-green.
        """
        p = self.path(*parts)
        try:
            return p.read_text(encoding="utf-8", errors="replace")
        except (OSError, IsADirectoryError):
            return None

    def run(self, argv: list[str], timeout: int = 300, cwd: Path | None = None):
        """Shell out, capturing everything. Never raises; returns a record."""
        t0 = time.time()
        try:
            cp = subprocess.run(
                argv,
                cwd=str(cwd or self.repo),
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            return {
                "argv": argv,
                "rc": cp.returncode,
                "stdout": cp.stdout,
                "stderr": cp.stderr,
                "duration_s": round(time.time() - t0, 3),
                "ran": True,
            }
        except (subprocess.TimeoutExpired, OSError) as exc:
            return {
                "argv": argv,
                "rc": None,
                "stdout": "",
                "stderr": f"{type(exc).__name__}: {exc}",
                "duration_s": round(time.time() - t0, 3),
                "ran": False,
            }


@dataclasses.dataclass
class Result:
    id: str
    tier: int
    title: str
    status: str
    severity: str = MAJOR
    # Evidence is the ACTUAL OBSERVED VALUE (file:line, digest, byte count,
    # captured stdout) — never a restatement of the claim.
    evidence: dict = dataclasses.field(default_factory=dict)
    remediation: str = ""
    layer: str = ""
    src: str = ""
    # False => no poisoned-fixture repro exists in test_audit.py, so a green
    # from this check has never been observed to be capable of going red.
    verified: bool = False
    notes: list[str] = dataclasses.field(default_factory=list)
    duration_s: float = 0.0

    def finalize(self) -> "Result":
        """Enforce the evidence rule. Called by the runner for every result."""
        if self.status == PASS and not self.evidence:
            self.status = SKIP
            self.notes.append(
                "EVIDENCE RULE: check reported pass with no observed value; "
                "downgraded to SKIP because a pass with no evidence is "
                "indistinguishable from a check that never ran."
            )
        if not self.verified:
            self.notes.append(
                "UNVERIFIED: no poisoned-fixture repro in audit/test_audit.py; "
                "this check has never been observed RED (SI-HARN-001)."
            )
        return self

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


# ── registry ──────────────────────────────────────────────────────────────
_REGISTRY: list[dict] = []


def check(check_id: str, tier: int, title: str, severity: str = MAJOR,
          layer: str = "", src: str = "", verified: bool = False):
    """Register a check function. The function returns a Result (or raises)."""

    def deco(fn: Callable[[Ctx], Result]):
        _REGISTRY.append({
            "id": check_id, "tier": tier, "title": title, "severity": severity,
            "layer": layer, "src": src, "verified": verified, "fn": fn,
        })
        fn._audit_meta = _REGISTRY[-1]  # type: ignore[attr-defined]
        return fn

    return deco


def registry() -> list[dict]:
    # Importing the check modules populates the registry.
    from audit import checks_t0, checks_t1  # noqa: F401
    return list(_REGISTRY)


def new(meta: dict, status: str, evidence: dict | None = None,
        remediation: str = "", notes: Iterable[str] = ()) -> Result:
    """Helper for check bodies: build a Result pre-filled from the metadata."""
    return Result(
        id=meta["id"], tier=meta["tier"], title=meta["title"], status=status,
        severity=meta["severity"], evidence=dict(evidence or {}),
        remediation=remediation, layer=meta["layer"], src=meta["src"],
        verified=meta["verified"], notes=list(notes),
    )


def run_check(entry: dict, ctx: Ctx) -> Result:
    """Run one check, converting any exception into an ERROR result.

    An exception is ERROR, never PASS and never FAIL: we do not know what the
    product does, so we must not claim either way.
    """
    t0 = time.time()
    try:
        res = entry["fn"](ctx)
    except Exception:  # noqa: BLE001 - deliberate: any failure is ERROR
        res = Result(
            id=entry["id"], tier=entry["tier"], title=entry["title"],
            status=ERROR, severity=entry["severity"],
            evidence={"traceback": traceback.format_exc()[-2000:]},
            remediation="Fix the check itself; an erroring check is not a pass.",
            layer=entry["layer"], src=entry["src"], verified=entry["verified"],
        )
    res.duration_s = round(time.time() - t0, 3)
    return res.finalize()


# ── small helpers shared by checks ────────────────────────────────────────
def grep(text: str, pattern, path_label: str) -> list[dict]:
    """Return [{file, line, text}] for every matching line. Evidence-shaped."""
    import re
    rx = pattern if hasattr(pattern, "search") else re.compile(pattern)
    out = []
    for i, line in enumerate(text.splitlines(), 1):
        if rx.search(line):
            out.append({"file": path_label, "line": i, "text": line.strip()[:200]})
    return out


def grep_tree(root: Path, pattern, globs=("*.py",), exclude=()) -> list[dict]:
    import re
    rx = pattern if hasattr(pattern, "search") else re.compile(pattern)
    hits = []
    for g in globs:
        for p in sorted(root.rglob(g)):
            sp = str(p)
            if any(x in sp for x in exclude):
                continue
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if rx.search(line):
                    hits.append({"file": sp, "line": i, "text": line.strip()[:200]})
    return hits
