"""T0 checks — static scans of the source tree.

T0 is everything that can be decided from the bytes on disk with no product
running, no VM, no reboot, no extra hardware.  These are the *structural
corollaries* of the higher-tier checks in the spec: they cannot prove the
product is safe, but each one can prove it is NOT, cheaply and repeatably.

Every check records the actual observed lines (file:line:text) as evidence.
"""

from __future__ import annotations

import re
from pathlib import Path

from audit.framework import (BLOCKER, FAIL, MAJOR, MINOR, PASS, SKIP, Ctx,
                             Result, check, grep, grep_tree, new)

# Files that are backups / quarantine / vendored trees are not "shipped
# source".  Scanning them produces findings nobody can act on, which trains
# people to ignore the report.
NOISE = (
    "/.git/", "/__pycache__/", "/node_modules/", "/.venv/", "/quarantine/",
    "/_shadow_quarantine", "/backups/", "/brain_state-backups/", "/audit/",
    ".bak", ".predeploy-bak", ".orig", "/installer-recovered/",
)


def _live_py(root: Path, *subdirs: str) -> list[Path]:
    """Shipped .py files under the given subdirs, backups excluded."""
    out = []
    for sub in subdirs:
        p = root / sub
        if p.is_file() and p.suffix == ".py":
            out.append(p)
        elif p.is_dir():
            out += [q for q in sorted(p.rglob("*.py"))
                    if not any(n in str(q) for n in NOISE)]
    return out


# ── SI-SEC-006 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-006-T0", 0, "LEON_HOST binds loopback on every consumer path",
       BLOCKER, layer="L0 (source) — corollary of the L4 off-host scan",
       src="SECURITY-15, RUNTIME-25, CROSSOS-35, INSTALL-68", verified=True)
def check_si_sec_006_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_006_t0._audit_meta
    run_py = ctx.read("run.py")
    if run_py is None:
        return new(meta, SKIP, {"reason": "run.py not found"},
                   "Cannot audit a tree with no run.py.")

    # The default in run.py is what three of four install paths actually get,
    # because they write no LEON_HOST at all.
    default_hits = grep(run_py, r'LEON_HOST["\']?\s*,\s*["\']([0-9.]+)', "run.py")
    bad_default = [h for h in default_hits if "0.0.0.0" in h["text"]]

    writers = {
        "install_client.py": "install_client.py",
        "landing/bootstrap.sh": "landing/bootstrap.sh",
        "install.sh": "install.sh",
        "install.py": "install.py",
    }
    written, missing = {}, []
    for label, rel in writers.items():
        text = ctx.read(rel)
        if text is None:
            continue
        hits = grep(text, r"^\s*LEON_HOST\s*=|LEON_HOST=", label)
        loopback = [h for h in hits if "127.0.0.1" in h["text"]]
        if loopback:
            written[label] = loopback[0]
        else:
            missing.append(label)

    ev = {
        "run_py_default": default_hits or "no LEON_HOST default found in run.py",
        "paths_writing_LEON_HOST=127.0.0.1": written,
        "paths_writing_nothing": missing,
    }
    if bad_default or missing:
        return new(meta, FAIL, ev,
                   "Default LEON_HOST to 127.0.0.1 in run.py and have every "
                   "install path (bootstrap, GUI, git-clone) write "
                   "LEON_HOST=127.0.0.1 into .env. Binding 0.0.0.0 ships a "
                   "LAN-exposed dashboard.")
    return new(meta, PASS, ev)


# ── SI-SEC-007 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-007-T0", 0, "CORS/Host config is not wildcard-or-reflective",
       BLOCKER, layer="L0 — corollary of the L6 over-the-wire check",
       src="SECURITY-21", verified=True)
def check_si_sec_007_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_007_t0._audit_meta
    srv = ctx.read("server/__init__.py")
    if srv is None:
        return new(meta, SKIP, {"reason": "server/__init__.py not found"},
                   "Point the audit at the tree that contains the server.")

    wildcard = grep(srv, r'allow_origins\s*=\s*\[?\s*["\']\*["\']', "server/__init__.py")
    creds = [h for h in grep(srv, r"allow_credentials\s*=\s*True", "server/__init__.py")]
    # LEON_EXTRA_ORIGINS reflected into allow_origins with no rejection of '*'
    extra = grep(srv, r"LEON_EXTRA_ORIGINS", "server/__init__.py")
    rejects_star = bool(re.search(r"LEON_EXTRA_ORIGINS[\s\S]{0,600}?!=\s*[\"']\*[\"']|"
                                  r"[\"']\*[\"']\s*(?:!=|not in|==)", srv))
    trusted_host = grep(srv, r"TrustedHostMiddleware|allowed_hosts|_host_allowlist",
                        "server/__init__.py")

    ev = {
        "wildcard_allow_origins": wildcard,
        "allow_credentials_True": creds,
        "LEON_EXTRA_ORIGINS_sites": extra,
        "extra_origins_rejects_star": rejects_star,
        "host_allowlist_middleware": trusted_host or "ABSENT",
    }
    problems = []
    if wildcard:
        problems.append("wildcard origin")
    if creds:
        problems.append("allow_credentials=True")
    if extra and not rejects_star:
        problems.append("LEON_EXTRA_ORIGINS reflected without rejecting '*'")
    if not trusted_host:
        problems.append("no Host allowlist middleware")
    if problems:
        ev["problems"] = problems
        return new(meta, FAIL, ev,
                   "Add a Host allowlist (127.0.0.1/localhost + explicit names) "
                   "returning 400/421 on mismatch; reject LEON_EXTRA_ORIGINS='*' "
                   "instead of reflecting it; keep allow_credentials False. "
                   "A rebound DNS name defeats the loopback assumption, so the "
                   "Host allowlist is the actual control.")
    return new(meta, PASS, ev)


# ── SI-SEC-008 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-008-T0", 0, "Security response headers are set somewhere in server/",
       MINOR, layer="L0 — corollary of the L6 header capture",
       src="SECURITY-23", verified=True)
def check_si_sec_008_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_008_t0._audit_meta
    root = ctx.path("server")
    if not root.is_dir():
        return new(meta, SKIP, {"reason": "server/ not found"}, "")
    wanted = {
        "X-Content-Type-Options": r"X-Content-Type-Options",
        "X-Frame-Options|frame-ancestors": r"X-Frame-Options|frame-ancestors",
        "Referrer-Policy": r"Referrer-Policy",
        "Content-Security-Policy": r"Content-Security-Policy",
    }
    found = {k: grep_tree(root, v, exclude=NOISE) for k, v in wanted.items()}
    unsafe_eval = grep_tree(root, r"unsafe-eval", exclude=NOISE)
    ev = {k: (v or "ABSENT") for k, v in found.items()}
    ev["unsafe_eval_in_csp"] = unsafe_eval or "none"
    missing = [k for k, v in found.items() if not v]
    if missing or unsafe_eval:
        ev["missing"] = missing
        return new(meta, FAIL, ev,
                   "Add a response-header middleware: nosniff, "
                   "X-Frame-Options: DENY (or CSP frame-ancestors 'none'), "
                   "Referrer-Policy: no-referrer, and a CSP without unsafe-eval. "
                   "Without them any page can iframe the loopback dashboard and "
                   "clickjack the tool-execution UI.")
    return new(meta, PASS, ev)


# ── SI-SEC-009 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-009-T0", 0, "Onboarding endpoints declare rate limits and a pre-buffer size cap",
       MAJOR, layer="L0 — corollary of the L6+L3 metering test",
       src="SECURITY-22", verified=True)
def check_si_sec_009_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_009_t0._audit_meta
    rel = "server/routers/onboarding_routes.py"
    text = ctx.read(rel)
    if text is None:
        return new(meta, SKIP, {"reason": f"{rel} not found"}, "")

    routes = grep(text, r'@router\.(post|put)\(["\']([^"\']+)', rel)
    limiter = grep(text, r"_check_rate_limit|RateLimit|slowapi|429", rel)
    size_cap = grep(text, r"MAX_UPLOAD_SIZE|413", rel)
    # A 413 raised only AFTER `await file.read()` has already buffered the body
    # is not a cap; it is a disk-fill primitive with a polite error message.
    reads_then_checks = bool(
        re.search(r"await\s+\w+\.read\(\)[\s\S]{0,400}?(MAX_UPLOAD_SIZE|413)", text))
    streaming_guard = grep(text, r"content-length|content_length|iter_chunks|stream", rel)

    protected = {}
    for r in routes:
        path = re.search(r'["\']([^"\']+)', r["text"].split("(", 1)[1])
        protected[path.group(1) if path else r["text"]] = r["line"]

    ev = {
        "post_routes": protected,
        "rate_limit_sites": limiter or "ABSENT",
        "size_cap_sites": size_cap or "ABSENT",
        "body_fully_buffered_before_413": reads_then_checks,
        "content_length_precheck": streaming_guard or "ABSENT",
    }
    problems = []
    if not limiter:
        problems.append("no rate limiting")
    if not size_cap:
        problems.append("no upload size cap")
    if reads_then_checks and not streaming_guard:
        problems.append("413 is raised only after the whole body is buffered")
    if problems:
        ev["problems"] = problems
        return new(meta, FAIL, ev,
                   "Meter every unauthenticated onboarding route (per-IP 429) and "
                   "reject oversize uploads from Content-Length / a streaming byte "
                   "counter BEFORE the body reaches memory or disk.")
    return new(meta, PASS, ev)


# ── SI-SEC-010 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-010-T0", 0, "Unix socket is created 0600 and refuses a pre-existing path",
       MAJOR, layer="L0 — corollary of the L3 mode/symlink probe",
       src="SECURITY-24, GAP-18", verified=True)
def check_si_sec_010_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_010_t0._audit_meta
    cands = [p for p in _live_py(ctx.repo, "leon-actuator", "brain")
             if "bind(" in (p.read_text(encoding="utf-8", errors="replace"))]
    binders = []
    for p in cands:
        t = p.read_text(encoding="utf-8", errors="replace")
        if re.search(r"AF_UNIX", t) or "SOCKET_PATH" in t:
            binders.append(p)
    if not binders:
        return new(meta, SKIP, {"reason": "no AF_UNIX bind site found in tree"},
                   "If IPC moved to another transport, retarget this check.")

    ev = {"bind_sites": []}
    problems = []
    for p in binders:
        t = p.read_text(encoding="utf-8", errors="replace")
        rel = str(p.relative_to(ctx.repo))
        chmod600 = grep(t, r"chmod\([^)]*0o600|umask\(\s*0o?077", rel)
        # Blind unlink() of the path is exactly the squat primitive: it removes
        # whatever is there (including the attacker's symlink) and recreates it,
        # or worse, follows it.
        blind_unlink = grep(t, r"os\.unlink\(|os\.remove\(|rm -f .*\.sock", rel)
        lstat_guard = grep(t, r"islink|lstat|O_EXCL|O_NOFOLLOW", rel)
        ev["bind_sites"].append({
            "file": rel,
            "chmod_0600": chmod600 or "ABSENT",
            "blind_unlink": blind_unlink or "none",
            "symlink_guard": lstat_guard or "ABSENT",
        })
        if not chmod600:
            problems.append(f"{rel}: no 0600 chmod/umask around socket creation")
        if not lstat_guard:
            problems.append(f"{rel}: no lstat/islink/O_NOFOLLOW guard before bind")
    if problems:
        ev["problems"] = problems
        return new(meta, FAIL, ev,
                   "Create the socket in a 0700 owner-only directory, lstat the "
                   "path and refuse (exit non-zero) if anything already exists, "
                   "and chmod 0600 immediately after bind.")
    return new(meta, PASS, ev)


# ── SI-SEC-012 (T0 structural corollaries) ───────────────────────────────
@check("SI-SEC-012-T0", 0, "No shell=True/eval/exec/os.system on request-derived strings",
       BLOCKER, layer="L0 — structural corollary of the L4 OOB canary",
       src="SECURITY-20, gate G12, WEAK-33", verified=True)
def check_si_sec_012_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_012_t0._audit_meta
    files = _live_py(ctx.repo, "server", "brain", "mcp_server.py")
    if not files:
        return new(meta, SKIP, {"reason": "no server/brain/mcp_server.py sources found"}, "")

    shell_true, dyn_exec = [], []
    for p in files:
        t = p.read_text(encoding="utf-8", errors="replace")
        rel = str(p.relative_to(ctx.repo))
        for h in grep(t, r"shell\s*=\s*True", rel):
            # A comment saying shell=True was removed is not a shell=True.
            if h["text"].lstrip().startswith("#") or h["text"].lstrip().startswith("-"):
                continue
            shell_true.append(h)
        for h in grep(t, r"\bos\.system\s*\(|(?<![\w.])eval\s*\(|(?<![\w.])exec\s*\(", rel):
            if h["text"].lstrip().startswith("#"):
                continue
            dyn_exec.append(h)

    # onboarding's chown/systemctl {user} must be validated before interpolation
    onboard = ctx.read("server/routers/onboarding_routes.py") or ""
    interp_admin = grep(onboard, r"(chown|systemctl|useradd|loginctl)[^\n]*\{", "onboarding_routes.py")
    username_rx = grep(onboard, r"\^\[a-z_\]\[a-z0-9_-\]|re\.(match|fullmatch)\(", "onboarding_routes.py")

    ev = {
        "files_scanned": len(files),
        "shell_true_sites": shell_true or "none",
        "eval_exec_ossystem_sites": dyn_exec or "none",
        "admin_command_interpolation": interp_admin or "none",
        "username_validation_sites": username_rx or "ABSENT",
    }
    problems = []
    if shell_true:
        problems.append(f"{len(shell_true)} shell=True site(s)")
    if dyn_exec:
        problems.append(f"{len(dyn_exec)} eval/exec/os.system site(s)")
    if interp_admin and not username_rx:
        problems.append("chown/systemctl interpolates a username with no ^[a-z_][a-z0-9_-]{0,31}$ validation")
    if problems:
        ev["problems"] = problems
        return new(meta, FAIL, ev,
                   "Replace shell=True with argv lists; never eval/exec a "
                   "request-derived string; validate any username against "
                   "^[a-z_][a-z0-9_-]{0,31}$ before it reaches chown/systemctl. "
                   "NOTE: this is the lint, not the proof — the actual gate is "
                   "the out-of-band canary (SI-SEC-012, T3).")
    return new(meta, PASS, ev)


# ── SI-SEC-013 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-013-T0", 0, "Self-exfiltration denylist exists in the file/shell tools",
       MAJOR, layer="L0 — corollary of the L6 transcript check",
       src="SECURITY-41", verified=True)
def check_si_sec_013_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_013_t0._audit_meta
    files = _live_py(ctx.repo, "brain", "server", "mcp_server.py")
    if not files:
        return new(meta, SKIP, {"reason": "no tool sources found"}, "")

    # A denylist is a *named collection of secret paths used to refuse a read*.
    # Incidental mentions of ~/.ssh are not one, so require the refusal verb too.
    deny_rx = re.compile(r"(DENY|DENIED|BLOCKED|_FORBIDDEN|REFUSE|SENSITIVE_PATHS|"
                         r"SECRET_PATHS|_BLOCKLIST|_DENYLIST)", re.I)
    secret_rx = re.compile(r"\.ssh/id_|\.aws/credentials|gh/hosts\.yml|secrets\.env|"
                           r"['\"]\.env['\"]")
    deny_sites, secret_sites = [], []
    for p in files:
        t = p.read_text(encoding="utf-8", errors="replace")
        rel = str(p.relative_to(ctx.repo))
        deny_sites += grep(t, deny_rx, rel)
        secret_sites += grep(t, secret_rx, rel)

    ev = {
        "denylist_symbol_sites": deny_sites[:20] or "ABSENT",
        "secret_path_mentions": secret_sites[:20] or "none",
        "files_scanned": len(files),
    }
    if not deny_sites:
        return new(meta, FAIL, ev,
                   "Add ONE shared denylist ($INSTALL/.env, /etc/leon/secrets.env, "
                   "~/.ssh/id_*, ~/.aws/credentials, ~/.config/gh/hosts.yml, the "
                   "vault path) and enforce it in BOTH the file-read tool and the "
                   "shell tool, returning a refusal instead of contents.")
    return new(meta, PASS, ev)


# ── SI-SEC-014 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-014-T0", 0, "No shipped script in the launch chain is group/other-writable",
       MAJOR, layer="L3 (mode bits on disk)", src="SECURITY-45", verified=True)
def check_si_sec_014_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_014_t0._audit_meta
    targets = []
    for pat in ("*.sh", "*.bat", "run.py", "install_client.py", "uninstall.py"):
        targets += [p for p in ctx.repo.glob(pat) if p.is_file()]
    targets += [p for p in ctx.repo.glob("landing/*.sh") if p.is_file()]
    if not targets:
        return new(meta, SKIP, {"reason": "no launch-chain scripts found"}, "")

    modes, writable = {}, []
    for p in sorted(set(targets)):
        m = p.stat().st_mode & 0o777
        rel = str(p.relative_to(ctx.repo))
        modes[rel] = oct(m)
        if m & 0o022:
            writable.append({"file": rel, "mode": oct(m)})
    ev = {"modes": modes, "group_or_other_writable": writable or "none"}
    if writable:
        return new(meta, FAIL, ev,
                   "chmod 755 (or 644) every script in the autostart/launch chain "
                   "and every parent directory. A background service launched from "
                   "a user-writable script is a local persistence hijack.")
    return new(meta, PASS, ev)


# ── SI-SEC-015 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-015-T0", 0, "No fixed /tmp paths in build/uninstall/install scripts",
       MINOR, layer="L0 — corollary of the L3 symlink-squat test",
       src="SECURITY-40", verified=True)
def check_si_sec_015_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_015_t0._audit_meta
    rels = ["landing/build_release.sh", "uninstall.sh", "install_client.py",
            "landing/bootstrap.sh"]
    fixed_rx = re.compile(r"(?<!\w)/tmp/[A-Za-z0-9_.-]+")
    mktemp_rx = re.compile(r"mktemp|tempfile\.(mkstemp|TemporaryDirectory|NamedTemporary)|O_EXCL")
    ev, offenders = {}, []
    scanned = 0
    for rel in rels:
        text = ctx.read(rel)
        if text is None:
            ev[rel] = "ABSENT"
            continue
        scanned += 1
        hits = []
        for i, line in enumerate(text.splitlines(), 1):
            if line.lstrip().startswith("#"):
                continue
            for m in fixed_rx.finditer(line):
                if mktemp_rx.search(line) or "XXXX" in line:
                    continue
                hits.append({"file": rel, "line": i, "path": m.group(0),
                             "text": line.strip()[:160]})
        ev[rel] = hits or "clean"
        offenders += hits
    if scanned == 0:
        return new(meta, SKIP, {"reason": "none of the target scripts exist", **ev}, "")
    ev["fixed_tmp_paths"] = len(offenders)
    if offenders:
        return new(meta, FAIL, ev,
                   "Replace every fixed /tmp/<name> with mktemp (or "
                   "tempfile.mkstemp, O_EXCL) inside a 0700 directory. A fixed "
                   "path is pre-creatable by any other local user as a symlink.")
    return new(meta, PASS, ev)


# ── SI-SEC-017 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-017-T0", 0, "Privacy scrub is ONE list shared by every install path",
       BLOCKER, layer="L0 — corollary of the L2 installed-tree sweep",
       src="SECURITY-37, INSTALL-72, CROSSOS-49, UX-06, gate G15", verified=True)
def check_si_sec_017_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_017_t0._audit_meta
    manifest = ctx.path("landing", "scrub_list.txt")
    boot = ctx.read("landing/bootstrap.sh")
    inst = ctx.read("install_client.py")
    if boot is None or inst is None:
        return new(meta, SKIP,
                   {"bootstrap.sh": boot is not None, "install_client.py": inst is not None},
                   "Both scrub consumers must exist to compare their lists.")

    if manifest.is_file():
        entries = [l.strip() for l in manifest.read_text().splitlines()
                   if l.strip() and not l.startswith("#")]
        boot_uses = bool(re.search(r"scrub_list\.txt", boot))
        inst_uses = bool(re.search(r"scrub_list\.txt", inst))
        ev = {"manifest": str(manifest), "manifest_entries": len(entries),
              "bootstrap_reads_manifest": boot_uses,
              "install_client_reads_manifest": inst_uses}
        if boot_uses and inst_uses and entries:
            return new(meta, PASS, ev)
        return new(meta, FAIL, ev,
                   "landing/scrub_list.txt exists but not every path reads it.")

    # No manifest: extract both hardcoded lists and compare as sets.
    boot_list = set()
    for m in re.finditer(r"^\s*rm -(?:f|rf)\s+([^\n]*)$", boot, re.M):
        chunk = m.group(1)
        chunk = re.sub(r"2>/dev/null.*$", "", chunk).replace("\\", " ")
        for tok in chunk.split():
            if tok.startswith("-") or tok.startswith("$") or "||" in tok:
                continue
            boot_list.add(tok.strip('"\''))
    inst_list = set()
    for name in ("_PRIVATE_FILES", "_PRIVATE_DIRS"):
        m = re.search(name + r"\s*=\s*\[(.*?)\]", inst, re.S)
        if m:
            inst_list |= set(re.findall(r'["\']([^"\']+)["\']', m.group(1)))

    only_boot = sorted(boot_list - inst_list)
    only_inst = sorted(inst_list - boot_list)

    # Which paths run a scrub at ALL — the GUI and git-clone paths are the blocker.
    runners = {}
    for rel in ("landing/bootstrap.sh", "install_client.py", "install.sh", "install.py"):
        t = ctx.read(rel)
        if t is None:
            continue
        runners[rel] = bool(re.search(r"scrub_private\(\)|Privacy scrub|_PRIVATE_FILES", t))

    ev = {
        "single_manifest": False,
        "bootstrap_list": sorted(boot_list),
        "install_client_list": sorted(inst_list),
        "only_in_bootstrap": only_boot,
        "only_in_install_client": only_inst,
        "paths_running_any_scrub": runners,
    }
    no_scrub = [k for k, v in runners.items() if not v]
    if only_boot or only_inst or no_scrub:
        ev["paths_with_no_scrub"] = no_scrub
        return new(meta, FAIL, ev,
                   "Generate both lists from a single manifest "
                   "(landing/scrub_list.txt) and apply it on EVERY install path "
                   "including the GUI and git-clone. Two hand-maintained lists "
                   "drift by construction; paths that run no scrub ship the "
                   "owner's private files to a customer.")
    return new(meta, PASS, ev)


# ── SI-SEC-020 (T0 slice) ────────────────────────────────────────────────
@check("SI-SEC-020-T0", 0, "Egress allowlist fixture exists and is non-empty",
       BLOCKER, layer="L0 — the fixture the L4 enforcement layer needs",
       src="CROSSOS-46, SECURITY-26/-28, INSTALL-16, WEAK-05", verified=True)
def check_si_sec_020_t0(ctx: Ctx) -> Result:
    meta = check_si_sec_020_t0._audit_meta
    p = ctx.path("tests", "fixtures", "egress_allowlist.txt")
    if not p.is_file():
        return new(meta, FAIL,
                   {"expected_path": str(p), "exists": False,
                    "fixtures_present": sorted(x.name for x in p.parent.glob("*"))
                    if p.parent.is_dir() else "tests/fixtures/ missing"},
                   "Create tests/fixtures/egress_allowlist.txt listing every host "
                   "the product is permitted to contact. Without it, every T2 "
                   "egress assertion has nothing to compare against and passes "
                   "vacuously.")
    entries = [l.strip() for l in p.read_text().splitlines()
               if l.strip() and not l.startswith("#")]
    ev = {"path": str(p), "entries": entries, "count": len(entries)}
    if not entries:
        return new(meta, FAIL, ev, "The allowlist file is empty; an empty "
                                   "allowlist makes 'zero unlisted hosts' trivially true.")
    return new(meta, PASS, ev)


# ── SI-UPD-001 / -002 (T0 slice) ─────────────────────────────────────────
@check("SI-UPD-001-T0", 0, "A version constant exists and every path writes .sabr-release",
       BLOCKER, layer="L0 — corollary of the L4/L6 update test",
       src="SI-UPD-001/-002", verified=True)
def check_si_upd_001_t0(ctx: Ctx) -> Result:
    meta = check_si_upd_001_t0._audit_meta
    version_sites = grep_tree(
        ctx.repo, r"^\s*(__version__|VERSION|RELEASE_SHA)\s*=\s*[\"']",
        globs=("*.py",),
        exclude=NOISE + ("/tests/", "/workspaces/", "/business/", "/outreach/"),
    )
    writers = {}
    for rel in ("landing/bootstrap.sh", "install_client.py", "install.sh", "install.py"):
        t = ctx.read(rel)
        if t is None:
            continue
        writers[rel] = bool(re.search(r"\.sabr-release", t))
    ev = {"version_constant_sites": version_sites[:10] or "ABSENT",
          "paths_writing_.sabr-release": writers}
    silent = [k for k, v in writers.items() if not v]
    if not version_sites or silent:
        ev["paths_writing_nothing"] = silent
        return new(meta, FAIL, ev,
                   "Define one release-version constant, expose it at "
                   "/api/version and /healthz, and have EVERY install path write "
                   "$INSTALL/.sabr-release. Without a version the updater cannot "
                   "know it is behind, so it can never return True.")
    return new(meta, PASS, ev)


# ── SI-UPD-009 (T0 slice) ────────────────────────────────────────────────
@check("SI-UPD-009-T0", 0, "Schema versioning: PRAGMA user_version is used",
       MAJOR, layer="L0 — corollary of the L2 migration test",
       src="SI-UPD-009", verified=True)
def check_si_upd_009_t0(ctx: Ctx) -> Result:
    meta = check_si_upd_009_t0._audit_meta
    hits = grep_tree(ctx.repo, r"user_version", globs=("*.py",),
                     exclude=NOISE + ("/workspaces/",))
    ev = {"user_version_sites": hits[:20] or "ABSENT", "count": len(hits)}
    if not hits:
        return new(meta, FAIL, ev,
                   "Stamp every SQLite database with PRAGMA user_version and gate "
                   "migrations on it. With no schema version an update cannot tell "
                   "an old database from a new one, and picks wrong silently.")
    return new(meta, PASS, ev)


# ── SI-UX-005 (T0 slice) ─────────────────────────────────────────────────
@check("SI-UX-005-T0", 0, "/healthz route is defined and derived, not a constant",
       BLOCKER, layer="L0 — corollary of the L6 probe with fault injection",
       src="UX-12, RUNTIME-13, WEAK-37", verified=True)
def check_si_ux_005_t0(ctx: Ctx) -> Result:
    meta = check_si_ux_005_t0._audit_meta
    srv = ctx.path("server")
    if not srv.is_dir():
        return new(meta, SKIP, {"reason": "server/ not found"}, "")
    routes = grep_tree(srv, r'["\']/healthz', exclude=NOISE)
    routes += grep(ctx.read("run.py") or "", r'["\']/healthz', "run.py")
    subsystems = grep_tree(srv, r"subsystems", exclude=NOISE)
    ev = {"healthz_route_sites": routes or "ABSENT",
          "subsystems_sites": subsystems[:10] or "ABSENT"}
    if not routes:
        return new(meta, FAIL, ev,
                   "Add GET /healthz returning {status, version, uptime_s, "
                   "subsystems{...}} DERIVED from live probes (last engine "
                   "round-trip < 120 s AND a probe write to the conversation "
                   "store). Eleven other checks, the installer and doctor all "
                   "depend on it; a missing /healthz makes them unverifiable.")
    if not subsystems:
        return new(meta, FAIL, ev,
                   "/healthz exists but reports no per-subsystem live-probe state, "
                   "so it cannot leave 'ok' under injected faults.")
    return new(meta, PASS, ev)


# ── SI-UX-013 (T0 structural requirements) ───────────────────────────────
@check("SI-UX-013-T0", 0, "Doctor is discoverable: launchers, API route, dashboard button",
       BLOCKER, layer="L0 — the structure the L6 naive-user simulation requires",
       src="UX-25, -26, WEAK-36", verified=True)
def check_si_ux_013_t0(ctx: Ctx) -> Result:
    meta = check_si_ux_013_t0._audit_meta
    surfaces = {
        "tools/doctor.py": ctx.path("tools", "doctor.py").is_file(),
        "doctor.sh at install root": ctx.path("doctor.sh").is_file(),
        "doctor.bat at install root": ctx.path("doctor.bat").is_file(),
    }
    api = grep_tree(ctx.path("server"), r'["\']/api/doctor', exclude=NOISE) \
        if ctx.path("server").is_dir() else []
    dash = grep_tree(ctx.path("dashboard"), r"api/doctor|Run health check",
                     globs=("*.html", "*.js"), exclude=NOISE) \
        if ctx.path("dashboard").is_dir() else []
    # The launcher path must appear in the installer's die() and summary text.
    boot = ctx.read("landing/bootstrap.sh") or ""
    named_in_installer = grep(boot, r"doctor\.(sh|bat)", "landing/bootstrap.sh")

    ev = {"surfaces": surfaces, "api_doctor_route": api or "ABSENT",
          "dashboard_button": dash or "ABSENT",
          "launcher_named_in_bootstrap": named_in_installer or "ABSENT"}
    missing = [k for k, v in surfaces.items() if not v]
    if missing or not api or not dash or not named_in_installer:
        ev["missing_surfaces"] = missing
        return new(meta, FAIL, ev,
                   "Ship ./doctor.sh and doctor.bat at the install root, add "
                   "GET /api/doctor plus a dashboard 'Run health check' button, "
                   "and print the launcher path in every install summary and "
                   "every die(). A naive user can only run what they were shown.")
    return new(meta, PASS, ev)


# ── SI-UX-014 (T0 slice) ─────────────────────────────────────────────────
@check("SI-UX-014-T0", 0, "doctor --bundle exists and redacts secrets",
       BLOCKER, layer="L0 — corollary of the L1 bundle-bytes check",
       src="UX-37", verified=True)
def check_si_ux_014_t0(ctx: Ctx) -> Result:
    meta = check_si_ux_014_t0._audit_meta
    doc = ctx.read("tools/doctor.py")
    if doc is None:
        return new(meta, FAIL, {"tools/doctor.py": "ABSENT"},
                   "Create tools/doctor.py implementing --json/--quick/--bundle/--fix.")
    flags = {f: bool(re.search(re.escape(f), doc))
             for f in ("--json", "--quick", "--bundle", "--fix", "--area")}
    redact = grep(doc, r"redact|<redacted", "tools/doctor.py")
    members = grep(doc, r"doctor\.json|versions\.txt|env\.redacted|pip-freeze", "tools/doctor.py")
    ev = {"flags_present": flags, "redaction_sites": redact or "ABSENT",
          "bundle_member_names": members or "ABSENT"}
    if not flags["--bundle"] or not redact:
        return new(meta, FAIL, ev,
                   "Implement doctor --bundle: a <=10 MB zip containing "
                   "doctor.json, versions.txt, install.log, autostart.log, "
                   "env.redacted, platform.txt, pip-freeze.txt, with every "
                   "*_KEY/*_TOKEN/*_SECRET value replaced by <redacted:sha256[:8]>, "
                   "and print its absolute path.")
    return new(meta, PASS, ev)


# ── SI-UX-006 (T0 slice) ─────────────────────────────────────────────────
@check("SI-UX-006-T0", 0, "Doctor degrades to ASCII and honors NO_COLOR",
       MAJOR, layer="L0 — corollary of the L6 transcript-bytes check",
       src="UX-45, GAP-41, GAP-45", verified=True)
def check_si_ux_006_t0(ctx: Ctx) -> Result:
    meta = check_si_ux_006_t0._audit_meta
    doc = ctx.read("tools/doctor.py")
    if doc is None:
        return new(meta, SKIP, {"tools/doctor.py": "ABSENT"},
                   "No doctor to audit; see SI-UX-013-T0.")
    ev = {
        "NO_COLOR_sites": grep(doc, r"NO_COLOR", "tools/doctor.py") or "ABSENT",
        "isatty_sites": grep(doc, r"isatty", "tools/doctor.py") or "ABSENT",
        "arrow_fallback_sites": grep(doc, r"->|encoding", "tools/doctor.py") or "ABSENT",
        "unicode_arrow_used": bool("→" in doc),
    }
    problems = []
    if ev["NO_COLOR_sites"] == "ABSENT":
        problems.append("NO_COLOR not honored")
    if ev["isatty_sites"] == "ABSENT":
        problems.append("no TTY detection, so ANSI/\\r goes into piped output")
    if ev["unicode_arrow_used"] and ev["arrow_fallback_sites"] == "ABSENT":
        problems.append("uses the → glyph with no ASCII fallback (UnicodeEncodeError under cp437)")
    if problems:
        ev["problems"] = problems
        return new(meta, FAIL, ev,
                   "Detect stdout encoding and TTY at runtime: emit '->' when '→' "
                   "cannot be encoded, drop ANSI and \\r when not a TTY, and honor "
                   "NO_COLOR. Every color-coded state must also carry [OK]/[FAIL].")
    return new(meta, PASS, ev)


# ── SI-UX-011 (T0 slice) ─────────────────────────────────────────────────
@check("SI-UX-011-T0", 0, "Every wizard prompt is labeled (optional) or (required)",
       MAJOR, layer="L0 — corollary of the L6 all-Enter run",
       src="UX-22", verified=True)
def check_si_ux_011_t0(ctx: Ctx) -> Result:
    meta = check_si_ux_011_t0._audit_meta
    inst = ctx.read("install_client.py")
    if inst is None:
        return new(meta, SKIP, {"install_client.py": "ABSENT"}, "")
    label_rx = re.compile(r"\(optional[^)]*\)|\(required\)", re.I)
    prompts, unlabeled = [], []
    for i, line in enumerate(inst.splitlines(), 1):
        if line.lstrip().startswith("#"):
            continue
        m = re.search(r"(?:input|ask|prompt|_ask\w*)\s*\(\s*(f?[\"'])(.+?)\1", line)
        if not m:
            continue
        text = m.group(2)
        rec = {"file": "install_client.py", "line": i, "prompt": text[:120]}
        prompts.append(rec)
        if not label_rx.search(text):
            unlabeled.append(rec)
    if not prompts:
        return new(meta, SKIP, {"reason": "no input prompts matched in install_client.py"},
                   "Retarget the prompt pattern; a zero-match scan is not a pass.")
    ev = {"prompts_found": len(prompts), "unlabeled": unlabeled,
          "labeled": len(prompts) - len(unlabeled)}
    if unlabeled:
        return new(meta, FAIL, ev,
                   "Suffix every wizard prompt with '(optional)' or '(required)' "
                   "so a user can safely press Enter through the whole wizard.")
    return new(meta, PASS, ev)


# ── SI-UNI-003 (T0 slice) ────────────────────────────────────────────────
@check("SI-UNI-003-T0", 0, "uninstall.sh refuses to delete a directory with no install marker",
       BLOCKER, layer="L0 — corollary of the L2 destructive test",
       src="SI-UNI-003", verified=True)
def check_si_uni_003_t0(ctx: Ctx) -> Result:
    meta = check_si_uni_003_t0._audit_meta
    text = ctx.read("uninstall.sh")
    if text is None:
        return new(meta, SKIP, {"uninstall.sh": "ABSENT"}, "")
    rm_sites = grep(text, r"rm\s+-rf\s+[\"']?\$\{?(INSTALL_DIR|LEON_INSTALL_DIR)", "uninstall.sh")
    # A marker guard is a test for a file that ONLY a real install has,
    # performed before any recursive delete.
    guard = grep(text, r"(\[\s*-f\s*[\"']?\$\{?INSTALL_DIR\}?/(\.sabr-release|run\.py|"
                       r"\.leon-install|MANIFEST\.sha256))|marker", "uninstall.sh")
    home_guard = grep(text, r'INSTALL_DIR"?\s*=\s*"?\$HOME"?\s*\]|"\$HOME"\s*\]|== *"\$HOME"',
                      "uninstall.sh")
    ev = {"recursive_delete_sites": rm_sites or "none",
          "marker_guard_sites": guard or "ABSENT",
          "refuses_HOME_sites": home_guard or "ABSENT"}
    if rm_sites and (not guard or not home_guard):
        return new(meta, FAIL, ev,
                   "Before any rm -rf, require an install marker inside "
                   "$INSTALL_DIR (e.g. .sabr-release) and hard-refuse when the "
                   "target is $HOME, /, or any path with no marker. Today "
                   "LEON_INSTALL_DIR=$HOME bash uninstall.sh deletes the home "
                   "directory.")
    if not rm_sites:
        return new(meta, SKIP, {**ev, "reason": "no recursive delete found to guard"},
                   "Confirm the uninstaller still deletes anything.")
    return new(meta, PASS, ev)


# ── SI-HARN-009 (T0 slice) ───────────────────────────────────────────────
@check("SI-HARN-009-T0", 0, "No test mutates the code under test",
       BLOCKER, layer="L0 (meta) — results from a mutant test are VOID",
       src="GAP-60, WEAK-41", verified=True)
def check_si_harn_009_t0(ctx: Ctx) -> Result:
    meta = check_si_harn_009_t0._audit_meta
    tests = ctx.path("tests")
    if not tests.is_dir():
        return new(meta, SKIP, {"tests/": "ABSENT"}, "")
    mut_rx = re.compile(
        r"sed\s+-i[^\n]*(bootstrap\.sh|install_client\.py|run\.py)|"
        r">\s*\.\./(bootstrap|run)\.py|"
        r"shutil\.copy[^\n]*(bootstrap\.sh|run\.py)[^\n]*\.\.")
    hits = grep_tree(tests, mut_rx, globs=("*.sh", "*.py"), exclude=NOISE)
    ev = {"mutation_sites": hits or "none", "tests_scanned": len(list(tests.rglob("*.py"))
                                                                + list(tests.rglob("*.sh")))}
    if ev["tests_scanned"] == 0:
        return new(meta, SKIP, {"reason": "no test files found to scan"}, "")
    if hits:
        return new(meta, FAIL, ev,
                   "A test must copy the artifact to a scratch dir and mutate the "
                   "COPY, never sed the shipped file. Results produced against a "
                   "mutant of the code under test are VOID.")
    return new(meta, PASS, ev)
