#!/usr/bin/env python3
"""
Leon World Viewer — Web Edition (for remote access via Tailscale)

Renders Leon's MuJoCo world server-side using EGL (headless GPU),
streams frames as MJPEG to your browser. Works over Tailscale.

Usage:
  python3 view_leon_web.py                    # viewer only, port 8765
  python3 view_leon_web.py --brain            # with brain sim
  python3 view_leon_web.py --brain --neurons 1000
  python3 view_leon_web.py --port 9000        # custom port

Then open: http://<tailscale-ip>:8765/
"""

import argparse
import io
import json
import os
import struct
import sys
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

# Force EGL for headless rendering
os.environ["MUJOCO_GL"] = "egl"

import mujoco
import numpy as np

# Globals
_model = None
_data = None
_renderer = None
_brain = None
_body = None
_sim_running = False
_sim_hz = 0.0
_lock = threading.Lock()

# Camera state (controllable from browser)
_cam = None
_follow_leon = True
_first_person = False

RENDER_WIDTH = 960
RENDER_HEIGHT = 640
TARGET_FPS = 20


def init_world(model_path: str):
    """Load MuJoCo model and set up renderer."""
    global _model, _data, _renderer, _cam
    _model = mujoco.MjModel.from_xml_path(model_path)
    _data = mujoco.MjData(_model)
    mujoco.mj_forward(_model, _data)
    _cam = mujoco.MjvCamera()
    _cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    _cam.azimuth = 180
    _cam.elevation = -30
    _cam.distance = 5.0
    _cam.lookat[:] = [0.0, 0.0, 0.8]
    print(f"[WEB] World loaded: {_model.nbody} bodies, {_model.ngeom} geoms")


def init_brain(neurons: int):
    """Initialize brain and wire to MuJoCo body."""
    global _brain, _body, _model, _data
    sys.path.insert(0, os.path.dirname(__file__))
    from brain.brain import Brain
    from brain.embodiment import MuJoCoBody

    _brain = Brain(total_neurons=neurons)
    _body = MuJoCoBody()
    _body.init_metabolic(_brain)
    _brain.simulated_body = _body

    # Use the body's model/data instead of the standalone one
    _model = _body.model
    _data = _body.data

    # Camera setup (renderer created lazily on first render)
    global _cam
    _cam = mujoco.MjvCamera()
    _cam.type = mujoco.mjtCamera.mjCAMERA_FREE
    _cam.azimuth = 180
    _cam.elevation = -30
    _cam.distance = 5.0
    _cam.lookat[:] = [0.0, 0.0, 0.8]

    print(f"[WEB] Brain: {_brain.total_neurons:,} neurons, "
          f"{_brain.total_synapses:,} synapses, 101 body systems")


def brain_loop():
    """Run brain simulation in background thread."""
    global _sim_hz, _sim_running
    _sim_running = True
    tick = 0
    t0 = time.time()
    while _sim_running:
        with _lock:
            _brain.step()
        tick += 1
        elapsed = time.time() - t0
        if elapsed > 1.0:
            _sim_hz = tick / elapsed
            tick = 0
            t0 = time.time()
        if tick % 5 == 0:
            time.sleep(0.001)


def physics_loop():
    """Step MuJoCo physics when brain is NOT running (viewer-only mode)."""
    global _sim_running
    _sim_running = True
    while _sim_running:
        with _lock:
            mujoco.mj_step(_model, _data)
        time.sleep(0.002)


_render_lock = threading.Lock()
# EGL context created lazily on first render, always from the same thread
_renderer_ready = False

def _ensure_renderer():
    """Create renderer on first call (must always be from same thread)."""
    global _renderer, _renderer_ready
    if not _renderer_ready:
        _renderer = mujoco.Renderer(_model, height=RENDER_HEIGHT, width=RENDER_WIDTH)
        _renderer_ready = True

def render_frame() -> bytes:
    """Render a frame. Called from the stream handler thread.
    Uses a lock so only one thread renders at a time."""
    from PIL import Image

    with _render_lock:
        _ensure_renderer()

        if _first_person:
            _cam.type = mujoco.mjtCamera.mjCAMERA_FIXED
            cam_id = mujoco.mj_name2id(
                _model, mujoco.mjtObj.mjOBJ_CAMERA, "first_person")
            _cam.fixedcamid = cam_id if cam_id >= 0 else 0
        else:
            _cam.type = mujoco.mjtCamera.mjCAMERA_FREE
            if _follow_leon:
                try:
                    torso_pos = _data.body("torso").xpos.copy()
                    _cam.lookat[:] = [torso_pos[0], torso_pos[1],
                                      max(0.5, torso_pos[2])]
                except Exception:
                    pass

        _renderer.update_scene(_data, _cam)
        frame = _renderer.render()

    # JPEG encode outside lock
    img = Image.fromarray(frame)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=75)
    return buf.getvalue()


def get_body_state() -> dict:
    """Get body state for the info overlay."""
    if _body is not None:
        return _body.get_state()
    # Minimal state for viewer-only mode
    return {
        "position": _data.qpos[:3].tolist(),
        "height": float(_data.qpos[2]),
    }


# ═══════════════════════════════════════════════════════════════════════
# HTTP SERVER
# ═══════════════════════════════════════════════════════════════════════

HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
<title>Leon's World</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #111; color: #ddd; font-family: 'Courier New', monospace; }
  #container { display: flex; height: 100vh; }
  #viewer { flex: 1; display: flex; align-items: center; justify-content: center; }
  #viewer img { max-width: 100%; max-height: 100vh; image-rendering: auto; }
  #sidebar { width: 320px; background: #1a1a1a; padding: 16px; overflow-y: auto;
             border-left: 1px solid #333; font-size: 12px; }
  #sidebar h2 { color: #7af; margin-bottom: 8px; font-size: 14px; }
  .section { margin-bottom: 12px; padding: 8px; background: #222; border-radius: 4px; }
  .section h3 { color: #aaa; font-size: 11px; margin-bottom: 4px; text-transform: uppercase; }
  .kv { display: flex; justify-content: space-between; padding: 1px 0; }
  .kv .k { color: #888; }
  .kv .v { color: #cfc; }
  .prompt { background: #1a2a1a; padding: 8px; border-radius: 4px; margin-top: 8px;
            color: #8f8; font-style: italic; white-space: pre-wrap; }
  #controls { margin-top: 12px; }
  #controls button { background: #333; color: #ddd; border: 1px solid #555; padding: 6px 12px;
                     margin: 2px; cursor: pointer; border-radius: 3px; }
  #controls button:hover { background: #444; }
  #controls button.active { background: #254; border-color: #7af; }
  .hz { color: #fa7; }
</style>
</head>
<body>
<div id="container">
  <div id="viewer">
    <img id="stream" src="/stream" alt="Leon's World"/>
  </div>
  <div id="sidebar">
    <h2>LEON'S WORLD</h2>
    <div id="status" class="section"><h3>Status</h3><div class="kv"><span class="k">Loading...</span></div></div>
    <div id="body-state" class="section"><h3>Body</h3></div>
    <div id="emotions" class="section"><h3>Emotions</h3></div>
    <div id="prompt-box" class="prompt">Loading body state...</div>
    <div id="controls">
      <h3 style="color:#aaa;margin-bottom:4px">CAMERA</h3>
      <button onclick="cam('closer')">Zoom In</button>
      <button onclick="cam('farther')">Zoom Out</button>
      <button onclick="cam('left')">Rotate L</button>
      <button onclick="cam('right')">Rotate R</button>
      <button onclick="cam('up')">Tilt Up</button>
      <button onclick="cam('down')">Tilt Down</button><br>
      <button id="followBtn" class="active" onclick="toggleFollow()">Follow Leon</button>
      <button onclick="cam('first_person')">1st Person</button>
      <button onclick="cam('overview')">Overview</button>
      <button onclick="cam('reset')">Reset</button>
      <div id="cam-info" style="color:#666;margin-top:4px;font-size:10px"></div>
    </div>
  </div>
</div>
<script>
function cam(action) {
  fetch('/camera?action=' + action).then(r => r.json()).then(d => {
    document.getElementById('cam-info').textContent =
      'az=' + d.azimuth + ' el=' + d.elevation + ' d=' + d.distance +
      (d.following ? ' [following]' : '') + (d.first_person ? ' [1st person]' : '');
  }).catch(() => {});
}
function toggleFollow() {
  fetch('/camera?action=toggle_follow').then(r => r.json()).then(d => {
    document.getElementById('followBtn').className = d.following ? 'active' : '';
  });
}
function updateState() {
  fetch('/state').then(r => r.json()).then(s => {
    // Status
    let status = '';
    status += kv('Height', (s.height || 0).toFixed(2) + 'm');
    status += kv('Sim Hz', '<span class="hz">' + (s._sim_hz || 0).toFixed(0) + '</span>');
    status += kv('Tick', s.tick_count || 0);
    status += kv('Age', (s.age_s || 0) + 's');
    if (s.heart_rate_hz) status += kv('Heart', s.heart_rate_hz + ' Hz');
    if (s.breath_rate_hz) status += kv('Breath', s.breath_rate_hz + ' Hz');
    if (s.trust_level !== undefined) status += kv('Trust', s.trust_level);
    if (s.confidence !== undefined) status += kv('Confidence', s.confidence);
    if (s.antenna_completeness !== undefined) status += kv('Antenna', s.antenna_completeness);
    document.getElementById('status').innerHTML = '<h3>Status</h3>' + status;

    // Body
    let body = '';
    if (s.hunger !== undefined) body += kv('Hunger', s.hunger);
    if (s.fatigue !== undefined) body += kv('Fatigue', s.fatigue);
    if (s.thirst !== undefined) body += kv('Thirst', s.thirst);
    if (s.pain_total !== undefined) body += kv('Pain', s.pain_total);
    if (s.sympathetic !== undefined) body += kv('Sympathetic', s.sympathetic);
    if (s.parasympathetic !== undefined) body += kv('Parasympathetic', s.parasympathetic);
    if (s.cortisol !== undefined) body += kv('Cortisol', s.cortisol);
    if (s.endorphins !== undefined) body += kv('Endorphins', s.endorphins);
    document.getElementById('body-state').innerHTML = '<h3>Body</h3>' + body;

    // Emotions
    let emo = '';
    if (s.emotions) {
      for (let [k, v] of Object.entries(s.emotions)) {
        if (k !== 'dominant' && v > 0) emo += kv(k, v);
      }
      if (s.emotions.dominant) emo += kv('Dominant', '<b>' + s.emotions.dominant + '</b>');
    }
    if (s.in_flow) emo += kv('Flow', s.flow_depth);
    if (s.wonder > 0) emo += kv('Wonder', s.wonder);
    document.getElementById('emotions').innerHTML = '<h3>Emotions</h3>' + (emo || kv('State', 'neutral'));

    // Prompt
    if (s._prompt) document.getElementById('prompt-box').textContent = s._prompt;
  }).catch(() => {});
}
function kv(k, v) { return '<div class="kv"><span class="k">' + k + '</span><span class="v">' + v + '</span></div>'; }
setInterval(updateState, 1000);
updateState();
</script>
</body>
</html>"""


class ViewerHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # suppress request logs

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode())

        elif self.path == "/stream":
            self.send_response(200)
            self.send_header("Content-Type",
                           "multipart/x-mixed-replace; boundary=frame")
            self.end_headers()
            try:
                while _sim_running:
                    jpg = render_frame()
                    self.wfile.write(b"--frame\r\n")
                    self.wfile.write(b"Content-Type: image/jpeg\r\n")
                    self.wfile.write(f"Content-Length: {len(jpg)}\r\n\r\n".encode())
                    self.wfile.write(jpg)
                    self.wfile.write(b"\r\n")
                    time.sleep(1.0 / TARGET_FPS)
            except (BrokenPipeError, ConnectionResetError):
                pass

        elif self.path == "/state":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            state = get_body_state()
            state["_sim_hz"] = round(_sim_hz, 1)
            if _body is not None:
                state["_prompt"] = _body.for_prompt()
            self.wfile.write(json.dumps(state, default=str).encode())

        elif self.path.startswith("/camera"):
            self._handle_camera()

        else:
            self.send_error(404)

    def _handle_camera(self):
        global _follow_leon, _first_person
        from urllib.parse import urlparse, parse_qs
        params = parse_qs(urlparse(self.path).query)
        action = params.get("action", [""])[0]

        with _lock:
            if action == "closer":
                _cam.distance = max(1.5, _cam.distance - 1.0)
            elif action == "farther":
                _cam.distance = min(25, _cam.distance + 1.0)
            elif action == "left":
                _cam.azimuth = (_cam.azimuth - 20) % 360
            elif action == "right":
                _cam.azimuth = (_cam.azimuth + 20) % 360
            elif action == "up":
                _cam.elevation = min(-5, _cam.elevation + 10)
            elif action == "down":
                _cam.elevation = max(-89, _cam.elevation - 10)
            elif action == "toggle_follow":
                _follow_leon = not _follow_leon
                _first_person = False
            elif action == "first_person":
                _first_person = True
                _follow_leon = False
            elif action == "overview":
                _first_person = False
                _follow_leon = False
                _cam.azimuth = 180
                _cam.elevation = -60
                _cam.distance = 20
                _cam.lookat[:] = [0, 0, 0]
            elif action == "reset":
                _first_person = False
                _follow_leon = True
                _cam.azimuth = 180
                _cam.elevation = -30
                _cam.distance = 5.0
                _cam.lookat[:] = [0, 0, 0.8]

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps({
            "ok": True, "following": _follow_leon,
            "first_person": _first_person,
            "azimuth": round(_cam.azimuth, 1),
            "elevation": round(_cam.elevation, 1),
            "distance": round(_cam.distance, 1),
        }).encode())


def main():
    parser = argparse.ArgumentParser(description="Leon World Viewer (Web)")
    parser.add_argument("--brain", action="store_true",
                       help="Run brain simulation")
    parser.add_argument("--neurons", type=int, default=1000,
                       help="Neuron count (default 1000)")
    parser.add_argument("--port", type=int, default=8765,
                       help="HTTP port (default 8765)")
    args = parser.parse_args()

    model_path = os.path.join(os.path.dirname(__file__), "brain", "leon_body.xml")
    os.chdir(os.path.dirname(__file__) or ".")

    # Check PIL
    try:
        from PIL import Image
    except ImportError:
        print("[WEB] Installing Pillow for JPEG encoding...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install",
                              "--break-system-packages", "Pillow"])
        from PIL import Image

    if args.brain:
        init_brain(args.neurons)
        threading.Thread(target=brain_loop, daemon=True, name="brain").start()
        print(f"[WEB] Brain simulation running")
    else:
        init_world(model_path)
        threading.Thread(target=physics_loop, daemon=True, name="physics").start()

    print(f"[WEB] Renderer will initialize on first frame request")

    server = ThreadedHTTPServer(("0.0.0.0", args.port), ViewerHandler)
    print(f"[WEB] Viewer ready at http://0.0.0.0:{args.port}/")
    print(f"[WEB] Open in browser: http://<your-tailscale-ip>:{args.port}/")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        global _sim_running
        _sim_running = False
        print("\n[WEB] Shutting down")


if __name__ == "__main__":
    main()
