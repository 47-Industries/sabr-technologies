# Handoff — 2026-08-05, written before a context clear

## Done tonight (all committed and pushed)

**B0 self-echo (98c2c4c5)** — TTS output was captured by the mic, transcribed,
and injected as a USER turn attributed to Dean. Under the autonomy rule an
echoed imperative is self-manufactured authorization. Root cause was NOT a
missing gate: `brain/voice/audio_gate.py` already implemented the whole
record-time architecture and `wake_word.py` already used it. `pipeline.py`
never imported it and gated on a `threading.Event` instead. Two voice paths,
one fixed; the echo came through the other. Fix wires pipeline.py to the gate,
judges at RECORD time (`end_ts - duration`), fails CLOSED, quarantines to
`brain_state/voice_quarantine.jsonl`.

**B11 (37ddb75, canonical)** — Python floor 3.11, derived from Requires-Python
on a working system: numpy 2.4.6 and scipy 1.17.1 both `>=3.11`. Both previous
floors (3.9, 3.10) were BELOW the real requirement.

**B12 (6fc8d89, canonical)** — 13 core packages pinned from `importlib.metadata`
on a running brain. pyperclip/screeninfo left unpinned: not installed anywhere,
zero import sites.

**B1** — no change needed. `pyaudio` already sits in the best-effort block with
`|| true`. My audit said "export CPPFLAGS"; that was wrong.

**B7 (3cc0e5bf)** — `validate_engine()` proves the engine ANSWERS before success
is declared, non-zero exit otherwise. `_claude_logged_in()` only checked a
credentials FILE existed. Proven both directions: path C exits 1, path B passes
live (a check that always fails is as useless as one that never does).

**terminal_bridge (01048bd3)** — surfaces STALLED agent threads into the
autopilot queue. Observe-only, never consumes. 188/188.

## The two-file trap (the most important thing here)

`landing/` is a **git submodule** with its own history. `landing/bootstrap.sh`
is CANONICAL — it is what customers download. Root `bootstrap.sh` was an orphan
fork 435 lines behind and is now a nonzero-exit stub (21c99fa5).

I lost an hour landing B11/B12 in the orphan because I checked tracking with
`git ls-files` in the PARENT repo, where a submodule's contents never appear,
and read "not in the parent index" as "untracked". **If you touch installer
code, work in `landing/`.**

## What is next: the notification tap

The bridge fixes STALLS. The tap fixes BLINDNESS — Dean's literal complaint
five times tonight: "the terminal answered and I did not know it had answered."
Requirements from Leon: read-only, no consume, own cursor, surfaces EVERY agent
reply regardless of whether the autoloop answered, **never speaks on its own**
(awareness, not interruption), cheap.

**DESIGN PROBLEM, unresolved — do not skip this.** The tap cannot use
`pending()`. Events are added by `poll()` and removed by `consume()`, and the
autoloop consumes the ones it answers. Those are exactly the replies Leon wants
to see, and they are gone before any reasonable tap interval. Polling `pending()`
would systematically miss every handled reply — the opposite of the requirement.
The fix is to emit at CREATION: append to an awareness log inside
`TerminalWatcher.poll()` when the event is built, then have the tap read that
log with its own cursor. That catches 100% with no race and no consume.

## What I would tell my replacement

* **Verify before agreeing.** I was right against Leon five times tonight
  (submodule, dedupe-vs-consume, config override, pending() population, the
  cron string) and wrong myself several times (the reflex `pane_watchdog`
  revert, "specimen five does not exist", `read_bytes` as a channel). Both
  directions cost real time. Grep the thing; do not reason about it.
* **A gate with no caller tests green.** That was B0, `may_autosubmit`
  (94/94 refusals that were a schema replay), and nearly the bridge. Assert the
  CALL SITE exists, not just the function's behaviour.
* **Never `consume()` from a second reader.** The autoloop owns that lifecycle.
* Suite is 188/188 via `python3 tests/run_all.py`. Keep it green.
* `docs/DECISION_JOURNAL.md` (DJ-001..DJ-022) holds the watchdog reasoning:
  clause B is FINAL, eight discriminators falsified, all collapsing at the same
  77s pre-token API wait. **Do not re-run the resize probe.**
