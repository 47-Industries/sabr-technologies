#!/usr/bin/env python3
"""Sabr SI — restore an identity archive written by uninstall (any OS).

    python restore_identity.py <archive.tar.gz>
    python restore_identity.py <archive.tar.gz> --into C:\\path\\to\\leon-brain

Why this file exists
--------------------
restore_identity.sh was written first, and within the hour it repeated the
exact mistake that made uninstall.sh useless on Windows: it is bash. A Windows
owner has no bash, so a Windows uninstall printed a restore command that could
not be run — the very same shape of failure, one layer along. Twice is a
pattern, not bad luck: anything an owner must run to get their SI back has to
exist in Python, because Python is the one interpreter every install is
guaranteed to have.

The placement rule this whole script exists to enforce:

    .env         -> the install directory
    brain_state  -> the install directory
    .leon        -> the HOME directory, NOT the install

A plain untar puts .leon inside the install, where nothing reads it. The SI
then boots with no learned cognition and starts from zero, silently, while the
owner believes they restored it.
"""

import argparse
import os
import platform
import shutil
import sys
import tarfile
import time
from pathlib import Path

HOME = Path.home()
G, Y, R, C, D, N = "\033[32m", "\033[33m", "\033[31m", "\033[36m", "\033[2m", "\033[0m"
if platform.system() == "Windows" and not os.environ.get("WT_SESSION"):
    G = Y = R = C = D = N = ""

# name in archive -> where its reader actually looks
DESTINATIONS = {".env": "install", "brain_state": "install", ".leon": "home"}


def say(msg=""):
    print(msg, flush=True)


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("archive")
    ap.add_argument("--into", default=str(HOME / "leon-brain"))
    args = ap.parse_args()

    archive = Path(args.archive).expanduser()
    install = Path(args.into).expanduser()

    if not archive.is_file():
        say(f"{R}[ERROR]{N} {archive} does not exist.")
        return 1
    try:
        with tarfile.open(archive, "r:gz") as tar:
            members = sorted({m.name.split("/")[0] for m in tar.getmembers()})
    except (OSError, tarfile.TarError) as e:
        say(f"{R}[ERROR]{N} {archive} is not a readable archive: {e}")
        say("If you moved it between machines it may have been corrupted in transit.")
        return 1

    say("")
    say(f"{C}Sabr SI — restore identity{N}")
    say(f"  archive     {archive}")
    say(f"  install     {install}")
    say(f"  contains    {' '.join(members)}")
    say("")

    if not install.is_dir():
        say(f"{R}[STOPPED]{N} {install} does not exist.")
        say("Install the SI first, then run this BEFORE its first boot — a booted")
        say("SI writes a fresh empty brain_state, and restoring over it afterwards")
        say("throws away the run you just did.")
        return 1

    stamp = time.strftime("%Y%m%d-%H%M%S")
    staging = install.parent / f".si-restore-{stamp}"
    try:
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(staging)
    except (OSError, tarfile.TarError) as e:
        shutil.rmtree(staging, ignore_errors=True)
        say(f"{R}[STOPPED]{N} could not unpack: {e}. Nothing has been changed.")
        return 1

    restored = 0
    try:
        for name in members:
            src = staging / name
            if not src.exists():
                continue
            base = install if DESTINATIONS.get(name, "install") == "install" else HOME
            dest = base / name
            if dest.exists():
                # Never delete what was already there. If this restore is wrong,
                # the owner has to be able to walk it back.
                shutil.move(str(dest), str(dest) + f".replaced-{stamp}")
                say(f"  {D}moved existing {name} aside -> {name}.replaced-{stamp}{N}")
            shutil.move(str(src), str(dest))
            note = "  (learned skills, lessons, reflections)" if name == ".leon" else ""
            say(f"{G}[OK]{N} {name} -> {dest}{D}{note}{N}")
            restored += 1
    finally:
        shutil.rmtree(staging, ignore_errors=True)

    # Verify where the SI reads, not where we just wrote.
    say("")
    failed = False
    for name in members:
        if name not in DESTINATIONS:
            continue
        base = install if DESTINATIONS[name] == "install" else HOME
        if (base / name).exists():
            say(f"{G}[VERIFIED]{N} {name} is where the SI will look for it")
        else:
            say(f"{R}[FAILED]{N} {name} did not land at {base / name}")
            failed = True

    if failed or restored == 0:
        say("")
        say(f"{R}Restore incomplete.{N} Your archive is untouched at {archive}.")
        return 1

    say("")
    say(f"{G}Restored.{N} Start the SI — it should know its own name and remember you.")
    say(f"{D}Anything replaced was renamed .replaced-{stamp}, not deleted.{N}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
