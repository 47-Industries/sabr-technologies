#!/usr/bin/env python3
"""
SI Installer — Sabr

Run this on a client's machine to install and activate their SI.
Works on Windows, macOS, and Linux.

Usage:
    python3 install.py

What it does:
    1. Checks Python version and OS
    2. Installs pip dependencies
    3. Generates machine fingerprint
    4. Prompts for license key
    5. Activates with the license server
    6. Creates startup script
    7. Launches onboarding
"""

import hashlib
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import urllib.request
import urllib.error
import uuid

SYSTEM = platform.system()
# B11: ONE floor across both installers. 3.11 is set by numpy (>=3.11)
# and scipy (>=3.11), read from installed dist metadata — not a guess.
MIN_PYTHON = (3, 11)
LICENSE_SERVER = "https://license.sabr.co"

# ANSI colors (disabled on Windows without colorama)
if SYSTEM == "Windows":
    G, Y, R, B, RST = "", "", "", "", ""
else:
    G, Y, R, B, RST = "\033[92m", "\033[93m", "\033[91m", "\033[94m", "\033[0m"


def banner():
    print(f"""
{B}    ╔═══════════════════════════════════════╗
    ║       SABR — SI Installation          ║
    ║   Synthetic Intelligence Platform     ║
    ╚═══════════════════════════════════════╝{RST}
    """)


def check_python():
    v = sys.version_info
    if (v.major, v.minor) < MIN_PYTHON:
        print(f"{R}Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required. You have {v.major}.{v.minor}.{RST}")
        print(f"Download from https://python.org/downloads/")
        sys.exit(1)
    print(f"{G}[OK]{RST} Python {v.major}.{v.minor}.{v.micro}")


def check_os():
    print(f"{G}[OK]{RST} Platform: {SYSTEM} ({platform.machine()})")
    if SYSTEM == "Windows":
        print(f"     Dependencies: pyautogui, pygetwindow, pyperclip, screeninfo, plyer")
    elif SYSTEM == "Darwin":
        print(f"     Dependencies: cliclick (brew install cliclick), pyperclip, screeninfo, plyer")
    else:
        print(f"     Dependencies: xdotool, wmctrl, pyautogui, mss")


def install_dependencies():
    print(f"\n{B}Installing Python dependencies...{RST}")
    deps = [
        "fastapi", "uvicorn", "mss", "pyperclip", "screeninfo", "plyer",
        "pyautogui", "Pillow", "pytesseract", "python-dotenv",
    ]

    if SYSTEM == "Windows":
        deps.extend(["pygetwindow", "pywinauto"])
    elif SYSTEM == "Darwin":
        deps.append("pyobjc-framework-ApplicationServices")

    pip = [sys.executable, "-m", "pip", "install", "--quiet"] + deps
    r = subprocess.run(pip, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"{Y}Some dependencies may have failed. Continuing anyway.{RST}")
        if r.stderr:
            print(f"     {r.stderr[:200]}")
    else:
        print(f"{G}[OK]{RST} Dependencies installed")

    # macOS: check cliclick
    if SYSTEM == "Darwin":
        if not shutil.which("cliclick"):
            print(f"\n{Y}cliclick not found. Installing via Homebrew...{RST}")
            subprocess.run(["brew", "install", "cliclick"], capture_output=True)
            if shutil.which("cliclick"):
                print(f"{G}[OK]{RST} cliclick installed")
            else:
                print(f"{Y}cliclick not installed. Install manually: brew install cliclick{RST}")

    # Linux: check xdotool + wmctrl
    if SYSTEM == "Linux":
        for tool in ["xdotool", "wmctrl", "tesseract"]:
            if not shutil.which(tool):
                print(f"{Y}{tool} not found. Install: sudo apt install {tool}{RST}")


def machine_id() -> str:
    parts = [
        socket.gethostname(),
        format(uuid.getnode(), '012x'),
        platform.node(),
        platform.machine(),
        str(os.cpu_count() or 0),
    ]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:32]


def activate_license():
    print(f"\n{B}License Activation{RST}")
    print(f"Enter your license key (format: SABR-XXXX-XXXX-XXXX-XXXX)")
    print(f"You received this from Sabr when you signed up.\n")

    key = input("License key: ").strip()
    if not key:
        print(f"{R}No key entered. Exiting.{RST}")
        sys.exit(1)

    mid = machine_id()
    mname = f"{platform.node()} ({SYSTEM} {platform.machine()})"

    print(f"\nActivating... (machine: {mid[:12]}...)")

    data = json.dumps({
        "license_key": key,
        "machine_id": mid,
        "machine_name": mname,
    }).encode()

    req = urllib.request.Request(
        f"{LICENSE_SERVER}/api/license/activate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        try:
            result = json.loads(body)
        except Exception:
            result = {"ok": False, "error": f"HTTP {e.code}: {body[:200]}"}
    except Exception as e:
        print(f"{R}Cannot reach license server: {e}{RST}")
        print(f"Check your internet connection and try again.")
        sys.exit(1)

    if result.get("ok"):
        print(f"{G}[ACTIVATED]{RST} Welcome, {result.get('client_name', 'client')}!")
        print(f"     Plan: {result.get('plan', 'standard')}")
        return key
    else:
        print(f"{R}Activation failed: {result.get('error', 'Unknown error')}{RST}")
        sys.exit(1)


def create_env(license_key: str):
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    lines = []

    # Preserve existing .env if present
    if os.path.exists(env_path):
        with open(env_path, encoding="utf-8") as f:
            lines = f.readlines()

    # Update or add license key and server
    keys_to_set = {
        "LEON_LICENSE_KEY": license_key,
        "LICENSE_SERVER": LICENSE_SERVER,
    }

    for key, value in keys_to_set.items():
        found = False
        for i, line in enumerate(lines):
            if line.startswith(f"{key}=") or line.startswith(f"# {key}="):
                lines[i] = f"{key}={value}\n"
                found = True
                break
        if not found:
            lines.append(f"{key}={value}\n")

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    print(f"{G}[OK]{RST} .env updated with license key")


def create_startup_script():
    """Create a platform-appropriate startup script."""
    root = os.path.dirname(os.path.abspath(__file__))

    if SYSTEM == "Windows":
        script = os.path.join(root, "start.bat")
        with open(script, "w") as f:
            f.write(f'@echo off\ncd /d "{root}"\npython run.py --port 8000\npause\n')
        print(f"{G}[OK]{RST} Created start.bat")

    elif SYSTEM == "Darwin":
        script = os.path.join(root, "start.sh")
        with open(script, "w") as f:
            f.write(f'#!/bin/bash\ncd "{root}"\npython3 run.py --port 8000\n')
        os.chmod(script, 0o755)
        print(f"{G}[OK]{RST} Created start.sh")

    else:  # Linux
        script = os.path.join(root, "start.sh")
        with open(script, "w") as f:
            f.write(f'#!/bin/bash\ncd "{root}"\npython3 run.py --port 8000\n')
        os.chmod(script, 0o755)
        print(f"{G}[OK]{RST} Created start.sh")


def main():
    # ── DEPRECATION GATE ─────────────────────────────────────────────
    # This installer contains NO Claude/LLM connection step whatsoever —
    # no key prompt, no CLI check, no probe. It installs infra deps and a
    # license key, prints "Installation complete!", and offers to start a
    # brain that physically cannot think. Nothing references it; it just
    # sat here executable, one stale link or old clone away from producing
    # another mute SI. install_client.py is the real installer.
    if os.environ.get("LEON_ALLOW_LEGACY_INSTALL") != "1":
        print(
            "\n  install.py is the legacy license-key installer. It never\n"
            "  connects a thinking engine, so the SI it produces cannot\n"
            "  speak — and it will still tell you it succeeded.\n\n"
            "  Use the real installer instead:\n\n"
            "      ./setup.sh          (created by bootstrap.sh)\n"
            "      python3 install_client.py\n\n"
            "  Override with LEON_ALLOW_LEGACY_INSTALL=1 if you know why.\n",
            file=sys.stderr,
        )
        raise SystemExit(2)

    banner()
    check_python()
    check_os()
    install_dependencies()
    key = activate_license()
    create_env(key)
    create_startup_script()

    print(f"""
{G}Installation complete!{RST}

{B}To start your SI:{RST}""")

    if SYSTEM == "Windows":
        print(f"    Double-click start.bat")
        print(f"    Or run: python run.py --port 8000")
    else:
        print(f"    ./start.sh")
        print(f"    Or run: python3 run.py --port 8000")

    print(f"""
{B}Then open in your browser:{RST}
    http://localhost:8000/onboarding

Your SI will walk you through the birth process.

{Y}Need help? Contact dean@sabr.co{RST}
""")

    # Offer to start now
    start = input("Start your SI now? [Y/n] ").strip().lower()
    if start != "n":
        if SYSTEM == "Windows":
            subprocess.Popen(["python", "run.py", "--port", "8000"])
        else:
            subprocess.Popen(["python3", "run.py", "--port", "8000"])
        print(f"\n{G}SI starting...{RST} Open http://localhost:8000/onboarding")


if __name__ == "__main__":
    main()
