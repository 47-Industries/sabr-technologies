"""
Telephony — Twilio phone/SMS + ElevenLabs voice.

Gives Leon:
  - His own phone number (Twilio)
  - Send/receive SMS
  - Make outbound calls with ElevenLabs TTS voice
  - Receive inbound calls and respond with voice
  - Voicemail handling

For Gio: texts Leon's number, gets intelligent responses.
For lead gen: Leon texts/calls prospects as Dean.
"""

import base64
import io
import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Optional

from .config import (
    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER,
    ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID,
)

log = logging.getLogger("leon.business.telephony")


# --- ElevenLabs TTS ---

def text_to_speech(text: str, voice_id: str = None) -> bytes:
    """Convert text to speech audio using ElevenLabs. Returns MP3 bytes."""
    vid = voice_id or ELEVENLABS_VOICE_ID
    if not ELEVENLABS_API_KEY or not vid:
        log.warning("ElevenLabs not configured — returning empty audio")
        return b""

    url = f"https://api.elevenlabs.io/v1/text-to-speech/{vid}"
    payload = json.dumps({
        "text": text,
        "model_id": "eleven_turbo_v2_5",
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.75,
            "style": 0.3,
        }
    }).encode()

    req = urllib.request.Request(url, data=payload, headers={
        "Content-Type": "application/json",
        "xi-api-key": ELEVENLABS_API_KEY,
        "Accept": "audio/mpeg",
    })

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read()
    except Exception as e:
        log.error(f"ElevenLabs TTS failed: {e}")
        return b""


def text_to_speech_streaming_url(text: str, voice_id: str = None) -> str:
    """Get a streaming TTS URL for use in Twilio <Play> or <Stream>."""
    vid = voice_id or ELEVENLABS_VOICE_ID
    # ElevenLabs streaming endpoint — Twilio can fetch this directly
    return (
        f"https://api.elevenlabs.io/v1/text-to-speech/{vid}/stream"
        f"?output_format=ulaw_8000"
    )


# --- Twilio SMS ---

def _twilio_request(endpoint: str, data: Dict[str, str], method: str = "POST") -> Dict:
    """Make an authenticated request to the Twilio API."""
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN:
        log.warning("Twilio not configured")
        return {"error": "Twilio not configured"}

    url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/{endpoint}.json"
    encoded = urllib.parse.urlencode(data).encode() if data else None

    credentials = base64.b64encode(
        f"{TWILIO_ACCOUNT_SID}:{TWILIO_AUTH_TOKEN}".encode()
    ).decode()

    req = urllib.request.Request(url, data=encoded, method=method, headers={
        "Authorization": f"Basic {credentials}",
        "Content-Type": "application/x-www-form-urlencoded",
    })

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        log.error(f"Twilio API error {e.code}: {body}")
        return {"error": f"HTTP {e.code}", "detail": body}
    except Exception as e:
        log.error(f"Twilio request failed: {e}")
        return {"error": str(e)}


# Need urllib.parse for urlencode
import urllib.parse


def send_sms(to: str, body: str, from_number: str = None) -> Dict:
    """Send an SMS via Twilio."""
    from_num = from_number or TWILIO_PHONE_NUMBER
    if not from_num:
        return {"error": "No Twilio phone number configured"}

    result = _twilio_request("Messages", {
        "To": to,
        "From": from_num,
        "Body": body,
    })
    if "sid" in result:
        log.info(f"SMS sent to {to}: {body[:50]}...")
    return result


def make_call(to: str, twiml_url: str, from_number: str = None) -> Dict:
    """Initiate an outbound call. twiml_url serves the call script."""
    from_num = from_number or TWILIO_PHONE_NUMBER
    return _twilio_request("Calls", {
        "To": to,
        "From": from_num,
        "Url": twiml_url,
    })


def get_call_twiml_greeting(text: str) -> str:
    """Generate TwiML for Leon to speak on a call using ElevenLabs audio."""
    # For now, use Twilio's built-in <Say> with a neutral voice.
    # Phase 2: stream ElevenLabs audio via <Play> or Media Streams.
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Matthew">{text}</Say>
    <Gather input="speech" timeout="5" action="/api/business/call-response">
        <Say voice="Polly.Matthew">How can I help you?</Say>
    </Gather>
</Response>"""


def get_call_twiml_with_elevenlabs(text: str) -> str:
    """Generate TwiML that plays ElevenLabs audio (requires webhook to serve audio)."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Play>/api/business/tts-audio?text={urllib.parse.quote(text)}</Play>
    <Gather input="speech" timeout="5" action="/api/business/call-response">
        <Play>/api/business/tts-audio?text={urllib.parse.quote("How can I help you?")}</Play>
    </Gather>
</Response>"""


# --- Webhook handlers (called by Twilio when SMS/calls come in) ---

class InboundHandler:
    """Processes inbound SMS and calls from Twilio webhooks."""

    def __init__(self, respond_fn=None):
        """
        respond_fn: async function that takes (from_number, message_text, channel)
                    and returns Leon's response string.
        """
        self.respond_fn = respond_fn

    def handle_inbound_sms(self, from_number: str, body: str) -> str:
        """Process incoming SMS. Returns TwiML response."""
        log.info(f"Inbound SMS from {from_number}: {body[:100]}")

        if self.respond_fn:
            # Get Leon's response
            response_text = self.respond_fn(from_number, body, "sms")
        else:
            response_text = "Hey! Got your message. Let me look into that and get back to you."

        return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>{response_text}</Message>
</Response>"""

    def handle_inbound_call(self, from_number: str) -> str:
        """Process incoming call. Returns TwiML greeting."""
        log.info(f"Inbound call from {from_number}")
        greeting = "Hey, this is Leon. What's up?"
        return get_call_twiml_greeting(greeting)

    def handle_call_speech(self, from_number: str, speech_result: str) -> str:
        """Process speech input during a call. Returns TwiML with response."""
        log.info(f"Call speech from {from_number}: {speech_result}")

        if self.respond_fn:
            response_text = self.respond_fn(from_number, speech_result, "phone")
        else:
            response_text = "Got it. Let me think about that. I'll text you with more details."

        return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Matthew">{response_text}</Say>
    <Gather input="speech" timeout="5" action="/api/business/call-response">
        <Say voice="Polly.Matthew">Anything else?</Say>
    </Gather>
</Response>"""


# --- Phone number provisioning ---

def search_available_numbers(area_code: str = "727", limit: int = 5) -> list:
    """Search for available Twilio phone numbers in an area code."""
    if not TWILIO_ACCOUNT_SID or not TWILIO_AUTH_TOKEN:
        return []

    url = (
        f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}"
        f"/AvailablePhoneNumbers/US/Local.json"
        f"?AreaCode={area_code}&Limit={limit}"
    )

    credentials = base64.b64encode(
        f"{TWILIO_ACCOUNT_SID}:{TWILIO_AUTH_TOKEN}".encode()
    ).decode()

    req = urllib.request.Request(url, headers={
        "Authorization": f"Basic {credentials}",
    })

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            return data.get("available_phone_numbers", [])
    except Exception as e:
        log.error(f"Number search failed: {e}")
        return []


def buy_number(phone_number: str, sms_url: str = "", voice_url: str = "") -> Dict:
    """Purchase a Twilio phone number and configure webhooks."""
    data = {"PhoneNumber": phone_number}
    if sms_url:
        data["SmsUrl"] = sms_url
    if voice_url:
        data["VoiceUrl"] = voice_url

    return _twilio_request("IncomingPhoneNumbers", data)
