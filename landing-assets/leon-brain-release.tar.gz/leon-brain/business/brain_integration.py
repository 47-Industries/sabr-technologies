"""
Brain integration — hooks the business platform into Leon's autonomous loop.

Registers:
  1. A periodic routine that runs the pipeline tick every 30 minutes
  2. Lead gen discovery campaigns every 6 hours
  3. Daily pipeline report generation
  4. Inbound message handler wired to Leon's responder
  5. Tool definitions so Leon can use business tools via Claude

This is the glue between Leon's brain and the business system.
"""

import json
import logging
import threading
import time
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("leon.business.integration")


# --- Tools for Leon's Claude responder ---

BUSINESS_TOOLS = [
    {
        "name": "business_find_leads",
        "description": "Search for businesses in a location that need websites or AI automation. Returns scored and qualified leads.",
        "input_schema": {
            "type": "object",
            "properties": {
                "queries": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Industry search queries (e.g. ['landscaping companies', 'restaurants']). Defaults to all industries if empty."
                },
                "location": {
                    "type": "string",
                    "description": "Location to search (default: Indian Rocks Beach, FL)"
                }
            },
            "required": []
        }
    },
    {
        "name": "business_list_leads",
        "description": "List leads in the CRM pipeline, optionally filtered by stage (new, contacted, replied, qualified, call_scheduled, closed_won, cold).",
        "input_schema": {
            "type": "object",
            "properties": {
                "stage": {"type": "string", "description": "Filter by pipeline stage"},
                "limit": {"type": "integer", "description": "Max leads to return (default 20)"}
            },
            "required": []
        }
    },
    {
        "name": "business_lead_detail",
        "description": "Get full details on a lead — contact info, conversation history, AI assessment, talking points for Dean's call. Accepts the lead's UUID or the business name (substring match).",
        "input_schema": {
            "type": "object",
            "properties": {
                "lead_id": {"type": "string", "description": "Lead UUID (or the business name — names are resolved automatically)"},
                "name": {"type": "string", "description": "Business name to look up instead of an ID, e.g. 'The Shop Salon'"}
            }
        }
    },
    {
        "name": "business_send_outreach",
        "description": "Send outreach to a lead via email or SMS. Can provide custom message or let AI generate one in Dean's voice.",
        "input_schema": {
            "type": "object",
            "properties": {
                "lead_id": {"type": "string", "description": "Lead ID"},
                "channel": {"type": "string", "enum": ["email", "sms"], "description": "Communication channel"},
                "custom_message": {"type": "string", "description": "Custom message (optional — AI generates if empty)"}
            },
            "required": ["lead_id", "channel"]
        }
    },
    {
        "name": "business_send_sms",
        "description": "Send an SMS to any phone number via Leon's Twilio number.",
        "input_schema": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "Phone number to text"},
                "body": {"type": "string", "description": "Message text"}
            },
            "required": ["to", "body"]
        }
    },
    {
        "name": "business_generate_demo",
        "description": "Generate a personalized website audit or proposal demo for a lead. Gets the foot in the door.",
        "input_schema": {
            "type": "object",
            "properties": {
                "lead_id": {"type": "string", "description": "Lead ID"}
            },
            "required": ["lead_id"]
        }
    },
    {
        "name": "business_add_lead",
        "description": "Manually add a lead to the CRM pipeline.",
        "input_schema": {
            "type": "object",
            "properties": {
                "business_name": {"type": "string"},
                "owner_name": {"type": "string"},
                "phone": {"type": "string"},
                "email": {"type": "string"},
                "website": {"type": "string"},
                "industry": {"type": "string"},
                "city": {"type": "string"},
                "notes": {"type": "string"}
            },
            "required": ["business_name"]
        }
    },
    {
        "name": "business_pipeline_report",
        "description": "Generate a daily pipeline report — stats, hot leads, calls ready, pending tasks.",
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "business_pipeline_tick",
        "description": "Run one pipeline management cycle — process follow-ups, generate demos, archive cold leads, rescore, generate alerts.",
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
]


def handle_business_tool(tool_name: str, args: Dict[str, Any]) -> str:
    """Execute a business tool and return the result as a string."""
    try:
        if tool_name == "business_find_leads":
            from .lead_gen import run_discovery_campaign, save_discovered_leads
            leads = run_discovery_campaign(
                args.get("queries"),
                args.get("location"),
            )
            saved = save_discovered_leads(leads)
            return json.dumps({
                "discovered": len(leads),
                "saved": saved,
                "top_leads": [
                    {"name": l.get("name"), "score": l.get("score"),
                     "website": l.get("website", ""), "phone": l.get("formatted_phone_number", "")}
                    for l in leads[:10]
                ],
            })

        elif tool_name == "business_list_leads":
            from .database import list_leads
            leads = list_leads(
                stage=args.get("stage"),
                limit=args.get("limit", 20),
            )
            return json.dumps([{
                "id": l.id, "business_name": l.business_name,
                "stage": l.stage, "score": l.score,
                "phone": l.phone, "email": l.email,
                "industry": l.industry, "city": l.city,
            } for l in leads])

        elif tool_name == "business_lead_detail":
            from .pipeline import get_lead_detail
            lead_id = args.get("lead_id") or args.get("id")
            if lead_id:
                # Claude routinely passes the business NAME in the lead_id
                # slot (observed live 2026-06-11). If the value doesn't
                # match any real lead id, treat it as a name lookup.
                from .database import list_leads as _ll
                if not any(l.id == lead_id for l in _ll(limit=500)):
                    args = {**args, "name": args.get("name") or str(lead_id)}
                    lead_id = None
            if not lead_id:
                # Leon usually knows the business NAME, not the UUID —
                # he called this with {"name": "The Shop Salon"} during
                # the 2026-06-11 Fable test and got a bare KeyError.
                # Resolve names to ids here instead of bouncing him.
                name = (args.get("name") or args.get("business_name")
                        or args.get("query") or "").strip().lower()
                if not name:
                    return json.dumps({
                        "ok": False,
                        "error": "pass lead_id, or name/business_name "
                                 "to look one up",
                    })
                from .database import list_leads
                matches = [l for l in list_leads(limit=200)
                           if name in (l.business_name or "").lower()]
                if not matches:
                    return json.dumps({
                        "ok": False,
                        "error": f"no lead matching {name!r} — try "
                                 "business_list_leads to see what's in "
                                 "the CRM",
                    })
                if len(matches) > 1:
                    return json.dumps({
                        "ok": False,
                        "error": f"{len(matches)} leads match {name!r} — "
                                 "be more specific or pass lead_id",
                        "candidates": [
                            {"id": l.id, "business_name": l.business_name}
                            for l in matches[:5]
                        ],
                    })
                lead_id = matches[0].id
            return json.dumps(get_lead_detail(lead_id))

        elif tool_name == "business_send_outreach":
            from .outreach import execute_outreach
            result = execute_outreach(
                args["lead_id"],
                args.get("channel", "email"),
                args.get("custom_message"),
            )
            return json.dumps(result)

        elif tool_name == "business_send_sms":
            from .telephony import send_sms
            result = send_sms(args["to"], args["body"])
            return json.dumps(result)

        elif tool_name == "business_generate_demo":
            from .demo_builder import generate_demo_report
            result = generate_demo_report(args["lead_id"])
            return json.dumps(result, default=str)

        elif tool_name == "business_add_lead":
            from .database import create_lead
            from .pipeline import rescore_lead
            lead = create_lead(args)
            rescore_lead(lead.id)
            return json.dumps({"id": lead.id, "business_name": lead.business_name, "score": lead.score})

        elif tool_name == "business_pipeline_report":
            from .pipeline import generate_daily_report
            return generate_daily_report()

        elif tool_name == "business_pipeline_tick":
            from .pipeline import run_pipeline_tick
            result = run_pipeline_tick()
            return json.dumps(result)

        else:
            return json.dumps({"error": f"Unknown business tool: {tool_name}"})

    except Exception as e:
        log.error(f"Business tool {tool_name} failed: {e}", exc_info=True)
        return json.dumps({"error": str(e)})


# --- Routine registration ---

def register_business_routines(routine_add_fn: Callable) -> None:
    """
    Register business platform routines with Leon's routine scheduler.

    Call this from server startup after the routine scheduler is initialized.
    routine_add_fn should be routines.routine_add_custom.
    """
    def _pipeline_tick_action(ctx):
        from .pipeline import run_pipeline_tick
        result = run_pipeline_tick()
        alerts = result.get("alerts", [])
        for alert in alerts:
            if alert.get("type") == "call_ready":
                # Notify Dean immediately
                ctx.notify("Call Ready!", alert["message"])
                if hasattr(ctx, "tts") and ctx.tts:
                    ctx.tts(f"Dean, {alert['message']}")
        log.info(f"Pipeline tick: {result}")

    def _discovery_action(ctx):
        from .lead_gen import run_discovery_campaign, save_discovered_leads
        leads = run_discovery_campaign(max_results_per_query=10)
        saved = save_discovered_leads(leads)
        log.info(f"Discovery: found {len(leads)}, saved {saved}")
        if saved > 0:
            ctx.notify("New Leads", f"Found {saved} new leads!")

    def _daily_report_action(ctx):
        from .pipeline import generate_daily_report
        report = generate_daily_report()
        ctx.notify("Daily Pipeline Report", report[:500])
        log.info(f"Daily report generated")

    try:
        routine_add_fn(
            name="business_pipeline_tick",
            schedule="every 30m",
            action=_pipeline_tick_action,
            description="Run pipeline management: follow-ups, demos, archiving, scoring, alerts",
        )
        # Lead discovery is NOT registered. Dean's standing directive
        # (2026-07-30): there is more client work on the books than there is
        # time to deliver it, so hunting for more clients is not the job.
        # The second scheduler for it lives in business/daemon.py and is off
        # by the same flag. Set LEON_LEAD_GEN=1 to bring both back.
        import os as _os
        if _os.environ.get("LEON_LEAD_GEN", "0") == "1":
            routine_add_fn(
                name="business_lead_discovery",
                schedule="every 6h",
                action=_discovery_action,
                description="Run lead discovery campaign to find businesses without websites",
            )
        routine_add_fn(
            name="business_daily_report",
            schedule="0 8 *",  # 8 AM daily
            action=_daily_report_action,
            description="Generate and deliver daily pipeline report",
        )
        log.info("Business routines registered: pipeline_tick(30m), daily_report(8am); "
                 "lead discovery disabled by directive")
    except Exception as e:
        log.error(f"Failed to register business routines: {e}")
