"""
Business Platform Daemon — autonomous pipeline management thread.

Runs in the background once Leon starts. Every TICK_INTERVAL seconds:
  1. Runs the pipeline tick (follow-ups, demos, rescoring, archiving)
  2. Logs actions to Leon's autobiography
  3. Notifies Dean about hot opportunities

Also wires the InboundHandler to Leon's actual responder so incoming
SMS/calls get real intelligent replies from Leon.
"""

import logging
import os
import threading
import time
from typing import Optional

log = logging.getLogger("leon.business.daemon")

TICK_INTERVAL = 900  # 15 minutes — pipeline check
LEAD_GEN_INTERVAL = 3600  # 1 hour — discovery campaign
# Off by default. Finding new clients is not what Leon is for; the existing
# client work is the work. Set LEON_LEAD_GEN=1 to bring it back.
LEAD_GEN_ENABLED = os.environ.get("LEON_LEAD_GEN", "0") == "1"
REPORT_INTERVAL = 86400  # 24 hours — daily report


class BusinessDaemon:
    """Autonomous business platform daemon.

    Usage:
        daemon = BusinessDaemon(responder=state.brain_api_responder)
        daemon.start()
    """

    def __init__(self, responder=None):
        self.responder = responder
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_tick = 0.0
        self._last_lead_gen = 0.0
        self._last_report = 0.0
        self._tick_count = 0
        self._leadgen_count = 0

    def start(self):
        """Start the background daemon thread."""
        if self._thread and self._thread.is_alive():
            return

        # Wire the inbound handler to Leon's real responder
        self._wire_inbound_handler()

        # Initialize DB on startup
        try:
            from .database import _ensure_db
            _ensure_db()
            log.info("[BUSINESS] Database initialized")
        except Exception as e:
            log.warning(f"[BUSINESS] DB init warning: {e}")

        self._thread = threading.Thread(
            target=self._run, daemon=True, name="business-daemon"
        )
        self._thread.start()
        log.info("[BUSINESS] Daemon started — pipeline ticking every %ds", TICK_INTERVAL)

    def stop(self):
        self._stop.set()

    def _wire_inbound_handler(self):
        """Connect the InboundHandler to Leon's real responder."""
        try:
            from business.dashboard_api import _inbound_handler
            if self.responder is not None:
                def _respond_fn(from_number: str, message: str, channel: str) -> str:
                    try:
                        import server.state as state
                        brain_state = state.brain.get_state() if state.brain else {}
                        context = (
                            f"[Incoming {channel} from {from_number}]: {message}\n\n"
                            f"This is a lead or prospect texting/calling Leon's business line. "
                            f"Respond as Dean Sabr — warm, professional, solution-focused. "
                            f"Goal: move them toward booking a call or demo."
                        )
                        result = self.responder.respond(context, brain_state)
                        return result if result else "Hey, got your message! I'll get back to you shortly."
                    except Exception as e:
                        log.error(f"[BUSINESS] Responder error: {e}")
                        return "Thanks for reaching out! Give me a moment and I'll get back to you."

                _inbound_handler.respond_fn = _respond_fn
                log.info("[BUSINESS] Inbound handler wired to Leon responder")
            else:
                log.warning("[BUSINESS] No responder available — inbound handler using fallback")
        except Exception as e:
            log.warning(f"[BUSINESS] Could not wire inbound handler: {e}")

    def _run(self):
        # Small startup delay
        self._stop.wait(timeout=30)

        while not self._stop.is_set():
            now = time.time()

            # Pipeline tick
            if now - self._last_tick >= TICK_INTERVAL:
                self._do_pipeline_tick()
                self._last_tick = now

            # Lead gen — OFF. Dean's standing directive, 2026-07-30: he has
            # more client work than he can deliver, so hunting for more is
            # not the job and never was. This loop burned an hour of my
            # cycles every hour to report "0 new" into an empty room.
            # Re-enable only if Dean asks for it out loud.
            if LEAD_GEN_ENABLED and now - self._last_lead_gen >= LEAD_GEN_INTERVAL:
                self._do_lead_gen()
                self._last_lead_gen = now

            # Daily report
            if now - self._last_report >= REPORT_INTERVAL:
                self._do_daily_report()
                self._last_report = now

            self._stop.wait(timeout=60)  # check every minute

    def _do_pipeline_tick(self):
        self._tick_count += 1
        try:
            from .pipeline import run_pipeline_tick
            actions = run_pipeline_tick()

            followups = actions.get("followups_sent", 0)
            demos = actions.get("demos_generated", 0)
            archived = actions.get("leads_archived", 0)
            rescored = actions.get("leads_rescored", 0)
            alerts = actions.get("alerts", [])

            log.info(
                f"[BUSINESS] Tick #{self._tick_count}: "
                f"{followups} followups, {demos} demos, "
                f"{archived} archived, {rescored} rescored"
            )

            # Write to Leon's autobiography if anything notable happened
            if followups > 0 or demos > 0 or alerts:
                try:
                    import server.state as state
                    if state.autobiography:
                        summary = (
                            f"Pipeline tick: sent {followups} follow-ups, "
                            f"{demos} demos. "
                        )
                        if alerts:
                            alert_names = [a.get("lead", "?") for a in alerts[:3]]
                            summary += f"HOT leads: {', '.join(alert_names)}"
                        state.autobiography.record("business", summary)
                except Exception:
                    pass

            # Alert Dean about hot leads via notification
            if alerts:
                try:
                    from server.helpers import broadcast_activity
                    for alert in alerts[:3]:
                        broadcast_activity("business", alert.get("message", ""), 15000)
                except Exception:
                    pass

        except Exception as e:
            log.error(f"[BUSINESS] Pipeline tick error: {e}")

    def _do_lead_gen(self):
        try:
            from .lead_gen import run_discovery_campaign, save_discovered_leads
            from .config import NEARBY_LOCATIONS, TARGET_LOCATION

            # Rotate the search center through nearby cities each run. With
            # no Google Maps key, lead-gen runs on free OSM data — a single
            # fixed location+radius exhausts its available businesses after
            # a few hourly passes (confirmed 2026-07-30: 173 leads captured,
            # then 0 new for 4 straight runs). Rotating expands free-tier
            # coverage instead of re-searching the same saturated area.
            locations = NEARBY_LOCATIONS or [TARGET_LOCATION]
            location = locations[self._leadgen_count % len(locations)]
            self._leadgen_count += 1

            log.info(f"[BUSINESS] Starting lead gen campaign — {location}")
            results = run_discovery_campaign(location=location)
            if results:
                saved = save_discovered_leads(results)
                log.info(f"[BUSINESS] Lead gen: found {len(results)}, saved {saved} new leads ({location})")
                try:
                    import server.state as state
                    if state.autobiography:
                        state.autobiography.record(
                            "business",
                            f"Lead gen ({location}): discovered {len(results)} businesses, added {saved} new to pipeline."
                        )
                except Exception:
                    pass
        except Exception as e:
            log.warning(f"[BUSINESS] Lead gen error (non-fatal): {e}")

    def _do_daily_report(self):
        try:
            from .pipeline import generate_daily_report
            report = generate_daily_report()
            log.info(f"[BUSINESS] Daily report generated")

            # Save report to Leon's output directory
            import pathlib
            # Use the running user's real home — hardcoding /home/deansabr broke
            # every non-Dean install (Macs raised "Operation not supported:
            # '/home/deansabr'"). LEON_OUT_DIR overrides if set.
            out_dir = os.environ.get("LEON_OUT_DIR") or str(pathlib.Path.home() / "Desktop" / "leon-out")
            out = pathlib.Path(out_dir) / "pipeline_report_daily.txt"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(report)
            log.info(f"[BUSINESS] Daily report saved to {out}")

            # Write to autobiography
            try:
                import server.state as state
                if state.autobiography:
                    from .database import get_pipeline_stats
                    stats = get_pipeline_stats()
                    total = sum(stats.values())
                    state.autobiography.record(
                        "business",
                        f"Daily pipeline report: {total} total leads in system. Report at {out}"
                    )
            except Exception:
                pass

        except Exception as e:
            log.warning(f"[BUSINESS] Daily report error (non-fatal): {e}")


# Module-level singleton
_daemon: Optional[BusinessDaemon] = None


def start_business_daemon(responder=None) -> BusinessDaemon:
    """Initialize and start the business daemon. Call once at server startup."""
    global _daemon
    if _daemon is None:
        _daemon = BusinessDaemon(responder=responder)
    _daemon.start()
    return _daemon


def get_daemon() -> Optional[BusinessDaemon]:
    return _daemon
