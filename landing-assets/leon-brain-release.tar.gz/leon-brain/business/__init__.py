"""
Leon Business Platform — autonomous sales, lead gen, CRM, outreach, telephony.

This module gives Leon the ability to:
  - Find businesses that need websites/AI/automation (lead gen)
  - Reach out as Dean via email, SMS, phone, DMs (outreach)
  - Handle conversations autonomously (pipeline management)
  - Make/receive phone calls with ElevenLabs voice (telephony)
  - Build and send personalized demos (demo builder)
  - Manage a self-updating lead dashboard (CRM + dashboard API)
"""
