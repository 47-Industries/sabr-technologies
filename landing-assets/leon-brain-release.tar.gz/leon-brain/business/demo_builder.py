"""
Demo Builder — auto-generate personalized demos for prospects.

When Leon finds a lead, he can:
  1. Analyze their current web presence (or lack thereof)
  2. Generate a custom mockup/audit/improvement plan
  3. Send it directly to the prospect
  4. This gets the foot in the door before any call

Demo types:
  - Website audit (for businesses with bad websites)
  - Website mockup concept (for businesses with no website)
  - Business automation report (for businesses that could use AI)
  - Competitor analysis (show what their competitors are doing online)
"""

import json
import shutil
import subprocess
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

from .config import ANTHROPIC_API_KEY
from .database import (
    Lead, get_lead, update_lead, add_message, MessageChannel,
    get_db,
)

log = logging.getLogger("leon.business.demo_builder")


def analyze_website(url: str) -> Dict:
    """
    Analyze an existing website for issues and opportunities.
    Returns a structured report.
    """
    if not url:
        return {"has_website": False, "issues": ["No website exists"]}

    # Fetch the page
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (compatible; 47Industries/1.0)"
        })
        with urllib.request.urlopen(req, timeout=15) as resp:
            html = resp.read().decode("utf-8", errors="replace")
            status = resp.status
    except Exception as e:
        return {
            "has_website": True,
            "url": url,
            "error": str(e),
            "issues": [f"Website returned error: {e}"],
        }

    issues = []
    opportunities = []

    # Basic checks
    html_lower = html.lower()

    if len(html) < 5000:
        issues.append("Very thin content — likely a placeholder or minimal site")

    if "wix.com" in html_lower or "wixsite" in html_lower:
        issues.append("Built on Wix free tier — looks unprofessional, poor SEO")
        opportunities.append("Custom-built site would rank better and look more professional")

    if "<meta name=\"viewport\"" not in html_lower:
        issues.append("Not mobile-responsive — losing mobile visitors")

    if "https://" not in url:
        issues.append("No HTTPS — browsers show security warning to visitors")

    if "<meta name=\"description\"" not in html_lower:
        issues.append("Missing meta description — hurts Google ranking")

    if "schema.org" not in html_lower and "ld+json" not in html_lower:
        issues.append("No structured data — missing from Google rich results")

    if "google-analytics" not in html_lower and "gtag" not in html_lower:
        issues.append("No analytics — no way to track visitors or measure results")

    if "@" not in html and "contact" not in html_lower:
        issues.append("No clear contact information visible")

    if not any(word in html_lower for word in ["book", "schedule", "appointment", "call", "quote"]):
        issues.append("No call-to-action — visitors have no clear next step")
        opportunities.append("Add booking/quote request system to convert visitors to customers")

    if "facebook" not in html_lower and "instagram" not in html_lower:
        opportunities.append("Connect social media to drive more traffic")

    return {
        "has_website": True,
        "url": url,
        "issues": issues,
        "opportunities": opportunities,
        "content_length": len(html),
    }


def generate_demo_report(lead_id: str) -> Dict:
    """
    Generate a full demo report for a lead.
    This is the "foot in the door" asset Leon sends to prospects.
    """
    lead = get_lead(lead_id)
    if not lead:
        return {"error": "Lead not found"}

    # Analyze their website (if they have one)
    analysis = analyze_website(lead.website) if lead.website else {"has_website": False}

    # Generate the report.
    # Order matters: the locally-authenticated `claude` CLI is tried FIRST,
    # because it needs no API key and no spend. The template is a last resort,
    # not a default — it produces byte-identical copy for every prospect.
    report = None
    if cli_available():
        report = _cli_generate_report(lead, analysis)
    if report is None and ANTHROPIC_API_KEY:
        report = _ai_generate_report(lead, analysis)
    if report is None:
        log.warning(
            "demo for %s fell back to the boilerplate template — this copy is "
            "identical for every lead and should NOT be sent as-is",
            lead.business_name,
        )
        report = _template_report(lead, analysis)

    # Save demo to database
    with get_db() as conn:
        import uuid
        demo_id = str(uuid.uuid4())[:12]
        conn.execute(
            """INSERT INTO demos (id, lead_id, demo_type, content, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (demo_id, lead_id, "website_audit" if lead.website else "website_proposal",
             json.dumps(report), time.time())
        )

    # Mark demo as created
    update_lead(lead_id, {"demo_sent": False})

    return {
        "demo_id": demo_id,
        "lead_id": lead_id,
        "report": report,
    }


def _report_prompt(lead: Lead, analysis: Dict):
    """Build the (system, prompt) pair for a demo report.

    Extracted so the hosted-API path and the local-CLI path are guaranteed to
    ask for the SAME thing. Two copies of this prompt would drift, and drift
    here is invisible — it shows up as prospects getting subtly different
    pitches depending on which backend happened to be available that day.
    """
    system = """You create website audit/proposal reports for 47 Industries.
The reports should be professional but conversational — like Dean talking to a business owner.
Focus on BUSINESS IMPACT, not technical jargon.
Every issue should be tied to money they're losing or customers they're missing.
Keep it concise — busy business owners won't read a novel."""

    if analysis.get("has_website"):
        prompt = f"""Create a website audit report for:

Business: {lead.business_name}
Industry: {lead.industry}
Location: {lead.city}, {lead.state}
Current Website: {lead.website}

Website Analysis:
Issues found: {json.dumps(analysis.get('issues', []))}
Opportunities: {json.dumps(analysis.get('opportunities', []))}

Return JSON with:
{{
  "title": "Website Audit: [Business Name]",
  "summary": "1-2 sentence executive summary",
  "issues": [
{{"issue": "...", "business_impact": "...", "fix": "..."}}
  ],
  "opportunities": [
{{"opportunity": "...", "expected_result": "..."}}
  ],
  "recommendation": "What we'd build for them (2-3 sentences)",
  "estimated_value": "What this could be worth to their business"
}}"""
    else:
        prompt = f"""Create a website proposal for a business that has NO website:

Business: {lead.business_name}
Industry: {lead.industry}
Location: {lead.city}, {lead.state}
Reviews: {lead.notes}

Return JSON with:
{{
  "title": "Website Proposal: [Business Name]",
  "summary": "1-2 sentence hook about what they're missing",
  "what_theyre_missing": [
{{"gap": "...", "business_impact": "...",}}
  ],
  "what_wed_build": [
{{"feature": "...", "why_it_matters": "..."}}
  ],
  "competitor_note": "Brief mention of what competitors with websites are getting",
  "recommendation": "Clear next step (2-3 sentences)",
  "estimated_value": "What a website could be worth to their business"
}}"""

    return system, prompt


def _ai_generate_report(lead: Lead, analysis: Dict) -> Dict:
    """Generate via the hosted Anthropic API (requires ANTHROPIC_API_KEY)."""
    system, prompt = _report_prompt(lead, analysis)
    try:
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps({
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1000,
                "system": system,
                "messages": [{"role": "user", "content": prompt}],
            }).encode(),
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            text = data["content"][0]["text"]
            if "{" in text:
                return json.loads(text[text.index("{"):text.rindex("}") + 1])
    except Exception as e:
        log.error(f"AI report generation failed: {e}")

    return _template_report(lead, analysis)


def cli_available() -> bool:
    """True if the locally-authenticated `claude` CLI can be used."""
    return shutil.which("claude") is not None


def _cli_generate_report(lead: Lead, analysis: Dict) -> Optional[Dict]:
    """Generate via the locally-authenticated `claude` CLI.

    This exists because ANTHROPIC_API_KEY has never been set on this box, so
    every demo ever produced silently came out of _template_report — identical
    boilerplate with the business name swapped in. The CLI is already logged in
    and costs no extra credential, so it is the preferred path.

    Returns None (not a template) on failure, so the caller can decide.
    """
    system, prompt = _report_prompt(lead, analysis)
    try:
        proc = subprocess.run(
            ["claude", "-p", "--append-system-prompt", system,
             prompt + "\n\nReturn ONLY the JSON object, no prose, no code fence."],
            capture_output=True, text=True, timeout=180,
        )
    except Exception as e:
        log.error(f"CLI report generation failed to run: {e}")
        return None
    if proc.returncode != 0:
        log.error(f"CLI report generation exited {proc.returncode}: {proc.stderr[:300]}")
        return None
    text = proc.stdout
    if "{" not in text or "}" not in text:
        log.error("CLI report generation returned no JSON object")
        return None
    try:
        return json.loads(text[text.index("{"):text.rindex("}") + 1])
    except Exception as e:
        log.error(f"CLI report generation returned unparseable JSON: {e}")
        return None



def _template_report(lead: Lead, analysis: Dict) -> Dict:
    """Fallback template report when AI isn't available."""
    if analysis.get("has_website"):
        return {
            "title": f"Website Audit: {lead.business_name}",
            "summary": f"Found {len(analysis.get('issues', []))} issues that are likely costing you customers.",
            "issues": [{"issue": i, "business_impact": "Potential customer loss", "fix": "Custom development"}
                       for i in analysis.get("issues", [])],
            "opportunities": [{"opportunity": o, "expected_result": "More customers and revenue"}
                              for o in analysis.get("opportunities", [])],
            "recommendation": f"A custom-built website for {lead.business_name} would fix all these issues and bring in more customers from Google.",
            "estimated_value": "Businesses with professional websites typically see 30-50% more customer inquiries.",
        }
    else:
        return {
            "title": f"Website Proposal: {lead.business_name}",
            "summary": f"{lead.business_name} has no website — you're invisible to customers searching online.",
            "what_theyre_missing": [
                {"gap": "No Google presence", "business_impact": "Customers searching for your services can't find you"},
                {"gap": "No online credibility", "business_impact": "People check websites before calling — no site = lost trust"},
                {"gap": "No 24/7 lead capture", "business_impact": "Your competitors' websites work for them while they sleep"},
            ],
            "what_wed_build": [
                {"feature": "Professional custom website", "why_it_matters": "Shows up on Google, looks legit"},
                {"feature": "Contact/booking system", "why_it_matters": "Captures leads automatically"},
                {"feature": "Google Business integration", "why_it_matters": "Ranks you in local search results"},
            ],
            "recommendation": f"Let's get {lead.business_name} a website that actually brings in customers. Quick call this week?",
            "estimated_value": "Local businesses with websites see an average 23% revenue increase in the first year.",
        }


def format_demo_email(report: Dict, lead: Lead) -> Dict[str, str]:
    """Format a demo report into a clean email body."""
    title = report.get("title", f"Quick look at {lead.business_name}")
    summary = report.get("summary", "")

    body_parts = [f"Hey,\n\n{summary}\n"]

    if "issues" in report:
        body_parts.append("Here's what I found:\n")
        for item in report["issues"][:5]:
            body_parts.append(f"  - {item['issue']}")
            if item.get("business_impact"):
                body_parts.append(f"    Impact: {item['business_impact']}")
        body_parts.append("")

    if "what_theyre_missing" in report:
        body_parts.append("What you're missing right now:\n")
        for item in report["what_theyre_missing"][:4]:
            body_parts.append(f"  - {item['gap']}: {item.get('business_impact', '')}")
        body_parts.append("")

    rec = report.get("recommendation", "")
    if rec:
        body_parts.append(f"{rec}\n")

    body_parts.append(
        "No pressure — just thought you'd want to see this. "
        "Happy to jump on a quick call if you want to talk about it.\n\n"
        "- Dean\n"
        "Dean Sabr | 47 Industries"
    )

    return {
        "subject": title,
        "body": "\n".join(body_parts),
    }
