"""
Dashboard API — FastAPI routes for the lead management dashboard.

Serves:
  - Pipeline overview (stats, stages, totals)
  - Lead CRUD (list, detail, create, update, delete)
  - Conversation history per lead
  - Outreach actions (send email, sms, demo)
  - Pipeline reports
  - Twilio webhook endpoints (inbound SMS/calls)

Mount this on the main Leon server as a sub-app or include routes.
"""

import json
import logging
import time
from typing import Optional

from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

from .database import (
    create_lead, get_lead, update_lead, delete_lead, list_leads,
    get_pipeline_stats, get_conversation, add_message,
    get_pending_tasks, complete_task, LeadStage,
)
from .pipeline import (
    run_pipeline_tick, generate_daily_report, get_lead_detail, rescore_lead,
)
from .outreach import (
    execute_outreach, handle_inbound_message, generate_outreach_message,
)
from .demo_builder import generate_demo_report, format_demo_email
from .lead_gen import run_discovery_campaign, save_discovered_leads
from .telephony import (
    send_sms, InboundHandler, search_available_numbers, buy_number,
    text_to_speech,
)

log = logging.getLogger("leon.business.api")
router = APIRouter(prefix="/api/business", tags=["business"])

# Inbound message handler — will be wired to Leon's responder
_inbound_handler = InboundHandler(respond_fn=handle_inbound_message)


# --- Pydantic models ---

class LeadCreate(BaseModel):
    business_name: str
    owner_name: str = ""
    industry: str = ""
    phone: str = ""
    email: str = ""
    website: str = ""
    address: str = ""
    city: str = ""
    state: str = "FL"
    notes: str = ""
    source: str = "manual"


class LeadUpdate(BaseModel):
    business_name: Optional[str] = None
    owner_name: Optional[str] = None
    industry: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None
    stage: Optional[str] = None
    score: Optional[int] = None
    notes: Optional[str] = None
    deal_value: Optional[float] = None
    call_notes: Optional[str] = None


class OutreachRequest(BaseModel):
    channel: str = "email"
    custom_message: Optional[str] = None


class SMSRequest(BaseModel):
    to: str
    body: str


# --- Pipeline Overview ---

@router.get("/pipeline")
async def pipeline_overview():
    """Get full pipeline overview — stats, hot leads, alerts."""
    stats = get_pipeline_stats()
    hot = list_leads(stage=LeadStage.CALL_SCHEDULED.value, limit=10)
    replied = list_leads(stage=LeadStage.REPLIED.value, limit=10)
    recent = list_leads(limit=10, order_by="created_at DESC")

    return {
        "stats": stats,
        "total_leads": sum(stats.values()),
        "call_ready": [_lead_summary(l) for l in hot],
        "replied": [_lead_summary(l) for l in replied],
        "recent": [_lead_summary(l) for l in recent],
    }


@router.get("/pipeline/report")
async def daily_report():
    """Get the daily pipeline report text."""
    return {"report": generate_daily_report()}


# --- Lead CRUD ---

@router.get("/leads")
async def get_leads(stage: Optional[str] = None, limit: int = 100):
    """List leads, optionally filtered by stage."""
    leads = list_leads(stage=stage, limit=limit)
    return {"leads": [_lead_summary(l) for l in leads], "count": len(leads)}


@router.get("/leads/{lead_id}")
async def get_lead_details(lead_id: str):
    """Get full detail for a lead — everything for the dashboard detail view."""
    detail = get_lead_detail(lead_id)
    if "error" in detail:
        raise HTTPException(status_code=404, detail=detail["error"])
    return detail


@router.post("/leads")
async def create_new_lead(data: LeadCreate):
    """Manually create a lead."""
    lead = create_lead(data.model_dump())
    rescore_lead(lead.id)
    return {"lead": _lead_summary(lead)}


@router.patch("/leads/{lead_id}")
async def update_existing_lead(lead_id: str, data: LeadUpdate):
    """Update a lead's fields."""
    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No updates provided")
    lead = update_lead(lead_id, updates)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return {"lead": _lead_summary(lead)}


@router.delete("/leads/{lead_id}")
async def remove_lead(lead_id: str):
    """Delete a lead and all associated data."""
    success = delete_lead(lead_id)
    if not success:
        raise HTTPException(status_code=404, detail="Lead not found")
    return {"deleted": True}


# --- Outreach ---

@router.post("/leads/{lead_id}/outreach")
async def send_outreach(lead_id: str, data: OutreachRequest):
    """Send outreach to a lead via specified channel."""
    result = execute_outreach(lead_id, data.channel, data.custom_message)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/leads/{lead_id}/demo")
async def create_demo(lead_id: str):
    """Generate and optionally send a demo report for a lead."""
    result = generate_demo_report(lead_id)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.get("/leads/{lead_id}/conversation")
async def lead_conversation(lead_id: str):
    """Get full conversation history for a lead."""
    messages = get_conversation(lead_id)
    return {
        "messages": [
            {
                "id": m.id,
                "direction": m.direction,
                "channel": m.channel,
                "content": m.content,
                "subject": m.subject,
                "timestamp": m.timestamp,
            }
            for m in messages
        ]
    }


# --- Lead Generation ---

@router.post("/discover")
async def run_discovery(
    queries: Optional[list] = None,
    location: Optional[str] = None,
):
    """Run a lead discovery campaign. Returns found and saved leads."""
    leads = run_discovery_campaign(queries, location)
    saved = save_discovered_leads(leads)
    return {
        "discovered": len(leads),
        "saved": saved,
        "top_leads": [
            {"name": l.get("name"), "score": l.get("score"), "website": l.get("website", "")}
            for l in leads[:10]
        ],
    }


# --- Pipeline Automation ---

@router.post("/pipeline/tick")
async def trigger_pipeline_tick():
    """Manually trigger a pipeline tick (normally runs in autonomous loop)."""
    result = run_pipeline_tick()
    return result


# --- SMS / Phone Webhooks (Twilio) ---

@router.post("/webhook/sms")
async def twilio_sms_webhook(request: Request):
    """Twilio calls this when an SMS is received on Leon's number."""
    form = await request.form()
    from_number = form.get("From", "")
    body = form.get("Body", "")

    response_twiml = _inbound_handler.handle_inbound_sms(from_number, body)
    return Response(content=response_twiml, media_type="application/xml")


@router.post("/webhook/voice")
async def twilio_voice_webhook(request: Request):
    """Twilio calls this when a phone call comes in on Leon's number."""
    form = await request.form()
    from_number = form.get("From", "")

    response_twiml = _inbound_handler.handle_inbound_call(from_number)
    return Response(content=response_twiml, media_type="application/xml")


@router.post("/call-response")
async def twilio_call_response(request: Request):
    """Twilio calls this with speech input during a call."""
    form = await request.form()
    from_number = form.get("From", "")
    speech = form.get("SpeechResult", "")

    response_twiml = _inbound_handler.handle_call_speech(from_number, speech)
    return Response(content=response_twiml, media_type="application/xml")


@router.get("/tts-audio")
async def tts_audio(text: str):
    """Serve ElevenLabs audio for Twilio <Play> tags."""
    audio = text_to_speech(text)
    if not audio:
        raise HTTPException(status_code=500, detail="TTS failed")
    return Response(content=audio, media_type="audio/mpeg")


# --- Direct SMS send ---

@router.post("/sms")
async def send_direct_sms(data: SMSRequest):
    """Send an SMS directly (not tied to a lead)."""
    result = send_sms(data.to, data.body)
    return result


# --- Phone Number Management ---

@router.get("/phone/available")
async def available_numbers(area_code: str = "727"):
    """Search for available phone numbers."""
    numbers = search_available_numbers(area_code)
    return {"numbers": numbers}


@router.post("/phone/buy")
async def purchase_number(phone_number: str, webhook_base: str = ""):
    """Purchase a phone number and configure webhooks."""
    sms_url = f"{webhook_base}/api/business/webhook/sms" if webhook_base else ""
    voice_url = f"{webhook_base}/api/business/webhook/voice" if webhook_base else ""
    result = buy_number(phone_number, sms_url, voice_url)
    return result


# --- Tasks ---

@router.get("/tasks")
async def pending_tasks(limit: int = 20):
    """Get pending tasks."""
    tasks = get_pending_tasks(limit)
    return {
        "tasks": [
            {
                "id": t.id,
                "lead_id": t.lead_id,
                "action": t.action,
                "description": t.description,
                "due_at": t.due_at,
            }
            for t in tasks
        ]
    }


@router.post("/tasks/{task_id}/complete")
async def mark_task_complete(task_id: str):
    """Mark a task as completed."""
    complete_task(task_id)
    return {"completed": True}


# --- Helpers ---

def _lead_summary(lead) -> dict:
    """Convert a Lead to a summary dict for the API."""
    return {
        "id": lead.id,
        "business_name": lead.business_name,
        "owner_name": lead.owner_name,
        "industry": lead.industry,
        "phone": lead.phone,
        "email": lead.email,
        "website": lead.website,
        "city": lead.city,
        "state": lead.state,
        "stage": lead.stage,
        "score": lead.score,
        "last_contact": lead.last_contact,
        "conversation_count": lead.conversation_count,
        "demo_sent": bool(lead.demo_sent),
        "deal_value": lead.deal_value,
    }
