"""
Business platform configuration.

All secrets loaded from environment variables (set in .env or systemd EnvironmentFile).
"""

import os

# --- Twilio (phone + SMS) ---
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER", "")  # Leon's number

# --- ElevenLabs (voice) ---
ELEVENLABS_API_KEY = os.environ.get("ELEVENLABS_API_KEY", "")
ELEVENLABS_VOICE_ID = os.environ.get("ELEVENLABS_VOICE_ID", "")  # Leon's voice clone

# --- Email (outbound as Dean) ---
SMTP_HOST = os.environ.get("LEON_SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("LEON_SMTP_PORT", "587"))
SMTP_USER = os.environ.get("LEON_SMTP_USER", "")  # dean's email
SMTP_PASSWORD = os.environ.get("LEON_SMTP_PASSWORD", "")  # app password
EMAIL_FROM_NAME = os.environ.get("LEON_EMAIL_FROM_NAME", "Dean Sabr")
EMAIL_FROM_ADDRESS = os.environ.get("LEON_EMAIL_FROM_ADDRESS", "")

# --- Lead Gen ---
GOOGLE_MAPS_API_KEY = os.environ.get("GOOGLE_MAPS_API_KEY", "")
TARGET_LOCATION = os.environ.get("LEON_TARGET_LOCATION", "Indian Rocks Beach, FL")
TARGET_RADIUS_MILES = int(os.environ.get("LEON_TARGET_RADIUS_MILES", "30"))

# Rotation of nearby FL cities for lead gen when no Google Maps key is
# configured. Discovered 2026-07-30: with no key, lead-gen runs entirely on
# free OSM Overpass data against a single fixed TARGET_LOCATION + 30mi
# radius, hourly, forever — the free dataset in that one radius gets fully
# captured (173 leads) within a few runs, after which every subsequent run
# rediscovers the same businesses and saves 0 new ones. That's not a dedup
# bug, it's a saturated search area. Rotating the search center through
# nearby cities each hourly run expands free-tier coverage with zero cost.
# TARGET_LOCATION stays first/primary — this only matters when it's exhausted.
NEARBY_LOCATIONS = [
    loc.strip() for loc in os.environ.get(
        "LEON_NEARBY_LOCATIONS",
        "Indian Rocks Beach, FL|Clearwater, FL|Largo, FL|Seminole, FL|"
        "St. Petersburg, FL|Pinellas Park, FL|Dunedin, FL|Tampa, FL",
    ).split("|") if loc.strip()
]

# --- Database ---
import pathlib
DB_PATH = pathlib.Path(os.environ.get(
    "LEON_BUSINESS_DB",
    str(pathlib.Path(__file__).parent / "data" / "business.db")
))

# --- Dashboard ---
DASHBOARD_PORT = int(os.environ.get("LEON_DASHBOARD_PORT", "8090"))

# --- Anthropic (for demo generation + conversation AI) ---
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
