"""
CRM Database — SQLite-backed lead pipeline.

Tables:
  - leads: all prospects with scoring, stage, contact info, analysis
  - conversations: full message history per lead (email, sms, dm)
  - tasks: follow-ups, reminders, scheduled actions
  - demos: generated demos/mockups sent to leads
"""

import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import DB_PATH


class LeadStage(str, Enum):
    NEW = "new"
    RESEARCHED = "researched"
    CONTACTED = "contacted"
    REPLIED = "replied"
    QUALIFIED = "qualified"
    CALL_SCHEDULED = "call_scheduled"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"
    COLD = "cold"


class MessageChannel(str, Enum):
    EMAIL = "email"
    SMS = "sms"
    PHONE = "phone"
    INSTAGRAM_DM = "instagram_dm"
    FACEBOOK_DM = "facebook_dm"
    OTHER = "other"


@dataclass
class Lead:
    id: str = ""
    business_name: str = ""
    owner_name: str = ""
    industry: str = ""
    phone: str = ""
    email: str = ""
    website: str = ""  # empty = no website (our target)
    address: str = ""
    city: str = ""
    state: str = ""
    stage: str = LeadStage.NEW.value
    score: int = 0  # 0-100
    source: str = ""  # how we found them
    notes: str = ""
    problems_identified: str = ""  # JSON list
    solutions_proposed: str = ""  # JSON list
    ai_assessment: str = ""  # Leon's analysis
    revenue_estimate: str = ""
    last_contact: float = 0
    next_followup: float = 0
    created_at: float = 0
    updated_at: float = 0
    conversation_count: int = 0
    demo_sent: bool = False
    call_scheduled_at: float = 0
    call_notes: str = ""
    deal_value: float = 0
    social_profiles: str = ""  # JSON dict


@dataclass
class Message:
    id: str = ""
    lead_id: str = ""
    channel: str = MessageChannel.EMAIL.value
    direction: str = "outbound"  # inbound or outbound
    content: str = ""
    subject: str = ""  # for emails
    timestamp: float = 0
    read: bool = False
    metadata: str = ""  # JSON


@dataclass
class Task:
    id: str = ""
    lead_id: str = ""
    action: str = ""  # "follow_up", "send_demo", "schedule_call", "research"
    description: str = ""
    due_at: float = 0
    completed: bool = False
    created_at: float = 0


# --- Database initialization ---

_SCHEMA = """
CREATE TABLE IF NOT EXISTS leads (
    id TEXT PRIMARY KEY,
    business_name TEXT NOT NULL,
    owner_name TEXT DEFAULT '',
    industry TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    website TEXT DEFAULT '',
    address TEXT DEFAULT '',
    city TEXT DEFAULT '',
    state TEXT DEFAULT '',
    stage TEXT DEFAULT 'new',
    score INTEGER DEFAULT 0,
    source TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    problems_identified TEXT DEFAULT '[]',
    solutions_proposed TEXT DEFAULT '[]',
    ai_assessment TEXT DEFAULT '',
    revenue_estimate TEXT DEFAULT '',
    last_contact REAL DEFAULT 0,
    next_followup REAL DEFAULT 0,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    conversation_count INTEGER DEFAULT 0,
    demo_sent INTEGER DEFAULT 0,
    call_scheduled_at REAL DEFAULT 0,
    call_notes TEXT DEFAULT '',
    deal_value REAL DEFAULT 0,
    social_profiles TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    lead_id TEXT NOT NULL,
    channel TEXT NOT NULL,
    direction TEXT NOT NULL,
    content TEXT NOT NULL,
    subject TEXT DEFAULT '',
    timestamp REAL NOT NULL,
    read INTEGER DEFAULT 0,
    metadata TEXT DEFAULT '{}',
    FOREIGN KEY (lead_id) REFERENCES leads(id)
);

CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    lead_id TEXT DEFAULT '',
    action TEXT NOT NULL,
    description TEXT NOT NULL,
    due_at REAL DEFAULT 0,
    completed INTEGER DEFAULT 0,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS demos (
    id TEXT PRIMARY KEY,
    lead_id TEXT NOT NULL,
    demo_type TEXT NOT NULL,
    content TEXT NOT NULL,
    file_path TEXT DEFAULT '',
    sent_at REAL DEFAULT 0,
    opened INTEGER DEFAULT 0,
    created_at REAL NOT NULL,
    FOREIGN KEY (lead_id) REFERENCES leads(id)
);

CREATE INDEX IF NOT EXISTS idx_leads_stage ON leads(stage);
CREATE INDEX IF NOT EXISTS idx_leads_score ON leads(score DESC);
CREATE INDEX IF NOT EXISTS idx_leads_next_followup ON leads(next_followup);
CREATE INDEX IF NOT EXISTS idx_conversations_lead ON conversations(lead_id);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_at);
CREATE INDEX IF NOT EXISTS idx_tasks_completed ON tasks(completed);
"""


def _ensure_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(str(DB_PATH)) as conn:
        conn.executescript(_SCHEMA)


@contextmanager
def get_db():
    _ensure_db()
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


# --- CRUD Operations ---

def create_lead(data: Dict[str, Any]) -> Lead:
    now = time.time()
    lead_id = data.get("id") or str(uuid.uuid4())[:12]
    lead = Lead(
        id=lead_id,
        business_name=data.get("business_name", ""),
        owner_name=data.get("owner_name", ""),
        industry=data.get("industry", ""),
        phone=data.get("phone", ""),
        email=data.get("email", ""),
        website=data.get("website", ""),
        address=data.get("address", ""),
        city=data.get("city", ""),
        state=data.get("state", ""),
        stage=data.get("stage", LeadStage.NEW.value),
        score=data.get("score", 0),
        source=data.get("source", ""),
        notes=data.get("notes", ""),
        problems_identified=json.dumps(data.get("problems_identified", [])),
        solutions_proposed=json.dumps(data.get("solutions_proposed", [])),
        ai_assessment=data.get("ai_assessment", ""),
        revenue_estimate=data.get("revenue_estimate", ""),
        created_at=now,
        updated_at=now,
        social_profiles=json.dumps(data.get("social_profiles", {})),
    )
    with get_db() as conn:
        conn.execute(
            """INSERT INTO leads (id, business_name, owner_name, industry, phone,
               email, website, address, city, state, stage, score, source, notes,
               problems_identified, solutions_proposed, ai_assessment, revenue_estimate,
               created_at, updated_at, social_profiles)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (lead.id, lead.business_name, lead.owner_name, lead.industry,
             lead.phone, lead.email, lead.website, lead.address, lead.city,
             lead.state, lead.stage, lead.score, lead.source, lead.notes,
             lead.problems_identified, lead.solutions_proposed, lead.ai_assessment,
             lead.revenue_estimate, lead.created_at, lead.updated_at,
             lead.social_profiles)
        )
    return lead


def get_lead(lead_id: str) -> Optional[Lead]:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
        if not row:
            return None
        return Lead(**dict(row))


def update_lead(lead_id: str, updates: Dict[str, Any]) -> Optional[Lead]:
    updates["updated_at"] = time.time()
    set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
    values = list(updates.values()) + [lead_id]
    with get_db() as conn:
        conn.execute(f"UPDATE leads SET {set_clause} WHERE id = ?", values)
    return get_lead(lead_id)


def delete_lead(lead_id: str) -> bool:
    with get_db() as conn:
        conn.execute("DELETE FROM conversations WHERE lead_id = ?", (lead_id,))
        conn.execute("DELETE FROM tasks WHERE lead_id = ?", (lead_id,))
        conn.execute("DELETE FROM demos WHERE lead_id = ?", (lead_id,))
        result = conn.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
        return result.rowcount > 0


def list_leads(stage: Optional[str] = None, limit: int = 100,
               order_by: str = "score DESC") -> List[Lead]:
    with get_db() as conn:
        if stage:
            rows = conn.execute(
                f"SELECT * FROM leads WHERE stage = ? ORDER BY {order_by} LIMIT ?",
                (stage, limit)
            ).fetchall()
        else:
            rows = conn.execute(
                f"SELECT * FROM leads ORDER BY {order_by} LIMIT ?",
                (limit,)
            ).fetchall()
        return [Lead(**dict(r)) for r in rows]


def get_pipeline_stats() -> Dict[str, int]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT stage, COUNT(*) as cnt FROM leads GROUP BY stage"
        ).fetchall()
        return {r["stage"]: r["cnt"] for r in rows}


def get_leads_needing_followup() -> List[Lead]:
    now = time.time()
    with get_db() as conn:
        rows = conn.execute(
            """SELECT * FROM leads
               WHERE next_followup > 0 AND next_followup <= ?
               AND stage NOT IN ('closed_won', 'closed_lost', 'cold')
               ORDER BY next_followup ASC""",
            (now,)
        ).fetchall()
        return [Lead(**dict(r)) for r in rows]


def auto_archive_cold(days_inactive: int = 14) -> int:
    cutoff = time.time() - (days_inactive * 86400)
    with get_db() as conn:
        result = conn.execute(
            """UPDATE leads SET stage = 'cold', updated_at = ?
               WHERE stage IN ('contacted', 'replied')
               AND last_contact < ? AND last_contact > 0""",
            (time.time(), cutoff)
        )
        return result.rowcount


# --- Conversation tracking ---

def add_message(lead_id: str, channel: str, direction: str,
                content: str, subject: str = "", metadata: Dict = None) -> Message:
    msg = Message(
        id=str(uuid.uuid4())[:12],
        lead_id=lead_id,
        channel=channel,
        direction=direction,
        content=content,
        subject=subject,
        timestamp=time.time(),
        metadata=json.dumps(metadata or {}),
    )
    with get_db() as conn:
        conn.execute(
            """INSERT INTO conversations (id, lead_id, channel, direction, content,
               subject, timestamp, metadata)
               VALUES (?,?,?,?,?,?,?,?)""",
            (msg.id, msg.lead_id, msg.channel, msg.direction, msg.content,
             msg.subject, msg.timestamp, msg.metadata)
        )
        conn.execute(
            "UPDATE leads SET conversation_count = conversation_count + 1, last_contact = ?, updated_at = ? WHERE id = ?",
            (msg.timestamp, msg.timestamp, lead_id)
        )
    return msg


def get_conversation(lead_id: str) -> List[Message]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM conversations WHERE lead_id = ? ORDER BY timestamp ASC",
            (lead_id,)
        ).fetchall()
        return [Message(**dict(r)) for r in rows]


# --- Task management ---

def create_task(lead_id: str, action: str, description: str,
                due_at: float = 0) -> Task:
    task = Task(
        id=str(uuid.uuid4())[:12],
        lead_id=lead_id,
        action=action,
        description=description,
        due_at=due_at or time.time() + 86400,  # default: tomorrow
        created_at=time.time(),
    )
    with get_db() as conn:
        conn.execute(
            "INSERT INTO tasks (id, lead_id, action, description, due_at, created_at) VALUES (?,?,?,?,?,?)",
            (task.id, task.lead_id, task.action, task.description, task.due_at, task.created_at)
        )
    return task


def get_pending_tasks(limit: int = 20) -> List[Task]:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM tasks WHERE completed = 0 ORDER BY due_at ASC LIMIT ?",
            (limit,)
        ).fetchall()
        return [Task(**dict(r)) for r in rows]


def complete_task(task_id: str) -> None:
    with get_db() as conn:
        conn.execute("UPDATE tasks SET completed = 1 WHERE id = ?", (task_id,))
