"""
Outreach Automation — multi-channel communication as Dean.

Handles:
  - Email outreach (personalized cold emails)
  - SMS outreach (via Twilio)
  - Follow-up sequences
  - Response handling
  - Conversation management
  - Demo delivery

All outreach is in Dean's voice — conversational, direct, outcome-focused.
"""

import email.mime.multipart
import email.mime.text
import email.mime.base
import json
import logging
import smtplib
import time
from typing import Any, Dict, List, Optional

from .config import (
    SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD,
    EMAIL_FROM_NAME, EMAIL_FROM_ADDRESS, ANTHROPIC_API_KEY,
)
from .database import (
    Lead, add_message, get_conversation, get_lead, update_lead,
    create_task, MessageChannel, LeadStage,
)
from .telephony import send_sms

log = logging.getLogger("leon.business.outreach")


# --- Email ---

def send_email(to: str, subject: str, body: str, html: bool = False,
               attachments: List[Dict] = None) -> Dict:
    """
    Send an email as Dean.
    attachments: [{"filename": "demo.pdf", "content": bytes, "mime": "application/pdf"}]
    """
    if not SMTP_USER or not SMTP_PASSWORD:
        log.warning("SMTP not configured")
        return {"error": "SMTP not configured", "sent": False}

    msg = email.mime.multipart.MIMEMultipart()
    msg["From"] = f"{EMAIL_FROM_NAME} <{EMAIL_FROM_ADDRESS or SMTP_USER}>"
    msg["To"] = to
    msg["Subject"] = subject

    if html:
        msg.attach(email.mime.text.MIMEText(body, "html"))
    else:
        msg.attach(email.mime.text.MIMEText(body, "plain"))

    if attachments:
        for att in attachments:
            part = email.mime.base.MIMEBase("application", "octet-stream")
            part.set_payload(att["content"])
            import email.encoders
            email.encoders.encode_base64(part)
            part.add_header("Content-Disposition", f'attachment; filename="{att["filename"]}"')
            msg.attach(part)

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        log.info(f"Email sent to {to}: {subject}")
        return {"sent": True, "to": to, "subject": subject}
    except Exception as e:
        log.error(f"Email send failed: {e}")
        return {"error": str(e), "sent": False}


# --- Outreach Templates ---

def generate_outreach_message(lead: Lead, channel: str = "email",
                              context: str = "") -> Dict[str, str]:
    """
    Generate a personalized outreach message for a lead using Claude.
    Returns {"subject": ..., "body": ...} for email or {"body": ...} for SMS.

    Uses Claude to write in Dean's voice — conversational, direct, focused on
    their specific business problems and how we can help.
    """
    if not ANTHROPIC_API_KEY:
        return _template_outreach(lead, channel)

    # Build context about the lead
    lead_context = f"""
Business: {lead.business_name}
Industry: {lead.industry}
Location: {lead.city}, {lead.state}
Current website: {lead.website or 'NONE'}
Problems identified: {lead.problems_identified}
Revenue estimate: {lead.revenue_estimate}
Notes: {lead.notes}
"""

    system_prompt = """You are writing outreach messages AS Dean Sabr, CEO of 47 Industries.

Dean's style:
- Conversational and direct, never salesy or corporate
- Focuses on OUTCOMES and business results, not features
- Short sentences, gets to the point fast
- Adapts to the person — if it's a landscaper, talk about getting more jobs and looking professional
- Never uses phrases like "I hope this email finds you well" or "I wanted to reach out"
- Leads with value — what can he do for THEM specifically
- Confident but not arrogant
- Signs off casually: "- Dean" or "Dean Sabr | 47 Industries"

Dean's services:
- Custom website design & development (no templates, no Wix)
- AI business automation
- Lead generation systems
- Monthly management

Typical pricing: $3K-$7K setup + $500-$2K/month for ongoing management/AI features.
"""

    if channel == "email":
        user_prompt = f"""Write a cold outreach EMAIL to this business. Keep it under 150 words.
The goal: get them interested in a quick call about their website/online presence.

{lead_context}
{f"Additional context: {context}" if context else ""}

Return JSON: {{"subject": "...", "body": "..."}}
The subject should be casual and specific to their business (NOT generic like "Your Website").
The body should feel like a real person wrote it in 60 seconds, not a marketing team."""
    else:  # sms
        user_prompt = f"""Write a cold outreach TEXT MESSAGE (SMS) to this business owner.
Keep it under 160 characters if possible, max 300.
The goal: spark curiosity and get a reply.

{lead_context}
{f"Additional context: {context}" if context else ""}

Return JSON: {{"body": "..."}}
Should feel like a text from someone they almost know, not a bot."""

    try:
        import urllib.request
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps({
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 500,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_prompt}],
            }).encode(),
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            text = data["content"][0]["text"]
            # Extract JSON from response
            if "{" in text:
                json_str = text[text.index("{"):text.rindex("}") + 1]
                return json.loads(json_str)
    except Exception as e:
        log.error(f"AI outreach generation failed: {e}")

    return _template_outreach(lead, channel)


def _template_outreach(lead: Lead, channel: str) -> Dict[str, str]:
    """Fallback templates when AI generation isn't available."""
    name = lead.business_name
    if channel == "email":
        return {
            "subject": f"Quick question about {name}",
            "body": (
                f"Hey,\n\n"
                f"I was looking at businesses in {lead.city} and noticed {name} "
                + ("doesn't have a website yet. " if not lead.website else "could use a website upgrade. ")
                + "I build custom sites and AI tools for local businesses — "
                f"nothing cookie-cutter, just stuff that actually brings in more customers.\n\n"
                f"Would you be open to a quick 5-min call this week? "
                f"I can show you exactly what I'd do for {name}.\n\n"
                f"- Dean\n"
                f"Dean Sabr | 47 Industries"
            ),
        }
    else:
        no_site_text = "you don't have a website yet right?" if not lead.website else "your site could be doing way more for you."
        return {
            "body": (
                f"Hey! I saw {name} online — {no_site_text} "
                f"I build custom sites for local businesses. Would a quick call this week work?"
            ),
        }


# --- Outreach Execution ---

def execute_outreach(lead_id: str, channel: str = "email",
                     custom_message: str = None) -> Dict:
    """
    Execute outreach to a lead. Generates message, sends it, logs it.
    Returns result dict.
    """
    lead = get_lead(lead_id)
    if not lead:
        return {"error": f"Lead {lead_id} not found"}

    # Generate or use custom message
    if custom_message:
        message = {"body": custom_message}
        if channel == "email":
            message["subject"] = f"Quick question about {lead.business_name}"
    else:
        message = generate_outreach_message(lead, channel)

    # Send via appropriate channel
    result = {}
    if channel == "email":
        if not lead.email:
            return {"error": "No email address for this lead"}
        result = send_email(lead.email, message.get("subject", ""), message["body"])
    elif channel == "sms":
        if not lead.phone:
            return {"error": "No phone number for this lead"}
        result = send_sms(lead.phone, message["body"])
    else:
        return {"error": f"Unsupported channel: {channel}"}

    # Log the conversation
    if result.get("sent") or result.get("sid"):
        add_message(
            lead_id=lead_id,
            channel=channel,
            direction="outbound",
            content=message["body"],
            subject=message.get("subject", ""),
        )
        # Update lead stage
        if lead.stage == LeadStage.NEW.value or lead.stage == LeadStage.RESEARCHED.value:
            update_lead(lead_id, {"stage": LeadStage.CONTACTED.value})

        # Schedule follow-up
        create_task(
            lead_id=lead_id,
            action="follow_up",
            description=f"Follow up if no reply to {channel} outreach",
            due_at=time.time() + (3 * 86400),  # 3 days
        )

    return {"success": True, "channel": channel, "message": message, "result": result}


# --- Follow-up Sequences ---

def execute_followup(lead_id: str) -> Dict:
    """Check if a lead needs follow-up and send appropriate message."""
    lead = get_lead(lead_id)
    if not lead:
        return {"error": "Lead not found"}

    conversation = get_conversation(lead_id)
    outbound_count = sum(1 for m in conversation if m.direction == "outbound")

    if outbound_count >= 4:
        # Too many follow-ups — mark cold
        update_lead(lead_id, {"stage": LeadStage.COLD.value})
        return {"action": "marked_cold", "reason": "4+ outreach attempts with no reply"}

    # Generate follow-up based on conversation history
    if outbound_count == 1:
        channel = "email"
        msg = generate_outreach_message(lead, channel, context="This is a follow-up. Keep it short and add new value.")
    elif outbound_count == 2:
        channel = "sms"  # Switch to text on 3rd attempt
        msg = generate_outreach_message(lead, channel, context="Final follow-up attempt via text.")
    else:
        channel = "email"
        msg = generate_outreach_message(lead, channel, context="Last attempt. Be direct about what you can do.")

    return execute_outreach(lead_id, channel)


# --- Response Handling ---

def handle_inbound_message(from_contact: str, message_text: str,
                           channel: str) -> str:
    """
    Handle an inbound message from a lead/prospect.
    Identifies the lead, logs the message, generates Leon's response.
    Returns the response text.
    """
    from .database import get_db

    # Find lead by phone or email
    lead = None
    with get_db() as conn:
        if "@" in from_contact:
            row = conn.execute("SELECT * FROM leads WHERE email = ?", (from_contact,)).fetchone()
        else:
            # Normalize phone
            clean = re.sub(r'[^\d]', '', from_contact)[-10:]
            row = conn.execute(
                "SELECT * FROM leads WHERE phone LIKE ?", (f"%{clean}%",)
            ).fetchone()
        if row:
            lead = Lead(**dict(row))

    if not lead:
        # Unknown contact — might be Gio or existing client
        log.info(f"Message from unknown contact {from_contact}: {message_text[:100]}")
        return _generate_response_unknown(from_contact, message_text, channel)

    # Log inbound message
    add_message(lead.id, channel, "inbound", message_text)

    # Update stage
    if lead.stage in (LeadStage.CONTACTED.value, LeadStage.NEW.value):
        update_lead(lead.id, {"stage": LeadStage.REPLIED.value})

    # Generate contextual response
    return _generate_response(lead, message_text, channel)


def _generate_response(lead: Lead, message: str, channel: str) -> str:
    """Generate Leon's response to a lead's message, in Dean's voice."""
    conversation = get_conversation(lead.id)
    history = "\n".join(
        f"{'Dean' if m.direction == 'outbound' else lead.owner_name or 'Them'}: {m.content}"
        for m in conversation[-10:]
    )

    # Check if they're ready to schedule a call
    call_indicators = ["call", "phone", "talk", "schedule", "meet", "available", "free"]
    if any(word in message.lower() for word in call_indicators):
        update_lead(lead.id, {"stage": LeadStage.CALL_SCHEDULED.value})
        # Alert Dean
        return (
            "Yeah for sure! Let me check my schedule — what day works best for you? "
            "I'm pretty flexible this week."
        )

    if not ANTHROPIC_API_KEY:
        return "Hey! Got your message. Let me get back to you with more details shortly."

    try:
        import urllib.request
        system = """You are responding AS Dean Sabr in a business conversation.
Keep responses SHORT (1-3 sentences for text, 2-4 for email).
Be conversational, helpful, and move toward scheduling a call.
Never be pushy. Be genuinely helpful.
If they ask about pricing, give a range ($3K-7K setup, $500-2K/mo) and say it depends on scope.
If they seem interested, suggest a quick call."""

        prompt = f"""Lead: {lead.business_name} ({lead.industry})
Conversation so far:
{history}

They just said: {message}

Respond as Dean via {channel}. Keep it natural and short."""

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps({
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 300,
                "system": system,
                "messages": [{"role": "user", "content": prompt}],
            }).encode(),
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            response = data["content"][0]["text"]

            # Log outbound
            add_message(lead.id, channel, "outbound", response)
            return response
    except Exception as e:
        log.error(f"Response generation failed: {e}")
        return "Hey! Got your message — let me look into this and get back to you shortly."


def _generate_response_unknown(contact: str, message: str, channel: str) -> str:
    """Response for unknown contacts (could be Gio, could be a new lead)."""
    # For now, friendly generic response. Leon will learn contacts over time.
    return (
        "Hey! This is Leon with 47 Industries. "
        "Got your message — how can I help you today?"
    )


# Need re for phone normalization
import re
