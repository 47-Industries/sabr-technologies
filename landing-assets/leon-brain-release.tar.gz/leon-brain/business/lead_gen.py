"""
Lead Generation Engine — autonomous business discovery.

Finds businesses that:
  - Have no website (or a terrible one)
  - Are in the target area (Florida, primarily)
  - Are established and generating revenue
  - Would benefit from web dev, AI, or automation

Sources:
  - Google Maps / Places API
  - Google Search (site-less businesses)
  - Yelp scraping
  - Social media (Instagram/Facebook business pages without websites)
  - Local directories

The engine runs continuously in Leon's autonomous loop, feeding new leads
into the CRM database.
"""

import json
import logging
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

import requests

from .config import GOOGLE_MAPS_API_KEY, TARGET_LOCATION, TARGET_RADIUS_MILES
from .database import create_lead, list_leads, Lead, LeadStage

log = logging.getLogger("leon.business.lead_gen")


# --- Google Places API ---

def search_businesses_google(
    query: str,
    location: str = None,
    radius_meters: int = None,
) -> List[Dict]:
    """
    Search Google Places for businesses matching query in location.
    Returns list of business dicts with name, address, phone, website, rating, etc.
    """
    loc = location or TARGET_LOCATION
    radius = radius_meters or (TARGET_RADIUS_MILES * 1609)  # miles to meters

    if not GOOGLE_MAPS_API_KEY:
        log.warning("Google Maps API key not configured — using fallback search")
        return _fallback_search(query, loc)

    # Text Search (new) API
    url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
    params = urllib.parse.urlencode({
        "query": f"{query} in {loc}",
        "radius": radius,
        "key": GOOGLE_MAPS_API_KEY,
    })

    try:
        req = urllib.request.Request(f"{url}?{params}")
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())

        results = []
        for place in data.get("results", []):
            results.append({
                "name": place.get("name", ""),
                "address": place.get("formatted_address", ""),
                "place_id": place.get("place_id", ""),
                "rating": place.get("rating", 0),
                "reviews": place.get("user_ratings_total", 0),
                "types": place.get("types", []),
                "business_status": place.get("business_status", ""),
            })
        return results
    except Exception as e:
        log.error(f"Google Places search failed: {e}")
        return []


def get_place_details(place_id: str) -> Dict:
    """Get full details for a place (phone, website, hours, etc.)."""
    if not GOOGLE_MAPS_API_KEY:
        return {}

    url = "https://maps.googleapis.com/maps/api/place/details/json"
    params = urllib.parse.urlencode({
        "place_id": place_id,
        "fields": "name,formatted_phone_number,website,url,formatted_address,"
                  "opening_hours,business_status,types,rating,user_ratings_total",
        "key": GOOGLE_MAPS_API_KEY,
    })

    try:
        req = urllib.request.Request(f"{url}?{params}")
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        return data.get("result", {})
    except Exception as e:
        log.error(f"Place details fetch failed: {e}")
        return {}


# Query phrase -> OpenStreetMap tag filters. Covers SEARCH_CAMPAIGNS.
# Overpass QL fragment format: 'key'='value' (matched as [key=value]).
_OSM_TAG_MAP = {
    "landscaping": [("shop", "garden_centre"), ("craft", "gardener")],
    "pressure washing": [("shop", "cleaning")],
    "pool cleaning": [("shop", "pool")],
    "house cleaning": [("shop", "cleaning")],
    "handyman": [("craft", "handyman")],
    "painting contractors": [("craft", "painter")],
    "fence installation": [("craft", "fence_contractor")],
    "concrete contractors": [("craft", "builder")],
    "tree service": [("craft", "tree_service")],
    "pest control": [("shop", "pest_control")],
    "roofing": [("craft", "roofer")],
    "plumbing": [("craft", "plumber"), ("shop", "plumbing")],
    "electricians": [("craft", "electrician")],
    "hvac": [("craft", "hvac")],
    "restaurants": [("amenity", "restaurant")],
    "food trucks": [("amenity", "fast_food")],
    "smoke shop": [("shop", "tobacco"), ("shop", "e-cigarette")],
    "barbershop": [("shop", "hairdresser")],
    "nail salon": [("shop", "beauty")],
    "auto repair": [("shop", "car_repair")],
    "used car": [("shop", "car")],
    "real estate": [("office", "estate_agent")],
    "insurance": [("office", "insurance")],
    "tax preparation": [("office", "tax_advisor")],
    "personal trainer": [("leisure", "fitness_centre")],
    "photographer": [("shop", "photo")],
    "wedding venue": [("amenity", "events_venue")],
    "event planner": [("office", "event_planner")],
    "tutoring": [("office", "educational_institution")],
}


def _osm_tags_for_query(query: str) -> List[Tuple[str, str]]:
    q = query.lower()
    for key, tags in _OSM_TAG_MAP.items():
        if key in q:
            return tags
    return []


def _geocode(location: str) -> Optional[Tuple[float, float]]:
    """Free geocoding via OSM Nominatim. No key required."""
    try:
        resp = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": location, "format": "json", "limit": 1},
            headers={"User-Agent": "LeonBrain-LeadGen/1.0 (sabr.co)"},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        if not data:
            return None
        return float(data[0]["lat"]), float(data[0]["lon"])
    except Exception as e:
        log.warning(f"Geocode failed for '{location}': {e}")
        return None


def _fallback_search(query: str, location: str) -> List[Dict]:
    """
    Fallback when no Google API key — queries OpenStreetMap's Overpass
    API for real businesses by category near the geocoded location.
    Free, no key, no billing. Weaker than Places (no ratings/review
    counts, and OSM tag coverage varies by area), but it's real
    structured POI data instead of an always-empty stub.
    """
    log.info(f"Fallback search (OSM Overpass): {query} in {location}")
    results = []

    tags = _osm_tags_for_query(query)
    if not tags:
        log.info(f"No OSM tag mapping for '{query}' — skipping (no generic text search to avoid junk results)")
        return results

    coords = _geocode(location)
    if not coords:
        return results
    lat, lon = coords
    radius_m = min(TARGET_RADIUS_MILES * 1609, 50000)  # Overpass caps sane radius

    tag_filters = "".join(f'node["{k}"="{v}"](around:{radius_m},{lat},{lon});' for k, v in tags)
    overpass_query = f"[out:json][timeout:25];({tag_filters});out center 20;"

    try:
        resp = requests.post(
            "https://overpass-api.de/api/interpreter",
            data={"data": overpass_query},
            headers={"User-Agent": "LeonBrain-LeadGen/1.0 (sabr.co)"},
            timeout=30,
        )
        resp.raise_for_status()
        elements = resp.json().get("elements", [])

        for el in elements:
            t = el.get("tags", {})
            name = t.get("name")
            if not name:
                continue

            addr_parts = [
                t.get("addr:housenumber", ""),
                t.get("addr:street", ""),
                t.get("addr:city", ""),
                t.get("addr:state", ""),
            ]
            address = " ".join(p for p in addr_parts if p).strip() or location

            results.append({
                "name": name,
                "address": address,
                "place_id": f"osm:{el.get('type', 'node')}/{el.get('id', '')}",
                "rating": 0,
                "reviews": 0,
                "types": [f"{k}:{v}" for k, v in tags],
                "business_status": "",
                "website": t.get("contact:website") or t.get("website", ""),
                "phone": t.get("contact:phone") or t.get("phone", ""),
            })

        log.info(f"Fallback search: {len(results)} OSM candidates for '{query}' near {location}")
    except Exception as e:
        log.warning(f"Overpass search failed for '{query}' near {location}: {e}")

    return results[:20]


# --- Lead Qualification ---

def score_lead(business: Dict) -> int:
    """
    Score a business 0-100 based on how good a prospect they are.

    High scores:
      - No website (or very bad one)
      - Established (good reviews, been around)
      - Industry that benefits from web/AI
      - Has contact info available

    Low scores:
      - Already has good website
      - National chain
      - Very new (might not have budget)
    """
    score = 50  # baseline

    # No website = huge bonus
    website = business.get("website", "")
    if not website:
        score += 30
    elif _is_bad_website(website):
        score += 20
    else:
        score -= 20  # already has a decent site

    # Reviews indicate established business
    reviews = business.get("reviews", 0)
    if reviews >= 50:
        score += 15
    elif reviews >= 20:
        score += 10
    elif reviews >= 5:
        score += 5
    elif reviews == 0:
        score -= 10  # might be too new

    # Good rating = healthy business
    rating = business.get("rating", 0)
    if rating >= 4.5:
        score += 5
    elif rating < 3.0 and rating > 0:
        score -= 5

    # Has phone number = reachable
    if business.get("phone"):
        score += 5

    # Industry bonuses
    good_industries = [
        "restaurant", "contractor", "landscaping", "plumber", "electrician",
        "hvac", "roofing", "cleaning", "salon", "barbershop", "gym",
        "auto_repair", "dentist", "chiropractor", "real_estate", "lawyer",
        "accounting", "spa", "pet", "veterinary", "moving",
    ]
    types = business.get("types", [])
    industry = business.get("industry", "").lower()
    if any(ind in " ".join(types + [industry]) for ind in good_industries):
        score += 10

    # National chains already have corporate marketing/websites and won't
    # buy a local custom site — the docstring has promised this penalty
    # since this function was written, but nothing ever implemented it.
    KNOWN_CHAINS = [
        "orangetheory", "terminix", "mcdonald's", "mcdonalds", "starbucks",
        "subway", "jiffy lube", "great clips", "supercuts", "anytime fitness",
        "planet fitness", "massage envy", "h&r block", "jackson hewitt",
        "1-800", "servpro", "chick-fil-a", "domino's", "dominos", "pizza hut",
        "aaron's", "rent-a-center", "advance auto parts", "autozone",
        "midas", "meineke", "les schwab", "big o tires", "valvoline",
        "european wax center", "the joint chiropractic",
    ]
    name = (business.get("business_name") or business.get("name") or "").lower()
    if any(chain in name for chain in KNOWN_CHAINS):
        score -= 35

    return max(0, min(100, score))


def _is_bad_website(url: str) -> bool:
    """Check if a website is low-quality (placeholder, Wix free tier, dead, etc.)."""
    if not url:
        return True
    bad_indicators = [
        "wixsite.com", "weebly.com", "wordpress.com",  # free tier
        "squarespace.com",  # technically fine but signals DIY
        "facebook.com", "instagram.com",  # social-only
        "yelp.com", "yellowpages.com",  # directory page as "website"
    ]
    return any(ind in url.lower() for ind in bad_indicators)


# --- Discovery Campaigns ---

# Industries to search for that commonly lack websites
SEARCH_CAMPAIGNS = [
    # Service businesses (high value, often no website)
    "landscaping companies",
    "pressure washing",
    "pool cleaning service",
    "house cleaning service",
    "handyman services",
    "painting contractors",
    "fence installation",
    "concrete contractors",
    "tree service",
    "pest control",
    "roofing contractors",
    "plumbing companies",
    "electricians",
    "HVAC repair",

    # Local retail / food
    "restaurants",
    "food trucks",
    "smoke shops",
    "barbershops",
    "nail salons",
    "auto repair shops",
    "used car dealers",

    # Professional services
    "real estate agents",
    "insurance agents",
    "tax preparation",
    "personal trainers",
    "photographers",
    "wedding venues",
    "event planners",
    "tutoring services",
]


def run_discovery_campaign(
    campaign_queries: List[str] = None,
    location: str = None,
    max_results_per_query: int = 20,
) -> List[Dict]:
    """
    Run a full discovery campaign — search multiple industries,
    get details, score, and return qualified leads.
    """
    queries = campaign_queries or SEARCH_CAMPAIGNS
    loc = location or TARGET_LOCATION
    all_leads = []

    for query in queries:
        log.info(f"Searching: {query} in {loc}")
        businesses = search_businesses_google(query, loc)

        for biz in businesses[:max_results_per_query]:
            # Get full details
            details = {}
            if biz.get("place_id"):
                details = get_place_details(biz["place_id"])

            # Merge basic + details
            full = {**biz, **details}

            # Score it
            full["score"] = score_lead(full)

            # Only keep if score is decent
            if full["score"] >= 40:
                all_leads.append(full)

        # Rate limit — don't hammer APIs
        time.sleep(1)

    # Deduplicate by name+address
    seen = set()
    unique = []
    for lead in all_leads:
        key = (lead.get("name", "").lower(), lead.get("address", "").lower())
        if key not in seen:
            seen.add(key)
            unique.append(lead)

    # Sort by score
    unique.sort(key=lambda x: x.get("score", 0), reverse=True)

    log.info(f"Discovery complete: {len(unique)} qualified leads from {len(queries)} campaigns")
    return unique


def save_discovered_leads(leads: List[Dict]) -> int:
    """Save discovered leads to the CRM database. Skip duplicates."""
    saved = 0
    existing = {l.business_name.lower() for l in list_leads(limit=10000)}

    for lead_data in leads:
        name = lead_data.get("name", "")
        if name.lower() in existing:
            continue

        create_lead({
            "business_name": name,
            "phone": lead_data.get("formatted_phone_number", lead_data.get("phone", "")),
            "email": lead_data.get("email", ""),
            "website": lead_data.get("website", ""),
            "address": lead_data.get("formatted_address", lead_data.get("address", "")),
            "city": _extract_city(lead_data.get("formatted_address", "")),
            "state": "FL",
            "industry": _guess_industry(lead_data.get("types", [])),
            "score": lead_data.get("score", 50),
            "source": "google_places",
            "revenue_estimate": _estimate_revenue(lead_data),
            "notes": f"Rating: {lead_data.get('rating', 'N/A')}, "
                     f"Reviews: {lead_data.get('user_ratings_total', 0)}",
        })
        existing.add(name.lower())
        saved += 1

    log.info(f"Saved {saved} new leads to CRM")
    return saved


def _extract_city(address: str) -> str:
    """Pull the city out of an address, in either shape we actually receive.

    Two real formats arrive here and the old version only handled one:
      Google:  "123 Main St, Clearwater, FL 33755"   (comma separated)
      OSM:     "5867 Haines Road North Saint Petersburg FL"  (NO commas)
    The OSM shape is what lead_gen actually stores today, so every lead in the
    CRM had city="" — verified 2026-07-30 against 173 stored rows. The old code
    also did .split(" ")[0] on the city segment, which would have truncated
    "Saint Petersburg" to "Saint" even when commas were present.
    """
    if not address:
        return ""
    parts = [seg.strip() for seg in address.split(",") if seg.strip()]
    if len(parts) >= 3:
        return parts[-2]                      # "... , CITY, ST ZIP"
    if len(parts) == 2:
        # "Indian Rocks Beach, FL" -> the tail is only a state, so the city is
        # the FIRST segment. Returning the tail gave 78 leads a city of "FL".
        if re.fullmatch(r"[A-Z]{2}(\s+\d{5}(-\d{4})?)?", parts[-1]):
            return parts[0]
        return re.sub(r"\s+[A-Z]{2}(\s+\d{5})?$", "", parts[-1]).strip() or parts[0]
    # No commas: strip a trailing 2-letter state (and ZIP), then take the
    # trailing capitalised words as the city. Multi-word cities survive.
    tail = re.sub(r"\s+\d{5}(-\d{4})?$", "", address.strip())
    tail = re.sub(r"\s+([A-Z]{2})$", "", tail).strip()
    words = tail.split()
    STREET = {"street", "st", "avenue", "ave", "road", "rd", "boulevard", "blvd",
              "drive", "dr", "lane", "ln", "way", "court", "ct", "place", "pl",
              "terrace", "highway", "hwy", "circle", "cir", "parkway", "pkwy",
              "north", "south", "east", "west", "n", "s", "e", "w", "ne", "nw",
              "se", "sw", "suite", "ste", "unit", "#"}
    city = []
    for w in reversed(words):
        if w.lower().strip(".").isdigit() or w.lower().strip(".") in STREET:
            break
        if not w[:1].isupper():
            break
        city.insert(0, w)
        if len(city) >= 3:
            break
    return " ".join(city)


def _guess_industry(types: List[str]) -> str:
    """Map Google Places types to a readable industry."""
    type_map = {
        "restaurant": "Restaurant",
        "food": "Food & Beverage",
        "contractor": "Contractor",
        "plumber": "Plumbing",
        "electrician": "Electrical",
        "roofing_contractor": "Roofing",
        "painter": "Painting",
        "car_repair": "Auto Repair",
        "hair_care": "Salon",
        "gym": "Fitness",
        "real_estate_agency": "Real Estate",
        "lawyer": "Legal",
        "dentist": "Dental",
        "veterinary_care": "Veterinary",
        "moving_company": "Moving",
        "locksmith": "Locksmith",
        "pet_store": "Pet Services",
    }
    for t in types:
        if t in type_map:
            return type_map[t]
    return types[0].replace("_", " ").title() if types else "General"


def _estimate_revenue(data: Dict) -> str:
    """Rough revenue estimate based on reviews and type."""
    reviews = data.get("user_ratings_total", 0)
    if reviews > 200:
        return "$500K-$2M+/yr"
    elif reviews > 50:
        return "$200K-$500K/yr"
    elif reviews > 10:
        return "$50K-$200K/yr"
    else:
        return "< $50K/yr (estimate)"
