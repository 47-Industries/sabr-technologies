"""
Pipeline Manager — lead scoring, stage management, auto-actions.

This is the autonomous brain of the sales system. It runs in Leon's
autonomous loop and:
  - Scores and re-scores leads based on engagement
  - Moves leads through pipeline stages automatically
  - Triggers follow-ups when due
  - Archives cold leads
  - Alerts Dean when a call is ready
  - Generates daily/weekly pipeline reports
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional

from .database import (
    Lead, LeadStage, list_leads, get_lead, update_lead,
    get_pipeline_stats, get_leads_needing_followup, auto_archive_cold,
    get_pending_tasks, complete_task, get_conversation,
)
from .outreach import execute_followup, execute_outreach
from .demo_builder import generate_demo_report, format_demo_email
from .outreach import send_email

log = logging.getLogger("leon.business.pipeline")


# --- Lead Scoring ---

def rescore_lead(lead_id: str) -> int:
    """Recalculate a lead's score based on all available data."""
    lead = get_lead(lead_id)
    if not lead:
        return 0

    score = 50  # base

    # No website = high value target
    if not lead.website:
        score += 25
    elif "wix" in (lead.website or "").lower() or "weebly" in (lead.website or "").lower():
        score += 15

    # Engagement signals
    conversation = get_conversation(lead_id)
    inbound = [m for m in conversation if m.direction == "inbound"]
    if len(inbound) >= 3:
        score += 20  # very engaged
    elif len(inbound) >= 1:
        score += 15  # replied at least once

    # Call scheduled = very hot
    if lead.stage == LeadStage.CALL_SCHEDULED.value:
        score += 25

    # Revenue potential
    rev = lead.revenue_estimate.lower()
    if "$500k" in rev or "$2m" in rev or "$1m" in rev:
        score += 10
    elif "$200k" in rev:
        score += 5

    # Time decay — leads get colder over time without engagement
    if lead.last_contact > 0:
        days_since = (time.time() - lead.last_contact) / 86400
        if days_since > 14:
            score -= 15
        elif days_since > 7:
            score -= 5

    # Already closed
    if lead.stage == LeadStage.CLOSED_WON.value:
        score = 100
    elif lead.stage == LeadStage.CLOSED_LOST.value:
        score = 0
    elif lead.stage == LeadStage.COLD.value:
        score = max(score - 30, 5)

    score = max(0, min(100, score))
    update_lead(lead_id, {"score": score})
    return score


# --- Autonomous Pipeline Actions ---

def run_pipeline_tick() -> Dict[str, Any]:
    """
    Run one tick of the pipeline manager. Called by Leon's autonomous loop.
    Returns a summary of actions taken.
    """
    actions = {
        "followups_sent": 0,
        "demos_generated": 0,
        "leads_archived": 0,
        "leads_rescored": 0,
        "alerts": [],
    }

    # 1. Handle due follow-ups
    followup_leads = get_leads_needing_followup()
    for lead in followup_leads[:5]:  # max 5 per tick to avoid spam
        result = execute_followup(lead.id)
        if result.get("success") or result.get("action"):
            actions["followups_sent"] += 1

    # 2. Generate demos for high-score leads that don't have one
    hot_leads = list_leads(stage=LeadStage.RESEARCHED.value, limit=3)
    for lead in hot_leads:
        if lead.score >= 60 and not lead.demo_sent:
            demo = generate_demo_report(lead.id)
            if demo.get("report"):
                # Send the demo via email if we have their email
                if lead.email:
                    email_content = format_demo_email(demo["report"], lead)
                    send_email(lead.email, email_content["subject"], email_content["body"])
                    update_lead(lead.id, {"demo_sent": True, "stage": LeadStage.CONTACTED.value})
                    actions["demos_generated"] += 1

    # 3. Archive cold leads
    archived = auto_archive_cold(days_inactive=14)
    actions["leads_archived"] = archived

    # 4. Rescore active leads
    active_leads = list_leads(limit=50)
    for lead in active_leads:
        if lead.stage not in (LeadStage.CLOSED_WON.value, LeadStage.CLOSED_LOST.value):
            rescore_lead(lead.id)
            actions["leads_rescored"] += 1

    # 5. Alert Dean about hot opportunities
    call_ready = list_leads(stage=LeadStage.CALL_SCHEDULED.value)
    for lead in call_ready:
        actions["alerts"].append({
            "type": "call_ready",
            "lead": lead.business_name,
            "phone": lead.phone,
            "message": f"CALL READY: {lead.business_name} ({lead.phone}) wants to talk!",
        })

    # High-score leads that replied
    hot_replies = [l for l in list_leads(stage=LeadStage.REPLIED.value) if l.score >= 70]
    for lead in hot_replies:
        actions["alerts"].append({
            "type": "hot_lead",
            "lead": lead.business_name,
            "score": lead.score,
            "message": f"HOT LEAD: {lead.business_name} (score {lead.score}) is engaged — push for a call",
        })

    log.info(f"Pipeline tick: {actions['followups_sent']} followups, "
             f"{actions['demos_generated']} demos, {actions['leads_archived']} archived, "
             f"{len(actions['alerts'])} alerts")

    return actions


# --- Pipeline Reports ---

def generate_daily_report() -> str:
    """Generate a daily pipeline summary for Dean."""
    stats = get_pipeline_stats()
    total = sum(stats.values())

    hot = list_leads(stage=LeadStage.CALL_SCHEDULED.value)
    replied = list_leads(stage=LeadStage.REPLIED.value)
    qualified = list_leads(stage=LeadStage.QUALIFIED.value)

    report_lines = [
        "=== DAILY PIPELINE REPORT ===",
        f"Total leads: {total}",
        "",
        "Pipeline breakdown:",
    ]
    for stage, count in sorted(stats.items(), key=lambda x: x[1], reverse=True):
        report_lines.append(f"  {stage}: {count}")

    if hot:
        report_lines.append(f"\nCALLS READY ({len(hot)}):")
        for lead in hot:
            report_lines.append(f"  - {lead.business_name} | {lead.phone} | Score: {lead.score}")

    if replied:
        report_lines.append(f"\nREPLIED ({len(replied)}):")
        for lead in replied[:10]:
            report_lines.append(f"  - {lead.business_name} | Score: {lead.score}")

    pending_tasks = get_pending_tasks(limit=10)
    if pending_tasks:
        report_lines.append(f"\nPENDING TASKS ({len(pending_tasks)}):")
        for task in pending_tasks[:5]:
            report_lines.append(f"  - [{task.action}] {task.description}")

    return "\n".join(report_lines)


def get_lead_detail(lead_id: str) -> Dict:
    """
    Get full detail view for a lead — everything Dean needs to see
    when he clicks on a lead in the dashboard.
    """
    lead = get_lead(lead_id)
    if not lead:
        return {"error": "Lead not found"}

    conversation = get_conversation(lead_id)

    # Generate talking points
    talking_points = _generate_talking_points(lead)

    return {
        "lead": {
            "id": lead.id,
            "business_name": lead.business_name,
            "owner_name": lead.owner_name,
            "industry": lead.industry,
            "phone": lead.phone,
            "email": lead.email,
            "website": lead.website,
            "address": f"{lead.address}, {lead.city}, {lead.state}",
            "stage": lead.stage,
            "score": lead.score,
            "source": lead.source,
            "revenue_estimate": lead.revenue_estimate,
            "deal_value": lead.deal_value,
            "created_at": lead.created_at,
            "last_contact": lead.last_contact,
        },
        "analysis": {
            "problems": json.loads(lead.problems_identified) if lead.problems_identified else [],
            "solutions": json.loads(lead.solutions_proposed) if lead.solutions_proposed else [],
            "ai_assessment": lead.ai_assessment,
        },
        "conversation": [
            {
                "direction": m.direction,
                "channel": m.channel,
                "content": m.content,
                "timestamp": m.timestamp,
            }
            for m in conversation
        ],
        "talking_points": talking_points,
        "notes": lead.notes,
    }


def _generate_talking_points(lead: Lead) -> List[str]:
    """Generate talking points for Dean before a call."""
    points = []

    if not lead.website:
        points.append(f"They have NO website — you're offering something they clearly need")
    elif "wix" in (lead.website or "").lower():
        points.append(f"They're on Wix — talk about limitations, SEO issues, professionalism")

    if lead.industry:
        points.append(f"Industry: {lead.industry} — mention similar clients or relevant results")

    if lead.revenue_estimate:
        points.append(f"Estimated revenue: {lead.revenue_estimate} — they can afford this")

    conversation = get_conversation(lead.id)
    if conversation:
        last_msg = conversation[-1]
        if last_msg.direction == "inbound":
            points.append(f"Their last message: \"{last_msg.content[:100]}\" — address this directly")

    points.append("Ask about their biggest challenge right now — let them talk")
    points.append("Mention the demo/audit you sent if applicable")
    points.append("Goal: schedule a follow-up or close on the spot")

    return points
