#!/bin/bash
# Launcher with the custom hey_leon wake word.

# ── Auto-detect live X display ────────────────────────────────────────
# leon.service hardcodes DISPLAY=:1 but the real display can be :0 after
# a reboot (depends on display manager / Wayland fallback order). Probe
# the X sockets and export whichever one actually responds. If none
# respond, leave DISPLAY untouched and let downstream tools complain.
for _sock in /tmp/.X11-unix/X*; do
  [ -e "$_sock" ] || continue
  _num="${_sock##*/X}"
  if DISPLAY=":$_num" XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}" \
       timeout 1 xdpyinfo >/dev/null 2>&1; then
    export DISPLAY=":$_num"
    break
  fi
done
unset _sock _num

# Kill any lingering process on port 8000 from a previous crash
fuser -k 8000/tcp 2>/dev/null || true

cd /home/deansabr/Desktop/Leon-V1.3-SOURCE
export LEON_WAKE_BACKEND=openwakeword
export LEON_WAKE_MODEL_PATH=/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain_state/voice/wake_models/hey_leon.onnx
export LEON_WAKE_WORD=hey_leon
exec python3 run.py --neurons 10000
