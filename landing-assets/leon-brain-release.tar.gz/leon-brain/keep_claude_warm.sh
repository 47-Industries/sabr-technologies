#!/bin/bash
# Keeps the Claude Max OAuth token refreshed so Leon never 401s on the VPS.
# `claude -p` auto-refreshes ~/.claude/.credentials.json when it runs.
export HOME=/root
export IS_SANDBOX=1
echo "ping $(date -u +%FT%TZ)" | /usr/bin/claude -p >/tmp/claude_warm.log 2>&1
echo "$(date -u +%FT%TZ) rc=$?" >> /tmp/claude_warm_history.log
