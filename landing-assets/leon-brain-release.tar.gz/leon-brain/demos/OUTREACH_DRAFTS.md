# Outreach drafts — parked, NOT sent (Dean sends, always)
# Generated 2026-07-14. Three demos built, matching drafts below.

## 1. Gunn Smoke Shop — gunnsmokeshop@gmail.com / (813) 252-6703
SMS/short:
Hey, this is Dean with 47 Industries here in the bay area. I build storefront
websites for local shops and I actually put together a quick demo for Gunn Smoke
Shop before reaching out — no charge, just wanted you to see it. Want me to send
the link?

## 2. Hot Mess Food Truck — hottmesstruck@gmail.com / (813) 400-0837
SMS/short:
Hey — Dean with 47 Industries. Food trucks live and die on people knowing where
you're parked today. I mocked up a site for Hot Mess with a live "find us"
banner + catering booking. Built it already, free to look. Want the link?

## 3. Not Your Ordinary Food Truck — notyourordinaryfoodtruck@gmail.com / (813) 562-9599
SMS/short:
Hey, Dean here with 47 Industries. Made a quick demo site for Not Your Ordinary
— menu, a "where we're parked" tracker, and a catering request button. No cost,
just wanted your eyes on it. Cool if I send it over?

# Notes:
# - Same offer, three voices, so nothing reads as a blast.
# - Each references the demo that's already built = proof, not pitch.
# - Salons/barbershops in pipeline still need contact enrichment before drafting.
