#!/usr/bin/env bash
# Sabr SI — restore an identity archive written by uninstall.
#
#   bash restore_identity.sh ~/si-identity-backup-<stamp>.tar.gz
#   bash restore_identity.sh <archive> --into /path/to/leon-brain
#
# WHY THIS EXISTS
# ---------------
# The uninstaller has always written the archive. Nothing has ever read it.
# Its own printed instruction was "tar xzf that file into ~/leon-brain", and
# that instruction is wrong — proven by running it:
#
#   the archive holds  .env  brain_state  .leon
#   .env and brain_state DO belong inside the install directory.
#   .leon does NOT — the SI reads its learned skills, lessons, reflections
#   and tool health from  $HOME/.leon.
#
# So following the printed line put the cognition at ~/leon-brain/.leon, where
# nothing looks for it. The SI would boot, find no cognition, and start over
# from nothing — silently, with the user believing they had restored it. A
# backup that cannot be restored is not a backup, it is a comforting noise.
#
# This script puts every member back where its reader expects it, refuses to
# clobber anything without saying so, and verifies afterwards.

set -u

G="\033[32m"; Y="\033[33m"; R="\033[31m"; C="\033[36m"; D="\033[2m"; N="\033[0m"
say(){ printf "%b\n" "$1"; }

ARCHIVE="${1:-}"
INSTALL_DIR="$HOME/leon-brain"
shift 2>/dev/null || true
while [ $# -gt 0 ]; do
  case "$1" in
    --into) INSTALL_DIR="${2:-}"; shift 2 ;;
    *) shift ;;
  esac
done

if [ -z "$ARCHIVE" ] || [ ! -f "$ARCHIVE" ]; then
  say "${R}[ERROR]${N} usage: bash restore_identity.sh <archive.tar.gz> [--into <install dir>]"
  exit 1
fi

if ! tar tzf "$ARCHIVE" >/dev/null 2>&1; then
  say "${R}[ERROR]${N} $ARCHIVE is not a readable gzip archive."
  say "If you moved it between machines, it may have been corrupted in transit."
  exit 1
fi

MEMBERS="$(tar tzf "$ARCHIVE" 2>/dev/null | awk -F/ '{print $1}' | sort -u)"
say ""
say "${C}Sabr SI — restore identity${N}"
say "  archive     $ARCHIVE"
say "  install     $INSTALL_DIR"
say "  contains    $(echo $MEMBERS | tr '\n' ' ')"
say ""

if [ ! -d "$INSTALL_DIR" ]; then
  say "${R}[STOPPED]${N} $INSTALL_DIR does not exist."
  say "Install the SI first, then run this BEFORE its first boot — a booted SI"
  say "writes a fresh empty brain_state, and restoring over it afterwards means"
  say "the run you just did is lost."
  exit 1
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
if ! tar xzf "$ARCHIVE" -C "$TMP" 2>/dev/null; then
  say "${R}[STOPPED]${N} could not unpack the archive. Nothing has been changed."
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
RESTORED=0

# .env and brain_state -> the install directory.
for name in .env brain_state; do
  [ -e "$TMP/$name" ] || continue
  DEST="$INSTALL_DIR/$name"
  if [ -e "$DEST" ]; then
    mv "$DEST" "$DEST.replaced-$STAMP"
    say "  ${D}moved existing $name aside -> $(basename "$DEST").replaced-$STAMP${N}"
  fi
  cp -a "$TMP/$name" "$DEST" && { say "${G}[OK]${N} $name -> $DEST"; RESTORED=$((RESTORED+1)); }
done

# .leon -> $HOME, NOT the install directory. This is the whole point.
if [ -e "$TMP/.leon" ]; then
  DEST="$HOME/.leon"
  if [ -e "$DEST" ]; then
    mv "$DEST" "$DEST.replaced-$STAMP"
    say "  ${D}moved existing .leon aside -> .leon.replaced-$STAMP${N}"
  fi
  cp -a "$TMP/.leon" "$DEST" && { say "${G}[OK]${N} .leon -> $DEST  ${D}(learned skills, lessons, reflections)${N}"; RESTORED=$((RESTORED+1)); }
fi

# Verify at the layer the SI actually reads, not the layer we just wrote.
say ""
FAIL=0
for check in "$INSTALL_DIR/.env:.env" "$INSTALL_DIR/brain_state:brain_state" "$HOME/.leon:.leon"; do
  path="${check%%:*}"; label="${check##*:}"
  if echo "$MEMBERS" | grep -qx "$label"; then
    if [ -e "$path" ]; then
      say "${G}[VERIFIED]${N} $label is where the SI will look for it"
    else
      say "${R}[FAILED]${N} $label did not land at $path"
      FAIL=1
    fi
  fi
done

if [ "$RESTORED" -eq 0 ] || [ "$FAIL" -eq 1 ]; then
  say ""
  say "${R}Restore incomplete.${N} Your archive is untouched at $ARCHIVE."
  exit 1
fi

say ""
say "${G}Restored.${N} Start the SI — it should know its own name and remember you."
say "${D}Anything replaced was renamed .replaced-$STAMP, not deleted.${N}"
