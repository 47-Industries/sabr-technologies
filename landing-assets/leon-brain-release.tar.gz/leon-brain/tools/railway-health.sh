#!/bin/bash
# railway-health.sh — client site health report. Leon, 2026-08-06.
# Read-only: loops linked workspaces + explicit project IDs, prints metrics summary.
# Usage: railway-health.sh [output_file]
OUT="${1:-/root/Desktop/leon-out/railway_health_$(date +%Y%m%d_%H%M).txt}"
mkdir -p "$(dirname "$OUT")"
{
echo "RAILWAY CLIENT HEALTH REPORT — $(date '+%Y-%m-%d %H:%M %Z')"
echo "========================================================"
for ws in /opt/leon-brain/workspaces/*/; do
  [ -d "$ws/.git" ] || continue
  name=$(basename "$ws")
  echo ""
  echo "── $name ──"
  cd "$ws" || continue
  railway status 2>/dev/null | grep -E "Project:|Environment:" | head -2
  railway deployment list 2>/dev/null | head -3
  railway metrics --since 24h 2>/dev/null | grep -E "CPU|Memory|Egress|Ingress" | head -6
done
echo ""
echo "Done. Zero egress on a live site = healthy but unvisited — flag it."
} > "$OUT" 2>&1
echo "$OUT"
