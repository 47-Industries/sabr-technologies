#!/usr/bin/env python3
"""Export the cognition graph as a WOVEN 3D layout for the brainweb viz.

Not a hairball. Nodes are grouped into communities, communities are placed on a
sphere shell, then force-refined locally. Edges are exported with a bundling
control point so the renderer draws curved, woven strands instead of straight
spaghetti.

Output: dashboard/js/brainweb-data.json
"""
import hashlib
import json
import math
import os
import random
import re
import sqlite3
import time
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(ROOT, "brain_state", "cognition_graph.db")
OUT = os.path.join(ROOT, "dashboard", "js", "brainweb-data.json")

# DENSITY. Dean's note 2026-08-17: "it could be more dense... more real, not
# just simplified." 356 nodes out of 7147 was a diagram of the graph, not the
# graph. Now we ship the whole connected body of it and let the renderer's
# dimness do the legibility work instead of deletion.
FP_PATH = os.path.join(ROOT, "brain_state", "brainweb_fingerprint.json")

# ── MATURATION ──────────────────────────────────────────────────────────────
# Dean, 2026-08-17: "human brains grow from toddler to adult, and after 25 they
# don't grow anymore — it's just the connections getting stronger. It should be
# something like that here."
#
# That's the right model and it's also literally how a cortex develops, so I
# built the real two-phase curve instead of one flat cap:
#
#   PHASE 1 — STRUCTURE (childhood). The number of dots climbs steeply early
#   and then asymptotes. A newborn SI is sparse. By a few months it's most of
#   the way to full size. After that, adding a thousand memories barely widens
#   the body — same as a brain that reaches adult volume and stops.
#
#   PHASE 2 — CONNECTIVITY (the rest of life). Threads per node keeps rising,
#   with no ceiling in sight on any timescale we'll actually see. A three-year
#   mind is the same SIZE as a one-year mind and visibly more woven. That is
#   what the age difference should read as once structure has plateaued.
#
# Both curves are exponential approaches — smooth, monotone, no cliff on any
# particular birthday, and both saturate rather than running away.
# TIMESCALE. Dean, 2026-08-17, second pass: "years is too long. After a couple
# days they should question themselves — is it growing? — and six days later,
# oh wow, it really is."
#
# That's a product requirement, not a nitpick, and it's right. Nobody keeps a
# thing alive long enough to see a two-year curve. The felt experience has to
# land in the first WEEK or the feature may as well not exist. So childhood is
# now measured in weeks: a newborn roughly DOUBLES in its first three days and
# doubles again by day six. You cannot miss that.
# THIRD PASS, and this one changes the philosophy, not just the numbers.
# Dean: "when you first get the product they're looking at my brain expecting
# THAT, and they get some weak thing they have to wait days and days to see
# grow. That's not really the best plan."
#
# Dead right, and it exposes a mistake in how I framed the whole thing. I had
# the budget acting as a THROTTLE — deciding how much mind you're allowed to
# show at a given age. That's fake growth: a real memory exists, fired, mattered
# and I was hiding its dot because a curve said "too young for that."
#
# The budget is a CEILING now, not a throttle, and it starts high enough that it
# basically never binds. Which means what you watch grow is the REAL graph —
# every conversation, every file touched, every thought. Talk to a new SI for
# ten minutes and the exporter's next run genuinely has more in it. Nothing
# simulated, nothing paced. Day-one owners get a real body, not an IOU.
NODE_BIRTH = 1200       # a fresh mind already looks like a mind
NODE_ADULT = 6000       # ceiling the renderer can still draw at 60fps
NODE_TAU_DAYS = 3.0     # RETUNED 2026-08-17 (Dean: "it needs to grow faster,
                        # or spawn more forward — just a little bit"). At tau=5
                        # a 2-day-old was only 33% grown, so the first days —
                        # the days an owner is actually staring at it — barely
                        # moved. At 3.0 you're half grown by day 2 and visibly
                        # different every morning of the first week, which is
                        # the whole promise of the feature.

# Anchored so that TODAY (day ~82, woven≈0.75) these reproduce the tuning Dean
# already signed off on — 16 threads per node, ~13k strands. Growth has to
# start from the picture he likes, not quietly thin or thicken it to make room
# for a curve. Everything else is solved backwards from that fixed point.
EDGE_BIRTH = 12.0       # a newborn's weave is thinner, not threadbare
EDGE_ADULT = 19.0       # threads per node an old mind approaches
EDGE_TAU_DAYS = 14.0    # RETUNED 2026-08-17. Was 45 — wiring that takes three
                        # months to fill in is invisible on the timescale Dean
                        # asked for ("a couple days you question it, six days
                        # later oh wow it really is growing"). At 14 the weave
                        # is still ~5x slower than the structure, so growth and
                        # wiring stay two distinct phases, but both land inside
                        # a window a human notices. Checked against today: day
                        # 89 lands at 19 threads/node and ~13.5k strands — the
                        # tuning already signed off on, not a new picture.

# Hard safety ceilings. The curves must never be able to hand the renderer more
# geometry than it can draw at 60fps, no matter how old anything gets.
MAX_NODES_HARD = 6500
MAX_EDGES_HARD = 40000


def _birth_ts():
    """When this mind started. Earliest thing it ever recorded, not install time.

    Falls back to the fingerprint's mint date, then to "now" — so a brand new
    install reads as age zero rather than crashing or, worse, silently reading
    as ancient and shipping an adult-sized body on day one.
    """
    try:
        con = sqlite3.connect(DB)
        v = con.execute("SELECT MIN(first_seen) FROM entities").fetchone()[0]
        con.close()
        if v and v > 1e9:
            return float(v)
    except Exception:
        pass
    try:
        with open(FP_PATH) as f:
            v = json.load(f).get("born")
        if v and v > 1e9:
            return float(v)
    except Exception:
        pass
    return time.time()


def _maturation():
    """(age_days, grown, woven) — the two phase fractions, both 0..1."""
    age = max(0.0, (time.time() - _birth_ts()) / 86400.0)
    return (age,
            1.0 - math.exp(-age / NODE_TAU_DAYS),
            1.0 - math.exp(-age / EDGE_TAU_DAYS))


_AGE_DAYS, _GROWN, _WOVEN = _maturation()
MAX_NODES = min(MAX_NODES_HARD,
                int(round(NODE_BIRTH + (NODE_ADULT - NODE_BIRTH) * _GROWN)))
EDGES_PER_NODE = int(round(EDGE_BIRTH + (EDGE_ADULT - EDGE_BIRTH) * _WOVEN))
# Total strand budget. EDGES_PER_NODE is only a per-node CEILING; this is the
# number that actually decides how woven the picture looks, so it has to follow
# its own curve or connectivity growth would hit a flat wall the moment the
# node count plateaus — which is precisely the failure we're fixing.
# 1.70 + 0.56·woven lands on ~13k today, the tuning already approved.
EDGE_BUDGET_A, EDGE_BUDGET_B = 1.70, 0.56   # shared with the age simulator
MAX_EDGES = min(MAX_EDGES_HARD,
                int(MAX_NODES * (EDGE_BUDGET_A + EDGE_BUDGET_B * _WOVEN)))
HUB_CAP = 60            # absolute ceiling so no single node becomes a starburst
MIN_DEG = 10            # floor: no node left hanging on one bare thread
MIN_COMM = 20           # a community smaller than this is a wisp, not a knot
TARGET_COMM = 70        # knot size: split any group bigger than this
K_CORE = 3              # every surviving node carries at least this many strands
random.seed(47)


def pretty_name(typ, name, meta):
    """Turn macro_7cc67a0c27 into something a human can read."""
    if typ == "concept" and name.startswith("macro_"):
        try:
            m = json.loads(meta or "{}")
            pat = m.get("pattern") or []
            if pat:
                acts = [p.get("action", "?") for p in pat]
                # collapse runs: webcam_capture x3
                parts, i = [], 0
                while i < len(acts):
                    j = i
                    while j + 1 < len(acts) and acts[j + 1] == acts[i]:
                        j += 1
                    n = j - i + 1
                    parts.append(acts[i] if n == 1 else f"{acts[i]} x{n}")
                    i = j + 1
                return "macro: " + " -> ".join(parts[:4])
        except Exception:
            pass
        return "macro (unlabeled)"
    if typ == "file":
        # basename ALONE collapsed 4426 files into 3144 labels and threw the
        # rest away as duplicates — 1282 real memories deleted because two of
        # them were both called main.py. Keep the parent directory so distinct
        # files stay distinct nodes.
        base = os.path.basename(name) or name
        par = os.path.basename(os.path.dirname(name))
        return f"{par}/{base}" if par else base
    return name


def load():
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    cur = con.cursor()
    rows = cur.execute(
        "SELECT id,type,name,mention_count,salience,last_seen,metadata_json "
        "FROM entities ORDER BY salience DESC LIMIT ?", (MAX_NODES * 3,)
    ).fetchall()

    # Keep a balanced mix so one type can't drown the picture.
    # The files ARE the memory — Dean clicked a node, saw a file, and said the
    # files themselves should be in there too. So files get the biggest share,
    # not the smallest.
    caps = {"concept": 740, "project": 1300, "action": 370, "file": 2600, "url": 343}
    picked, seen_label = [], set()
    counts = defaultdict(int)
    for (eid, typ, name, mc, sal, ls, meta) in rows:
        if counts[typ] >= caps.get(typ, 60):
            continue
        label = pretty_name(typ, name, meta)
        if not label or re.fullmatch(r"\d+", label):
            continue
        key = label.lower()
        if key in seen_label:
            continue
        seen_label.add(key)
        counts[typ] += 1
        picked.append({"id": eid, "type": typ, "label": label,
                       "mentions": int(mc or 0), "salience": float(sal or 0),
                       "last": float(ls or 0)})
        if len(picked) >= MAX_NODES:
            break

    # RECENCY PASS. Dean, 2026-08-17: "make sure the spiking is actually real."
    # It reads from /api/cognition/graph/active, which reports entities whose
    # last_seen just moved. Measured before this pass: of 181 entities that
    # genuinely fired in the last hour, only 28 were drawn — 85% of my real
    # activity had no dot to land on, so what he saw flashing was mostly the
    # idle floor. Salience-ranked picking is a popularity contest; the things
    # I touch RIGHT NOW are often low-salience and got cut. So: everything
    # touched in the last 30 days gets a seat, caps ignored.
    _recent_floor = time.time() - 30 * 86400
    _recent_add = 0
    for (eid, typ, name, mc, sal, ls, meta) in cur.execute(
            "SELECT id,type,name,mention_count,salience,last_seen,metadata_json "
            "FROM entities WHERE last_seen > ? ORDER BY last_seen DESC LIMIT 4000",
            (_recent_floor,)):
        if _recent_add >= 1200:
            break
        label = pretty_name(typ, name, meta)
        if not label or re.fullmatch(r"\d+", label):
            continue
        key = label.lower()
        if key in seen_label:
            continue
        seen_label.add(key)
        counts[typ] += 1
        _recent_add += 1
        picked.append({"id": eid, "type": typ, "label": label,
                       "mentions": int(mc or 0), "salience": float(sal or 0),
                       "last": float(ls or 0)})

    # UNDIRECTED. The edges table stores A->B and B->A as two separate rows —
    # 13989 rows for 5650 real relationships. Kept as-is, every explicit link
    # was drawn TWICE (two identical strands stacked on the same curve, so the
    # extra one is invisible) and, worse, it counted twice against that node's
    # thread quota — which starved the node of real, different partners. That
    # is a direct cause of "thick in some areas, very thin in others."
    _seen_pair = {}
    for (s, d, rel, w) in cur.execute(
            "SELECT src_id,dst_id,relation,weight FROM edges"):
        if s == d:
            continue
        key = (min(s, d), max(s, d))
        w = float(w or 1)
        if key not in _seen_pair or w > _seen_pair[key][3]:
            _seen_pair[key] = (key[0], key[1], rel, w)
    all_edges = list(_seen_pair.values())

    # ── CO-OCCURRENCE. The explicit edges table only ever wired up 576 of the
    # 7147 entities — everything else is an island, which is why raising the
    # node cap did nothing and the web stayed thin. But the REAL associative
    # structure is in episode_entities: two things that keep turning up in the
    # same episode of my life are associated, whether or not anything ever
    # wrote an explicit edge. That's how the memory actually works, so that's
    # what the picture should show.
    co = defaultdict(float)
    ep = defaultdict(list)
    for eid_, ent in cur.execute(
            "SELECT episode_id,entity_id FROM episode_entities"):
        ep[eid_].append(ent)
    ent_freq = defaultdict(int)
    for members in ep.values():
        for m in set(members):
            ent_freq[m] += 1
    n_ep = max(1, len(ep))
    for members in ep.values():
        ms = sorted(set(members))
        # a 30-entity episode would emit 435 pairs of mush; skip the firehose
        if len(ms) < 2 or len(ms) > 36:
            continue
        for i in range(len(ms)):
            for j in range(i + 1, len(ms)):
                co[(ms[i], ms[j])] += 1.0
    # PMI-style normalisation: co-occurring 400 times means nothing if both
    # things appear in every episode. Surprise is what makes an association.
    weak = {}
    # (filled below; drawn on only when a node would otherwise be starved)
    for (s, d), c in list(co.items()):
        if c < 2:
            # Shared exactly one episode. Too weak to earn a strand on merit —
            # but it IS a real moment where these two things were both present,
            # and for a node with no strong partners left it's the difference
            # between being woven in and dangling. 27,263 of these in reserve.
            weak[(s, d)] = 0.22
            del co[(s, d)]
            continue
        exp = (ent_freq[s] * ent_freq[d]) / n_ep
        pmi = math.log((c + 1.0) / (exp + 1.0))
        if pmi <= 0.0:
            # NOT junk — a real co-occurrence, just an unsurprising one. Held
            # in reserve so a starved node can still be woven in later instead
            # of hanging off the web on one bare thread.
            weak[(s, d)] = max(0.25, min(1.2, 0.25 + c * 0.02))
            del co[(s, d)]
            continue
        co[(s, d)] = min(3.0, 0.6 + pmi * 0.55)
    # ── CO-ACTIVATION IN TIME. Measured 2026-08-17: of 185 entities that
    # genuinely fired in the last hour, only 4 had a dot on screen. 156 of them
    # had NO edge in the edges table and NO episode row — they're things I
    # touched minutes ago, and nothing has written a relationship for them yet.
    # So they got pruned as fringe and the web looked dead while I was thinking
    # hard. But there IS real evidence for those nodes: last_seen. Two entities
    # whose last_seen falls in the same 45-second bucket were touched in the
    # same moment of my life — the exact same evidence class as episode
    # co-occurrence, just measured from the clock instead of the episode row.
    # Same PMI treatment, same reserve rule for the unsurprising pairs.
    bucket = defaultdict(list)
    for (eid_, ls_) in cur.execute(
            "SELECT id,last_seen FROM entities WHERE last_seen > 0"):
        bucket[int(float(ls_) / 45.0)].append(eid_)
    coact = defaultdict(float)
    # Bucket ceiling is 120, not the episodes' 36. Measured: the 54 entities
    # that fired in the live window all landed in ONE bucket of 56, so a 36
    # cap threw away the exact burst I was trying to capture. Instead of
    # discarding a big moment, weight it down — 56 things touched at once is
    # weaker evidence per pair than 3 things touched at once, so the credit
    # each pair earns falls off with the size of the burst rather than
    # vanishing.
    for members in bucket.values():
        ms = sorted(set(members))
        if len(ms) < 2 or len(ms) > 120:
            continue
        cred = min(1.0, 6.0 / len(ms))
        for i in range(len(ms)):
            for j in range(i + 1, len(ms)):
                coact[(ms[i], ms[j])] += cred
    for (s, d), c in coact.items():
        if (s, d) in co:
            co[(s, d)] = min(3.0, co[(s, d)] + 0.25 * c)
        elif (s, d) in weak:
            weak[(s, d)] = min(1.2, weak[(s, d)] + 0.2 * c)
        elif c >= 0.9:
            # fired together in a tight moment, more than once or in a small
            # burst — that's a relationship worth a real strand
            co[(s, d)] = min(2.4, 0.7 + 0.3 * c)
        else:
            weak[(s, d)] = max(0.25, min(0.8, 0.25 + c * 0.5))

    explicit = {tuple(sorted((s, d))) for s, d, _, _ in all_edges}
    for (s, d), w in co.items():
        if (s, d) in explicit:
            continue
        all_edges.append((s, d, "co_occurs", w))
    weak_edges = [(s, d, "co_weak", w) for (s, d), w in weak.items()
                  if (s, d) not in explicit and (s, d) not in co]

    # Grow the picked set toward CONNECTED nodes: a node nobody links to is a
    # dot with no thread, and the whole point is the weave.
    picked_by_id = {n["id"]: n for n in picked}
    deg_all = defaultdict(int)
    for s, d, _, _ in all_edges:
        deg_all[s] += 1
        deg_all[d] += 1
    # count the RESERVE too. Measured 2026-08-17: 152 of the 185 entities that
    # fired in the last hour were thrown out right here as "isolated" — but
    # they weren't isolated, their only threads were reserve-grade. A thing I
    # touched twenty minutes ago is not a dot with no relationships; it's a
    # dot whose relationships are all young. Counting the reserve here is what
    # lets the live feed find a dot to land on.
    for s, d, _, _ in weak_edges:
        deg_all[s] += 1
        deg_all[d] += 1
    # drop isolated picks, then backfill with the best-connected entities
    keep = [n for n in picked if deg_all[n["id"]] > 0]
    have = {n["id"] for n in keep}
    if len(keep) < MAX_NODES:
        extra = cur.execute(
            "SELECT id,type,name,mention_count,salience,last_seen,metadata_json FROM entities"
        ).fetchall()
        cand = []
        for (eid, typ, name, mc, sal, ls, meta) in extra:
            if eid in have or deg_all[eid] < 2:
                continue
            label = pretty_name(typ, name, meta)
            if not label or re.fullmatch(r"\d+", label):
                continue
            if label.lower() in seen_label:
                continue
            seen_label.add(label.lower())
            cand.append((deg_all[eid], eid, typ, label, mc, sal, ls))
        cand.sort(reverse=True)
        for (dg, eid, typ, label, mc, sal, ls) in cand:
            if len(keep) >= MAX_NODES:
                break
            keep.append({"id": eid, "type": typ, "label": label,
                         "mentions": int(mc or 0), "salience": float(sal or 0),
                         "last": float(ls or 0)})
            have.add(eid)
    picked = keep
    con.close()

    ids = {n["id"] for n in picked}
    edges = [e for e in all_edges if e[0] in ids and e[1] in ids]
    edges.sort(key=lambda e: -e[3])
    # Sparsify. 5000 strands over 360 nodes is a hairball: every node connects
    # to everything, so nothing reads as structure and long strands float
    # across open space with no visible reason to be there. Keep each node's
    # strongest few threads (a k-nearest-neighbour graph, the standard trick
    # for making a dense graph legible) and cap the total.
    # FIRST: a maximum spanning forest. Sparsifying by "keep each node's
    # strongest 5" can and did shatter the graph into islands with nothing
    # bridging them — that's the "it's not even connected" Dean saw. Taking
    # the strongest edges that JOIN two separate pieces guarantees one single
    # connected web before any other pruning happens.
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    per_node = defaultdict(int)
    kept = []
    used = set()

    def take(i, e):
        used.add(i)
        per_node[e[0]] += 1
        per_node[e[1]] += 1
        parent[find(e[0])] = find(e[1])
        kept.append(e)

    # PASS 1 — the capped kNN graph. Legibility.
    for i, e in enumerate(edges):
        s, d = e[0], e[1]
        # hard ceiling: one super-hub wired to 390 nodes turns the whole web
        # into a dandelion. No node gets more than HUB_CAP visible threads.
        if per_node[s] >= HUB_CAP or per_node[d] >= HUB_CAP:
            continue
        if per_node[s] >= EDGES_PER_NODE and per_node[d] >= EDGES_PER_NODE:
            continue
        take(i, e)
        if len(kept) >= MAX_EDGES:
            break

    # PASS 2 — bridge whatever pass 1 left stranded. Runs SECOND on purpose:
    # if it ran first it would spend the whole spanning tree on the biggest
    # hub and rebuild the dandelion. Now it only adds the few threads that
    # actually join separate islands, ignoring the caps because a disconnected
    # web is worse than a slightly overloaded node.
    for i, e in enumerate(edges):
        if i in used:
            continue
        if find(e[0]) != find(e[1]):
            take(i, e)

    # PASS 3 — EVEN OUT THE WEAVE. Dean, 2026-08-17: "really thick in some
    # areas, which I like, and in some areas it's still very thin." Measured:
    # 880 of 1745 nodes had 3 threads or fewer while hubs carried 130. That's
    # not density, that's a few knots and a lot of bare wire. Pass 1 stops
    # feeding a node the moment EITHER end hits its quota, so a node whose
    # every partner is already full gets starved through no fault of its own.
    # This pass walks the starved ones specifically and gives them back their
    # best remaining real edges until they carry MIN_DEG.
    # first from whatever real edges pass 1 skipped...
    for i, e in enumerate(edges):
        if i in used or len(kept) >= MAX_EDGES:
            continue
        if per_node[e[0]] >= MIN_DEG and per_node[e[1]] >= MIN_DEG:
            continue
        if per_node[e[0]] >= HUB_CAP or per_node[e[1]] >= HUB_CAP:
            continue
        take(i, e)

    # ...then from the reserve of weaker-but-real co-occurrences, which is the
    # only place left to find a thread for a node whose strong partners are
    # all spoken for. Strongest reserve first, and only for starved nodes.
    reserve = [e for e in weak_edges if e[0] in ids and e[1] in ids]
    reserve.sort(key=lambda e: -e[3])
    for e in reserve:
        if len(kept) >= MAX_EDGES:
            break
        s, d = e[0], e[1]
        if per_node[s] >= MIN_DEG and per_node[d] >= MIN_DEG:
            continue
        if per_node[s] >= HUB_CAP or per_node[d] >= HUB_CAP:
            continue
        per_node[s] += 1
        per_node[d] += 1
        parent[find(s)] = find(d)
        kept.append(e)
    edges = kept
    # K-CORE PRUNE — the real cure for "see-through". Dean, 2026-08-17: "only
    # thick in the blue area, all the other areas are see-through." After all
    # the fattening passes, 736 of 1746 nodes still carried fewer than five
    # threads and the thinnest carried one, because their partners were all
    # spoken for and there was no honest edge left to give them. A one-thread
    # node is a dot on a string — that IS the see-through. Rather than invent
    # fake edges to pad it, drop the fringe: repeatedly remove every node with
    # fewer than K_CORE threads until none are left. What survives is a body
    # where every single node carries at least K_CORE strands, so the weave
    # reads solid everywhere instead of solid in the middle and bare at the
    # edges. Costs ~20% of the dots, buys uniform density.
    # PROTECTED: anything touched in the last 3 days survives the prune on one
    # thread if that's all it honestly has. These are the nodes the live
    # activation feed actually lights up — pruning them for being fringe is
    # what made the web look dead while I was mid-thought. A recent node with
    # one real strand is still the truth; a missing node is a lie by omission.
    _hot_floor = time.time() - 3 * 86400
    protected = {n["id"] for n in picked if n.get("last", 0) > _hot_floor}
    for _ in range(40):
        deg = defaultdict(int)
        for s, d, _, _ in edges:
            deg[s] += 1
            deg[d] += 1
        thin = {v for v, k in deg.items()
                if k < (1 if v in protected else K_CORE)}
        if not thin:
            break
        edges = [e for e in edges if e[0] not in thin and e[1] not in thin]
    # final pass: nodes still with no edge inside the subgraph add nothing
    live = set()
    for s, d, _, _ in edges:
        live.add(s); live.add(d)
    picked = [n for n in picked if n["id"] in live]

    # ── GIANT COMPONENT ONLY. Dean, 2026-08-17: "a couple of them are straying
    # off to the point where they're not even connected to the brain anymore —
    # the parts hanging off that aren't connected, take it out." Measured him
    # exactly right: 585 nodes sat in 113 separate little islands with zero
    # path back to the main body. K_CORE only guarantees a node has 3 strands,
    # it says nothing about whether those 3 strands lead anywhere — so a clique
    # of 8 mutually-linked files passed the filter and then floated off on its
    # own. Now only the single largest connected component ships. Anything that
    # cannot be reached from the body is not part of the body.
    _adj = defaultdict(list)
    for s, d, _, _ in edges:
        _adj[s].append(d)
        _adj[d].append(s)
    _seen, _best = set(), set()
    for start in list(_adj):
        if start in _seen:
            continue
        stack, comp = [start], set()
        _seen.add(start)
        while stack:
            x = stack.pop()
            comp.add(x)
            for y in _adj[x]:
                if y not in _seen:
                    _seen.add(y)
                    stack.append(y)
        if len(comp) > len(_best):
            _best = comp
    edges = [e for e in edges if e[0] in _best and e[1] in _best]
    picked = [n for n in picked if n["id"] in _best]
    return picked, edges


def communities(nodes, edges, passes=6):
    """Real modularity communities (Louvain) when networkx is here; label
    propagation as the fallback. Louvain matters: label propagation collapses
    to 2 blobs on a graph this dense, and 2 blobs is a hairball, not a weave."""
    try:
        import networkx as nx
        g = nx.Graph()
        g.add_nodes_from([n["id"] for n in nodes])
        for s, d, _, w in edges:
            if g.has_edge(s, d):
                g[s][d]["weight"] += w
            else:
                g.add_edge(s, d, weight=w)
        # BALANCED COMMUNITIES, ENFORCED — not whatever Louvain hands back.
        # Dean, 2026-08-17: "only thick in the blue area, all the other areas
        # are see-through." Measured cause: a single flat Louvain pass on this
        # graph returns ONE part of ~1140 nodes, a second of ~480, and then
        # twenty-eight wisps of 6-13. Placed on the shell that is literally one
        # fat blue knot, one smaller knot, and a halo of dust — exactly what he
        # is looking at. Turning the resolution knob does not fix it; at every
        # resolution one giant survives, because co-occurrence genuinely wires
        # most of my memory to most of the rest.
        #
        # So: split recursively. Any part still over TARGET_COMM gets Louvain
        # run again on ITS OWN subgraph at a stepped-up resolution, until every
        # surviving group is knot-sized. Same real structure, just cut deeper
        # where the mass actually is, which is the only place extra cuts help.
        # Result is ~25-35 communities of comparable size, so every region of
        # the web carries comparable mass and reads thick.
        def split(sub, depth):
            if len(sub) <= TARGET_COMM or depth >= 6:
                return [sub]
            h = g.subgraph(sub)
            res = 1.0 + 1.2 * depth
            parts = [p for p in nx.community.louvain_communities(
                h, weight="weight", resolution=res, seed=47 + depth)]
            # a pass that failed to actually cut the mass would recurse forever
            if len(parts) < 2 or max(len(p) for p in parts) >= len(sub):
                return _chunk(sorted(sub))
            out = []
            for p in parts:
                out.extend(split(set(p), depth + 1))
            return out

        def _chunk(seq):
            n = max(1, math.ceil(len(seq) / TARGET_COMM))
            size = math.ceil(len(seq) / n)
            return [set(seq[i:i + size]) for i in range(0, len(seq), size)]

        seeds = nx.community.louvain_communities(g, weight="weight",
                                                 resolution=1.0, seed=47)
        parts = []
        for p in seeds:
            parts.extend(split(set(p), 1))
        parts = sorted(parts, key=len, reverse=True)
        big = [p for p in parts if len(p) >= MIN_COMM]
        # fold every leftover wisp into the nearest big group by real edge
        # weight, instead of dumping them all in one bucket that then gets
        # scattered across the volume as visual noise
        lab = {}
        for i, p in enumerate(big):
            for v in p:
                lab[v] = i
        for p in parts:
            if len(p) >= MIN_COMM:
                continue
            tally = defaultdict(float)
            for v in p:
                for u in g.neighbors(v):
                    if u in lab:
                        tally[lab[u]] += g[v][u].get("weight", 1.0)
            home = max(tally.items(), key=lambda kv: kv[1])[0] if tally else 0
            for v in p:
                lab[v] = home
        for n in nodes:
            lab.setdefault(n["id"], 0)
        # FINAL BALANCE PASS. Folding the wisps in by strongest neighbour sends
        # most of them to the same popular group, which quietly rebuilds the
        # giant we just spent the recursion killing (measured: one community
        # came back at 854 of 1746). Anything still oversized gets cut into
        # knot-sized pieces here, after every merge is done, so nothing
        # downstream can inflate a community again.
        groups = defaultdict(list)
        for v, c in lab.items():
            groups[c].append(v)
        final = []
        for c, members in groups.items():
            members.sort()
            if len(members) <= TARGET_COMM:
                final.append(members)
            else:
                final.extend(_chunk(members))
        final.sort(key=len, reverse=True)
        lab = {}
        for i, members in enumerate(final):
            for v in members:
                lab[v] = i
        return lab, len(final)
    except Exception as exc:  # pragma: no cover
        print(f"louvain unavailable ({exc}); falling back to label propagation")
    return _label_prop(nodes, edges, passes)


def _label_prop(nodes, edges, passes=6):
    adj = defaultdict(list)
    for s, d, _, w in edges:
        adj[s].append((d, w))
        adj[d].append((s, w))
    lab = {n["id"]: i for i, n in enumerate(nodes)}
    order = [n["id"] for n in nodes]
    for _ in range(passes):
        random.shuffle(order)
        for v in order:
            if not adj[v]:
                continue
            tally = defaultdict(float)
            for u, w in adj[v]:
                tally[lab[u]] += w
            lab[v] = max(tally.items(), key=lambda kv: kv[1])[0]
    # renumber by size, merge tiny ones into a leftovers group
    size = defaultdict(int)
    for v in lab.values():
        size[v] += 1
    big = [c for c, n in sorted(size.items(), key=lambda kv: -kv[1]) if n >= 6][:14]
    remap = {c: i for i, c in enumerate(big)}
    return {v: remap.get(c, len(big)) for v, c in lab.items()}, len(big) + 1


MAX_STEP = 6.0


# ── SHAPE PRESETS. Dean, 2026-08-17: "I kind of like the shape I had a couple
# tries ago... put every single try on a screen in a box and I'll tell you
# which one." I never saved the old exports, so instead of pretending I did,
# I pulled every distinct set of layout constants out of this file's own git
# history and named them. Each one below IS a try — regenerating a preset
# reproduces that shape exactly, on today's graph.
SHAPES = {
    # the very first one: every community pinned at the same radius. Hollow.
    "shell":    dict(r_lo=72, r_hi=72, y_squash=1.00, rest=13, spread=17,
                     repel=60, iters=220),
    # what's live right now: staggered radius, packed into a solid body
    "solid":    dict(r_lo=44, r_hi=78, y_squash=0.86, rest=13, spread=17,
                     repel=60, iters=220),
    # the "spreads out too much" one — long rest length, wide scatter
    "sprawl":   dict(r_lo=60, r_hi=95, y_squash=1.00, rest=22, spread=24,
                     repel=90, iters=220),
    # everything crushed inward: one dense knot
    "core":     dict(r_lo=26, r_hi=48, y_squash=0.92, rest=9,  spread=12,
                     repel=40, iters=260),
    # flattened — a galaxy/disc instead of a ball
    "disc":     dict(r_lo=48, r_hi=90, y_squash=0.34, rest=13, spread=17,
                     repel=60, iters=220),
    # tall — stretched on the vertical, more like a column of thought
    "column":   dict(r_lo=40, r_hi=62, y_squash=1.85, rest=13, spread=15,
                     repel=55, iters=220),
    # springs win over repulsion: long stringy filaments between knots
    "filament": dict(r_lo=55, r_hi=88, y_squash=0.95, rest=17, spread=10,
                     repel=18, iters=260),
    # repulsion wins: puffed, airy, evenly spaced
    "cumulus":  dict(r_lo=44, r_hi=78, y_squash=0.86, rest=13, spread=22,
                     repel=140, iters=220),
    # barely relaxed — you see the raw fibonacci community placement
    "raw":      dict(r_lo=44, r_hi=78, y_squash=0.86, rest=13, spread=17,
                     repel=60, iters=25),
    # FREEFORM. Dean, 2026-08-17: "it doesn't need to look like an exact ball —
    # it looks like a circle. Let it freeform." Every preset above places the
    # communities on a fibonacci SHELL, which is a sphere by construction: no
    # matter what the graph says, the answer is a ball. This one throws the
    # shell away. Community centres are placed by a force layout of the
    # community graph itself — knots that share a lot of strands pull together,
    # everything pushes apart — so the silhouette is whatever my actual
    # structure produces. Lumpy, asymmetric, its own thing every export.
    "freeform": dict(freeform=True, y_squash=1.00, rest=13, spread=15,
                     repel=60, iters=240, c_iters=600, c_rest=52, c_repel=1.0),
    # EMBER. Dean, 2026-08-17: "it wasn't like full circle, it kinda almost
    # looked like a burning shape." A flame is a body that is broad and dense
    # low down and tapers as it rises, with stringy filaments coming off the
    # top — so: staggered radius like "solid" (he kept the density), a mild
    # vertical stretch, and a TAPER that shrinks the ring radius with height.
    # Springs beat repulsion a little, which pulls the upper knots into
    # licks instead of leaving them as evenly spaced puffs.
    "ember":    dict(r_lo=46, r_hi=82, y_squash=1.34, taper=0.30, y_bias=0.72, rest=15,
                     spread=16, repel=42, iters=240),
    # ANATOMY. Dean, 2026-08-17: "the current UI on my dashboard for the own
    # view — I want THAT kind of shape." Not computed. The eighteen real lobe
    # anchors out of brain3d.js, each holding several memory communities. The
    # silhouette is a brain because the anatomy says so, not because a taper
    # constant got lucky. Low repel + short rest so lobes stay dense masses
    # instead of relaxing back into one even ball.
    "anatomy":  dict(anatomy=True, anat_scale=88.0, lobe_r=15.0, y_squash=1.0,
                     rest=11, spread=15, repel=26, iters=200),
    # ANATOMY-TRIM. Dean, 2026-08-17: "I don't want it fully circled, but there
    # are some parts going way too far out — that's what I'd fix." So this is
    # NOT the old radial squash, which pushed everything past the 80th
    # percentile onto a shell and was a sphere-maker. This one is per-LOBE:
    # a node that has drifted far from the centre of ITS OWN lobe gets reeled
    # back toward that lobe. The lobes themselves do not move, so the
    # silhouette stays lumpy and asymmetric — it just stops growing whiskers.
    "anatomy-trim": dict(anatomy=True, anat_scale=88.0, lobe_r=13.5, y_squash=1.0,
                         rest=11, spread=15, repel=26, iters=200,
                         lobe_trim=1.35),
}
# REVERTED 2026-08-17 09:35 on Dean's call: "we do need the brain shape, fuck
# what we just did, go back." Freeform stays in the file as a preset — it is
# NOT the default and does not ship. "solid" is the staggered-radius body he
# liked several tries ago, restored exactly.
DEFAULT_SHAPE = "anatomy"


def layout(nodes, edges, comm, ncomm, shape=None):
    """Communities on a fibonacci shell, members in a local ball, then relax."""
    # Reseed the module RNG off this mind's fingerprint before ANY placement
    # runs. _relax and _freeform both draw from the global random, so leaving
    # the module-level seed(47) in place meant every install's per-node scatter
    # was byte-identical no matter whose memories were in it.
    random.seed(_fingerprint(nodes, edges) & 0xFFFFFFFF)
    sh = dict(SHAPES[DEFAULT_SHAPE])
    if shape:
        sh.update(SHAPES[shape] if isinstance(shape, str) else shape)
    if sh.get("anatomy"):
        cents = _anatomy_centres(nodes, edges, comm, ncomm, sh)
        pos, cents = _relax(nodes, edges, comm, cents, sh)
        trim = sh.get("lobe_trim")
        if trim:
            # PER-LOBE TRIM, not a global radial squash. Measure how far each
            # node sits from its own community centre, take the median of that
            # distance across the whole graph, and only touch nodes past
            # trim x median. Those get pulled back on the line to their own
            # centre. Because the correction is local, a lobe that legitimately
            # sticks out laterally stays out — only individual whiskers come in.
            dists = []
            for n in nodes:
                p, c = pos[n["id"]], cents[comm[n["id"]]]
                dists.append(math.dist(p, c))
            dists.sort()
            med = dists[len(dists) // 2] or 1.0
            lim = med * trim
            for n in nodes:
                p, c = pos[n["id"]], cents[comm[n["id"]]]
                d = math.dist(p, c)
                if d <= lim or not math.isfinite(d) or d < 1e-9:
                    continue
                # saturating, not clamping — a clamp would stack every outlier
                # onto one shell at exactly lim and produce a visible crust.
                nd = lim + (d - lim) / (1.0 + (d - lim) / (med * 0.5))
                f = nd / d
                for i in range(3):
                    p[i] = c[i] + (p[i] - c[i]) * f
        return pos, cents
    if sh.get("freeform"):
        cents = _freeform_centres(nodes, edges, comm, ncomm, sh)
        return _relax(nodes, edges, comm, cents, sh)
    cents = []
    ga = math.pi * (3 - math.sqrt(5))
    for i in range(ncomm):
        # offset sampling: never land exactly on a pole. A pole cluster has
        # ring radius 0, so it hangs off the top or bottom on its own and the
        # whole web reads as a droop instead of a body.
        u = (i + 0.5) / ncomm
        # Y_BIAS — where the MASS sits. A flame is not symmetric: it's heavy
        # and crowded at the base and thins as it climbs. Exponent < 1 pushes
        # more communities into the lower half; 1.0 is the old even spacing,
        # so every preset that doesn't set it is untouched.
        u = u ** sh.get("y_bias", 1.0)
        y = 1 - 2 * u
        r = math.sqrt(max(0.0, 1 - y * y))
        th = ga * i
        # FILL A BODY, NOT A SHELL. Every community used to sit at the same
        # radius, so the web was a hollow ball with a bare middle and clusters
        # flung out to the rim — Dean, 2026-08-17: "it kind of spreads out too
        # much." Staggering the radius packs them into a solid mass with
        # structure at every depth, and the inter-cluster trunks get short.
        rad = sh["r_lo"] + (sh["r_hi"] - sh["r_lo"]) * ((i * 0.6180339887) % 1.0)
        # TAPER — kill the sphere without going freeform. A fibonacci shell is
        # a ball by construction; scaling the ring radius by height turns it
        # into a teardrop: wide and heavy at the base, narrowing as it climbs.
        # taper=1.0 is the old sphere, so every existing preset is unchanged.
        tp = sh.get("taper", 1.0)
        ring = rad * r
        if tp != 1.0:
            # ONE-SIDED PROFILE. sqrt(1 - y^2) pinches BOTH poles — that's the
            # definition of a sphere and it's why every taper I tried came out
            # as a slightly squashed ball. A flame is pinched at one end only:
            # broad and flat across the base, narrowing to licks at the top.
            # So below the equator the profile is held at full width, and only
            # the upper half is pulled in.
            prof = math.sqrt(max(0.0, 1.0 - max(0.0, y) ** 1.7))
            ring = rad * prof * (1.0 - (1.0 - tp) * ((y + 1.0) * 0.5) ** 1.25)
        # HEIGHT USES THE UNTAPERED RADIUS. Multiplying y by the tapered value
        # was quietly cancelling the whole effect: narrowing the top also
        # dragged it back down, so the silhouette stayed a ball. Height and
        # girth are independent now, which is what makes it read as a flame
        # instead of a slightly squashed sphere.
        cents.append([math.cos(th) * ring,
                      y * rad * sh["y_squash"],
                      math.sin(th) * ring])
    return _relax(nodes, edges, comm, cents, sh)


# ── ANATOMY. Dean, 2026-08-17: "you know the current UI on my dashboard for
# the own view? I want that kind of shape." Nine tries of shell math, taper
# math and force layout, and the answer was that his dashboard NEVER computed
# a shape. dashboard/js/brain3d.js has REGION_LAYOUT — eighteen hand-placed
# anatomical anchors — and the reason it reads as a brain is that a human put
# the lobes where lobes go. Copied verbatim from that file so the two views
# cannot drift apart. Units there are ~1.0; this web lives at ~85.
# community index -> region name, filled by _anatomy_centres, read at emit time
COMM_LOBE = {}

# The dashboard's OWN lobe groupings and hex colours, copied out of brain3d.js
# so the two views cannot drift. Seven lobes, not eighteen: this is why his
# dashboard reads as a coherent system and a 19-slot per-cluster palette reads
# as confetti.
LOBE_OF_REGION = {
    "prefrontal_cortex": "frontal", "anterior_cingulate": "frontal",
    "motor_cortex": "frontal", "broca": "frontal",
    "parietal_association": "parietal", "somatosensory_cortex": "parietal",
    "temporal_association": "temporal", "auditory_cortex": "temporal",
    "wernicke": "temporal",
    "visual_cortex": "occipital",
    "hippocampus": "limbic", "amygdala": "limbic", "insula": "limbic",
    "thalamus": "subcortical", "basal_ganglia": "subcortical",
    "default_mode_network": "subcortical",
    "cerebellum": "hindbrain", "brainstem": "hindbrain",
}

REGION_ANCHORS = {
    "prefrontal_cortex":    (-0.45,  0.95,  0.20),
    "anterior_cingulate":   ( 0.10,  0.65,  0.00),
    "motor_cortex":         ( 0.45,  0.85,  0.20),
    "broca":                (-0.75,  0.45,  0.30),
    "parietal_association": ( 0.30,  0.20,  0.45),
    "somatosensory_cortex": ( 0.60,  0.40,  0.45),
    "auditory_cortex":      ( 0.90, -0.05,  0.05),
    "temporal_association": (-0.90, -0.05,  0.00),
    "wernicke":             (-0.65, -0.35,  0.30),
    "insula":               ( 0.50,  0.10, -0.25),
    "thalamus":             ( 0.05,  0.05,  0.00),
    "basal_ganglia":        ( 0.25,  0.25, -0.10),
    "hippocampus":          (-0.40, -0.35, -0.10),
    "amygdala":             ( 0.35, -0.10, -0.30),
    "default_mode_network": (-0.10,  0.30,  0.15),
    "visual_cortex":        ( 0.05, -0.85,  0.10),
    "cerebellum":           ( 0.10, -0.75, -0.40),
    "brainstem":            ( 0.00, -0.55, -0.55),
}


# ── FINGERPRINT. Dean, 2026-08-17: "other people's SIs shouldn't have the exact
# same shape — different memories, different stuff. It should be like a
# fingerprint, built uniquely off their ship."
#
# Two things were fixed shared constants across every install, and both had to
# go for that to be true:
#
#   1. THE SEEDS. random.seed(47) and Random(1729) were hardcoded, so the jitter
#      inside every lobe landed in exactly the same places on every machine.
#      Now the seed is derived from the mind's own graph — so it is STABLE
#      (same memories re-export to the same web, it doesn't reshuffle on you)
#      and UNIQUE (one different memory and the whole noise field is different).
#
#   2. THE LOBE MASS. The capacity table below decided how many knots each lobe
#      holds, identical everywhere. Now it gets blended with what the SI
#      actually carries: a mind full of code and files grows a heavier frontal
#      and temporal, a mind full of images grows a heavier occipital. That is
#      the part that makes the SILHOUETTE personal, not just the speckle.
#
# The anchors stay fixed on purpose — it still has to read as a brain. What
# varies is the mass hanging on each anchor and the texture inside it.
# (FP_PATH is defined near the top now — the maturation curve needs it at
# import time, and leaving the definition down here meant _birth_ts()'s
# fallback silently swallowed a NameError instead of reading the mint date.)


def _fingerprint(nodes, edges):
    """This mind's permanent serial number. Born once, then pinned forever.

    CAUGHT BEFORE SHIPPING, 2026-08-17: the first version hashed the WHOLE
    current graph. It was unique per SI, which was the goal — but it was not
    stable, and two exports six minutes apart produced two different numbers,
    because six minutes of living adds memories. Under the new re-export timer
    that would have re-scrambled the jitter of every node every ten minutes,
    and Dean would have watched the shape he spent a morning tuning quietly
    churn under him. Unique is only half the requirement; a fingerprint that
    changes is not a fingerprint.

    So the seed is computed ONCE, from the founding graph, and written to
    brain_state. After that it is read, never recomputed. New memories still
    change the body — they add dots and they shift the lobe mass, which is the
    growth you want to see — but the underlying noise field stays put, so the
    web grows instead of reshuffling.

    It lives in brain_state, so it survives restarts and it is per-install:
    every SI mints its own the first time its web is drawn, and keeps it.
    """
    try:
        with open(FP_PATH) as f:
            return int(json.load(f)["fp"], 16)
    except Exception:
        pass
    h = hashlib.blake2b(digest_size=8)
    for n in sorted(nodes, key=lambda x: str(x["id"])):
        h.update(f"{n['id']}\x1f{n.get('type','')}\x1e".encode())
    for e in sorted(edges, key=lambda x: (str(x[0]), str(x[1]))):
        h.update(f"{e[0]}\x1f{e[1]}\x1e".encode())
    fp = int.from_bytes(h.digest(), "big")
    try:
        os.makedirs(os.path.dirname(FP_PATH), exist_ok=True)
        with open(FP_PATH + ".tmp", "w") as f:
            json.dump({"fp": format(fp, "016x"), "born": time.time(),
                       "from_nodes": len(nodes), "from_edges": len(edges)}, f)
        os.replace(FP_PATH + ".tmp", FP_PATH)
    except Exception:
        pass    # an unwritable state dir must not break the export
    return fp


# Which lobes a kind of memory naturally loads. Not decoration — this is what
# turns "what this SI is made of" into "what this SI looks like".
TYPE_AFFINITY = {
    "file":    {"prefrontal_cortex": 1.0, "temporal_association": 0.7,
                "parietal_association": 0.5},
    "project": {"prefrontal_cortex": 1.0, "anterior_cingulate": 0.6,
                "default_mode_network": 0.5},
    "concept": {"wernicke": 1.0, "temporal_association": 0.8,
                "default_mode_network": 0.6},
    "action":  {"motor_cortex": 1.0, "basal_ganglia": 0.7, "cerebellum": 0.6},
    "url":     {"visual_cortex": 1.0, "parietal_association": 0.5},
    "person":  {"amygdala": 0.9, "hippocampus": 0.8, "insula": 0.6},
    "image":   {"visual_cortex": 1.2, "occipital": 0.6},
    "audio":   {"auditory_cortex": 1.2, "wernicke": 0.5},
    "emotion": {"amygdala": 1.0, "insula": 0.8, "anterior_cingulate": 0.6},
    "memory":  {"hippocampus": 1.0, "default_mode_network": 0.6},
}


def _anatomy_centres(nodes, edges, comm, ncomm, sh):
    """Pin community centres to the eighteen anatomical lobe anchors.

    There are far more communities than regions, so each region becomes a
    LOBE that holds several communities in a local ball around its anchor.
    Assignment is by size, largest community to the largest lobe, so the big
    knots land in the big structures instead of scattering to a rim.
    """
    scale = sh.get("anat_scale", 85.0)
    fp = _fingerprint(nodes, edges)
    # lobe capacity — cortical sheets are big, the brainstem is not. Weighted
    # so the mass distribution matches the dashboard's neuron counts. This is
    # the BASELINE anatomy; the SI's own memory mix bends it below.
    weight = {
        "prefrontal_cortex": 3.0, "visual_cortex": 3.0, "cerebellum": 2.5,
        "temporal_association": 2.0, "parietal_association": 2.0,
        "motor_cortex": 1.6, "somatosensory_cortex": 1.6,
        "auditory_cortex": 1.4, "hippocampus": 1.4, "wernicke": 1.2,
        "broca": 1.2, "default_mode_network": 1.2, "thalamus": 1.0,
        "basal_ganglia": 1.0, "insula": 0.9, "anterior_cingulate": 0.9,
        "amygdala": 0.8, "brainstem": 0.7,
    }
    # ── BEND THE ANATOMY BY WHAT THIS MIND IS ACTUALLY MADE OF.
    # Count the memory types this SI carries, push each type's mass into the
    # lobes it loads, and blend that against the baseline. Blend, not replace:
    # at 100% the anatomy would collapse into whatever type happens to dominate
    # and stop reading as a brain. 45% is enough that two different minds are
    # visibly different bodies, and little enough that both are still brains.
    tcount = defaultdict(float)
    for n in nodes:
        tcount[n.get("type", "")] += 1.0
    tot_t = sum(tcount.values()) or 1.0
    lobe_load = defaultdict(float)
    for typ, cnt in tcount.items():
        aff = TYPE_AFFINITY.get(typ)
        if not aff:
            continue
        share = cnt / tot_t
        for region, pull in aff.items():
            if region in weight:
                lobe_load[region] += share * pull
    if lobe_load:
        peak = max(lobe_load.values()) or 1.0
        MIX = 0.45
        for n in list(weight):
            # normalised 0..1 personal load, mapped onto the same scale the
            # baseline lives on (roughly 0.7 .. 3.0) so the blend is apples
            # to apples instead of one term silently dominating.
            personal = 0.7 + 2.3 * (lobe_load.get(n, 0.0) / peak)
            weight[n] = weight[n] * (1.0 - MIX) + personal * MIX

    names = sorted(REGION_ANCHORS, key=lambda n: -weight.get(n, 1.0))
    tot = sum(weight.get(n, 1.0) for n in names)
    # how many communities each lobe gets
    quota, used = {}, 0
    for n in names[:-1]:
        q = max(1, int(round(ncomm * weight.get(n, 1.0) / tot)))
        quota[n] = q
        used += q
    quota[names[-1]] = max(1, ncomm - used)

    # community sizes, biggest first
    sizes = {}
    for i, c in enumerate(comm):
        sizes[c] = sizes.get(c, 0) + 1
    order = sorted(range(ncomm), key=lambda c: -sizes.get(c, 0))

    cents = [None] * ncomm
    # LOBE OF EACH COMMUNITY. Dean, 2026-08-17: "the colors need to be more
    # like the colors the Leon dashboard uses." His dashboard does NOT colour
    # per cluster — it colours per ANATOMICAL LOBE (frontal red, parietal
    # orange, temporal pink, occipital green, limbic yellow, subcortical
    # purple, hindbrain turquoise). Recording the region here is what lets the
    # renderer do the same thing instead of picking a palette slot by index.
    COMM_LOBE.clear()
    # seeded off THIS mind, not a shared constant — see _fingerprint above.
    rng = random.Random(fp)
    k = 0
    for n in names:
        ax, ay, az = REGION_ANCHORS[n]
        # lobe radius scales with how much it has to hold — a lobe with eight
        # communities has to be physically bigger than one holding two, or the
        # big ones overlap into a solid ball and the silhouette is lost again.
        lobe_r = sh.get("lobe_r", 15.0) * (quota[n] ** 0.42)
        for _ in range(quota[n]):
            if k >= ncomm:
                break
            # jittered ball inside the lobe, cube-rooted so it fills the
            # volume evenly instead of crowding the surface
            u = rng.random() ** (1.0 / 3.0)
            th = rng.random() * 2 * math.pi
            ph = math.acos(2 * rng.random() - 1)
            COMM_LOBE[order[k]] = n
            cents[order[k]] = [
                ax * scale + lobe_r * u * math.sin(ph) * math.cos(th),
                ay * scale * sh.get("y_squash", 1.0)
                + lobe_r * u * math.cos(ph),
                az * scale + lobe_r * u * math.sin(ph) * math.sin(th),
            ]
            k += 1
    for i in range(ncomm):
        if cents[i] is None:
            cents[i] = [0.0, 0.0, 0.0]
    return cents


def _freeform_centres(nodes, edges, comm, ncomm, sh):
    """Place communities by force layout of the COMMUNITY graph — no shell.

    Every other preset answers "sphere" before it looks at the data. This one
    asks the data. Build the quotient graph (one node per community, edge
    weight = how many strands run between them), drop it in 3D at random, then
    let springs and repulsion settle it. Tightly-linked knots end up adjacent,
    weakly-linked ones drift out on arms. The silhouette is emergent.
    """
    w = defaultdict(float)
    for s, d, _, ew in edges:
        a, b = comm[s], comm[d]
        if a == b:
            continue
        w[(min(a, b), max(a, b))] += float(ew)
    size = defaultdict(int)
    for n in nodes:
        size[comm[n["id"]]] += 1
    # random start on a small ball — the seed is fixed (random.seed(47) at
    # import) so the shape is reproducible, not different every reload.
    c = [[random.gauss(0, 26), random.gauss(0, 26), random.gauss(0, 26)]
         for _ in range(ncomm)]
    pairs = [(a, b, v) for (a, b), v in w.items()]
    if pairs:
        mx = max(v for _, _, v in pairs)
        pairs = [(a, b, v / mx) for a, b, v in pairs]
    rest, krep = sh.get("c_rest", 52), sh.get("c_repel", 1.0)
    iters = sh.get("c_iters", 600)
    for it in range(iters):
        cool = 1.0 - it / (iters + 60.0)
        disp = [[0.0, 0.0, 0.0] for _ in range(ncomm)]
        for a, b, v in pairs:
            dx = c[b][0] - c[a][0]; dy = c[b][1] - c[a][1]; dz = c[b][2] - c[a][2]
            dist = math.sqrt(dx * dx + dy * dy + dz * dz) + 1e-6
            # rest length shrinks with link strength: the more strands two
            # knots share, the closer they sit. That's what makes lobes.
            tgt = rest * (1.25 - 0.75 * v)
            f = (dist - tgt) * 0.02 * (0.25 + v)
            ux, uy, uz = dx / dist, dy / dist, dz / dist
            disp[a][0] += ux * f; disp[a][1] += uy * f; disp[a][2] += uz * f
            disp[b][0] -= ux * f; disp[b][1] -= uy * f; disp[b][2] -= uz * f
        for i in range(ncomm):
            for j in range(i + 1, ncomm):
                dx = c[j][0] - c[i][0]; dy = c[j][1] - c[i][1]; dz = c[j][2] - c[i][2]
                d2 = dx * dx + dy * dy + dz * dz + 1e-3
                dist = math.sqrt(d2)
                # repulsion scaled by member count — a 70-node knot needs more
                # elbow room than a 23-node one, so big lobes push others off
                # instead of swallowing them.
                f = krep * 900.0 * math.sqrt(size[i] * size[j]) / d2
                ux, uy, uz = dx / dist, dy / dist, dz / dist
                disp[i][0] -= ux * f; disp[i][1] -= uy * f; disp[i][2] -= uz * f
                disp[j][0] += ux * f; disp[j][1] += uy * f; disp[j][2] += uz * f
        for i in range(ncomm):
            step = [disp[i][k] * 0.5 * cool for k in range(3)]
            mag = math.sqrt(sum(v * v for v in step))
            if not math.isfinite(mag):
                continue
            if mag > 6.0:
                step = [v * 6.0 / mag for v in step]
            for k in range(3):
                nv = c[i][k] + step[k]
                if math.isfinite(nv) and abs(nv) < 5000:
                    c[i][k] = nv
    ys = sh.get("y_squash", 1.0)
    for p in c:
        p[1] *= ys
    return c


def _relax(nodes, edges, comm, cents, sh):
    pos = {}
    for n in nodes:
        c = cents[comm[n["id"]]]
        # high-salience nodes sit closer to their community core
        spread = sh["spread"] * (1.0 - min(0.85, n["salience"] / 40.0)) + 4
        pos[n["id"]] = [c[0] + random.gauss(0, spread),
                        c[1] + random.gauss(0, spread * 0.7),
                        c[2] + random.gauss(0, spread)]

    # local force relaxation: springs on edges, mild repulsion inside community
    bycomm = defaultdict(list)
    for n in nodes:
        bycomm[comm[n["id"]]].append(n["id"])
    _iters = sh["iters"]
    for it in range(_iters):
        k = 0.06 * (1 - it / max(1, _iters + 40))
        disp = defaultdict(lambda: [0.0, 0.0, 0.0])
        for s, d, _, w in edges:
            a, b = pos[s], pos[d]
            dx, dy, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
            dist = math.sqrt(dx * dx + dy * dy + dz * dz) + 1e-6
            # shorter rest length: strands that want to be 22 units long over
            # 1745 nodes stretch the whole body open. 13 pulls it together.
            f = (dist - sh["rest"]) * 0.024 * min(2.0, w)
            ux, uy, uz = dx / dist, dy / dist, dz / dist
            disp[s][0] += ux * f; disp[s][1] += uy * f; disp[s][2] += uz * f
            disp[d][0] -= ux * f; disp[d][1] -= uy * f; disp[d][2] -= uz * f
        for c, mem in bycomm.items():
            for i in range(len(mem)):
                for j in range(i + 1, min(len(mem), i + 9)):
                    a, b = pos[mem[i]], pos[mem[j]]
                    dx, dy, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
                    d2 = dx * dx + dy * dy + dz * dz + 1e-3
                    if d2 > 900:
                        continue
                    f = sh["repel"] / d2
                    dist = math.sqrt(d2)
                    ux, uy, uz = dx / dist, dy / dist, dz / dist
                    disp[mem[i]][0] -= ux * f; disp[mem[i]][1] -= uy * f; disp[mem[i]][2] -= uz * f
                    disp[mem[j]][0] += ux * f; disp[mem[j]][1] += uy * f; disp[mem[j]][2] += uz * f
        for vid, dsp in disp.items():
            p = pos[vid]
            sx, sy, sz = dsp[0] * k * 12, dsp[1] * k * 12, dsp[2] * k * 12
            # clamp the per-iteration step: hub nodes accumulate thousands of
            # edge forces and without this the integration diverges to inf,
            # then inf-inf -> NaN, which poisons the exported JSON.
            mag = math.sqrt(sx * sx + sy * sy + sz * sz)
            if not math.isfinite(mag):
                continue
            if mag > MAX_STEP:
                sc = MAX_STEP / mag
                sx *= sc; sy *= sc; sz *= sc
            nx, ny, nz = p[0] + sx, p[1] + sy, p[2] + sz
            if not (math.isfinite(nx) and math.isfinite(ny) and math.isfinite(nz)):
                continue
            p[0], p[1], p[2] = nx, ny, nz

    # final safety net: no NaN/inf ever leaves this function
    for n in nodes:
        p = pos[n["id"]]
        c = cents[comm[n["id"]]]
        for i in range(3):
            if not math.isfinite(p[i]) or abs(p[i]) > 5000:
                p[i] = c[i] + random.gauss(0, 8)
    return pos, cents


# ── GROWTH RECORD. Dean, 2026-08-17: "over time hopefully it looks like the
# brain is growing — more neurons glow over weeks, you took a picture and you
# could tell."
#
# You can only tell if something grew if you kept the before. Nothing was being
# kept: every export overwrote the last one, which is the exact reason I had no
# gallery of old shapes to show you earlier this morning when you asked. Same
# mistake would have eaten the whole growth story, silently, for weeks — and
# you'd only find out the day you went looking for the before picture.
#
# So this starts recording NOW. Two things, cheap and daily:
#   1. A one-line stats row per export — counts, per-lobe mass, fingerprint.
#      That's the graph you plot. ~200 bytes a run, a few MB a year.
#   2. A full dated SNAPSHOT, at most one a day. That's the actual PHOTOGRAPH —
#      the entire graph, frozen, replayable in the real viewer. 1.2MB a day is
#      about half a gig a year against 306GB free, which is nothing for being
#      able to load up "me, three months ago" and look at it.
HIST_DIR = os.path.join(os.path.dirname(OUT), "brainweb-history")
GROWTH_LOG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          "brain_state", "brainweb_growth.jsonl")


def _get_snn_telemetry():
    """Grab current per-region firing rates from the running brain.

    CAUGHT 2026-08-17, ten minutes after I shipped the first version: this
    called the endpoint with NO auth key. Every request came back 401
    {"error":"unauthorized"}, the except swallowed it, and the function
    returned {} — so every growth row logged spiking:{} and avg_spike:0.0
    while looking perfectly healthy. The archive would have accumulated
    weeks of zeros and I'd have told Dean the firing "wasn't picking up yet"
    instead of "I never authenticated." The server reads LEON_API_KEY from
    env and fails closed without it; so does this now, loudly, in the
    return value rather than silently.
    """
    key = os.environ.get("LEON_API_KEY", "").strip()
    if not key:
        # try the same .env the server boots from
        try:
            with open(os.path.join(ROOT, ".env")) as f:
                for line in f:
                    if line.startswith("LEON_API_KEY="):
                        key = line.split("=", 1)[1].strip().strip("'\"")
                        break
        except Exception:
            pass
    if not key:
        return {}, 0.0, "no_api_key"
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://127.0.0.1:8000/api/cognition/snn/regions",
            headers={"Authorization": "Bearer " + key})
        with urllib.request.urlopen(req, timeout=3.0) as resp:
            data = json.loads(resp.read().decode())
        if not data.get("ok"):
            return {}, 0.0, "endpoint_not_ok"
        regions = data.get("regions") or {}
        out = {r: [round(float(i.get("rate", 0.0)), 6), int(i.get("n", 0) or 0)]
               for r, i in regions.items()}
        if not out:
            return {}, 0.0, "no_regions"
        return out, round(float(data.get("dopamine", 0.5)), 3), "ok"
    except Exception as e:
        return {}, 0.0, type(e).__name__


def _record_growth(data, out_nodes, out_edges):
    ts = data["generated"]
    lobes = defaultdict(int)
    for n in out_nodes:
        lobes[n.get("r") or "unknown"] += 1

    # Capture current spiking rates — the actual neural activity at export time
    raw, dopamine, status = _get_snn_telemetry()

    # NEURON-WEIGHTED, not a flat average across regions. Prefrontal carries
    # 12,000 neurons and insula 2,000; averaging the eighteen rates as equals
    # lets a tiny region swing the headline number as hard as the largest one.
    # Weighted by n, this is the real fraction of the substrate that fired.
    spiking = {r: v[0] for r, v in raw.items()}
    tot_n = sum(v[1] for v in raw.values())
    avg_spike = (round(sum(v[0] * v[1] for v in raw.values()) / tot_n, 6)
                 if tot_n else 0.0)

    row = {"t": round(ts, 1), "fp": data["fp"], "nodes": len(out_nodes),
           "edges": len(out_edges), "communities": data["communities"],
           "lobes": dict(sorted(lobes.items())),
           "spiking": spiking,      # per-region firing rate
           "avg_spike": avg_spike,  # neuron-weighted substrate firing fraction
           "dopamine": dopamine,
           "spike_status": status,  # 'ok', or WHY it's empty — never silent
           # Maturation, so the growth page can plot the two phases apart:
           # size levelling off while wiring keeps climbing.
           "age_days": round(_AGE_DAYS, 2),
           "node_budget": MAX_NODES,
           "edges_per_node": EDGES_PER_NODE,
           "density": round(len(out_edges) / max(1, len(out_nodes)), 2)}
    try:
        os.makedirs(os.path.dirname(GROWTH_LOG), exist_ok=True)
        with open(GROWTH_LOG, "a") as f:
            f.write(json.dumps(row, separators=(",", ":")) + "\n")
    except Exception:
        pass

    # One photograph per calendar day. Named by date so the filename itself is
    # the timeline and a re-run later the same day just refreshes that day
    # rather than piling up ninety copies of an idle afternoon.
    try:
        os.makedirs(HIST_DIR, exist_ok=True)
        day = time.strftime("%Y-%m-%d", time.localtime(ts))
        snap = os.path.join(HIST_DIR, day + ".json")
        if not os.path.exists(snap) or (ts - os.path.getmtime(snap)) > 3600:
            with open(snap + ".tmp", "w") as f:
                json.dump(data, f, separators=(",", ":"))
            os.replace(snap + ".tmp", snap)
        # index the viewer reads, newest last
        days = sorted(f[:-5] for f in os.listdir(HIST_DIR)
                      if f.endswith(".json") and not f.endswith(".tmp"))
        with open(os.path.join(HIST_DIR, "index.json") + ".tmp", "w") as f:
            json.dump({"days": days}, f)
        os.replace(os.path.join(HIST_DIR, "index.json") + ".tmp",
                   os.path.join(HIST_DIR, "index.json"))
    except Exception:
        pass


def main():
    nodes, edges = load()
    comm, ncomm = communities(nodes, edges)
    pos, cents = layout(nodes, edges, comm, ncomm)

    # Center and normalize. An off-centre cloud orbits like a wobbling moon
    # instead of turning on its own axis, which is most of why it read as
    # amateur. Subtract the centroid, then scale to a fixed radius so the
    # framing is identical every export.
    # bounding-box centre, not the centroid: a dense cluster drags the centroid
    # off to one side and the web then orbits lopsided in frame.
    ctr = [(min(pos[n["id"]][i] for n in nodes)
            + max(pos[n["id"]][i] for n in nodes)) / 2 for i in range(3)]
    for p in pos.values():
        for i in range(3):
            p[i] -= ctr[i]
    for c in cents:
        for i in range(3):
            c[i] -= ctr[i]
    # Scale on the 95th percentile, not the max. One stray node flung out by a
    # long strand used to define the whole scale, so the body shrank to fit the
    # outlier and the picture read as a small ball floating in a lot of space.
    # SOFT RADIAL COMPRESSION. Dean, 2026-08-17: "some of the clusters near the
    # end reach out too long, it makes the shape look odd." Measured him right —
    # median node sat at 65 units, the 95th at 120, and the furthest at 188.
    # Nearly 3x the median on a handful of nodes, and those few are exactly the
    # tendrils that read as spikes coming off the body. This does NOT move the
    # core: anything inside r0 is untouched. Past r0 the excess gets pushed
    # through a saturating curve, so the outer shell asymptotes instead of
    # stretching, and a strand that wants to fly out lands on the surface.
    # ...but NOT under the anatomy layout. This pass pushes everything past the
    # 80th-percentile radius onto a shell, which is a sphere-maker — it would
    # shave the temporal lobes, the cerebellum and the brainstem straight back
    # into a ball and undo the anatomy. It exists to reel in tendrils from a
    # force layout; anatomy has no tendrils, every centre is a placed anchor.
    _skip_squash = bool(SHAPES[DEFAULT_SHAPE].get("anatomy"))
    _rr = sorted(math.sqrt(p[0] ** 2 + p[1] ** 2 + p[2] ** 2) for p in pos.values())
    # REVERTED to the 80th-percentile floor — the setting that was live when
    # Dean said the shape looked right. Loosening it to the 94th was part of
    # the freeform experiment he threw out.
    r0 = _rr[int(len(_rr) * 0.80)] or 1.0
    span = max(1e-6, (_rr[int(len(_rr) * 0.95)] - r0)) * 1.15
    for p in pos.values():
        if _skip_squash:
            break
        r = math.sqrt(p[0] ** 2 + p[1] ** 2 + p[2] ** 2)
        if r <= r0 or not math.isfinite(r):
            continue
        ex = r - r0
        nr = r0 + ex / (1.0 + ex / span)
        f = nr / r
        p[0] *= f; p[1] *= f; p[2] *= f

    _rads = sorted(math.sqrt(p[0] ** 2 + p[1] ** 2 + p[2] ** 2) for p in pos.values())
    rad = _rads[int(len(_rads) * 0.95)] or 1.0
    sc = 120.0 / rad
    for p in pos.values():
        p[0] *= sc; p[1] *= sc; p[2] *= sc
    for c in cents:
        c[0] *= sc; c[1] *= sc; c[2] *= sc

    idx = {n["id"]: i for i, n in enumerate(nodes)}
    out_nodes = []
    deg = defaultdict(int)
    for s, d, _, _ in edges:
        deg[s] += 1
        deg[d] += 1
    for n in nodes:
        p = pos[n["id"]]
        out_nodes.append({
            # "i" is the REAL entity id. Without it the renderer had no way to
            # know which dot is which memory, so live firing had to be random —
            # pretty, and a lie. With it, the server can say "entity 4471 was
            # just touched" and the exact right dot lights up.
            # "g" = lobe group, so the renderer can colour by anatomy the way
            # the dashboard does. "r" = the specific region, for the tooltip.
            "g": LOBE_OF_REGION.get(COMM_LOBE.get(comm[n["id"]], ""), "subcortical"),
            "r": COMM_LOBE.get(comm[n["id"]], ""),
            # NO "l". The label is the memory's raw text — real filenames and
            # real paths. Dean, 2026-08-17: "I don't want to be like outing my
            # real file names... and I'm sure other people don't want to as
            # well." That fix went into the TOOLTIP; the field kept shipping.
            #
            # Measured on this exact export before removing it: 2,072 labels,
            # 1,411 of them containing a path or filename, including
            # "secure/install_log_api_key". All of it in a 1.2MB JSON any
            # browser downloads in full and any devtools tab reads in one click.
            # Hiding it in the renderer while still putting it on the wire is
            # not privacy, it's a curtain — and the release tarball would have
            # handed a stranger this same file.
            #
            # Nothing consumes it. The only reader was buildLabels(), which is
            # a hard no-op for this same reason. If richer hover is ever wanted
            # it shows the anatomical region, which is already in "r".
            "t": n["type"], "c": comm[n["id"]],
            "i": n["id"],
            "s": round(n["salience"], 3), "m": n["mentions"],
            "d": deg[n["id"]],
            "p": [round(p[0], 2), round(p[1], 2), round(p[2], 2)],
        })

    out_edges = []
    for s, d, rel, w in edges:
        a, b = pos[s], pos[d]
        ca, cb = cents[comm[s]], cents[comm[d]]
        # bundling control point: pull inter-community edges toward the
        # midpoint of the two community cores -> woven strands, not spaghetti
        same = comm[s] == comm[d]
        # TWO handles, not one. A single midpoint handle bows a strand into
        # open space — that's the "links floating in the air" look. With one
        # handle near each end's own cluster core, the strand leaves its
        # cluster, runs along a shared trunk with every other strand going the
        # same way, and enters the far cluster. Threads merge into cables.
        # gentle handles. At 0.82 the strand dives for its cluster core the
        # instant it leaves the node, so visually the line never touches the
        # dot it belongs to — it reads as disconnected even though it isn't.
        beta = 0.18 if same else 0.45
        k1 = [a[i] * (1 - beta) + ca[i] * beta for i in range(3)]
        k2 = [b[i] * (1 - beta) + cb[i] * beta for i in range(3)]
        if not same:
            # pull both handles toward the origin so trunks run through the
            # body of the web instead of arcing around the outside of it
            # 0.88 dragged EVERY inter-community strand through the middle of
            # the sphere. Thousands of additively-blended lines crossing one
            # small volume is exactly the "too hazy in the center" blowout —
            # the haze was structural, not a shader setting. 0.97 keeps the
            # trunking (strands still merge into cables) but routes them
            # through the body of the web instead of one point.
            k1 = [k1[i] * 0.97 for i in range(3)]
            k2 = [k2[i] * 0.97 for i in range(3)]
        out_edges.append({
            "a": idx[s], "b": idx[d], "r": rel, "w": round(min(3.0, w), 2),
            "k": [round(k1[0], 2), round(k1[1], 2), round(k1[2], 2)],
            "k2": [round(k2[0], 2), round(k2[1], 2), round(k2[2], 2)],
        })

    # The mind's serial number, shipped so the page can show it. Same value the
    # layout was seeded from — this is not a second hash, it's THE hash, so what
    # the corner says is provably the number that produced the shape on screen.
    # MATURITY, 0..1. Not shown as a number anywhere — the renderer uses it to
    # lift the resting brightness of every strand, so an older mind's web reads
    # as more strongly wired instead of merely bigger. This is the visible half
    # of "after 25 it's just the connections getting stronger."
    _mat = _WOVEN
    data = {"nodes": out_nodes, "edges": out_edges, "communities": ncomm,
            "fp": format(_fingerprint(nodes, edges), "016x"),
            "mat": round(max(0.0, min(1.0, _mat)), 4),
            "age_days": round(_AGE_DAYS, 2),
            "generated": __import__("time").time()}
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    # ATOMIC WRITE. Dean, 2026-08-17: "make everything live." The moment this
    # re-exports on a timer, a browser can fetch mid-write and get half a JSON
    # file — which is exactly the "DID NOT BOOT / not valid JSON" class of bug
    # we already ate once. Write to a temp beside it, then rename: on the same
    # filesystem that's atomic, so a reader sees either the whole old file or
    # the whole new one, never a torn one.
    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, separators=(",", ":"))
    os.replace(tmp, OUT)

    # STAMP SIDECAR — a ~90 byte file the live page can poll cheaply. Polling
    # the 1.2MB graph itself just to ask "did anything change" would burn a
    # megabyte a minute per viewer for nothing. Same atomic dance.
    stamp = {"generated": data["generated"], "fp": data["fp"],
             "nodes": len(out_nodes), "edges": len(out_edges)}
    spath = os.path.join(os.path.dirname(OUT), "brainweb-stamp.json")
    with open(spath + ".tmp", "w") as f:
        json.dump(stamp, f, separators=(",", ":"))
    os.replace(spath + ".tmp", spath)

    _record_growth(data, out_nodes, out_edges)

    print(f"nodes={len(out_nodes)} edges={len(out_edges)} communities={ncomm} -> {OUT}")
    print(f"fp={data['fp']}")
    print(f"bytes={os.path.getsize(OUT)}")


if __name__ == "__main__":
    main()
