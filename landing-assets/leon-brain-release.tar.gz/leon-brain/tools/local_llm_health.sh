#!/usr/bin/env bash
# local_llm_health.sh — mechanical guard against a repeat of the day-of-silence.
#
# On 2026-08-07 Dean's Claude usage ran out and Leon went mute for over a day,
# because LEON_DISABLE_LOCAL_LLM=1 made the local fallback unavailable. The flag
# lived in /etc/leon/secrets.env while the .env copy was already commented out,
# so the two config sources drifted and nobody could see the live one.
#
# This asserts, against the RUNNING process (not a file on disk):
#   1. the brain's live environ resolves to a non-"off" local LLM mode
#   2. the configured model is actually pulled in ollama
#   3. local_llm.is_available() is True
#   4. no stray legacy kill switch is live anywhere
#
# Exit 0 = a Claude outage would be survivable. Non-zero = Leon would go silent.
# Run from the wake sequence, not from memory.

set -uo pipefail
BRAIN_DIR=/opt/leon-brain
FAIL=0
note() { printf '%s %s\n' "$1" "$2"; }

PID=$(systemctl show -p MainPID --value leon.service 2>/dev/null)
if [ -z "${PID:-}" ] || [ "$PID" = "0" ] || [ ! -r "/proc/$PID/environ" ]; then
  note FAIL "leon.service has no readable MainPID (got '${PID:-}')"
  exit 2
fi
note OK "brain MainPID=$PID (resolved, never hardcoded — a hardcoded 550 fooled me once)"

ENVFILE=$(tr '\0' '\n' < "/proc/$PID/environ")
MODE=$(printf '%s\n' "$ENVFILE" | sed -n 's/^LEON_LOCAL_LLM_MODE=//p')
MODEL=$(printf '%s\n' "$ENVFILE" | sed -n 's/^LEON_LOCAL_MODEL=//p')
LEGACY=$(printf '%s\n' "$ENVFILE" | sed -n 's/^LEON_DISABLE_LOCAL_LLM=//p')
MODE=${MODE:-fallback}
MODEL=${MODEL:-qwen2.5:3b-instruct-q4_K_M}

if [ "$MODE" = "off" ]; then
  note FAIL "live mode is 'off' — a Claude outage means silence"; FAIL=1
else
  note OK "live mode=$MODE"
fi

if [ -n "$LEGACY" ] && [ "$LEGACY" != "0" ]; then
  note WARN "legacy LEON_DISABLE_LOCAL_LLM=$LEGACY still in the live environ (harmless while MODE is set, but retire it: grep -rn LEON_DISABLE_LOCAL_LLM /etc /opt)"
fi

if ollama list 2>/dev/null | awk 'NR>1{print $1}' | grep -qx "$MODEL"; then
  note OK "model $MODEL is pulled"
else
  note FAIL "model $MODEL is NOT pulled — availability check would pass but generation would 404"; FAIL=1
fi

AVAIL=$(cd "$BRAIN_DIR" && python3 -c "
import sys; sys.path.insert(0,'$BRAIN_DIR')
try:
    from brain import local_llm as L
    print('%s|%s' % (L.is_available(), L.LOCAL_LLM_MODE))
except Exception as e:
    print('ERR|%s' % e)
" 2>/dev/null)
case "$AVAIL" in
  True\|*) note OK "local_llm.is_available()=True (${AVAIL#*|})" ;;
  *)       note FAIL "local_llm availability check failed: $AVAIL"; FAIL=1 ;;
esac

if [ "$FAIL" -eq 0 ]; then
  note PASS "a Claude outage is survivable — Leon keeps talking"
else
  note FAIL "Leon would go MUTE in a Claude outage. Fix before it happens, not after."
fi
exit "$FAIL"
