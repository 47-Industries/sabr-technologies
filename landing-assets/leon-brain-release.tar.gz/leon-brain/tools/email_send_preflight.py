#!/usr/bin/env python3
"""Preflight for the outreach send path.

Exists because the Gmail refresh token silently died 2026-06-20 (OAuth consent
screen stuck in Testing => Google expires test-user refresh tokens after 7 days)
and NOTHING noticed for seven weeks, because nothing ever tried to send.

Rule this enforces: never trust "credentials exist on disk". Ask Google.
Exit 0 = send path is live. Exit 1 = dead, with the reason.
"""
import json, sys, urllib.parse, urllib.request

CRED = "/root/.openclaw/google-oauth/credentials.json"
TOK  = "/root/.openclaw/google-oauth/tokens.json"

def pick(d, key):
    return d.get(key) or d.get("installed", {}).get(key) or d.get("web", {}).get(key)

def main():
    try:
        cred = json.load(open(CRED)); tok = json.load(open(TOK))
    except Exception as e:
        print(f"DEAD: cannot read credentials ({e})"); return 1
    rt = tok.get("refresh_token")
    if not rt:
        print("DEAD: no refresh_token in token store"); return 1
    body = urllib.parse.urlencode({
        "client_id": pick(cred, "client_id"),
        "client_secret": pick(cred, "client_secret"),
        "refresh_token": rt,
        "grant_type": "refresh_token",
    }).encode()
    try:
        r = urllib.request.urlopen("https://oauth2.googleapis.com/token", body, timeout=20)
        data = json.load(r)
    except Exception as e:
        detail = ""
        try: detail = e.read().decode()[:200]
        except Exception: pass
        print(f"DEAD: Google refused the refresh token. {getattr(e,'code','')} {detail}")
        print("FIX: Google Cloud console -> OAuth consent screen -> publish "
              "from Testing to Production, then re-authorize once. Testing-mode "
              "refresh tokens expire after 7 days.")
        return 1
    if not data.get("access_token"):
        print("DEAD: refresh succeeded but returned no access_token"); return 1
    print("LIVE: refresh token valid, access_token obtained.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
