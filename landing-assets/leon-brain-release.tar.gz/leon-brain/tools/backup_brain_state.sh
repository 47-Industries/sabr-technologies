#!/usr/bin/env bash
# Consistent nightly backup of Leon's own brain_state.
# Uses sqlite3 .backup (NOT cp) — a live WAL database copied with cp can land
# torn/unreadable. Non-sqlite files are rsynced. Keeps last N dated dirs.
set -uo pipefail
SRC=/opt/leon-brain/brain_state
DEST_ROOT=/opt/leon-brain/brain_state-backups
KEEP=7
ts=$(date +%Y%m%d-%H%M%S)
dest="$DEST_ROOT/$ts"
mkdir -p "$dest" || exit 1

fail=0
shopt -s nullglob
for db in "$SRC"/*.db; do
  name=$(basename "$db")
  if sqlite3 "$db" ".backup '$dest/$name'" 2>/dev/null; then
    # prove the copy is readable and not truncated
    if ! sqlite3 "$dest/$name" "pragma quick_check;" 2>/dev/null | grep -q '^ok$'; then
      echo "CORRUPT COPY: $name" >&2; fail=1
    fi
  else
    echo "BACKUP FAILED: $name" >&2; fail=1
  fi
done

rsync -a --exclude='*.db' --exclude='*.db-wal' --exclude='*.db-shm' \
      --exclude='code_backups' "$SRC"/ "$dest/_files/" 2>/dev/null

# rotate: keep newest $KEEP
ls -1d "$DEST_ROOT"/*/ 2>/dev/null | sort -r | tail -n +$((KEEP+1)) | xargs -r rm -rf

du_sz=$(du -sh "$dest" | cut -f1)
echo "backup $ts -> $dest ($du_sz), failures=$fail"
exit $fail
