#!/usr/bin/env bash
# stale_terminal_check.sh — mechanical guard against the "Enter never landed" bug.
#
# WHY THIS EXISTS: three separate times, Leon typed a prompt into a delegated
# tmux terminal, the Enter keystroke never submitted it, and the terminal sat
# idle for hours while Leon believed it was working. Once it cost Dean 147
# minutes of dead air. Promising to "check next time" did not fix it. This does.
#
# Detects: a pane whose Claude TUI input box contains text AND which is not
# currently working (no "Worked for"/spinner activity on the last screen).
# Prints one line per suspect pane. Exit 1 if any found, 0 if clean.
#
# Usage: bash tools/stale_terminal_check.sh [--clear|--submit]
#   --clear   sends Ctrl-U to wipe the stranded text (does NOT submit it —
#             submitting blind could re-run stale work).
#   --submit  sends a raw CR (-H 0d) to actually submit it, then verifies the
#             pane really started running. Use when you know the text is wanted.
#
# Every finding is confirmed by a repaint probe before it is reported — see the
# long note at the probe itself. A first capture alone is NOT evidence.

set -uo pipefail
SESSION="${LEON_TMUX_SESSION:-agents}"
CLEAR=0
SUBMIT=0
case "${1:-}" in
  --clear)  CLEAR=1 ;;
  --submit) SUBMIT=1 ;;
  "")       ;;
  *) echo "unknown option: $1 (want --clear or --submit)" >&2; exit 2 ;;
esac

found=0

# Only real agent panes — leon-view-* are read-only mirrors of the same session.
while read -r target name; do
  [[ -z "$target" ]] && continue
  screen="$(tmux capture-pane -p -t "$target" 2>/dev/null)" || continue

  # The input box line starts with the prompt glyph. Strip it and see if
  # anything but whitespace is left.
  # The LIVE input box is the LAST prompt-glyph line on screen, inside the
  # bottom border box. Earlier '❯' lines are the ECHOED TRANSCRIPT of prompts
  # already submitted — matching those makes the check report a pane as stale
  # forever after any successful submit (false positive, observed 2026-08-09 on
  # spark-8-website: '/clear' had landed, ctx was empty, check still screamed).
  # Scope to the region after the last border rule, then take that box's line.
  boxline="$(printf '%s\n' "$screen" | awk '/^❯/{last=$0} END{print last}')"
  pending="$(printf '%s' "$boxline" | sed 's/^❯//')"
  # An empty input box is not literally empty — the TUI pads it with spaces and
  # U+00A0 non-breaking spaces. Strip ALL whitespace (including the unicode
  # kind) before deciding there is real stranded text, or every idle pane
  # reports as stale and the check becomes noise you learn to ignore.
  stripped="$(printf '%s' "$pending" | sed 's/\xc2\xa0//g' | tr -d '[:space:]')"
  [[ -z "$stripped" ]] && continue
  # Trim leading/trailing whitespace for display only.
  pending="$(printf '%s' "$pending" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"

  # If the pane is actively churning, text in the box is normal (queued input),
  # not stranded.
  #
  # ONLY 'esc to interrupt' proves a turn is RUNNING. The old check also matched
  # '✻ Work…' / '✻ Think…' — but a FINISHED turn paints a past-tense summary
  # with the SAME glyph ('✻ Worked for 8s', '✻ Cogitated for 8m 21s'). Those
  # matched, so the check read a long-idle pane as busy and skipped it: the
  # exact pane it exists to catch. Caught 2026-08-10 when this misread made a
  # dead pane report as submitted. A live spinner always carries the interrupt
  # hint; a completed summary never does. Match the hint, nothing else.
  if printf '%s\n' "$screen" | grep -qiF 'esc to interrupt'; then
    continue
  fi

  # ── REPAINT PROBE ─────────────────────────────────────────────────────────
  # capture-pane returns tmux's buffer, which is only as fresh as the LAST TIME
  # THE APP PAINTED. The Claude TUI (Ink) does not repaint an idle input box, so
  # a line that was submitted and consumed can sit in the buffer looking like
  # stranded text for as long as nothing touches the pane. Observed live
  # 2026-08-10 03:06: three panes read as STALE; typing a single character into
  # one wiped the whole "stranded" line, proving the app's input box had been
  # empty the entire time and only the buffer was lying.
  #
  # So: never trust the first capture. Provoke a repaint with a net-zero edit —
  # one printable char, then one backspace — and re-read. Real stranded text
  # survives it unchanged (foo -> foox -> foo). A phantom frame does not
  # (nothing -> x -> nothing), and the box comes back genuinely empty.
  #
  # Raw hex, not key names: tmux's key translation table is exactly what the
  # Ink raw-mode reader ignores (this is the same root cause as the Enter bug —
  # `send-keys Enter` never submits, `send-keys -H 0d` does). 78='x', 7f=DEL.
  tmux send-keys -t "$target" -H 78 2>/dev/null
  tmux send-keys -t "$target" -H 7f 2>/dev/null
  sleep 0.4
  screen2="$(tmux capture-pane -p -t "$target" 2>/dev/null)" || continue
  boxline2="$(printf '%s\n' "$screen2" | awk '/^❯/{last=$0} END{print last}')"
  stripped2="$(printf '%s' "$boxline2" | sed 's/^❯//; s/\xc2\xa0//g' | tr -d '[:space:]')"
  if [[ -z "$stripped2" ]]; then
    # The text evaporated under a keystroke that removed itself. It was never
    # in the app — only in the buffer. Not a finding. Saying nothing here is the
    # entire point: a check that reports phantoms is a check you stop reading.
    continue
  fi

  found=1
  echo "STALE  $name  ($target)  unsent: ${pending:0:70}"
  if (( SUBMIT )); then
    # -H 0d, never `Enter` — see the note above and the 2026-08-10 root cause.
    tmux send-keys -t "$target" -H 0d
    sleep 1
    if tmux capture-pane -p -t "$target" | grep -qiE 'esc to interrupt|✻ (Churn|Work|Think)'; then
      echo "       -> submitted; pane is now running"
    else
      echo "       -> submitted, but pane is NOT running — verify by hand"
    fi
  elif (( CLEAR )); then
    tmux send-keys -t "$target" C-u
    echo "       -> cleared (text was NOT submitted; resend deliberately)"
  fi
done < <(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{window_name}' 2>/dev/null \
           | awk -v s="$SESSION" '$1 ~ "^"s":"')

if (( found )); then
  exit 1
fi
echo "clean — no stranded input in any $SESSION pane"
exit 0
