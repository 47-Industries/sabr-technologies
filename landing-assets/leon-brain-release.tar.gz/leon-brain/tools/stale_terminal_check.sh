#!/usr/bin/env bash
# stale_terminal_check.sh — mechanical guard against the "Enter never landed" bug.
#
# WHY THIS EXISTS: three separate times, Leon typed a prompt into a delegated
# tmux terminal, the Enter keystroke never submitted it, and the terminal sat
# idle for hours while Leon believed it was working. Once it cost Dean 147
# minutes of dead air. Promising to "check next time" did not fix it. This does.
#
# Detects: a pane whose Claude TUI input box contains text AND which is not
# currently working (no "Worked for"/spinner activity on the last screen).
# Prints one line per suspect pane. Exit 1 if any found, 0 if clean.
#
# Usage: bash tools/stale_terminal_check.sh [--clear]
#   --clear  also sends Ctrl-U to wipe the stranded text (does NOT submit it —
#            submitting blind could re-run stale work).

set -uo pipefail
SESSION="${LEON_TMUX_SESSION:-agents}"
CLEAR=0
[[ "${1:-}" == "--clear" ]] && CLEAR=1

found=0

# Only real agent panes — leon-view-* are read-only mirrors of the same session.
while read -r target name; do
  [[ -z "$target" ]] && continue
  screen="$(tmux capture-pane -p -t "$target" 2>/dev/null)" || continue

  # The input box line starts with the prompt glyph. Strip it and see if
  # anything but whitespace is left.
  # The LIVE input box is the LAST prompt-glyph line on screen, inside the
  # bottom border box. Earlier '❯' lines are the ECHOED TRANSCRIPT of prompts
  # already submitted — matching those makes the check report a pane as stale
  # forever after any successful submit (false positive, observed 2026-08-09 on
  # spark-8-website: '/clear' had landed, ctx was empty, check still screamed).
  # Scope to the region after the last border rule, then take that box's line.
  boxline="$(printf '%s\n' "$screen" | awk '/^❯/{last=$0} END{print last}')"
  pending="$(printf '%s' "$boxline" | sed 's/^❯//')"
  # An empty input box is not literally empty — the TUI pads it with spaces and
  # U+00A0 non-breaking spaces. Strip ALL whitespace (including the unicode
  # kind) before deciding there is real stranded text, or every idle pane
  # reports as stale and the check becomes noise you learn to ignore.
  stripped="$(printf '%s' "$pending" | sed 's/\xc2\xa0//g' | tr -d '[:space:]')"
  [[ -z "$stripped" ]] && continue
  # Trim leading/trailing whitespace for display only.
  pending="$(printf '%s' "$pending" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"

  # If the pane is actively churning, text in the box is normal (queued input),
  # not stranded. Esc/interrupt hints only appear while a turn is running.
  if printf '%s\n' "$screen" | grep -qiE 'esc to interrupt|✻ (Churn|Work|Think)'; then
    continue
  fi

  found=1
  echo "STALE  $name  ($target)  unsent: ${pending:0:70}"
  if (( CLEAR )); then
    tmux send-keys -t "$target" C-u
    echo "       -> cleared (text was NOT submitted; resend deliberately)"
  fi
done < <(tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{window_name}' 2>/dev/null \
           | awk -v s="$SESSION" '$1 ~ "^"s":"')

if (( found )); then
  exit 1
fi
echo "clean — no stranded input in any $SESSION pane"
exit 0
