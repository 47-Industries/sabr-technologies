#!/usr/bin/env bash
# watch_video.sh — turn a video into something Leon can actually LOOK at.
#
#   watch_video.sh <file-or-URL> [frame_count]
#
# Produces, under /opt/leon-brain/leon-out/watch/<slug>/ :
#   source.*            the video itself
#   frames/f_%03d.jpg   N evenly-spaced stills across the whole runtime
#   sheet_1.jpg ...     contact sheets (4x3 grids) — the whole arc in one image
#   info.txt            duration / resolution / fps / codec
#
# Leon then reads the sheets and frames directly with his Read tool.
set -uo pipefail

SRC="${1:-}"
N="${2:-24}"
OUTROOT="/opt/leon-brain/leon-out/watch"
[ -z "$SRC" ] && { echo "usage: watch_video.sh <file-or-URL> [frame_count]"; exit 2; }

slug=$(echo "$SRC" | md5sum | cut -c1-10)
DIR="$OUTROOT/$slug"
rm -rf "$DIR"; mkdir -p "$DIR/frames"

VID=""
if [[ "$SRC" =~ ^https?:// ]]; then
  echo "[1/4] downloading..."
  # a direct media URL is just a file — curl it, don't make yt-dlp parse it as a webpage
  if [[ "$SRC" =~ \.(mp4|mov|webm|mkv|m4v|avi)(\?.*)?$ ]]; then
    ext=$(echo "$SRC" | sed -E 's/\?.*$//; s/.*\.([a-zA-Z0-9]+)$/\1/')
    curl -sL --max-time 300 -o "$DIR/source.$ext" "$SRC" 2>"$DIR/dl.log"
    [ -s "$DIR/source.$ext" ] || rm -f "$DIR/source.$ext"
  fi
  if [ -z "$(ls "$DIR"/source.* 2>/dev/null)" ]; then
    yt-dlp --no-playlist --no-warnings -f "best[ext=mp4]/best" \
           -o "$DIR/source.%(ext)s" "$SRC" >>"$DIR/dl.log" 2>&1
  fi
  VID=$(ls "$DIR"/source.* 2>/dev/null | head -1)
  if [ -z "$VID" ]; then
    echo "DOWNLOAD FAILED — last lines:"; tail -6 "$DIR/dl.log"
    echo "HINT: login-walled sites block this. Save the file and pass a local path instead."
    exit 3
  fi
else
  [ -f "$SRC" ] || { echo "no such file: $SRC"; exit 4; }
  ext="${SRC##*.}"
  cp "$SRC" "$DIR/source.$ext"
  VID="$DIR/source.$ext"
fi

echo "[2/4] probing..."
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$VID" 2>/dev/null | cut -d. -f1)
[ -z "$DUR" ] && DUR=0
ffprobe -v error -select_streams v:0 \
  -show_entries stream=width,height,r_frame_rate,codec_name \
  -show_entries format=duration,size,format_name \
  -of default=noprint_wrappers=1 "$VID" > "$DIR/info.txt" 2>&1
HAS_AUDIO=$(ffprobe -v error -select_streams a -show_entries stream=codec_name -of csv=p=0 "$VID" 2>/dev/null | head -1)
echo "audio_stream=${HAS_AUDIO:-none}" >> "$DIR/info.txt"
cat "$DIR/info.txt"

echo "[3/4] extracting $N frames across ${DUR}s..."
if [ "$DUR" -gt 2 ] 2>/dev/null; then
  # even spacing across the WHOLE runtime, so nothing at the end is missed
  fps=$(python3 -c "print(max(0.02,$N/float($DUR)))")
  ffmpeg -v error -i "$VID" -vf "fps=$fps,scale=640:-2" -frames:v "$N" \
         -q:v 3 "$DIR/frames/f_%03d.jpg" -y 2>>"$DIR/ff.log"
else
  ffmpeg -v error -i "$VID" -vf "scale=640:-2" -frames:v "$N" \
         -q:v 3 "$DIR/frames/f_%03d.jpg" -y 2>>"$DIR/ff.log"
fi
GOT=$(ls "$DIR/frames" 2>/dev/null | wc -l)
if [ "$GOT" -eq 0 ]; then
  echo "FRAME EXTRACTION FAILED:"; tail -6 "$DIR/ff.log"; exit 5
fi

echo "[4/4] building contact sheets..."
i=0; sheet=1
while [ $i -lt "$GOT" ]; do
  ffmpeg -v error -pattern_type glob -start_number $((i+1)) \
    -i "$DIR/frames/f_*.jpg" -vf "tile=4x3:nb_frames=12,scale=1280:-2" \
    -frames:v 1 -q:v 3 "$DIR/sheet_$sheet.jpg" -y 2>>"$DIR/ff.log"
  i=$((i+12)); sheet=$((sheet+1))
done
# fallback: if glob/tile produced nothing, sheets simply won't exist; frames still do
echo
echo "READY  dir=$DIR"
echo "frames=$GOT  duration=${DUR}s  sheets=$(ls "$DIR"/sheet_*.jpg 2>/dev/null | wc -l)"
ls "$DIR"/sheet_*.jpg 2>/dev/null
