# conv_replay — does the conversation panel paint Dean's line twice?

Behavioural replay of the SHIPPED functions in `dashboard/index.html`
(`_paintUserEcho`, `_userLinePainted`, `_claimUserEcho`, `_normUserLine`,
`pullConvo`, `appendConvTurn`) under jsdom. `extract.py` pulls them out of the
page by brace matching, so this tests the real code, never a paraphrase.

    npm i jsdom          # not vendored; that is why this is a tool, not a test
    python3 extract.py [path/to/index.html] > funcs.js
    node run.js

The scenario is taken from a live WebSocket capture: the server emits exactly
ONE `brain_response_start` carrying the user text, then the store rows arrive
through `pullConvo`. Each case must end with exactly one `.conv-user` row.

Known-good / known-bad, 2026-08-05:

    current dashboard/index.html          4/4 PASS
    git show 8e026afe~1:dashboard/index.html   FAIL "store re-punctuated"
        Dean rows=2  ["Dean:do it", "Dean:Do it."]

That failing case IS the bug Dean reported for days: the brain/STT stores the
utterance re-punctuated, pre-fix `_normUserLine` did not strip punctuation, so
the echo already on screen could not be claimed and a second row was painted.

The source-level invariants this protects are pinned in
`tests/test_dashboard_conv_dedupe.py`, which runs in the stdlib-only suite.

## The label trap (2026-08-05, the third "fix" of this bug)

**The browser never receives `dashboard/index.html` verbatim.** `server/__init__.py`
rewrites `conv-name-dean">Dean:` to `LEON_USER_NAME` (default `You:`) as it serves
the page — per-SI branding. It rewrites the three PAINTERS. It cannot rewrite the
two GUARDS, which matched the literal `/^\s*Dean:\s*/`.

So in the bytes Dean actually loaded, the strip matched nothing: extracted text
stayed `"You:do it"` while `want` was `"do it"`, strict equality failed every
time, and both the echo and the stored copy rendered — on a freshly loaded tab.

Replay the SERVED form with `LABEL=You`. Against the code before the
`_userRowText()` fix:

    LABEL=You node run.js
    FAIL  typed, store text identical
          Dean rows=3  ["You:helllo??","You:helllo??","You:helllo??"]

Three rows for one message. Always run both forms — a pass on the disk form
alone is a pass on a file nobody loads.
