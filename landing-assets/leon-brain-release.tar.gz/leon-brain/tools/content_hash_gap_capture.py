#!/usr/bin/env python3
"""Item 11 / DJ-017 content-hash gap capture.

Reuses brain.mission.pane_watchdog.split_frame/_h (the shipped content_hash,
chrome-excluded per decision 4/5) rather than reimplementing it. Samples two
panes for WINDOW seconds, records the timestamp of every content_hash change,
and reports the hung arm's fastest recurrence period vs the healthy arm's
slowest inter-change gap -- the exact pair item 11's 3x criterion compares.

Usage: content_hash_gap_capture.py <hung_session:window> <healthy_session:window> [window_s] [interval_s]
"""
import json
import subprocess
import sys
import time

sys.path.insert(0, "/opt/leon-brain")
from brain.mission.pane_watchdog import split_frame, _h  # noqa: E402


def capture(target: str) -> str:
    session, window = target.split(":", 1)
    return subprocess.run(
        ["tmux", "capture-pane", "-p", "-t", f"{session}:{window}", "-S", "-60"],
        capture_output=True, text=True, check=True,
    ).stdout


def sample_hash(target: str) -> str:
    content, _chrome = split_frame(capture(target))
    return _h(content)


def run(target: str, window_s: float, interval_s: float) -> list:
    """Returns list of (ts, hash) for every SAMPLE, not just changes."""
    out = []
    t0 = time.time()
    while time.time() - t0 < window_s:
        ts = time.time() - t0
        out.append((ts, sample_hash(target)))
        time.sleep(interval_s)
    return out


def change_gaps(samples: list) -> list:
    """Gaps between successive DISTINCT content_hash values."""
    changes = [samples[0][0]]
    for i in range(1, len(samples)):
        if samples[i][1] != samples[i - 1][1]:
            changes.append(samples[i][0])
    return [b - a for a, b in zip(changes, changes[1:])]


def main():
    hung_t, healthy_t = sys.argv[1], sys.argv[2]
    window_s = float(sys.argv[3]) if len(sys.argv) > 3 else 60.0
    interval_s = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5

    hung_samples, healthy_samples = [], []
    t0 = time.time()
    while time.time() - t0 < window_s:
        ts = time.time() - t0
        hung_samples.append((ts, sample_hash(hung_t)))
        healthy_samples.append((ts, sample_hash(healthy_t)))
        time.sleep(interval_s)

    hung_gaps = change_gaps(hung_samples)
    healthy_gaps = change_gaps(healthy_samples)

    result = {
        "window_s": window_s,
        "interval_s": interval_s,
        "hung_target": hung_t,
        "healthy_target": healthy_t,
        "hung_distinct_hashes": len({h for _, h in hung_samples}),
        "healthy_distinct_hashes": len({h for _, h in healthy_samples}),
        "hung_change_gaps_s": hung_gaps,
        "healthy_change_gaps_s": healthy_gaps,
        "hung_fastest_recurrence_s": min(hung_gaps) if hung_gaps else None,
        "healthy_slowest_gap_s": max(healthy_gaps) if healthy_gaps else None,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
