#!/usr/bin/env bash
# Beta-readiness gate for the Sabr SI installer.
#
# Every check here runs something real. Nothing in this file asserts that a
# commit exists or that a file is on disk — those are not verification. Each
# gate exercises the layer a CUSTOMER touches: the live endpoint, the real
# payload, the shipped tarball, the actual four verbs.
#
# Exit 0 = safe to hand to a beta tester. Any FAIL = do not ship.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2

PASS=0; FAIL=0; WARN=0
ok()   { printf '  [PASS] %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf '  [FAIL] %s\n' "$1"; FAIL=$((FAIL+1)); }
warn() { printf '  [WARN] %s\n' "$1"; WARN=$((WARN+1)); }
sec()  { printf '\n== %s ==\n' "$1"; }

BASE="${SABR_BASE_URL:-https://sabrtechnologies.com}"
TOKEN="${SABR_PREFLIGHT_TOKEN:-}"

# ── 1. the code itself ────────────────────────────────────────────
sec "1. Code"
if python3 -m pytest tests/ -q >/tmp/pf_tests.txt 2>&1; then
  ok "test suite green ($(grep -oE '[0-9]+ passed' /tmp/pf_tests.txt | tail -1))"
else
  bad "test suite RED — $(tail -1 /tmp/pf_tests.txt)"
fi

# ── 1b. source durability ─────────────────────────────────────────
# TWICE NOW a real, shipping fix has existed ONLY in the working tree.
# 2026-08-11: the "mr. sabr" fix. 2026-08-12: 121 lines of bootstrap.sh
# including the P0 that dead-ended every stock Mac. Both were live to
# customers — the site serves that file straight off disk and the release
# build tars the working tree — so nothing looked broken. But git had none
# of it. One disk failure and the fix is gone with no trace it ever existed,
# and the next person to touch that file silently reverts it.
#
# The tarball-from-HEAD gate below cannot catch this: it compares the
# payload to HEAD, and HEAD is exactly what's missing the work. This gate
# checks the other direction — that nothing real is stranded off HEAD.
# Untracked files are ignored on purpose (landing/ is full of scratch
# assets); only TRACKED modifications and unpushed commits count.
sec "1b. Source durability"
# workspaces/ is cloned client repos and scratch, not shipping source — if it
# were counted this gate would be red forever and everyone would learn to
# ignore it. The landing/ line is the submodule pointer; its contents get
# their own check on the next line.
_dirty=$(git status --porcelain --untracked-files=no 2>/dev/null \
         | grep -vE '^.[ MD] (landing|workspaces/)' | wc -l)
_sub_dirty=$(git -C landing status --porcelain --untracked-files=no 2>/dev/null | wc -l)
if [ "$_dirty" = "0" ] && [ "$_sub_dirty" = "0" ]; then
  ok "no tracked changes stranded in a working tree"
else
  bad "$((_dirty + _sub_dirty)) tracked file(s) modified but never committed — a fix that exists only on this disk"
fi

_unpushed=$(git log --oneline @{u}..HEAD 2>/dev/null | wc -l)
_sub_unpushed=$(git -C landing log --oneline @{u}..HEAD 2>/dev/null | wc -l)
if [ "$_unpushed" = "0" ] && [ "$_sub_unpushed" = "0" ]; then
  ok "everything committed is also pushed"
else
  bad "$((_unpushed + _sub_unpushed)) commit(s) local-only — this box is the single copy"
fi

# ── 2. the artifact ───────────────────────────────────────────────
sec "2. Release artifact"
if bash landing/verify_release.sh >/tmp/pf_rel.txt 2>&1 && grep -q "ALL CLEAN" /tmp/pf_rel.txt; then
  ok "secret/content/size/pin/name gates clean at every serve location"
else
  bad "release audit failed — see /tmp/pf_rel.txt"
fi

TARBALL=landing/leon-brain-release.tar.gz
if [ -f "$TARBALL" ]; then
  if [ "$(tar tzf $TARBALL 2>/dev/null | grep -c 'secure/')" = "0" ]; then
    ok "no secure/ (private keys) in the payload"
  else
    bad "PRIVATE KEYS ARE IN THE TARBALL — stop everything"
  fi
  # THE ARTIFACT MUST CONTAIN THE FIXES. Learned 2026-08-12: this script
  # reported "ready to hand to a beta tester" while the tarball on disk had
  # been built hours earlier and contained NONE of that night's fixes. Every
  # other gate passed because every other gate read the REPO. The customer
  # does not download the repo. Check the payload.
  SHIPPED_COMMIT=$(tar xzOf $TARBALL leon-brain/VERSION 2>/dev/null \
                   | awk '/^commit:/ {print substr($2,1,8)}')
  HEAD_COMMIT=$(git rev-parse --short=8 HEAD 2>/dev/null)
  if [ -n "$SHIPPED_COMMIT" ] && [ "$SHIPPED_COMMIT" = "$HEAD_COMMIT" ]; then
    ok "tarball was built from HEAD ($HEAD_COMMIT)"
  else
    bad "tarball is from ${SHIPPED_COMMIT:-unknown}, HEAD is $HEAD_COMMIT — customers would download code without the latest fixes"
  fi

  # List ONCE into a file. `tar tzf … | grep -q` makes grep exit on the first
  # match, tar gets SIGPIPE, and the check reports "missing" for a file that
  # is present. That false FAIL is worse than no check at all.
  tar tzf $TARBALL >/tmp/pf_list.txt 2>/dev/null
  # An entry point that isn't shipped is a silent dead install.
  for f in run.py run_body.py requirements.txt; do
    if grep -q "leon-brain/$f$" /tmp/pf_list.txt; then
      ok "ships $f"
    else
      bad "$f missing from the tarball — autostart would point at nothing"
    fi
  done
else
  bad "no release tarball built"
fi

# ── 3. the four verbs ─────────────────────────────────────────────
sec "3. Install / update / uninstall / wipe"
if grep -q "def run(self)" installer/sabr_installer.py; then
  ok "install verb present"
else
  bad "no install path"
fi
if grep -q '"--uninstall"' installer/sabr_installer.py; then
  ok "uninstall verb present (--uninstall)"
else
  bad "no uninstall verb"
fi
if grep -q '"--purge"' installer/sabr_installer.py; then
  ok "wipe verb present (--purge)"
else
  bad "no wipe verb"
fi
# Update has no flag of its own — it is "re-run the installer over a live
# install". That works, and was verified by hand, but a customer told to
# "update" has no obvious verb to type and no way to tell an update from a
# reinstall. Against the four-verbs-one-program spec this is a real gap.
if grep -qE '"--update"' installer/sabr_installer.py; then
  ok "update verb present (--update)"
else
  warn "no explicit --update verb; update = re-run the installer (works, undiscoverable)"
fi

# ── 4. the live path a stranger walks ─────────────────────────────
sec "4. Live checkout -> token -> download"
CODE=$(curl -s -o /tmp/pf_cfg.json -w '%{http_code}' --max-time 25 \
       "$BASE/api/onboarding/install-config?token=${TOKEN}" 2>/dev/null)
if [ -z "$TOKEN" ]; then
  warn "no SABR_PREFLIGHT_TOKEN set — skipping live redemption"
elif [ "$CODE" = "200" ] && grep -q '"ok":[[:space:]]*true' /tmp/pf_cfg.json; then
  ok "token redeems (HTTP 200, ok:true)"
  WANT=$(python3 -c "import json;print(json.load(open('/tmp/pf_cfg.json')).get('artifacts',{}).get('release_tarball_sha256',''))" 2>/dev/null)
  MINE=$(sha256sum $TARBALL 2>/dev/null | awk '{print $1}')
  if [ -n "$WANT" ] && [ "$WANT" = "$MINE" ]; then
    ok "endpoint advertises the sha we actually built"
  else
    bad "sha mismatch: endpoint says ${WANT:0:16}…, disk has ${MINE:0:16}…"
  fi
  # Identity: the config must NOT leak the builder's name to a customer.
  #
  # This check used to grep SABR_PREFLIGHT_TOKEN's own response for "Dean" and
  # call any hit a leak. That is wrong and it cost us a false NOT-READY on
  # 2026-08-12: Dean's tenant is legitimately named "Dean Sabr", so redeeming
  # HIS token and getting HIS name back is the endpoint behaving correctly.
  # The property only means anything against a token that is NOT the builder's.
  # So mint a throwaway tenant through the SAME public route a customer walks
  # (POST /api/onboarding/create-account) and assert ITS config comes back with
  # ITS name, not the builder's.
  #
  # Minting via brain.tenant on this box does NOT work for this: the registry
  # is per-install (brain_state/registry.json) and production runs elsewhere,
  # so a locally-minted token is invalid at the live endpoint.
  PROBE=$(curl -s --max-time 25 -X POST "$BASE/api/onboarding/create-account" \
          -H 'Content-Type: application/json' \
          -d '{"siName":"PreflightProbe","userName":"Preflight Probe","email":"preflight-probe@sabrtechnologies.com","business":"internal preflight"}' 2>/dev/null \
          | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))" 2>/dev/null)
  if [ -z "$PROBE" ]; then
    warn "could not mint a probe tenant — identity leak check not exercised"
  elif curl -s --max-time 25 "$BASE/api/onboarding/install-config?token=$PROBE" \
       -o /tmp/pf_probe.json 2>/dev/null &&
       grep -qiE '"user_name"[[:space:]]*:[[:space:]]*"(dean|dean sabr)"' /tmp/pf_probe.json; then
    bad "install-config returns the builder's name to a non-builder tenant"
  elif grep -q '"user_name"[[:space:]]*:[[:space:]]*"Preflight Probe"' /tmp/pf_probe.json; then
    ok "no builder identity in the install config (verified with a probe tenant)"
  else
    warn "probe tenant redeemed but returned an unexpected identity"
  fi
else
  bad "token redemption failed (HTTP $CODE)"
fi

# An unauthenticated version endpoint is what proves a running SI is ours.
if curl -fs --max-time 15 "$BASE/api/version" >/dev/null 2>&1; then
  ok "/api/version answers unauthenticated"
else
  warn "/api/version not reachable at $BASE"
fi

# ── 5. cross-platform reality ─────────────────────────────────────
sec "5. Windows / macOS / Linux"
# The installer branches on IS_WINDOWS / IS_MAC / IS_LINUX, not on the
# platform.system() strings. Checking for "Darwin" reported a missing macOS
# path on an installer that has one.
for marker in IS_WINDOWS IS_MAC IS_LINUX; do
  n=$(grep -c "\b$marker\b" installer/sabr_installer.py)
  if [ "$n" -gt 1 ]; then
    ok "installer branches on $marker ($n sites)"
  else
    bad "no real $marker branching in the installer"
  fi
done
if grep -q "plistlib" installer/sabr_installer.py; then
  ok "macOS autostart uses a LaunchAgent plist"
else
  bad "no macOS autostart mechanism"
fi

# ── 6. things that must never latch off ───────────────────────────
sec "6. No permanent give-up paths"
if grep -q "_SCREEN_BACKOFF_MAX" brain/vision_daemon.py; then
  ok "screen capture backs off instead of latching off"
else
  bad "screen capture can still disable itself for the whole session"
fi

# ── 7. promises nobody kept ───────────────────────────────────────
sec "7. Comments that name code that doesn't exist"
if python3 tools/check_comment_promises.py . >/tmp/pf_promises.txt 2>&1; then
  ok "no comment promises a function that was never written"
else
  bad "$(tail -2 /tmp/pf_promises.txt | head -1)"
fi

printf '\n────────────────────────────\n'
printf 'PASS %d   WARN %d   FAIL %d\n' "$PASS" "$WARN" "$FAIL"
if [ "$FAIL" -gt 0 ]; then
  printf 'NOT READY for a beta tester.\n'; exit 1
fi
printf 'Ready to hand to a beta tester.\n'
