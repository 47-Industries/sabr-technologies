#!/usr/bin/env bash
# Restart the brain (to load on-disk fixes into the running process), then
# verify the signup rate-limit fix at the layer a customer experiences:
# a POST from a public IP that is NOT this VPS.
# Writes results to /opt/leon-brain/brain_state/restart_verify.txt
set -uo pipefail
OUT=/opt/leon-brain/brain_state/restart_verify.txt
: > "$OUT"
say() { echo "$*" >> "$OUT"; }

say "=== BEFORE restart ==="
say "running commit: $(curl -s https://sabrtechnologies.com/api/version | python3 -c 'import sys,json;print(json.load(sys.stdin).get("commit"))' 2>/dev/null)"

systemctl restart leon.service
say "restart issued, waiting for /api/version to answer..."
for i in $(seq 1 90); do
  if curl -sf --max-time 5 https://sabrtechnologies.com/api/version >/dev/null 2>&1; then
    say "back up after ${i}s"; break
  fi
  sleep 2
done

say ""
say "=== AFTER restart ==="
say "running commit: $(curl -s https://sabrtechnologies.com/api/version | python3 -c 'import sys,json;print(json.load(sys.stdin).get("commit"))' 2>/dev/null)"

say ""
say "=== stranger signup, from Dean's PC (a different public IP) ==="
RESP=$(ssh -o ConnectTimeout=20 -o StrictHostKeyChecking=no "mr. sabr"@desktop-htdf1jb \
  'curl.exe -s -X POST https://sabrtechnologies.com/api/onboarding/create-account -H "Content-Type: application/json" -d "{\"siName\":\"Probe\",\"userName\":\"Rate Limit Probe\",\"email\":\"ratelimit-probe@sabrtechnologies.com\"}"' 2>/dev/null | tr -d '\r')
say "$RESP"

TOKEN=$(printf '%s' "$RESP" | grep -oE 'nlkd_[A-Za-z0-9_-]+' | head -1)
if [ -n "$TOKEN" ]; then
  say "minted token: ${TOKEN:0:12}..."
  say "--- redeem it (identity leak check: must NOT say Dean) ---"
  say "$(curl -s "https://sabrtechnologies.com/api/onboarding/install-config?token=$TOKEN" | head -c 500)"
else
  say "NO TOKEN MINTED — signup still blocked for a stranger."
fi
say ""
say "done: $(date)"
