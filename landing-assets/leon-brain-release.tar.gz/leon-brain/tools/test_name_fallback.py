"""Regression test: no code path may name a client's SI "Leon".

Simulates a CLIENT install (LEON_SI_NAME missing, brain/owner_facts.py absent
so brain.origin.is_original() is False) and exercises every site that resolves
the SI name. Any site that answers "Leon" is a leak: that name drags in
leon_persona.py and Dean's life with it.

Run:  python3 tools/test_name_fallback.py
Exit: 0 = clean, 1 = at least one site leaked.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# --- simulate a client machine ------------------------------------------
os.environ.pop("LEON_SI_NAME", None)
os.environ.pop("LEON_WAKE_WORD", None)
os.environ["LEON_LICENSE_KEY"] = "test-client-key"

import brain.origin as _origin
_origin.is_original = lambda: False          # this box is NOT the original

from brain import identity


def check(label, value):
    leaked = "leon" in str(value).strip().lower()
    print(f"  {'LEAK ' if leaked else 'ok   '} {label:<34} -> {value!r}")
    return leaked


def main():
    print("Simulated client install (no LEON_SI_NAME, not the original):\n")
    bad = 0

    bad += check("identity.si_name()", identity.si_name())
    bad += check("identity.user_name()", identity.user_name())

    # run.py banner name
    from run import resolve_si_name
    bad += check("run.resolve_si_name()", resolve_si_name())

    # proactive fallback source label
    import brain.proactive as proactive
    bad += check("proactive._notify_source()", proactive._notify_source(None))

    # goal_pursuit curiosity prompt name
    import brain.goal_pursuit as gp
    bad += check("goal_pursuit._curiosity_name()", gp._curiosity_name())

    # wake word
    from brain.voice.wake_word_vosk import default_wake_phrase
    bad += check("voice.default_wake_phrase()", default_wake_phrase())

    print()
    if bad:
        print(f"FAIL — {bad} site(s) named a client's SI 'Leon'.")
        return 1
    print("PASS — no site leaked the ancestor's name.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
