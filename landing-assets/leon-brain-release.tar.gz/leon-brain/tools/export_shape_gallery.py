#!/usr/bin/env python3
"""Every layout shape I've tried, rendered in one grid so Dean can point.

He asked for "every single try on a screen like in a box." I never saved the
old exported files, so this does the honest version instead of faking it: it
loads the graph ONCE, builds communities ONCE, then re-runs the layout under
each named preset in export_brainweb.SHAPES. Same nodes, same edges, same
communities in every box — the ONLY thing that differs between panels is the
shape math. So a difference you see is a real difference in the layout, not
noise from a different export.

Output: dashboard/js/brainweb-shapes.json  (positions only, subsampled)
"""
import json
import math
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tools import export_brainweb as EB  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "dashboard", "js", "brainweb-shapes.json")

# each panel is small on screen, so full density is wasted pixels and a dead
# framerate with 9 of them. Subsample to a fixed budget — the SHAPE survives
# subsampling, which is the only thing being judged here.
MAX_NODES = 900
MAX_EDGES = 2600


def normalize(pos, nodes):
    """Identical framing for every panel or the comparison is meaningless."""
    ids = [n["id"] for n in nodes]
    ctr = [(min(pos[i][k] for i in ids) + max(pos[i][k] for i in ids)) / 2
           for k in range(3)]
    for i in ids:
        for k in range(3):
            pos[i][k] -= ctr[k]
    rr = sorted(math.sqrt(sum(pos[i][k] ** 2 for k in range(3))) for i in ids)
    r95 = rr[int(len(rr) * 0.95)] or 1.0
    s = 100.0 / r95
    for i in ids:
        for k in range(3):
            pos[i][k] *= s
    return pos


def main():
    t0 = time.time()
    random.seed(47)
    print("loading graph…", flush=True)
    nodes, edges = EB.load()
    comm, ncomm = EB.communities(nodes, edges)
    print(f"  {len(nodes)} nodes, {len(edges)} edges, {ncomm} communities "
          f"({time.time() - t0:.1f}s)", flush=True)

    # pick the subsample ONCE so every panel shows the same memories
    keep = set(n["id"] for n in nodes)
    if len(nodes) > MAX_NODES:
        deg = {n["id"]: 0 for n in nodes}
        for s, d, _, _ in edges:
            deg[s] += 1
            deg[d] += 1
        keep = set(sorted(deg, key=lambda i: -deg[i])[:MAX_NODES])
    sub_nodes = [n for n in nodes if n["id"] in keep]
    idx = {n["id"]: i for i, n in enumerate(sub_nodes)}
    sub_edges = [(s, d, w) for s, d, _x, w in edges if s in keep and d in keep]
    sub_edges.sort(key=lambda e: -e[2])
    sub_edges = sub_edges[:MAX_EDGES]
    print(f"  panel budget: {len(sub_nodes)} nodes / {len(sub_edges)} strands",
          flush=True)

    out = {
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "nodes": len(sub_nodes),
        "edges": len(sub_edges),
        "comm": [comm[n["id"]] % 24 for n in sub_nodes],
        "links": [[idx[s], idx[d]] for s, d, _w in sub_edges],
        "shapes": [],
    }

    for name in EB.SHAPES:
        t = time.time()
        random.seed(47)                       # same jitter in every panel
        pos, _c = EB.layout(nodes, edges, comm, ncomm, shape=name)
        pos = normalize(pos, sub_nodes)
        flat = []
        for n in sub_nodes:
            p = pos[n["id"]]
            flat += [round(p[0], 1), round(p[1], 1), round(p[2], 1)]
        out["shapes"].append({"name": name, "p": flat})
        print(f"  {name:<9} {time.time() - t:5.1f}s", flush=True)

    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(out, f, separators=(",", ":"))
    os.replace(tmp, OUT)
    print(f"wrote {OUT} ({os.path.getsize(OUT) / 1024:.0f} KB) "
          f"in {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
