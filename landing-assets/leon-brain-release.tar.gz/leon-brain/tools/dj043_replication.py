#!/usr/bin/env python3
"""DJ-043 synthetic replication, 20 trials, per the protocol written before
this ran. Ship rule reused unchanged: hung <=5 voluntary switches/15s,
healthy >=100/15s, sampled at the thread-group-leader TID for both (the
precondition verified in DJ-043 -- /proc/PID/status reflects only the
leader thread, not a process-wide sum)."""
import subprocess
import sys
import time
import json

sys.path.insert(0, "/opt/leon-brain")
from tools.keep_busy_runner import ensure_busy  # noqa: E402

HUNG_PID = sys.argv[1]
HEALTHY_PID = sys.argv[2]
HEALTHY_WINDOW = sys.argv[3]
N_TRIALS = int(sys.argv[4])
WINDOW_S = float(sys.argv[5]) if len(sys.argv) > 5 else 15.0
OUT = sys.argv[6] if len(sys.argv) > 6 else "/tmp/dj043_repl.jsonl"

HUNG_CEIL = 5
HEALTHY_FLOOR = 100


def vctx(pid):
    try:
        for line in open(f"/proc/{pid}/status"):
            if line.startswith("voluntary_ctxt_switches:"):
                return int(line.split()[1])
    except Exception:
        return None
    return None


idx_holder = [0]
kill = False

for trial in range(1, N_TRIALS + 1):
    reprompted = ensure_busy(HEALTHY_WINDOW, idx_holder)
    if reprompted:
        time.sleep(5)

    h0 = vctx(HUNG_PID)
    b0 = vctx(HEALTHY_PID)
    time.sleep(WINDOW_S)
    h1 = vctx(HUNG_PID)
    b1 = vctx(HEALTHY_PID)

    hung_delta = (h1 - h0) if (h0 is not None and h1 is not None) else None
    healthy_delta = (b1 - b0) if (b0 is not None and b1 is not None) else None

    hung_pass = hung_delta is not None and hung_delta <= HUNG_CEIL
    healthy_pass = healthy_delta is not None and healthy_delta >= HEALTHY_FLOOR
    if not (hung_pass and healthy_pass):
        kill = True

    row = {"trial": trial, "reprompted_this_trial": reprompted,
           "hung_delta": hung_delta, "healthy_delta": healthy_delta,
           "hung_pass": hung_pass, "healthy_pass": healthy_pass}
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
    print(json.dumps(row))

print(json.dumps({"FINAL": "NO" if kill else "YES - held across all 20 trials"}))
