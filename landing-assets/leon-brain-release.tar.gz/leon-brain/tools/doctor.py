#!/usr/bin/env python3
"""
doctor.py — find EVERYTHING that's broken, in one pass, on any OS.

WHY THIS EXISTS (Dean, 2026-08-10): we kept discovering breakage one symptom
at a time — "it won't talk", then "it can't hear", then "two instances" —
because nothing ever asked the whole question at once. Every one of those was
findable in under a second by a script. So: no more symptom-chasing.

THE RULE THIS ENCODES: an install is not "successful" because pip exited 0.
It is successful when every module the code actually imports can actually be
imported, in the interpreter that will actually run it.

Usage:  python doctor.py            # human report
        python doctor.py --json     # machine readable
Exit:   0 = clean, 1 = something is broken.
"""
import ast
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STDLIB = set(getattr(sys, "stdlib_module_names", ()))

# import-name -> pip-name, where they differ.
PIP_NAME = {
    "faster_whisper": "faster-whisper", "cv2": "opencv-python",
    "PIL": "Pillow", "yaml": "PyYAML", "dotenv": "python-dotenv",
    "serial": "pyserial", "sklearn": "scikit-learn",
    "webrtcvad": "webrtcvad" if platform.system() == "Linux" else "webrtcvad-wheels",
}
# Imported behind a try/except and genuinely optional — absence is not a fault.
OPTIONAL = {"deepgram", "elevenlabs", "pyaudio", "torch", "transformers",
            "qiskit", "matplotlib", "openai", "google", "mistralai", "ollama"}

results = []


def add(area, name, ok, detail="", fatal=True):
    results.append({"area": area, "name": name, "ok": ok,
                    "detail": detail, "fatal": fatal})


_LOCAL_CACHE = {}


def local_modules(pkg_dir):
    """Anything that is OUR code — a sibling .py or package anywhere in the
    tree — is not a missing dependency. Without this, `import leon_core` from
    brain/neurons.py reads as 'pip install leon_core', which is nonsense and
    makes the whole report untrustworthy."""
    key = str(pkg_dir)
    if key not in _LOCAL_CACHE:
        names = set()
        for base in {ROOT, pkg_dir}:
            for p in base.rglob("*"):
                if "__pycache__" in p.parts or ".venv" in p.parts:
                    continue
                if p.suffix == ".py":
                    names.add(p.stem)
                elif p.is_dir():
                    names.add(p.name)
        _LOCAL_CACHE[key] = names
    return _LOCAL_CACHE[key]


def third_party_imports(pkg_dir):
    """Every top-level third-party module the source actually imports."""
    found = {}
    for py in pkg_dir.rglob("*.py"):
        if "__pycache__" in py.parts or ".venv" in py.parts:
            continue
        try:
            tree = ast.parse(py.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError:
            add("source", str(py.relative_to(ROOT)), False, "does not parse")
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                # level>0 is a relative import — never third party.
                names = [node.module] if (node.module and not node.level) else []
            else:
                continue
            for n in names:
                top = n.split(".")[0]
                if top in STDLIB or top in ("brain", "tools", "tests"):
                    continue
                if top in local_modules(pkg_dir):
                    continue
                found.setdefault(top, str(py.relative_to(ROOT)))
    return found


def check_imports(python_exe):
    """Import each module IN THE INTERPRETER THAT RUNS THE BRAIN, not this one."""
    mods = third_party_imports(ROOT / "brain")
    probe = (
        "import importlib.util as u,sys,json\n"
        "print(json.dumps([m for m in json.loads(sys.argv[1])"
        " if u.find_spec(m) is None]))"
    )
    try:
        out = subprocess.run([python_exe, "-c", probe, json.dumps(sorted(mods))],
                             capture_output=True, text=True, timeout=120)
        missing = json.loads(out.stdout.strip() or "[]")
    except Exception as e:
        add("deps", "import probe", False, f"could not run {python_exe}: {e}")
        return
    for m in sorted(mods):
        if m not in missing:
            continue
        opt = m in OPTIONAL
        add("deps", m, False,
            f"imported by {mods[m]} — pip install {PIP_NAME.get(m, m)}",
            fatal=not opt)
    add("deps", f"{len(mods) - len(missing)}/{len(mods)} brain imports resolve",
        not [m for m in missing if m not in OPTIONAL])


def check_audio(python_exe):
    """Speaking and hearing are SEPARATE faults. Report them separately."""
    for label, mods in (("can speak (output)", ["pyttsx3"]),
                        ("can hear (input)", ["sounddevice", "soundfile",
                                              "faster_whisper", "webrtcvad"])):
        probe = ("import importlib.util as u,sys,json;"
                 "print(json.dumps([m for m in json.loads(sys.argv[1])"
                 " if u.find_spec(m) is None]))")
        try:
            out = subprocess.run([python_exe, "-c", probe, json.dumps(mods)],
                                 capture_output=True, text=True, timeout=60)
            missing = json.loads(out.stdout.strip() or "[]")
        except Exception as e:
            add("audio", label, False, str(e))
            continue
        add("audio", label, not missing,
            f"missing {', '.join(missing)}" if missing else "")

    # A module that imports is not a device that exists. Ask the hardware.
    probe = ("import sounddevice as sd;"
             "d=sd.query_devices();"
             "print(sum(1 for x in d if x['max_input_channels']>0),"
             "sum(1 for x in d if x['max_output_channels']>0))")
    try:
        out = subprocess.run([python_exe, "-c", probe],
                             capture_output=True, text=True, timeout=60)
        if out.returncode != 0:
            add("audio", "audio devices", False,
                (out.stderr.strip().splitlines() or ["query failed"])[-1])
        else:
            ins, outs = out.stdout.split()
            add("audio", "microphone present", int(ins) > 0, f"{ins} input device(s)")
            add("audio", "speaker present", int(outs) > 0, f"{outs} output device(s)")
    except Exception as e:
        add("audio", "audio devices", False, str(e))


def check_instances():
    """Two brains on one state DB is the 'give me a second' forever bug."""
    try:
        import psutil
    except ImportError:
        add("runtime", "instance count", False, "psutil missing, cannot check",
            fatal=False)
        return
    procs = []
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            cl = " ".join(p.info["cmdline"] or "")
        except Exception:
            continue
        # pythonw.exe is the Windows autostart interpreter — it has no console
        # and was invisible to every earlier check that only looked for python.
        if "run.py" in cl and "python" in (p.info["name"] or "").lower():
            procs.append((p.info["pid"], cl[:90]))
    add("runtime", "exactly one SI instance", len(procs) <= 1,
        f"{len(procs)} running: {procs}" if len(procs) != 1 else "1 running")


def check_llm():
    """No LLM credential = a brain with memory, senses, and no mouth."""
    env = {}
    for f in (ROOT / ".env", Path("/etc/leon/secrets.env")):
        if f.exists():
            for line in f.read_text(errors="replace").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    env[k.strip()] = v.strip().strip('"\'')
    api = env.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")
    creds = Path.home() / ".claude" / ".credentials.json"
    sub = creds.exists() and creds.stat().st_size > 0
    add("llm", "language model reachable", bool(api) or sub,
        "no ANTHROPIC_API_KEY and no ~/.claude/.credentials.json — "
        "the SI will boot, think, and never speak")

    for key in ("ELEVENLABS_API_KEY", "DEEPGRAM_API_KEY", "GEMINI_API_KEY"):
        v = env.get(key, "")
        if key in env:
            add("keys", key, bool(v), "present but EMPTY" if not v else "", fatal=False)


def check_config_drift():
    """Two config files disagreeing cost a full day of silence on 2026-08-09."""
    seen = {}
    for f in (ROOT / ".env", Path("/etc/leon/secrets.env")):
        if not f.exists():
            continue
        for line in f.read_text(errors="replace").splitlines():
            line = line.strip()
            if line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            seen.setdefault(k.strip(), {})[str(f)] = v.strip()
    for k, where in seen.items():
        if len(where) > 1 and len(set(where.values())) > 1:
            add("config", f"{k} drift", False,
                " vs ".join(f"{p}={v}" for p, v in where.items()))
    add("config", "no config drift between .env and secrets.env",
        not any(len(w) > 1 and len(set(w.values())) > 1 for w in seen.values()))


def main():
    venv = ROOT / (".venv/Scripts/python.exe" if platform.system() == "Windows"
                   else ".venv/bin/python")
    python_exe = str(venv) if venv.exists() else sys.executable
    add("env", "virtualenv in use", venv.exists(), f"using {python_exe}", fatal=False)

    check_imports(python_exe)
    check_audio(python_exe)
    check_instances()
    check_llm()
    check_config_drift()

    if "--json" in sys.argv:
        print(json.dumps(results, indent=2))
    else:
        bad = [r for r in results if not r["ok"]]
        print(f"\nSI DOCTOR — {platform.system()} — {len(results) - len(bad)}"
              f"/{len(results)} checks passed\n")
        for area in dict.fromkeys(r["area"] for r in results):
            print(f"  {area}")
            for r in (x for x in results if x["area"] == area):
                mark = "OK  " if r["ok"] else ("FAIL" if r["fatal"] else "warn")
                print(f"    [{mark}] {r['name']}"
                      + (f" — {r['detail']}" if r["detail"] else ""))
            print()
        fatal = [r for r in bad if r["fatal"]]
        print(f"  {len(fatal)} blocking problem(s), "
              f"{len(bad) - len(fatal)} non-blocking.\n")

    return 1 if any(not r["ok"] and r["fatal"] for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
