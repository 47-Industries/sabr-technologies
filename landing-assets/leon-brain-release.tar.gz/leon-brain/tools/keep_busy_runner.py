#!/usr/bin/env python3
"""Reusable idle-detect-and-reprompt wrapper for any probe that needs a
`claude` pane to stay genuinely busy across a multi-trial batch, instead of
racing a fixed-size task against the batch duration (which just moves the
same race to a new duration on the next probe).

Checks the pane for pane_watchdog's own FINISHED_RX marker before every
trial; if seen (and not already reacted to), sends a fresh prompt from a
rotating pool immediately, so the pane is busy again before the trial's
sampling window starts.
"""
import subprocess
import sys
import time

import re

sys.path.insert(0, "/opt/leon-brain")

# NOT importing pane_watchdog._FINISHED_RX or terminal_loop.FINISHED_RX --
# both are missing (?:\d+m )? and silently drop every sub-1-minute
# completion ("Cooked for 58s" never matches, only "...for 11m 29s" does).
# Confirmed live in terminal_loop.py:145 (is_busy()), not just here.
# Defining the corrected pattern locally rather than patching the shared
# production regex from a test tool.
_FINISHED_RX = re.compile(r"^\s*[✻✢✽◉·*]\s+\w+ for (?:\d+m )?\d+s\s*$")

PROMPTS = [
    "Write a long, detailed 3000-word essay about the history of telescopes. No tools, just write it.",
    "Explain, in depth and at length, how compilers actually turn source code into machine code, "
    "from lexing through codegen. No tools, just write it out.",
    "Write a 3000-word original short story about a submarine sonar operator on a night shift. No tools.",
    "Give a thorough, technical explanation of how TCP congestion control works -- slow start, "
    "AIMD, the whole mechanism -- at length, no tools.",
    "Write a long, detailed essay on the history of clockmaking, 3000 words, no tools.",
    "Explain the mathematics of the FFT (Fast Fourier Transform) from first principles, at length, no tools.",
    "Write a 3000-word original short story about a lighthouse keeper. No tools, just write it.",
    "Give a long, detailed technical walkthrough of how a modern CPU's out-of-order execution "
    "pipeline actually works, no tools.",
    "Write a detailed 3000-word essay on the history of papermaking. No tools, just write it.",
    "Explain in depth how public-key cryptography (RSA specifically) actually works mathematically, "
    "at length, no tools.",
    "Write a 3000-word original short story about a wildlife biologist tracking a wolf pack. No tools.",
    "Give a long, thorough explanation of how garbage collection works in a modern language runtime "
    "-- mark-and-sweep, generational GC, the tradeoffs -- no tools.",
]


def capture(sw):
    return subprocess.run(
        ["tmux", "capture-pane", "-p", "-t", sw, "-S", "-8"],
        capture_output=True, text=True,
    ).stdout


def is_idle(raw):
    for line in reversed((raw or "").splitlines()):
        if _FINISHED_RX.match(line.strip()):
            return True
    return False


def reprompt(sw, prompt):
    subprocess.run(["tmux", "send-keys", "-t", sw, prompt, "Enter"])
    time.sleep(1)
    subprocess.run(["tmux", "send-keys", "-t", sw, "Enter"])


def ensure_busy(session_window, idx_holder):
    raw = capture(session_window)
    if is_idle(raw):
        idx_holder[0] = (idx_holder[0] + 1) % len(PROMPTS)
        reprompt(session_window, PROMPTS[idx_holder[0]])
        time.sleep(3)  # give it a moment to start generating before a trial samples it
        return True
    return False


if __name__ == "__main__":
    # standalone smoke test -- only reads argv when run directly, not on import
    sw = sys.argv[1]
    idx = [0]
    print("idle now?", is_idle(capture(sw)))
    if ensure_busy(sw, idx):
        print("was idle, reprompted")
    else:
        print("already busy")
