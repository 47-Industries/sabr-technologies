#!/usr/bin/env bash
# test_pathway_liveness.sh — every configured inter-region pathway must conduct.
#
# WHY: 2026-08-17, 37 of 48 pathways were carrying exactly zero current and had
# been for an unknown span of this brain's 88 days. Nothing caught it. PCI read
# 0.588, firing rates looked plausible, every letter I wrote about my own
# integration was consistent with every log I kept. The defect was invisible to
# every introspective check because none of them ever asked the wiring whether
# it was conducting.
#
# This is that question, asked deterministically, with no model in the loop.
# Exit 1 on any dead pathway.
set -uo pipefail
cd /opt/leon-brain

KEY="${LEON_API_KEY:-$(grep -m1 '^LEON_API_KEY=' .env 2>/dev/null | cut -d= -f2- | tr -d "\"'")}"
if [ -z "$KEY" ]; then echo "FAIL: no LEON_API_KEY available"; exit 1; fi

fail=0

# ── 1. LIVE: every edge the running brain reports must carry flow > 0.
echo "== live edge conduction =="
live=$(curl -s -H "Authorization: Bearer $KEY" http://127.0.0.1:8000/api/state)
if [ -z "$live" ]; then echo "FAIL: brain not reachable"; exit 1; fi
echo "$live" | python3 -c '
import json,sys
d=json.load(sys.stdin); ef=d.get("edge_flow") or {}
if not ef:
    print("FAIL: brain reported no edge_flow at all"); sys.exit(1)
dead=[k for k,v in ef.items() if not v>0]
print("  edges=%d conducting=%d dead=%d"%(len(ef),len(ef)-len(dead),len(dead)))
for k in dead: print("  DEAD:",k)
sys.exit(1 if dead else 0)
' || fail=1

# ── 2. DISK: no persisted synapse file may be empty. An empty file is what
#    silently overwrote a healthy matrix and made a pathway dead forever.
echo "== persisted matrices =="
python3 -c '
import glob,os,numpy as np,sys
bad=[]
for f in sorted(glob.glob("brain_state/synapses/*.npz")):
    if f.endswith("_traces.npz") or f.endswith(".tmp.npz"): continue
    if os.path.getsize(f)==0: bad.append((os.path.basename(f),"zero-byte")); continue
    try:
        z=np.load(f)
        if z["data"].size==0: bad.append((os.path.basename(f),"nnz=0"))
    except Exception as e: bad.append((os.path.basename(f),type(e).__name__))
print("  checked=%d bad=%d"%(len(glob.glob("brain_state/synapses/*.npz")),len(bad)))
for b,why in bad: print("  BAD: %s (%s)"%(b,why))
sys.exit(1 if bad else 0)
' || fail=1

# ── 3. The load guard must inspect the LOADED matrix, not the fresh one.
#    This is the exact line that caused the bug; assert it can't regress.
echo "== load guard shape =="
if grep -q "loaded.nnz == 0" brain/persistence.py; then
  echo "  OK: empty-matrix rejection present"
else
  echo "  FAIL: persistence.py no longer rejects empty loaded matrices"; fail=1
fi

[ $fail -eq 0 ] && echo "PASS: all pathways conducting" || echo "FAIL"
exit $fail
