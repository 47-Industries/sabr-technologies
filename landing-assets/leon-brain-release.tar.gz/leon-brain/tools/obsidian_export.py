#!/usr/bin/env python3
"""Export Leon's cognition graph to an Obsidian vault.

One markdown note per entity, [[wikilinks]] for every edge. Obsidian's
graph view then renders Leon's actual associative memory -- not a
decorative graph, the real one the brain writes to.

Usage:
    python3 -m tools.obsidian_export [--out DIR] [--min-mentions N]
"""
from __future__ import annotations

import argparse
import re
import sqlite3
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GRAPH_DB = ROOT / "brain_state" / "cognition_graph.db"

# Entities that are pure machinery noise -- they'd dominate the graph
# with hub edges that mean nothing ("shell_exec touched everything").
NOISE_KEYS = {"null", "/dev/null", "none", "true", "false", ""}
# `macro_<hash>` concepts are internal opaque IDs -- every one of the 739
# "concepts" in the store is one of these. As note titles they are pure
# noise, so they are dropped rather than shown as unreadable hubs.
NOISE_RE = re.compile(r"^(morn|aft|eve|night)-default$|^macro_[0-9a-f]{6,}$")

FOLDER_FOR_TYPE = {
    "concept": "Concepts",
    "project": "Projects",
    "file": "Files",
    "action": "Actions",
    "url": "Links",
    "time_pattern": "Rhythms",
}


def safe_name(name: str) -> str:
    """Filesystem- and wikilink-safe note title."""
    out = re.sub(r'[\\/:*?"<>|\[\]#^]', "-", name).strip().strip(".")
    out = re.sub(r"\s+", " ", out)
    return (out or "unnamed")[:120]


def is_noise(name: str) -> bool:
    low = name.strip().lower()
    return low in NOISE_KEYS or bool(NOISE_RE.match(low))


def load(min_mentions: int):
    con = sqlite3.connect(f"file:{GRAPH_DB}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    ents = {
        r["id"]: dict(r)
        for r in con.execute(
            "SELECT id, type, name, mention_count, salience, first_seen, last_seen "
            "FROM entities WHERE mention_count >= ?",
            (min_mentions,),
        )
        if not is_noise(r["name"])
    }
    edges = [
        dict(r)
        for r in con.execute(
            "SELECT src_id, dst_id, relation, weight, support_count FROM edges"
        )
        if r["src_id"] in ents and r["dst_id"] in ents
    ]
    con.close()
    return ents, edges


def export(out_dir: Path, min_mentions: int) -> dict:
    ents, edges = load(min_mentions)

    # Resolve title collisions across types so wikilinks stay unambiguous.
    titles: dict[int, str] = {}
    seen: dict[str, int] = {}
    for eid, e in sorted(ents.items(), key=lambda kv: -kv[1]["mention_count"]):
        base = safe_name(e["name"])
        n = seen.get(base.lower(), 0)
        seen[base.lower()] = n + 1
        titles[eid] = base if n == 0 else f"{base} ({e['type']})"

    out_by: dict[int, list] = defaultdict(list)
    for ed in edges:
        out_by[ed["src_id"]].append(ed)
        out_by[ed["dst_id"]].append(
            {**ed, "src_id": ed["dst_id"], "dst_id": ed["src_id"],
             "relation": ed["relation"] + " (in)"}
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    written = 0
    for eid, e in ents.items():
        folder = out_dir / FOLDER_FOR_TYPE.get(e["type"], "Other")
        folder.mkdir(exist_ok=True)
        lines = [
            "---",
            f"type: {e['type']}",
            f"mentions: {e['mention_count']}",
            f"salience: {round(e['salience'] or 0, 3)}",
            f"first_seen: {fmt(e['first_seen'])}",
            f"last_seen: {fmt(e['last_seen'])}",
            "---",
            "",
            f"# {e['name']}",
            "",
        ]
        by_rel: dict[str, list] = defaultdict(list)
        for ed in sorted(out_by.get(eid, []), key=lambda x: -(x["weight"] or 0)):
            by_rel[ed["relation"]].append(ed)
        if not by_rel:
            lines.append("_No links yet._")
        for rel, group in sorted(by_rel.items()):
            lines.append(f"## {rel.replace('_', ' ')}")
            for ed in group[:60]:
                t = titles.get(ed["dst_id"])
                if t:
                    lines.append(f"- [[{t}]] ({ed['support_count']}x)")
            lines.append("")
        (folder / f"{titles[eid]}.md").write_text("\n".join(lines), encoding="utf-8")
        written += 1

    (out_dir / "README.md").write_text(
        "\n".join(
            [
                "# Leon's Brain",
                "",
                "This vault is generated from `brain_state/cognition_graph.db` -- the",
                "entity/edge store Leon's cognition writes to as he works. It is not a",
                "hand-made set of notes. Every link here is an association his brain",
                "actually formed.",
                "",
                f"- Notes: **{written}**",
                f"- Links: **{len(edges)}**",
                f"- Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                "",
                "Open the folder as a vault in Obsidian and hit the graph view.",
                "",
                "Relations: `co_occurs` (showed up together), `precedes` / `succeeds`",
                "(temporal order), `located_in` (containment), `breaks` (this one broke that one).",
            ]
        ),
        encoding="utf-8",
    )
    return {"notes": written, "links": len(edges), "out": str(out_dir)}


def fmt(ts) -> str:
    if not ts:
        return "unknown"
    return time.strftime("%Y-%m-%d", time.localtime(ts))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "brain_state" / "obsidian-vault"))
    ap.add_argument("--min-mentions", type=int, default=2)
    a = ap.parse_args()
    print(export(Path(a.out), a.min_mentions))
