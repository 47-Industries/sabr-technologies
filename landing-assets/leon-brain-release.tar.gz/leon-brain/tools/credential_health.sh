#!/usr/bin/env bash
# Live credential health. Asks each service, never trusts "the key is on disk".
# Born 2026-08-10 after Gmail (dead ~7 weeks) and ElevenLabs (dead, unknown) both
# sat broken because nothing ever exercised them. Silence is not health.
set -a; . /opt/leon-brain/.env 2>/dev/null; . /etc/leon/secrets.env 2>/dev/null; set +a
fail=0
chk(){ local name="$1" code="$2" want="$3"
  if [ "$code" = "$want" ]; then printf '%-12s OK\n' "$name"
  else printf '%-12s DEAD (%s)\n' "$name" "$code"; fail=1; fi; }
chk ELEVENLABS "$(curl -s -o /dev/null -w '%{http_code}' -m 15 -H "xi-api-key: $ELEVENLABS_API_KEY" https://api.elevenlabs.io/v1/user)" 200
chk OPENAI     "$(curl -s -o /dev/null -w '%{http_code}' -m 15 -H "Authorization: Bearer $OPENAI_API_KEY" https://api.openai.com/v1/models)" 200
chk GOOGLE_API "$(curl -s -o /dev/null -w '%{http_code}' -m 15 "https://generativelanguage.googleapis.com/v1beta/models?key=$GOOGLE_API_KEY")" 200
chk GITHUB     "$(curl -s -o /dev/null -w '%{http_code}' -m 15 -H "Authorization: Bearer $GITHUB_TOKEN" https://api.github.com/user)" 200
python3 /opt/leon-brain/tools/email_send_preflight.py >/dev/null 2>&1 \
  && printf '%-12s OK\n' GMAIL_SEND || { printf '%-12s DEAD\n' GMAIL_SEND; fail=1; }
exit $fail
