#!/bin/bash
# 60s idle, then fire the sleep stimulus, then 180s mid-wait. Tagged rows.
cd /opt/leon-brain
OUT=brain_state/spinner_bands.jsonl
: > $OUT
python3 /tmp/claude-0/-home-deansabr-Desktop-all-folders-Personal-Research-Element-115/6ce31222-b0b3-4acb-a10b-ac176e5a64b3/scratchpad/sampler.py idle 60 >> $OUT
tmux send-keys -t band:p "run python3 -c 'import time; time.sleep(180)'" 
sleep 1
tmux send-keys -t band:p Enter
sleep 6
python3 /tmp/claude-0/-home-deansabr-Desktop-all-folders-Personal-Research-Element-115/6ce31222-b0b3-4acb-a10b-ac176e5a64b3/scratchpad/sampler.py midwait 180 >> $OUT
