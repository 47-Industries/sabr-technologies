import socket
import threading


def _server(ready, port_holder):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    port_holder.append(srv.getsockname()[1])
    srv.listen(1)
    ready.set()
    conn, _ = srv.accept()
    # Accepts the connection, then never sends anything, ever. The client's
    # recv() blocks forever, genuinely, in the kernel -- not a spin.
    threading.Event().wait()


def main():
    ready = threading.Event()
    port_holder = []
    t = threading.Thread(target=_server, args=(ready, port_holder), daemon=True)
    t.start()
    ready.wait()
    port = port_holder[0]

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", port))
    # ESTABLISHED now. Genuinely block in recv() -- zero CPU, real syscall
    # wait, same archetype as DJ-004's FIFO block but WITH a socket to
    # measure byte-delta against.
    client.recv(4096)


if __name__ == "__main__":
    main()
