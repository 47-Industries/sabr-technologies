import hashlib
import math


def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(math.isqrt(n)) + 1):
        if n % i == 0:
            return False
    return True


def hash_chain(seed, rounds):
    h = seed
    for _ in range(rounds):
        h = hashlib.sha256(h).digest()
    return h


def main():
    count = 0
    n = 2
    seed = b"start"
    while True:
        if is_prime(n):
            count += 1
            seed = hash_chain(seed, 50)
        n += 1


if __name__ == "__main__":
    main()
