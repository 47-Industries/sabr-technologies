#!/usr/bin/env python3
"""Soak: residue sampler + the three-stream watchdog, live, on real panes.

Residue has only ever appeared on panes left alone, so the sampler has to be
running when nobody is driving them. This runs both at once — the sampler
ambushes residue, the watchdog exercises wedged/working/finished against real
input.

A DEBT IS CLOSED BY EVIDENCE OF A REPLY, and this runner has to supply it.

The closer was wired into TerminalWatcher.consume() on 2026-08-03 and then
immediately defeated here: this runner never calls consume(), so the v1rtue
probe debt stayed owed and the pane escalated as `pane_wedged` 269s later —
"content frozen 269s > 269s threshold" — against an agent that had already
answered ACK and gone back to work. A real false positive against a real
agent, from the exact failure written into test_send_ledger.py minutes
earlier.

The lesson is not "remember to call consume". It is that a fix wired into ONE
caller is not a fix. The ledger needs a closer keyed on evidence rather than
on which caller happens to be driving, so any consumer of the ledger closes
debts the same way.
"""
import json, os, re, subprocess, sys, time
sys.path.insert(0, "/opt/leon-brain")
from brain.mission import residue_sampler as rs, pane_watchdog as pw, send_ledger as sl

STATE = "/opt/leon-brain/brain_state"
HEARTBEAT = os.path.join(STATE, "soak_heartbeat.json")
POLL_S = float(os.environ.get("LEON_SOAK_POLL_S", "5"))

sampler = rs.ResidueSampler()
watchdog = pw.PaneWatchdog()
counts = {"polls": 0, "samples": 0, "residue_caught": 0, "escalations": 0,
          "debts_closed": 0, "geometry_absent_polls": 0,
          # The AMBIGUOUS state hunt, continuous rather than a one-shot net.
          # A 12s window against a state that only exists while a pane waits
          # mid-turn was never going to catch one — same error as asserting a
          # 110s stream against a 600s threshold. This checks EVERY poll and
          # records the first specimen, because the state is currently
          # predicted-not-witnessed and one sighting settles it.
          "ambiguous_seen": 0, "states": {}}
_prev_sample = {}


def descendants(pid):
    """pid plus every descendant, via /proc walk.

    Added after a socket count disagreed between an ad-hoc read and the
    recorder. Leon's hypothesis was a grandchild holding the socket; the data
    said otherwise — v1rtue's leader had NO children and simply was not in ss
    output any more, so the disagreement was TEMPORAL, two readings minutes
    apart. Kept anyway because element115 does have children, and a leader
    that delegates its network work would produce exactly the bug that was
    hypothesised.
    """
    seen, stack = set(), [pid]
    while stack:
        cur = stack.pop()
        if cur in seen or not cur:
            continue
        seen.add(cur)
        try:
            with open(f"/proc/{cur}/task/{cur}/children") as fh:
                stack.extend(int(x) for x in fh.read().split())
        except Exception:
            pass
    return seen


def socket_map():
    """pid -> (established_count, bytes_in_flight). ONE ss call per tick.

    Measured 2026-08-03: `ss -tnp` costs p50 16.9ms / p90 21.2ms for ALL
    sockets. Per-pane that is 84ms a tick across five panes, over the ~50ms
    budget. Called once and filtered, it is 3.4ms amortised per pane. So the
    cadence is safe only because the call is per TICK, and this comment is
    here so nobody "simplifies" it into the pane loop.

    HONEST GAP, named rather than hidden: ss maps sockets to pids by walking
    /proc/*/fd for inodes. It sees only what this process may read, and a
    keepalive socket looks identical to one awaiting a response — which is why
    the row carries bytes-in-flight separately from a plain count. Presence is
    not evidence of waiting.
    """
    out = {}
    try:
        r = subprocess.run(["ss", "-tnp"], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        return out
    for line in r.splitlines()[1:]:
        f = line.split()
        if len(f) < 5:
            continue
        m = re.search(r"pid=(\d+)", line)
        if not m:
            continue
        pid = int(m.group(1))
        try:
            rq, sq = int(f[1]), int(f[2])
        except ValueError:
            rq = sq = 0
        est, flight = out.get(pid, (0, 0))
        out[pid] = (est + 1, flight + rq + sq)
    return out
started = time.time()
_last_content = {}


def close_debt_if_answered(window, content_hash):
    """Close on EVIDENCE: the pane produced new content after the send.

    Same edge consume() keys on — there being something to read — without
    requiring that Leon be the one reading it. Returns the closed send_id.
    """
    prev = _last_content.get(window)
    _last_content[window] = content_hash
    if prev is None or prev == content_hash:
        return None
    status, entry = sl.debt_status(window, None)
    if status == sl.OWED and entry and not entry.get("replied"):
        sl.mark(entry["send_id"], window, "replied")
        return entry["send_id"]
    return None


while True:
    try:

        counts["polls"] += 1
        windows = sampler.windows()
        _t0 = time.perf_counter()
        socks = socket_map()
        ss_ms = round((time.perf_counter() - _t0) * 1000, 1)
        absent = 0
        for w in windows:
            s = sampler.poll(w)
            if s is None:
                absent += 1
                continue
            counts["samples"] += 1
            if s["disagrees"]:
                counts["residue_caught"] += 1

            meta = pw.pane_meta(w)
            started_at = pw.proc_started_at(meta["pane_pid"])
            frame = rs._tmux(["capture-pane", "-p", "-t",
                              f"{rs.SESSION}:{w}", "-S", "-60"])
            # Close BEFORE deciding, so a pane that just answered is never
            # judged against a debt it has already paid.
            if close_debt_if_answered(w, pw.split_frame(frame)[0]):
                counts["debts_closed"] += 1
            status, _ = sl.debt_status(w, started_at)
            d = watchdog.observe(pw.sample(
                w, frame,
                cpu_ticks=pw.read_cpu_ticks(meta["pane_pid"]),
                pane_pid=meta["pane_pid"], pane_dead=meta["pane_dead"],
                pane_command=meta["pane_command"],
                turn_owed=(status == sl.OWED), debt_status=status,
                proc_started_at=started_at))
            prev = _prev_sample.get(w)
            _prev_sample[w] = pw.sample(w, frame, cpu_ticks=pw.read_cpu_ticks(meta["pane_pid"]),
                                        pane_pid=meta["pane_pid"], now=time.time())
            if prev is not None:
                cur = _prev_sample[w]
                dt = cur.ts - prev.ts
                rate = ((cur.cpu_ticks - prev.cpu_ticks) / dt
                        if cur.cpu_ticks is not None and prev.cpu_ticks is not None and dt > 0
                        else None)
                if (cur.content_hash == prev.content_hash
                        and cur.chrome_pulse != prev.chrome_pulse
                        and rate is not None and rate < pw.CPU_BURN_TICKS_PER_S):
                    counts["ambiguous_seen"] += 1
                    with open(os.path.join(STATE, "ambiguous_state.jsonl"), "a") as fh:
                        fh.write(json.dumps({
                            "ts": cur.ts, "window": w, "cpu_ticks_per_s": rate,
                            "content_frozen": True, "chrome_alive": True,
                            "note": "content frozen + chrome ALIVE + low CPU — the "
                                    "state that makes working and wedged the same "
                                    "observable. Predicted from the mechanism; this "
                                    "row is a WITNESS."}) + "\n")
            # PASSIVE RECORDER — every ~10s, one row per pane, no judgement.
            # Purpose: catch chrome-alive/content-frozen diverging in the WILD.
            # Two attempts to manufacture that state failed, so stop
            # manufacturing and just be recording when a real pane works past
            # its threshold. Writes unconditionally, which is the opposite of
            # the escalation path on purpose: this is a log to read later, not
            # an alert to act on.
            if counts["polls"] % 2 == 0 and prev is not None:
                with open(os.path.join(STATE, "stream_recorder.jsonl"), "a") as fh:
                    fh.write(json.dumps({
                        "ts": cur.ts, "window": w,
                        "content_frozen": cur.content_hash == prev.content_hash,
                        "chrome_frozen": cur.chrome_pulse == prev.chrome_pulse,
                        "cpu_ticks_per_s": None if rate is None else round(rate, 2),
                        "cursor_x": s["cursor_x"], "cursor_cells": s["cursor_cells"],
                        "painted_len": len(s["painted"] or ""),
                        "verdict": d.state, "turn_owed": status == sl.OWED,
                        "gap_s": None if d.gap_s is None else round(d.gap_s),
                        "threshold_s": None if d.threshold_s is None else round(d.threshold_s),
                        # Non-paint, non-timing, non-turn-duration. A pane
                        # awaiting a long call holds a connection; a wedged one
                        # does not. Count and in-flight bytes are separate
                        # because keepalive makes presence alone meaningless.
                        "sockets_established": sum(
                            socks.get(d, (0, 0))[0] for d in descendants(meta["pane_pid"])),
                        "socket_bytes_in_flight": sum(
                            socks.get(d, (0, 0))[1] for d in descendants(meta["pane_pid"])),
                        "descendant_pids": len(descendants(meta["pane_pid"])),
                        "proc_state": (open(f"/proc/{meta['pane_pid']}/stat").read()
                                       .rsplit(")", 1)[1].split()[0]
                                       if meta["pane_pid"] else None),
                        # Logged on the FIRST row only, per Leon: if the walk
                        # costs more than the cadence can absorb, the number
                        # has to be in the record, not in a memory.
                        # Stamped on EVERY row of the tick that paid it, not
                        # just the first. The first-row latch put the number
                        # in a commit message and in zero rows — a painted
                        # value with no landed evidence, which is the exact
                        # failure this whole subsystem exists to catch.
                        "ss_walk_ms": ss_ms,
                    }) + "\n")
            counts["states"][d.state] = counts["states"].get(d.state, 0) + 1
            if d.escalate:
                counts["escalations"] += 1

        # The geometry-absent contract: silent per pane, loud in aggregate.
        alarm, why = pw.geometry_absent_verdict(len(windows), absent)
        if absent:
            counts["geometry_absent_polls"] += 1
        if alarm:
            from brain.mission import escalation
            escalation.escalate("*", "reader_geometry_lost", detail=why)

        with open(HEARTBEAT, "w") as fh:
            json.dump({"started": started, "now": time.time(),
                       "uptime_s": round(time.time() - started, 1), **counts}, fh, indent=2)
    except Exception as e:
        with open(os.path.join(STATE, "soak_errors.log"), "a") as fh:
            fh.write(f"{time.time()} {e!r}\n")
    time.sleep(POLL_S)
