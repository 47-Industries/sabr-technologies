import socket
import threading
import time


def _server(ready, port_holder, stop):
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    port_holder.append(srv.getsockname()[1])
    srv.listen(1)
    ready.set()
    conn, _ = srv.accept()
    conn.setblocking(True)
    while not stop.is_set():
        try:
            conn.recv(4096)
        except Exception:
            break


def _heavy_retry(sock, stop):
    """64 bytes every 1s, unconditionally -- independent of the deadlock,
    much heavier than DJ-041's 2-byte/5s heartbeat."""
    payload = b"x" * 64
    while not stop.is_set():
        try:
            sock.send(payload)
        except Exception:
            break
        time.sleep(1)


def main():
    ready = threading.Event()
    port_holder = []
    stop = threading.Event()
    t = threading.Thread(target=_server, args=(ready, port_holder, stop), daemon=True)
    t.start()
    ready.wait()
    port = port_holder[0]

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", port))

    retry = threading.Thread(target=_heavy_retry, args=(client, stop), daemon=True)
    retry.start()

    lock = threading.Lock()
    lock.acquire()
    lock.acquire()  # genuine self-deadlock, never returns


if __name__ == "__main__":
    main()
