#!/usr/bin/env python3
"""Healthy-arm sweep for DJ-008. Raw rows, no verdicts — the journal cites data."""
import json, os, subprocess, time
OUT="/opt/leon-brain/brain_state/healthy_arm_sweep.jsonl"
def panes():
    o=subprocess.run(["tmux","list-panes","-a","-F","#{session_name}\t#{window_name}"],
                     capture_output=True,text=True).stdout
    return [w for s,w in (l.split("\t") for l in o.splitlines() if "\t" in l) if s=="agents"]
def fgpids(w):
    p=int(subprocess.run(["tmux","display-message","-p","-t",f"agents:{w}","#{pane_pid}"],
                         capture_output=True,text=True).stdout.strip() or 0)
    if not p: return []
    d=open(f"/proc/{p}/stat").read(); tp=int(d[d.rindex(")")+2:].split()[5])
    out=[]
    for e in os.listdir("/proc"):
        if e.isdigit():
            try:
                dd=open(f"/proc/{e}/stat").read()
                if int(dd[dd.rindex(")")+2:].split()[2])==tp: out.append(int(e))
            except Exception: pass
    return out
def counters(pids):
    mf=rss=0
    for p in pids:
        try:
            d=open(f"/proc/{p}/stat").read(); f=d[d.rindex(")")+2:].split()
            mf+=int(f[7])
            rss+=int(open(f"/proc/{p}/statm").read().split()[1])
        except Exception: pass
    return mf,rss
prev={}
end=time.time()+1800
with open(OUT,"a") as fh:
    fh.write(json.dumps({"event":"start","ts":time.time(),"interval_s":5,"duration_s":1800})+"\n")
while time.time()<end:
    for w in panes():
        pids=fgpids(w); mf,rss=counters(pids)
        p=prev.get(w)
        if p:
            row={"ts":time.time(),"window":w,"minflt_delta":mf-p[0],"rss_delta":rss-p[1],
                 "pids":len(pids)}
            with open(OUT,"a") as fh:
                fh.write(json.dumps(row)+"\n"); fh.flush(); os.fsync(fh.fileno())
        prev[w]=(mf,rss)
    time.sleep(5)
