#!/usr/bin/env python3
"""Byte-delta only (CPU-min retired per DJ-040) against the blocked-syscall
archetype: hung arm is fixture_socket_blocked_recv.py, genuinely blocked in
recv() on an ESTABLISHED-but-silent socket -- not the spin-holding-socket
fixture DJ-040 validated against.

Ship rule, reused unchanged from DJ-040 (not a new number): hung <=100
bytes/60s AND healthy >=1024 bytes/60s, zero overlap across 20 trials.
"""
import re
import subprocess
import sys
import time
import json

sys.path.insert(0, "/opt/leon-brain")
from tools.keep_busy_runner import ensure_busy  # noqa: E402

HUNG_PID = sys.argv[1]
HEALTHY_PID = sys.argv[2]
HEALTHY_WINDOW = sys.argv[3]
N_TRIALS = int(sys.argv[4])
WINDOW_S = float(sys.argv[5]) if len(sys.argv) > 5 else 60.0
OUT = sys.argv[6] if len(sys.argv) > 6 else "/tmp/dj040b_results.jsonl"

HUNG_BYTE_CEIL = 100
HEALTHY_BYTE_FLOOR = 1024


def sample_sockets(pid):
    out = subprocess.run(["ss", "-tiep"], capture_output=True, text=True).stdout
    lines = out.splitlines()
    sockets = {}
    i = 0
    while i < len(lines):
        line = lines[i]
        if f"pid={pid}," in line or f"pid={pid})" in line:
            m_state = re.match(r"^(\S+)", line)
            m_ino = re.search(r"ino:(\d+)", line)
            info = lines[i + 1] if i + 1 < len(lines) else ""
            bs = re.search(r"bytes_sent:(\d+)", info)
            br = re.search(r"bytes_received:(\d+)", info)
            total = (int(bs.group(1)) if bs else 0) + (int(br.group(1)) if br else 0)
            if m_ino:
                sockets[m_ino.group(1)] = total
        i += 1
    return sockets


def byte_delta(before, after):
    delta = 0
    for ino, v1 in after.items():
        delta += max(0, v1 - before[ino]) if ino in before else v1
    return delta


idx_holder = [0]
kill = False

for trial in range(1, N_TRIALS + 1):
    reprompted = ensure_busy(HEALTHY_WINDOW, idx_holder)
    if reprompted:
        time.sleep(5)  # let generation actually establish before measuring

    h0 = sample_sockets(HUNG_PID)
    b0 = sample_sockets(HEALTHY_PID)
    time.sleep(WINDOW_S)
    h1 = sample_sockets(HUNG_PID)
    b1 = sample_sockets(HEALTHY_PID)

    hung_delta = byte_delta(h0, h1)
    healthy_delta = byte_delta(b0, b1)
    passes = hung_delta <= HUNG_BYTE_CEIL and healthy_delta >= HEALTHY_BYTE_FLOOR
    if not passes:
        kill = True

    row = {"trial": trial, "reprompted_this_trial": reprompted,
           "hung_delta": hung_delta, "healthy_delta": healthy_delta,
           "passes_rule": passes}
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
    print(json.dumps(row))

print(json.dumps({"FINAL": "NO" if kill else "YES - held across all trials"}))
