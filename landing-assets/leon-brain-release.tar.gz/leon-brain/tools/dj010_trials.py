#!/usr/bin/env python3
"""Per-socket-inode byte-delta tracking PLUS per-trial CPU-minimum, sampled
together in the same 60s window so this doesn't double the wall-clock cost
of a separate run.

Byte-delta ship rule (pre-registered, absolute floor not the original 4x
ratio -- degenerate here since the hung arm is deterministically ~0):
  hung <= 100 bytes/60s AND healthy >= 1024 bytes/60s, zero overlap, 20 trials.

CPU-minimum ship rule (pre-registered separately, different statistic than
DJ-019's already-dead mean comparison): per-trial CPU minimum over a 10s
sub-window (1s samples) -- hung-spinner minimum >= 98% in >=18/20 trials,
healthy-busy minimum < 90% in >=18/20 trials.
"""
import re
import subprocess
import sys
import time
import json

sys.path.insert(0, "/opt/leon-brain")
from tools.keep_busy_runner import ensure_busy  # noqa: E402

HUNG_PID = sys.argv[1]
HEALTHY_PID = sys.argv[2]
HEALTHY_WINDOW = sys.argv[3]
N_TRIALS = int(sys.argv[4])
WINDOW_S = float(sys.argv[5]) if len(sys.argv) > 5 else 60.0
OUT = sys.argv[6] if len(sys.argv) > 6 else "/tmp/dj010_results.jsonl"

HUNG_BYTE_CEIL = 100
HEALTHY_BYTE_FLOOR = 1024
CPU_MIN_HUNG_FLOOR_PCT = 98.0
CPU_MIN_HEALTHY_CEIL_PCT = 90.0
CPU_SUBWINDOW_S = 10


def sample_sockets(pid):
    out = subprocess.run(["ss", "-tiep"], capture_output=True, text=True).stdout
    lines = out.splitlines()
    sockets = {}
    states = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if f"pid={pid}," in line or f"pid={pid})" in line:
            m_state = re.match(r"^(\S+)", line)
            m_ino = re.search(r"ino:(\d+)", line)
            info = lines[i + 1] if i + 1 < len(lines) else ""
            bs = re.search(r"bytes_sent:(\d+)", info)
            br = re.search(r"bytes_received:(\d+)", info)
            total = (int(bs.group(1)) if bs else 0) + (int(br.group(1)) if br else 0)
            if m_ino:
                sockets[m_ino.group(1)] = total
            if m_state:
                states.append(m_state.group(1))
        i += 1
    return sockets, states


def byte_delta(before, after):
    delta = 0
    for ino, v1 in after.items():
        delta += max(0, v1 - before[ino]) if ino in before else v1
    return delta


def cpu_ticks(pid):
    try:
        d = open(f"/proc/{pid}/stat").read()
        f = d[d.rindex(")") + 2:].split()
        return int(f[11]) + int(f[12])
    except Exception:
        return None


def cpu_minimum_pct(pid, seconds):
    """Sample 1s intervals for `seconds`, return the MIN per-second rate as a pct."""
    prev = cpu_ticks(pid)
    rates = []
    for _ in range(seconds):
        time.sleep(1)
        cur = cpu_ticks(pid)
        if prev is not None and cur is not None:
            rates.append(cur - prev)  # ticks in 1s == pct of one core, assuming 100 Hz
        prev = cur
    return min(rates) if rates else None, rates


idx_holder = [0]
byte_kill = False
cpu_hung_pass_count = 0
cpu_healthy_pass_count = 0

for trial in range(1, N_TRIALS + 1):
    reprompted = ensure_busy(HEALTHY_WINDOW, idx_holder)

    # CPU-minimum sub-window first (10s), THEN byte-delta over the remainder
    # of the 60s window so both measurements come from the same trial.
    hung_cpu_min, hung_cpu_series = cpu_minimum_pct(HUNG_PID, CPU_SUBWINDOW_S)
    healthy_cpu_min, healthy_cpu_series = cpu_minimum_pct(HEALTHY_PID, CPU_SUBWINDOW_S)

    h0, hs0 = sample_sockets(HUNG_PID)
    b0, bs0 = sample_sockets(HEALTHY_PID)
    time.sleep(max(0, WINDOW_S - CPU_SUBWINDOW_S))
    h1, hs1 = sample_sockets(HUNG_PID)
    b1, bs1 = sample_sockets(HEALTHY_PID)

    hung_byte_delta = byte_delta(h0, h1)
    healthy_byte_delta = byte_delta(b0, b1)
    byte_passes = hung_byte_delta <= HUNG_BYTE_CEIL and healthy_byte_delta >= HEALTHY_BYTE_FLOOR
    if not byte_passes:
        byte_kill = True

    hung_cpu_pass = hung_cpu_min is not None and hung_cpu_min >= CPU_MIN_HUNG_FLOOR_PCT
    healthy_cpu_pass = healthy_cpu_min is not None and healthy_cpu_min < CPU_MIN_HEALTHY_CEIL_PCT
    if hung_cpu_pass:
        cpu_hung_pass_count += 1
    if healthy_cpu_pass:
        cpu_healthy_pass_count += 1

    row = {
        "trial": trial, "reprompted_this_trial": reprompted,
        "hung_byte_delta": hung_byte_delta, "healthy_byte_delta": healthy_byte_delta,
        "byte_rule_passes": byte_passes,
        "hung_cpu_min_pct": hung_cpu_min, "healthy_cpu_min_pct": healthy_cpu_min,
        "hung_cpu_series": hung_cpu_series, "healthy_cpu_series": healthy_cpu_series,
        "hung_cpu_rule_passes": hung_cpu_pass, "healthy_cpu_rule_passes": healthy_cpu_pass,
    }
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
    print(json.dumps(row))

print(json.dumps({
    "BYTE_FINAL": "NO - overlap/miss occurred" if byte_kill else "YES - held across all trials",
    "CPU_MIN_HUNG": f"{cpu_hung_pass_count}/{N_TRIALS} trials >=98%",
    "CPU_MIN_HEALTHY": f"{cpu_healthy_pass_count}/{N_TRIALS} trials <90%",
    "CPU_MIN_FINAL": "YES" if cpu_hung_pass_count >= 18 and cpu_healthy_pass_count >= 18 else "NO",
}))
