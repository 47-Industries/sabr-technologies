#!/usr/bin/env bash
# REGRESSION GUARD. Dean, 2026-08-17: hovering a node must never print a real
# filename — he demos this on video and so will customers. This asserts the
# tooltip renders the anatomical region and NOT the memory's own label.
set -uo pipefail
P="$(dirname "$0")/../dashboard/js/brainweb-page.html"
fail=0
check() { if eval "$2"; then echo "  ok   $1"; else echo "  FAIL $1"; fail=1; fi; }

echo "brainweb privacy audit:"
# the tooltip must build from the region map, not the label
check "tooltip uses REGION_LABEL"      "grep -q 'REGION_LABEL\[d.r\]' '$P'"
# d.l (the raw label / filename) must not reach the tooltip or any sprite
check "tooltip does NOT print d.l"     "! grep -q 'tip.innerHTML.*d\.l' '$P'"
check "no live label sprites"          "! grep -qE '^\s*buildLabels\(data' '$P'"
check "sprite builder is disabled"     "grep -q 'function buildLabels() { return; }' '$P'"
# entity ids are machine fingerprints too
check "tooltip does NOT print d.i"     "! grep -q 'tip.innerHTML.*d\.i' '$P'"

# ── DATA LAYER ────────────────────────────────────────────────────────────
# Everything above audits the RENDERER. On 2026-08-17 all five of those passed
# while the payload itself still shipped every label: 2,072 of them, 1,411
# containing a real path, including "secure/install_log_api_key" — in a 1.2MB
# JSON the browser downloads whole and devtools reads in one click. Hiding a
# field in the renderer while still putting it on the wire is a curtain, not
# privacy, and the release tarball would have handed that file to a stranger.
#
# So these checks read the PAYLOAD, not the page. A guard that only audits the
# layer you edited is how the leak survived the fix in the first place.
D="$(dirname "$0")/../dashboard/js/brainweb-data.json"
if [ -f "$D" ]; then
  check "payload carries no label field" \
    "python3 -c \"import json,sys; d=json.load(open('$D')); sys.exit(0 if not any('l' in n for n in d['nodes']) else 1)\""
  check "payload carries no file paths" \
    "! grep -qE '[A-Za-z0-9_-]+/[A-Za-z0-9_-]+\.(py|js|sh|md|json|html|ts)' '$D'"
  check "payload never mentions secure/" \
    "! grep -q 'secure/' '$D'"
  # The fingerprint must survive label removal — it is the layout seed, and if
  # stripping a field reshuffles it, every SI's body silently changes shape.
  check "payload still has a fingerprint" \
    "python3 -c \"import json; d=json.load(open('$D')); assert d.get('fp')\""
else
  echo "  skip payload checks — no brainweb-data.json yet"
fi

exit $fail
