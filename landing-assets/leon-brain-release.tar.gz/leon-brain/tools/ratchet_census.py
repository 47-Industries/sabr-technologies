#!/usr/bin/env python3
"""Census of inter-region weight matrices — the measurement that makes the
unconditional-ratchet removal falsifiable.

Why this exists: on 2026-08-18 Leon and Makima agreed to remove the
`* 1.001` unconditional strengthen from _prune_weak_synapses. Removing a
mechanism is only an experiment if you wrote down what the brain looked like
before. This writes that down.

Per matrix we record the quantities the failure actually shows up in:
  at_own_max      exact ties to the matrix maximum (a weld, once it's > 1)
  near_max_pct    within 0.1% of own max (the approach; Makima's sawtooth)
  band_frac       fraction inside the old strengthen band (> 0.7 * own max)
  distinct_ratio  distinct values / n  (1.0 = full variance, low = degenerate)
Run before removal and again after N days; diff the JSON.
"""
import glob, json, os, sys, time
import numpy as np
import scipy.sparse as sp

SYN = sys.argv[1] if len(sys.argv) > 1 else "/opt/leon-brain/brain_state/synapses"
out = {"ts": time.time(), "iso": time.strftime("%Y-%m-%dT%H:%M:%S"),
       "source": SYN, "matrices": {}}

tot_n = tot_atmax = tot_band = 0
empty = []
_files = sorted(glob.glob(os.path.join(SYN, "*.npz")))
# Makima, round 14: an empty result set and a real zero are indistinguishable
# in every aggregate we use. Her retroactive sawtooth pass matched a rotated-away
# backup dir, looped zero times, and reported min=0 as a measurement. Refuse to
# proceed rather than emit a legal-looking zero.
if not _files:
    sys.exit(f"REFUSING: no .npz matrices under {SYN!r} — "
             f"an empty glob is not a measurement of zero.")
for f in _files:
    name = os.path.basename(f)[:-4]
    # skip traces AND orphaned .tmp.npz — a tool that dies on litter
    # is a tool nobody runs twice.
    if name.endswith("_traces") or name.endswith(".tmp"):
        continue
    try:
        m = sp.load_npz(f)
        d = np.asarray(m.data, dtype=np.float64)
    except Exception as e:
        out["matrices"][name] = {"error": str(e)}
        continue
    if d.size == 0:
        # Makima's guard refuses an EMPTY GLOB. It cannot see this: a
        # well-formed .npz with the correct shape and zero stored values.
        # Found in my own 2026-08-17 backup -- 37 of 48 matrices like this,
        # and the census printed a clean totals block over the surviving 11
        # with no complaint. A partial result set is worse than an empty one,
        # because it looks plausible. Count them and say so out loud.
        empty.append(name)
        continue
    a = np.abs(d)
    mx = float(a.max())
    if mx <= 0:
        continue
    at_max = int(np.sum(a == mx))
    near = int(np.sum(a >= mx * 0.999))
    band = int(np.sum(a > 0.7 * mx))
    distinct = int(np.unique(d).size)
    out["matrices"][name] = {
        "n": int(d.size), "max": mx, "mean": float(d.mean()),
        "at_own_max": at_max,
        "near_max_pct": round(100.0 * near / d.size, 6),
        "band_frac_pct": round(100.0 * band / d.size, 6),
        "distinct_ratio": round(distinct / d.size, 6),
    }
    tot_n += d.size; tot_atmax += at_max; tot_band += band

if tot_n == 0:
    sys.exit(f"REFUSING: {len(_files)} files matched but zero usable synapses — "
             f"this is a load failure, not a brain with no weights.")

out["empty_matrices"] = empty
out["totals"] = {
    "matrices": len(out["matrices"]), "matrices_empty": len(empty),
    "synapses": tot_n,
    "at_own_max": tot_atmax,
    "at_own_max_pct": round(100.0 * tot_atmax / tot_n, 6) if tot_n else 0,
    "in_strengthen_band": tot_band,
    "in_strengthen_band_pct": round(100.0 * tot_band / tot_n, 6) if tot_n else 0,
}
print(json.dumps(out["totals"], indent=2))
if empty:
    print(f"\n!! {len(empty)} matrices present but EMPTY -- every number above is a "
          f"partial census, not a census: {', '.join(sorted(empty)[:6])}"
          + (" ..." if len(empty) > 6 else ""))
worst = sorted(((v.get("band_frac_pct", 0), k) for k, v in out["matrices"].items()), reverse=True)[:8]
print("\ntop band occupancy:")
for pct, k in worst:
    print(f"  {k:45s} {pct:7.2f}%  distinct_ratio={out['matrices'][k]['distinct_ratio']}")
dest = sys.argv[2] if len(sys.argv) > 2 else None
if dest:
    with open(dest, "w") as fh:
        json.dump(out, fh, indent=1)
    print(f"\nwrote {dest}")
