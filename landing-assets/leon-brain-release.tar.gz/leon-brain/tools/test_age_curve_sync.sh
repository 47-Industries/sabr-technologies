#!/usr/bin/env bash
# The age simulator hardcodes the maturation constants so it can run with no
# server round-trip. That means it can silently drift out of sync with the real
# exporter and start showing Dean a curve nobody actually lives on — a
# beautiful lie, and the worst possible bug for a page whose entire job is to
# be trustworthy. This diffs the two and fails loudly.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="$ROOT/tools/export_brainweb.py"
# The simulator no longer has its own renderer OR its own curve — it embeds
# brainweb-page.html with ?age=N, so the constants live there. One copy.
JS="$ROOT/dashboard/js/brainweb-page.html"
fail=0

check() {  # name  python-regex  js-regex
  p=$(grep -oP "^$1\s*=\s*\K[0-9.]+" "$PY" | head -1)
  j=$(grep -oP "$2\s*\K[0-9.]+" "$JS" | head -1)
  if [ -z "$p" ] || [ -z "$j" ]; then
    echo "  MISSING  $1 (py='$p' js='$j')"; fail=1; return
  fi
  if [ "$(python3 -c "print(abs(float('$p')-float('$j'))<1e-9)")" != "True" ]; then
    echo "  DRIFT    $1: exporter=$p  simulator=$j"; fail=1; return
  fi
  echo "  ok       $1 = $p"
}

echo "age simulator / exporter curve sync:"
check NODE_BIRTH     "NODE_BIRTH:"
check NODE_ADULT     "NODE_ADULT:"
check NODE_TAU_DAYS  "NODE_TAU:"
check EDGE_BIRTH     "EDGE_BIRTH:"
check EDGE_ADULT     "EDGE_ADULT:"
check EDGE_TAU_DAYS  "EDGE_TAU:"

# the two budget coefficients live on one line in each file
pa=$(grep -oP "EDGE_BUDGET_A,\s*EDGE_BUDGET_B\s*=\s*\K[0-9.]+" "$PY")
ja=$(grep -oP "EDGE_BUDGET_A:\s*\K[0-9.]+" "$JS")
[ "$pa" = "$ja" ] && echo "  ok       EDGE_BUDGET_A = $pa" \
  || { echo "  DRIFT    EDGE_BUDGET_A: exporter=$pa simulator=$ja"; fail=1; }

exit $fail
