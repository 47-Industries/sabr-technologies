#!/usr/bin/env python3
"""Stuck-but-dribbling specimen vs the same healthy arm, 30s windows,
read-only sampling (safe to run alongside the other batch already reading
the same healthy PID)."""
import re
import subprocess
import sys
import time
import json

DRIBBLE_PID = sys.argv[1]
HEALTHY_PID = sys.argv[2]
N_TRIALS = int(sys.argv[3])
WINDOW_S = float(sys.argv[4]) if len(sys.argv) > 4 else 30.0
OUT = sys.argv[5] if len(sys.argv) > 5 else "/tmp/dribble_results.jsonl"


def sample(pid):
    out = subprocess.run(["ss", "-tiep"], capture_output=True, text=True).stdout
    lines = out.splitlines()
    sockets = {}
    i = 0
    while i < len(lines):
        if f"pid={pid}," in lines[i] or f"pid={pid})" in lines[i]:
            m_ino = re.search(r"ino:(\d+)", lines[i])
            info = lines[i + 1] if i + 1 < len(lines) else ""
            bs = re.search(r"bytes_sent:(\d+)", info)
            br = re.search(r"bytes_received:(\d+)", info)
            total = (int(bs.group(1)) if bs else 0) + (int(br.group(1)) if br else 0)
            if m_ino:
                sockets[m_ino.group(1)] = total
        i += 1
    return sockets


def delta(before, after):
    d = 0
    for ino, v1 in after.items():
        d += max(0, v1 - before[ino]) if ino in before else v1
    return d


for trial in range(1, N_TRIALS + 1):
    d0 = sample(DRIBBLE_PID)
    h0 = sample(HEALTHY_PID)
    time.sleep(WINDOW_S)
    d1 = sample(DRIBBLE_PID)
    h1 = sample(HEALTHY_PID)
    row = {"trial": trial, "dribble_delta": delta(d0, d1), "healthy_delta": delta(h0, h1)}
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
    print(json.dumps(row))
