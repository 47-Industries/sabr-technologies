#!/usr/bin/env bash
# retry_installer_freeze.sh — unattended recovery for the v2026.08.24.1
# installer freeze, written 2026-08-23 by Leon.
#
# WHY THIS EXISTS: the four-OS PyInstaller build on tag v2026.08.23.1 (run
# 32682974966) built every binary green and then died at upload-artifact:
# "Artifact storage quota has been hit" — 259 stale artifacts across
# phantom47m repos had eaten the account quota. All were purged the same
# night, but GitHub recalculates usage on a 6-12h delay, so the rerun hit
# the same wall. This script retries on a timer until the quota thaws, then
# stages the released binaries into landing/installers/ (what
# /download/installer/<os> actually serves) and disarms itself.
#
# Idempotent, flocked, self-disarming. Safe to run any number of times.
set -euo pipefail

TAG="v2026.08.24.2"
RUN_ID="32703999550"
REPO="phantom47m/leon-brain-vps"
ROOT="/opt/leon-brain"
DEST="$ROOT/landing/installers"
MARKER="$DEST/.staged-$TAG"
STATE="/tmp/retry_installer_freeze.attempts"
LOG="$ROOT/brain_state/installer-freeze-retry.log"
say() { echo "[$(date '+%F %T')] $*" | tee -a "$LOG"; }

disarm() {
  systemctl disable --now leon-installer-freeze-retry.timer >/dev/null 2>&1 || true
  say "disarmed systemd timer"
}

exec 9>/tmp/retry_installer_freeze.lock
flock -n 9 || exit 0

if [ -f "$MARKER" ]; then disarm; exit 0; fi

status=$(gh run view "$RUN_ID" --repo "$REPO" --json status,conclusion \
           --jq '"\(.status)/\(.conclusion // "none")"' 2>/dev/null || echo "unknown")
say "run $RUN_ID status: $status"

case "$status" in
  in_progress/*|queued/*|requested/*|waiting/*)
    exit 0 ;;
  completed/success)
    ;;  # fall through to staging
  completed/*)
    n=$(cat "$STATE" 2>/dev/null || echo 0)
    if [ "$n" -ge 8 ]; then
      say "GIVING UP after $n reruns — needs human eyes. Leaving cron armed off."
      disarm; exit 1
    fi
    echo $((n + 1)) > "$STATE"
    say "rerunning failed jobs (attempt $((n + 1)))"
    gh run rerun "$RUN_ID" --repo "$REPO" --failed 2>>"$LOG" || true
    exit 0 ;;
  *)
    say "cannot read run status — leaving armed"; exit 0 ;;
esac

# ── run succeeded: stage the release assets ─────────────────────────
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
say "downloading release $TAG assets"
gh release download "$TAG" --repo "$REPO" --dir "$tmp" 2>>"$LOG"

# integrity: right magic bytes, sane sizes, all four present — a truncated
# or wrong-type file must never land in the serve directory.
check() { # file, min_MB, magic_regex
  local f="$tmp/$1" mb magic
  [ -f "$f" ] || { say "MISSING asset $1"; exit 1; }
  mb=$(( $(stat -c %s "$f") / 1048576 ))
  [ "$mb" -ge "$2" ] || { say "asset $1 too small (${mb}MB)"; exit 1; }
  magic=$(head -c 4 "$f" | od -An -tx1 | tr -d ' \n')
  echo "$magic" | grep -qE "$3" || { say "asset $1 bad magic $magic"; exit 1; }
}
check "sabr-installer"             15 '^7f454c46'  # ELF
check "SabrInstaller.exe"           8 '^4d5a'      # MZ
check "SabrInstaller-macos.zip"     8 '^504b'      # PK
check "SabrInstaller-macos-intel.zip" 8 '^504b'    # PK

for pair in "sabr-installer:sabr-installer-linux" \
            "SabrInstaller.exe:SabrInstaller.exe" \
            "SabrInstaller-macos.zip:SabrInstaller-macos.zip" \
            "SabrInstaller-macos-intel.zip:SabrInstaller-macos-intel.zip"; do
  src="${pair%%:*}"; dst="${pair##*:}"
  [ -f "$DEST/$dst" ] && cp -f "$DEST/$dst" "$DEST/$dst.pre-$TAG.bak"
  install -m 0644 "$tmp/$src" "$DEST/$dst.tmp" && mv -f "$DEST/$dst.tmp" "$DEST/$dst"
  say "staged $dst ($(stat -c %s "$DEST/$dst") bytes)"
done

# verify at the layer the customer experiences: live endpoint must serve the
# staged bytes (linux is the cheap end-to-end probe; all three share a route).
live=$(curl -s "https://sabrtechnologies.com/download/installer/linux" | sha256sum | cut -d' ' -f1)
local_sha=$(sha256sum "$DEST/sabr-installer-linux" | cut -d' ' -f1)
if [ "$live" = "$local_sha" ]; then
  say "LIVE VERIFIED: /download/installer/linux serves the $TAG build"
else
  say "WARNING: live endpoint hash ($live) != staged ($local_sha) — check the serve path"
fi

touch "$MARKER"
say "DONE — $TAG binaries staged and live. Disarming."
disarm
