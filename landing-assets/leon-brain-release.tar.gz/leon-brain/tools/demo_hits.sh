#!/usr/bin/env bash
# Who opened their mockup? Reads Caddy's JSON access log out of journald.
SINCE="${1:-24 hours ago}"
journalctl -u caddy --since "$SINCE" --no-pager -o cat 2>/dev/null \
| grep '"uri":"/demo' \
| python3 -c '
import sys,json,collections
c=collections.Counter(); ips=collections.defaultdict(set)
for line in sys.stdin:
    i=line.find("{")
    if i<0: continue
    try: d=json.loads(line[i:])
    except Exception: continue
    r=d.get("request",{}); u=r.get("uri","")
    if not u.startswith("/demo"): continue
    c[u]+=1; ips[u].add(r.get("remote_ip",""))
if not c: print("No demo page views yet."); raise SystemExit
print(f"{sum(c.values())} views across {len(c)} pages\n")
for u,n in c.most_common(40):
    print(f"{n:4}  {len(ips[u])} uniq  {u}")
'
