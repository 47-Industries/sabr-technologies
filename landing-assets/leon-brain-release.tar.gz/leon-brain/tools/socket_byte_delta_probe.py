#!/usr/bin/env python3
"""DJ-010 rx+tx socket byte-delta probe.

For a given PID, sums bytes_sent + bytes_received across every socket
`ss -tiep` attributes to that process, at trial start and trial end.
Also records socket state, per DJ-010's mandatory guard: void any trial
where the hung arm's socket leaves ESTABLISHED.
"""
import re
import subprocess
import sys
import time

PID = sys.argv[1]
WINDOW_S = float(sys.argv[2]) if len(sys.argv) > 2 else 60.0


def sample(pid):
    out = subprocess.run(["ss", "-tiep"], capture_output=True, text=True).stdout
    lines = out.splitlines()
    total_bytes = 0
    state = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if f"pid={pid}," in line or f"pid={pid})" in line:
            m = re.match(r"^(\S+)", line)
            st = m.group(1) if m else None
            info = lines[i + 1] if i + 1 < len(lines) else ""
            bs = re.search(r"bytes_sent:(\d+)", info)
            br = re.search(r"bytes_received:(\d+)", info)
            total_bytes += int(bs.group(1)) if bs else 0
            total_bytes += int(br.group(1)) if br else 0
            state = st if state is None else state
        i += 1
    return total_bytes, state


t0, s0 = sample(PID)
time.sleep(WINDOW_S)
t1, s1 = sample(PID)
delta = t1 - t0
print(f"delta={delta} state_start={s0} state_end={s1}")
