import hashlib
import json
import math
import random
import re


def sieve_chunk(lo, hi):
    primes = []
    for n in range(lo, hi):
        if n < 2:
            continue
        is_p = True
        for i in range(2, int(math.isqrt(n)) + 1):
            if n % i == 0:
                is_p = False
                break
        if is_p:
            primes.append(n)
    return primes


def hash_round(data, rounds):
    h = data
    for _ in range(rounds):
        h = hashlib.sha256(h).digest()
    return h


def sort_and_scan(items):
    items = sorted(items)
    total = 0
    for i, v in enumerate(items):
        total += v * (i + 1)
    return total


def regex_pass(text):
    return len(re.findall(r"[aeiou]+", text))


def json_roundtrip(obj):
    return json.loads(json.dumps(obj))


def matrix_multiply(a, b):
    n = len(a)
    result = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            s = 0
            for k in range(n):
                s += a[i][k] * b[k][j]
            result[i][j] = s
    return result


def string_build(n):
    parts = []
    for i in range(n):
        parts.append(str(i * i))
    return "-".join(parts)


def dict_churn(n):
    d = {}
    for i in range(n):
        d[f"key{i}"] = i * i
    total = sum(d.values())
    return total


def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a


def recursive_depth(n):
    if n <= 0:
        return 0
    return 1 + recursive_depth(n - 1)


def main():
    rng = random.Random(1234)
    lo = 2
    matrix = [[rng.randint(1, 9) for _ in range(8)] for _ in range(8)]
    matrix2 = [[rng.randint(1, 9) for _ in range(8)] for _ in range(8)]
    seed = b"start"
    text = "the quick brown fox jumps over the lazy dog " * 20
    counter = 0
    while True:
        step = counter % 9
        if step == 0:
            sieve_chunk(lo, lo + 500)
            lo += 500
        elif step == 1:
            seed = hash_round(seed, 30)
        elif step == 2:
            sort_and_scan([rng.randint(0, 100000) for _ in range(400)])
        elif step == 3:
            regex_pass(text)
        elif step == 4:
            json_roundtrip({"a": list(range(50)), "b": text})
        elif step == 5:
            matrix_multiply(matrix, matrix2)
        elif step == 6:
            string_build(300)
        elif step == 7:
            dict_churn(300)
        elif step == 8:
            fib(2000)
            recursive_depth(200)
        counter += 1


if __name__ == "__main__":
    main()
