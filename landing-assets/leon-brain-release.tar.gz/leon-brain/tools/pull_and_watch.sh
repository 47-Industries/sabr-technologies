#!/usr/bin/env bash
# Pull whatever Dean dropped in SHOW-LEON-VIDEO and look at it.
set -uo pipefail
REMOTE='C:/Users/Mr. Sabr/Desktop/SHOW-LEON-VIDEO'
STAGE=/opt/leon-brain/leon-out/watch/_inbox
mkdir -p "$STAGE"
LIST=$(ssh "mr. sabr"@desktop-htdf1jb 'dir /b "C:\Users\Mr. Sabr\Desktop\SHOW-LEON-VIDEO"' 2>/dev/null | tr -d '\r' | grep -iE '\.(mp4|mov|webm|mkv|m4v|avi)$')
[ -z "$LIST" ] && { echo "nothing to watch in SHOW-LEON-VIDEO"; exit 1; }
echo "$LIST" | while read -r f; do
  [ -z "$f" ] && continue
  echo "pulling: $f"
  ssh "mr. sabr"@desktop-htdf1jb "copy /Y \"C:\\Users\\Mr. Sabr\\Desktop\\SHOW-LEON-VIDEO\\$f\" C:\\Windows\\Temp\\watchme" >/dev/null 2>&1
  scp -q -O "mr. sabr"@desktop-htdf1jb:/C:/Windows/Temp/watchme "$STAGE/$f" 2>/dev/null
  ssh "mr. sabr"@desktop-htdf1jb 'del /Q C:\Windows\Temp\watchme' >/dev/null 2>&1
  [ -s "$STAGE/$f" ] && bash /opt/leon-brain/tools/watch_video.sh "$STAGE/$f" "${1:-24}"
done
