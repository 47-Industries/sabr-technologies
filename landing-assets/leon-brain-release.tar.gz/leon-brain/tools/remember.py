#!/usr/bin/env python3
"""Write a durable memory into Leon's knowledge store.

Exists because the LEARN goal gate requires the knowledge table to GROW to
count a pursuit as progress — but Leon had no tool that writes to it. Read-only
knowledge_search was the only path, so LEARN goals could never advance and the
same task got handed back forever (observed 2026-08-10: three identical
reminder-tool tests in 20 minutes).

Usage:  python3 tools/remember.py "what I learned" [--tags a,b] [--source ...]
Prints the new row id. Exit 1 if the row count did not actually increase.
"""
import sys, argparse, sqlite3
sys.path.insert(0, "/opt/leon-brain")
from brain.knowledge_store import KnowledgeStore

p = argparse.ArgumentParser()
p.add_argument("text")
p.add_argument("--tags", default="")
p.add_argument("--source", default="self_learning")
a = p.parse_args()

text = a.text.strip()
if len(text) < 20:
    print("REFUSED: too short to be durable knowledge (min 20 chars)")
    sys.exit(1)

ks = KnowledgeStore()
def count():
    with sqlite3.connect(ks.db_path, timeout=10) as c:
        return int(c.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0])

before = count()
tags = [t.strip() for t in a.tags.split(",") if t.strip()] or None
rid = ks.store(text, source=a.source, tags=tags)
after = count()

if after <= before:
    print(f"FAILED: row count did not grow ({before} -> {after})")
    sys.exit(1)
print(f"remembered id={rid}  knowledge {before} -> {after}")
