"""Capture a pane specimen that the cursor gate can actually adjudicate.

A .txt capture is reader-versus-nothing: `capture-pane` does not serialise
the cursor, so every mismatch row replayed from one carries cursor_x=null
and mechanical_verdict="unknown". Fifty rows of that adjudicate nothing.

So a specimen is now a PAIR — the screen plus the geometry that was true at
the same moment — and this is the only sanctioned way to make one.

ON "ATOMICALLY", SAID PLAINLY: it cannot be. `capture-pane` and
`display-message` are two separate tmux round-trips and there is no tmux
primitive that returns screen and cursor together. Claiming atomicity would
be claiming a guarantee the tool does not offer.

What is achievable is DETECTION, so the race becomes countable instead of
silent: read geometry, read the screen, read geometry again. If the two
geometry reads differ, the screen was captured across a repaint and the
sample is discarded and retried. A specimen that survives is one where
nothing moved on either side of the capture. Same shape as the re-sample
argument for injection: you cannot make read-then-read atomic, so you
verify afterwards and throw away what you cannot vouch for.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

FIELDS = "#{cursor_y}\t#{cursor_x}\t#{pane_in_mode}\t#{pane_pid}\t#{pane_current_command}"


def _tmux(args):
    return subprocess.run(["tmux"] + args, capture_output=True, text=True,
                          timeout=10).stdout


def _geometry(target: str) -> dict:
    out = _tmux(["display-message", "-p", "-t", target, FIELDS]).strip()
    p = out.split("\t")
    if len(p) != 5 or not p[0].isdigit():
        raise RuntimeError(f"unreadable geometry: {out!r}")
    return {"cursor_y": int(p[0]), "cursor_x": int(p[1]),
            "pane_in_mode": p[2] == "1", "pane_pid": int(p[3]) if p[3].isdigit() else None,
            "pane_current_command": p[4]}


def capture(target: str, attempts: int = 8) -> tuple[str, dict]:
    """(screen, geometry) with the geometry verified stable across the read.

    Raises rather than returning a sample it cannot vouch for. A specimen
    that quietly reports a cursor from a different frame than its screen is
    worse than no specimen: it looks like evidence.
    """
    for i in range(attempts):
        before = _geometry(target)
        screen = _tmux(["capture-pane", "-p", "-t", target])   # no -S: rows
        after = _geometry(target)                              # align with cursor_y
        if before == after:
            return screen, after
        time.sleep(0.25)
    raise RuntimeError(f"{target}: geometry never held still across a capture "
                       f"in {attempts} attempts — pane is repainting continuously")


def prompt_prefix_width(screen: str, geo: dict) -> int | None:
    lines = screen.splitlines()
    if geo["cursor_y"] >= len(lines):
        return None
    row = lines[geo["cursor_y"]]
    for i, ch in enumerate(row):
        if ch in "❯>":
            # prefix is the glyph plus one separator cell, if present
            return i + 2 if len(row) > i + 1 else i + 1
    return None


def write(target: str, out_dir: str, name: str, note: str = "") -> dict:
    screen, geo = capture(target)
    prefix = prompt_prefix_width(screen, geo)
    lines = screen.splitlines()
    row = lines[geo["cursor_y"]] if geo["cursor_y"] < len(lines) else None
    meta = {
        "captured_at": time.time(),
        "target": target,
        "name": name,
        "note": note,
        **geo,
        "prompt_prefix_width": prefix,
        "row_at_cursor_y": row,
        # The two claims, recorded separately and never merged. This is the
        # whole point of the format: a specimen states what the SCREEN said
        # and what the CURSOR said, so a replay can adjudicate rather than
        # abstain.
        "painted_text": (row[prefix:].strip() if row and prefix is not None else None),
        "cursor_says_typed_cells": (geo["cursor_x"] - prefix) if prefix is not None else None,
        "geometry_verified_stable": True,
    }
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name + ".txt"), "w") as fh:
        fh.write(screen)
    with open(os.path.join(out_dir, name + ".cursor.json"), "w") as fh:
        json.dump(meta, fh, indent=2)
    return meta


if __name__ == "__main__":
    print(json.dumps(write(sys.argv[1], sys.argv[2], sys.argv[3],
                           sys.argv[4] if len(sys.argv) > 4 else ""), indent=2))
