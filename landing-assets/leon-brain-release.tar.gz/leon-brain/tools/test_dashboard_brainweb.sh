#!/usr/bin/env bash
# Regression guard for the 2026-08-17 "how come your brain didn't change?" bug.
#
# THE BUG: an entire morning of work on the living memory web shipped to a
# STANDALONE page (dashboard/js/brainweb-page.html) while the dashboard Dean
# actually looks at still mounted the old Brain3D point cloud. Every layer I
# checked was green, because I kept checking the layer I edited. Nobody was
# lying; the two things were simply never connected.
#
# So this test asserts at the layer DEAN EXPERIENCES: it pulls the bytes the
# live server hands a browser, not the file on disk. "It's committed" and
# "it's on disk" are not verification.
#
# Usage: bash tools/test_dashboard_brainweb.sh
set -uo pipefail

BASE="${LEON_BASE:-http://127.0.0.1:8000}"
KEY="${LEON_API_KEY:-$(grep -oP '(?<=^LEON_API_KEY=).*' /opt/leon-brain/.env 2>/dev/null | tr -d '"')}"
fail=0
ok()   { echo "  PASS  $1"; }
bad()  { echo "  FAIL  $1"; fail=1; }

INDEX="$(curl -sf "$BASE/?key=$KEY")" || { echo "FAIL: dashboard did not respond at $BASE"; exit 1; }
WEB="$(curl -sf "$BASE/js/brainweb-page.html?key=$KEY")" || { echo "FAIL: brainweb page 404 at $BASE"; exit 1; }

echo "dashboard brainweb wiring — against live bytes from $BASE"

# 1. The dashboard must actually mount the web.
grep -q 'id = .brainweb-frame.\|brainweb-frame' <<<"$INDEX" \
  && ok "dashboard mounts the living memory web" \
  || bad "dashboard does NOT mount brainweb — the old brain is back"

# 2. The old point cloud must NOT be constructed. This is the exact regression:
#    both could coexist in the file and the old one would win the z-order.
grep -q 'new Brain3D(' <<<"$INDEX" \
  && bad "old Brain3D is being constructed again" \
  || ok "old Brain3D point cloud is not constructed"

# 3. The frame must carry a key. Empty key = silent 401 wall = eternal
#    "WEAVING MEMORY" with no visible cause. Worst failure mode there is.
grep -q "brainweb-page.html?key=' *+ *encodeURIComponent" <<<"$INDEX" \
  && ok "frame src carries an auth key" \
  || bad "frame src has no key — the web will hang on 401s"

# 4. The stubs must survive. Six call sites still reach for brain3d/dust from
#    the rAF loop; a throw in there kills the loop silently, not loudly.
for m in initNeurons updateState animate; do
  grep -q "$m" <<<"$INDEX" && ok "brain3d.$m call site still satisfied" \
                           || bad "brain3d.$m stub missing — rAF loop will throw"
done

# 5. The framed page must be the LIVE build, not a stale artifact.
stamp="$(grep -o 'b[0-9]\{3,\}-[a-z]*' <<<"$WEB" | head -1)"
[ -n "$stamp" ] && ok "brainweb build stamp present: $stamp" \
                || bad "brainweb has no build stamp — cannot tell stale from fresh"

# 6. Privacy guard still holds on the page the dashboard now embeds. Delegate
#    to the dedicated test rather than re-implementing a weaker grep here — my
#    first pass at this matched `e.filename` in the boot watchdog (the JS file
#    that threw, not a memory filename) and cried leak on clean code. A loose
#    guard that fires on nothing real gets ignored, which is worse than none.
PRIV=/opt/leon-brain/tools/test_brainweb_privacy.sh
if [ -x "$PRIV" ] || [ -f "$PRIV" ]; then
  if bash "$PRIV" >/dev/null 2>&1; then ok "embedded web passes the privacy guard"
  else bad "embedded web FAILS tools/test_brainweb_privacy.sh — run it for detail"; fi
else
  echo "  SKIP  privacy guard not found at $PRIV"
fi

echo
[ "$fail" -eq 0 ] && echo "ALL PASS — Dean's dashboard is showing the new brain." \
                  || echo "FAILURES ABOVE — the dashboard is not showing what you think it is."
exit "$fail"
