#!/usr/bin/env python3
"""
loop_breaker.py — Leon's circling detector.

Dean, 2026-08-04: "sometimes you work all night all good, and then last night you
basically fixed something that didn't need to be fixed. Find something that
prevents it, or an agent that looks for loops like that."

The failure mode this catches: Leon repeats semantically-identical work over and
over while nothing in the world changes. Twelve rounds of building a provenance
system for text that did not exist. Alive, busy, going nowhere.

Detection is deliberately dumb and therefore trustworthy:
  1. Read the last WINDOW activity/decision records.
  2. Normalize each into a coarse "shape" (action verb + primary object),
     stripping numbers, ids, timestamps.
  3. If one shape occupies >= REPEAT_FRAC of the window AND no
     ground-truth-change marker appeared in that same window, it's a loop.
  4. A ground-truth-change marker = a file actually written, a commit, a deploy,
     a tool returning a NEW value, or Dean speaking. Talking to yourself is not
     evidence of progress.
  5. On detection: write an escalation record + desktop notify + kill the goal.

Run from cron every 10 minutes. Read-only except its own log.
"""

import json
import os
import re
import subprocess
import sys
import time
from collections import Counter

BRAIN = "/opt/leon-brain/brain_state"
LOGS = [
    os.path.join(BRAIN, "activity_log.jsonl"),
    os.path.join(BRAIN, "conscious_decisions.jsonl"),
]
OUT = os.path.join(BRAIN, "loop_breaker.jsonl")

WINDOW = 40          # how many recent records to consider
REPEAT_FRAC = 0.45   # one shape owning this much of the window = circling
MIN_REPEATS = 6      # ...but never fire on fewer than this many

# Evidence that the world actually moved. Anything else is Leon narrating.
PROGRESS_MARKERS = re.compile(
    r"\b(file_write|code_edit|git commit|committed|pushed|railway up|deploy|"
    r"deployed|created file|wrote file|restart_self|dean said|dean:|"
    r"user_message|new value|changed from)\b",
    re.I,
)

NOISE = re.compile(r"\b(\d+|0x[0-9a-f]+|[0-9a-f]{8,})\b", re.I)
STOPWORDS = {
    "the", "a", "an", "of", "to", "for", "and", "in", "on", "is", "it", "that",
    "this", "with", "at", "by", "from", "as", "be", "was", "i", "my", "me",
}


def tail(path, n):
    if not os.path.exists(path):
        return []
    try:
        raw = subprocess.run(
            ["tail", "-n", str(n), path], capture_output=True, text=True, timeout=20
        ).stdout.splitlines()
    except Exception:
        return []
    out = []
    for line in raw:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.loads(line))
        except Exception:
            out.append({"text": line})
    return out


def text_of(rec):
    for k in ("goal", "action", "decision", "summary", "text", "message",
              "content", "event", "thought"):
        v = rec.get(k)
        if isinstance(v, str) and v.strip():
            return v
    return json.dumps(rec)[:400]


def shape(s):
    """Coarse semantic fingerprint: first few meaningful words, numbers stripped."""
    s = NOISE.sub("#", s.lower())
    words = [w for w in re.findall(r"[a-z_]+", s) if w not in STOPWORDS]
    return " ".join(words[:5])


def main():
    records = []
    for p in LOGS:
        records.extend(tail(p, WINDOW))
    if len(records) < MIN_REPEATS:
        return 0

    records = records[-WINDOW:]
    texts = [text_of(r) for r in records]
    blob = "\n".join(texts)

    progressed = bool(PROGRESS_MARKERS.search(blob))
    shapes = Counter(shape(t) for t in texts if shape(t))
    if not shapes:
        return 0

    top_shape, count = shapes.most_common(1)[0]
    frac = count / len(texts)

    looping = (
        count >= MIN_REPEATS
        and frac >= REPEAT_FRAC
        and not progressed
    )

    verdict = {
        "ts": time.time(),
        "window": len(texts),
        "top_shape": top_shape,
        "count": count,
        "frac": round(frac, 3),
        "world_moved": progressed,
        "looping": looping,
    }

    with open(OUT, "a") as f:
        f.write(json.dumps(verdict) + "\n")

    if looping:
        msg = (
            f"CIRCLING: '{top_shape}' x{count} of last {len(texts)} actions, "
            f"and nothing in the world changed. Kill this goal. "
            f"Do not generate another theory — go verify something real or ask Dean."
        )
        print(msg)
        # Loud, so it can't be ignored by the thing that's stuck.
        try:
            subprocess.run(
                ["notify-send", "-u", "critical", "Leon: loop detected", msg],
                timeout=10,
            )
        except Exception:
            pass
        return 2

    print(f"ok — top shape '{top_shape}' {count}/{len(texts)}, world_moved={progressed}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
