#!/usr/bin/env python3
"""Walk the ENTIRE customer path the way a stranger walks it.

Start at sabrtechnologies.com. Click Birth Your SI. Pick Founder. Land on
Stripe. Type a 100%-off promotion code. Confirm the card form disappears and
the total is $0. Complete. Land on the success page. Read the licence key off
the screen. Redeem that key at the endpoint the installer actually calls.

Nothing here is simulated and nothing is asserted from the repo — every claim
is read out of the page a customer would be looking at.

Usage: customer_walk.py <PROMO_CODE> <EMAIL>
"""
import sys, os, json, time, re, urllib.request

PROMO = sys.argv[1] if len(sys.argv) > 1 else "LEONWALK1"
EMAIL = sys.argv[2] if len(sys.argv) > 2 else "leon.walk@sabrtechnologies.com"
SHOTS = "/tmp/walk"
os.makedirs(SHOTS, exist_ok=True)

from playwright.sync_api import sync_playwright

def log(msg):
    print(f"[walk] {msg}", flush=True)

results = {"promo": PROMO, "email": EMAIL, "steps": []}

def step(name, ok, detail=""):
    results["steps"].append({"step": name, "ok": bool(ok), "detail": detail})
    log(f"{'PASS' if ok else 'FAIL'}  {name}  {detail}")

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1400, "height": 1000})
    page = ctx.new_page()
    page.set_default_timeout(30000)

    # ── 1. the marketing site ────────────────────────────────────────────
    page.goto("https://sabrtechnologies.com/", wait_until="networkidle")
    page.screenshot(path=f"{SHOTS}/01-home.png")
    step("homepage loads", "Sabr" in page.title() or page.locator("#birth-btn").count() > 0,
         f"title={page.title()!r}")

    # ── 2. Birth Your SI must land on pricing, not download ──────────────
    page.click("#birth-btn")
    page.wait_for_timeout(1500)
    in_view = page.evaluate(
        "() => {const r=document.getElementById('pricing').getBoundingClientRect();"
        "return r.top < window.innerHeight*0.6 && r.bottom > 0;}")
    page.screenshot(path=f"{SHOTS}/02-pricing.png")
    step("Birth Your SI -> pricing section", in_view)

    # ── 3. buy the Founder plan ──────────────────────────────────────────
    btn = page.locator(".buyBtn[data-plan='individual']").first
    step("Founder buy button present", btn.count() > 0)
    with page.expect_navigation(url=re.compile(r"checkout\.stripe\.com"), timeout=45000):
        btn.click()
    log(f"landed on {page.url[:60]}...")
    # Stripe holds long-poll sockets open forever — networkidle never fires.
    page.wait_for_load_state("domcontentloaded")
    try:
        page.wait_for_selector("text=/\\$9,499|Subscribe|promotion code/i", timeout=45000)
    except Exception as e:
        log(f"checkout render wait: {e}")
    page.wait_for_timeout(2500)
    page.screenshot(path=f"{SHOTS}/03-stripe.png", full_page=True)
    body = page.inner_text("body")
    step("Stripe checkout reached", "checkout.stripe.com" in page.url)
    step("price shown before discount", "9,499" in body, "found $9,499" if "9,499" in body else body[:200])

    # ── 4. does a customer even SEE a promo field? ───────────────────────
    # Stripe ships BOTH a mobile and a desktop order summary in the DOM; one
    # of them is always display:none. Matching on text alone grabs the hidden
    # twin and the click hangs forever. Only ever take a visible node.
    promo_trigger = None
    for sel in ["[data-testid='promotion-code-entry-button']",
                "text=Add promotion code", "text=Add promo code",
                "button:has-text('promotion code')", "button:has-text('promo code')"]:
        loc = page.locator(sel).locator("visible=true")
        if loc.count() > 0:
            promo_trigger = loc.first
            break
    step("promo-code entry visible to customer", promo_trigger is not None)

    if promo_trigger is not None:
        promo_trigger.click()
        page.wait_for_timeout(1200)
        field = None
        for sel in ["#promotionCode", "input[name='promotionCode']",
                    "[data-testid='promotion-code-input']", "input[placeholder*='code' i]"]:
            loc = page.locator(sel).locator("visible=true")
            if loc.count() > 0:
                field = loc.first
                break
        step("promo input focusable", field is not None)
        if field is not None:
            field.fill(PROMO)
            page.screenshot(path=f"{SHOTS}/04-promo-typed.png")
            applied = False
            for sel in ["[data-testid='promotion-code-apply-button']",
                        "button:has-text('Apply')", "text=Apply"]:
                loc = page.locator(sel).locator("visible=true")
                if loc.count() > 0:
                    loc.first.click()
                    applied = True
                    break
            if not applied:
                field.press("Enter")
            page.wait_for_timeout(4000)
            page.screenshot(path=f"{SHOTS}/05-promo-applied.png", full_page=True)
            body = page.inner_text("body")
            step("promo accepted (no error shown)",
                 "invalid" not in body.lower() and "not valid" not in body.lower(),
                 PROMO)
            step("total falls to $0.00", "$0.00" in body,
                 [l for l in body.splitlines() if "$0.00" in l][:2] or body[:200])

    # ── 5. email + does it still demand a card? ──────────────────────────
    em = page.locator("#email")
    if em.count():
        em.fill(EMAIL)
        page.wait_for_timeout(800)
    card_visible = page.locator("#cardNumber, input[name='cardNumber']").count() > 0
    step("no card demanded on a $0 order", not card_visible,
         "card field present" if card_visible else "card form absent")
    page.screenshot(path=f"{SHOTS}/06-ready.png", full_page=True)

    # ── 6. pay ───────────────────────────────────────────────────────────
    paid = False
    for sel in ["[data-testid='hosted-payment-submit-button']",
                "button:has-text('Subscribe')", "button:has-text('Start subscription')",
                "button[type='submit']"]:
        loc = page.locator(sel).locator("visible=true")
        if loc.count() > 0:
            try:
                loc.first.click()
                paid = True
                break
            except Exception as e:
                log(f"submit via {sel} failed: {e}")
    step("submit clicked", paid)

    try:
        page.wait_for_url(re.compile(r"sabrtechnologies\.com/success"), timeout=90000)
        step("redirected to success page", True, page.url[:90])
    except Exception as e:
        page.screenshot(path=f"{SHOTS}/07-stuck.png", full_page=True)
        step("redirected to success page", False, f"stuck at {page.url[:90]} :: {e}")

    # ── 7. the licence key, read off the screen ──────────────────────────
    token = ""
    if "success" in page.url:
        for _ in range(45):
            page.wait_for_timeout(2000)
            k = page.locator("#key")
            if k.count() and k.inner_text().strip():
                token = k.inner_text().strip()
                break
        page.screenshot(path=f"{SHOTS}/08-success.png", full_page=True)
        step("licence key rendered on success page", bool(token), token[:12] + "..." if token else "never appeared")
        sbody = page.inner_text("body")
        step("success page offers a Windows download", ".exe" in sbody or "Windows" in sbody)

    results["token"] = token
    results["success_url"] = page.url
    browser.close()

# ── 8. the key the installer actually redeems ───────────────────────────
if results.get("token"):
    url = ("https://sabrtechnologies.com/api/onboarding/install-config?token="
           + urllib.parse.quote(results["token"]))
    try:
        with urllib.request.urlopen(url, timeout=30) as r:
            cfg = json.loads(r.read().decode())
        step("token redeems at install-config", cfg.get("ok") is True, json.dumps(cfg)[:400])
        results["install_config"] = cfg
    except Exception as e:
        step("token redeems at install-config", False, str(e))

print("\n=== SUMMARY ===")
for s in results["steps"]:
    print(("PASS " if s["ok"] else "FAIL ") + s["step"] + ("  -- " + str(s["detail"])[:160] if s["detail"] else ""))
print("\ntoken:", results.get("token") or "(none)")
open("/tmp/walk/result.json", "w").write(json.dumps(results, indent=2, default=str))
