# Gio / Jarvis — Clean Rebirth Handoff
Status as of 2026-06-25 ~22:19. Resume when Dean says Gio is back.

## The problem Gio hit
Gio ran the installer. Symptoms:
1. Integrations panel showed only a search bar, NO app list/grid.
2. His SI still called itself "Leon" and carried Leon's goals (identity bleed).
3. ElevenLabs ("11 laps") key did not work off the rip / at all.
4. Wake word by the SI's name did not respond.

## Root cause (diagnosed in code)
- TWO disconnected onboarding systems:
  - TERMINAL installer (install_client.py): writes a real .env (LEON_SI_NAME,
    ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID, LEON_TTS_PREFER=elevenlabs,
    ANTHROPIC_API_KEY, LEON_USER_NAME) + lays down an EMPTY fresh brain_state.
    run.py loads .env into os.environ. This path is CORRECT.
  - WEB onboarding wizard (server/onboarding_routes.py): saves name + ENCRYPTED
    ElevenLabs key + voice id into TENANT METADATA only. Never writes .env or
    os.environ. The running brain reads identity (LEON_SI_NAME) and TTS key
    (ELEVENLABS_API_KEY) straight from the ENVIRONMENT -> so wizard-saved name
    and keys are orphaned. THIS is the deeper bug.
- FOOT-GUN in terminal installer: line 355 `ask("SI name", default="Leon")`.
  If the user pressed Enter, the SI was literally born named "Leon" -> persona,
  wake word, identity all inherit "Leon". Most likely what happened to Gio.
- Identity/name plumbing itself is fine: brain/identity.py si_name() reads
  LEON_SI_NAME (defaults "Leon" only on original). wake_word_vosk.py line ~204
  defaults wake phrase to the SI's own name from LEON_SI_NAME. Both correct IF
  the env var is set.

## FIX ALREADY MADE (this session)
- install_client.py setup_wizard(): removed the "Leon" default. Now loops until
  the user enters a NON-EMPTY name and REFUSES "leon" (case-insensitive).
  => future terminal installs can no longer be accidentally born as Leon.

## STILL TO DO (next session, with Dean)
1. Web onboarding wizard rewrite: make it write the real .env (name + keys) via
   _upsert_env (from server/routers/voice_routes.py, used by integrations panel)
   so wizard installs birth correctly too. BIGGER job — do deliberately.
2. Integrations panel empty on Gio's box: catalog code (/api/integrations/catalog
   in server/routers/integrations_routes.py) is FINE on our end. Need a log /
   browser console from HIS machine to diagnose (fetch failing or stale build).
3. Rebuild release tarball to ship the name-default fix — DEAN-SUPERVISED ONLY,
   wait for Dean's explicit go.

## Gio's clean rebirth procedure (run on his Mac, in the leon-brain folder)
1. Stop the brain.
2. rm -rf brain_state      (wipes inherited Leon memories/goals)
3. mv .env .env.old        (clear old identity/keys)
4. Re-run the installer. When prompted: name = Jarvis; paste his ElevenLabs key
   at the voice step; paste his Claude key. Pick neuron size.
=> True blank-slate Jarvis: own name, zero memories, voice working off the rip.

## Other open threads
- sabrtechnologies.com: root live on Railway; www CNAME -> tmq47fpj.up.railway.app
  saved at Namecheap (confirmed on registrar NS). Waiting on propagation + Railway
  SSL cert issuance for https://www. Recheck and confirm green.
- Joe (iUSEJOE): Dean about to relay Joe's text re: app updates + a TestFlight
  push. Start that next.

---
# Integrity Network — Joe's lifecycle requirement (2026-06-25 22:21)
Joe's point: IN is NOT just lead-gen (homeowner -> contractor match). The
platform must own the ENTIRE project lifecycle:
- maintain all project-related data
- track progress through each phase (Phase 1, Phase 2, ...)
- release payments on predefined milestones / completed deliverables
- keep the client informed: notify on phase transitions, show overall status
Joe doesn't see PM/workflow capability in the current design; asks if it's a
later phase. Wants alignment on long-term vision.

## Our answer / mapping (it IS planned, lives in existing milestones)
- This is the milestone + escrow backbone, not a bolt-on:
  - M5 escrow adapter = milestone-gated payment release (the money engine).
  - M6 change-order recompute = lifecycle changes mid-project.
  - The PHASE TRACKER + client notifications layer sits ON TOP of M5/M6:
    a project state machine (phases/deliverables) that triggers (a) payment
    release on milestone completion and (b) client status notifications.
- Action: add an explicit milestone to the IN roadmap — call it
  M8 "Project Lifecycle / Workflow Engine": project state machine, phase
  model, deliverable tracking, milestone->payment hooks, client status feed +
  notifications. Confirm to Joe it's a deliberate phase, not missing.
- Needs IN backend repo read access to wire phases to the fee/escrow engine.

---
# Integrity Network — Lifecycle Engine BUILD (2026-06-25 22:30)
Repo cloned: /opt/leon-brain/workspaces/integrity-network (monorepo).
Backend = apps/api (TS/Express/Prisma/Postgres). Mobile = apps/mobile = FLUTTER (Dart).
TestFlight pipeline = codemagic.yaml -> App Store Connect "Integrity Network"
(builds + signs iOS on Codemagic CI, NOT on this Linux VPS; triggered by git push).

## DONE (typechecks clean, tsc --noEmit rc=0, prisma generate ok) — NOT pushed:
- prisma/schema.prisma: + ProjectExecution, ProjectPhase, ProjectDeliverable,
  PhaseEvent + enums ProjectExecStatus, PhaseStatus. Additive only.
- prisma/migrations/20260625_add_project_lifecycle/migration.sql (hand-written, additive).
- src/services/projectLifecycleService.ts — create lifecycle from contract,
  phases+deliverables, setDeliverable, transitionPhase (on complete -> release
  linked ScheduledPayment + write NotificationLog client ping + stamp), auto-complete.
- src/routes/projects.ts — POST /api/projects, GET /:id, GET /by-contract/:cid,
  PATCH /deliverables/:id, PATCH /phases/:id/transition. auth + admin/coordinator.
- src/index.ts — mounted app.use("/api/projects", projectRoutes).

## NOT done yet:
- Flutter UI (apps/mobile/lib): homeowner project-status screen (phases, deliverables,
  live status, payment-released badge) + coordinator phase controls. This is what
  makes the feature VISIBLE in the app / TestFlight.
- Apply migration to Joe's prod DB (deploy step).
- Push -> Codemagic -> TestFlight (needs Dean: it's a client release; runs on his
  Apple/App Store Connect creds via Codemagic).

## Decision pending: meaningful TestFlight "with everything" needs the Flutter
## screens first. Backend is ready and green underneath them.

---
# IN Lifecycle — pushed to branch (2026-06-25 22:55)
Branch: feat/project-lifecycle (pushed to origin). PR link:
https://github.com/47-Industries/integrity-network/pull/new/feat/project-lifecycle
Validated: backend tsc --noEmit clean; flutter analyze clean on all new files
(10 remaining analyzer notes are pre-existing, not ours).

## Built + pushed (8 files):
backend models+migration+service+routes+wiring; mobile api methods +
ProjectStatusScreen (homeowner) + ProjectManageScreen (contractor/coordinator).

## BEFORE a meaningful TestFlight (remaining):
1. NAV WIRING — add entry points so screens are reachable:
   - homeowner: button in client_dashboard -> ProjectStatusScreen(contractId/execId)
   - contractor/admin: entry -> ProjectManageScreen(executionId)
   (screens exist + analyze clean; just not linked into navigation yet)
2. MERGE feat/project-lifecycle -> main. NOTE: pushing main auto-deploys the API
   on Railway and runs `prisma migrate deploy` against Joe's PROD DB. Deliberate step.
3. TESTFLIGHT: Codemagic has TWO workflows — ios-testflight (homeowner app id
   6761015745) + ios-testflight-pro (pro app id 6761085133), both submit_to_testflight.
   No auto branch-trigger seen -> likely started manually in Codemagic UI (or via
   Codemagic API token, which we don't have). Building covers BOTH apps.

## git push works from Leon's shell (gh phantom47m) — branch push done autonomously.
