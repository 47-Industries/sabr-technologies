# Sabr Checkout + Auto-Provision

Stranger pays -> Stripe webhook fires -> we mint their install token, build their
one-line install command, and email it. No human in the loop.

## Files
- app.py        FastAPI: /health, /create-checkout, /webhook
- provision.py  mints token, builds install cmd, emails buyer
- Dockerfile    Railway-ready (uvicorn)

## To go LIVE, Dean provides (env vars):
1. STRIPE_SECRET_KEY      (Stripe account -> API keys)
2. PRICE_BUILD            (Stripe product: $12,000 one-time)
3. PRICE_MONTHLY          (Stripe product: $2,000 / month)
4. STRIPE_WEBHOOK_SECRET  (Stripe -> webhooks -> point at /webhook)
5. EMAIL_API_KEY          (Resend or SendGrid, to actually send the link)

## Entitlement env (live since 2026-07-29):
- LEASE_SIGNING_KEY         signs the "entitled through <date>" lease
- ENTITLEMENT_STORE         path to tenants.json — MUST live on the mounted
                            volume (/data/tenants.json), never in the code
                            dir, or every deploy makes every tenant unknown
- GRACE_DAYS (14), ENTITLEMENT_STALE_DAYS (3), ENTITLEMENT_DAILY_CEILING (2000)

## INSTALLER SPEC — the lease key, stated so nobody builds on it wrong:
The install ships SABR_LEASE_VERIFY_KEY, the SAME secret as the server's
LEASE_SIGNING_KEY (HMAC is symmetric). This is safe ONLY because the lease is
narration, not auth: it gates nothing, and a forged or leaked key buys nicer
fake error messages and zero cognition. THE LEASE IS NOT AN AUTH TOKEN.
Never authenticate anything against it; entitlement is enforced at the
gateway by the tenant token, full stop.

## Then Leon does:
- railway up this folder as a new service
- point "Or start instantly" on the site -> POST /create-checkout
- add the Stripe webhook URL -> /webhook
Until creds exist, /create-checkout returns a clean "not configured" message
instead of faking a sale.
