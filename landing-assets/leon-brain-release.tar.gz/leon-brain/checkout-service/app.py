"""
Sabr checkout service — takes the money, then auto-provisions.

Routes:
  GET  /health           -> liveness
  POST /create-checkout  -> {email?, coupon?} -> Stripe Checkout URL ($12k build + $2k/mo)
                            no coupon: checkout page offers a promo-code field;
                            coupon id given: that discount is pre-applied
  POST /webhook          -> Stripe calls this; on payment success we provision + email

Go-live needs (env): STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET,
PRICE_BUILD (one-time $12k price id), PRICE_MONTHLY ($2k/mo price id),
plus EMAIL_API_KEY for provision.py. Until those are set, /create-checkout
returns a clear 'not configured' message instead of pretending.
"""
import os, json
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from provision import mint_install, send_install_email, build_install_cmd
import entitlement

app = FastAPI(title="Sabr Checkout")

# The landing site is a static page on a different host, so the buy button
# calls us cross-origin. Lock CORS to our own domains (override via env).
ALLOWED_ORIGINS = [o.strip() for o in os.environ.get(
    "ALLOWED_ORIGINS",
    "https://sabrtechnologies.com,https://www.sabrtechnologies.com,"
    "https://sabr-technologies-production.up.railway.app",
).split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

SECRET = os.environ.get("STRIPE_SECRET_KEY")
WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET")
PRICE_BUILD = os.environ.get("PRICE_BUILD")      # legacy one-time (kept for existing links)
PRICE_MONTHLY = os.environ.get("PRICE_MONTHLY")  # legacy recurring

# Tiered catalogue. A plan is (one-time price or None, recurring price).
# The page sells this tier as FOUNDER — same tier the env vars historically
# called PRICE_INDIV_* ("individual"). Canonical name is now `founder`
# everywhere in code; the INDIV env names are read as fallback so a deploy
# works no matter which set Railway carries. Founder has no deployment fee —
# it installs itself. Business carries a real deployment because a human
# does onboarding. Enterprise never reaches checkout; it's a conversation.
PLANS = {
    ("founder",  "month"): (None, os.environ.get("PRICE_FOUNDER_MONTHLY") or os.environ.get("PRICE_INDIV_MONTHLY")),
    ("founder",  "year"):  (None, os.environ.get("PRICE_FOUNDER_ANNUAL") or os.environ.get("PRICE_INDIV_ANNUAL")),
    ("business", "month"): (os.environ.get("PRICE_BIZ_SETUP"), os.environ.get("PRICE_BIZ_MONTHLY")),
    ("business", "year"):  (os.environ.get("PRICE_BIZ_SETUP"), os.environ.get("PRICE_BIZ_ANNUAL")),
}

# Requests may still say "individual" (older page JS, old links). Alias, not
# a second tier — it resolves to founder and never appears in /health.
PLAN_ALIASES = {"individual": "founder"}

def _resolve(plan, interval):
    """Pick line items for a plan, falling back to the legacy pair."""
    plan_name = (plan or "business").lower()
    plan_name = PLAN_ALIASES.get(plan_name, plan_name)
    key = (plan_name, (interval or "month").lower())
    if key in PLANS:
        setup, rec = PLANS[key]
        if rec:
            items = []
            if setup:
                items.append({"price": setup, "quantity": 1})
            items.append({"price": rec, "quantity": 1})
            return items
    if PRICE_BUILD and PRICE_MONTHLY:
        return [{"price": PRICE_BUILD, "quantity": 1},
                {"price": PRICE_MONTHLY, "quantity": 1}]
    return None
# {CHECKOUT_SESSION_ID} is substituted by Stripe on redirect. Without it the
# success page has no way to ask who just paid, which is exactly why the
# first real customer landed on the homepage and saw nothing happen.
SUCCESS_URL = os.environ.get(
    "SUCCESS_URL",
    # A dedicated static page, not the marketing homepage. Delivery on the
    # homepage shared a DOM with a WebGL canvas and three scroll-reveal
    # observers, and the receipt visibly blinked before settling.
    "https://sabrtechnologies.com/success.html",
)
if "{CHECKOUT_SESSION_ID}" not in SUCCESS_URL:
    SUCCESS_URL += ("&" if "?" in SUCCESS_URL else "?") + "session_id={CHECKOUT_SESSION_ID}"
INSTALL_BASE_PUBLIC = os.environ.get("INSTALL_BASE", "https://sabrtechnologies.com/landing-assets")
# The prebuilt GUI installers are gitignored release artifacts, so they are
# NOT inside the landing image — /landing-assets/SabrInstaller.exe has always
# been a 404. Windows buyers had no path at all (found 2026-07-29). They now
# live in a public, TLS-served asset repo; hashes are in the release notes.
INSTALLERS_BASE = os.environ.get(
    "INSTALLERS_BASE",
    "https://github.com/47-Industries/sabr-installers/releases/latest/download",
)
CANCEL_URL = os.environ.get("CANCEL_URL", "https://sabr-technologies-production.up.railway.app/#pricing")

def _stripe():
    import stripe
    stripe.api_key = SECRET
    return stripe

@app.get("/health")
def health():
    plans = sorted("%s/%s" % k for k, v in PLANS.items() if v[1])
    return {"ok": True, "configured": bool(SECRET and plans), "plans": plans}

def _resolve_discount(stripe, code):
    """A user-supplied string -> the `discounts` entry Stripe will accept.

    Order matters: promotion code FIRST, because that's what humans have.
    Returns None when the string resolves to nothing usable, so the caller
    can say "invalid code" instead of leaking a Stripe error string.
    """
    code = (code or "").strip()
    if not code:
        return None
    # Promotion code lookup is case-insensitive on Stripe's side, but be
    # forgiving about what a person types into a URL anyway.
    for candidate in {code, code.upper()}:
        try:
            found = stripe.PromotionCode.list(code=candidate, active=True, limit=1)
            data = getattr(found, "data", None) or found.get("data") or []
            if data:
                pc = data[0]
                pid = pc["id"] if isinstance(pc, dict) else pc.id
                return {"promotion_code": pid}
        except Exception:
            pass
    # Not a promotion code — maybe it really is a coupon id (internal links).
    try:
        c = stripe.Coupon.retrieve(code)
        valid = c["valid"] if isinstance(c, dict) else getattr(c, "valid", False)
        if valid:
            return {"coupon": code}
    except Exception:
        pass
    return None


@app.post("/create-checkout")
async def create_checkout(req: Request):
    if not (SECRET and PRICE_BUILD and PRICE_MONTHLY):
        return JSONResponse(status_code=503, content={
            "ok": False,
            "error": "Checkout not configured yet. Set STRIPE_SECRET_KEY, PRICE_BUILD, PRICE_MONTHLY.",
        })
    try:
        body = await req.json()
    except Exception:
        body = {}
    email = (body or {}).get("email")
    coupon = (body or {}).get("coupon")
    items = _resolve((body or {}).get("plan"), (body or {}).get("interval"))
    if not items:
        return JSONResponse(status_code=503, content={
            "ok": False, "error": "That plan isn't configured yet."})
    stripe = _stripe()
    kwargs = dict(
        mode="subscription",
        # Card explicitly: the live account has no automatic payment methods
        # configured yet, and Stripe 400s on an empty method set. Verified
        # against the live API 2026-07-29 — remove only after card is
        # switched on in dashboard payment-method settings.
        payment_method_types=["card"],
        # If a promo takes the total to $0 for good, don't ask for a card at
        # all — a free customer staring at a card form assumes a hidden charge.
        payment_method_collection="if_required",
        customer_email=email,
        line_items=items,
        success_url=SUCCESS_URL,
        cancel_url=CANCEL_URL,
    )
    # Stripe rejects a session that sets both `discounts` and
    # `allow_promotion_codes`, so it's one or the other: an explicit coupon
    # in the request pre-applies a founder's rate; otherwise the checkout
    # page shows a promo-code field Dean can service from the dashboard
    # with no redeploy.
    #
    # What arrives here from ?promo=... is whatever a HUMAN typed or was sent
    # in a link — i.e. a promotion CODE ("GIOFOUNDER"), not a coupon id
    # ("prGb8WzG"). Passing that straight through as `coupon` made Stripe
    # answer "No such coupon" and the page said "code is invalid" for a code
    # that was perfectly real. So: try it as a promotion code first, and only
    # fall back to treating it as a raw coupon id. Anything unresolvable gets
    # a 400 that says WHY, instead of a generic 502.
    if coupon:
        resolved = _resolve_discount(stripe, coupon)
        if resolved is None:
            return JSONResponse(status_code=400, content={
                "ok": False,
                "error": "That code isn't valid — it may be expired, "
                         "already fully redeemed, or mistyped.",
                "code": coupon,
            })
        kwargs["discounts"] = [resolved]
    else:
        kwargs["allow_promotion_codes"] = True
    try:
        session = stripe.checkout.Session.create(**kwargs)
    except Exception as e:
        return JSONResponse(status_code=502, content={"ok": False, "error": str(e)})
    return {"ok": True, "url": session.url}

def _plain(o):
    """Any stripe SDK object -> plain nested dict. SDK-major agnostic."""
    if isinstance(o, dict):
        return o
    for meth in ("to_dict_recursive", "to_dict"):
        fn = getattr(o, meth, None)
        if callable(fn):
            try:
                return json.loads(json.dumps(fn(), default=str))
            except Exception:
                pass
    try:
        # StripeObject.__str__ is a JSON dump in every published major.
        return json.loads(str(o))
    except Exception:
        return {}


@app.post("/webhook")
async def webhook(req: Request):
    payload = await req.body()
    sig = req.headers.get("stripe-signature", "")
    if not WEBHOOK_SECRET:
        raise HTTPException(503, "Webhook secret not configured")
    stripe = _stripe()
    try:
        event = stripe.Webhook.construct_event(payload, sig, WEBHOOK_SECRET)
    except Exception as e:
        raise HTTPException(400, f"Bad signature: {e}")
    etype = event["type"]
    # stripe-python dropped dict inheritance on StripeObject in v13, so
    # `obj.get(...)` started raising AttributeError: get and every webhook
    # 500'd — a paying customer completed checkout and was provisioned
    # nothing (found in live logs 2026-07-29). Coerce to a plain dict once,
    # here, so no downstream code cares what SDK major we're on.
    obj = _plain(event["data"]["object"])
    if etype == "checkout.session.completed":
        email = obj.get("customer_email") or (obj.get("customer_details") or {}).get("email")
        if email:
            # Mint first, bind second, email LAST. If the upsert throws, no
            # email goes out, this handler 500s, and Stripe retries — the
            # customer waits thirty seconds instead of holding a token that
            # will never resolve. The order is the guarantee (REV8 §3).
            rec = mint_install(email)
            entitlement.upsert(
                rec["token"],
                email=email,
                stripe_customer=obj.get("customer"),
                stripe_subscription=obj.get("subscription"),
                # Recorded so /install can hand the buyer their own command
                # on the success page. Email is a delivery path that can fail
                # silently (unset EMAIL_API_KEY); the screen in front of them
                # cannot. Never rely on one channel for the thing they bought.
                stripe_session=obj.get("id"),
                status=entitlement.ACTIVE,
            )
            send_install_email(rec)
            print(f"[checkout] provisioned {email} token={rec['token']}")
    else:
        # Status events. Suspension only ever comes out of one of these —
        # never out of an invoice.paid that failed to show up.
        updated = entitlement.on_stripe_event(etype, obj)
        if updated:
            print(f"[entitlement] {etype} -> {updated['token'][:8]} "
                  f"status={updated['status']}")
        else:
            print(f"[entitlement] {etype} -> no tenant matched, ignored")
    return {"received": True}


@app.get("/install")
def install_for_session(session_id: str):
    """Success-page lookup: 'I just paid — what do I run?'

    Authorised by the session id Stripe puts in the return URL, and we
    re-verify against the live API that it is actually paid before handing
    out a token. Never trust the query string alone.

    Returns pending=True (not an error) while the webhook is still in
    flight, so the page can poll instead of telling a paying customer
    that something went wrong when nothing has.
    """
    if not SECRET:
        return JSONResponse(status_code=503, content={"ok": False, "error": "not configured"})
    stripe = _stripe()
    try:
        sess = _plain(stripe.checkout.Session.retrieve(session_id))
    except Exception as e:
        return JSONResponse(status_code=404, content={"ok": False, "error": str(e)})
    if sess.get("status") != "complete" or sess.get("payment_status") not in ("paid", "no_payment_required"):
        return JSONResponse(status_code=402, content={"ok": False, "error": "That checkout isn't complete."})
    token = entitlement.find_by(stripe_session=sess.get("id")) or \
        entitlement.find_by(stripe_customer=sess.get("customer"))
    if not token:
        return {"ok": True, "pending": True}
    email = (sess.get("customer_details") or {}).get("email") or sess.get("customer_email")
    return {
        "ok": True,
        "pending": False,
        "email": email,
        "install_cmd": build_install_cmd(token),
        "token": token,
        "installers": {
            "windows": f"{INSTALLERS_BASE}/SabrInstaller.exe",
            "macos": f"{INSTALLERS_BASE}/SabrInstaller-macos.zip",
            # Apple Silicon and Intel are DIFFERENT binaries — arm64 vs
            # x86_64 Mach-O, verified against the live release 2026-08-05.
            # The page used to offer one "macos" link, so half of all Mac
            # buyers downloaded an executable their CPU cannot run.
            "macos_intel": f"{INSTALLERS_BASE}/SabrInstaller-macos-intel.zip",
            # Asset is published as `sabr-installer` (no -linux suffix). The old URL
            # 404'd for every Linux buyer — verified live 2026-08-01. Note
            # scripts/fetch_installers.sh deliberately renames it to
            # sabr-installer-linux when staging LOCALLY; the release asset name
            # and the local filename are not the same string.
            "linux": f"{INSTALLERS_BASE}/sabr-installer",
        },
    }


@app.get("/entitlement")
def entitlement_check(token: str):
    """The gateway asks here before spending a thought on someone.

    Answers {allow, report, lease}. `report` is authored copy the SI speaks
    as its own condition — we never ask a suspended mind to compose the
    sentence about its own suspension.
    """
    stripe_mod = _stripe() if SECRET else None
    return entitlement.evaluate(token, stripe_mod=stripe_mod)


ADMIN_KEY = os.environ.get("ADMIN_KEY")


@app.post("/admin/mint")
async def admin_mint(req: Request):
    """Provision a comped/contract customer who never goes through Stripe.

    Founding-tier deals are signed offline — no Stripe
    session, so the webhook never fires and no token ever exists. Without
    this, the only way to hand a contract client a working install is to
    charge them a card they already didn't use. Guarded by ADMIN_KEY;
    503s (not 200) when the key is unset so a misconfigured deploy can
    never mint free minds for the internet.
    """
    if not ADMIN_KEY:
        raise HTTPException(503, "Admin minting not configured")
    if req.headers.get("X-Admin-Key") != ADMIN_KEY:
        raise HTTPException(401, "bad admin key")
    body = await req.json()
    email = (body.get("email") or "").strip()
    if not email:
        raise HTTPException(400, "email required")
    plan = body.get("plan") or "contract"
    rec = mint_install(email, plan=plan)
    entitlement.upsert(rec["token"], email=email, plan=plan,
                       source="admin", status=entitlement.ACTIVE)
    print(f"[admin] minted {email} token={rec['token']}")
    return {"ok": True, "token": rec["token"], "email": email, "plan": plan,
            "install_cmd": rec["install_cmd"]}
