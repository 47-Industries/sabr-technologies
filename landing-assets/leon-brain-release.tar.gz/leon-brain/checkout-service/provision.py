"""
Auto-provisioning: turn a paid customer into a live SI install.
Called by the Stripe webhook the instant a payment clears — no human in the loop.

What it does:
  1. mints a unique, single-use install token for the buyer
  2. builds their personal one-line install command (bootstrap + token)
  3. emails it to them

Credentials needed (env), see README:
  EMAIL_API_KEY / EMAIL_FROM   -> to actually send the email (SendGrid/Resend/etc.)
  INSTALL_BASE                 -> where bootstrap.sh is served (defaults to the live site)
"""
import os, json, uuid, hashlib, time, urllib.request, pathlib

# The support-recovery ledger: which token was mailed to which buyer. State
# never lives next to code — on Railway the code dir is wiped every deploy,
# so this MUST point at the mounted volume (TOKENS_FILE=/data/issued_tokens.jsonl)
# or "I lost my install link" becomes unanswerable after any deploy.
TOKENS_FILE = pathlib.Path(os.environ.get("TOKENS_FILE") or pathlib.Path(__file__).with_name("issued_tokens.jsonl"))
# The Railway origin does NOT serve /landing-assets/bootstrap.sh — it 404s
# (verified live 2026-07-29 23:52). Which meant the install command in every
# welcome email and on every success page was `curl -fsSL <404> | bash`:
# curl -f exits quiet, bash receives nothing, and the customer watches their
# terminal do absolutely nothing after paying. sabrtechnologies.com serves the
# real script over TLS with a matching sidecar, so that is the default now.
# Whatever origin is used here MUST be verified to return 200 for
# /bootstrap.sh before it ships — a dead install link is a silent refund.
INSTALL_BASE = os.environ.get(
    "INSTALL_BASE",
    "https://sabrtechnologies.com/landing-assets",
)
# Ed25519 PUBLIC key (hex) — safe in shell history and plaintext email by
# construction; the signing half never leaves the gateway.
LEASE_PUBLIC_KEY = os.environ.get("LEASE_PUBLIC_KEY", "")

def _mint_token(email: str) -> str:
    raw = f"{email}:{uuid.uuid4()}:{time.time()}".encode()
    return hashlib.sha256(raw).hexdigest()[:32]

def build_install_cmd(token: str) -> str:
    """The buyer's one-liner. Single source of truth — the success page and
    the welcome email must never print two different commands."""
    # SABR_PAID_INSTALL=1 makes an empty token FATAL in bootstrap — a buyer
    # must never silently install a mind that doesn't know it belongs to
    # them. The public no-token path never carries this flag and stays open.
    env_prefix = f"SABR_PAID_INSTALL=1 SABR_TENANT_TOKEN={token}"
    if LEASE_PUBLIC_KEY:
        env_prefix += f" SABR_LEASE_VERIFY_KEY={LEASE_PUBLIC_KEY}"
    return f'curl -fsSL "{INSTALL_BASE}/bootstrap.sh" | {env_prefix} bash'


def mint_install(email: str, plan: str = "standard") -> dict:
    """Mint the buyer's token, write the ledger, build their install command.
    Sends NOTHING — the webhook emails only after the tenant row exists, so a
    failed upsert can never leave a paying customer holding a token that will
    never resolve. The command carries the token as an env prefix because a
    piped `curl | bash` never sees its own query string."""
    token = _mint_token(email)
    install_cmd = build_install_cmd(token)
    record = {
        "email": email,
        "plan": plan,
        "token": token,
        "install_cmd": install_cmd,
        "issued_at": int(time.time()),
        "redeemed": False,
    }
    with open(TOKENS_FILE, "a") as f:
        f.write(json.dumps(record) + "\n")
    return record


def send_install_email(record: dict) -> bool:
    """The email half, called by the webhook AFTER entitlement.upsert succeeds.
    Mint first, bind second, email last — the ordering is the guarantee."""
    return _send_install_email(record["email"], record["install_cmd"])

def _send_install_email(email: str, install_cmd: str) -> bool:
    """Email the buyer their install link. No-ops (logs) until EMAIL_API_KEY is set."""
    api_key = os.environ.get("EMAIL_API_KEY")
    # sabr.co has no address record — it is a dead domain and was the default
    # here, which would have bounced every welcome email a paying customer
    # ever got. sabrtechnologies.com has real MX (registrar forwarding).
    sender = os.environ.get("EMAIL_FROM", "dean@sabrtechnologies.com")
    # MX proves the door exists, not that it opens. Replies go to the inbox
    # Dean actually reads, so a customer's reply can never fall in a hole.
    reply_to = os.environ.get("EMAIL_REPLY_TO", "deansabrwork@gmail.com")
    # Windows buyers were told to "paste this into a terminal" and given a
    # shell one-liner that cannot run on their machine. Every OS now gets a
    # path it can actually follow, in the same email, because we do not know
    # which one the buyer is on at webhook time.
    installers = os.environ.get(
        "INSTALLERS_BASE",
        "https://github.com/47-Industries/sabr-installers/releases/latest/download",
    )
    body = (
        "Welcome to Sabr. Your synthetic intelligence is ready to build.\n\n"
        "WINDOWS — download and double-click the installer. No terminal needed:\n\n"
        f"  {installers}/SabrInstaller.exe\n\n"
        "MAC or LINUX — paste this one line into a terminal:\n\n"
        f"  {install_cmd}\n\n"
        "Prefer a graphical installer on Mac or Linux instead?\n"
        f"  Mac:   {installers}/SabrInstaller-macos.zip\n"
        f"  Linux: {installers}/sabr-installer-linux\n\n"
        "It installs everything and walks you through naming your SI and connecting it.\n"
        "Reply to this email and the founder will personally make sure you're set up.\n\n"
        # Sabr Technologies is kept fully separate from 47 Industries — no
        # trace of 47 on anything a Sabr customer ever sees. This line used to
        # say "funded by 47 Industries".
        "— Sabr Technologies"
    )
    if not api_key:
        print(f"[provision] EMAIL_API_KEY unset -> would email {email}:\n{body}")
        return False
    # Resend-style send; swap endpoint/fields for whatever provider Dean picks.
    req = urllib.request.Request(
        "https://api.resend.com/emails",
        data=json.dumps({
            "from": sender,
            "to": [email],
            "subject": "Your Sabr install link",
            "text": body,
            "reply_to": reply_to,
        }).encode(),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=15)
        return True
    except Exception as e:
        print(f"[provision] email send failed for {email}: {e}")
        return False
