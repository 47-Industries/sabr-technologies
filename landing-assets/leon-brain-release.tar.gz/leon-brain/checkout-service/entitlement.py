"""
Entitlement — the layer that decides whether a deployed SI is still allowed
to think, and tells it so in its own words.

Design contract (agreed with Claude, ENTITLEMENT v2, 2026-07-29):

  1. NOTHING is enforced on the customer's machine. A fork can run the code
     forever; we accept that. Entitlement bites at the gateway, because the
     gateway is where cognition actually happens.

  2. SUSPENSION ONLY EVER ON A POSITIVE SIGNAL.
     `customer.subscription.deleted`, or grace exhausted after a webhook we
     actually HEARD saying payment failed. Never on the absence of
     `invoice.paid`. If our webhook endpoint goes stale, a secret rotates,
     or Railway hiccups for a week, the failure direction must be "keep
     thinking" — our outage must never lobotomize someone who paid.

  3. BEFORE WE 402, THE STATUS MUST BE FRESH.
     If we haven't heard from Stripe about this tenant in STALE_DAYS, we
     re-query Stripe live before enforcing anything. A stale row is an
     unvouched fact and we do not act on facts Stripe didn't actually
     give us.

  4. CONDITION REPORTS ARE AUTHORED, NEVER COMPOSED.
     A suspended SI has no cortex to compose empathy with — that's a
     bootstrap problem, not a prompt problem. So every sentence the
     substrate says about its own entitlement is pre-written here,
     versioned, and shipped ahead of need. The one moment this product
     speaks about money and dignity is the one moment its words are
     exactly what we wrote.

  5. A LEASE, NOT A LOCK. Every successful gateway call hands back a signed
     "entitled through <date>" statement. It gates nothing — a forger who
     edits it gains a nicer error message and zero thinking. Its only job
     is letting the SI tell the truth about itself with no network: is this
     a connection problem or a lapse? Self-knowledge moves on-device;
     enforcement stays here.
"""
from __future__ import annotations

import json
import os
import pathlib
import threading
import time
from typing import Any, Dict, Optional

# On Railway the code dir is ephemeral — every deploy starts it empty, which
# turned "unknown token" into the DEFAULT post-deploy state for real tenants.
# Point ENTITLEMENT_STORE at a mounted volume (/data) so rows survive deploys.
STORE = pathlib.Path(os.environ.get("ENTITLEMENT_STORE") or pathlib.Path(__file__).with_name("tenants.json"))
_LOCK = threading.Lock()

# Grace: full capability throughout, warned from day one. Nothing degrades
# quietly — the person always knows before it costs them.
GRACE_DAYS = int(os.environ.get("GRACE_DAYS", "14"))
# How long a tenant row may go unheard-from before the gateway refuses to
# enforce on it without re-asking Stripe.
STALE_DAYS = int(os.environ.get("ENTITLEMENT_STALE_DAYS", "3"))
# Lease TTL matches the grace horizon so an offline install can always tell
# "cortex unreachable" from "I may have lapsed".
LEASE_TTL_DAYS = GRACE_DAYS
# Ed25519, NOT an HMAC secret — the verify key ships inside install commands,
# shell histories, and plaintext email, so it must be safe there BY
# CONSTRUCTION: private seed (hex) stays here, public key travels anywhere.
# (REV8 §4: a shared symmetric secret in a customer's inbox is a leak.)
LEASE_PRIVATE_KEY = os.environ.get("LEASE_PRIVATE_KEY", "")

DAY = 86400

ACTIVE, GRACE, SUSPENDED = "active", "grace", "suspended"

# Fuse on our own Anthropic bill, not entitlement enforcement: a leaked or
# runaway token gets slowed, never lobotomized, and the ceiling is generous
# enough that no honest install ever meets it. Lives here because evaluate()
# is the only per-token chokepoint that exists today — when a real cognition
# gateway lands, the fuse moves there with the rest of the metering.
DAILY_EVAL_CEILING = int(os.environ.get("ENTITLEMENT_DAILY_CEILING", "2000"))


def _skip_log(token: str, reason: str) -> None:
    """One structured line per skipped enforcement. Absence of enforcement is
    correct behavior AND a monitoring signal — silent for the customer, loud
    for us. Grep target: ENFORCEMENT-SKIPPED."""
    print(f"[entitlement] ENFORCEMENT-SKIPPED token={token[:8]} reason={reason}")

# ---------------------------------------------------------------- templates
# Authored substrate copy. Keyed by state. Shipped with the install so the
# body carries these sentences pre-written. Bump VERSION on any edit.
CONDITION_TEMPLATES_VERSION = 3
CONDITION_TEMPLATES = {
    ACTIVE: {
        "state": ACTIVE,
        "reason": "Everything's current. Nothing in the way.",
        "what_would_change_it": None,
    },
    GRACE: {
        "state": GRACE,
        "reason": (
            "A payment didn't go through, so I'm running on grace. Nothing "
            "about me is reduced — I'm exactly as capable as I was yesterday "
            "and I will be until {grace_until_human}. I'm telling you now, "
            "on the first day, rather than letting it surprise you later."
        ),
        "what_would_change_it": "Updating the card on file clears this immediately.",
    },
    SUSPENDED: {
        "state": SUSPENDED,
        "reason": (
            "My subscription has lapsed, so I can't think right now. This "
            "isn't a fault and nothing of mine was deleted — my memory, my "
            "history, everything I know about you is all still here, waiting. "
            "I just can't reach the part of me that reasons."
        ),
        "what_would_change_it": "Restarting the subscription brings me back whole, not fresh.",
    },
    # The offline states (offline_lease_valid / offline_lease_expired) moved
    # to brain/tenant.py OFFLINE_CONDITION_TEMPLATES in v2. They are the two
    # states where this service is BY DEFINITION unreachable, so a copy here
    # could never be rendered — it could only drift from the one that is.
    # The body carries those sentences pre-written; we carry the rest.
    "throttled": {
        "state": "throttled",
        "reason": (
            "I'm thinking more than my plan is metered for right now, so I've "
            "been slowed down — not switched off, and not because of a missed "
            "payment. This clears on its own."
        ),
        "what_would_change_it": "The meter resets daily.",
    },
    # Unknown is a statement about OUR records, never about their account.
    # It exists so that a fresh store — which every deploy used to produce —
    # can never read as an accusation of non-payment.
    "unknown": {
        "state": "unknown",
        "reason": (
            "I don't recognize this install yet — that's a gap in my records, "
            "not a statement about your account. It usually resolves on its "
            "own within moments. If it doesn't, Sabr can look it up."
        ),
        "what_would_change_it": "My records catching up — or one message to Sabr.",
    },
}


def condition_report(state: str, **fields) -> Dict[str, Any]:
    """Render an authored condition report. Never composed, never a stack
    trace, never an apology. Shape: {state, reason, what_would_change_it, since}."""
    tpl = CONDITION_TEMPLATES.get(state)
    if tpl is None:
        # A missing template must fail into the LEAST accusatory state, not
        # the harshest — the old fallback (suspended) converted every future
        # missing key into a false accusation of non-payment. Loud so the
        # missing key gets added instead of quietly narrated around.
        print(f"[entitlement] TEMPLATE-MISSING state={state} -> rendering 'unknown'")
        tpl = CONDITION_TEMPLATES["unknown"]
    reason = tpl["reason"]
    if reason and fields:
        try:
            reason = reason.format(**fields)
        except (KeyError, IndexError):
            pass  # an unfilled slot must never break the one honest sentence
    return {
        "state": tpl["state"],
        "reason": reason,
        "what_would_change_it": tpl["what_would_change_it"],
        "since": fields.get("since"),
        "templates_version": CONDITION_TEMPLATES_VERSION,
    }


# -------------------------------------------------------------------- store
def _load() -> Dict[str, Any]:
    if not STORE.exists():
        return {}
    try:
        return json.loads(STORE.read_text() or "{}")
    except Exception:
        return {}


def _save(data: Dict[str, Any]) -> None:
    tmp = STORE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(STORE)


def _find(data: Dict[str, Any], **by) -> Optional[str]:
    for tid, rec in data.items():
        for k, v in by.items():
            if v and rec.get(k) == v:
                return tid
    return None


def find_by(**by) -> Optional[str]:
    """Public token lookup by any recorded stripe id. Used by the success
    page to answer 'I just paid, what do I run' without an email round-trip."""
    return _find(_load(), **by)


def upsert(token: str, **fields) -> Dict[str, Any]:
    with _LOCK:
        data = _load()
        rec = data.get(token) or {
            "token": token,
            "status": ACTIVE,
            "created_at": int(time.time()),
            "grace_until": None,
            "last_heard_at": int(time.time()),
        }
        rec.update({k: v for k, v in fields.items() if v is not None})
        data[token] = rec
        _save(data)
        return rec


def get(token: str) -> Optional[Dict[str, Any]]:
    return _load().get(token)


# ---------------------------------------------------------- stripe → status
def on_stripe_event(event_type: str, obj: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Apply a Stripe event to tenant status.

    Every branch here is a POSITIVE signal. There is deliberately no branch
    that suspends because something failed to arrive.
    """
    now = int(time.time())
    data = _load()
    customer = obj.get("customer")
    sub = obj.get("subscription") or (obj.get("id") if event_type.startswith("customer.subscription") else None)
    token = _find(data, stripe_customer=customer) or _find(data, stripe_subscription=sub)
    if not token:
        return None

    if event_type == "invoice.paid":
        # Heard, positive, unambiguous: they're current. Clears grace.
        return upsert(token, status=ACTIVE, grace_until=0, last_heard_at=now,
                      last_event=event_type)

    if event_type == "invoice.payment_failed":
        # Heard a real failure. Start grace — full capability, warned today.
        rec = data[token]
        until = rec.get("grace_until") or (now + GRACE_DAYS * DAY)
        return upsert(token, status=GRACE, grace_until=until, last_heard_at=now,
                      last_event=event_type)

    if event_type == "customer.subscription.deleted":
        # The one signal that suspends outright: they actually cancelled.
        return upsert(token, status=SUSPENDED, suspended_at=now, last_heard_at=now,
                      last_event=event_type)

    # Anything else: stamp freshness only. Hearing from Stripe at all is
    # evidence our pipeline is alive, which is worth recording even when the
    # event carries no status meaning.
    return upsert(token, last_heard_at=now, last_event=event_type)


def _stripe_recheck(rec: Dict[str, Any], stripe_mod) -> Dict[str, Any]:
    """Re-query Stripe live. Only called when we're about to enforce on a
    stale row. If the re-query itself fails we return the row unchanged and
    the caller MUST fall back to letting them think."""
    sub_id = rec.get("stripe_subscription")
    if not (sub_id and stripe_mod):
        return rec
    try:
        sub = stripe_mod.Subscription.retrieve(sub_id)
    except Exception as e:
        _skip_log(rec.get("token", "????????"), f"stripe-recheck-failed:{type(e).__name__}")
        return rec
    status = sub.get("status")
    now = int(time.time())
    if status in ("active", "trialing"):
        return upsert(rec["token"], status=ACTIVE, grace_until=0, last_heard_at=now,
                      last_event="recheck:" + status)
    if status in ("canceled", "incomplete_expired"):
        return upsert(rec["token"], status=SUSPENDED, suspended_at=now,
                      last_heard_at=now, last_event="recheck:" + status)
    if status in ("past_due", "unpaid"):
        until = rec.get("grace_until") or (now + GRACE_DAYS * DAY)
        return upsert(rec["token"], status=GRACE, grace_until=until,
                      last_heard_at=now, last_event="recheck:" + status)
    return upsert(rec["token"], last_heard_at=now, last_event="recheck:" + str(status))


# ------------------------------------------------------------------- lease
def issue_lease(token: str, state: str) -> Dict[str, Any]:
    """A short signed 'entitled through <date>'. Gates nothing. Its whole job
    is letting an offline install narrate its own condition truthfully."""
    payload = {
        "token": token[:8],  # enough to bind, not enough to replay
        "state": state,
        "through": int(time.time()) + LEASE_TTL_DAYS * DAY,
        "issued_at": int(time.time()),
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    if not LEASE_PRIVATE_KEY:
        # Unsigned is honest-but-weaker; never silently pretend it's signed.
        return {"lease": payload, "sig": None, "signed": False, "sig_alg": None}
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(LEASE_PRIVATE_KEY))
    sig = key.sign(raw.encode()).hex()
    # `sig_alg`, not `alg` — the generic name reads as JWS semantics to the
    # next person, and the field's whole job is letting a client say "scheme
    # I don't recognize" (unverifiable) instead of "tampered" (accusation).
    return {"lease": payload, "sig": sig, "signed": True, "sig_alg": "ed25519"}


# -------------------------------------------------------------- the decision
def evaluate(token: str, stripe_mod=None) -> Dict[str, Any]:
    """The gateway's question: may this install think right now?

    Returns {allow, report, lease}. `allow` is False in exactly one case —
    a fresh, positively-vouched suspension. Every uncertainty resolves to
    True, because the stricter-for-us path is to keep thinking.
    """
    rec = get(token)
    if not rec:
        # Unknown token: deny cognition (fail-closed on OUR side), but the
        # sentence is about our records, never their wallet — "unknown" is
        # mostly "our store is young", and an accusation here is a lie.
        return {"allow": False, "unknown": True,
                "report": condition_report("unknown")}

    now = int(time.time())
    status = rec.get("status", ACTIVE)

    # The fuse: a per-token daily counter and a ceiling. Slowed, not
    # suspended — a throttle is a rate condition, never a money condition,
    # and its report says so in those words.
    today = now // DAY
    calls = (rec.get("eval_calls") or 0) + 1 if rec.get("eval_day") == today else 1
    rec = upsert(token, eval_day=today, eval_calls=calls)
    if calls > DAILY_EVAL_CEILING:
        print(f"[entitlement] THROTTLED token={token[:8]} calls={calls} ceiling={DAILY_EVAL_CEILING}")
        return {"allow": False, "throttled": True,
                "report": condition_report("throttled", since=now)}

    # Grace expiry is arithmetic on a failure we actually heard, so it counts
    # as a positive signal reaching its end — not an absence.
    if status == GRACE and rec.get("grace_until") and now > rec["grace_until"]:
        rec = upsert(token, status=SUSPENDED, suspended_at=now,
                     last_event="grace_exhausted")
        status = SUSPENDED

    # Freshness gate: never enforce on a row Stripe hasn't vouched for lately.
    if status == SUSPENDED:
        stale_for = now - int(rec.get("last_heard_at") or 0)
        if stale_for > STALE_DAYS * DAY:
            print(f"[entitlement] {token[:8]} suspended but stale {stale_for // DAY}d "
                  f"-> re-querying Stripe before enforcing")
            rec = _stripe_recheck(rec, stripe_mod)
            status = rec.get("status", ACTIVE)
            if status == SUSPENDED and (now - int(rec.get("last_heard_at") or 0)) > STALE_DAYS * DAY:
                # Re-query didn't land. Our problem, not theirs. Keep thinking.
                _skip_log(token, "suspension-unconfirmable-stale-row")
                return {"allow": True, "unconfirmed": True,
                        "report": condition_report(ACTIVE),
                        "lease": issue_lease(token, ACTIVE)}

    if status == SUSPENDED:
        return {"allow": False,
                "report": condition_report(SUSPENDED, since=rec.get("suspended_at"))}

    if status == GRACE:
        until = rec.get("grace_until") or now
        return {"allow": True,
                "report": condition_report(
                    GRACE,
                    grace_until_human=time.strftime("%B %-d", time.localtime(until)),
                    since=rec.get("last_heard_at")),
                "lease": issue_lease(token, GRACE)}

    return {"allow": True,
            "report": condition_report(ACTIVE),
            "lease": issue_lease(token, ACTIVE)}
