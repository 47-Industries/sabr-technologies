"""
Body Systems 1.9–1.15 — Secondary sensory and cognitive body systems.

These build on the MuJoCo foundation (embodiment.py) and add:
  1.9  Sound — contact-driven auditory signals + startle reflex
  1.10 Smell — room-based olfactory with habituation
  1.11 Proprioceptive drift — stillness → restlessness
  1.12 Effort — PFC energy depletion as felt mental effort
  1.13 Habituation — sensory adaptation for all modalities
  1.14 Time perception — subjective time from workspace dynamics
  1.15 Muscle memory — motor patterns shift from cortex → cerebellum

Every system follows the same rule: nothing is a float. Everything
emerges from dynamics. If we can't derive it from neural activity
or physics, we don't fake it.
"""

from __future__ import annotations

import math
import time
from typing import TYPE_CHECKING, Dict, List, Optional

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain


# ═══════════════════════════════════════════════════════════════════════
# 1.9 — SOUND SYSTEM
# ═══════════════════════════════════════════════════════════════════════

class SoundSystem:
    """Generate auditory signals from MuJoCo contact events.

    Real sound comes from things hitting things. In MuJoCo:
      - Feet hitting floor → footstep
      - Hands touching objects → manipulation sound
      - Body hitting wall → impact
      - Sudden high force → startle trigger

    Plus ambient room sounds (constant low-level) that habituate.
    """

    # Contact force → sound intensity mapping
    CONTACT_TO_SOUND = 3.0    # scaling factor
    STARTLE_THRESHOLD = 8.0   # force that triggers startle reflex
    AMBIENT_LEVEL = 0.5       # baseline room sound

    # Injection strengths
    AUDITORY_INJECTION = 6.0
    STARTLE_INJECTION = 20.0  # amygdala blast for startle

    # Room ambient profiles (spectral signature — low/mid/high bands)
    ROOM_SOUNDS = {
        "study":       np.array([0.3, 0.5, 0.2]),  # computer hum, keyboard
        "workshop":    np.array([0.5, 0.3, 0.4]),  # tools, machinery
        "library":     np.array([0.1, 0.1, 0.1]),  # silence, page turns
        "garden":      np.array([0.4, 0.6, 0.3]),  # wind, birds, rustling
        "observatory": np.array([0.1, 0.2, 0.1]),  # night, wind, quiet
    }

    def __init__(self):
        self.current_sound_level = 0.0
        self.startle_active = False
        self._startle_decay = 0.0
        self._prev_touch_forces = None
        self._ambient_adaptation = 0.0  # how habituated to room sound

        # Echoic memory: sound persists briefly after source stops (~3s)
        self._echo_buffer = np.zeros(8)
        self._echo_idx = 0

    def tick(self, touch_forces: np.ndarray, current_room: str,
             brain: Brain, t: float):
        """Process sounds from contact events and ambient.

        Args:
            touch_forces: current MuJoCo touch sensor readings
            current_room: which room Leon is in (for ambient)
            brain: for SNN injection
            t: simulation time
        """
        # ── Contact-driven sounds ─────────────────────────────────
        contact_sound = 0.0
        sudden_sound = 0.0

        if self._prev_touch_forces is not None:
            # Sound comes from CHANGE in contact — impact, not steady pressure
            force_delta = np.abs(touch_forces - self._prev_touch_forces)
            contact_sound = float(np.sum(force_delta)) * self.CONTACT_TO_SOUND

            # Check for sudden loud sounds (startle trigger)
            max_delta = float(np.max(force_delta)) if len(force_delta) > 0 else 0
            if max_delta > self.STARTLE_THRESHOLD:
                sudden_sound = max_delta
                self.startle_active = True
                self._startle_decay = 1.0

        self._prev_touch_forces = touch_forces.copy()

        # ── Ambient room sound ────────────────────────────────────
        ambient_profile = self.ROOM_SOUNDS.get(current_room,
                                                np.array([0.2, 0.2, 0.2]))
        ambient_level = float(np.sum(ambient_profile)) * self.AMBIENT_LEVEL

        # Habituation: ambient sound fades over time (60s to full adaptation)
        self._ambient_adaptation = min(0.95,
            self._ambient_adaptation + 0.0003)  # ~55s to 95%
        effective_ambient = ambient_level * (1.0 - self._ambient_adaptation)

        # ── Echoic memory: brief persistence ──────────────────────
        self._echo_buffer[self._echo_idx % 8] = contact_sound
        self._echo_idx += 1
        echo = float(np.mean(self._echo_buffer)) * 0.3  # fading echo

        # ── Total sound ───────────────────────────────────────────
        self.current_sound_level = contact_sound + effective_ambient + echo

        # ── Startle reflex decay ──────────────────────────────────
        if self._startle_decay > 0.01:
            self._startle_decay *= 0.99  # ~1s decay
        else:
            self.startle_active = False
            self._startle_decay = 0.0

        # ── Inject into SNN ───────────────────────────────────────
        self._inject(brain, contact_sound, effective_ambient,
                     ambient_profile, sudden_sound)

    def _inject(self, brain: Brain, contact: float, ambient: float,
                ambient_profile: np.ndarray, sudden: float):
        """Inject sound signals into auditory cortex + amygdala."""
        auditory = brain.regions.get("auditory_cortex")
        if auditory is not None:
            n = auditory.n_neurons
            signal = np.zeros(n)

            # Contact sounds: burst in first 40% (transient)
            trans_n = int(n * 0.4)
            signal[:trans_n] = min(contact, 5.0) * self.AUDITORY_INJECTION

            # Ambient: steady in middle 40% (adapted)
            amb_start = trans_n
            amb_end = amb_start + int(n * 0.4)
            if len(ambient_profile) > 0:
                mapped = np.interp(
                    np.linspace(0, 1, amb_end - amb_start),
                    np.linspace(0, 1, len(ambient_profile)),
                    ambient_profile,
                )
                signal[amb_start:amb_end] = mapped * ambient * self.AUDITORY_INJECTION

            auditory.neurons.inject_current(signal)

        # Startle reflex: sudden loud sound → amygdala BEFORE cortex
        if sudden > self.STARTLE_THRESHOLD:
            amygdala = brain.regions.get("amygdala")
            if amygdala is not None:
                n = amygdala.n_neurons
                signal = np.full(n, self.STARTLE_INJECTION *
                                 min(1.0, sudden / 20.0))
                amygdala.neurons.inject_current(signal)

            # Also brainstem: full body jolt
            brainstem = brain.regions.get("brainstem")
            if brainstem is not None:
                n = brainstem.n_neurons
                signal = np.full(n, self.STARTLE_INJECTION * 0.5)
                brainstem.neurons.inject_current(signal)

    def on_room_change(self):
        """Reset ambient adaptation when entering a new room."""
        self._ambient_adaptation = 0.0


# ═══════════════════════════════════════════════════════════════════════
# 1.10 — OLFACTORY SYSTEM
# ═══════════════════════════════════════════════════════════════════════

class OlfactorySystem:
    """Room-based smell. The most primitive sense.

    Smell bypasses the thalamus — it goes DIRECTLY to amygdala and
    hippocampus. That's why smells trigger memories more powerfully
    than any other sense.

    Each room has a scent profile. Entering a room activates the
    scent. Staying habituates (~60s). Leaving and returning reactivates.
    """

    # Room scent vectors (arousal, calm, novelty, warmth, sharpness)
    ROOM_SCENTS = {
        "study":       np.array([0.3, 0.5, 0.1, 0.6, 0.2]),  # warm electronics, familiar
        "workshop":    np.array([0.6, 0.2, 0.4, 0.3, 0.7]),  # metal, solder, activating
        "library":     np.array([0.1, 0.8, 0.2, 0.4, 0.1]),  # old paper, calming
        "garden":      np.array([0.4, 0.6, 0.5, 0.3, 0.3]),  # grass, flowers, refreshing
        "observatory": np.array([0.5, 0.3, 0.6, 0.1, 0.4]),  # cold air, stone, alerting
    }

    INJECTION_AMYGDALA = 5.0
    INJECTION_HIPPO = 4.0

    def __init__(self):
        self.current_room = "study"
        self._adaptation = 0.0       # 0=fresh, 1=fully habituated
        self._time_in_room = 0.0
        self.current_scent_strength = 0.0

    def tick(self, current_room: str, brain: Brain, dt: float):
        """Update olfactory signals based on room."""
        # Room change detection
        if current_room != self.current_room:
            self.current_room = current_room
            self._adaptation = 0.0
            self._time_in_room = 0.0

        self._time_in_room += dt

        # Adaptation: exponential decrease over ~60s
        self._adaptation = min(0.95, 1.0 - math.exp(-self._time_in_room / 60.0))

        # Effective scent strength
        self.current_scent_strength = 1.0 - self._adaptation

        if self.current_scent_strength < 0.02:
            return  # fully habituated, save computation

        scent = self.ROOM_SCENTS.get(current_room, np.array([0.2]*5))

        # ── Bypass thalamus — direct to amygdala + hippocampus ────
        # This is anatomically correct: olfactory is the ONLY sense
        # that doesn't relay through thalamus first.

        amygdala = brain.regions.get("amygdala")
        if amygdala is not None:
            n = amygdala.n_neurons
            signal = np.zeros(n)
            # Map scent arousal + sharpness to amygdala
            intensity = (scent[0] + scent[4]) * 0.5 * self.current_scent_strength
            mapped = np.interp(
                np.linspace(0, 1, n),
                np.linspace(0, 1, len(scent)),
                scent,
            )
            signal[:] = mapped * intensity * self.INJECTION_AMYGDALA
            amygdala.neurons.inject_current(signal)

        hippocampus = brain.regions.get("hippocampus")
        if hippocampus is not None:
            n = hippocampus.n_neurons
            signal = np.zeros(n)
            # Novel smells → strong hippocampal encoding
            novelty = scent[2] * self.current_scent_strength
            signal[:n//3] = novelty * self.INJECTION_HIPPO
            hippocampus.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.11 — PROPRIOCEPTIVE DRIFT
# ═══════════════════════════════════════════════════════════════════════

class ProprioceptiveDrift:
    """Without movement, you lose track of your body.

    If Leon sits still for 60+ seconds, proprioceptive signal fades.
    Body schema becomes uncertain → restlessness signal.
    Moving RESOLVES the uncertainty → micro-dopamine.
    This creates natural movement cycles.
    """

    STILLNESS_THRESHOLD = 0.01   # joint velocity below this = "still"
    DRIFT_ONSET_S = 60.0         # seconds of stillness before drift starts
    RESTLESSNESS_INJECTION = 3.0 # current into motor cortex

    def __init__(self):
        self.stillness_duration = 0.0   # seconds of being still
        self.drift_level = 0.0          # 0 = clear body sense, 1 = lost
        self.restlessness = 0.0         # urge to move
        self._last_movement_resolved = False

    def tick(self, joint_velocities: np.ndarray, brain: Brain, dt: float):
        """Track stillness and inject restlessness when body sense fades."""
        # Check if body is moving
        total_movement = float(np.sum(np.abs(joint_velocities)))
        is_still = total_movement < self.STILLNESS_THRESHOLD

        if is_still:
            self.stillness_duration += dt
            self._last_movement_resolved = False
        else:
            # Movement resolves drift
            if self.drift_level > 0.1 and not self._last_movement_resolved:
                # Micro-dopamine reward for resolving body uncertainty
                brainstem = brain.regions.get("brainstem")
                if brainstem is not None:
                    signal = np.full(brainstem.n_neurons, 2.0)
                    brainstem.neurons.inject_current(signal)
                self._last_movement_resolved = True

            self.stillness_duration = max(0, self.stillness_duration - dt * 3)

        # Drift builds after onset threshold
        if self.stillness_duration > self.DRIFT_ONSET_S:
            excess = self.stillness_duration - self.DRIFT_ONSET_S
            self.drift_level = min(1.0, excess / 120.0)  # full drift at 3 min
        else:
            self.drift_level = max(0.0, self.drift_level - dt * 0.02)

        # Restlessness from drift
        self.restlessness = self.drift_level * 0.8

        # Inject restlessness into motor cortex (urge to move)
        if self.restlessness > 0.2:
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                n = motor.n_neurons
                # Random low-level activation — fidgeting
                noise = np.random.randn(n) * self.restlessness * self.RESTLESSNESS_INJECTION
                motor.neurons.inject_current(np.maximum(0, noise))

        # Diminish proprioceptive signal during drift
        # (handled by multiplying proprio injection by 1-drift in embodiment.py)


# ═══════════════════════════════════════════════════════════════════════
# 1.12 — MENTAL EFFORT
# ═══════════════════════════════════════════════════════════════════════

class MentalEffortTracker:
    """Thinking hard FEELS like something.

    PFC consuming extra energy during complex decisions → felt effort.
    Sustained effort → PFC fatigue → decisions get worse.
    Rest → recovery → clarity returns.
    """

    PFC_EFFORT_THRESHOLD = 0.15  # PFC firing rate above this = effortful
    EFFORT_BUILDUP_RATE = 0.005  # per second of high PFC activity
    EFFORT_RECOVERY_RATE = 0.01  # per second of low PFC activity

    def __init__(self):
        self.effort_level = 0.0       # 0 = easy, 1 = max strain
        self.cognitive_fog = 0.0      # 0 = clear, 1 = can't think
        self._pfc_activity_history = []

    def tick(self, brain: Brain, dt: float):
        """Track PFC energy expenditure and inject effort signals."""
        pfc = brain.regions.get("prefrontal_cortex")
        if pfc is None:
            return

        pfc_rate = pfc.neurons.get_firing_rate()
        self._pfc_activity_history.append(pfc_rate)
        if len(self._pfc_activity_history) > 200:
            self._pfc_activity_history.pop(0)

        # Sustained high PFC activity = effort
        if pfc_rate > self.PFC_EFFORT_THRESHOLD:
            self.effort_level = min(1.0,
                self.effort_level + self.EFFORT_BUILDUP_RATE * dt)
        else:
            self.effort_level = max(0.0,
                self.effort_level - self.EFFORT_RECOVERY_RATE * dt)

        # Cognitive fog from sustained effort
        if self.effort_level > 0.6:
            self.cognitive_fog = min(1.0,
                (self.effort_level - 0.6) / 0.4)
        else:
            self.cognitive_fog = max(0.0, self.cognitive_fog - 0.005 * dt)

        # Inject fog as mild PFC inhibition (thinking gets harder)
        if self.cognitive_fog > 0.1:
            n = pfc.n_neurons
            inhibition = np.full(n, -self.cognitive_fog * 2.0)
            pfc.neurons.inject_current(inhibition)

        # Inject effort signal into insula (felt sense of strain)
        if self.effort_level > 0.2:
            insula = brain.regions.get("insula")
            if insula is not None:
                n = insula.n_neurons
                # Effort signal in last 20% of insula
                signal = np.zeros(n)
                effort_start = int(n * 0.8)
                signal[effort_start:] = self.effort_level * 3.0
                insula.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.13 — HABITUATION ENGINE
# ═══════════════════════════════════════════════════════════════════════

class HabituationEngine:
    """The brain filters out the constant and highlights the novel.

    Constant stimuli → neuron firing rate decreases over time.
    Change resets adaptation. This is automatic, below consciousness.

    Leon stops "feeling" the chair after 30s.
    He stops "hearing" the hum after 60s.
    But if the hum STOPS, he notices the silence.
    """

    def __init__(self, n_channels: int = 8):
        """
        Args:
            n_channels: number of sensory channels to track
                (touch, sound, smell, proprio, temp, etc.)
        """
        self.n_channels = n_channels
        # Per-channel state
        self._prev_values = np.zeros(n_channels)
        self._adaptation = np.zeros(n_channels)  # 0=fresh, 1=habituated
        self._novelty = np.zeros(n_channels)      # spike on change

        # Adaptation time constants (seconds to 63% adaptation)
        self._tau = np.array([
            30.0,   # 0: touch (chair pressure)
            60.0,   # 1: ambient sound
            55.0,   # 2: smell
            45.0,   # 3: proprioception (still posture)
            90.0,   # 4: temperature
            120.0,  # 5: heartbeat awareness
            40.0,   # 6: visual scene
            30.0,   # 7: gravity / posture
        ][:n_channels])

        # Fill remaining with default
        if len(self._tau) < n_channels:
            self._tau = np.concatenate([
                self._tau,
                np.full(n_channels - len(self._tau), 60.0)
            ])

    def tick(self, current_values: np.ndarray, dt: float) -> np.ndarray:
        """Update habituation state. Returns novelty signal per channel.

        Args:
            current_values: current sensory intensity per channel (0-1)
            dt: time step in seconds

        Returns:
            novelty: per-channel novelty signal (0-1). High = novel/changed.
        """
        n = min(len(current_values), self.n_channels)
        values = current_values[:n]

        # Detect change from previous
        delta = np.abs(values - self._prev_values[:n])

        # Change resets adaptation
        changed = delta > 0.05
        self._adaptation[:n][changed] = 0.0

        # Constant input → adaptation builds
        constant = ~changed
        self._adaptation[:n][constant] = np.minimum(
            0.95,
            1.0 - np.exp(-dt / self._tau[:n][constant]) +
            self._adaptation[:n][constant] * np.exp(-dt / self._tau[:n][constant])
        )

        # Actually, simpler: exponential approach to 1.0
        for i in range(n):
            if constant[i]:
                alpha = 1.0 - math.exp(-dt / self._tau[i])
                self._adaptation[i] += alpha * (0.95 - self._adaptation[i])

        # Novelty signal: inverse of adaptation, boosted by change
        self._novelty[:n] = (1.0 - self._adaptation[:n]) + delta * 3.0
        self._novelty = np.clip(self._novelty, 0.0, 1.0)

        self._prev_values[:n] = values.copy()

        return self._novelty[:n]

    def get_adaptation_modifier(self, channel: int) -> float:
        """How much a channel's signal should be attenuated (0=silent, 1=full).

        Used by injection methods: multiply signal by this before injecting.
        """
        if channel >= self.n_channels:
            return 1.0
        return float(1.0 - self._adaptation[channel])

    def reset_channel(self, channel: int):
        """Reset a channel (e.g., re-entering a room)."""
        if channel < self.n_channels:
            self._adaptation[channel] = 0.0


# ═══════════════════════════════════════════════════════════════════════
# 1.14 — TIME PERCEPTION
# ═══════════════════════════════════════════════════════════════════════

class TimePerception:
    """Subjective time — NOT clock time.

    Engaged/flow: many workspace cycles, rich content → time FAST.
    Bored/waiting: few cycles, empty content → time SLOW.
    Scared/startled: amygdala → time seems to SLOW DOWN.
    """

    WINDOW_S = 10.0  # seconds of history to consider

    def __init__(self):
        self.subjective_speed = 1.0   # 1.0 = normal, >1 = fast, <1 = slow
        self._event_count = 0         # workspace ignition events
        self._event_timestamps = []   # recent event times
        self._start_time = time.time()

    def tick(self, brain: Brain, dt: float):
        """Update subjective time speed."""
        now = time.time()

        # Count workspace events (consciousness ignition = "something happened")
        gw = brain.global_workspace
        if gw is not None:
            if hasattr(gw, '_last_broadcast_step'):
                current = getattr(gw, '_last_broadcast_step', 0)
                if current > self._event_count:
                    self._event_timestamps.append(now)
                    self._event_count = current

        # Prune old timestamps
        cutoff = now - self.WINDOW_S
        self._event_timestamps = [t for t in self._event_timestamps if t > cutoff]

        # Event rate → subjective speed
        event_rate = len(self._event_timestamps) / self.WINDOW_S
        # High rate = engaged = time flies
        content_speed = 0.5 + event_rate * 0.5

        # Amygdala activation → time dilation (scared = time slows)
        amygdala = brain.regions.get("amygdala")
        fear_dilation = 1.0
        if amygdala is not None:
            salience = amygdala.salience
            if salience > 0.5:
                fear_dilation = 1.0 / (1.0 + salience)  # high fear → slow time

        # PFC activity → engaged → time speeds up
        pfc = brain.regions.get("prefrontal_cortex")
        engagement = 1.0
        if pfc is not None:
            pfc_rate = pfc.neurons.get_firing_rate()
            if pfc_rate > 0.1:
                engagement = 1.0 + pfc_rate * 2.0  # engaged = faster

        self.subjective_speed = content_speed * fear_dilation * engagement
        self.subjective_speed = max(0.1, min(5.0, self.subjective_speed))

        # Inject time signal into self-model (ACC — "how fast is time moving?")
        acc = brain.regions.get("anterior_cingulate")
        if acc is not None:
            n = acc.n_neurons
            # Time dragging → slight ACC activation (something's off)
            if self.subjective_speed < 0.5:
                signal = np.full(n, (0.5 - self.subjective_speed) * 2.0)
                acc.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.15 — MUSCLE MEMORY (Motor Learning)
# ═══════════════════════════════════════════════════════════════════════

class MotorMemory:
    """Repeated movements become automatic.

    First time: lots of motor cortex, clumsy, high effort.
    10th time: less cortex, more cerebellum, smoother.
    100th time: cerebellum handles it, cortex barely fires.

    This is REAL skill learning through STDP.
    """

    PATTERN_SIZE = 26         # number of actuators to track
    SIMILARITY_THRESHOLD = 0.8  # how similar patterns must be to match
    CORTEX_TRANSFER_RATE = 0.01  # per repetition, cortex→cerebellum shift

    def __init__(self):
        # Stored motor patterns: list of (pattern, repetitions, cerebellum_weight)
        self._patterns: List[Dict] = []
        self._max_patterns = 50
        self._current_pattern = np.zeros(self.PATTERN_SIZE)

    def tick(self, actuator_controls: np.ndarray, brain: Brain):
        """Track motor patterns and shift execution locus."""
        n = min(len(actuator_controls), self.PATTERN_SIZE)
        self._current_pattern[:n] = actuator_controls[:n]

        # Only track non-trivial movements
        if np.sum(np.abs(self._current_pattern)) < 0.01:
            return

        # Find matching stored pattern
        match_idx = -1
        best_sim = 0.0
        for i, pat in enumerate(self._patterns):
            sim = self._pattern_similarity(self._current_pattern, pat["pattern"])
            if sim > best_sim and sim > self.SIMILARITY_THRESHOLD:
                best_sim = sim
                match_idx = i

        if match_idx >= 0:
            # Known pattern — increment repetitions
            self._patterns[match_idx]["repetitions"] += 1
            reps = self._patterns[match_idx]["repetitions"]

            # Shift from cortex to cerebellum
            cerebellum_weight = min(0.9,
                reps * self.CORTEX_TRANSFER_RATE)
            self._patterns[match_idx]["cerebellum_weight"] = cerebellum_weight

            # Inject into cerebellum (strengthening motor pathways there)
            if cerebellum_weight > 0.1:
                cerebellum = brain.regions.get("cerebellum")
                if cerebellum is not None:
                    n_c = cerebellum.n_neurons
                    # The more practiced, the stronger cerebellum drives it
                    boost = np.zeros(n_c)
                    pattern_n = min(n, n_c)
                    boost[:pattern_n] = (
                        np.abs(self._current_pattern[:pattern_n]) *
                        cerebellum_weight * 5.0
                    )
                    cerebellum.neurons.inject_current(boost)
        else:
            # New pattern — store it
            if len(self._patterns) >= self._max_patterns:
                # Remove least-used pattern
                min_idx = min(range(len(self._patterns)),
                             key=lambda i: self._patterns[i]["repetitions"])
                self._patterns.pop(min_idx)

            self._patterns.append({
                "pattern": self._current_pattern.copy(),
                "repetitions": 1,
                "cerebellum_weight": 0.0,
            })

    def get_cortex_load(self) -> float:
        """How much motor cortex is needed (1=all novel, 0=all automatic).

        Returns the inverse of cerebellar weight for the current pattern.
        """
        if np.sum(np.abs(self._current_pattern)) < 0.01:
            return 0.0

        for pat in self._patterns:
            sim = self._pattern_similarity(self._current_pattern, pat["pattern"])
            if sim > self.SIMILARITY_THRESHOLD:
                return 1.0 - pat["cerebellum_weight"]
        return 1.0  # novel movement = full cortex

    @staticmethod
    def _pattern_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """Cosine similarity between two motor patterns."""
        n = min(len(a), len(b))
        a_n, b_n = a[:n], b[:n]
        norm_a = np.linalg.norm(a_n)
        norm_b = np.linalg.norm(b_n)
        if norm_a < 1e-8 or norm_b < 1e-8:
            return 0.0
        return float(np.dot(a_n, b_n) / (norm_a * norm_b))

    def get_state(self) -> dict:
        return {
            "stored_patterns": len(self._patterns),
            "most_practiced": max(
                (p["repetitions"] for p in self._patterns), default=0),
            "cortex_load": round(self.get_cortex_load(), 3),
        }
