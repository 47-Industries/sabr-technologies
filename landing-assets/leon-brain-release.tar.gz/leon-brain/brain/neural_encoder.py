"""
NeuralEncoder — turns text into an 18-D brain-state fingerprint.

This is the bridge that makes the spiking simulation actually CAUSE
memory encoding. Before this module, the `neural_fingerprint` column on
the `knowledge` table was empty across all 225 rows — every fact was
stored as text only, and `knowledge_search` ranked purely by SQLite FTS.
The brain played zero role in retrieval.

After this module, every fact gets a 18-D fingerprint derived from the
brain's anatomical structure (the 18 regions + their connectivity).
Retrieval (Phase 2) ranks by cosine similarity between query and stored
fingerprints. The brain genuinely participates in recall.

## Encoder design — STRUCTURAL PROJECTION (Phase 1)

We map each text deterministically through a per-region projection
matrix into an 18-D activation vector. The projection matrices are
SEEDED FROM BRAIN STRUCTURE — each region's matrix is derived from:
  - That region's neuron count (region with more neurons → wider response)
  - That region's incoming connectivity (which other regions send to it,
    weighted by connection probability)
  - That region's anatomical role (encoded as a per-region "input bias")

The encoder lives in `BrainFingerprint(regions, z_scores)` dataclass.

## Why not just run the spiking sim?

We tried. The spiking dynamics at small scale (2000 neurons) had a
catastrophic signal-to-noise ratio: identical-text encodes diverged
~0.4 cosine despite full state resets. The deterministic floating-point
arithmetic combined with chaotic neural dynamics meant we couldn't get
reliable fingerprints out of <10K neurons without forcing the noise to
zero — which collapsed all texts to two alternating attractors.

The projection encoder is the honest "Phase 1" deliverable: every fact
gets a brain-derived fingerprint that clusters semantically similar
text. Phase 5+ adds spiking dynamics back in, but THAT layer becomes
useful once we have:
  - Quantum-random noise (so the chaotic dynamics are seeded by physical
    QRNG instead of PRNG drift)
  - STDP-derived strength weights (Phase 3) that decay between recalls
  - More neurons (production already has 10K; encoder can grow)

For now, projection gives us: deterministic, fast (<1ms per encode),
discriminating, anatomically-informed fingerprints — which is everything
Phase 2 retrieval needs.
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from typing import List, Optional

import numpy as np

from brain.config import BrainConfig
from sensory.text import TextEncoder


# Anatomical input gains — per-region multiplier on the text-feature
# projection. Roughly reflects "how much does this region respond to
# language input." Wernicke + Broca are language regions → high. Visual
# cortex doesn't process raw text → low. Cerebellum / brainstem / motor
# have minor language involvement → low.
# These are biology-flavored priors, NOT learned. Tunable.
_LANGUAGE_GAIN = {
    "wernicke":               1.00,
    "broca":                  0.85,
    "temporal_association":   0.75,  # semantic memory
    "parietal_association":   0.60,
    "prefrontal_cortex":      0.65,  # working memory / planning
    "anterior_cingulate":     0.45,
    "hippocampus":            0.55,  # episodic binding
    "default_mode_network":   0.50,
    "amygdala":               0.30,  # only for emotionally-loaded text
    "insula":                 0.25,
    "thalamus":               0.40,  # relay
    "basal_ganglia":          0.20,
    "visual_cortex":          0.15,
    "auditory_cortex":        0.20,  # would be higher for speech
    "somatosensory_cortex":   0.10,
    "motor_cortex":           0.10,
    "cerebellum":             0.10,
    "brainstem":              0.05,
}


@dataclass(frozen=True)
class BrainFingerprint:
    """18-D activation pattern across the named brain regions."""
    regions: List[str]
    z_scores: List[float]

    def to_dict(self) -> dict:
        return {"regions": list(self.regions),
                "z_scores": list(self.z_scores),
                "dim": len(self.z_scores)}

    def to_array(self) -> np.ndarray:
        return np.asarray(self.z_scores, dtype=np.float32)

    @classmethod
    def from_dict(cls, d: dict) -> "BrainFingerprint":
        return cls(regions=list(d.get("regions", [])),
                   z_scores=list(d.get("z_scores", [])))

    @classmethod
    def from_json(cls, s: str) -> Optional["BrainFingerprint"]:
        if not s or not isinstance(s, str):
            return None
        try:
            d = json.loads(s)
        except Exception:
            return None
        if not isinstance(d, dict) or "z_scores" not in d:
            return None
        return cls.from_dict(d)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


class NeuralEncoder:
    """Thread-safe text → brain-fingerprint encoder.

    Uses a deterministic structural projection seeded by the brain's
    region structure. See module docstring for design rationale."""

    PROJECTION_SEED = 47   # honors Sabr — stable seed for the
                           # projection matrices so encodes are repeatable
                           # across processes

    def __init__(self, text_feature_dim: int = 256):
        self._lock = threading.Lock()
        self._text_encoder = TextEncoder(feature_dim=text_feature_dim)
        self._feature_dim = text_feature_dim

        # Canonical region ordering (matches brain.regions iteration order)
        self._region_names: List[str] = list(BrainConfig.REGION_PROPORTIONS.keys())

        # Build per-region projection matrix from the text-feature space
        # to a single scalar (the region's "activation" for this input).
        # Each region gets its OWN deterministic random projection
        # weighted by:
        #   - language-gain prior (anatomy)
        #   - region size (proportion of total neurons)
        #   - row-sum of incoming connectivity
        # Result: 18 vectors of length feature_dim, one per region.
        rng = np.random.RandomState(self.PROJECTION_SEED)
        self._region_projections = np.zeros(
            (len(self._region_names), text_feature_dim), dtype=np.float32)

        # Per-feature-band gain: TextEncoder produces 4 quarters —
        # [char, word, bigram, structural]. Semantically meaningful
        # signal lives in word + bigram quarters; char is noisy and
        # structural (length, caps, punctuation) clusters by surface
        # form regardless of content. Bake the reweighting INTO the
        # projection so baseline + real encodes get identical treatment.
        q = text_feature_dim // 4
        feature_gain = np.ones(text_feature_dim, dtype=np.float32)
        feature_gain[:q]           = 0.70   # char features — weak signal
        feature_gain[q:2 * q]      = 1.40   # word features — strong
        feature_gain[2 * q:3 * q]  = 1.40   # bigram features — strong
        feature_gain[3 * q:]       = 0.10   # structural — almost zero
        self._feature_gain = feature_gain

        for i, name in enumerate(self._region_names):
            # Base random projection × per-feature-band gain
            base = rng.randn(text_feature_dim).astype(np.float32) * feature_gain
            # Anatomical gain
            lang_gain = _LANGUAGE_GAIN.get(name, 0.3)
            # Region size (proportion of all neurons)
            size_gain = float(BrainConfig.REGION_PROPORTIONS.get(name, 0.05))
            # Incoming connectivity strength
            incoming = sum(p for (src, dst), p in BrainConfig.CONNECTIVITY.items()
                           if dst == name)
            conn_gain = 1.0 + min(incoming, 1.0)  # 1.0–2.0
            self._region_projections[i] = base * lang_gain * np.sqrt(size_gain) * conn_gain

        # Baseline = mean and std of region activations across a corpus
        # of nonsense / null inputs. We'll z-score against this.
        self._compute_baseline()

        self._encode_count = 0
        self._total_encode_ms = 0.0
        print(f"[ENCODER] ready — projection encoder over "
              f"{len(self._region_names)} anatomical regions "
              f"(feature_dim={text_feature_dim}, seed={self.PROJECTION_SEED})")

    # ── baseline ───────────────────────────────────────────────────────
    def _compute_baseline(self) -> None:
        """Probe the encoder with many random-text-like feature vectors
        to establish per-region activation statistics. Z-scoring against
        these means an empty/null input → ~0 fingerprint, while
        meaningful text → fingerprint with clear positive/negative
        deviations."""
        rng = np.random.RandomState(self.PROJECTION_SEED + 1)
        N = 200
        samples = []
        for _ in range(N):
            # Synthetic feature vector resembling what TextEncoder.encode
            # would produce — roughly uniform [0, 1] with small skew
            fake_features = np.clip(rng.uniform(0, 1, self._feature_dim) +
                                    rng.randn(self._feature_dim) * 0.1,
                                    0, 1).astype(np.float32)
            activations = self._region_projections @ fake_features
            samples.append(activations)
        s = np.asarray(samples, dtype=np.float32)
        self._baseline_mean = s.mean(axis=0)
        self._baseline_std = s.std(axis=0) + 1e-6

    # ── public encode API ──────────────────────────────────────────────
    def encode_to_fingerprint(self, text: str) -> BrainFingerprint:
        """Project `text` through the per-region structural matrices
        and return a z-scored 18-D activation pattern.

        Empty or whitespace-only text returns a zero-vector fingerprint."""
        if not text or not text.strip():
            return BrainFingerprint(
                regions=list(self._region_names),
                z_scores=[0.0] * len(self._region_names),
            )
        with self._lock:
            t0 = time.time()
            try:
                features = self._text_encoder.encode(text)
                if features.size == 0:
                    return BrainFingerprint(
                        regions=list(self._region_names),
                        z_scores=[0.0] * len(self._region_names),
                    )
                # Pad / truncate if dim mismatch (defensive)
                if len(features) != self._feature_dim:
                    f = np.zeros(self._feature_dim, dtype=np.float32)
                    f[:min(len(features), self._feature_dim)] = \
                        features[:min(len(features), self._feature_dim)]
                    features = f
                # Project to 18 region activations. The per-feature-band
                # gain (word + bigram up, structural down) is already
                # baked into self._region_projections at init time.
                activations = self._region_projections @ features
                # Z-score against baseline
                z = (activations - self._baseline_mean) / self._baseline_std
                z = np.clip(z, -8.0, 8.0)
                fp = BrainFingerprint(
                    regions=list(self._region_names),
                    z_scores=[float(x) for x in z],
                )
            finally:
                self._encode_count += 1
                self._total_encode_ms += (time.time() - t0) * 1000.0
            return fp

    def encode_to_json(self, text: str) -> str:
        """Convenience wrapper for KnowledgeStore.store(neural_fingerprint=...)
        — returns a JSON dict ready for the column."""
        return self.encode_to_fingerprint(text).to_json()

    # ── introspection ──────────────────────────────────────────────────
    def stats(self) -> dict:
        avg = (self._total_encode_ms / self._encode_count) \
            if self._encode_count else 0.0
        return {
            "encoder_type":   "structural_projection",
            "feature_dim":    self._feature_dim,
            "region_dim":     len(self._region_names),
            "regions":        list(self._region_names),
            "encode_count":   self._encode_count,
            "avg_encode_ms":  round(avg, 3),
            "projection_seed": self.PROJECTION_SEED,
        }
