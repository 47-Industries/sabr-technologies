"""
Cognition consolidator — sleep-pass over Phase 1 episodes + Phase 2 graph.

Runs cooperatively with the existing SleepConsolidator (which already
distills conversation → knowledge). This module's job is to mine the
episode log + graph for higher-order structure:

  1. REPLAY  — find chains of successful actions, reinforce graph edges
  2. COMPRESS — find repetitive episode sequences, create macro entities
  3. DECAY   — prune weak graph edges that haven't been reinforced
  4. CAUSAL  — extract simple "if X then Y" rules from precedes patterns
  5. SELF    — update self_model archetypes from accumulated episodes
  6. HYPOTHETICAL — generate "what if" candidates for active-mode exploration

Each pass returns a ConsolidationReport that the inspection endpoint
exposes. Passes are NOT triggered every loop tick — they're meant to fire
during the existing sleep cycles, plus an on-demand endpoint for testing.

Heavy lifting: we shell out to SQLite via the EpisodeStore connection.
No external ML deps. Causal rules are statistical patterns over the
already-tagged side_effect / success columns, not LLM-generated.
"""

from __future__ import annotations

import collections
import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.consolidation")


# ── Phase 11B — LLM causal hypothesis support ──────────────────────────────

def _llm_causal_enabled() -> bool:
    return os.environ.get("LEON_COGNITION_LLM_CAUSAL", "off").lower() in (
        "on", "1", "true", "yes",
    )


def _default_hypothesis_store_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "causal_hypotheses.jsonl")


@dataclass
class CausalHypothesis:
    """An LLM-generated explanation grounded in statistical evidence.

    The 'status' field is the safety contract: hypotheses are NEVER
    treated as facts — only as candidate explanations to verify against
    future episodes. The 'support' field is the floor: this hypothesis
    came from a real statistical pattern with N observations behind it.
    """
    type: str = "causal_hypothesis"
    cause: str = ""
    effect: str = ""
    support: int = 0                  # episode pairs supporting the underlying rule
    confidence: float = 0.0           # P(B | A) of the underlying rule
    hypothesis: str = ""              # LLM-generated explanation
    status: str = "unverified"        # 'unverified' | 'corroborated' | 'contradicted'
    first_seen: float = 0.0
    last_seen: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CausalRule:
    """A statistical 'if A then B' rule mined from precedes patterns."""
    antecedent: str           # action_name A
    consequent: str           # action_name B
    confidence: float         # P(B | A) over observed precedences
    support: int              # number of A→B observations
    avg_latency_ms: float     # time between A and B
    avg_outcome: float        # mean success of B following A

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ConsolidationReport:
    started_ts: float
    duration_s: float
    chains_replayed: int = 0
    chain_edges_reinforced: int = 0
    macros_created: int = 0
    edges_decayed: int = 0
    rules_extracted: int = 0
    hypotheticals_generated: int = 0
    self_archetypes_updated: bool = False
    # Phase 11B — LLM-assisted causal hypotheses (off by default)
    causal_hypotheses_generated: int = 0
    causal_hypotheses: List[Dict[str, Any]] = field(default_factory=list)
    # Phase 12A — hypothesis corroboration
    hypothesis_verify: Dict[str, Any] = field(default_factory=dict)
    # H1 — rotation results (populated at most once per 24h)
    episodes_pruned: int = 0
    jsonl_lines_pruned: int = 0
    knowledge_disposed: int = 0
    notes: List[str] = field(default_factory=list)
    rules: List[Dict[str, Any]] = field(default_factory=list)
    hypotheticals: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class CognitionConsolidator:
    """Runs episode-driven consolidation passes."""

    def __init__(self, *, episodes, graph, self_model, world_model, drives,
                 sleep_consolidator=None):
        self.episodes = episodes
        self.graph = graph
        self.self_model = self_model
        self.world_model = world_model
        self.drives = drives
        self.sleep = sleep_consolidator
        self._last_pass: Optional[ConsolidationReport] = None
        self._pass_count = 0
        self._installed_hook = False
        self._last_prune_ts: float = 0.0  # H1 — rotation throttle (24h gate)
        self.verifier = None  # Phase 12A — set by bootstrap.install

    # -- main pass --------------------------------------------------------

    def consolidate_pass(self, *, hours: int = 72) -> ConsolidationReport:
        """Single consolidation pass over the last `hours` of episodes."""
        t0 = time.time()
        report = ConsolidationReport(started_ts=t0, duration_s=0.0)

        try:
            self._replay_successful_chains(hours=hours, report=report)
        except Exception as e:
            report.notes.append(f"replay failed: {e}")
        try:
            self._compress_repetitive(hours=hours, report=report)
        except Exception as e:
            report.notes.append(f"compress failed: {e}")
        try:
            report.edges_decayed = int(self.graph.decay_edges(
                factor=0.92, below_weight=0.05, older_than_hours=168.0))
        except Exception as e:
            report.notes.append(f"decay failed: {e}")
        rules = []
        try:
            rules = self._extract_causal_rules(hours=hours, min_support=3,
                                               min_confidence=0.6)
            report.rules_extracted = len(rules)
            report.rules = [r.to_dict() for r in rules[:20]]
        except Exception as e:
            report.notes.append(f"rules failed: {e}")
        # Phase 11B — LLM-assisted causal hypotheses (env-gated, fail-safe)
        if _llm_causal_enabled() and rules:
            try:
                hyps = self._generate_causal_hypotheses(rules,
                                                         min_support=5,
                                                         min_confidence=0.7,
                                                         max_rules=5)
                report.causal_hypotheses_generated = len(hyps)
                report.causal_hypotheses = [h.to_dict() for h in hyps]
            except Exception as e:
                report.notes.append(f"llm causal hypotheses failed: {e}")
        try:
            self._update_self_archetypes(report=report)
        except Exception as e:
            report.notes.append(f"self_archetype failed: {e}")
        try:
            hyps = self._generate_hypotheticals(top_n=5)
            report.hypotheticals_generated = len(hyps)
            report.hypotheticals = hyps
        except Exception as e:
            report.notes.append(f"hypotheticals failed: {e}")
        try:
            cal = self.episodes.calibration(hours=24)
            if cal.get("brier") is not None:
                self.self_model.append_calibration(
                    brier=cal["brier"], n=cal["n"], ts=time.time())
        except Exception as e:
            report.notes.append(f"calibration capture failed: {e}")

        # Phase 12A — verify open hypotheses against fresh episodes
        if self.verifier is not None:
            try:
                report.hypothesis_verify = self.verifier.verify_pass()
            except Exception as e:
                report.notes.append(f"hypothesis verify failed: {e}")

        # Persist self_model after a consolidation pass
        try:
            self.self_model.save(force=True)
        except Exception as e:
            report.notes.append(f"self_model.save failed: {e}")

        # H1 — rotation (at most once per 24h)
        try:
            if time.time() - self._last_prune_ts > 24 * 3600:
                self._rotate_old_state(report=report)
                # Memory garbage disposal — dispose stale perceptual cache,
                # protect anything re-accessed/strengthened/emotional/spoken.
                try:
                    from brain.knowledge_store import KnowledgeStore
                    gc = KnowledgeStore().prune_stale()
                    report.knowledge_disposed = gc.get("disposed", 0)
                    if report.knowledge_disposed:
                        report.notes.append(
                            f"disposed {report.knowledge_disposed} stale memories "
                            f"({gc.get('kept')} kept)")
                except Exception as e:
                    report.notes.append(f"knowledge GC failed: {e}")
                self._last_prune_ts = time.time()
        except Exception as e:
            report.notes.append(f"rotation failed: {e}")

        report.duration_s = round(time.time() - t0, 3)
        self._last_pass = report
        self._pass_count += 1
        return report

    # -- (1) replay ------------------------------------------------------

    def _replay_successful_chains(self, *, hours: int,
                                  report: ConsolidationReport,
                                  min_chain_len: int = 3,
                                  min_reward: float = 0.4) -> None:
        """Pull recent successful episode chains (same session, sequential
        IDs) and reinforce 'precedes' edges between their action entities."""
        rows = self.episodes.recent(limit=2000)
        # Group by session, ordered by id ASC
        sessions: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
        cutoff = time.time() - hours * 3600
        for r in rows:
            if (r.get("ts") or 0) < cutoff:
                continue
            sid = r.get("session_id") or ""
            sessions[sid].append(r)

        chains_replayed = 0
        edges_boosted = 0
        for sid, eps in sessions.items():
            eps.sort(key=lambda x: x.get("id", 0))
            # Slide a window; collect runs of successes
            run: List[Dict[str, Any]] = []
            for ep in eps:
                if ep.get("success") == 1 and (ep.get("reward") or 0) >= min_reward:
                    run.append(ep)
                else:
                    if len(run) >= min_chain_len:
                        chains_replayed += 1
                        edges_boosted += self._reinforce_run(run)
                    run = []
            if len(run) >= min_chain_len:
                chains_replayed += 1
                edges_boosted += self._reinforce_run(run)

        report.chains_replayed = chains_replayed
        report.chain_edges_reinforced = edges_boosted

    def _reinforce_run(self, run: List[Dict[str, Any]]) -> int:
        """Boost graph 'precedes' weight along a successful run of episodes."""
        action_ids: List[int] = []
        for ep in run:
            an = ep.get("action_name")
            if not an:
                continue
            try:
                aid = self.graph.entity_get_or_create("action", an)
                action_ids.append(aid)
            except Exception:
                pass
        if len(action_ids) < 2:
            return 0
        return self.graph.reinforce_chain(action_ids, weight_delta=0.4)

    # -- (2) compress ----------------------------------------------------

    def _compress_repetitive(self, *, hours: int,
                              report: ConsolidationReport,
                              min_count: int = 4,
                              min_chain_len: int = 2) -> None:
        """Detect identical sub-sequences (action_name + arg_signature) that
        recur. Each surviving pattern becomes a concept entity 'macro_*'."""
        rows = self.episodes.recent(limit=3000)
        cutoff = time.time() - hours * 3600
        # Build session-ordered sequences of (action, sig)
        sessions: Dict[str, List[Tuple[str, str]]] = collections.defaultdict(list)
        for r in rows:
            if (r.get("ts") or 0) < cutoff:
                continue
            sid = r.get("session_id") or ""
            sessions[sid].append((r.get("action_name") or "", r.get("arg_signature") or ""))

        # Count length-N sliding windows across all sessions (N=2..4)
        pattern_counts: collections.Counter = collections.Counter()
        for sid, seq in sessions.items():
            for N in (2, 3, 4):
                for i in range(len(seq) - N + 1):
                    window = tuple(seq[i:i + N])
                    pattern_counts[window] += 1

        created = 0
        for pattern, count in pattern_counts.most_common(50):
            if count < min_count or len(pattern) < min_chain_len:
                continue
            tag = self._pattern_signature(pattern)
            try:
                self.graph.entity_get_or_create(
                    "concept", f"macro_{tag}",
                    salience=1.0 + count * 0.1,
                    metadata={
                        "pattern": [{"action": a, "sig": s} for (a, s) in pattern],
                        "observed_count": count,
                    },
                )
                created += 1
            except Exception:
                pass
        report.macros_created = created

    @staticmethod
    def _pattern_signature(pattern: Tuple[Tuple[str, str], ...]) -> str:
        import hashlib
        joined = "→".join(f"{a}{s}" for (a, s) in pattern)
        return hashlib.sha1(joined.encode("utf-8")).hexdigest()[:10]

    # -- (4) causal rules ------------------------------------------------

    def _extract_causal_rules(self, *, hours: int, min_support: int,
                              min_confidence: float) -> List[CausalRule]:
        """Mine simple A→B precedes patterns with conditional success rates.

        For each pair (A, B) where B follows A within the same session
        within 30s, compute P(B success | A success) and support count.
        Keep the ones above threshold.
        """
        rows = self.episodes.recent(limit=3000)
        cutoff = time.time() - hours * 3600
        sessions: Dict[str, List[Dict[str, Any]]] = collections.defaultdict(list)
        for r in rows:
            if (r.get("ts") or 0) < cutoff:
                continue
            sid = r.get("session_id") or ""
            sessions[sid].append(r)
        for eps in sessions.values():
            eps.sort(key=lambda x: x.get("id", 0))

        # pair_data: (A, B) → list of (latency_ms_between, B_success, A_success)
        pair_data: Dict[Tuple[str, str], List[Tuple[float, int, int]]] = collections.defaultdict(list)
        for sid, eps in sessions.items():
            for i in range(len(eps) - 1):
                a = eps[i]
                b = eps[i + 1]
                a_name = a.get("action_name") or ""
                b_name = b.get("action_name") or ""
                if not a_name or not b_name or a_name == b_name:
                    continue
                gap = (b.get("ts", 0) - a.get("ts", 0)) * 1000  # ms
                if gap > 30_000:  # >30s = different intent, skip
                    continue
                pair_data[(a_name, b_name)].append(
                    (gap, int(b.get("success") or 0), int(a.get("success") or 0))
                )

        rules: List[CausalRule] = []
        for (a_name, b_name), observations in pair_data.items():
            n = len(observations)
            if n < min_support:
                continue
            n_a_success = sum(1 for _, _, asucc in observations if asucc)
            n_b_given_a_success = sum(
                1 for _, bsucc, asucc in observations if asucc and bsucc
            )
            if n_a_success == 0:
                continue
            confidence = n_b_given_a_success / n_a_success
            if confidence < min_confidence:
                continue
            avg_latency = sum(g for g, _, _ in observations) / n
            avg_outcome = sum(bsucc for _, bsucc, _ in observations) / n
            rules.append(CausalRule(
                antecedent=a_name,
                consequent=b_name,
                confidence=round(confidence, 3),
                support=n,
                avg_latency_ms=round(avg_latency, 1),
                avg_outcome=round(avg_outcome, 3),
            ))
        rules.sort(key=lambda r: -(r.confidence * r.support))
        return rules

    # -- (5) self model archetype update ---------------------------------

    def _update_self_archetypes(self, *, report: ConsolidationReport) -> None:
        # SelfModel.archetypes() is derived, but force a save so the disk
        # snapshot includes the latest scores.
        snap = self.self_model.snapshot()
        report.notes.append(
            "archetypes: " + ", ".join(
                f"{k}={v}" for k, v in snap.get("archetypes", {}).items()
            )
        )
        report.self_archetypes_updated = True

    # -- (6) hypotheticals ----------------------------------------------

    def _generate_hypotheticals(self, *, top_n: int = 5) -> List[Dict[str, Any]]:
        """Generate 'what if I tried X next' candidates for active-mode planning.

        Pulls top entities + loudest drives + recent calibration. Returns
        small list of candidate (action, args, expected_utility) records.
        Used by active mode (when enabled) as an exploration nudge.
        """
        hyps: List[Dict[str, Any]] = []
        try:
            top_actions = self.graph.top_entities("action", limit=15)
            loudest = self.drives.loudest()
            for ent in top_actions[:top_n]:
                action_name = ent["name"]
                pred = self.world_model.predict("tool", action_name, {},
                                                self._build_minimal_context())
                hyps.append({
                    "action": action_name,
                    "p_success": round(pred.p_success, 3),
                    "method": pred.method,
                    "mention_count": ent["mention_count"],
                    "salience": round(ent["salience"], 3),
                    "loudest_drive_at_gen": loudest,
                })
        except Exception as e:
            log.warning("generate_hypotheticals failed: %s", e)
        return hyps

    def _build_minimal_context(self):
        from brain.cognition.episodes import Context
        ctx = Context(ts=time.time(),
                      nm={"dopamine": 0.5, "acetylcholine": 0.3,
                          "norepinephrine": 0.1, "serotonin": 0.5},
                      dev_stage="UNKNOWN", active_app=None,
                      hour=time.localtime().tm_hour, dow=time.localtime().tm_wday,
                      user_present=True)
        ctx.compute_bucket()
        return ctx

    # ── Phase 11B — LLM-assisted causal explanations ─────────────────────

    def _generate_causal_hypotheses(
        self,
        rules: List[CausalRule],
        *,
        min_support: int = 5,
        min_confidence: float = 0.7,
        max_rules: int = 5,
    ) -> List[CausalHypothesis]:
        """For each statistical causal rule that meets the support/confidence
        floor, ask Claude (via `claude -p` subprocess) for a plausible
        explanation. Stored as 'hypothesis' with status='unverified'.

        SAFETY: hypotheses are NEVER generated for rules below the floor.
        The Claude output is NOT treated as ground truth — it's a candidate
        explanation tagged for future corroboration.
        """
        eligible = [r for r in rules
                    if r.support >= min_support and r.confidence >= min_confidence]
        eligible = eligible[:max_rules]
        if not eligible:
            return []
        # M2 fix: dedupe against already-stored hypotheses BEFORE the LLM call.
        # Without this, a stable rule (cause→effect) re-fires the claude -p
        # subprocess every consolidation pass — 96 redundant calls/day at the
        # 15-min sleep cadence. We keep the existing hypothesis live (touch
        # last_seen + support/confidence) but skip the LLM round-trip.
        existing = self._existing_hypothesis_keys()
        out: List[CausalHypothesis] = []
        for rule in eligible:
            key = self._hypothesis_key(rule.antecedent, rule.consequent)
            if key in existing:
                # Refresh metadata cheaply, no LLM call.
                try:
                    self._touch_hypothesis(key, support=rule.support,
                                           confidence=rule.confidence)
                except Exception as e:
                    log.debug("touch hypothesis failed: %s", e)
                continue
            try:
                explanation = self._ask_claude_for_explanation(rule)
            except Exception as e:
                log.warning("LLM causal explanation failed for %s→%s: %s",
                            rule.antecedent, rule.consequent, e)
                continue
            if not explanation or len(explanation.strip()) < 5:
                continue
            now = time.time()
            h = CausalHypothesis(
                cause=rule.antecedent,
                effect=rule.consequent,
                support=rule.support,
                confidence=rule.confidence,
                hypothesis=explanation.strip()[:600],
                status="unverified",
                first_seen=now,
                last_seen=now,
            )
            out.append(h)
            self._persist_hypothesis(h)
        return out

    # H1 rotation ────────────────────────────────────────────────────────
    def _rotate_old_state(self, *, report: ConsolidationReport) -> None:
        """Trim episodes.db + jsonl files to bounded sizes. Called at most
        once per 24h from consolidate_pass."""
        # 1. Episodes table — delete rows older than 30 days.
        try:
            n = self.episodes.prune_older_than(days=30)
            report.episodes_pruned = int(n or 0)
            if n:
                log.info("rotation: pruned %d episodes older than 30 days", n)
        except Exception as e:
            log.warning("episodes prune failed: %s", e)

        # 2. JSONL files — tail-rewrite to keep last N lines.
        jsonl_targets = [
            (_default_hypothesis_store_path(), 10_000),
            (os.path.join(os.path.dirname(_default_hypothesis_store_path()),
                          "active_mode_audit.jsonl"), 50_000),
        ]
        total_pruned = 0
        for path, keep in jsonl_targets:
            try:
                pruned = self._tail_rewrite_jsonl(path, keep_lines=keep)
                total_pruned += pruned
                if pruned:
                    log.info("rotation: trimmed %s by %d lines", path, pruned)
            except Exception as e:
                log.warning("tail rewrite failed for %s: %s", path, e)
        report.jsonl_lines_pruned = total_pruned

    @staticmethod
    def _tail_rewrite_jsonl(path: str, *, keep_lines: int) -> int:
        """Keep only the last N lines of a JSONL file. Atomic via os.replace.
        Returns number of lines pruned (0 if file missing or already small).
        """
        if not os.path.exists(path):
            return 0
        with open(path) as f:
            lines = f.readlines()
        if len(lines) <= keep_lines:
            return 0
        kept = lines[-keep_lines:]
        tmp = path + ".rotate.tmp"
        with open(tmp, "w") as f:
            f.writelines(kept)
        os.replace(tmp, path)
        return len(lines) - len(kept)

    # M2 helpers ─────────────────────────────────────────────────────────
    @staticmethod
    def _hypothesis_key(cause: str, effect: str) -> str:
        return f"{cause}→{effect}"

    def _existing_hypothesis_keys(self) -> set:
        """Read all stored hypotheses once per pass and return their keys."""
        keys: set = set()
        path = _default_hypothesis_store_path()
        if not os.path.exists(path):
            return keys
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                    except Exception:
                        continue
                    c = d.get("cause"); e = d.get("effect")
                    if c and e:
                        keys.add(self._hypothesis_key(c, e))
        except Exception as ex:
            log.debug("existing hypothesis read failed: %s", ex)
        return keys

    def _touch_hypothesis(self, key: str, *, support: int, confidence: float) -> None:
        """Append a lightweight touch line; on next pass the dedupe sees the
        original. Avoids the cost of rewriting the file."""
        path = _default_hypothesis_store_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "a") as f:
                f.write(json.dumps({
                    "type": "touch",
                    "key": key,
                    "support": support,
                    "confidence": confidence,
                    "ts": time.time(),
                }) + "\n")
        except Exception as e:
            log.debug("touch_hypothesis write failed: %s", e)

    def _ask_claude_for_explanation(self, rule: CausalRule) -> str:
        """Call `claude -p` with a focused prompt. Short timeout — if it
        fails or times out, skip this rule (don't block consolidation)."""
        prompt = (
            "You are analyzing a statistical pattern observed in Leon's "
            "(an AI brain's) action history.\n\n"
            f"Pattern: action '{rule.antecedent}' often precedes action "
            f"'{rule.consequent}' (within 30 seconds, same session).\n"
            f"Support: {rule.support} observed pairs.\n"
            f"Confidence P({rule.consequent} succeeds | {rule.antecedent} succeeds) = "
            f"{rule.confidence:.2f}.\n"
            f"Average latency between them: {rule.avg_latency_ms:.0f}ms.\n\n"
            "In one short sentence (under 25 words), suggest the most plausible "
            "causal explanation for WHY this pattern exists. Be concrete. "
            "Do not speculate beyond the data. Do not propose unrelated theories.\n\n"
            "Reply with just the explanation sentence, no preamble."
        )
        try:
            # Strip ANTHROPIC_API_KEY (dead) so CLI uses OAuth Max plan
            env = os.environ.copy()
            env.pop("ANTHROPIC_API_KEY", None)
            r = subprocess.run(
                ["claude", "-p",
                 "--model", "haiku",
                 "--effort", "low",
                 "--no-session-persistence",
                 prompt],
                capture_output=True, text=True, timeout=20, env=env,
            )
            if r.returncode != 0:
                log.warning("claude returncode %d for causal explanation", r.returncode)
                return ""
            return r.stdout.strip()
        except subprocess.TimeoutExpired:
            log.warning("claude timeout for causal explanation")
            return ""

    @staticmethod
    def _persist_hypothesis(h: CausalHypothesis) -> None:
        """Append to brain_state/causal_hypotheses.jsonl."""
        try:
            path = _default_hypothesis_store_path()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "a") as f:
                f.write(json.dumps(h.to_dict()) + "\n")
        except Exception as e:
            log.warning("hypothesis persist failed: %s", e)

    def recent_hypotheses(self, limit: int = 50) -> List[Dict[str, Any]]:
        path = _default_hypothesis_store_path()
        if not os.path.exists(path):
            return []
        try:
            with open(path) as f:
                # Read more than limit so touch-line filtering still hits limit
                # real hypotheses on a busy store.
                lines = f.readlines()[-(limit * 4):]
            out: List[Dict[str, Any]] = []
            for line in lines:
                if not line.strip():
                    continue
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get("type") == "touch":  # M2: skip dedupe-touch records
                    continue
                out.append(d)
            return out[-limit:]
        except Exception as e:
            log.warning("recent_hypotheses read failed: %s", e)
            return []

    # -- hook into existing SleepConsolidator ----------------------------

    def install_sleep_hook(self) -> bool:
        """Wrap SleepConsolidator.consolidate so our pass runs alongside it.

        Idempotent — checks for marker attribute.
        """
        if self.sleep is None or self._installed_hook:
            return False
        original = self.sleep.consolidate
        if getattr(original, "_cognition_wrapped", False):
            return False

        def wrapped(*args, **kwargs):
            original_result = original(*args, **kwargs)
            try:
                self.consolidate_pass()
            except Exception as e:
                log.warning("consolidation pass during sleep failed: %s", e)
            return original_result

        wrapped._cognition_wrapped = True  # type: ignore[attr-defined]
        self.sleep.consolidate = wrapped
        self._installed_hook = True
        return True

    # -- inspection ------------------------------------------------------

    def last_pass(self) -> Optional[Dict[str, Any]]:
        return self._last_pass.to_dict() if self._last_pass else None

    def stats(self) -> Dict[str, Any]:
        return {
            "pass_count": self._pass_count,
            "sleep_hook_installed": self._installed_hook,
            "last_pass": self.last_pass(),
        }
