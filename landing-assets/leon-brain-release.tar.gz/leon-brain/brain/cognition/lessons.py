"""
Phase 13 — Lessons / Corrections.

Captures Dean's corrections into a persistent rule store. The whole point:
when Dean says "stop doing X" or "always do Y", that guidance must influence
Leon's future behavior FOREVER, not just for the current Claude turn.

Three sources feed this store:

  1) Explicit  — Dean says "remember:", "don't do that", "stop doing X",
                 "always Y", etc. The responder calls .capture_from_turn(...)
                 on every user turn; the heuristic matcher pulls candidates.
  2) Implicit  — Dean repeats the SAME correction multiple times for the same
                 topic; we boost weight on the relevant rule.
  3) Manual    — POST /api/cognition/lessons/add or skill_inventory tools.

A Lesson is:
  id (rowid), text, scope (global|tool:<name>|topic:<x>|app:<x>),
  polarity (do|dont), weight (0..1, decays slightly with disuse),
  created_ts, last_seen_ts, hit_count

Consumed by:
  • Executive — veto strategies that violate a do-not lesson
  • Prompt builder — inject up to N relevant lessons per turn
  • Suggestions — propose adherence reminders proactively
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.lessons")


_SCHEMA = """
CREATE TABLE IF NOT EXISTS lessons (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    text          TEXT NOT NULL,
    scope         TEXT NOT NULL DEFAULT 'global',
    polarity      TEXT NOT NULL DEFAULT 'dont',
    weight        REAL NOT NULL DEFAULT 0.5,
    created_ts    REAL NOT NULL,
    last_seen_ts  REAL NOT NULL,
    hit_count     INTEGER NOT NULL DEFAULT 1,
    source        TEXT
);
CREATE INDEX IF NOT EXISTS idx_lessons_scope ON lessons(scope);
CREATE INDEX IF NOT EXISTS idx_lessons_weight ON lessons(weight DESC);
"""


# Heuristic patterns for capturing corrections. These are intentionally
# conservative — we want very high precision, low recall. False-positive
# lessons are worse than missed ones because they will hurt every prompt.
_PAT_DONT = re.compile(
    r"(?:please\s+)?(?:don'?t|do\s+not|never|stop|quit|cease)\s+(.+?)(?:[.!?]|$)",
    re.I,
)
_PAT_DO = re.compile(
    r"(?:please\s+)?(?:always|from\s+now\s+on|going\s+forward|remember\s+to)\s+(.+?)(?:[.!?]|$)",
    re.I,
)
_PAT_REMEMBER = re.compile(
    r"(?:remember\s+(?:that|this)?:?)\s*(.+?)(?:[.!?]|$)",
    re.I,
)

_MAX_LESSON_LEN = 240
_MIN_LESSON_LEN = 5
_DECAY_PER_DAY = 0.02
_WEIGHT_BOOST_REPEAT = 0.15
_WEIGHT_INIT = 0.6


@dataclass
class Lesson:
    id: int
    text: str
    scope: str
    polarity: str
    weight: float
    created_ts: float
    last_seen_ts: float
    hit_count: int
    source: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class LessonStore:
    """Persistent rule store. Sqlite, WAL, thread-safe."""

    def __init__(self, *, path: Optional[str] = None):
        self.path = path or os.path.expanduser("~/.leon/lessons.db")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass

    # -- capture -------------------------------------------------------

    def capture_from_turn(self, user_text: str,
                          *, source: str = "user") -> List[Lesson]:
        """Try to extract one or more lessons from a single Dean turn."""
        if not user_text or len(user_text) < _MIN_LESSON_LEN:
            return []
        out: List[Lesson] = []
        for pol, pat in (("dont", _PAT_DONT), ("do", _PAT_DO),
                         ("do", _PAT_REMEMBER)):
            for m in pat.finditer(user_text):
                clean = (m.group(1) or "").strip()
                clean = re.sub(r"\s+", " ", clean)
                if len(clean) < _MIN_LESSON_LEN or len(clean) > _MAX_LESSON_LEN:
                    continue
                if _looks_conversational(clean):
                    continue
                scope = _infer_scope(user_text, clean)
                lesson = self.add(text=clean, polarity=pol, scope=scope,
                                  source=source)
                if lesson is not None:
                    out.append(lesson)
        return out

    def add(
        self, *,
        text: str,
        polarity: str = "dont",
        scope: str = "global",
        source: Optional[str] = None,
    ) -> Optional[Lesson]:
        """Add or merge a lesson. If a near-duplicate exists, bump its weight."""
        text = (text or "").strip()
        if len(text) < _MIN_LESSON_LEN or len(text) > _MAX_LESSON_LEN:
            return None
        if polarity not in ("do", "dont"):
            polarity = "dont"
        now = time.time()
        with self._lock:
            # near-duplicate check (case-insensitive substring within scope)
            dup = self._find_duplicate(text, scope)
            if dup is not None:
                new_weight = min(1.0, dup["weight"] + _WEIGHT_BOOST_REPEAT)
                self._conn.execute(
                    "UPDATE lessons SET last_seen_ts=?, hit_count=hit_count+1, weight=? WHERE id=?",
                    (now, new_weight, dup["id"]),
                )
                row = self._conn.execute(
                    "SELECT * FROM lessons WHERE id=?", (dup["id"],),
                ).fetchone()
                return _row(row)
            cur = self._conn.execute(
                """INSERT INTO lessons
                    (text, scope, polarity, weight, created_ts, last_seen_ts, hit_count, source)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (text, scope, polarity, _WEIGHT_INIT, now, now, 1, source),
            )
            row = self._conn.execute(
                "SELECT * FROM lessons WHERE id=?", (cur.lastrowid,),
            ).fetchone()
        log.info("captured lesson [%s,%s] %s", scope, polarity, text[:80])
        return _row(row)

    # -- query ---------------------------------------------------------

    def all(self, *, limit: int = 200) -> List[Lesson]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM lessons ORDER BY weight DESC, last_seen_ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        self._apply_decay(rows)
        return [_row(r) for r in rows]

    def relevant(
        self, *,
        text: str = "",
        scope_hints: Optional[List[str]] = None,
        limit: int = 6,
    ) -> List[Lesson]:
        """Return the top-K lessons relevant to the current turn.

        Relevance scoring:
          • exact scope match           +1.0
          • scope == 'global'           +0.3
          • token overlap with `text`   +0.5 * overlap_ratio
          • base weight                 +1.0 * weight
          • recency (last 7d)           +0.2
        """
        hints = set(scope_hints or [])
        hints.add("global")
        now = time.time()
        text_tokens = set(_tokens(text or ""))
        rows = self.all(limit=200)
        scored: List[Tuple[float, Lesson]] = []
        for L in rows:
            score = 1.0 * L.weight
            if L.scope in hints:
                score += 1.0 if L.scope != "global" else 0.3
            if text_tokens:
                lt = set(_tokens(L.text))
                if lt:
                    overlap = len(text_tokens & lt) / max(1, len(lt))
                    score += 0.5 * overlap
            if (now - L.last_seen_ts) < 7 * 86400:
                score += 0.2
            scored.append((score, L))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [L for _, L in scored[:limit]]

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            n = self._conn.execute("SELECT COUNT(*) AS n FROM lessons").fetchone()["n"]
            by_scope = self._conn.execute(
                "SELECT scope, COUNT(*) AS n FROM lessons GROUP BY scope"
            ).fetchall()
            by_pol = self._conn.execute(
                "SELECT polarity, COUNT(*) AS n FROM lessons GROUP BY polarity"
            ).fetchall()
        return {
            "total": n,
            "by_scope": {r["scope"]: r["n"] for r in by_scope},
            "by_polarity": {r["polarity"]: r["n"] for r in by_pol},
        }

    def remove(self, lesson_id: int) -> bool:
        with self._lock:
            cur = self._conn.execute("DELETE FROM lessons WHERE id=?", (lesson_id,))
            return cur.rowcount > 0

    # -- internals -----------------------------------------------------

    def _find_duplicate(self, text: str, scope: str):
        rows = self._conn.execute(
            "SELECT id, weight FROM lessons WHERE scope=?", (scope,),
        ).fetchall()
        ttl = text.lower()
        for r in rows:
            existing_text = self._conn.execute(
                "SELECT text FROM lessons WHERE id=?", (r["id"],),
            ).fetchone()["text"].lower()
            if ttl == existing_text:
                return r
            # cheap substring containment counts as dup
            if len(ttl) > 12 and (ttl in existing_text or existing_text in ttl):
                return r
        return None

    def _apply_decay(self, rows) -> None:
        """Apply mild weight decay for rows we just read but haven't seen
        recently. Cheap; runs at most once per query."""
        now = time.time()
        for r in rows:
            age_days = (now - (r["last_seen_ts"] or now)) / 86400.0
            if age_days < 7:
                continue
            decay = min(0.5, age_days * _DECAY_PER_DAY)
            new_w = max(0.05, (r["weight"] or 0.0) - decay)
            try:
                self._conn.execute(
                    "UPDATE lessons SET weight=? WHERE id=? AND weight>?",
                    (new_w, r["id"], new_w),
                )
            except Exception:
                pass


def _row(row) -> Lesson:
    return Lesson(
        id=row["id"], text=row["text"],
        scope=row["scope"] or "global",
        polarity=row["polarity"] or "dont",
        weight=float(row["weight"] or 0.0),
        created_ts=float(row["created_ts"] or 0.0),
        last_seen_ts=float(row["last_seen_ts"] or 0.0),
        hit_count=int(row["hit_count"] or 0),
        source=row["source"],
    )


def _tokens(s: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]{3,}", s.lower())][:64]


def _looks_conversational(text: str) -> bool:
    """Reject obvious conversational filler that isn't a real correction."""
    t = text.lower().strip()
    if len(t) > 200:
        return True
    if any(t.startswith(p) for p in (
        "worry about", "be silly", "be late", "make me", "tell me",
        "make sense", "say a", "talk like", "talking like",
        "be like", "ask me",
    )):
        return False  # these are usually genuine corrections, keep them
    if any(t.endswith(p) for p in ("right", "really", "i guess", "i mean")):
        return True
    return False


def _infer_scope(full_text: str, lesson_text: str) -> str:
    """Best-effort scope inference. Default 'global'."""
    low = (full_text + " " + lesson_text).lower()
    # tool scope
    m = re.search(r"\b(tool|use|using|call|fire|run)\s+([a-z_][a-z0-9_.]+)\b", low)
    if m:
        cand = m.group(2)
        if "." in cand or "_" in cand:
            return f"tool:{cand}"
    # app scope
    for app in ("brave", "chrome", "spotify", "discord", "slack", "vscode",
                "code", "obsidian", "soundcloud", "gmail", "calendar"):
        if app in low:
            return f"app:{app}"
    return "global"


__all__ = ["LessonStore", "Lesson"]
