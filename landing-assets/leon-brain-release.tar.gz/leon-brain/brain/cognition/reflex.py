"""
Phase 13 — Reflex layer.

Sub-250ms local responses that don't need Claude. The reflex layer is
specifically for turns where Leon can answer from its own state alone:

  • "what's your dopamine"  → read NM
  • "are you ok"            → state probe
  • "how do you feel"       → drive + NM summary
  • "what time is it"       → time.strftime
  • "what app am I on"      → awareness snapshot
  • "what's running"        → top procs (cached)
  • "how many tabs"         → awareness brave_tabs
  • "are you broken"        → tool_health summary
  • "any errors"            → recent_failures

Critical: this layer is **confidence-gated**. If no high-confidence reflex
matches the input, .respond() returns None and the executive falls through
to its normal path. We NEVER guess and reply with low-confidence reflex —
that would feel robotic.

This is NOT the same as canned replies (which are static text matches in
the responder). Reflex pulls live state.

Design:
  • Pure-Python, dataclass output. No I/O beyond the awareness/cognition
    handles passed in.
  • Returns a ReflexAnswer with text, confidence, source — caller decides
    whether to use it.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.cognition.reflex")


@dataclass
class ReflexAnswer:
    text: str
    confidence: float
    source: str        # which reflex matched
    latency_ms: float

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Pattern → reflex handler table ─────────────────────────────────────────


def _state(s: str) -> List[re.Pattern]:
    return [re.compile(p, re.I) for p in s.strip().splitlines() if p.strip()]


_PAT_HOW_FEEL = _state(r"""
^\s*how (?:do|are) you (?:feel|feeling|doing)\??\s*$
^\s*how('?s| is) it going\??\s*$
^\s*are you (?:ok|okay|alright|good)\??\s*$
^\s*you (?:ok|okay|good)\??\s*$
""")

_PAT_DOPAMINE = _state(r"""
^\s*(?:what'?s|how('?s| is)) your (?:dopamine|do?p)\??\s*$
^\s*dopamine(?:\s+level)?\??\s*$
""")

_PAT_NM_GENERIC = _state(r"""
^\s*(?:what'?s|how('?s| is)) your (?:acetylcholine|ach|seroton(?:in|en)|norepinephrine|ne|adrenaline)\??\s*$
^\s*(?:acetylcholine|ach|serotonin|seroten|norepinephrine|noradrenaline)\??\s*$
""")

_PAT_BRAIN_STATE = _state(r"""
^\s*(?:what'?s|how('?s| is)) your (?:state|brain(?:\s+state)?|head|mind)\??\s*$
^\s*brain (?:state|status)\??\s*$
^\s*how('?s| is) the brain\??\s*$
""")

_PAT_TIME = _state(r"""
^\s*what(?:\s+(?:time|day|date))\s+is it\??\s*$
^\s*what(?:'?s| is) the (?:time|date|day)\??\s*$
^\s*what day is it\??\s*$
""")

_PAT_APP = _state(r"""
^\s*what (?:app|window|program) (?:am i|are you|is) (?:on|using|in)\??\s*$
^\s*where am i\??\s*$
^\s*what(?:'?s| is) (?:in )?focus\??\s*$
""")

_PAT_TABS = _state(r"""
^\s*how many tabs(?:\s+(?:do i have|are open))?\??\s*$
^\s*tab count\??\s*$
""")

_PAT_HEALTH = _state(r"""
^\s*are you (?:broken|degraded|healthy)\??\s*$
^\s*tool (?:health|status)\??\s*$
^\s*any (?:broken|degraded) tools\??\s*$
^\s*what(?:'?s| is) broken\??\s*$
""")

_PAT_AWARENESS = _state(r"""
^\s*what do you see\??\s*$
^\s*what'?s going on\??\s*$
^\s*what'?s up\??\s*$
""")

# Phase 14 — additional high-confidence local patterns
_PAT_SESSION = _state(r"""
^\s*how long(?: have)? (?:i|you) been (?:here|working|on this|at it)\??\s*$
^\s*session (?:time|length|duration)\??\s*$
""")

_PAT_LOAD = _state(r"""
^\s*(?:what'?s the |how'?s the )?(?:system )?load(?: avg)?\??\s*$
^\s*cpu(?: load)?\??\s*$
""")

_PAT_MEMORY = _state(r"""
^\s*(?:what'?s the |how much )?(?:ram|memory) (?:used|usage|free)?\??\s*$
""")

_PAT_DEAR = _state(r"""
^\s*are you (?:listening|online|up|alive|awake)\??\s*$
^\s*you (?:listening|alive|there)\??\s*$
""")

_PAT_NETWORK = _state(r"""
^\s*(?:is the )?(?:internet|network|wifi) (?:up|on|working|connected)\??\s*$
^\s*am i (?:online|connected)\??\s*$
""")

_PAT_STAGE = _state(r"""
^\s*what (?:developmental |dev )?stage (?:are you|is the brain)(?:\s+(?:in|at))?\??\s*$
^\s*how (?:mature|old|developed) are you\??\s*$
""")

_PAT_STATS = _state(r"""
^\s*(?:how many|stats|status) (?:neurons|synapses|episodes|tools)\??\s*$
^\s*(?:tool|episode|skill) count\??\s*$
""")

_PAT_BUSY = _state(r"""
^\s*are you (?:busy|working on (?:anything|something))\??\s*$
^\s*what are you (?:doing|up to)\??\s*$
""")


class ReflexLayer:
    """Local state-aware reflex responder."""

    def __init__(self, *, brain=None, awareness=None, tool_health=None,
                 drives=None, gates=None):
        self.brain = brain
        self.awareness = awareness
        self.tool_health = tool_health
        self.drives = drives
        self.gates = gates

    def respond(self, text: str) -> Optional[ReflexAnswer]:
        """Try to answer from local state. Returns None on no-match."""
        if not text:
            return None
        t0 = time.monotonic()
        clean = text.strip()
        if len(clean) > 80:
            return None  # reflex is for short turns only

        # 1) Brain-state class
        if _any_match(_PAT_HOW_FEEL, clean):
            return self._make(self._feel_answer(), 0.92, "how_feel", t0)
        if _any_match(_PAT_DOPAMINE, clean):
            return self._make(self._nm_answer("dopamine"), 0.93, "dopamine", t0)
        if _any_match(_PAT_NM_GENERIC, clean):
            return self._make(self._nm_generic_answer(clean), 0.85, "nm_generic", t0)
        if _any_match(_PAT_BRAIN_STATE, clean):
            return self._make(self._brain_state_answer(), 0.88, "brain_state", t0)

        # 2) Time
        if _any_match(_PAT_TIME, clean):
            return self._make(self._time_answer(clean), 0.99, "time", t0)

        # 3) Awareness-based
        if _any_match(_PAT_APP, clean):
            return self._make(self._app_answer(), 0.85, "active_app", t0)
        if _any_match(_PAT_TABS, clean):
            return self._make(self._tabs_answer(), 0.85, "brave_tabs", t0)
        if _any_match(_PAT_AWARENESS, clean):
            return self._make(self._awareness_answer(), 0.7, "awareness", t0)

        # 4) Tool health
        if _any_match(_PAT_HEALTH, clean):
            return self._make(self._health_answer(), 0.88, "tool_health", t0)

        # Phase 14 — additional local patterns
        if _any_match(_PAT_DEAR, clean):
            return self._make("Listening.", 0.97, "presence", t0)
        if _any_match(_PAT_LOAD, clean):
            return self._make(self._load_answer(), 0.92, "loadavg", t0)
        if _any_match(_PAT_MEMORY, clean):
            return self._make(self._memory_answer(), 0.92, "memory", t0)
        if _any_match(_PAT_NETWORK, clean):
            return self._make(self._network_answer(), 0.93, "network", t0)
        if _any_match(_PAT_STAGE, clean):
            return self._make(self._stage_answer(), 0.88, "stage", t0)
        if _any_match(_PAT_SESSION, clean):
            return self._make(self._session_answer(), 0.86, "session", t0)
        if _any_match(_PAT_STATS, clean):
            return self._make(self._stats_answer(clean), 0.84, "stats", t0)
        if _any_match(_PAT_BUSY, clean):
            return self._make(self._busy_answer(), 0.82, "busy", t0)

        return None

    # -- answer builders ----------------------------------------------

    def _feel_answer(self) -> str:
        nm = self._nm()
        loud = None
        if self.drives is not None:
            try:
                loud = self.drives.loudest()
            except Exception:
                loud = None
        bits = []
        da = nm.get("dopamine")
        if da is not None:
            if da > 0.7:
                bits.append("motivated")
            elif da < 0.3:
                bits.append("flat")
            else:
                bits.append("steady")
        ach = nm.get("acetylcholine")
        if ach is not None:
            if ach > 0.7:
                bits.append("focused")
            elif ach < 0.3:
                bits.append("diffuse")
        ne = nm.get("norepinephrine")
        if ne is not None and ne > 0.7:
            bits.append("alert")
        if loud:
            bits.append(f"drive: {loud}")
        if not bits:
            return "Online."
        return "Feeling " + ", ".join(bits) + "."

    def _nm_answer(self, key: str) -> str:
        v = self._nm().get(key)
        if v is None:
            return "No reading."
        return f"{key} {v:.2f}."

    def _nm_generic_answer(self, text: str) -> str:
        nm = self._nm()
        low = text.lower()
        for k in ("dopamine", "acetylcholine", "serotonin", "norepinephrine"):
            if k in low:
                v = nm.get(k)
                if v is not None:
                    return f"{k} {v:.2f}."
        # Generic fallback
        parts = [f"{k}={v:.2f}" for k, v in nm.items() if isinstance(v, (int, float))]
        return ("nm " + " ".join(parts[:4])) if parts else "No nm reading."

    def _brain_state_answer(self) -> str:
        nm = self._nm()
        parts = []
        if nm:
            for k in ("dopamine", "acetylcholine", "serotonin", "norepinephrine"):
                v = nm.get(k)
                if isinstance(v, (int, float)):
                    parts.append(f"{k[:2]}={v:.2f}")
        snap = self._awareness_snap()
        if snap:
            app = snap.get("active_app")
            if app:
                parts.append(f"app={app}")
        return " ".join(parts) if parts else "State quiet."

    def _time_answer(self, text: str) -> str:
        low = text.lower()
        if "day" in low or "date" in low:
            return time.strftime("%A %B %d.")
        return time.strftime("%I:%M %p.").lstrip("0")

    def _app_answer(self) -> str:
        snap = self._awareness_snap()
        if not snap:
            return "Can't see — awareness asleep."
        app = snap.get("active_app") or "unknown"
        title = (snap.get("active_title") or "").split(" - ")[-1][:60]
        if title and title.lower() != app.lower():
            return f"{app} — {title}."
        return f"{app}."

    def _tabs_answer(self) -> str:
        snap = self._awareness_snap()
        if not snap or snap.get("brave_tabs") is None:
            return "Brave isn't reachable."
        n = snap["brave_tabs"]
        return f"{n} tab{'s' if n != 1 else ''} open."

    def _awareness_answer(self) -> str:
        snap = self._awareness_snap()
        if not snap:
            return "Quiet."
        bits = []
        if snap.get("active_app"):
            bits.append(snap["active_app"])
        if snap.get("brave_tabs"):
            bits.append(f"{snap['brave_tabs']} tabs")
        if snap.get("is_idle"):
            bits.append(f"idle {int(snap.get('idle_secs', 0))}s")
        if snap.get("load_avg_1m") is not None:
            bits.append(f"load {snap['load_avg_1m']:.2f}")
        return ", ".join(bits) if bits else "All quiet."

    def _health_answer(self) -> str:
        if self.tool_health is None:
            return "Tool health not tracking yet."
        try:
            s = self.tool_health.summary()
        except Exception as e:
            return f"Health probe failed: {e}"
        bits = []
        for k in ("healthy", "degraded", "broken", "untested"):
            v = s.get(k, 0)
            if v:
                bits.append(f"{v} {k}")
        if not bits:
            return "No tools observed yet."
        return ", ".join(bits) + "."

    # ── Phase 14 reflex answer builders ─────────────────────────────

    def _load_answer(self) -> str:
        snap = self._awareness_snap() or {}
        la = snap.get("load_avg_1m")
        if la is None:
            try:
                with open("/proc/loadavg") as f:
                    la = float(f.read().split()[0])
            except Exception:
                return "Load not readable."
        return f"Load {la:.2f}."

    def _memory_answer(self) -> str:
        snap = self._awareness_snap() or {}
        pct = snap.get("mem_pct")
        if pct is None:
            return "Memory not readable."
        return f"Memory {pct:.1f}% used."

    def _network_answer(self) -> str:
        snap = self._awareness_snap() or {}
        up = snap.get("network_up")
        if up is True:
            return "Online."
        if up is False:
            return "Offline."
        return "Unknown."

    def _stage_answer(self) -> str:
        if self.brain is None:
            return "Unknown."
        try:
            stage = getattr(self.brain, "developmental_stage", None) \
                or getattr(self.brain, "development_stage", None)
            return f"{stage}." if stage else "Unknown."
        except Exception:
            return "Unknown."

    def _session_answer(self) -> str:
        snap = self._awareness_snap() or {}
        age = snap.get("session_age_s")
        if age is None:
            return "No session tracking."
        if age < 60:
            return f"{int(age)}s in this session."
        if age < 3600:
            return f"{int(age/60)} min in this session."
        return f"{age/3600:.1f}h in this session."

    def _stats_answer(self, text: str) -> str:
        low = text.lower()
        if "neuron" in low:
            n = getattr(self.brain, "n_neurons", None) if self.brain else None
            if n is None and self.brain:
                # try state dict
                try:
                    n = (self.brain.get_state() or {}).get("total_neurons")
                except Exception:
                    n = None
            return f"{n:,} neurons." if n else "Unknown."
        if "synapse" in low:
            try:
                syn = (self.brain.get_state() or {}).get("total_synapses")
                return f"{syn:,} synapses." if syn else "Unknown."
            except Exception:
                return "Unknown."
        if "tool" in low:
            if self.tool_health:
                s = self.tool_health.summary()
                return f"{s.get('total',0)} tracked, {s.get('healthy',0)} healthy."
            return "1,596 registered."
        if "episode" in low or "skill" in low:
            return "Check the dashboard."
        return "Unknown stat."

    def _busy_answer(self) -> str:
        snap = self._awareness_snap() or {}
        app = snap.get("active_app") or snap.get("active_title")
        if app:
            return f"Watching. You're on {str(app)[:40]}."
        return "Idle. Listening."

    # -- helpers -------------------------------------------------------

    def _nm(self) -> Dict[str, float]:
        if self.brain is None:
            return {}
        try:
            nm = getattr(self.brain, "neuromodulators", None)
            if isinstance(nm, dict):
                return {k: float(v) for k, v in nm.items()
                        if isinstance(v, (int, float))}
        except Exception:
            pass
        return {}

    def _awareness_snap(self) -> Optional[Dict[str, Any]]:
        if self.awareness is None:
            return None
        try:
            return self.awareness.snapshot_dict()
        except Exception:
            return None

    def _make(self, text: str, conf: float, src: str, t0: float) -> ReflexAnswer:
        return ReflexAnswer(
            text=text, confidence=conf, source=src,
            latency_ms=round((time.monotonic() - t0) * 1000.0, 2),
        )


def _any_match(pats: List[re.Pattern], text: str) -> bool:
    return any(p.match(text) for p in pats)


__all__ = ["ReflexLayer", "ReflexAnswer"]
