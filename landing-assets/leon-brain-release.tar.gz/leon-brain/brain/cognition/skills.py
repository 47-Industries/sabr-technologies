"""
Phase 13 — Procedural skill memory.

Learns reusable tool chains by mining the episode store. A "skill" is a
named, ordered sequence of tool calls (with arg patterns) that:
  • has been observed N+ times within a sliding window
  • has a measured success rate > threshold
  • is short enough to be a single intent (default ≤ 6 steps)

When the executive/responder is about to plan a chain, it first asks
SkillMemory if a known skill matches the current intent; if yes, it can
invoke that skill directly (single-shot) instead of letting Claude
re-derive it every turn.

Storage: ~/.leon/skills.db (sqlite, WAL).

This module ships a synchronous miner — call .mine(window_minutes=60) to
crawl recent episodes and refresh stored skills. Phase 13 wires this on a
slow cron (every ~10min in shadow mode; not in the hot path).

Public surface:
  SkillMemory(episodes=…)
    .mine(window_minutes=60, min_runs=2, min_success_rate=0.7)
    .match(intent_text, recent_tools=None) -> Optional[Skill]
    .all() / .stats() / .invoke(skill_id, dispatch_fn)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Callable, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.skills")


# NOTE: keep this schema MINIMAL — only columns that have always existed.
# Phase 14 added new columns; those are applied via ALTER TABLE in __init__
# AFTER this baseline runs. Indexes that reference Phase 14 columns are
# created in __init__ AFTER the migration, otherwise CREATE INDEX would
# fail on existing pre-Phase-14 databases that don't have the column yet.
_SCHEMA = """
CREATE TABLE IF NOT EXISTS skills (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    signature       TEXT NOT NULL UNIQUE,
    name            TEXT,
    steps_json      TEXT NOT NULL,
    runs            INTEGER NOT NULL DEFAULT 1,
    success_runs    INTEGER NOT NULL DEFAULT 0,
    last_seen_ts    REAL NOT NULL,
    avg_latency_ms  REAL,
    notes           TEXT
);
CREATE INDEX IF NOT EXISTS idx_skills_seen ON skills(last_seen_ts DESC);
"""

# Phase 14 state machine thresholds
STATE_NOVICE     = "novice"
STATE_REINFORCED = "reinforced"
STATE_OPTIMIZED  = "optimized"
STATE_DEPRECATED = "deprecated"

# Reinforcement deltas
_REINFORCE_BOOST   = 0.08   # successful invoke
_REINFORCE_PENALTY = 0.15   # failed invoke (asymmetric — failure hurts more)
_DECAY_PER_DAY     = 0.01   # passive decay if unused
_DECAY_PER_DAY_STALE = 0.03 # faster decay if unused >30d

# State transition thresholds (runs OR invoke_runs counted)
_REINFORCED_RUNS = 5
_REINFORCED_SR   = 0.75
_OPTIMIZED_RUNS  = 15
_OPTIMIZED_SR    = 0.90
_DEPRECATE_SR    = 0.30   # if sustained SR drops below this with N+ runs
_DEPRECATE_MIN_RUNS = 4


@dataclass
class SkillStep:
    tool: str
    arg_template: Dict[str, Any]


@dataclass
class Skill:
    id: int
    signature: str
    name: str
    steps: List[SkillStep]
    runs: int
    success_runs: int
    success_rate: float
    last_seen_ts: float
    avg_latency_ms: Optional[float]
    # Phase 14
    reinforcement: float = 0.5
    state: str = "novice"
    last_invoked_ts: Optional[float] = None
    invoke_success: int = 0
    invoke_runs: int = 0

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["steps"] = [asdict(s) for s in self.steps]
        d["invoke_success_rate"] = (
            self.invoke_success / self.invoke_runs if self.invoke_runs else None
        )
        return d


class SkillMemory:
    """Mines episode store, exposes matched skills, persistent."""

    def __init__(self, *, episodes, path: Optional[str] = None,
                 max_steps: int = 6):
        self.episodes = episodes
        self.path = path or os.path.expanduser("~/.leon/skills.db")
        self.max_steps = max_steps
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        # Phase 14 — additive migration for older databases that pre-date
        # the reinforcement/state columns. ADD COLUMN is no-op if exists.
        for ddl in (
            "ALTER TABLE skills ADD COLUMN reinforcement REAL NOT NULL DEFAULT 0.5",
            "ALTER TABLE skills ADD COLUMN state TEXT NOT NULL DEFAULT 'novice'",
            "ALTER TABLE skills ADD COLUMN last_invoked_ts REAL",
            "ALTER TABLE skills ADD COLUMN invoke_success INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE skills ADD COLUMN invoke_runs INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE skills ADD COLUMN deprecated_at REAL",
        ):
            try:
                self._conn.execute(ddl)
            except sqlite3.OperationalError:
                pass  # column already exists
        # Index referencing Phase 14 columns — safe to run now that migration
        # has applied. Idempotent.
        try:
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_skills_state "
                "ON skills(state, reinforcement DESC)"
            )
        except sqlite3.OperationalError as e:
            log.warning("skills state index creation failed: %s", e)

    # -- mining --------------------------------------------------------

    def mine(
        self,
        *,
        window_minutes: int = 60,
        min_runs: int = 2,
        min_success_rate: float = 0.7,
        max_gap_s: float = 8.0,
    ) -> Dict[str, Any]:
        """Crawl recent episodes; find repeated successful tool-chains.

        Returns a report dict {found, new, updated}.
        """
        if self.episodes is None:
            return {"found": 0, "new": 0, "updated": 0, "skipped": "no episodes"}
        try:
            recent = self.episodes.recent(limit=4000)
        except Exception as e:
            log.warning("skills.mine episode read failed: %s", e)
            return {"found": 0, "new": 0, "updated": 0, "error": str(e)}

        # Filter to window + sort ascending by ts
        cutoff = time.time() - window_minutes * 60.0
        rows = [r for r in recent if r.get("ts", 0) >= cutoff
                and r.get("action_name")]
        rows.sort(key=lambda r: r.get("ts", 0))

        # Greedy chain segmenter: split when bucket changes OR gap > max_gap_s.
        chains: List[List[Dict[str, Any]]] = []
        cur: List[Dict[str, Any]] = []
        last_ts = 0.0
        last_bucket = None
        for r in rows:
            ts = float(r.get("ts", 0))
            bucket = r.get("bucket") or ""
            if cur and (ts - last_ts > max_gap_s or bucket != last_bucket):
                chains.append(cur)
                cur = []
            cur.append(r)
            last_ts = ts
            last_bucket = bucket
        if cur:
            chains.append(cur)

        # Keep only chains 2..max_steps with all-success
        candidates: List[List[Dict[str, Any]]] = []
        for ch in chains:
            if not (2 <= len(ch) <= self.max_steps):
                continue
            if not all(int(r.get("success") or 0) == 1 for r in ch):
                continue
            candidates.append(ch)

        # Count by signature
        sigs: Dict[str, Dict[str, Any]] = {}
        for ch in candidates:
            sig, steps = _signature(ch)
            agg = sigs.setdefault(sig, {
                "steps": steps, "runs": 0, "succ": 0, "latencies": [],
            })
            agg["runs"] += 1
            agg["succ"] += 1   # we filtered to success-only chains
            for r in ch:
                if r.get("latency_ms") is not None:
                    agg["latencies"].append(float(r["latency_ms"]))

        new_count = 0
        upd_count = 0
        now = time.time()
        for sig, agg in sigs.items():
            if agg["runs"] < min_runs:
                continue
            sr = agg["succ"] / max(1, agg["runs"])
            if sr < min_success_rate:
                continue
            avg_lat = (sum(agg["latencies"]) / len(agg["latencies"])
                       if agg["latencies"] else None)
            with self._lock:
                existing = self._conn.execute(
                    "SELECT * FROM skills WHERE signature=?", (sig,)
                ).fetchone()
                if existing is None:
                    name = _name_for(agg["steps"])
                    self._conn.execute(
                        """INSERT INTO skills
                            (signature, name, steps_json, runs, success_runs,
                             last_seen_ts, avg_latency_ms)
                           VALUES (?,?,?,?,?,?,?)""",
                        (sig, name, json.dumps(agg["steps"]),
                         agg["runs"], agg["succ"], now, avg_lat),
                    )
                    new_count += 1
                else:
                    self._conn.execute(
                        """UPDATE skills SET
                            runs=runs+?, success_runs=success_runs+?,
                            last_seen_ts=?, avg_latency_ms=?
                            WHERE id=?""",
                        (agg["runs"], agg["succ"], now, avg_lat, existing["id"]),
                    )
                    upd_count += 1

        return {
            "found": len(sigs),
            "candidates_above_threshold": sum(
                1 for s in sigs.values() if s["runs"] >= min_runs
            ),
            "new": new_count,
            "updated": upd_count,
        }

    # -- query ---------------------------------------------------------

    def all(self, *, limit: int = 100) -> List[Skill]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM skills ORDER BY last_seen_ts DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [_row_to_skill(r) for r in rows]

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            n = self._conn.execute("SELECT COUNT(*) AS n FROM skills").fetchone()["n"]
            runs = self._conn.execute(
                "SELECT COALESCE(SUM(runs),0) AS s FROM skills"
            ).fetchone()["s"]
        return {"total_skills": n, "total_observed_runs": runs}

    def match(
        self,
        intent_text: str = "",
        recent_tools: Optional[List[str]] = None,
    ) -> Optional[Skill]:
        """Return the best-matching learned skill for the current intent.

        Match heuristic:
          • If `recent_tools` provided (e.g. tools fired earlier in the turn)
            and they form a prefix of a known skill → that skill wins.
          • Else: search skill names + step tool names for token overlap
            against `intent_text`.

        Returns None if nothing scores > 1.5.
        """
        skills = self.all(limit=100)
        if not skills:
            return None

        best: Optional[Tuple[float, Skill]] = None

        if recent_tools:
            recent_tuple = tuple(recent_tools[: self.max_steps])
            for s in skills:
                names = tuple(step.tool for step in s.steps)
                if names[:len(recent_tuple)] == recent_tuple and len(names) > len(recent_tuple):
                    score = 2.0 + 0.5 * (s.success_rate)
                    if not best or score > best[0]:
                        best = (score, s)

        if intent_text:
            tokens = set(_tokens(intent_text))
            for s in skills:
                blob = " ".join([s.name] + [st.tool for st in s.steps]).lower()
                stoks = set(_tokens(blob))
                if not stoks:
                    continue
                overlap = len(tokens & stoks) / max(1, len(stoks))
                score = 1.0 * overlap + 0.5 * s.success_rate
                if not best or score > best[0]:
                    best = (score, s)

        if best and best[0] >= 1.5:
            return best[1]
        return None

    def invoke(
        self, skill_id: int, dispatch_fn: Callable[[str, Dict[str, Any]], Any],
        *, arg_overrides: Optional[Dict[int, Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Run a stored skill via the caller-provided dispatch function.

        dispatch_fn(tool_name, args) -> result_dict

        We do NOT auto-inject this into the responder's hot path here — the
        executive is the right place to decide WHEN to invoke. This method
        just executes a known skill once the caller chose to.
        """
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM skills WHERE id=?", (skill_id,)
            ).fetchone()
        if not row:
            return {"ok": False, "error": f"no skill id={skill_id}"}
        skill = _row_to_skill(row)
        results = []
        ok = True
        t0 = time.time()
        for i, step in enumerate(skill.steps):
            args = dict(step.arg_template or {})
            if arg_overrides and i in arg_overrides:
                args.update(arg_overrides[i])
            # Drop sentinel keys (we stored arg patterns, not real values)
            args = {k: v for k, v in args.items() if not _is_pattern(v)}
            try:
                r = dispatch_fn(step.tool, args)
                results.append({"tool": step.tool, "ok": _looks_ok(r), "result": r})
                if not _looks_ok(r):
                    ok = False
                    break
            except Exception as e:
                results.append({"tool": step.tool, "ok": False, "error": str(e)})
                ok = False
                break
        return {
            "ok": ok, "skill_id": skill_id, "name": skill.name,
            "steps_executed": len(results),
            "latency_ms": round((time.time() - t0) * 1000.0, 1),
            "results": results,
        }


# ── Helpers ────────────────────────────────────────────────────────────────

def _signature(chain: List[Dict[str, Any]]) -> Tuple[str, List[Dict[str, Any]]]:
    """Build a deterministic signature for a chain. We use the tool names
    + each step's arg KEYS (not values) so similar invocations collapse."""
    steps = []
    parts = []
    for r in chain:
        tool = r.get("action_name", "")
        try:
            args = json.loads(r.get("action_args_json") or "{}")
            if not isinstance(args, dict):
                args = {}
        except Exception:
            args = {}
        arg_keys = sorted(args.keys())
        steps.append({"tool": tool, "arg_template": {k: f"<{type(args[k]).__name__}>"
                                                       for k in arg_keys}})
        parts.append(tool + "(" + ",".join(arg_keys) + ")")
    sig = hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:16]
    return sig, steps


def _row_to_skill(row) -> Skill:
    try:
        steps_raw = json.loads(row["steps_json"]) or []
    except Exception:
        steps_raw = []
    steps = []
    for s in steps_raw:
        if isinstance(s, dict) and s.get("tool"):
            steps.append(SkillStep(
                tool=s["tool"],
                arg_template=s.get("arg_template") or {},
            ))
    runs = int(row["runs"] or 0)
    succ = int(row["success_runs"] or 0)
    sr = succ / max(1, runs)
    return Skill(
        id=row["id"], signature=row["signature"], name=row["name"] or "",
        steps=steps, runs=runs, success_runs=succ, success_rate=sr,
        last_seen_ts=float(row["last_seen_ts"] or 0.0),
        avg_latency_ms=row["avg_latency_ms"],
        # Phase 14 fields — protect against legacy rows where columns may
        # be present but the values None (defaults applied on read).
        reinforcement=float(
            row["reinforcement"] if "reinforcement" in row.keys()
            and row["reinforcement"] is not None else 0.5
        ),
        state=(row["state"] if "state" in row.keys() and row["state"] else "novice"),
        last_invoked_ts=(row["last_invoked_ts"]
                          if "last_invoked_ts" in row.keys() else None),
        invoke_success=int(row["invoke_success"]
                            if "invoke_success" in row.keys()
                            and row["invoke_success"] is not None else 0),
        invoke_runs=int(row["invoke_runs"]
                         if "invoke_runs" in row.keys()
                         and row["invoke_runs"] is not None else 0),
    )


def _name_for(steps: List[Dict[str, Any]]) -> str:
    if not steps:
        return "empty_skill"
    tools = [s.get("tool", "") for s in steps]
    short = [t.split(".")[-1] for t in tools]
    return " → ".join(short[:4])


def _tokens(s: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]{3,}", s.lower())][:64]


def _looks_ok(r: Any) -> bool:
    if isinstance(r, dict):
        if "ok" in r:
            return bool(r["ok"])
        return "error" not in r
    return bool(r)


def _is_pattern(v: Any) -> bool:
    return isinstance(v, str) and v.startswith("<") and v.endswith(">")


__all__ = ["SkillMemory", "Skill", "SkillStep"]


# ── Phase 14 — Reinforcement + state machine ────────────────────────────

def _new_state_for(runs: int, sr: float, current: str) -> str:
    """Decide the next state given run count and success rate.

    Once OPTIMIZED, only sustained failure drops back to DEPRECATED.
    DEPRECATED is sticky for `_DEPRECATE_MIN_RUNS` more runs.
    """
    if current == STATE_DEPRECATED:
        if runs >= _DEPRECATE_MIN_RUNS and sr >= _REINFORCED_SR:
            return STATE_REINFORCED  # rehabilitated
        return STATE_DEPRECATED
    # Demote any state if SR collapses
    if runs >= _DEPRECATE_MIN_RUNS and sr <= _DEPRECATE_SR:
        return STATE_DEPRECATED
    # Promote
    if runs >= _OPTIMIZED_RUNS and sr >= _OPTIMIZED_SR:
        return STATE_OPTIMIZED
    if runs >= _REINFORCED_RUNS and sr >= _REINFORCED_SR:
        return STATE_REINFORCED
    return STATE_NOVICE


def _reinforce_skillmemory():
    """Bolt reinforcement methods onto SkillMemory."""

    def reinforce(self, skill_id: int, success: bool,
                   *, latency_ms: Optional[float] = None) -> Optional[Skill]:
        """Apply success/failure reinforcement to a skill. Caller is the
        invoker (e.g. executive after running invoke())."""
        now = time.time()
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM skills WHERE id=?", (skill_id,),
            ).fetchone()
            if row is None:
                return None
            cur_reinf = float(row["reinforcement"] or 0.5)
            cur_state = row["state"] or STATE_NOVICE
            if success:
                new_reinf = min(1.0, cur_reinf + _REINFORCE_BOOST)
            else:
                new_reinf = max(0.0, cur_reinf - _REINFORCE_PENALTY)
            inv_runs = int(row["invoke_runs"] or 0) + 1
            inv_succ = int(row["invoke_success"] or 0) + (1 if success else 0)
            invoke_sr = inv_succ / max(1, inv_runs)
            # Combined SR across both mined runs and explicit invokes,
            # weighted toward invokes (they're more recent + intentional).
            mined_runs = int(row["runs"] or 0)
            mined_succ = int(row["success_runs"] or 0)
            total_runs = mined_runs + inv_runs
            total_succ = mined_succ + inv_succ
            combined_sr = total_succ / max(1, total_runs)
            new_state = _new_state_for(total_runs, combined_sr, cur_state)
            deprecated_at = now if (new_state == STATE_DEPRECATED
                                       and cur_state != STATE_DEPRECATED) else row["deprecated_at"]
            self._conn.execute(
                """UPDATE skills SET
                    reinforcement=?, state=?,
                    last_invoked_ts=?, invoke_runs=?, invoke_success=?,
                    deprecated_at=?
                   WHERE id=?""",
                (new_reinf, new_state, now, inv_runs, inv_succ,
                 deprecated_at, skill_id),
            )
            row2 = self._conn.execute(
                "SELECT * FROM skills WHERE id=?", (skill_id,)).fetchone()
        return _row_to_skill(row2)

    def decay_all(self, *, now: Optional[float] = None) -> Dict[str, int]:
        """Apply time-based reinforcement decay across all skills. Cheap;
        intended to run on the reflection cycle (~30min)."""
        now = now or time.time()
        decayed = 0
        deprecated_now = 0
        with self._lock:
            rows = self._conn.execute("SELECT * FROM skills").fetchall()
            for r in rows:
                last = float(r["last_invoked_ts"] or r["last_seen_ts"] or now)
                age_days = (now - last) / 86400.0
                if age_days < 1:
                    continue
                rate = _DECAY_PER_DAY_STALE if age_days > 30 else _DECAY_PER_DAY
                delta = min(0.5, age_days * rate)
                new_reinf = max(0.0, float(r["reinforcement"] or 0.5) - delta)
                # Sticky-deprecate skills that fall to floor
                cur_state = r["state"] or STATE_NOVICE
                new_state = cur_state
                deprecated_at = r["deprecated_at"]
                if new_reinf <= 0.05 and cur_state != STATE_DEPRECATED:
                    new_state = STATE_DEPRECATED
                    deprecated_at = now
                    deprecated_now += 1
                if abs(new_reinf - (r["reinforcement"] or 0.5)) > 0.005 \
                        or new_state != cur_state:
                    self._conn.execute(
                        "UPDATE skills SET reinforcement=?, state=?, deprecated_at=? WHERE id=?",
                        (new_reinf, new_state, deprecated_at, r["id"]),
                    )
                    decayed += 1
        return {"decayed": decayed, "deprecated_now": deprecated_now,
                 "scanned": len(rows) if isinstance(rows, list) else 0}

    def detect_tool_drift(self, tool_health) -> Dict[str, int]:
        """If a skill references a tool that is now BROKEN per tool_health,
        demote the skill's reinforcement and (if severe) state→deprecated."""
        if tool_health is None:
            return {"checked": 0, "demoted": 0}
        try:
            broken = {s.tool for s in tool_health.broken(limit=200)}
        except Exception:
            return {"checked": 0, "demoted": 0}
        if not broken:
            return {"checked": 0, "demoted": 0}
        demoted = 0
        with self._lock:
            rows = self._conn.execute("SELECT * FROM skills").fetchall()
            for r in rows:
                try:
                    steps = json.loads(r["steps_json"]) or []
                except Exception:
                    continue
                step_tools = {s.get("tool") for s in steps if isinstance(s, dict)}
                if not (step_tools & broken):
                    continue
                cur_reinf = float(r["reinforcement"] or 0.5)
                new_reinf = max(0.0, cur_reinf - 0.20)  # bigger hit than normal decay
                cur_state = r["state"] or STATE_NOVICE
                new_state = STATE_DEPRECATED if new_reinf <= 0.1 else cur_state
                deprecated_at = (time.time() if new_state == STATE_DEPRECATED
                                  and cur_state != STATE_DEPRECATED
                                  else r["deprecated_at"])
                self._conn.execute(
                    "UPDATE skills SET reinforcement=?, state=?, deprecated_at=? WHERE id=?",
                    (new_reinf, new_state, deprecated_at, r["id"]),
                )
                demoted += 1
        return {"checked": len(rows), "demoted": demoted}

    def by_state(self, state: str, limit: int = 100) -> List[Skill]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM skills WHERE state=? ORDER BY reinforcement DESC LIMIT ?",
                (state, limit),
            ).fetchall()
        return [_row_to_skill(r) for r in rows]

    def by_reinforcement(self, *, min_score: float = 0.3,
                          limit: int = 50) -> List[Skill]:
        """Top usable skills — what the executive prefers to invoke."""
        with self._lock:
            rows = self._conn.execute(
                """SELECT * FROM skills
                    WHERE reinforcement >= ? AND state != ?
                    ORDER BY reinforcement DESC, runs DESC
                    LIMIT ?""",
                (min_score, STATE_DEPRECATED, limit),
            ).fetchall()
        return [_row_to_skill(r) for r in rows]

    def state_summary(self) -> Dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT state, COUNT(*) AS n FROM skills GROUP BY state"
            ).fetchall()
        out = {STATE_NOVICE: 0, STATE_REINFORCED: 0,
               STATE_OPTIMIZED: 0, STATE_DEPRECATED: 0}
        for r in rows:
            out[r["state"] or STATE_NOVICE] = r["n"]
        return out

    SkillMemory.reinforce = reinforce
    SkillMemory.decay_all = decay_all
    SkillMemory.detect_tool_drift = detect_tool_drift
    SkillMemory.by_state = by_state
    SkillMemory.by_reinforcement = by_reinforcement
    SkillMemory.state_summary = state_summary


_reinforce_skillmemory()


# Wrap .invoke so it auto-reinforces. The OLD method is kept under _orig_invoke
# for parity with anyone calling without reinforcement intent.
_orig_invoke = SkillMemory.invoke

def _invoke_with_reinforcement(self, skill_id, dispatch_fn, **kwargs):
    out = _orig_invoke(self, skill_id, dispatch_fn, **kwargs)
    try:
        self.reinforce(skill_id, success=bool(out.get("ok")),
                        latency_ms=out.get("latency_ms"))
    except Exception as e:
        log.warning("skills.invoke reinforce failed: %s", e)
    return out

SkillMemory.invoke = _invoke_with_reinforcement


# ── Phase 15 — assisted skill crystallization ───────────────────────────

def _add_from_chain(self, *, steps: List[Dict[str, Any]],
                     name: str = "",
                     runs: int = 1, success_runs: int = 1) -> Optional[Skill]:
    """Insert a skill explicitly (from an approved crystallize_skill proposal).

    steps: [{"tool": "...", "args_keys": [...]}, ...]
    """
    if not steps:
        return None
    # Build a signature compatible with the miner so future identical
    # chains reinforce instead of duplicating
    sig_parts = [f"{s['tool']}({','.join(s.get('args_keys') or [])})"
                  for s in steps]
    sig = hashlib.sha1("|".join(sig_parts).encode("utf-8")).hexdigest()[:16]
    # Stored skill steps mirror miner format
    steps_json = json.dumps([{
        "tool": s["tool"],
        "arg_template": {k: "<unknown>" for k in (s.get("args_keys") or [])},
    } for s in steps])
    now = time.time()
    with self._lock:
        # Idempotent: if same signature already exists, just bump runs
        existing = self._conn.execute(
            "SELECT * FROM skills WHERE signature=?", (sig,)
        ).fetchone()
        if existing is not None:
            self._conn.execute(
                "UPDATE skills SET runs=runs+?, success_runs=success_runs+?, "
                "last_seen_ts=? WHERE id=?",
                (runs, success_runs, now, existing["id"]),
            )
            row = self._conn.execute(
                "SELECT * FROM skills WHERE id=?", (existing["id"],)
            ).fetchone()
            log.info("[skills] reinforced existing skill via crystallization id=%s",
                      existing["id"])
            return _row_to_skill(row)
        cur = self._conn.execute(
            """INSERT INTO skills
                (signature, name, steps_json, runs, success_runs,
                 last_seen_ts, reinforcement, state)
                VALUES (?,?,?,?,?,?,?,?)""",
            (sig, name or " → ".join(s["tool"].split(".")[-1] for s in steps[:4]),
              steps_json, runs, success_runs, now,
              0.65, STATE_REINFORCED),   # crystallized skills start strong
        )
        row = self._conn.execute(
            "SELECT * FROM skills WHERE id=?", (cur.lastrowid,)).fetchone()
    log.info("[skills] crystallized new skill #%s — %s", row["id"], name)
    return _row_to_skill(row)

SkillMemory.add_from_chain = _add_from_chain
