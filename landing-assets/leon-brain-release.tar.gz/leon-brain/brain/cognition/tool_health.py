"""
Phase 13 — Tool Immune System.

Tracks reliability per-tool from the close-wrap stream that already feeds the
EpisodeStore. No double-recording: tool_health subscribes via ToolHealth.observe()
which the bootstrap close-wrap calls right after recording the episode.

State per tool:
  status         ∈ {healthy, degraded, broken, untested}
  calls_total
  success_total
  success_rate   (rolling, last N=200)
  latency_p50_ms
  latency_p95_ms
  last_failure_kind
  last_failure_ts
  last_success_ts
  last_call_ts

Persisted to ~/.leon/tool_health.db (sqlite, WAL). Idempotent open. No imports
beyond stdlib.

Status policy:
  untested      — calls_total < 3
  broken        — success_rate ≤ 0.3 OR (3+ consecutive failures AND no success
                   in last 24h)
  degraded      — success_rate < 0.85 OR p95_latency > 8s OR last_failure
                   < 5min ago
  healthy       — otherwise

Used by:
  - Executive (avoid broken tools, prefer healthy alternatives)
  - Self-repair queue (failing tools auto-classify, surface candidates)
  - Prompt builder (warn Claude when a tool it might call is degraded)
  - Watchdog (escalate when broken count rises sharply)
"""

from __future__ import annotations

import collections
import logging
import os
import sqlite3
import statistics
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Optional, Tuple

from brain.cognition import failure_classifier as fc

log = logging.getLogger("leon.cognition.tool_health")


# ── Status constants ───────────────────────────────────────────────────────

STATUS_HEALTHY  = "healthy"
STATUS_DEGRADED = "degraded"
STATUS_BROKEN   = "broken"
STATUS_UNTESTED = "untested"

# Rolling-window size for success rate and latency percentiles.
_WINDOW = 200

# Thresholds.
_BROKEN_SR_MAX        = 0.30
_DEGRADED_SR_MAX      = 0.85
_DEGRADED_P95_MAX_MS  = 8000.0
_DEGRADED_RECENT_FAIL_S = 300.0
_BROKEN_NO_SUCCESS_S  = 86400.0
_MIN_CALLS_FOR_STATUS = 3


# ── Schema ─────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS tool_health (
    tool             TEXT PRIMARY KEY,
    calls_total      INTEGER NOT NULL DEFAULT 0,
    success_total    INTEGER NOT NULL DEFAULT 0,
    consecutive_fail INTEGER NOT NULL DEFAULT 0,
    last_call_ts     REAL,
    last_success_ts  REAL,
    last_failure_ts  REAL,
    last_failure_kind TEXT,
    last_failure_text TEXT,
    -- snapshots updated on every observe()
    success_rate     REAL,
    latency_p50_ms   REAL,
    latency_p95_ms   REAL,
    status           TEXT NOT NULL DEFAULT 'untested',
    -- raw rolling samples (JSON list, last _WINDOW)
    samples_json     TEXT
);
CREATE INDEX IF NOT EXISTS idx_tool_health_status ON tool_health(status);
"""


@dataclass
class ToolStats:
    tool: str
    status: str
    calls_total: int
    success_total: int
    success_rate: float
    latency_p50_ms: float
    latency_p95_ms: float
    consecutive_fail: int
    last_call_ts: Optional[float]
    last_success_ts: Optional[float]
    last_failure_ts: Optional[float]
    last_failure_kind: Optional[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class ToolHealth:
    """Persistent per-tool health tracker."""

    def __init__(self, *, path: Optional[str] = None):
        self.path = path or os.path.expanduser("~/.leon/tool_health.db")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            self.path, check_same_thread=False, isolation_level=None,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        except Exception:
            pass
        # In-memory cache of rolling samples; loaded lazily per-tool.
        self._samples: Dict[str, collections.deque] = {}

    # -- public --------------------------------------------------------

    def observe(
        self,
        tool: str,
        *,
        success: bool,
        latency_ms: float,
        result: Any = None,
        exception_text: Optional[str] = None,
        ts: Optional[float] = None,
    ) -> ToolStats:
        """Record one tool outcome and return the updated stats."""
        if not tool:
            tool = "<unknown>"
        ts = ts if ts is not None else time.time()
        lat = max(0.0, float(latency_ms))

        if success:
            failure = fc.Failure(kind=fc.KIND_OK, repairability=0.0, suggestion="")
        else:
            failure = fc.classify(result, exception_text=exception_text, tool=tool)

        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM tool_health WHERE tool=?", (tool,)
            ).fetchone()
            samples = self._samples_for(tool, row)
            samples.append((ts, 1 if success else 0, lat))

            calls_total = (row["calls_total"] if row else 0) + 1
            success_total = (row["success_total"] if row else 0) + (1 if success else 0)
            if success:
                consec_fail = 0
                last_success_ts = ts
                last_failure_ts = row["last_failure_ts"] if row else None
                last_failure_kind = row["last_failure_kind"] if row else None
                last_failure_text = row["last_failure_text"] if row else None
            else:
                consec_fail = (row["consecutive_fail"] if row else 0) + 1
                last_success_ts = row["last_success_ts"] if row else None
                last_failure_ts = ts
                last_failure_kind = failure.kind
                last_failure_text = (failure.matched_text or "")[:240]

            sr = sum(s[1] for s in samples) / max(1, len(samples))
            lats = sorted(s[2] for s in samples)
            p50 = _percentile(lats, 0.50)
            p95 = _percentile(lats, 0.95)

            status = _decide_status(
                calls_total=calls_total,
                success_rate=sr,
                p95_latency_ms=p95,
                consecutive_fail=consec_fail,
                last_success_ts=last_success_ts,
                last_failure_ts=last_failure_ts,
                now=ts,
            )

            import json as _json
            samples_json = _json.dumps(list(samples)[-_WINDOW:])

            self._conn.execute(
                """INSERT INTO tool_health
                    (tool, calls_total, success_total, consecutive_fail,
                     last_call_ts, last_success_ts, last_failure_ts,
                     last_failure_kind, last_failure_text,
                     success_rate, latency_p50_ms, latency_p95_ms,
                     status, samples_json)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(tool) DO UPDATE SET
                     calls_total=excluded.calls_total,
                     success_total=excluded.success_total,
                     consecutive_fail=excluded.consecutive_fail,
                     last_call_ts=excluded.last_call_ts,
                     last_success_ts=excluded.last_success_ts,
                     last_failure_ts=excluded.last_failure_ts,
                     last_failure_kind=excluded.last_failure_kind,
                     last_failure_text=excluded.last_failure_text,
                     success_rate=excluded.success_rate,
                     latency_p50_ms=excluded.latency_p50_ms,
                     latency_p95_ms=excluded.latency_p95_ms,
                     status=excluded.status,
                     samples_json=excluded.samples_json
                """,
                (
                    tool, calls_total, success_total, consec_fail,
                    ts, last_success_ts, last_failure_ts,
                    last_failure_kind, last_failure_text,
                    sr, p50, p95, status, samples_json,
                ),
            )

            return ToolStats(
                tool=tool, status=status,
                calls_total=calls_total, success_total=success_total,
                success_rate=sr, latency_p50_ms=p50, latency_p95_ms=p95,
                consecutive_fail=consec_fail,
                last_call_ts=ts,
                last_success_ts=last_success_ts,
                last_failure_ts=last_failure_ts,
                last_failure_kind=last_failure_kind,
            )

    # -- queries -------------------------------------------------------

    def get(self, tool: str) -> Optional[ToolStats]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM tool_health WHERE tool=?", (tool,)
            ).fetchone()
        if not row:
            return None
        return _row_to_stats(row)

    def status_of(self, tool: str) -> str:
        s = self.get(tool)
        return s.status if s else STATUS_UNTESTED

    def is_safe(self, tool: str) -> bool:
        """Cheap predicate the executive can call before suggesting a tool."""
        return self.status_of(tool) != STATUS_BROKEN

    def all_stats(self, *, status: Optional[str] = None,
                  limit: int = 500) -> List[ToolStats]:
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT * FROM tool_health WHERE status=? ORDER BY last_call_ts DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM tool_health ORDER BY last_call_ts DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [_row_to_stats(r) for r in rows]

    def summary(self) -> Dict[str, Any]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT status, COUNT(*) AS n FROM tool_health GROUP BY status"
            ).fetchall()
            total = self._conn.execute(
                "SELECT COUNT(*) AS n FROM tool_health"
            ).fetchone()
        counts = {r["status"]: r["n"] for r in rows}
        return {
            "total": total["n"] if total else 0,
            "healthy":  counts.get(STATUS_HEALTHY, 0),
            "degraded": counts.get(STATUS_DEGRADED, 0),
            "broken":   counts.get(STATUS_BROKEN, 0),
            "untested": counts.get(STATUS_UNTESTED, 0),
        }

    def broken(self, limit: int = 50) -> List[ToolStats]:
        return self.all_stats(status=STATUS_BROKEN, limit=limit)

    def degraded(self, limit: int = 50) -> List[ToolStats]:
        return self.all_stats(status=STATUS_DEGRADED, limit=limit)

    def reset(self, tool: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM tool_health WHERE tool=?", (tool,))
            self._samples.pop(tool, None)

    # -- internals -----------------------------------------------------

    def _samples_for(self, tool: str, row) -> collections.deque:
        if tool in self._samples:
            return self._samples[tool]
        dq: collections.deque = collections.deque(maxlen=_WINDOW)
        if row and row["samples_json"]:
            try:
                import json as _json
                for s in _json.loads(row["samples_json"]):
                    if isinstance(s, (list, tuple)) and len(s) == 3:
                        dq.append((float(s[0]), int(s[1]), float(s[2])))
            except Exception:
                pass
        self._samples[tool] = dq
        return dq


# ── Helpers ────────────────────────────────────────────────────────────────

def _percentile(sorted_values: List[float], q: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    k = q * (len(sorted_values) - 1)
    f = int(k)
    c = min(f + 1, len(sorted_values) - 1)
    return sorted_values[f] + (sorted_values[c] - sorted_values[f]) * (k - f)


def _decide_status(
    *, calls_total: int, success_rate: float, p95_latency_ms: float,
    consecutive_fail: int, last_success_ts: Optional[float],
    last_failure_ts: Optional[float], now: float,
) -> str:
    if calls_total < _MIN_CALLS_FOR_STATUS:
        return STATUS_UNTESTED
    # Broken — bad SR, or several consecutive failures with no recent success
    if success_rate <= _BROKEN_SR_MAX:
        return STATUS_BROKEN
    if consecutive_fail >= 3:
        if last_success_ts is None or (now - last_success_ts) > _BROKEN_NO_SUCCESS_S:
            return STATUS_BROKEN
    # Degraded
    if success_rate < _DEGRADED_SR_MAX:
        return STATUS_DEGRADED
    if p95_latency_ms > _DEGRADED_P95_MAX_MS:
        return STATUS_DEGRADED
    if last_failure_ts is not None and (now - last_failure_ts) < _DEGRADED_RECENT_FAIL_S:
        return STATUS_DEGRADED
    return STATUS_HEALTHY


def _row_to_stats(row) -> ToolStats:
    return ToolStats(
        tool=row["tool"],
        status=row["status"] or STATUS_UNTESTED,
        calls_total=row["calls_total"] or 0,
        success_total=row["success_total"] or 0,
        success_rate=float(row["success_rate"] or 0.0),
        latency_p50_ms=float(row["latency_p50_ms"] or 0.0),
        latency_p95_ms=float(row["latency_p95_ms"] or 0.0),
        consecutive_fail=row["consecutive_fail"] or 0,
        last_call_ts=row["last_call_ts"],
        last_success_ts=row["last_success_ts"],
        last_failure_ts=row["last_failure_ts"],
        last_failure_kind=row["last_failure_kind"],
    )


__all__ = [
    "ToolHealth", "ToolStats",
    "STATUS_HEALTHY", "STATUS_DEGRADED", "STATUS_BROKEN", "STATUS_UNTESTED",
]
