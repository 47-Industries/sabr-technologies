"""
Phase 12B — Active-mode auto-promote gate.

Leon currently runs in 'shadow' mode: the cognition loop ticks, predicts, and
logs everything, but never autonomously fires anything. Promotion to 'active'
mode is the moment Leon goes from passive observer to autonomous actor — so
the bar to flip the switch is deliberately high.

Promotion is NEVER automatic. This module's job is to surface readiness, not
to act. The flip happens via an explicit POST to /api/cognition/mode/active,
gated by `eligible(): True`. The promoter records the decision and audit-trails
the metrics that were green at flip time.

Criteria (all must be true)
───────────────────────────
  1. Brier (24h, n ≥ 100):   < 0.10
       - Calibration good enough to trust the world model.
       - Insufficient n → not eligible (we won't promote on tiny samples).
  2. Identity drift score:    < 0.20
       - Self model isn't thrashing — Leon's identity is stable.
  3. Recent autonomous failures (7d): 0
       - No `safety.mark_outcome(success=False)` events in the last 7 days.
       - Counted from the audit log, which is the durable record.
  4. Kill switch never engaged (7d):
       - Searches the audit log for any `kill_switch` block_layer in the
         last week. None means Dean trusts current state.
  5. Episode volume (7d):     ≥ 500
       - Need real activity history, not a quiet week.
  6. Successful hypothesis verification:
       - At least 1 corroborated causal rule. Optional — if Phase 12A
         verifier isn't installed, this check is skipped (returns True).

Anti-patterns this module guards against
────────────────────────────────────────
  - Promoting on a fresh boot when metrics look pristine because nothing's
    happened yet (handled by min-n and min-episode-volume gates).
  - Promoting after a single good day (handled by 7-day failure window).
  - Auto-flipping without human approval (handled by requiring explicit POST).
  - Treating absence-of-failure as proof-of-success (handled by min-episode-
    volume + Brier-with-min-n).
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass, asdict, field
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.cognition.auto_promote")


# ── Thresholds (env-tunable) ────────────────────────────────────────────────

def _env_float(key: str, default: float) -> float:
    try:
        v = os.environ.get(key)
        return float(v) if v is not None else default
    except Exception:
        return default


def _env_int(key: str, default: int) -> int:
    try:
        v = os.environ.get(key)
        return int(v) if v is not None else default
    except Exception:
        return default


def _thresholds() -> Dict[str, Any]:
    return {
        "brier_max": _env_float("LEON_PROMOTE_BRIER_MAX", 0.10),
        "brier_min_n": _env_int("LEON_PROMOTE_BRIER_MIN_N", 100),
        "drift_max": _env_float("LEON_PROMOTE_DRIFT_MAX", 0.20),
        "failure_window_hours": _env_int("LEON_PROMOTE_FAILURE_WINDOW_H", 168),  # 7d
        "kill_switch_window_hours": _env_int("LEON_PROMOTE_KILL_WINDOW_H", 168),
        "min_episodes_7d": _env_int("LEON_PROMOTE_MIN_EPISODES_7D", 500),
        "require_corroborated": _env_int("LEON_PROMOTE_REQUIRE_CORROBORATED", 1) == 1,
    }


# ── Records ─────────────────────────────────────────────────────────────────

@dataclass
class CriterionResult:
    name: str
    pass_: bool
    value: Any
    threshold: Any
    detail: str = ""

    def to_dict(self) -> Dict[str, Any]:
        # 'pass' is a Python keyword — emit as 'passed' so JSON consumers
        # don't have to quote it.
        d = asdict(self)
        d["passed"] = d.pop("pass_")
        return d


@dataclass
class ReadinessReport:
    eligible: bool
    criteria: List[CriterionResult] = field(default_factory=list)
    thresholds: Dict[str, Any] = field(default_factory=dict)
    checked_ts: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "eligible": self.eligible,
            "criteria": [c.to_dict() for c in self.criteria],
            "thresholds": self.thresholds,
            "checked_ts": self.checked_ts,
        }


# ── Promoter ────────────────────────────────────────────────────────────────

class AutoPromoter:
    """Evaluates promotion-readiness. Does NOT flip mode — caller does that
    via the explicit POST endpoint after inspecting `eligible`."""

    def __init__(self, *, cognition_bundle):
        # Take the whole bundle so we can pull from any subsystem.
        self.cog = cognition_bundle

    # ── public API ──────────────────────────────────────────────────────

    def readiness(self) -> ReadinessReport:
        th = _thresholds()
        criteria: List[CriterionResult] = []
        criteria.append(self._check_brier(th))
        criteria.append(self._check_drift(th))
        criteria.append(self._check_failures(th))
        criteria.append(self._check_kill_switch(th))
        criteria.append(self._check_episode_volume(th))
        criteria.append(self._check_corroborated(th))
        report = ReadinessReport(
            eligible=all(c.pass_ for c in criteria),
            criteria=criteria,
            thresholds=th,
            checked_ts=time.time(),
        )
        return report

    def promote(self, *, reason: str = "manual") -> Dict[str, Any]:
        """Flip the loop to active mode IF eligible. Returns the action taken
        plus the readiness report at decision time."""
        report = self.readiness()
        if not report.eligible:
            return {
                "ok": False,
                "promoted": False,
                "reason": "not eligible — see criteria",
                "report": report.to_dict(),
            }
        try:
            self.cog.loop.set_mode("active")
        except Exception as e:
            return {
                "ok": False,
                "promoted": False,
                "reason": f"set_mode failed: {e}",
                "report": report.to_dict(),
            }
        self._record_promotion(report=report, reason=reason)
        return {
            "ok": True,
            "promoted": True,
            "new_mode": self.cog.loop.mode(),
            "promotion_reason": reason,
            "report": report.to_dict(),
        }

    def demote(self, *, reason: str = "manual") -> Dict[str, Any]:
        """Flip back to shadow mode. No eligibility gate — demotion is
        always allowed and is the safe direction."""
        try:
            self.cog.loop.set_mode("shadow")
        except Exception as e:
            return {"ok": False, "demoted": False, "reason": f"set_mode failed: {e}"}
        self._record_demotion(reason=reason)
        return {"ok": True, "demoted": True, "new_mode": self.cog.loop.mode(),
                "demotion_reason": reason}

    # ── criteria ────────────────────────────────────────────────────────

    def _check_brier(self, th: Dict[str, Any]) -> CriterionResult:
        try:
            cal = self.cog.episodes.calibration(hours=24)
        except Exception as e:
            return CriterionResult(
                name="brier_24h", pass_=False, value=None,
                threshold=th["brier_max"], detail=f"calibration unavailable: {e}",
            )
        brier = cal.get("brier")
        n = cal.get("n", 0)
        if n < th["brier_min_n"]:
            return CriterionResult(
                name="brier_24h", pass_=False,
                value={"brier": brier, "n": n},
                threshold={"brier_max": th["brier_max"], "min_n": th["brier_min_n"]},
                detail=f"need n>={th['brier_min_n']} predictions, have {n}",
            )
        ok = (brier is not None) and (brier < th["brier_max"])
        return CriterionResult(
            name="brier_24h", pass_=ok,
            value={"brier": round(brier or 0, 4), "n": n},
            threshold={"brier_max": th["brier_max"], "min_n": th["brier_min_n"]},
            detail=f"brier={brier:.4f} (need < {th['brier_max']})" if brier is not None else "brier=None",
        )

    def _check_drift(self, th: Dict[str, Any]) -> CriterionResult:
        if self.cog.self_model is None:
            return CriterionResult(
                name="identity_drift", pass_=False, value=None,
                threshold=th["drift_max"], detail="self_model not installed",
            )
        try:
            drift = float(self.cog.self_model.identity_drift_score())
        except Exception as e:
            return CriterionResult(
                name="identity_drift", pass_=False, value=None,
                threshold=th["drift_max"], detail=f"drift calc failed: {e}",
            )
        ok = drift < th["drift_max"]
        return CriterionResult(
            name="identity_drift", pass_=ok, value=round(drift, 4),
            threshold=th["drift_max"],
            detail=f"drift={drift:.4f} (need < {th['drift_max']})",
        )

    def _check_failures(self, th: Dict[str, Any]) -> CriterionResult:
        """Count autonomous-action failures from the safety audit log over
        the failure window. Zero is required."""
        n_failures = self._count_audit_failures(hours=th["failure_window_hours"])
        ok = n_failures == 0
        return CriterionResult(
            name="autonomous_failures_7d", pass_=ok,
            value=n_failures, threshold=0,
            detail=f"{n_failures} autonomous failures in last "
                   f"{th['failure_window_hours']}h (need 0)",
        )

    def _check_kill_switch(self, th: Dict[str, Any]) -> CriterionResult:
        n_engagements = self._count_kill_switch_engagements(
            hours=th["kill_switch_window_hours"]
        )
        ok = n_engagements == 0
        return CriterionResult(
            name="kill_switch_7d", pass_=ok,
            value=n_engagements, threshold=0,
            detail=f"{n_engagements} kill-switch engagements in last "
                   f"{th['kill_switch_window_hours']}h (need 0)",
        )

    def _check_episode_volume(self, th: Dict[str, Any]) -> CriterionResult:
        try:
            stats = self.cog.episodes.stats()
        except Exception as e:
            return CriterionResult(
                name="episode_volume_7d", pass_=False, value=None,
                threshold=th["min_episodes_7d"], detail=f"stats failed: {e}",
            )
        total = int(stats.get("total_7d", 0) or 0)
        ok = total >= th["min_episodes_7d"]
        return CriterionResult(
            name="episode_volume_7d", pass_=ok, value=total,
            threshold=th["min_episodes_7d"],
            detail=f"{total} episodes in last 7d (need ≥ {th['min_episodes_7d']})",
        )

    def _check_corroborated(self, th: Dict[str, Any]) -> CriterionResult:
        if not th["require_corroborated"]:
            return CriterionResult(
                name="corroborated_hypotheses", pass_=True,
                value=None, threshold="(disabled)",
                detail="LEON_PROMOTE_REQUIRE_CORROBORATED=0 — skipped",
            )
        verifier = getattr(self.cog, "verifier", None)
        if verifier is None:
            # Verifier not installed — soft-pass with a note so absence
            # of Phase 12A doesn't permanently block promotion.
            return CriterionResult(
                name="corroborated_hypotheses", pass_=True,
                value=None, threshold=1,
                detail="verifier not installed — soft-pass",
            )
        try:
            n = len(verifier.corroborated_hypotheses(limit=100))
        except Exception as e:
            return CriterionResult(
                name="corroborated_hypotheses", pass_=False, value=None,
                threshold=1, detail=f"verifier read failed: {e}",
            )
        ok = n >= 1
        return CriterionResult(
            name="corroborated_hypotheses", pass_=ok, value=n,
            threshold=1, detail=f"{n} corroborated rule(s) (need ≥ 1)",
        )

    # ── audit log helpers ───────────────────────────────────────────────

    def _audit_log_path(self) -> Optional[str]:
        safety = getattr(self.cog, "safety", None)
        if safety is None:
            return None
        return getattr(safety, "audit_log_path", None)

    def _read_audit_lines(self, *, since_ts: float) -> List[Dict[str, Any]]:
        path = self._audit_log_path()
        if not path or not os.path.exists(path):
            return []
        out: List[Dict[str, Any]] = []
        try:
            with open(path) as f:
                # Read backwards conceptually — but the file is small enough
                # after rotation that linear scan is fine. Stop early once
                # we hit lines older than since_ts (entries are append-only
                # ordered by time).
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                    except Exception:
                        continue
                    ts = d.get("ts") or 0
                    if ts >= since_ts:
                        out.append(d)
        except Exception as e:
            log.debug("audit log read failed: %s", e)
        return out

    def _count_audit_failures(self, *, hours: int) -> int:
        since = time.time() - hours * 3600
        rows = self._read_audit_lines(since_ts=since)
        return sum(
            1 for r in rows
            if r.get("type") == "outcome" and r.get("success") is False
        )

    def _count_kill_switch_engagements(self, *, hours: int) -> int:
        since = time.time() - hours * 3600
        rows = self._read_audit_lines(since_ts=since)
        return sum(
            1 for r in rows
            if r.get("block_layer") == "kill_switch"
        )

    # ── audit promotion / demotion ─────────────────────────────────────

    def _promotion_log_path(self) -> str:
        # Co-locate with the rest of brain_state.
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        return os.path.join(root, "brain_state", "mode_promotions.jsonl")

    def _record_promotion(self, *, report: ReadinessReport, reason: str) -> None:
        try:
            os.makedirs(os.path.dirname(self._promotion_log_path()), exist_ok=True)
            with open(self._promotion_log_path(), "a") as f:
                f.write(json.dumps({
                    "type": "promote",
                    "to_mode": "active",
                    "reason": reason,
                    "ts": time.time(),
                    "report": report.to_dict(),
                }) + "\n")
        except Exception as e:
            log.warning("promotion log write failed: %s", e)

    def _record_demotion(self, *, reason: str) -> None:
        try:
            os.makedirs(os.path.dirname(self._promotion_log_path()), exist_ok=True)
            with open(self._promotion_log_path(), "a") as f:
                f.write(json.dumps({
                    "type": "demote",
                    "to_mode": "shadow",
                    "reason": reason,
                    "ts": time.time(),
                }) + "\n")
        except Exception as e:
            log.warning("demotion log write failed: %s", e)

    def recent_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        path = self._promotion_log_path()
        if not os.path.exists(path):
            return []
        try:
            with open(path) as f:
                lines = f.readlines()[-limit:]
            return [json.loads(line) for line in lines if line.strip()]
        except Exception:
            return []
