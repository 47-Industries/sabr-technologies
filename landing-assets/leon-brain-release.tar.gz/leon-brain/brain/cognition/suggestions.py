"""
Phase 13 — Suggestions system.

Generates safe proactive suggestions and pushes them as dashboard events
(via the same presence/observation channel Phase 13 uses for awareness).
Suggestions are READ-ONLY hints — Leon never executes them autonomously.

Sources of suggestions:

  • Tool immune system     — degraded/broken tools (e.g. "Brave CDP down")
  • Self-repair queue      — pending Dean-approval items
  • Watchdog               — service health drops
  • Awareness loop         — Dean's been idle 30+ min on the same window
  • Lessons                — applicable lessons not visibly being followed
  • Drives                 — strong drive Dean might want to know about
                              (e.g. continuity drive saying "no project
                              touched in 4h, want to pick something up?")

Suggestions are deduplicated by (kind, key) for `cooldown_s` so we don't
spam Dean with the same nudge every tick.

Severity:
  info     — informational; dashboard chip
  hint     — soft nudge; small toast
  warn     — visible alert; needs attention soon
  urgent   — pop into Leon's voice path (still no auto-action)

The runner ticks every ~60s and emits via emit_fn(channel, payload).
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Callable, Deque, Dict, List, Optional

log = logging.getLogger("leon.cognition.suggestions")


@dataclass
class Suggestion:
    ts: float
    key: str           # dedup key: f"{source}:{detail}"
    source: str        # tool_health | watchdog | awareness | lessons | drives | repair
    severity: str      # info | hint | warn | urgent
    text: str
    detail: Dict[str, Any]
    cooldown_s: float = 600.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class Suggestions:
    """Background suggestion generator + emitter."""

    def __init__(
        self,
        *,
        emit_fn: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        interval_s: Optional[float] = None,
        history_size: int = 200,
        tool_health=None,
        watchdog=None,
        awareness=None,
        lessons=None,
        drives=None,
        self_repair=None,
    ):
        if interval_s is None:
            interval_s = float(os.environ.get("LEON_SUGGESTIONS_TICK_S", "60.0"))
        self.interval_s = max(10.0, interval_s)
        self.emit_fn = emit_fn
        self.tool_health = tool_health
        self.watchdog = watchdog
        self.awareness = awareness
        self.lessons = lessons
        self.drives = drives
        self.self_repair = self_repair

        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._history: Deque[Suggestion] = deque(maxlen=history_size)
        self._last_seen_at: Dict[str, float] = {}

    # -- lifecycle -----------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="leon-suggestions", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t is not None:
            t.join(timeout=2.0)

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # -- public --------------------------------------------------------

    def recent(self, limit: int = 30) -> List[Dict[str, Any]]:
        return [s.to_dict() for s in list(self._history)[-limit:]]

    def tick_now(self) -> List[Suggestion]:
        out = self._generate()
        return out

    # -- loop ----------------------------------------------------------

    def _run(self) -> None:
        try:
            self._generate()
        except Exception as e:
            log.warning("initial suggestions tick failed: %s", e)
        while not self._stop.is_set():
            self._stop.wait(self.interval_s)
            if self._stop.is_set():
                break
            try:
                self._generate()
            except Exception as e:
                log.warning("suggestions tick failed: %s", e)

    def _generate(self) -> List[Suggestion]:
        now = time.time()
        proposed: List[Suggestion] = []

        # 1) Tool health — broken or degraded
        if self.tool_health is not None:
            try:
                s = self.tool_health.summary()
                if s.get("broken", 0) >= 1:
                    proposed.append(Suggestion(
                        ts=now,
                        key=f"tool_health:broken_count:{s['broken']}",
                        source="tool_health", severity="warn",
                        text=f"{s['broken']} tool(s) broken — check tool health panel",
                        detail={"summary": s},
                        cooldown_s=900.0,
                    ))
                if s.get("degraded", 0) >= 3:
                    proposed.append(Suggestion(
                        ts=now,
                        key=f"tool_health:degraded_count:{s['degraded']}",
                        source="tool_health", severity="hint",
                        text=f"{s['degraded']} tool(s) degraded",
                        detail={"summary": s},
                        cooldown_s=1800.0,
                    ))
            except Exception as e:
                log.warning("suggestions: tool_health probe failed: %s", e)

        # 2) Watchdog — overall != healthy
        if self.watchdog is not None:
            try:
                rep = self.watchdog.report() or {}
                overall = rep.get("overall")
                if overall and overall != "healthy":
                    proposed.append(Suggestion(
                        ts=now,
                        key=f"watchdog:overall:{overall}",
                        source="watchdog",
                        severity="warn" if overall == "degraded" else "urgent",
                        text=f"system {overall}",
                        detail={"failed_checks": [
                            c["name"] for c in rep.get("checks", [])
                            if not c.get("ok")
                        ]},
                        cooldown_s=600.0,
                    ))
            except Exception as e:
                log.warning("suggestions: watchdog probe failed: %s", e)

        # 3) Self-repair pending approval
        if self.self_repair is not None:
            try:
                rs = self.self_repair.stats()
                if rs.get("pending_approval", 0) > 0:
                    proposed.append(Suggestion(
                        ts=now,
                        key=f"repair:pending:{rs['pending_approval']}",
                        source="repair", severity="hint",
                        text=f"{rs['pending_approval']} repair item(s) awaiting your approval",
                        detail=rs,
                        cooldown_s=1800.0,
                    ))
            except Exception as e:
                log.warning("suggestions: repair probe failed: %s", e)

        # 4) Awareness — long idle
        if self.awareness is not None:
            try:
                snap = self.awareness.snapshot_dict() or {}
                idle = float(snap.get("idle_secs") or 0)
                if idle > 1800:  # 30 min
                    proposed.append(Suggestion(
                        ts=now,
                        key="awareness:long_idle",
                        source="awareness", severity="info",
                        text=f"You've been idle {int(idle/60)} min",
                        detail={"snapshot": snap},
                        cooldown_s=3600.0,
                    ))
            except Exception as e:
                log.warning("suggestions: awareness probe failed: %s", e)

        # 5) Drives — loudest
        if self.drives is not None:
            try:
                loud = self.drives.loudest()
                if loud and isinstance(loud, str) and loud not in ("homeostasis", "rest"):
                    proposed.append(Suggestion(
                        ts=now,
                        key=f"drive:{loud}",
                        source="drives", severity="info",
                        text=f"drive: {loud}",
                        detail={"drive": loud},
                        cooldown_s=1800.0,
                    ))
            except Exception as e:
                log.warning("suggestions: drives probe failed: %s", e)

        # Dedup + emit
        kept: List[Suggestion] = []
        for s in proposed:
            last = self._last_seen_at.get(s.key, 0.0)
            if (now - last) < s.cooldown_s:
                continue
            self._last_seen_at[s.key] = now
            self._history.append(s)
            kept.append(s)
            if self.emit_fn is not None:
                try:
                    self.emit_fn("suggestion", s.to_dict())
                except Exception as e:
                    log.warning("suggestions emit failed: %s", e)
        return kept


__all__ = ["Suggestions", "Suggestion"]
