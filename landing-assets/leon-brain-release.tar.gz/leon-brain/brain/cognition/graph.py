"""
Graph memory — entities, relations, episode linkage.

Replaces flat retrieval with an associative graph that learns over time.
Entities are extracted from each episode's args, action name, active app,
and time bucket; edges are inferred from temporal precedence within a
session, failure correlation, and co-occurrence.

The graph sits ON TOP of the episode log (Phase 1 substrate). It does not
replace `knowledge_store` — instead, on bootstrap it backfills entities
from the existing knowledge.db so retrieval is useful from day one rather
than empty until episodes accumulate.

Entity types (small, fixed alphabet — keep coverage > 90% with these):
  app          — application identity (brave, vscode, slack)
  url          — full URL with hostname extracted into name
  file         — filesystem path
  project      — repo / project root
  action       — tool/action archetype (browser.dom_click, screen.capture)
  person       — named human (Dean, plus anyone in knowledge.db)
  concept      — free-form noun phrase from knowledge or distillation
  time_pattern — bucket like 'night-coding', 'morning-meetings'

Edge relations:
  precedes        — A → B observed within same session in temporal order
  follows         — symmetric inverse of precedes
  breaks          — A failure correlates with B failure shortly after
  succeeds        — A success correlates with B success
  mentions        — A and B appeared in the same episode
  co_occurs       — A and B observed together often (weight derived from
                    mention count)
  depends_on      — manually asserted strong precedes (e.g. consolidation
                    output for a known macro)
  similar_to      — string-similarity entity dedupe link

All weights are unbounded positive floats that grow with support and
decay during consolidation. Weight 0 means the edge has decayed and should
be pruned.
"""

from __future__ import annotations

import difflib
import hashlib
import json as _json_mod  # explicit alias since we already import json elsewhere
import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

log = logging.getLogger("leon.cognition.graph")


# ── Phase 11E — text matching helpers (stdlib only) ───────────────────────

_TYPE_WEIGHTS = {
    "project":       1.5,
    "app":           1.3,
    "person":        1.2,
    "url":           1.0,
    "concept":       1.0,
    "action":        0.9,
    "file":          0.6,
    "time_pattern":  0.4,
}


def _normalize(text: str) -> str:
    if not text:
        return ""
    t = text.lower().strip()
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return t.strip()


def _acronym(name: str) -> str:
    """Pull leading letters from multi-word entity name."""
    parts = re.split(r"[\s_\-.]+", name.lower())
    if len(parts) < 2:
        return ""
    return "".join(p[0] for p in parts if p)


# H2 fix: SequenceMatcher is O(n*m). Called per-entity across a 250-row pool
# from GraphMemory.search() in the responder hot path (LEON_COGNITION_RETRIEVAL).
# An unbounded user query (e.g. pasted log file) would blow the request thread.
# Clamp both sides defensively at the leaf — cheap, no callers to update.
_FUZZY_MAX_LEN = 128

def _fuzzy_ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if len(a) > _FUZZY_MAX_LEN:
        a = a[:_FUZZY_MAX_LEN]
    if len(b) > _FUZZY_MAX_LEN:
        b = b[:_FUZZY_MAX_LEN]
    return difflib.SequenceMatcher(None, a, b).ratio()


def match_score(
    query: str,
    entity_name: str,
    entity_type: str,
    *,
    last_seen: float = 0.0,
    now: Optional[float] = None,
    aliases: Optional[List[str]] = None,
) -> float:
    """Composite relevance score for ranking entities against a query.

    Score layers (best wins, then type+recency adjusted):
      exact normalized → 1.0
      alias exact      → 0.95
      substring        → 0.8
      acronym match    → 0.7
      token containment → 0.5..0.65
      fuzzy ratio      → 0.3..0.5
    """
    # H2 fix: clamp inputs before any O(n*m) work. _normalize already lowercases
    # + strips punct; clamp BEFORE that so we don't normalize 10KB of garbage.
    if query and len(query) > 256:
        query = query[:256]
    if entity_name and len(entity_name) > 128:
        entity_name = entity_name[:128]
    q = _normalize(query)
    n = _normalize(entity_name)
    if not q or not n:
        return 0.0
    # Bail out of token-by-token fuzzy loop on huge tokenizations.
    # 32 tokens × 32 tokens × O(n*m) is already 1024 fuzzy_ratio calls; beyond
    # that, fall through to a single fuzzy_ratio on the joined strings.
    _q_tokens_count = q.count(" ") + 1
    _skip_token_fuzzy = _q_tokens_count > 32

    base = 0.0
    if q == n:
        base = 1.0
    elif aliases and any(_normalize(a) == q for a in aliases):
        base = 0.95
    elif q in n or n in q:
        base = 0.8
    else:
        acr = _acronym(entity_name)
        if acr and (acr in q.replace(" ", "") or q.replace(" ", "") == acr):
            base = 0.7
        else:
            q_tokens = q.split()
            n_tokens = n.split()
            best = 0.0
            for qt in q_tokens:
                if len(qt) < 3:
                    continue
                for nt in n_tokens:
                    if qt == nt:
                        best = max(best, 0.65)
                    elif qt in nt or nt in qt:
                        best = max(best, 0.5)
                    elif not _skip_token_fuzzy:
                        r = _fuzzy_ratio(qt, nt)
                        if r > 0.85:
                            best = max(best, 0.4 * r)
            if best > 0:
                base = best
            else:
                r = _fuzzy_ratio(q, n)
                if r > 0.6:
                    base = 0.3 * r

    if base == 0:
        return 0.0
    base *= _TYPE_WEIGHTS.get(entity_type, 1.0)
    if last_seen and now:
        age = max(0.0, now - last_seen)
        if age < 3600:
            base += 0.3 * (1.0 - age / 3600)
        elif age < 86400:
            base += 0.1 * (1.0 - age / 86400)
    return base


# ── Schema ──────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS entities (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    type            TEXT NOT NULL,
    name            TEXT NOT NULL,
    canonical_key   TEXT NOT NULL UNIQUE,
    mention_count   INTEGER DEFAULT 1,
    salience        REAL DEFAULT 1.0,
    first_seen      REAL,
    last_seen       REAL,
    metadata_json   TEXT
);
CREATE INDEX IF NOT EXISTS idx_ent_type ON entities(type);
CREATE INDEX IF NOT EXISTS idx_ent_lastseen ON entities(last_seen);
CREATE INDEX IF NOT EXISTS idx_ent_salience ON entities(salience DESC);

CREATE TABLE IF NOT EXISTS edges (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    src_id          INTEGER NOT NULL,
    dst_id          INTEGER NOT NULL,
    relation        TEXT NOT NULL,
    weight          REAL DEFAULT 1.0,
    support_count   INTEGER DEFAULT 1,
    first_seen      REAL,
    last_seen       REAL,
    UNIQUE(src_id, dst_id, relation)
);
CREATE INDEX IF NOT EXISTS idx_edge_src ON edges(src_id, relation);
CREATE INDEX IF NOT EXISTS idx_edge_dst ON edges(dst_id, relation);
CREATE INDEX IF NOT EXISTS idx_edge_weight ON edges(weight DESC);

CREATE TABLE IF NOT EXISTS episode_entities (
    episode_id      INTEGER NOT NULL,
    entity_id       INTEGER NOT NULL,
    role            TEXT,  -- 'subject' | 'object' | 'context'
    PRIMARY KEY(episode_id, entity_id, role)
);
CREATE INDEX IF NOT EXISTS idx_epe_episode ON episode_entities(episode_id);
CREATE INDEX IF NOT EXISTS idx_epe_entity  ON episode_entities(entity_id);
"""


# ── Extraction helpers ──────────────────────────────────────────────────────

_URL_RE = re.compile(r"https?://[^\s\"'<>]+")
_PATH_RE = re.compile(r"(?:/[\w.\-]+){2,}")


def _known_projects() -> tuple:
    """Project names worth minting an entity for, for THIS install.

    Always the SI's own name; on the original, also the owner's projects.
    Empty of owner material on every shipped build — brain/owner_facts.py is
    excluded from the tarball, so brain.origin returns (). Computed per call
    rather than at import so a rename takes effect without a restart; the
    backfill runs once, so the cost is irrelevant.
    """
    names = []
    try:
        from brain.identity import si_name
        n = (si_name() or "").strip().lower()
        if n and n != "si":
            names.append(n)
    except Exception:
        pass
    try:
        from brain.origin import owner_projects
        names.extend(owner_projects())
    except Exception:
        pass
    return tuple(dict.fromkeys(names))
_DOMAIN_RE = re.compile(r"^[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")


def _canonical_key(etype: str, name: str) -> str:
    return f"{etype}::{name.lower().strip()}"


def _bucket_to_time_pattern(bucket: str) -> Optional[str]:
    """Convert episode bucket key into a coarse time_pattern entity name."""
    if not bucket:
        return None
    parts = bucket.split("|")
    if len(parts) < 4:
        return None
    hour_band = parts[0]
    return f"{hour_band}-default"


def _project_from_path(path: str) -> Optional[str]:
    """Extract a project root name from a filesystem path."""
    if not path:
        return None
    parts = [p for p in path.split("/") if p]
    if len(parts) < 2:
        return None
    # Common pattern: /home/USER/Desktop/PROJECT/...
    for i, p in enumerate(parts):
        if p == "Desktop" and i + 1 < len(parts):
            return parts[i + 1]
    # Fallback: top 2 segments
    return parts[1] if len(parts) > 1 else parts[0]


# ── Main store ──────────────────────────────────────────────────────────────

@dataclass
class Entity:
    id: int
    type: str
    name: str
    canonical_key: str
    mention_count: int = 1
    salience: float = 1.0
    first_seen: float = 0.0
    last_seen: float = 0.0
    metadata: Optional[Dict[str, Any]] = None


def _default_db_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "cognition_graph.db")


class GraphMemory:
    """Entity-relation graph backed by SQLite. Thread-safe; WAL-mode."""

    def __init__(self, episodes, *, db_path: Optional[str] = None,
                 knowledge_db_path: Optional[str] = None):
        self.episodes = episodes
        self.path = db_path or _default_db_path()
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._lock = threading.RLock()  # reentrant — we have nested operations
        self._conn = sqlite3.connect(self.path, check_same_thread=False, timeout=5.0)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(_SCHEMA)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.commit()

        # Per-session memory of previous episode → enables 'precedes' edges
        self._prev_episode_entities: List[int] = []
        self._prev_session_id: Optional[str] = None
        self._prev_success: Optional[bool] = None
        self._prev_action_name: Optional[str] = None

        # Backfill from knowledge.db if available
        self._knowledge_db_path = knowledge_db_path or self._default_knowledge_path()
        self._backfilled = False

    @staticmethod
    def _default_knowledge_path() -> str:
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        return os.path.join(root, "brain_state", "knowledge.db")

    # -- entity/edge primitives ------------------------------------------

    def entity_get_or_create(
        self,
        etype: str,
        name: str,
        *,
        salience: float = 1.0,
        metadata: Optional[Dict[str, Any]] = None,
        ts: Optional[float] = None,
    ) -> int:
        ts = ts if ts is not None else time.time()
        ckey = _canonical_key(etype, name)
        with self._lock:
            row = self._conn.execute(
                "SELECT id, mention_count, salience FROM entities WHERE canonical_key=?",
                (ckey,),
            ).fetchone()
            if row is not None:
                # Bump mention count and salience (running average toward 1×salience)
                new_count = row["mention_count"] + 1
                new_sal = (row["salience"] * row["mention_count"] + salience) / new_count
                self._conn.execute(
                    "UPDATE entities SET mention_count=?, salience=?, last_seen=? WHERE id=?",
                    (new_count, new_sal, ts, row["id"]),
                )
                self._conn.commit()
                return int(row["id"])
            cur = self._conn.execute(
                """INSERT INTO entities
                   (type, name, canonical_key, mention_count, salience,
                    first_seen, last_seen, metadata_json)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (etype, name[:200], ckey, 1, salience, ts, ts,
                 None if metadata is None else __import__("json").dumps(metadata)),
            )
            self._conn.commit()
            return int(cur.lastrowid)

    def edge_upsert(
        self,
        src_id: int,
        dst_id: int,
        relation: str,
        *,
        weight_delta: float = 1.0,
        ts: Optional[float] = None,
    ) -> None:
        if src_id == dst_id:
            return
        ts = ts if ts is not None else time.time()
        with self._lock:
            row = self._conn.execute(
                "SELECT id, weight, support_count FROM edges WHERE src_id=? AND dst_id=? AND relation=?",
                (src_id, dst_id, relation),
            ).fetchone()
            if row is not None:
                self._conn.execute(
                    """UPDATE edges SET
                       weight = weight + ?,
                       support_count = support_count + 1,
                       last_seen = ?
                       WHERE id=?""",
                    (weight_delta, ts, row["id"]),
                )
            else:
                self._conn.execute(
                    """INSERT INTO edges
                       (src_id, dst_id, relation, weight, support_count,
                        first_seen, last_seen)
                       VALUES (?,?,?,?,?,?,?)""",
                    (src_id, dst_id, relation, weight_delta, 1, ts, ts),
                )
            self._conn.commit()

    def link_episode_entity(self, episode_id: int, entity_id: int, role: str = "subject") -> None:
        with self._lock:
            try:
                self._conn.execute(
                    "INSERT OR IGNORE INTO episode_entities (episode_id, entity_id, role) VALUES (?,?,?)",
                    (episode_id, entity_id, role),
                )
                self._conn.commit()
            except Exception as e:
                log.warning("link_episode_entity failed: %s", e)

    # -- extraction from episode -----------------------------------------

    def record_episode(self, episode_row: Dict[str, Any]) -> Dict[str, Any]:
        """Pull entities + edges out of a closed-episode row.

        Returns a small report of what was extracted.
        """
        ts = float(episode_row.get("ts") or time.time())
        ep_id = int(episode_row.get("id") or 0)
        action_name = episode_row.get("action_name") or ""
        action_args_json = episode_row.get("action_args_json") or "{}"
        active_app = episode_row.get("active_app")
        bucket = episode_row.get("bucket") or ""
        session_id = episode_row.get("session_id")
        success = bool(episode_row.get("success"))
        salience = float(episode_row.get("salience") or 1.0)

        # Parse args (best effort)
        try:
            args = __import__("json").loads(action_args_json) if action_args_json else {}
        except Exception:
            args = {}

        new_entity_ids: List[int] = []
        report = {"entities_created_or_bumped": 0, "edges_created_or_bumped": 0}

        # Action entity
        if action_name:
            aid = self.entity_get_or_create("action", action_name, salience=salience, ts=ts)
            new_entity_ids.append(aid)
            self.link_episode_entity(ep_id, aid, role="subject")
            report["entities_created_or_bumped"] += 1

        # Active app entity
        if active_app:
            appid = self.entity_get_or_create("app", active_app, salience=salience, ts=ts)
            new_entity_ids.append(appid)
            self.link_episode_entity(ep_id, appid, role="context")
            report["entities_created_or_bumped"] += 1

        # Time pattern
        tp = _bucket_to_time_pattern(bucket)
        if tp:
            tpid = self.entity_get_or_create("time_pattern", tp, salience=salience * 0.5, ts=ts)
            new_entity_ids.append(tpid)
            self.link_episode_entity(ep_id, tpid, role="context")

        # Walk args
        for k, v in args.items():
            if not isinstance(v, str):
                continue
            for m in _URL_RE.finditer(v):
                url = m.group(0)
                try:
                    host = urlparse(url).hostname or url[:80]
                except ValueError:
                    host = url[:80]
                uid = self.entity_get_or_create("url", host, salience=salience, ts=ts,
                                                 metadata={"sample_url": url})
                new_entity_ids.append(uid)
                self.link_episode_entity(ep_id, uid, role="object")
                report["entities_created_or_bumped"] += 1
            for m in _PATH_RE.finditer(v):
                path = m.group(0)
                fid = self.entity_get_or_create("file", path, salience=salience, ts=ts)
                new_entity_ids.append(fid)
                self.link_episode_entity(ep_id, fid, role="object")
                report["entities_created_or_bumped"] += 1
                proj = _project_from_path(path)
                if proj:
                    pid = self.entity_get_or_create("project", proj, salience=salience, ts=ts)
                    new_entity_ids.append(pid)
                    self.link_episode_entity(ep_id, pid, role="context")
                    # file located_in project
                    self.edge_upsert(fid, pid, "located_in", weight_delta=salience, ts=ts)
                    report["edges_created_or_bumped"] += 1

        # Dedupe within this episode's entity set
        new_entity_ids = list(dict.fromkeys(new_entity_ids))

        # Co-occurrence edges among all extracted entities
        for i, e1 in enumerate(new_entity_ids):
            for e2 in new_entity_ids[i + 1:]:
                self.edge_upsert(e1, e2, "co_occurs", weight_delta=0.25 * salience, ts=ts)
                self.edge_upsert(e2, e1, "co_occurs", weight_delta=0.25 * salience, ts=ts)
                report["edges_created_or_bumped"] += 2

        # Temporal precedence — only within same session
        if session_id is not None and self._prev_session_id == session_id and self._prev_episode_entities:
            for prev_e in self._prev_episode_entities:
                for cur_e in new_entity_ids:
                    self.edge_upsert(prev_e, cur_e, "precedes",
                                     weight_delta=0.5 * salience, ts=ts)
                    report["edges_created_or_bumped"] += 1
            # Failure correlation
            if self._prev_success is False and not success:
                # Both failed in sequence → breaks edge between actions
                if self._prev_action_name and action_name:
                    prev_action_id = self.entity_get_or_create("action", self._prev_action_name)
                    cur_action_id  = self.entity_get_or_create("action", action_name)
                    self.edge_upsert(prev_action_id, cur_action_id, "breaks",
                                     weight_delta=1.0, ts=ts)
                    report["edges_created_or_bumped"] += 1
            elif self._prev_success and success:
                if self._prev_action_name and action_name:
                    prev_action_id = self.entity_get_or_create("action", self._prev_action_name)
                    cur_action_id  = self.entity_get_or_create("action", action_name)
                    self.edge_upsert(prev_action_id, cur_action_id, "succeeds",
                                     weight_delta=0.5, ts=ts)
                    report["edges_created_or_bumped"] += 1

        # Update session memory
        self._prev_episode_entities = new_entity_ids
        self._prev_session_id = session_id
        self._prev_success = success
        self._prev_action_name = action_name

        return report

    # -- backfill from knowledge.db --------------------------------------

    def backfill_from_knowledge(self, max_rows: int = 2000) -> Dict[str, Any]:
        """Read recent knowledge.db rows and seed entities from their text.

        Cheap NER via regex over text. Creates 'concept' entities and links
        them via co_occurs. Idempotent — only runs once unless explicitly re-called.
        """
        if self._backfilled:
            return {"already_done": True}
        report = {"rows_processed": 0, "entities_seeded": 0}
        if not os.path.exists(self._knowledge_db_path):
            self._backfilled = True
            return {"skipped": "no knowledge.db at " + self._knowledge_db_path}
        try:
            kc = sqlite3.connect(self._knowledge_db_path, timeout=3.0)
            kc.row_factory = sqlite3.Row
            # Pull most recent rows — schema may vary, try a couple shapes
            for table in ("knowledge", "memories", "facts"):
                try:
                    rows = kc.execute(
                        f"SELECT * FROM {table} ORDER BY rowid DESC LIMIT ?", (max_rows,)
                    ).fetchall()
                    break
                except sqlite3.OperationalError:
                    continue
            else:
                kc.close()
                self._backfilled = True
                return {"skipped": "no compatible table found"}
            for r in rows:
                # text could be in 'text' / 'content' / 'fact' / 'body'
                text = None
                for col in ("text", "content", "fact", "body", "message"):
                    if col in r.keys() and r[col]:
                        text = r[col]
                        break
                if not text:
                    continue
                report["rows_processed"] += 1
                # URLs (urlparse can raise on malformed strings — wrap individually)
                for m in _URL_RE.finditer(text):
                    url = m.group(0)
                    try:
                        host = urlparse(url).hostname or url[:80]
                    except ValueError:
                        host = url[:80]
                    self.entity_get_or_create("url", host, salience=0.5)
                    report["entities_seeded"] += 1
                # File paths
                for m in _PATH_RE.finditer(text):
                    self.entity_get_or_create("file", m.group(0), salience=0.5)
                    report["entities_seeded"] += 1
                # Project mentions (heuristic: words from known project list).
                # The list is the SI's own name plus, on the ORIGINAL install
                # only, the owner's projects. It used to be a shipped literal
                # ("47 industries", "integrity network", "element 115", …), so
                # backfilling a customer's knowledge.db minted project
                # entities named after a stranger's companies whenever a row
                # happened to contain the word "integrity" — entities that
                # then rank, associate and surface as if the customer owned
                # them. See brain/origin.py.
                lower = text.lower()
                for proj in _known_projects():
                    if proj in lower:
                        self.entity_get_or_create("project", proj, salience=0.7)
                        report["entities_seeded"] += 1
            kc.close()
        except Exception as e:
            log.warning("backfill_from_knowledge failed: %s", e)
            report["error"] = str(e)[:200]
        self._backfilled = True
        return report

    # -- query API --------------------------------------------------------

    def get_entity(self, entity_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            row = self._conn.execute("SELECT * FROM entities WHERE id=?", (entity_id,)).fetchone()
        return dict(row) if row else None

    def find_entity(self, etype: str, name: str) -> Optional[Dict[str, Any]]:
        ckey = _canonical_key(etype, name)
        with self._lock:
            row = self._conn.execute("SELECT * FROM entities WHERE canonical_key=?", (ckey,)).fetchone()
        return dict(row) if row else None

    def top_entities(self, etype: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        with self._lock:
            if etype:
                rows = self._conn.execute(
                    """SELECT * FROM entities WHERE type=?
                       ORDER BY (salience * mention_count) DESC LIMIT ?""",
                    (etype, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT * FROM entities
                       ORDER BY (salience * mention_count) DESC LIMIT ?""",
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    def neighbors(
        self,
        entity_id: int,
        relation: Optional[str] = None,
        *,
        direction: str = "out",
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        with self._lock:
            if direction == "out":
                if relation:
                    rows = self._conn.execute(
                        """SELECT e.*, edges.relation, edges.weight, edges.support_count
                           FROM edges JOIN entities e ON e.id = edges.dst_id
                           WHERE edges.src_id=? AND edges.relation=?
                           ORDER BY edges.weight DESC LIMIT ?""",
                        (entity_id, relation, limit),
                    ).fetchall()
                else:
                    rows = self._conn.execute(
                        """SELECT e.*, edges.relation, edges.weight, edges.support_count
                           FROM edges JOIN entities e ON e.id = edges.dst_id
                           WHERE edges.src_id=?
                           ORDER BY edges.weight DESC LIMIT ?""",
                        (entity_id, limit),
                    ).fetchall()
            else:  # 'in'
                if relation:
                    rows = self._conn.execute(
                        """SELECT e.*, edges.relation, edges.weight, edges.support_count
                           FROM edges JOIN entities e ON e.id = edges.src_id
                           WHERE edges.dst_id=? AND edges.relation=?
                           ORDER BY edges.weight DESC LIMIT ?""",
                        (entity_id, relation, limit),
                    ).fetchall()
                else:
                    rows = self._conn.execute(
                        """SELECT e.*, edges.relation, edges.weight, edges.support_count
                           FROM edges JOIN entities e ON e.id = edges.src_id
                           WHERE edges.dst_id=?
                           ORDER BY edges.weight DESC LIMIT ?""",
                        (entity_id, limit),
                    ).fetchall()
        return [dict(r) for r in rows]

    def related_to(self, etype: str, name: str, *, limit: int = 10) -> List[Dict[str, Any]]:
        ent = self.find_entity(etype, name)
        if not ent:
            return []
        return self.neighbors(int(ent["id"]), limit=limit)

    # ── Phase 11E — fuzzy / acronym / type-weighted search ─────────────

    def search(self, query: str, *, limit: int = 5,
               pool_size: int = 250) -> List[Dict[str, Any]]:
        """Find entities relevant to a query string. Uses match_score
        (substring / acronym / fuzzy / token-overlap) with type weighting
        and recency boost. Stdlib only — no external NER.

        Returns list of {entity_dict, score, match_kind}.
        """
        if not query or not query.strip():
            return []
        now = time.time()
        # Pull a pool of candidate entities — top by mention*salience
        with self._lock:
            rows = self._conn.execute(
                """SELECT * FROM entities
                   ORDER BY (salience * mention_count) DESC LIMIT ?""",
                (pool_size,),
            ).fetchall()
        scored: List[Tuple[float, Dict[str, Any]]] = []
        for r in rows:
            d = dict(r)
            score = match_score(
                query, d["name"], d["type"],
                last_seen=d.get("last_seen") or 0.0,
                now=now,
            )
            if score > 0.3:  # cut-off — anything below this is noise
                scored.append((score, d))
        scored.sort(key=lambda x: -x[0])
        out = []
        for score, ent in scored[:limit]:
            out.append({**ent, "match_score": round(score, 3)})
        return out

    # -- consolidation hooks ---------------------------------------------

    def decay_edges(self, *, factor: float = 0.95, below_weight: float = 0.05,
                    older_than_hours: float = 168.0) -> int:
        """Decay edges that haven't been touched recently. Prune those at zero."""
        cutoff = time.time() - older_than_hours * 3600
        with self._lock:
            # Decay
            self._conn.execute(
                "UPDATE edges SET weight = weight * ? WHERE last_seen < ?",
                (factor, cutoff),
            )
            # Prune
            cur = self._conn.execute("DELETE FROM edges WHERE weight < ?", (below_weight,))
            n = cur.rowcount
            self._conn.commit()
        return int(n or 0)

    def reinforce_chain(self, action_ids: List[int], *, weight_delta: float = 0.5) -> int:
        """Boost precedes-weight along a successful action chain."""
        boosted = 0
        for i in range(len(action_ids) - 1):
            self.edge_upsert(action_ids[i], action_ids[i + 1], "precedes",
                             weight_delta=weight_delta)
            boosted += 1
        return boosted

    # -- introspection ---------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            ent_count = self._conn.execute("SELECT COUNT(*) AS n FROM entities").fetchone()["n"]
            edge_count = self._conn.execute("SELECT COUNT(*) AS n FROM edges").fetchone()["n"]
            type_breakdown = {}
            for r in self._conn.execute(
                "SELECT type, COUNT(*) AS n FROM entities GROUP BY type"
            ).fetchall():
                type_breakdown[r["type"]] = int(r["n"])
            rel_breakdown = {}
            for r in self._conn.execute(
                "SELECT relation, COUNT(*) AS n FROM edges GROUP BY relation"
            ).fetchall():
                rel_breakdown[r["relation"]] = int(r["n"])
        return {
            "entities_total": int(ent_count),
            "edges_total": int(edge_count),
            "entity_types": type_breakdown,
            "edge_relations": rel_breakdown,
            "db_path": self.path,
            "backfilled": self._backfilled,
        }

    def close_db(self) -> None:
        with self._lock:
            self._conn.close()
