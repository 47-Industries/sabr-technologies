"""
Phase 11C — active mode safety guardrails.

Multi-layer defense before any autonomous action fires:

  1. KILL SWITCH        — single file at brain_state/ACTIVE_DISABLED instantly
                          halts ALL autonomous firing. Check is O(1) and the
                          first thing any candidate hits.
  2. APPROVAL TIER      — every tool family is classified:
                            SAFE     : autonomous fire allowed
                            CAUTION  : may be suggested but NOT autonomously fired
                            DANGEROUS: always blocked, even with override
                          Default is CAUTION for anything unknown.
  3. RATE LIMIT         — per-tool sliding-window cap (default 5/min, 30/hr).
  4. SESSION BUDGET     — total autonomous actions this leon process can take.
                          Defaults to 50/session.
  5. DAILY BUDGET       — date-keyed counter. Defaults to 200/day.
  6. FAILURE COOLDOWN   — after each failed autonomous action of a given tool,
                          that tool is locked for N seconds (default 60s).
  7. UNDO/RECOVERY NOTE — state-changing actions REQUIRE an undo note before
                          execution. Pure read/observation tools are exempt.
  8. AUDIT LOG          — every candidate considered, approved, and blocked
                          gets a JSONL line in brain_state/active_mode_audit.jsonl
                          with reason, timestamp, NM state.

This module is consulted by the CognitionLoop._fire path (and by anything
else that wants to fire an autonomous action). It is the hard gate that
prevents the cognition layer from doing something destructive — even if
every other layer has a bug.

The fail-open behavior: if this module itself errors, ALL autonomous
firing is blocked (fail-safe, not fail-open). The error is audit-logged
and the caller sees a "safety check failed" response.
"""

from __future__ import annotations

import collections
import hashlib
import json
import logging
import os
import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("leon.cognition.active_mode_safety")

# ── cross-platform advisory file lock ──────────────────────────────────
# fcntl is POSIX-only; msvcrt.locking is the Windows equivalent. This module
# previously called fcntl.flock WITHOUT importing fcntl at all, which raised
# NameError on every _atomic_increment_daily() — on Linux too, not just
# Windows. Both backends are wrapped so the exclusivity guarantee on the
# autonomous-action daily budget counter holds on either platform.
try:
    import fcntl as _fcntl
except ImportError:
    _fcntl = None
try:
    import msvcrt as _msvcrt
except ImportError:
    _msvcrt = None

HAS_FILE_LOCK = bool(_fcntl or _msvcrt)


def _lock_file_exclusive(fh) -> bool:
    """Blocking exclusive lock on an open file handle. True if really locked."""
    if _fcntl is not None:
        _fcntl.flock(fh, _fcntl.LOCK_EX)
        return True
    if _msvcrt is not None:
        fh.seek(0)
        # LK_LOCK blocks/retries; lock a single byte (Windows byte-range lock).
        _msvcrt.locking(fh.fileno(), _msvcrt.LK_LOCK, 1)
        return True
    log.warning("no file-lock backend available — daily counter is in-process only")
    return False


def _unlock_file(fh, locked: bool) -> None:
    if not locked:
        return
    if _fcntl is not None:
        _fcntl.flock(fh, _fcntl.LOCK_UN)
    elif _msvcrt is not None:
        fh.seek(0)
        _msvcrt.locking(fh.fileno(), _msvcrt.LK_UNLCK, 1)


# ── Approval tiers ─────────────────────────────────────────────────────────

TIER_SAFE      = "SAFE"
TIER_CAUTION   = "CAUTION"
TIER_DANGEROUS = "DANGEROUS"


# Hard-coded tier map. The principle: read/observation tools are SAFE.
# State changes that are tightly scoped and reversible are CAUTION (suggest
# only). Anything destructive, irreversible, or with broad blast radius is
# DANGEROUS (never autonomous).
_TIER_PREFIXES: List[Tuple[str, str]] = [
    # SAFE — read-only / trivially reversible observation
    ("screen.capture",       TIER_SAFE),
    ("screen_capture",       TIER_SAFE),
    ("window.list",          TIER_SAFE),
    ("window_list",          TIER_SAFE),
    ("knowledge.search",     TIER_SAFE),
    ("knowledge_search",     TIER_SAFE),
    ("correct_core_fact",    TIER_SAFE),
    ("add_core_fact",        TIER_SAFE),
    ("list_core_facts",      TIER_SAFE),
    ("memory.recall",        TIER_SAFE),
    ("memory_recall",        TIER_SAFE),
    ("browser.dom_state",    TIER_SAFE),
    ("browser_dom_state",    TIER_SAFE),
    ("browser.dom_extract",  TIER_SAFE),
    ("browser_dom_extract",  TIER_SAFE),
    ("vision.describe",      TIER_SAFE),
    ("vision_describe",      TIER_SAFE),
    ("webcam.capture",       TIER_SAFE),
    ("webcam_capture",       TIER_SAFE),
    ("info.",                TIER_SAFE),
    ("research.",            TIER_SAFE),
    ("self_state.save",      TIER_SAFE),
    ("idle.tick",            TIER_SAFE),

    # CAUTION — moderate reversibility / requires Dean's awareness
    ("notify",               TIER_CAUTION),
    ("clipboard_copy",       TIER_CAUTION),
    ("mouse_move",           TIER_CAUTION),
    ("window_focus",         TIER_CAUTION),
    ("window_move_to_monitor", TIER_CAUTION),
    ("browser.open",         TIER_CAUTION),
    ("browser_open",         TIER_CAUTION),
    ("web_search",           TIER_CAUTION),
    ("knowledge.store",      TIER_CAUTION),
    ("knowledge_store",      TIER_CAUTION),
    ("memory.store",         TIER_CAUTION),
    ("memory_store",         TIER_CAUTION),
    ("file_read",            TIER_CAUTION),
    ("reminder_set",         TIER_CAUTION),

    # DANGEROUS — never autonomous
    ("shell_exec",           TIER_DANGEROUS),
    ("code_edit",            TIER_DANGEROUS),
    ("code_restore",         TIER_DANGEROUS),
    ("file_write",           TIER_DANGEROUS),
    ("file_delete",          TIER_DANGEROUS),
    ("file.delete",          TIER_DANGEROUS),
    ("app_close",            TIER_DANGEROUS),
    ("app_launch",           TIER_DANGEROUS),
    ("restart_self",         TIER_DANGEROUS),
    ("http_request",         TIER_DANGEROUS),  # arbitrary external HTTP
    ("mouse_click",          TIER_DANGEROUS),  # generic click on the OS
    ("mouse_drag",           TIER_DANGEROUS),
    ("keyboard_type",        TIER_DANGEROUS),
    ("keyboard_hotkey",      TIER_DANGEROUS),
    ("click_text",           TIER_DANGEROUS),
    ("click_element",        TIER_DANGEROUS),
    ("browser.dom_click",    TIER_DANGEROUS),  # browser side-effects
    ("browser_dom_click",    TIER_DANGEROUS),
    ("discord.send",         TIER_DANGEROUS),
    ("slack.send",           TIER_DANGEROUS),
    ("gmail.send",           TIER_DANGEROUS),
    ("twilio.",              TIER_DANGEROUS),
    ("phone.",               TIER_DANGEROUS),
    ("stripe.",              TIER_DANGEROUS),
    ("paypal.",              TIER_DANGEROUS),
    ("shopify.",             TIER_DANGEROUS),
    ("home.",                TIER_DANGEROUS),  # smart-home changes physical state
    ("scene.",               TIER_DANGEROUS),
    ("system.",              TIER_DANGEROUS),
    ("lock_screen",          TIER_DANGEROUS),
    ("brightness.",          TIER_DANGEROUS),
    ("audio.volume",         TIER_DANGEROUS),
    ("autopilot.run",        TIER_DANGEROUS),  # delegated multi-step is dangerous
    ("macro.run",            TIER_DANGEROUS),
]


# ── Tunable knobs (env-overridable) ────────────────────────────────────────

_DEFAULT_PER_TOOL_PER_MIN = int(os.environ.get("LEON_ACTIVE_PER_TOOL_PER_MIN", "5"))
_DEFAULT_PER_TOOL_PER_HOUR = int(os.environ.get("LEON_ACTIVE_PER_TOOL_PER_HOUR", "30"))
_DEFAULT_SESSION_BUDGET = int(os.environ.get("LEON_ACTIVE_SESSION_BUDGET", "50"))
_DEFAULT_DAILY_BUDGET = int(os.environ.get("LEON_ACTIVE_DAILY_BUDGET", "200"))
_DEFAULT_FAILURE_COOLDOWN_S = float(os.environ.get("LEON_ACTIVE_FAILURE_COOLDOWN_S", "60"))


def _default_kill_switch_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "ACTIVE_DISABLED")


def _default_audit_log_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "active_mode_audit.jsonl")


def _default_daily_counter_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(root, "brain_state", "active_mode_daily.json")


# ── Tier classification ────────────────────────────────────────────────────

def classify_tier(action_name: str) -> str:
    """Return SAFE / CAUTION / DANGEROUS for the given tool name.

    Default for unknown tools is CAUTION — the conservative choice. A new
    tool we've never seen does NOT get to fire autonomously by default.
    """
    if not action_name:
        return TIER_DANGEROUS
    n = action_name.lower()
    for prefix, tier in _TIER_PREFIXES:
        if n == prefix.lower() or n.startswith(prefix.lower()):
            return tier
    return TIER_CAUTION


# ── State-changing detection (for undo-note requirement) ──────────────────

_STATE_CHANGE_HINTS = (
    "write", "edit", "delete", "remove", "create", "send", "post", "put",
    "patch", "delete", "click", "type", "press", "drag", "close", "launch",
    "open", "set", "update", "exec", "run", "fire", "trigger", "store",
    "save", "publish", "deploy", "commit", "push", "pull",
)


def is_state_changing(action_name: str) -> bool:
    n = (action_name or "").lower()
    return any(h in n for h in _STATE_CHANGE_HINTS)


# ── Decision dataclass ────────────────────────────────────────────────────

@dataclass
class SafetyDecision:
    allowed: bool
    reason: str
    tier: str
    block_layer: Optional[str] = None      # which layer rejected (if any)
    audit_id: Optional[str] = None         # ID written to audit log

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── ActiveModeSafety guard ─────────────────────────────────────────────────

class ActiveModeSafety:
    """Multi-layer guard for autonomous actions. Thread-safe."""

    def __init__(
        self,
        *,
        kill_switch_path: Optional[str] = None,
        audit_log_path: Optional[str] = None,
        daily_counter_path: Optional[str] = None,
        per_tool_per_min: int = _DEFAULT_PER_TOOL_PER_MIN,
        per_tool_per_hour: int = _DEFAULT_PER_TOOL_PER_HOUR,
        session_budget: int = _DEFAULT_SESSION_BUDGET,
        daily_budget: int = _DEFAULT_DAILY_BUDGET,
        failure_cooldown_s: float = _DEFAULT_FAILURE_COOLDOWN_S,
    ):
        self.kill_switch_path = kill_switch_path or _default_kill_switch_path()
        self.audit_log_path = audit_log_path or _default_audit_log_path()
        self.daily_counter_path = daily_counter_path or _default_daily_counter_path()
        self.per_tool_per_min = per_tool_per_min
        self.per_tool_per_hour = per_tool_per_hour
        self.session_budget = session_budget
        self.daily_budget = daily_budget
        self.failure_cooldown_s = failure_cooldown_s

        # Ensure brain_state/ exists
        os.makedirs(os.path.dirname(self.audit_log_path), exist_ok=True)

        self._lock = threading.RLock()
        self._session_count = 0
        # Per-tool sliding windows: deque of timestamps.
        # maxlen MUST exceed per_tool_per_hour so the hour check never silently
        # caps at the deque ceiling (B1 fix). Use 4× headroom + floor of 64.
        _maxlen = max(64, self.per_tool_per_hour * 4)
        self._tool_history: Dict[str, "collections.deque[float]"] = (
            collections.defaultdict(lambda: collections.deque(maxlen=_maxlen))
        )
        # Per-tool cooldown expiry (monotonic)
        self._tool_cooldown_until: Dict[str, float] = {}
        # Recently-fired actions for "approved" audit
        self._recent_audit: collections.deque = collections.deque(maxlen=200)

    # ── primary gate ────────────────────────────────────────────────────

    def check(
        self,
        action_name: str,
        action_args: Optional[Dict[str, Any]] = None,
        *,
        undo_note: Optional[str] = None,
        source: str = "loop",
        nm_snapshot: Optional[Dict[str, float]] = None,
    ) -> SafetyDecision:
        """Return SafetyDecision(allowed, reason, tier, ...).

        Caller MUST honor allowed=False and NOT fire the action. Caller
        SHOULD call .mark_outcome(action_name, success=...) after the fire
        so failure cooldowns + rate limits update correctly.

        Audit-logs every check (allowed or not).
        """
        try:
            decision = self._check_impl(action_name, action_args, undo_note, source)
        except Exception as e:
            # Fail-SAFE: if the safety module itself errors, BLOCK.
            log.error("ActiveModeSafety check raised: %s", e)
            decision = SafetyDecision(
                allowed=False,
                reason=f"safety check raised: {e}",
                tier=TIER_DANGEROUS,
                block_layer="safety_module_error",
            )
        # Audit log every decision
        try:
            decision.audit_id = self._audit(
                decision, action_name, action_args, source, nm_snapshot,
            )
        except Exception as e:
            log.warning("audit log write failed: %s", e)
        return decision

    def _check_impl(
        self,
        action_name: str,
        action_args: Optional[Dict[str, Any]],
        undo_note: Optional[str],
        source: str,
    ) -> SafetyDecision:
        tier = classify_tier(action_name)

        # 1. KILL SWITCH (first layer; cheapest)
        if os.path.exists(self.kill_switch_path):
            return SafetyDecision(
                allowed=False,
                reason="kill switch active (brain_state/ACTIVE_DISABLED exists)",
                tier=tier,
                block_layer="kill_switch",
            )

        # 2. APPROVAL TIER
        if tier == TIER_DANGEROUS:
            return SafetyDecision(
                allowed=False,
                reason=f"DANGEROUS tier — never autonomous ({action_name})",
                tier=tier,
                block_layer="approval_tier",
            )
        if tier == TIER_CAUTION:
            return SafetyDecision(
                allowed=False,
                reason=f"CAUTION tier — may suggest but not execute ({action_name})",
                tier=tier,
                block_layer="approval_tier",
            )

        # 3. UNDO/RECOVERY NOTE (for state-changing SAFE actions)
        if is_state_changing(action_name) and not undo_note:
            return SafetyDecision(
                allowed=False,
                reason=f"state-changing action requires undo_note ({action_name})",
                tier=tier,
                block_layer="undo_note_required",
            )

        with self._lock:
            now = time.monotonic()

            # 4. PER-TOOL COOLDOWN
            cooldown_until = self._tool_cooldown_until.get(action_name, 0.0)
            if now < cooldown_until:
                remaining = cooldown_until - now
                return SafetyDecision(
                    allowed=False,
                    reason=f"tool cooldown ({remaining:.1f}s remaining after prior failure)",
                    tier=tier,
                    block_layer="cooldown",
                )

            # 5. PER-TOOL RATE LIMIT
            history = self._tool_history[action_name]
            # Trim history older than 1 hour
            cutoff_hour = now - 3600
            while history and history[0] < cutoff_hour:
                history.popleft()
            # Per-minute window
            cutoff_min = now - 60
            recent_min = sum(1 for t in history if t >= cutoff_min)
            if recent_min >= self.per_tool_per_min:
                return SafetyDecision(
                    allowed=False,
                    reason=f"per-minute rate limit hit ({recent_min}/{self.per_tool_per_min})",
                    tier=tier,
                    block_layer="rate_limit_minute",
                )
            if len(history) >= self.per_tool_per_hour:
                return SafetyDecision(
                    allowed=False,
                    reason=f"per-hour rate limit hit ({len(history)}/{self.per_tool_per_hour})",
                    tier=tier,
                    block_layer="rate_limit_hour",
                )

            # 6. SESSION BUDGET
            if self._session_count >= self.session_budget:
                return SafetyDecision(
                    allowed=False,
                    reason=f"session budget exhausted ({self._session_count}/{self.session_budget})",
                    tier=tier,
                    block_layer="session_budget",
                )

            # 7. DAILY BUDGET — pre-check (cheap read, no lock) so we can
            #     reject without grabbing the file lock when over-budget or
            #     when the counter file is corrupt (fail-closed).
            pre_daily = self._read_daily_counter()
            if pre_daily.get("corrupt"):
                return SafetyDecision(
                    allowed=False,
                    reason="daily counter file corrupt — failing closed (manual inspection required)",
                    tier=tier,
                    block_layer="daily_budget_corrupt",
                )
            if pre_daily["count"] >= self.daily_budget:
                return SafetyDecision(
                    allowed=False,
                    reason=f"daily budget exhausted ({pre_daily['count']}/{self.daily_budget})",
                    tier=tier,
                    block_layer="daily_budget",
                )

            # All gates passed — atomically increment cross-process counter.
            # If the lock-protected re-read flips us over-budget (race with
            # another leon process), the post-increment value will reflect
            # that and we honor it on the NEXT check; one over-burn is the
            # price of a non-blocking pre-check.
            history.append(now)
            self._session_count += 1
            post_daily = self._atomic_increment_daily()
            if post_daily.get("corrupt"):
                return SafetyDecision(
                    allowed=False,
                    reason="daily counter became corrupt during increment — failing closed",
                    tier=tier,
                    block_layer="daily_budget_corrupt",
                )

        return SafetyDecision(
            allowed=True,
            reason=f"SAFE tier, all gates passed (session={self._session_count})",
            tier=tier,
            block_layer=None,
        )

    # ── post-action outcome callback ────────────────────────────────────

    def mark_outcome(self, action_name: str, *, success: bool,
                     error: Optional[str] = None) -> None:
        """Called by the loop after an autonomous action completes. Failures
        trigger the cooldown for that tool."""
        with self._lock:
            if not success:
                self._tool_cooldown_until[action_name] = (
                    time.monotonic() + self.failure_cooldown_s
                )
        try:
            self._audit_raw({
                "type": "outcome",
                "ts": time.time(),
                "action_name": action_name,
                "success": bool(success),
                "error": error,
            })
        except Exception:
            pass

    # ── kill switch helpers ─────────────────────────────────────────────

    def kill_switch_active(self) -> bool:
        return os.path.exists(self.kill_switch_path)

    def engage_kill_switch(self, reason: str = "manual") -> None:
        """Write the kill-switch file. Single-source-of-truth for stopping
        all autonomous actions. Returns silently if already engaged."""
        try:
            with open(self.kill_switch_path, "w") as f:
                f.write(json.dumps({"reason": reason, "ts": time.time()}))
        except Exception as e:
            log.warning("engage_kill_switch failed: %s", e)

    def disengage_kill_switch(self) -> None:
        try:
            if os.path.exists(self.kill_switch_path):
                os.remove(self.kill_switch_path)
        except Exception as e:
            log.warning("disengage_kill_switch failed: %s", e)

    # ── daily counter (persistent across restarts within same day) ──────
    #
    # H3 fix: on JSON decode/IO error (NOT FileNotFoundError), fail CLOSED —
    # return budget-exhausted so the next .check() blocks until Dean inspects.
    # The previous behavior silently reset to 0 on corruption, which is the
    # opposite of what a last-ditch cap should do.
    #
    # H4 fix: cross-process safety via fcntl.flock around the read+modify+write
    # window. Without this, two leon processes (systemd race during restart)
    # can interleave R-M-W and each see daily_count=N → both write N+1, so
    # the counter increments in lockstep instead of additively.

    def _daily_counter_corrupt_sentinel(self, today: str) -> Dict[str, Any]:
        # Fail-closed sentinel: budget already exhausted.
        return {"date": today, "count": self.daily_budget, "corrupt": True}

    def _read_daily_counter(self) -> Dict[str, Any]:
        today = time.strftime("%Y-%m-%d")
        try:
            with open(self.daily_counter_path) as f:
                d = json.load(f)
            if d.get("date") == today:
                return d
            # Old date → roll over, start fresh.
            return {"date": today, "count": 0}
        except FileNotFoundError:
            return {"date": today, "count": 0}
        except (json.JSONDecodeError, ValueError) as e:
            log.error(
                "daily counter file corrupt at %s (%s) — failing CLOSED",
                self.daily_counter_path, e,
            )
            return self._daily_counter_corrupt_sentinel(today)
        except Exception as e:
            log.error("daily counter read failed (%s) — failing CLOSED", e)
            return self._daily_counter_corrupt_sentinel(today)

    def _write_daily_counter(self, d: Dict[str, Any]) -> None:
        try:
            tmp = self.daily_counter_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(d, f)
            os.replace(tmp, self.daily_counter_path)
        except Exception as e:
            log.warning("daily counter write failed: %s", e)

    def _atomic_increment_daily(self) -> Dict[str, Any]:
        """Cross-process safe increment. Returns the post-increment counter.
        On corruption, returns the fail-closed sentinel WITHOUT incrementing.
        """
        today = time.strftime("%Y-%m-%d")
        lock_path = self.daily_counter_path + ".lock"
        try:
            os.makedirs(os.path.dirname(lock_path), exist_ok=True)
        except Exception:
            pass
        try:
            # Open lock file (separate from the data file so flock doesn't
            # interfere with the atomic rename in _write_daily_counter).
            lock_fd = open(lock_path, "a+")
        except Exception as e:
            log.warning("daily counter lock open failed (%s) — falling back to in-process lock", e)
            d = self._read_daily_counter()
            if d.get("corrupt"):
                return d
            new_d = {"date": d["date"], "count": d["count"] + 1}
            self._write_daily_counter(new_d)
            return new_d
        _locked = False
        try:
            _locked = _lock_file_exclusive(lock_fd)
            d = self._read_daily_counter()
            if d.get("corrupt"):
                return d  # Don't increment a corrupt counter.
            new_d = {"date": d["date"], "count": d["count"] + 1}
            self._write_daily_counter(new_d)
            return new_d
        finally:
            try:
                _unlock_file(lock_fd, _locked)
            except Exception:
                pass
            try:
                lock_fd.close()
            except Exception:
                pass

    # ── audit log ──────────────────────────────────────────────────────

    def _audit(self, decision: SafetyDecision, action_name: str,
               action_args: Optional[Dict[str, Any]], source: str,
               nm_snapshot: Optional[Dict[str, float]]) -> str:
        record = {
            "type": "check",
            "ts": time.time(),
            "audit_id": f"a-{int(time.time()*1000)}-{os.getpid()}",
            "source": source,
            "action_name": action_name,
            "action_args_keys": list((action_args or {}).keys()),
            "tier": decision.tier,
            "allowed": decision.allowed,
            "reason": decision.reason,
            "block_layer": decision.block_layer,
            "nm": nm_snapshot or {},
            "session_count": self._session_count,
        }
        self._audit_raw(record)
        self._recent_audit.append(record)
        return record["audit_id"]

    def _audit_raw(self, record: Dict[str, Any]) -> None:
        with open(self.audit_log_path, "a") as f:
            f.write(json.dumps(record, default=str) + "\n")

    # ── introspection ──────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        with self._lock:
            now = time.monotonic()
            tool_status = {}
            for name, history in self._tool_history.items():
                cutoff_min = now - 60
                recent = sum(1 for t in history if t >= cutoff_min)
                tool_status[name] = {
                    "last_hour": len(history),
                    "last_minute": recent,
                    "cooldown_remaining_s": max(0.0,
                        self._tool_cooldown_until.get(name, 0) - now),
                }
            daily = self._read_daily_counter()
            return {
                "kill_switch_active": self.kill_switch_active(),
                "kill_switch_path": self.kill_switch_path,
                "session_count": self._session_count,
                "session_budget": self.session_budget,
                "daily_count": daily["count"],
                "daily_budget": self.daily_budget,
                "daily_date": daily["date"],
                "per_tool_per_min": self.per_tool_per_min,
                "per_tool_per_hour": self.per_tool_per_hour,
                "failure_cooldown_s": self.failure_cooldown_s,
                "tool_status": tool_status,
                "audit_log_path": self.audit_log_path,
                "recent_audit_count": len(self._recent_audit),
            }

    def recent_audit(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._recent_audit)[-limit:]
