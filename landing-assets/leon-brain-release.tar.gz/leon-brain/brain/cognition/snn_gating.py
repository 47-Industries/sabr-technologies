"""
SNN gating — make neuromodulators causally important.

The "honest architecture" doc identified this exact gap: NM levels only
flowed into prompt adjectives. This module translates them into REAL
behavior knobs the cognition loop, action ranker, and responder read:

    dopamine       → exploration_rate        (high DA = try non-greedy options)
                   → action_persistence      (high DA = chase reward, less giving up)
    norepinephrine → confidence_threshold    (high NE = require higher p_success)
                   → interruption_threshold  (high NE = more easily diverted by anomaly)
    acetylcholine  → memory_salience         (high ACh = episodes encoded heavier)
                   → attention_breadth       (high ACh = narrow focus, ignore distractions)
    serotonin      → retry_budget            (high 5HT = patient, more retries)
                   → stability_preference    (high 5HT = prefer known-good actions)

Behavior consequences (concrete examples):
  * High DA + low NE → Leon tries a new tool variant even if a familiar one
    would work — exploration is up, confidence threshold is down.
  * High NE → Leon defers a low-confidence action and asks Dean first instead
    of firing it speculatively.
  * High ACh during user instruction → that episode gets salience 1.8 and
    will dominate future retrievals from similar contexts.
  * Low 5HT + repeated click failures → Leon stops retrying after 1 attempt
    instead of burning 4 retries; raises friction drive instead.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


@dataclass(frozen=True)
class Gates:
    """A snapshot of behavior knobs derived from current NM levels."""
    exploration_rate: float      # 0..1  ε in ε-greedy action selection
    confidence_threshold: float  # 0..1  min p_success to act without deferring
    memory_salience: float       # 0.5..2.0  multiplier on episode reward/encoding
    retry_budget: int            # 0..5   retries before giving up
    attention_breadth: float     # 0..1  1 = wide/diffuse, 0 = laser focus
    interruption_threshold: float# 0..1  drive level needed to interrupt current
    action_persistence: float    # 0..1  willingness to push through partial fails
    stability_preference: float  # 0..1  bias toward repeating known-good actions

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SNNGates:
    """Reads brain.neuromodulators and produces a Gates snapshot.

    Cached for ~250ms because the cognition loop will call .current() many
    times per tick and re-reading the brain dict (which is mutated by the
    100Hz sim thread) costs ~6 dict lookups but more importantly keeps the
    Gates value stable within a single decision.
    """

    def __init__(self, brain: Any, cache_ms: float = 250.0):
        self.brain = brain
        self._cache_ttl_s = cache_ms / 1000.0
        self._cache: Optional[Gates] = None
        self._cache_ts: float = 0.0
        self._lock = threading.Lock()

    # -- public API --------------------------------------------------------

    def current(self) -> Gates:
        now = time.monotonic()
        with self._lock:
            if self._cache is not None and (now - self._cache_ts) < self._cache_ttl_s:
                return self._cache
            nm = self._read_nm()
            g = Gates(
                exploration_rate=self._exploration(nm),
                confidence_threshold=self._conf_threshold(nm),
                memory_salience=self._memory_salience(nm),
                retry_budget=self._retry_budget(nm),
                attention_breadth=self._attention_breadth(nm),
                interruption_threshold=self._interruption(nm),
                action_persistence=self._persistence(nm),
                stability_preference=self._stability(nm),
            )
            self._cache = g
            self._cache_ts = now
            return g

    def explain(self) -> Dict[str, Any]:
        """Human-readable why-these-knobs trace, for the inspection endpoint."""
        nm = self._read_nm()
        g = self.current()
        return {
            "neuromodulators": {k: round(v, 3) for k, v in nm.items()},
            "gates": {k: round(v, 3) if isinstance(v, float) else v
                      for k, v in g.to_dict().items()},
            "rationale": {
                "exploration_rate": f"dopamine={nm.get('dopamine', 0):.2f} → ε={g.exploration_rate:.2f}",
                "confidence_threshold": f"norepinephrine={nm.get('norepinephrine', 0):.2f} → require p_success≥{g.confidence_threshold:.2f}",
                "memory_salience": f"acetylcholine={nm.get('acetylcholine', 0):.2f} → encoding ×{g.memory_salience:.2f}",
                "retry_budget": f"serotonin={nm.get('serotonin', 0):.2f} → {g.retry_budget} retries",
                "attention_breadth": f"acetylcholine={nm.get('acetylcholine', 0):.2f} → breadth={g.attention_breadth:.2f}",
                "interruption_threshold": f"norepinephrine={nm.get('norepinephrine', 0):.2f} → interrupt-at-drive={g.interruption_threshold:.2f}",
                "action_persistence": f"dopamine={nm.get('dopamine', 0):.2f} → persistence={g.action_persistence:.2f}",
                "stability_preference": f"serotonin={nm.get('serotonin', 0):.2f} → repeat-known={g.stability_preference:.2f}",
            },
        }

    # -- mappings (each its own small function so the rationale is auditable)

    def _read_nm(self) -> Dict[str, float]:
        try:
            nm = getattr(self.brain, "neuromodulators", None) or {}
            return {
                "dopamine":       float(nm.get("dopamine", 0.5)),
                "acetylcholine":  float(nm.get("acetylcholine", 0.3)),
                "norepinephrine": float(nm.get("norepinephrine", 0.1)),
                "serotonin":      float(nm.get("serotonin", 0.5)),
            }
        except Exception:
            return {"dopamine": 0.5, "acetylcholine": 0.3,
                    "norepinephrine": 0.1, "serotonin": 0.5}

    @staticmethod
    def _exploration(nm: Dict[str, float]) -> float:
        # Baseline 0.08, scales to 0.55 at peak dopamine.
        # High DA means "novelty is rewarding right now, try things."
        return _clamp(0.08 + 0.47 * nm["dopamine"])

    @staticmethod
    def _conf_threshold(nm: Dict[str, float]) -> float:
        # Baseline 0.45, scales to 0.85 at peak NE.
        # High NE means "be cautious — anomalies are present, double-check first."
        return _clamp(0.45 + 0.40 * nm["norepinephrine"])

    @staticmethod
    def _memory_salience(nm: Dict[str, float]) -> float:
        # 0.5 at low ACh, 2.0 at high ACh. Multiplier on reward and on
        # episode "weight" for future retrieval — implements "we remember
        # what we were paying attention to."
        return _clamp(0.5 + 1.5 * nm["acetylcholine"], 0.5, 2.0)

    @staticmethod
    def _retry_budget(nm: Dict[str, float]) -> int:
        # Low 5HT = impatient (1 retry max). High 5HT = patient (5).
        return int(round(1 + 4 * nm["serotonin"]))

    @staticmethod
    def _attention_breadth(nm: Dict[str, float]) -> float:
        # High ACh narrows attention (low breadth). Inverse mapping.
        return _clamp(1.0 - 0.65 * nm["acetylcholine"], 0.2, 1.0)

    @staticmethod
    def _interruption(nm: Dict[str, float]) -> float:
        # Drive value required before we interrupt current task. High NE =
        # easier to interrupt (anomaly hyperawareness). Low NE = focused.
        return _clamp(0.70 - 0.50 * nm["norepinephrine"], 0.15, 0.95)

    @staticmethod
    def _persistence(nm: Dict[str, float]) -> float:
        # High DA = chase the reward through partial failures.
        return _clamp(0.3 + 0.6 * nm["dopamine"])

    @staticmethod
    def _stability(nm: Dict[str, float]) -> float:
        # High 5HT = prefer the boring familiar thing. Inverse of exploration.
        return _clamp(0.25 + 0.55 * nm["serotonin"])
