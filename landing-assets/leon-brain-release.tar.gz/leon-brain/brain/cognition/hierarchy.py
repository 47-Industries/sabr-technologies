"""
Hierarchy router — classify each user input into the layer that should handle it.

Three layers (Dean's principle #9):

  REACTIVE
    Fast-path canned replies + command-intent matchers that already exist in
    claude_api_responder._maybe_canned_reply() / _maybe_command_action().
    Skip cognition — no need for prediction or planning to answer "hey leon"
    with "Right here." Latency target: <50ms.

  MODEL_DRIVEN
    Default path. Use world_model + rollout to pre-flight any tool the
    responder is about to fire. Inject the cognition prompt augmentation
    so Claude sees current self-model + drives + relevant graph context.
    Latency target: <3s.

  STRATEGIC
    Long-horizon goals ("eventually rebrand to 47I", "make Leon faster
    over time", "I want X but in two weeks"). Should route through
    autopilot with extended planning depth and continuity-drive awareness.
    Latency target: minutes-to-hours of background work.

This module ONLY classifies. It does not execute. The responder (or any
caller) reads the Route and chooses its path. That keeps the router a
pure observer that can be tested in isolation and audited per request.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple


# ── Layer constants ────────────────────────────────────────────────────────

LAYER_REACTIVE  = "reactive"
LAYER_MODEL     = "model_driven"
LAYER_STRATEGIC = "strategic"


# ── Pattern dictionaries (small + auditable) ───────────────────────────────

# Strong reactive markers — short greetings, acknowledgments, single-word
# wake/control phrases. These should hit the canned/fast-path layer.
_REACTIVE_PATTERNS = [
    re.compile(r"^\s*(?:hey|hi|hello|yo|sup|good\s+(?:morning|night|evening))\s*[,!?.]*\s*leon?\s*[!?.]*\s*$", re.I),
    re.compile(r"^\s*leon\s*[!?.]*\s*$", re.I),
    re.compile(r"^\s*(?:thanks|thank you|ty)\s*[!?.]*\s*$", re.I),
    re.compile(r"^\s*(?:stop|shut up|quiet|cancel|nevermind)\s*[!?.]*\s*$", re.I),
    re.compile(r"^\s*(?:are you (?:there|awake|up))\s*\??\s*$", re.I),
    re.compile(r"^\s*(?:daddy'?s home|i'?m back|i'?m here)\s*$", re.I),
]

# Strong command markers — verbs that match existing command-intent table.
# This is a coarse overlay; the responder's own matcher is authoritative.
_COMMAND_VERBS = {
    "play", "pause", "skip", "next", "previous", "stop", "resume",
    "open", "close", "launch", "lock", "unlock", "focus",
    "mute", "unmute", "volume", "brightness",
    "screenshot", "screenshot now", "take a picture", "take a screenshot",
}

# Strategic markers — words that signal long-horizon intent.
_STRATEGIC_MARKERS = [
    re.compile(r"\b(?:eventually|long\s*[-]?\s*term|over\s+time|gradually)\b", re.I),
    re.compile(r"\b(?:in\s+(?:a\s+)?(?:few\s+)?(?:days?|weeks?|months?|years?))\b", re.I),
    re.compile(r"\b(?:rebrand|migrate|refactor\s+the\s+whole|overhaul|redesign|architect)\b", re.I),
    re.compile(r"\b(?:goal|roadmap|strategy|vision|plan\s+for)\b", re.I),
    re.compile(r"\b(?:phase\s*\d|milestone|deliverable)\b", re.I),
    re.compile(r"\b(?:make\s+(?:leon|the\s+brain)\s+(?:better|faster|smarter))\b", re.I),
    re.compile(r"\b(?:learn\s+to|over\s+the\s+next)\b", re.I),
]


@dataclass
class Route:
    layer: str                # reactive / model_driven / strategic
    confidence: float         # 0..1
    reasoning: str            # short human-readable rationale
    recommended_path: str     # "skip_cognition" | "responder_with_context" | "autopilot"
    suggested_cognition_flags: Dict[str, bool] = None  # what prompt sections to include

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if self.suggested_cognition_flags is None:
            d["suggested_cognition_flags"] = {}
        return d


class HierarchyRouter:
    """Classify user input into reactive / model-driven / strategic layer.

    Pure function (modulo cognition snapshot reads). Cheap — <1ms per call.
    """

    def __init__(self, *, gates=None, drives=None, world_model=None,
                 graph=None, self_model=None):
        # All injected dependencies are optional so the router can be
        # used standalone for testing. When present, classification can
        # use richer context (e.g., drives.loudest() biases the route).
        self.gates = gates
        self.drives = drives
        self.world_model = world_model
        self.graph = graph
        self.self_model = self_model

    # -- public --------------------------------------------------------

    def classify(self, user_text: str, *, context: Optional[Dict[str, Any]] = None) -> Route:
        text = (user_text or "").strip()
        if not text:
            return Route(
                layer=LAYER_REACTIVE, confidence=1.0,
                reasoning="empty input",
                recommended_path="skip_cognition",
                suggested_cognition_flags={},
            )

        # 1. Reactive check — short canned-reply / command patterns
        r = self._check_reactive(text)
        if r is not None:
            return r

        # 2. Strategic check — long-horizon keywords win even if other signal
        s = self._check_strategic(text)
        if s is not None:
            return s

        # 3. Default: model-driven path with cognition context
        return self._model_driven_route(text, context)

    # -- internals -----------------------------------------------------

    def _check_reactive(self, text: str) -> Optional[Route]:
        for pat in _REACTIVE_PATTERNS:
            if pat.match(text):
                return Route(
                    layer=LAYER_REACTIVE, confidence=0.95,
                    reasoning=f"matched reactive pattern: {pat.pattern[:60]}",
                    recommended_path="skip_cognition",
                    suggested_cognition_flags={},
                )
        # Short single-verb commands → reactive
        first_word = text.lower().split()[0] if text.split() else ""
        if first_word in _COMMAND_VERBS and len(text.split()) <= 5:
            return Route(
                layer=LAYER_REACTIVE, confidence=0.85,
                reasoning=f"short command intent ({first_word})",
                recommended_path="skip_cognition",
                suggested_cognition_flags={},
            )
        return None

    def _check_strategic(self, text: str) -> Optional[Route]:
        hits = []
        for pat in _STRATEGIC_MARKERS:
            m = pat.search(text)
            if m:
                hits.append(m.group(0))
                if len(hits) >= 2:
                    break
        if not hits:
            return None
        # Confidence proportional to hit count, capped
        conf = min(0.9, 0.5 + 0.2 * len(hits))
        return Route(
            layer=LAYER_STRATEGIC, confidence=conf,
            reasoning=f"strategic markers: {', '.join(hits[:3])}",
            recommended_path="autopilot",
            suggested_cognition_flags={
                "include_identity": True,
                "include_drives": True,
                "include_relevant_entities": True,
                "include_recent_episodes": True,  # strategic benefits from history
            },
        )

    def _model_driven_route(self, text: str,
                             context: Optional[Dict[str, Any]]) -> Route:
        # Cognition flags — pick what's worth including in the prompt
        flags = {
            "include_identity": True,
            "include_drives": False,
            "include_relevant_entities": False,
            "include_recent_episodes": False,
        }
        reasoning_bits = ["default model-driven path"]

        # Drive-loud → mention it in the prompt
        if self.drives is not None:
            loud = self.drives.loudest()
            if loud:
                flags["include_drives"] = True
                reasoning_bits.append(f"loud drive ({loud})")

        # Graph — if any entity in the user text matches a known one, include
        if self.graph is not None:
            matched = self._quick_entity_match(text)
            if matched:
                flags["include_relevant_entities"] = True
                reasoning_bits.append(f"{len(matched)} graph-known entities")

        # NE-driven cautious mode → include recent episodes for context
        if self.gates is not None:
            g = self.gates.current()
            if g.confidence_threshold > 0.7:
                flags["include_recent_episodes"] = True
                reasoning_bits.append(f"high-NE (conf_threshold={g.confidence_threshold:.2f})")

        return Route(
            layer=LAYER_MODEL, confidence=0.75,
            reasoning=", ".join(reasoning_bits),
            recommended_path="responder_with_context",
            suggested_cognition_flags=flags,
        )

    def _quick_entity_match(self, text: str) -> List[Tuple[str, str]]:
        """Lightweight name-token match against graph.top_entities cache.

        Returns up to 5 (type, name) hits whose name appears in `text`.
        Cheap fuzzy — case-insensitive substring. Not a real NER.
        """
        if self.graph is None:
            return []
        text_lower = text.lower()
        out: List[Tuple[str, str]] = []
        try:
            # Pull top-50 across all types as a quick lookup
            tops = self.graph.top_entities(limit=50)
            for ent in tops:
                name = (ent.get("name") or "").lower()
                if len(name) < 3:
                    continue
                if name in text_lower:
                    out.append((ent["type"], ent["name"]))
                    if len(out) >= 5:
                        break
        except Exception:
            pass
        return out

    # -- inspection ----------------------------------------------------

    def explain(self, user_text: str) -> Dict[str, Any]:
        """Verbose classification with intermediate signals — for the endpoint."""
        route = self.classify(user_text)
        explained: Dict[str, Any] = {
            "input": user_text,
            "route": route.to_dict(),
            "signals": {},
        }
        if self.drives is not None:
            try:
                explained["signals"]["loudest_drive"] = self.drives.loudest()
            except Exception:
                pass
        if self.gates is not None:
            try:
                g = self.gates.current()
                explained["signals"]["confidence_threshold"] = round(g.confidence_threshold, 3)
                explained["signals"]["exploration_rate"] = round(g.exploration_rate, 3)
            except Exception:
                pass
        if self.graph is not None:
            try:
                explained["signals"]["graph_entity_matches"] = [
                    {"type": t, "name": n} for (t, n) in self._quick_entity_match(user_text)
                ]
            except Exception:
                pass
        return explained
