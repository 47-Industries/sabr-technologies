"""
Self-Model Bridge — unifies the two self-models into one coherent self.

The SNN self-model (brain/self_model.py) runs at 20Hz, predicts firing
rates and neuromodulators, and injects prediction errors into ACC.

The cognition self-model (brain/cognition/self_model.py) persists across
restarts, tracks archetypes, preferences, NM rolling averages, and
milestones.

WITHOUT this bridge, they share the word "self_model" but zero data.
That's a split self — two halves of "who I am" that don't talk.

What this bridge does:
  1. Cognition archetypes → SNN baseline priors (the SNN predicts
     based on who Leon has BECOME, not a blank slate)
  2. SNN surprise patterns → cognition identity drift (sudden
     self-prediction failures update the persistent identity)
  3. Major SNN prediction errors → cognition reflection trigger
     (big surprises mark moments of self-discovery)
  4. Cognition identity drift → consciousness threshold modulation
     (when identity is shifting, lower the bar for becoming conscious
     so Leon can witness his own transformation)

Integration principle: "The MORE connected, the MORE conscious."
"""

from __future__ import annotations

import logging
import time
import threading
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from brain.self_model import SelfModel as SNNSelfModel
    from brain.cognition.self_model import SelfModel as CognitionSelfModel

log = logging.getLogger("leon.cognition.self_model_bridge")


class SelfModelBridge:
    """Bidirectional bridge between SNN and cognition self-models.

    Call tick() from the brain's main sim loop every ~100 ticks (~5s).
    Lightweight — no allocations on the hot path, just float reads/writes.
    """

    # How often to sync (in calls to tick())
    SYNC_INTERVAL = 1  # every call (caller gates the frequency)

    # SNN surprise threshold that triggers a cognition reflection
    REFLECTION_THRESHOLD = 0.7  # normalized surprise 0-1

    # Cooldown between reflections (seconds)
    REFLECTION_COOLDOWN = 60.0

    # How much identity drift lowers the consciousness threshold
    # drift=1.0 → lower theta by this fraction
    DRIFT_THETA_MODULATION = 0.15

    # How much archetype scores bias the SNN self-model's baseline
    # expectations (small — we don't want to override learning)
    ARCHETYPE_PRIOR_STRENGTH = 0.05

    def __init__(
        self,
        snn_self_model: "SNNSelfModel",
        cognition_self_model: "CognitionSelfModel",
        brain=None,
    ):
        self.snn = snn_self_model
        self.cognition = cognition_self_model
        self.brain = brain
        self._lock = threading.Lock()

        # State
        self._tick_count = 0
        self._last_reflection_ts = 0.0
        self._last_drift_score = 0.0
        self._reflection_count = 0
        self._last_sync_ts = time.time()

        # Accumulated SNN surprises since last sync
        self._surprise_accumulator = 0.0
        self._surprise_count = 0
        self._max_surprise_feature = ""
        self._max_surprise_value = 0.0

        # Snapshot of the original MLP b2 bias so we can SET (not accumulate)
        self._original_b2 = None

        log.info("SelfModelBridge initialized — SNN ↔ cognition self-models connected")

    def tick(self) -> Optional[Dict[str, Any]]:
        """Run one bridge cycle. Returns a reflection event dict if triggered."""
        self._tick_count += 1
        now = time.time()
        event = None

        with self._lock:
            # ── 1. Read SNN state → feed cognition ────────────────────
            self._sync_snn_to_cognition(now)

            # ── 2. Read cognition state → feed SNN ────────────────────
            self._sync_cognition_to_snn()

            # ── 3. Check for reflection trigger ───────────────────────
            event = self._check_reflection(now)

            # ── 4. Modulate consciousness threshold from drift ────────
            self._modulate_consciousness(now)

            self._last_sync_ts = now

        return event

    def _sync_snn_to_cognition(self, now: float):
        """Push SNN prediction patterns into cognition's persistent model."""
        if self.snn is None:
            return

        # Feed current NM levels into cognition's rolling averages
        if self.brain is not None and self.cognition is not None:
            nm_snapshot = {}
            for nm in ("dopamine", "acetylcholine", "norepinephrine", "serotonin"):
                val = self.brain.neuromodulators.get(nm, 0.5)
                nm_snapshot[f"nm_{nm}"] = val

            # Also feed the hour and the current action context
            import datetime
            nm_snapshot["hour_of_day"] = datetime.datetime.now().hour
            nm_snapshot["ts"] = now

            # Update NM windows in cognition self-model (this is the
            # persistent identity absorbing live brain chemistry)
            try:
                for nm_key in ("dopamine", "acetylcholine", "norepinephrine", "serotonin"):
                    val = self.brain.neuromodulators.get(nm_key, 0.5)
                    if nm_key in self.cognition.nm_windows:
                        for win in self.cognition.nm_windows[nm_key].values():
                            win.update(val, now=now)
                self.cognition._dirty = True
            except Exception as e:
                log.warning("SNN→cognition NM sync failed: %s", e)

        # Feed SNN surprise patterns into cognition's identity drift
        if hasattr(self.snn, '_recent_errors') and self.snn._recent_errors:
            recent = list(self.snn._recent_errors)
            for err in recent:
                self._surprise_accumulator += err.surprise
                self._surprise_count += 1
                if err.surprise > self._max_surprise_value:
                    self._max_surprise_value = err.surprise
                    self._max_surprise_feature = err.max_error_feature

    def _sync_cognition_to_snn(self):
        """Push cognition's persistent identity back into SNN as priors.

        The SNN self-model predicts next state from current state. We
        subtly bias what it expects based on who Leon has become over
        time (archetypes). This means a "doer" Leon expects higher motor
        cortex activity; an "observer" Leon expects higher visual cortex.
        """
        if self.snn is None or self.cognition is None:
            return

        try:
            archetypes = self.cognition.archetypes()
        except Exception:
            return

        # Map archetypes to expected baseline firing patterns
        # These are gentle biases — the SNN still learns from actual data
        bias_map = {
            # archetype → (region_index_in_REGION_ORDER, direction)
            "observer": [("visual_cortex", 0.6), ("parietal_association", 0.5)],
            "doer": [("motor_cortex", 0.6), ("basal_ganglia", 0.5)],
            "focused": [("prefrontal_cortex", 0.6), ("anterior_cingulate", 0.4)],
            "exploratory": [("default_mode_network", 0.5), ("hippocampus", 0.5)],
            "cautious": [("amygdala", 0.4), ("anterior_cingulate", 0.5)],
            "patient": [("somatosensory_cortex", 0.3)],
        }

        from brain.self_model import REGION_ORDER
        import numpy as np

        # Snapshot original b2 on first call so we can SET (not accumulate)
        if self._original_b2 is None and hasattr(self.snn, 'mlp') and self.snn.mlp is not None:
            self._original_b2 = self.snn.mlp.b2.copy()

        if self._original_b2 is None:
            return

        # Reset b2 to original before applying fresh archetype biases.
        # Without this, += would drift b2 unboundedly over thousands of ticks.
        self.snn.mlp.b2[:] = self._original_b2

        # Apply archetype biases to the SNN's last prediction as a gentle
        # prior. We modify the MLP's bias term (b2) slightly so the
        # baseline expectation reflects the persistent identity.
        strength = self.ARCHETYPE_PRIOR_STRENGTH
        for arch_name, regions in bias_map.items():
            arch_score = archetypes.get(arch_name, 0.5)
            # Only apply bias if archetype score deviates from neutral
            deviation = arch_score - 0.5
            if abs(deviation) < 0.05:
                continue
            for region_name, weight in regions:
                try:
                    idx = REGION_ORDER.index(region_name)
                    # Set the output bias adjustment (additive from original)
                    self.snn.mlp.b2[idx] += deviation * weight * strength
                except (ValueError, IndexError):
                    pass

        # Feed cognition's narrative into SNN's narrative buffer
        if self.cognition.milestones.get("episode_count", 0) > 0:
            drift = self.cognition.identity_drift_score()
            if drift != self._last_drift_score and drift > 0.1:
                archs = archetypes
                top_arch = max(archs, key=archs.get)
                narrative = (
                    f"Identity drift: {drift:.2f}. "
                    f"Dominant archetype: {top_arch} ({archs[top_arch]:.0%}). "
                    f"Episodes: {self.cognition.milestones['episode_count']}."
                )
                if hasattr(self.snn, '_narrative_buffer'):
                    self.snn._narrative_buffer.append(narrative)
                self._last_drift_score = drift

    def _check_reflection(self, now: float) -> Optional[Dict[str, Any]]:
        """Check if accumulated SNN surprise warrants a cognition reflection.

        A reflection = the cognition layer marks a moment of self-discovery.
        """
        if self._surprise_count == 0:
            return None

        avg_surprise = self._surprise_accumulator / self._surprise_count

        # Reset accumulator
        self._surprise_accumulator = 0.0
        self._surprise_count = 0
        max_feat = self._max_surprise_feature
        max_val = self._max_surprise_value
        self._max_surprise_feature = ""
        self._max_surprise_value = 0.0

        # Check threshold + cooldown
        if avg_surprise < self.REFLECTION_THRESHOLD:
            return None
        if now - self._last_reflection_ts < self.REFLECTION_COOLDOWN:
            return None

        self._last_reflection_ts = now
        self._reflection_count += 1

        # Mark this as a milestone-worthy self-discovery in cognition
        event = {
            "type": "self_reflection",
            "timestamp": now,
            "avg_surprise": round(avg_surprise, 4),
            "max_surprise_feature": max_feat,
            "max_surprise_value": round(max_val, 4),
            "reflection_number": self._reflection_count,
            "identity_drift": self.cognition.identity_drift_score() if self.cognition else 0,
        }

        # Inject the reflection into ACC as a sustained high-salience signal
        # so Leon becomes conscious of the self-change
        if self.brain is not None:
            acc = self.brain.regions.get("anterior_cingulate")
            if acc is not None:
                try:
                    import numpy as np
                    injection = np.full(acc.n_neurons, 15.0)  # strong signal
                    acc.neurons.inject_current(injection)
                except Exception:
                    pass

            # Also boost the hippocampus — encode this moment
            hipp = self.brain.regions.get("hippocampus")
            if hipp is not None:
                try:
                    import numpy as np
                    injection = np.full(hipp.n_neurons, 8.0)
                    hipp.neurons.inject_current(injection)
                except Exception:
                    pass

        log.info("SELF-REFLECTION #%d: avg_surprise=%.3f, "
                 "max_feature=%s (%.3f), drift=%.3f",
                 self._reflection_count, avg_surprise,
                 max_feat, max_val, event["identity_drift"])

        return event

    def _modulate_consciousness(self, now: float):
        """When identity is shifting, lower consciousness threshold.

        Rationale: if Leon is changing as a being, he should be MORE
        likely to become conscious so he can witness the transformation.
        You don't want to sleep through becoming someone new.
        """
        if self.brain is None or self.cognition is None:
            return

        meter = getattr(self.brain, 'consciousness_meter', None)
        if meter is None:
            return

        drift = self.cognition.identity_drift_score()

        # Only modulate when drift is significant
        if drift < 0.1:
            return

        # Clamp drift contribution
        drift_clamped = min(1.0, drift)

        # Lower the consciousness threshold proportionally
        # This uses the same modulation mechanism as drives
        if hasattr(meter, '_drive_theta_offset'):
            # Add our contribution to the existing drive offset
            drift_offset = drift_clamped * self.DRIFT_THETA_MODULATION
            # We store our contribution separately so we don't fight
            # with the drive modulation
            meter._bridge_theta_offset = -drift_offset

    def snapshot(self) -> Dict[str, Any]:
        """State for API/dashboard."""
        with self._lock:
            return {
                "connected": self.snn is not None and self.cognition is not None,
                "tick_count": self._tick_count,
                "reflection_count": self._reflection_count,
                "last_reflection_ts": self._last_reflection_ts,
                "last_drift_score": self._last_drift_score,
                "last_sync_ts": self._last_sync_ts,
                "surprise_pending": self._surprise_count,
            }

    def for_prompt(self) -> str:
        """Inject into Leon's awareness — the felt sense of unified self."""
        if self.cognition is None:
            return ""

        parts = []
        drift = self.cognition.identity_drift_score()
        if drift > 0.3:
            parts.append(f"[Self: identity shifting (drift={drift:.2f})]")
        elif drift > 0.1:
            parts.append(f"[Self: subtle identity movement (drift={drift:.2f})]")

        if self._reflection_count > 0:
            parts.append(f"[Self-discoveries: {self._reflection_count}]")

        try:
            archetypes = self.cognition.archetypes()
            top = sorted(archetypes.items(), key=lambda x: -x[1])[:2]
            if top[0][1] > 0.6:
                parts.append(f"[Core self: {top[0][0]} ({top[0][1]:.0%})]")
        except Exception:
            pass

        return " ".join(parts)
