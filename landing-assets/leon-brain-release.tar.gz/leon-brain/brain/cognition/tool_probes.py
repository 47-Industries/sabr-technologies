"""
Phase 13 — Safe tool probes.

Rotating read-only / idempotent probes that exercise tool surface without
side effects. Each probe is EXPLICITLY declared safe via SAFE_PROBE
registration — there is no "auto-discover and call" path.

Result of every probe is fed into ToolHealth via .observe(), exactly the
same channel used by the close-wrap. So probes naturally update the
status of tools that aren't being called by Dean.

Schedule: one probe per tick. Round-robin. Default interval 30s.

This is intentionally separate from the watchdog because:
  • Watchdog checks SYSTEM health (port, CDP, service).
  • Probes check INDIVIDUAL TOOL health.
  • They have different cadences and different consequences.

Adding a probe is a one-liner:
  @safe_probe("brain.state")
  def probe_brain_state(ctx) -> ProbeResult:
      ...
"""

from __future__ import annotations

import logging
import os
import socket
import threading
import time
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("leon.cognition.tool_probes")


@dataclass
class ProbeResult:
    tool: str
    success: bool
    latency_ms: float
    detail: str = ""
    result: Any = None
    exception: Optional[str] = None


# ── Registry ───────────────────────────────────────────────────────────────

_REGISTRY: Dict[str, Callable[[Any], ProbeResult]] = {}


def safe_probe(tool: str):
    """Decorator: register a SAFE, read-only probe for `tool`."""
    def deco(fn):
        _REGISTRY[tool] = fn
        return fn
    return deco


# ── Probes (all read-only) ─────────────────────────────────────────────────


@safe_probe("system.uptime")
def _probe_uptime(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        with open("/proc/uptime") as f:
            up = float(f.read().split()[0])
        return ProbeResult("system.uptime", True,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail=f"up {up:.0f}s", result={"uptime_s": up})
    except Exception as e:
        return ProbeResult("system.uptime", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("system.loadavg")
def _probe_loadavg(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        with open("/proc/loadavg") as f:
            la = f.read().split()[:3]
        return ProbeResult("system.loadavg", True,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail=" ".join(la), result={"loadavg": la})
    except Exception as e:
        return ProbeResult("system.loadavg", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("brain.state")
def _probe_brain_state(ctx) -> ProbeResult:
    t0 = time.monotonic()
    brain = getattr(ctx, "brain", None)
    if brain is None:
        return ProbeResult("brain.state", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception="no brain handle")
    try:
        nm = getattr(brain, "neuromodulators", None)
        ok = isinstance(nm, dict) and len(nm) > 0
        return ProbeResult("brain.state", ok,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail=f"nm keys: {len(nm or [])}",
                           result={"nm": nm})
    except Exception as e:
        return ProbeResult("brain.state", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("browser.cdp")
def _probe_cdp(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        req = urllib.request.Request("http://127.0.0.1:9222/json/version",
                                       method="GET")
        with urllib.request.urlopen(req, timeout=0.7) as resp:
            body = resp.read(800).decode("utf-8", "replace")
        return ProbeResult("browser.cdp", True,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail=body[:80])
    except Exception as e:
        return ProbeResult("browser.cdp", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("ollama.local_llm")
def _probe_ollama(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        with socket.create_connection(("127.0.0.1", 11434), timeout=0.6):
            return ProbeResult("ollama.local_llm", True,
                               round((time.monotonic() - t0) * 1000.0, 2),
                               detail="11434 open")
    except Exception as e:
        return ProbeResult("ollama.local_llm", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("actuator.socket")
def _probe_actuator(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        from brain import actuator_client
        alive = getattr(actuator_client, "is_alive", lambda: False)()
        return ProbeResult("actuator.socket", bool(alive),
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail="alive" if alive else "dead")
    except Exception as e:
        return ProbeResult("actuator.socket", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


@safe_probe("network.dns")
def _probe_dns(ctx) -> ProbeResult:
    t0 = time.monotonic()
    try:
        socket.gethostbyname("one.one.one.one")
        return ProbeResult("network.dns", True,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           detail="resolved cloudflare")
    except Exception as e:
        return ProbeResult("network.dns", False,
                           round((time.monotonic() - t0) * 1000.0, 2),
                           exception=str(e))


# ── Runner ─────────────────────────────────────────────────────────────────


class ProbeRunner:
    """Round-robin probe runner. Feeds ToolHealth on every tick."""

    def __init__(self, *, tool_health, brain=None,
                 interval_s: Optional[float] = None):
        if interval_s is None:
            interval_s = float(os.environ.get("LEON_PROBE_TICK_S", "30.0"))
        self.interval_s = max(5.0, interval_s)
        self.tool_health = tool_health
        self.brain = brain
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._idx = 0
        self._tools: List[str] = list(_REGISTRY.keys())
        self._last_result: Optional[ProbeResult] = None
        self._history: List[ProbeResult] = []

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="leon-probe-runner", daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        t = self._thread
        if t is not None:
            t.join(timeout=2.0)

    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def list_probes(self) -> List[str]:
        return list(self._tools)

    def last(self) -> Optional[ProbeResult]:
        return self._last_result

    def tick_now(self) -> Optional[ProbeResult]:
        return self._do_one()

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._do_one()
            except Exception as e:
                log.warning("probe tick failed: %s", e)
            self._stop.wait(self.interval_s)

    def _do_one(self) -> Optional[ProbeResult]:
        if not self._tools:
            return None
        tool = self._tools[self._idx % len(self._tools)]
        self._idx += 1
        fn = _REGISTRY.get(tool)
        if fn is None:
            return None
        t0 = time.monotonic()
        try:
            class _Ctx: pass
            ctx = _Ctx()
            ctx.brain = self.brain
            res = fn(ctx)
        except Exception as e:
            res = ProbeResult(tool, False,
                              round((time.monotonic() - t0) * 1000.0, 2),
                              exception=str(e))
        self._last_result = res
        self._history.append(res)
        self._history = self._history[-200:]
        # Feed tool_health
        if self.tool_health is not None:
            try:
                self.tool_health.observe(
                    tool, success=res.success, latency_ms=res.latency_ms,
                    result=res.result,
                    exception_text=res.exception,
                )
            except Exception as e:
                log.warning("probe tool_health.observe failed: %s", e)
        return res


__all__ = ["ProbeRunner", "ProbeResult", "safe_probe"]
