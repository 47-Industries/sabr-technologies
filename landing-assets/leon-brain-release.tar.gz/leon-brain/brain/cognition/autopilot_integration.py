"""
Autopilot integration — pre-flight rollout.simulate() for each plan step.

When LEON_COGNITION_AUTOPILOT=on:
  Before autopilot fires a step, ask the cognition layer's Rollout to
  simulate that action in the current context. If the recommendation is
  "abort" (low reversibility + thin data), the step is SKIPPED with a
  cognition_aborted result. If "defer", the step still runs but a flag
  is set so the caller can know cognition wanted to wait.

When off (default), this is pure pass-through.

Hooks into brain/autopilot.py:_run_step with a one-line guard. No new
dependencies on autopilot internals.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Optional

log = logging.getLogger("leon.cognition.autopilot_integration")


def is_autopilot_cognition_enabled() -> bool:
    return os.environ.get("LEON_COGNITION_AUTOPILOT", "off").lower() in (
        "on", "1", "true", "yes",
    )


def _get_cognition():
    try:
        import server  # type: ignore
        return getattr(server, "cognition", None)
    except Exception:
        return None


def maybe_preflight_step(
    tool: str,
    tool_args: Optional[Dict[str, Any]] = None,
    *,
    force: bool = False,
    remaining_plan: Optional[list] = None,
) -> Dict[str, Any]:
    """Returns a decision dict:
        {"proceed": True}                          → run the step normally
        {"proceed": True, "warning": str}          → run but cognition has concerns
        {"proceed": False, "reason": str}          → skip the step

    If cognition is off / unavailable, always returns {"proceed": True}.

    Phase 11A — if `remaining_plan` is provided (list of {tool, args} dicts
    for the steps AFTER this one), run a multi-step beam search across the
    full path. Otherwise fall back to single-step simulate().
    """
    if not (force or is_autopilot_cognition_enabled()):
        return {"proceed": True}
    cog = _get_cognition()
    if cog is None or getattr(cog, "rollout", None) is None:
        return {"proceed": True}
    try:
        ctx = cog.loop._build_context()
        # Try multi-step rollout when we have a real chain
        if remaining_plan and len(remaining_plan) >= 1:
            chain_candidates = [{"kind": "tool", "name": tool, "args": tool_args or {}}]
            for s in remaining_plan[:4]:  # cap depth at this step + 4 ahead = 5
                chain_candidates.append({
                    "kind": "tool",
                    "name": s.get("tool"),
                    "args": s.get("args") or {},
                })
            chain = cog.rollout.simulate_chain(
                chain_candidates, ctx, depth=min(len(chain_candidates), 3),
                beam_width=3,
            )
            decision: Dict[str, Any] = {
                "chain_simulation": chain.to_dict(),
            }
            if chain.recommendation == "abort":
                decision.update({
                    "proceed": False,
                    "reason": f"chain aborted: {chain.reason}",
                })
                return decision
            if chain.recommendation == "defer":
                decision.update({
                    "proceed": True,
                    "warning": f"chain would defer: {chain.reason}",
                })
                return decision
            decision["proceed"] = True
            return decision

        # Fallback: single-step
        sim = cog.rollout.simulate("tool", tool, tool_args or {}, ctx)
    except Exception as e:
        log.warning("preflight simulate failed: %s", e)
        return {"proceed": True}

    if sim.recommendation == "abort":
        return {
            "proceed": False,
            "reason": f"cognition aborted: {sim.reason}",
            "prediction": sim.prediction.to_dict(),
            "utility": sim.utility,
            "reversibility": sim.reversibility,
        }
    if sim.recommendation == "defer":
        return {
            "proceed": True,
            "warning": f"cognition would defer: {sim.reason}",
            "prediction": sim.prediction.to_dict(),
            "utility": sim.utility,
        }
    return {
        "proceed": True,
        "prediction": sim.prediction.to_dict(),
        "utility": sim.utility,
    }


def maybe_record_run_outcome(
    *,
    goal: str,
    steps: int,
    success: bool,
    duration_s: float,
    failed_steps: int = 0,
) -> None:
    """After an autopilot run completes, log a 'run' episode. Lets the world
    model and self-model learn about full-plan outcomes, not just per-step."""
    if not is_autopilot_cognition_enabled():
        return
    cog = _get_cognition()
    if cog is None or getattr(cog, "loop", None) is None:
        return
    try:
        cog.loop.record_tool_call(
            "autopilot.run",
            {"goal": goal[:120], "steps": steps, "failed_steps": failed_steps},
            {"ok": success, "duration_s": duration_s, "failed_steps": failed_steps},
            duration_s * 1000.0,
            kind="response",
            success_override=success,
        )
    except Exception as e:
        log.warning("autopilot record_run_outcome failed: %s", e)


def maybe_reinforce_successful_chain(action_names: list) -> int:
    """If autopilot completed a multi-step plan successfully, reinforce the
    corresponding graph chain so future hypotheticals favor it. No-op if
    cognition or graph is unavailable. Returns number of edges boosted."""
    if not is_autopilot_cognition_enabled():
        return 0
    cog = _get_cognition()
    if cog is None or getattr(cog, "graph", None) is None:
        return 0
    try:
        action_ids = []
        for name in action_names:
            if name:
                aid = cog.graph.entity_get_or_create("action", name)
                action_ids.append(aid)
        if len(action_ids) < 2:
            return 0
        return cog.graph.reinforce_chain(action_ids, weight_delta=0.6)
    except Exception as e:
        log.warning("autopilot reinforce_chain failed: %s", e)
        return 0
