"""
Leon cognition layer — Phase 1.

Sits ABOVE Claude (language cortex) and the SNN (state substrate). Owns:
  - episode log (every action, with prediction + outcome)
  - world model (calibrated p_success / latency / side-effects per action)
  - SNN gates (neuromodulators → real behavior knobs, not prompt adjectives)
  - drives (homeostatic urges that bias action selection)
  - rollout (1-step internal simulation before acting)
  - closed loop (Observe → Predict → Plan → Simulate → Act → Evaluate → Learn)

Designed to be additive: import + install via bootstrap.install(...) and the
rest of the stack keeps working unchanged. Shadow mode by default — predicts
and logs without gating behavior until explicitly enabled.

This package is intentionally self-contained. Stdlib + NumPy only.
"""

from brain.cognition.episodes import EpisodeStore, Episode, Context, Prediction
from brain.cognition.world_model import WorldModel
from brain.cognition.snn_gating import SNNGates, Gates
from brain.cognition.drives import DriveSystem, Drive
from brain.cognition.rollout import Rollout, Simulation
from brain.cognition.loop import CognitionLoop, ActionCandidate
# Phase 2 — persistent identity layer
from brain.cognition.graph import GraphMemory
from brain.cognition.self_model import SelfModel
from brain.cognition.consolidation import CognitionConsolidator, ConsolidationReport, CausalRule
# Phase 3 — hierarchical control + cognition-aware prompts
from brain.cognition.hierarchy import HierarchyRouter, Route
from brain.cognition.prompt_builder import CognitionPromptBuilder
# Phase 13 — persistent cognitive OS surface
from brain.cognition.failure_classifier import classify as classify_failure, Failure
from brain.cognition.tool_health import ToolHealth, ToolStats
from brain.cognition.awareness import AwarenessLoop, Snapshot
from brain.cognition.lessons import LessonStore, Lesson
from brain.cognition.skills import SkillMemory, Skill, SkillStep
from brain.cognition.reflex import ReflexLayer, ReflexAnswer
from brain.cognition.watchdog import Watchdog, WatchdogReport, Check
from brain.cognition.tool_probes import ProbeRunner, ProbeResult, safe_probe
# TWO different classes were both exported as `Proposal` — self_repair's and
# reflection's. Python keeps the last import, so `from brain.cognition import
# Proposal` silently handed out reflection's, and any caller expecting the
# self-repair one would have failed on an attribute that simply is not there,
# with nothing pointing at the name collision. Both are now reachable under
# unambiguous names; `Proposal` stays bound to reflection's so existing
# behaviour is unchanged.
from brain.cognition.self_repair import SelfRepair
from brain.cognition.self_repair import Proposal as RepairProposal
from brain.cognition.suggestions import Suggestions, Suggestion
from brain.cognition.executive import (
    ExecutiveController, ExecutivePlan, SimulationResult,
    STRATEGY_REFLEX_LOCAL, STRATEGY_REFLEX_TOOL, STRATEGY_CANNED,
    STRATEGY_CLAUDE_FAST, STRATEGY_CLAUDE_DEEP,
    STRATEGY_AUTOPILOT, STRATEGY_BACKGROUND,
)
# Phase 14 — experience-driven authority layer
from brain.cognition.tool_classifier import (
    ToolClassifier, ToolClass,
    CLASS_ACTIVE, CLASS_DORMANT, CLASS_REDUNDANT,
    CLASS_BROKEN, CLASS_LEGACY,
)
from brain.cognition.reflection import (
    Reflection, Insight, Proposal,   # also exported as ReflectionProposal below
    PROPOSAL_ADD_REFLEX, PROPOSAL_DEMOTE_TOOL,
    PROPOSAL_CRYSTALLIZE_SKILL, PROPOSAL_ROUTING_ADJUST,
    PROPOSAL_OPEN, PROPOSAL_APPROVED, PROPOSAL_REJECTED,
    PROPOSAL_APPLIED, PROPOSAL_FAILED,
)
# Phase 15 — provider abstraction
from brain.cognition.providers import (
    ProviderRegistry, ProviderState,
    STATUS_WARM, STATUS_COLD, STATUS_DEGRADED,
    STATUS_DEAD, STATUS_DISABLED,
)

__all__ = [
    "EpisodeStore", "Episode", "Context", "Prediction",
    "WorldModel",
    "SNNGates", "Gates",
    "DriveSystem", "Drive",
    "Rollout", "Simulation",
    "CognitionLoop", "ActionCandidate",
    # Phase 2
    "GraphMemory", "SelfModel",
    "CognitionConsolidator", "ConsolidationReport", "CausalRule",
    # Phase 3
    "HierarchyRouter", "Route",
    "CognitionPromptBuilder",
    # Phase 13
    "classify_failure", "Failure",
    "ToolHealth", "ToolStats",
    "AwarenessLoop", "Snapshot",
    "LessonStore", "Lesson",
    "SkillMemory", "Skill", "SkillStep",
    "ReflexLayer", "ReflexAnswer",
    "Watchdog", "WatchdogReport", "Check",
    "ProbeRunner", "ProbeResult", "safe_probe",
    "SelfRepair", "Proposal", "RepairProposal", "ReflectionProposal",
    "Suggestions", "Suggestion",
    "ExecutiveController", "ExecutivePlan",
    "STRATEGY_REFLEX_LOCAL", "STRATEGY_REFLEX_TOOL", "STRATEGY_CANNED",
    "STRATEGY_CLAUDE_FAST", "STRATEGY_CLAUDE_DEEP",
    "STRATEGY_AUTOPILOT", "STRATEGY_BACKGROUND",
]


# Explicit alias so callers can say which Proposal they mean.
ReflectionProposal = Proposal
