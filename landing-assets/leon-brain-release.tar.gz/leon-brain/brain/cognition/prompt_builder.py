"""
Cognition-aware system prompt builder.

Replaces "identity reconstructed each turn from boilerplate" with a
compact augmentation that injects what the cognition layer actually knows
about Leon and the current context. The augmentation is short by design
(≤300 tokens) — we are augmenting, not replacing, the existing persona
prompt.

Augmentation sections (each toggleable):

  IDENTITY     — self-model identity hash + archetype scores + top 3
                 preferred actions. Replaces the part of the existing
                 prompt that reconstructs "you are Leon" from boilerplate.

  DRIVES       — loudest homeostatic drive if above-baseline. Tells Claude
                 what's actually pushing for action right now ("anomaly
                 elevated — something on screen changed").

  ENTITIES     — top relevant graph entities (matched against user_text).
                 Gives Claude awareness of recurring URLs / files / projects.

  WORLD_MODEL  — concrete predictions for likely tool families given user
                 text. E.g. "browser.dom_click: 67% success rate, n=12.
                 Consider preceding with browser.dom_state to verify selector."

  EPISODES     — recent episodes summary (last 5). Off by default; only on
                 for strategic-layer requests where history matters.

The output is meant to be appended to the existing system prompt OR
used standalone if calling via the cognition path directly.
"""

from __future__ import annotations

import textwrap
import time
from typing import Any, Dict, List, Optional, Tuple


class CognitionPromptBuilder:
    """Produces a compact cognition-state addendum for the system prompt."""

    def __init__(self, *, self_model=None, drives=None, gates=None,
                 graph=None, world_model=None, episodes=None, verifier=None,
                 lessons=None, awareness=None, skills=None, tool_health=None):
        self.self_model = self_model
        self.drives = drives
        self.gates = gates
        self.graph = graph
        self.world_model = world_model
        self.episodes = episodes
        # Phase 12A — verifier exposes 'corroborated' hypotheses (verified
        # causal claims) that we can cite in the prompt.
        self.verifier = verifier
        # Phase 13 — dynamic prompt selection signals
        self.lessons = lessons
        self.awareness = awareness
        self.skills = skills
        self.tool_health = tool_health

    # -- main entry ----------------------------------------------------

    def build(
        self,
        base_prompt: str = "",
        user_text: str = "",
        *,
        include_identity: bool = True,
        include_drives: bool = True,
        include_relevant_entities: bool = True,
        include_world_model: bool = True,
        include_recent_episodes: bool = False,
        include_verified_causal: bool = True,
        include_lessons: bool = False,
        include_awareness: bool = False,
        include_skill_hint: bool = False,
        include_tool_warnings: bool = False,
        max_chars: int = 1500,
    ) -> str:
        """Returns base_prompt followed by cognition augmentation.

        Each section is appended only if its source is available AND has
        non-trivial content (no point printing baseline drives at 0.2 each).
        Total addendum is capped at max_chars.
        """
        sections: List[str] = []
        if base_prompt:
            sections.append(base_prompt)

        addendum_parts: List[str] = []
        if include_identity:
            blk = self._identity_block()
            if blk:
                addendum_parts.append(blk)
        if include_drives:
            blk = self._drives_block()
            if blk:
                addendum_parts.append(blk)
        if include_relevant_entities and user_text:
            blk = self._entities_block(user_text)
            if blk:
                addendum_parts.append(blk)
        if include_world_model and user_text:
            blk = self._world_model_block(user_text)
            if blk:
                addendum_parts.append(blk)
        if include_recent_episodes:
            blk = self._recent_episodes_block(limit=5)
            if blk:
                addendum_parts.append(blk)
        if include_verified_causal:
            blk = self._verified_causal_block(limit=4)
            if blk:
                addendum_parts.append(blk)
        # Phase 13 sections (default off; executive turns them on per-plan)
        if include_lessons:
            blk = self._lessons_block(user_text)
            if blk:
                addendum_parts.append(blk)
        if include_awareness:
            blk = self._awareness_block()
            if blk:
                addendum_parts.append(blk)
        if include_skill_hint and user_text:
            blk = self._skill_hint_block(user_text)
            if blk:
                addendum_parts.append(blk)
        if include_tool_warnings:
            blk = self._tool_warnings_block()
            if blk:
                addendum_parts.append(blk)

        if addendum_parts:
            addendum = "\n\n".join([
                "── COGNITION STATE (live, derived from your own episode history) ──",
                *addendum_parts,
            ])
            if len(addendum) > max_chars:
                addendum = addendum[:max_chars - 20] + "\n…(truncated)"
            sections.append(addendum)

        return "\n\n".join(sections)

    # -- section builders ----------------------------------------------

    def _identity_block(self) -> str:
        if self.self_model is None:
            return ""
        try:
            snap = self.self_model.snapshot()
        except Exception:
            return ""
        ident = snap.get("identity", {})
        arch = snap.get("archetypes", {})
        prefs = snap.get("preferred_actions", [])
        milestones = snap.get("milestones", {})

        # Archetype line — only show non-trivial scores
        arch_parts = []
        for k in ("observer", "doer", "patient", "exploratory", "cautious",
                  "focused", "consolidator"):
            v = arch.get(k)
            if v is None:
                continue
            if abs(v - 0.5) < 0.1 and k not in ("observer", "doer"):
                continue  # skip values close to neutral
            arch_parts.append(f"{k}={v:.2f}")
        arch_str = " ".join(arch_parts) if arch_parts else "balanced"

        prefs_str = ""
        if prefs:
            prefs_str = "; recent wins: " + ", ".join(
                f"{p['action']} ({int(p['success_rate']*100)}% over {p['count']})"
                for p in prefs[:3]
            )

        ep_count = milestones.get("episode_count", 0)
        lines = [
            f"IDENTITY (persistent, hash={ident.get('hash', '?')}, "
            f"episodes={ep_count}): {arch_str}{prefs_str}"
        ]
        return "\n".join(lines)

    def _drives_block(self) -> str:
        if self.drives is None:
            return ""
        try:
            snap = self.drives.snapshot()
        except Exception:
            return ""
        loudest = snap.get("loudest")
        drives = snap.get("drives", {})
        if not loudest:
            return ""  # nothing above baseline — say nothing
        payload = drives.get(loudest, {})
        above = payload.get("above_baseline", 0)
        explanations = {
            "uncertainty": "world model has low confidence on recent predictions; lean toward gathering info",
            "anomaly":     "recent prediction error spiked; something changed on the desktop or in app state",
            "friction":    "consecutive tool failures piling up; consider an alternative strategy or ask Dean",
            "continuity":  "no self-state save in a while; checkpoint when convenient",
            "curiosity":   "no meaningful activity in a while; small exploratory action is fine",
        }
        explain = explanations.get(loudest, "active homeostatic drive")
        return (f"DRIVE (live): {loudest} +{above:.2f} above baseline — {explain}.")

    def _entities_block(self, user_text: str) -> str:
        if self.graph is None:
            return ""
        text_lower = user_text.lower()
        hits: List[Tuple[str, str, int]] = []
        try:
            tops = self.graph.top_entities(limit=80)
            for ent in tops:
                name = (ent.get("name") or "").lower()
                if len(name) < 3:
                    continue
                if name in text_lower:
                    hits.append((ent["type"], ent["name"], ent.get("mention_count", 1)))
        except Exception:
            return ""
        if not hits:
            return ""
        # Top 5 by mention count
        hits.sort(key=lambda x: -x[2])
        hits = hits[:5]
        formatted = ", ".join(f"{n} ({t}, ×{c})" for (t, n, c) in hits)
        return f"GRAPH (related entities you've seen): {formatted}"

    def _world_model_block(self, user_text: str) -> str:
        """Pull action archetypes that the user_text suggests Leon might fire,
        and surface their measured success rate so Claude can plan."""
        if self.world_model is None or self.graph is None:
            return ""
        # Heuristic: from graph, pick the top action entities and report
        # their current world-model prediction in this context.
        try:
            top_actions = self.graph.top_entities("action", limit=5)
        except Exception:
            return ""
        if not top_actions:
            return ""
        ctx = self._build_minimal_context()
        lines = []
        for ent in top_actions:
            name = ent["name"]
            try:
                pred = self.world_model.predict("tool", name, {}, ctx)
            except Exception:
                continue
            if pred.method == "prior":
                continue  # don't surface uncalibrated predictions
            lines.append(
                f"  {name}: p_success={pred.p_success:.2f}, "
                f"latency~{int(pred.latency_ms)}ms, conf={pred.confidence:.2f}"
            )
        if not lines:
            return ""
        return "WORLD MODEL (measured from your history):\n" + "\n".join(lines)

    def _recent_episodes_block(self, limit: int = 5) -> str:
        if self.episodes is None:
            return ""
        try:
            rows = self.episodes.recent(limit=limit)
        except Exception:
            return ""
        if not rows:
            return ""
        lines = ["RECENT EPISODES:"]
        for r in rows:
            name = r.get("action_name", "?")
            ok = "✓" if r.get("success") else "✗"
            latency = r.get("latency_ms")
            lat_str = f"{int(latency)}ms" if latency else "?ms"
            lines.append(f"  {ok} {name} ({lat_str})")
        return "\n".join(lines)

    # Phase 12A — verified causal rules (corroborated hypotheses)
    def _verified_causal_block(self, limit: int = 4) -> str:
        """Cite hypotheses that have survived corroboration. These are
        Leon's verified causal knowledge."""
        if self.verifier is None:
            return ""
        try:
            corroborated = self.verifier.corroborated_hypotheses(limit=limit)
        except Exception:
            return ""
        if not corroborated:
            return ""
        lines = ["VERIFIED CAUSAL RULES (corroborated by your own action history):"]
        for h in corroborated:
            cause = h.get("cause", "?")
            effect = h.get("effect", "?")
            ratio = h.get("fresh_ratio") or 0
            n = h.get("occurrences") or 0
            txt = (h.get("hypothesis") or "").strip()
            if txt:
                lines.append(f"  {cause} → {effect}  ({int(ratio*100)}% / n={n}): {txt[:140]}")
            else:
                lines.append(f"  {cause} → {effect}  ({int(ratio*100)}% / n={n})")
        return "\n".join(lines)

    # -- helpers -------------------------------------------------------

    def _build_minimal_context(self):
        from brain.cognition.episodes import Context
        nm = {"dopamine": 0.5, "acetylcholine": 0.3,
              "norepinephrine": 0.1, "serotonin": 0.5}
        if self.gates is not None:
            try:
                # Pull live NM from the gates' brain reference
                br = getattr(self.gates, "brain", None)
                if br is not None:
                    nm.update(getattr(br, "neuromodulators", {}) or {})
            except Exception:
                pass
        ctx = Context(
            ts=time.time(), nm=nm, dev_stage="?", active_app=None,
            hour=time.localtime().tm_hour, dow=time.localtime().tm_wday,
            user_present=True,
        )
        ctx.compute_bucket()
        return ctx

    # -- introspection -------------------------------------------------

    def preview(self, user_text: str, **flags) -> Dict[str, Any]:
        """Return the augmented prompt + per-section breakdown."""
        result: Dict[str, Any] = {
            "input": user_text,
            "sections": {},
            "augmented_prompt": "",
            "addendum_only": "",
        }
        if flags.get("include_identity", True):
            result["sections"]["identity"] = self._identity_block()
        if flags.get("include_drives", True):
            result["sections"]["drives"] = self._drives_block()
        if flags.get("include_relevant_entities", True):
            result["sections"]["entities"] = self._entities_block(user_text)
        if flags.get("include_world_model", True):
            result["sections"]["world_model"] = self._world_model_block(user_text)
        if flags.get("include_recent_episodes", False):
            result["sections"]["recent_episodes"] = self._recent_episodes_block(limit=5)
        result["addendum_only"] = self.build("", user_text, **flags)
        result["augmented_prompt"] = self.build(
            "[base prompt elided]", user_text, **flags,
        )
        return result


    # ── Phase 13 section builders ────────────────────────────────────────

    def _lessons_block(self, user_text: str = "") -> str:
        """Top relevant lessons (Dean corrections) for this turn."""
        if self.lessons is None:
            return ""
        try:
            rel = self.lessons.relevant(text=user_text or "", limit=4)
        except Exception:
            return ""
        if not rel:
            return ""
        lines = ["LESSONS (rules Dean asked you to follow):"]
        for L in rel:
            tag = "DO" if L.polarity == "do" else "DON'T"
            lines.append(f"  • {tag}: {L.text[:140]}")
        return "\n".join(lines)

    def _awareness_block(self) -> str:
        """Active app / window / idle / tab count — environmental context."""
        if self.awareness is None:
            return ""
        try:
            snap = self.awareness.snapshot_dict()
        except Exception:
            snap = None
        if not snap:
            return ""
        bits = []
        if snap.get("active_app"):
            bits.append(f"app={snap['active_app']}")
        if snap.get("active_project"):
            bits.append(f"project={snap['active_project']}")
        if snap.get("brave_tabs") is not None:
            bits.append(f"tabs={snap['brave_tabs']}")
        if snap.get("is_idle"):
            bits.append(f"idle={int(snap.get('idle_secs', 0))}s")
        if snap.get("load_avg_1m") is not None:
            bits.append(f"load={snap['load_avg_1m']:.2f}")
        if not bits:
            return ""
        return "ENVIRONMENT (Dean's current state): " + ", ".join(bits)

    def _skill_hint_block(self, user_text: str = "") -> str:
        """If a learned skill matches this intent, surface it as a hint."""
        if self.skills is None:
            return ""
        try:
            hit = self.skills.match(intent_text=user_text or "")
        except Exception:
            hit = None
        if hit is None:
            return ""
        sr = hit.success_rate * 100.0
        return (f"LEARNED SKILL match: {hit.name!r} "
                f"(success={sr:.0f}%, runs={hit.runs}). "
                f"Consider invoking via skills.invoke(id={hit.id}).")

    def _tool_warnings_block(self) -> str:
        """Warn about currently-broken tools so Claude doesn't suggest them."""
        if self.tool_health is None:
            return ""
        try:
            broken = self.tool_health.broken(limit=8)
        except Exception:
            return ""
        if not broken:
            return ""
        names = [s.tool for s in broken[:8]]
        return ("TOOL WARNINGS (currently broken — avoid suggesting): "
                + ", ".join(names))

    # ── Phase 13 entry point used by Executive Controller ───────────────

    def build_for_plan(self, plan, base_prompt: str = "",
                        user_text: str = "") -> str:
        """Build a prompt addendum scoped to an ExecutivePlan.

        Honors plan.prompt_flags (the executive picks which sections matter
        for the chosen strategy) and budgets max_chars based on plan.budget_ms.
        """
        flags = dict(getattr(plan, "prompt_flags", None) or {})
        # Budget mapping: tight budget → smaller addendum
        budget_ms = int(getattr(plan, "budget_ms", 3000) or 3000)
        if budget_ms <= 500:
            max_chars = 200
        elif budget_ms <= 2500:
            max_chars = 700
        else:
            max_chars = 1500
        # Always enable lessons + tool_warnings when above reflex tier
        flags.setdefault("include_lessons", True)
        flags.setdefault("include_tool_warnings", True)
        flags.setdefault("include_awareness", True)
        return self.build(base_prompt, user_text,
                           max_chars=max_chars, **flags)
