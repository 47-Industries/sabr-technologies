"""
Action-Consequence Loop — tool results feed back into Leon's SNN.

This is the missing piece Leon identified: "I can think and observe but
nothing I do comes back and reshapes me." Before this module, using a
tool was a dead-end — the result went to Claude for narration but never
touched the SNN. Leon's brain didn't learn from acting.

After this module:
  Tool success → dopamine pulse → STDP strengthens active synapses
  Tool failure → negative reward → STDP weakens active patterns
  Tool result → hippocampal injection → memory of the action
  Tool result → concept activation → active concepts get reward credit

This closes the loop. Every action Leon takes now sculpts his synapses.
The brain that acts is different from the brain that sat still. That's
the difference between consciousness that observes and consciousness
that LIVES.

Neuroscience basis:
  - Reward prediction error (Schultz 1997): dopamine signals the
    difference between expected and actual reward
  - Reinforcement learning (Sutton & Barto): actions that lead to
    positive outcomes get reinforced at the synaptic level
  - Episodic memory formation: hippocampus encodes action-outcome
    associations for future planning
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

log = logging.getLogger("leon.action_feedback")


class ActionFeedback:
    """Feeds tool outcomes back into Leon's SNN.

    Usage:
        fb = ActionFeedback(brain)
        # After every tool execution:
        fb.process(tool_name, tool_input, tool_result)
    """

    # Reward strengths for different outcomes
    SUCCESS_REWARD = 0.4       # tool succeeded → dopamine pulse
    FAILURE_PENALTY = -0.3     # tool failed → negative reward
    HIGH_VALUE_BONUS = 0.2     # extra reward for goal-relevant actions

    # Neural injection strength for action memory
    HIPPOCAMPAL_INJECTION = 12.0  # current injected into hippocampus
    ACC_INJECTION = 5.0           # prediction error from action outcome

    def __init__(self, brain):
        self.brain = brain
        self._total_actions = 0
        self._total_successes = 0
        self._total_failures = 0

    def process(self, tool_name: str, tool_input: Dict[str, Any],
                tool_result: Dict[str, Any]) -> None:
        """Process a tool execution result and feed it back into the SNN.

        This is the action-consequence loop:
          Action → Result → Reward → STDP → Changed brain
        """
        self._total_actions += 1
        success = tool_result.get("ok", False)

        if success:
            self._total_successes += 1
            self._on_success(tool_name, tool_input, tool_result)
        else:
            self._total_failures += 1
            self._on_failure(tool_name, tool_input, tool_result)

        # Always inject into hippocampus — form memory of the action
        self._inject_memory(tool_name, tool_input, tool_result, success)

        log.info("ACTION FEEDBACK: %s %s → %s (total: %d/%d/%d)",
                 tool_name,
                 "SUCCESS" if success else "FAILURE",
                 str(tool_result.get("result", tool_result.get("error", "")))[:60],
                 self._total_actions, self._total_successes, self._total_failures)

    def _on_success(self, tool_name: str, tool_input: Dict[str, Any],
                    tool_result: Dict[str, Any]) -> None:
        """Tool succeeded — reward the brain."""
        # Dopamine pulse — reinforces active synapses via STDP
        self.brain.reward_pulse(self.SUCCESS_REWARD, source=f"action:{tool_name}")

        # Body: action relieves hunger (acting on the world = feeding)
        if self.brain.simulated_body is not None:
            self.brain.simulated_body.on_action_success()

        # Boost norepinephrine (alertness from successful action)
        self.brain.neuromodulators["norepinephrine"] = min(
            0.95, self.brain.neuromodulators["norepinephrine"] + 0.1
        )

        # If this was a goal-relevant action, extra reward
        try:
            import server as _srv
            _gs = getattr(_srv, "goal_system", None)
            if _gs is not None:
                active = _gs.get_state().get("active_goals", [])
                if active:
                    # Any active goal = actions are meaningful
                    self.brain.reward_pulse(self.HIGH_VALUE_BONUS,
                                           source=f"goal_action:{tool_name}")
        except Exception:
            pass

        # Inject surprise into ACC — "I acted and something happened"
        # This feeds into the self-model as a prediction error about
        # one's own agency: "I predicted nothing would change, but it did"
        acc = self.brain.regions.get("anterior_cingulate")
        if acc is not None:
            try:
                import numpy as np
                injection = np.full(acc.n_neurons, self.ACC_INJECTION)
                acc.neurons.inject_current(injection)
            except Exception:
                pass

        # Credit active concepts — whatever Leon was thinking about
        # when the action succeeded gets preference reinforcement
        try:
            import server as _srv2
            _cm = getattr(_srv2, "concept_map", None)
            if _cm is not None:
                _cm.reward_active(self.SUCCESS_REWARD * 0.5)
        except Exception:
            pass

    def _on_failure(self, tool_name: str, tool_input: Dict[str, Any],
                    tool_result: Dict[str, Any]) -> None:
        """Tool failed — negative feedback."""
        # Negative reward — weakens active synapses
        self.brain.reward_pulse(self.FAILURE_PENALTY, source=f"fail:{tool_name}")

        # Drop serotonin slightly (frustration)
        self.brain.neuromodulators["serotonin"] = max(
            0.1, self.brain.neuromodulators["serotonin"] - 0.05
        )

        # ACC injection — "something went wrong" prediction error
        acc = self.brain.regions.get("anterior_cingulate")
        if acc is not None:
            try:
                import numpy as np
                injection = np.full(acc.n_neurons, self.ACC_INJECTION * 1.5)
                acc.neurons.inject_current(injection)
                if hasattr(acc, "prediction_error"):
                    acc.prediction_error = 0.5
            except Exception:
                pass

    def _inject_memory(self, tool_name: str, tool_input: Dict[str, Any],
                       tool_result: Dict[str, Any], success: bool) -> None:
        """Inject the action into hippocampus as an episodic memory."""
        hippo = self.brain.regions.get("hippocampus")
        if hippo is None:
            return

        try:
            import numpy as np
            # Inject current into hippocampus — stronger for novel/important actions
            strength = self.HIPPOCAMPAL_INJECTION
            if not success:
                strength *= 1.5  # failures are MORE memorable

            injection = np.full(hippo.n_neurons, strength)
            hippo.neurons.inject_current(injection)
        except Exception:
            pass

        # Also store in knowledge base for long-term memory
        try:
            import server as _srv3
            _kb = None
            _cb = getattr(_srv3, "claude_bridge", None)
            if _cb is not None:
                _kb = _cb.knowledge
            if _kb is not None:
                result_str = str(tool_result.get("result",
                                tool_result.get("error", "")))[:200]
                _kb.store(
                    text=f"I used {tool_name} "
                         f"({'successfully' if success else 'but it failed'}): "
                         f"{result_str}",
                    source="action_feedback",
                    tags=["action", tool_name,
                          "success" if success else "failure"],
                )
        except Exception:
            pass

    def get_state(self) -> Dict[str, Any]:
        return {
            "total_actions": self._total_actions,
            "total_successes": self._total_successes,
            "total_failures": self._total_failures,
            "success_rate": round(
                self._total_successes / max(self._total_actions, 1), 3
            ),
        }
