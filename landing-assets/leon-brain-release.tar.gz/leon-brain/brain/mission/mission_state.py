"""
Mission State Engine — operational checklist tracking per project.

Each checklist item has: status, evidence, last_checked, blocker,
confidence, requires_approval, auto_check_capable.

Persists in the same projects.db alongside project records.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
import uuid
from typing import Any, Optional

log = logging.getLogger("leon.mission.mission_state")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS checklist_templates (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    items       TEXT NOT NULL DEFAULT '[]',   -- JSON array of {key, label, category}
    created_at  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS checklist_items (
    id              TEXT PRIMARY KEY,
    project_id      TEXT NOT NULL,
    template_id     TEXT,
    item_key        TEXT NOT NULL,
    label           TEXT NOT NULL,
    category        TEXT DEFAULT 'general',
    status          TEXT NOT NULL DEFAULT 'unknown',   -- unknown|pending|in_progress|done|blocked|skipped
    evidence        TEXT DEFAULT '',
    last_checked    REAL,
    blocker         TEXT DEFAULT '',
    confidence      REAL DEFAULT 0.0,     -- 0.0-1.0
    requires_approval INTEGER DEFAULT 0,
    auto_check_capable INTEGER DEFAULT 0,
    auto_check_connector TEXT DEFAULT '',  -- connector name that can verify this
    notes           TEXT DEFAULT '',
    created_at      REAL NOT NULL,
    updated_at      REAL NOT NULL,
    UNIQUE(project_id, item_key)
);
"""

# Default iOS app deployment checklist
IOS_DEPLOY_CHECKLIST = [
    {"key": "app_id_created", "label": "App ID created in Apple Developer Portal", "category": "apple"},
    {"key": "asc_app_record", "label": "App Store Connect app record exists", "category": "apple"},
    {"key": "iap_skus", "label": "IAP SKUs configured", "category": "apple"},
    {"key": "provisioning_profiles", "label": "Provisioning profiles exist", "category": "apple"},
    {"key": "revenuecat_configured", "label": "RevenueCat project configured", "category": "revenuecat"},
    {"key": "revenuecat_products", "label": "RevenueCat products/entitlements set up", "category": "revenuecat"},
    {"key": "codemagic_workflow", "label": "Codemagic workflow configured", "category": "ci"},
    {"key": "codemagic_build_green", "label": "Codemagic build passing", "category": "ci"},
    {"key": "repo_exists", "label": "Git repository exists", "category": "github"},
    {"key": "pr_merged", "label": "Latest PR merged to main", "category": "github"},
    {"key": "backend_healthy", "label": "Backend health check passing", "category": "backend"},
    {"key": "backend_version", "label": "Backend running expected version", "category": "backend"},
    {"key": "secrets_configured", "label": "All required secrets/env vars set", "category": "secrets"},
    {"key": "build_uploaded", "label": "Build uploaded to TestFlight/App Store", "category": "deploy"},
    {"key": "screenshots_ready", "label": "App Store screenshots prepared", "category": "deploy"},
    {"key": "privacy_policy", "label": "Privacy policy URL set", "category": "compliance"},
    {"key": "domain_configured", "label": "Domain DNS configured", "category": "infra"},
]


class MissionStateEngine:
    def __init__(self, db_path: str | None = None):
        self.db_path = os.path.abspath(db_path or DB_PATH)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._ensure_default_template()
        log.info("MissionStateEngine ready")

    def _ensure_default_template(self):
        row = self._conn.execute(
            "SELECT id FROM checklist_templates WHERE name = 'ios_deploy'"
        ).fetchone()
        if not row:
            self._conn.execute(
                "INSERT INTO checklist_templates (id, name, description, items, created_at) VALUES (?,?,?,?,?)",
                ("ios_deploy", "ios_deploy", "iOS App Deployment Checklist",
                 json.dumps(IOS_DEPLOY_CHECKLIST), time.time()),
            )
            self._conn.commit()

    # ── Templates ───────────────────────────────────────────────────────

    def list_templates(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM checklist_templates ORDER BY name").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["items"] = json.loads(d["items"]) if isinstance(d["items"], str) else d["items"]
            result.append(d)
        return result

    def create_template(self, name: str, items: list[dict], description: str = "") -> dict:
        tid = uuid.uuid4().hex[:12]
        self._conn.execute(
            "INSERT INTO checklist_templates (id, name, description, items, created_at) VALUES (?,?,?,?,?)",
            (tid, name, description, json.dumps(items), time.time()),
        )
        self._conn.commit()
        return {"id": tid, "name": name, "items": items}

    # ── Apply template to project ───────────────────────────────────────

    def apply_template(self, project_id: str, template_name: str = "ios_deploy") -> list[dict]:
        row = self._conn.execute(
            "SELECT * FROM checklist_templates WHERE name = ?", (template_name,)
        ).fetchone()
        if not row:
            return []
        items = json.loads(row["items"]) if isinstance(row["items"], str) else row["items"]
        now = time.time()
        created = []
        for item in items:
            iid = uuid.uuid4().hex[:12]
            try:
                self._conn.execute(
                    """INSERT OR IGNORE INTO checklist_items
                       (id, project_id, template_id, item_key, label, category,
                        status, confidence, auto_check_capable, created_at, updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (iid, project_id, row["id"], item["key"], item["label"],
                     item.get("category", "general"), "unknown", 0.0, 0, now, now),
                )
                created.append(item)
            except sqlite3.IntegrityError:
                pass
        self._conn.commit()
        return created

    # ── Item CRUD ───────────────────────────────────────────────────────

    def get_items(self, project_id: str, category: str | None = None) -> list[dict]:
        q = "SELECT * FROM checklist_items WHERE project_id = ?"
        params: list = [project_id]
        if category:
            q += " AND category = ?"
            params.append(category)
        q += " ORDER BY category, item_key"
        return [dict(r) for r in self._conn.execute(q, params).fetchall()]

    def update_item(self, project_id: str, item_key: str, **kwargs) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM checklist_items WHERE project_id = ? AND item_key = ?",
            (project_id, item_key),
        ).fetchone()
        if not row:
            return None
        sets = []
        vals = []
        for k in ("status", "evidence", "blocker", "confidence", "requires_approval",
                   "auto_check_capable", "auto_check_connector", "notes"):
            if k in kwargs:
                sets.append(f"{k} = ?")
                vals.append(kwargs[k])
        if "status" in kwargs or "evidence" in kwargs:
            sets.append("last_checked = ?")
            vals.append(time.time())
        sets.append("updated_at = ?")
        vals.append(time.time())
        vals.append(project_id)
        vals.append(item_key)
        self._conn.execute(
            f"UPDATE checklist_items SET {', '.join(sets)} WHERE project_id = ? AND item_key = ?",
            vals,
        )
        self._conn.commit()
        return dict(self._conn.execute(
            "SELECT * FROM checklist_items WHERE project_id = ? AND item_key = ?",
            (project_id, item_key),
        ).fetchone())

    def add_custom_item(self, project_id: str, item_key: str, label: str,
                        category: str = "custom", **kwargs) -> dict:
        iid = uuid.uuid4().hex[:12]
        now = time.time()
        self._conn.execute(
            """INSERT OR REPLACE INTO checklist_items
               (id, project_id, item_key, label, category, status, confidence,
                requires_approval, auto_check_capable, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (iid, project_id, item_key, label, category,
             kwargs.get("status", "unknown"), kwargs.get("confidence", 0.0),
             kwargs.get("requires_approval", 0), kwargs.get("auto_check_capable", 0),
             now, now),
        )
        self._conn.commit()
        return dict(self._conn.execute(
            "SELECT * FROM checklist_items WHERE project_id = ? AND item_key = ?",
            (project_id, item_key),
        ).fetchone())

    # ── Summary ─────────────────────────────────────────────────────────

    def project_readiness(self, project_id: str) -> dict:
        items = self.get_items(project_id)
        if not items:
            return {"project_id": project_id, "total": 0, "readiness_pct": 0, "by_status": {}, "blockers": []}
        by_status: dict[str, int] = {}
        blockers = []
        for item in items:
            s = item["status"]
            by_status[s] = by_status.get(s, 0) + 1
            if s == "blocked":
                blockers.append({"key": item["item_key"], "label": item["label"], "blocker": item.get("blocker", "")})
        done = by_status.get("done", 0)
        total = len(items)
        return {
            "project_id": project_id,
            "total": total,
            "done": done,
            "readiness_pct": round(100 * done / total, 1) if total else 0,
            "by_status": by_status,
            "blockers": blockers,
            "auto_checkable": sum(1 for i in items if i.get("auto_check_capable")),
        }

    def all_blockers(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM checklist_items WHERE status = 'blocked' ORDER BY updated_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
