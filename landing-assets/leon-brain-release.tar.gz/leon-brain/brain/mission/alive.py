"""
Phase 17+ — ALIVE: Everything that makes Leon a living operator.

Desktop notifications, terminal resurrection, CI auto-fix, morning briefing,
GitHub watcher, priority engine, daily report delivery, PR creation,
Codemagic triggers, self-health monitor.

This is the final layer. After this, Leon is awake.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sqlite3
import time
import threading
from datetime import datetime, timedelta
from typing import Any, Callable, Optional

log = logging.getLogger("leon.mission.alive")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")


def _run(cmd: list[str], cwd: str | None = None, timeout: int = 30, env: dict | None = None) -> dict:
    try:
        run_env = os.environ.copy()
        if env:
            run_env.update(env)
        if "DISPLAY" not in run_env:
            run_env["DISPLAY"] = ":0"
        # Ensure Flutter SDK is in PATH
        flutter_bin = os.path.expanduser("~/.flutter-sdk/bin")
        if os.path.isdir(flutter_bin) and flutter_bin not in run_env.get("PATH", ""):
            run_env["PATH"] = flutter_bin + ":" + run_env.get("PATH", "")
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           cwd=cwd, env=run_env)
        return {"ok": r.returncode == 0, "stdout": r.stdout.strip()[:4000],
                "stderr": r.stderr.strip()[:1000], "code": r.returncode}
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "code": -1}


# ═══════════════════════════════════════════════════════════════════════
#  1. DESKTOP NOTIFICATIONS — cut through anywhere
# ═══════════════════════════════════════════════════════════════════════

class DesktopNotifier:
    """Send notifications that Dean sees even when not on the dashboard."""

    @staticmethod
    def notify(title: str, body: str, urgency: str = "normal", icon: str = "dialog-information"):
        """Send a desktop notification via notify-send."""
        from brain.identity import si_name, brand
        _run(["notify-send", f"--urgency={urgency}", f"--icon={icon}",
              f"--app-name={si_name()}", brand(title), body], timeout=5)

    @staticmethod
    def urgent(title: str, body: str):
        DesktopNotifier.notify(title, body, urgency="critical", icon="dialog-warning")

    @staticmethod
    def sound(sound_file: str = "/usr/share/sounds/freedesktop/stereo/message-new-instant.oga"):
        """Play an alert sound."""
        if os.path.exists(sound_file):
            _run(["paplay", sound_file], timeout=5)


# ═══════════════════════════════════════════════════════════════════════
#  2. TERMINAL RESURRECTION — resume idle Claude Code sessions
# ═══════════════════════════════════════════════════════════════════════

class TerminalResurrector:
    """Detect stuck terminals and send safe continuation prompts."""

    # Only send safe, read-only continuation prompts
    SAFE_PROMPTS = {
        "idle_at_prompt": "echo 'Leon: terminal idle — ready for work'",
        "error_at_prompt": None,  # don't auto-continue on errors
        "unknown_state": None,
    }

    @staticmethod
    def capture_screen(terminal_name: str) -> str:
        r = _run(["tmux", "capture-pane", "-t", f"agents:{terminal_name}", "-p", "-S", "-30"])
        return r["stdout"] if r["ok"] else ""

    @staticmethod
    def send_keys(terminal_name: str, keys: str):
        """Send keystrokes to a tmux terminal."""
        # ROUTED THROUGH THE GATE 2026-08-03 — see terminal_loop.send().
        from brain.mission.terminal_loop import TerminalWatcher
        if not TerminalWatcher().send(terminal_name, keys):
            return False

    @staticmethod
    def classify_terminal(screen: str) -> dict:
        """Classify what state a terminal is in."""
        lower = screen.lower()
        lines = screen.strip().splitlines()
        last = lines[-1].strip() if lines else ""

        if "y/n" in lower or "[y/n]" in lower:
            return {"state": "waiting_confirmation", "safe_to_resume": False,
                    "detail": f"Waiting for yes/no: {last[:80]}"}
        if "error" in lower and ("$" in last or ">" in last):
            return {"state": "error_at_prompt", "safe_to_resume": False,
                    "detail": "Error occurred, at prompt"}
        if "permission denied" in lower:
            return {"state": "permission_error", "safe_to_resume": False,
                    "detail": "Permission denied"}
        if any(x in lower for x in ["compiling", "building", "downloading", "installing", "running"]):
            return {"state": "working", "safe_to_resume": False,
                    "detail": "Process still running"}
        if last.endswith("$") or last.endswith(">") or last.endswith("#"):
            return {"state": "idle_at_prompt", "safe_to_resume": True,
                    "detail": f"Idle at shell prompt"}
        if "bypass permissions" in lower or "⏵" in last:
            return {"state": "claude_code_prompt", "safe_to_resume": False,
                    "detail": "At Claude Code prompt — waiting for user input"}
        return {"state": "unknown", "safe_to_resume": False, "detail": f"Last: {last[:60]}"}

    def resurrect_all(self) -> list[dict]:
        """Check all agent terminals and report/act on stuck ones."""
        results = []
        r = _run(["tmux", "list-windows", "-t", "agents", "-F",
                   "#{window_name}:#{window_activity}"])
        if not r["ok"]:
            return results

        for line in r["stdout"].splitlines():
            parts = line.split(":", 1)
            if len(parts) < 2:
                continue
            name = parts[0]
            activity = int(parts[1]) if parts[1].isdigit() else 0
            idle_s = int(time.time() - activity) if activity else -1

            if idle_s < 600:  # not idle enough (< 10 min)
                continue

            screen = self.capture_screen(name)
            classification = self.classify_terminal(screen)
            classification["terminal"] = name
            classification["idle_min"] = round(idle_s / 60)
            results.append(classification)

        return results


# ═══════════════════════════════════════════════════════════════════════
#  3. CI AUTO-FIX — actually fix what we diagnosed
# ═══════════════════════════════════════════════════════════════════════

class CIFixer:
    """Actually fix CI failures, not just diagnose them."""

    def __init__(self, session_path: str = "~/.openclaw/forever-sessions.json"):
        self._paths: dict[str, str] = {}
        try:
            p = os.path.expanduser(session_path)
            if os.path.exists(p):
                with open(p) as f:
                    for s in json.load(f).get("forever", []):
                        self._paths[s.get("windowName", "")] = s.get("path", "")
        except Exception:
            pass

    def _find(self, name: str) -> str | None:
        slug = name.lower().replace(" ", "-")
        for wn, path in self._paths.items():
            if slug == wn or slug in wn or wn in slug:
                if os.path.isdir(path):
                    return path
        return None

    def fix_flutter_lint(self, project_name: str) -> dict:
        """Run dart fix + flutter analyze on a project."""
        path = self._find(project_name)
        if not path:
            return {"ok": False, "detail": f"No local path for {project_name}"}

        # Run dart fix
        r = _run(["dart", "fix", "--apply"], cwd=path, timeout=90)
        # Run flutter analyze
        r2 = _run(["flutter", "analyze", "--no-fatal-infos", "lib/"], cwd=path, timeout=90)

        if r2["ok"]:
            # Check if files changed
            diff = _run(["git", "diff", "--stat"], cwd=path)
            if diff["stdout"]:
                # Commit and push
                _run(["git", "add", "-A"], cwd=path)
                branch = _run(["git", "branch", "--show-current"], cwd=path).get("stdout", "main")
                _run(["git", "commit", "-m", "fix: resolve Flutter lint errors\n\nAutomated by Leon autopilot"], cwd=path)
                _run(["git", "pull", "--rebase", "origin", branch], cwd=path, timeout=60)
                push = _run(["git", "push", "origin", branch], cwd=path, timeout=60)
                return {"ok": True, "detail": f"Fixed lint errors, committed and pushed on {branch}",
                        "pushed": push["ok"]}
            return {"ok": True, "detail": "Analyze passing, no changes needed"}
        return {"ok": False, "detail": f"Lint errors remain after dart fix: {r2['stdout'][:200]}"}

    def check_local_env_for_secret(self, project_name: str, secret_name: str) -> dict:
        """Check if a secret value exists in local .env files. Searches recursively."""
        path = self._find(project_name)
        if not path:
            return {"found": False, "detail": "No local path"}

        env_files = []
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d not in ("node_modules", ".git", ".next", "build", ".dart_tool")]
            for f in files:
                if f.startswith(".env"):
                    env_files.append(os.path.join(root, f))

        for ef_path in env_files:
            try:
                with open(ef_path) as f:
                    for line in f:
                        if line.strip().startswith(secret_name + "="):
                            val = line.strip().split("=", 1)[1].strip('"').strip("'")
                            if not val or val == "":
                                continue
                            masked = val[:4] + "..." + val[-4:] if len(val) > 10 else "***"
                            rel = os.path.relpath(ef_path, path)
                            return {"found": True, "file": rel, "masked_value": masked,
                                    "detail": f"Found {secret_name} in {rel} ({masked})"}
            except Exception:
                pass
        return {"found": False, "detail": f"{secret_name} not found in any .env file"}

    def diagnose_ci_deep(self, project_name: str) -> dict:
        """Deep diagnosis: pull CI logs, check schema, check local vs CI env mismatches."""
        path = self._find(project_name)
        result = {"project": project_name, "issues": [], "fixable": [], "needs_dean": []}

        # Get repo info
        repo_info = None
        if path:
            r = _run(["git", "remote", "get-url", "origin"], cwd=path)
            if r["ok"]:
                parts = r["stdout"].rstrip("/").split("/")
                if len(parts) >= 2:
                    repo_info = (parts[-2], parts[-1].replace(".git", ""))

        if not repo_info:
            result["issues"].append("Cannot find repo")
            return result

        owner, repo = repo_info

        # Get latest failed run details
        r = _run(["gh", "run", "view", "--repo", f"{owner}/{repo}",
                   "--json", "jobs,conclusion,headBranch",
                   "--jq", '.jobs[] | select(.conclusion == "failure") | .steps[] | select(.conclusion == "failure") | .name'],
                  timeout=15)
        if r["ok"] and r["stdout"]:
            for step in r["stdout"].splitlines():
                result["issues"].append(f"Failed step: {step}")

        # Check if CI workflow references secrets not in GitHub
        if path:
            import glob
            for wf in glob.glob(os.path.join(path, ".github/workflows/*.yml")):
                try:
                    with open(wf) as f:
                        content = f.read()
                    # Find ${{ secrets.XXX }} references
                    import re
                    secrets_used = set(re.findall(r'\$\{\{\s*secrets\.(\w+)\s*\}\}', content))
                    for secret in secrets_used:
                        result["issues"].append(f"CI uses secret: {secret}")
                except Exception:
                    pass

        return result


# ═══════════════════════════════════════════════════════════════════════
#  4. GITHUB WATCHER — incoming issues, PRs, comments
# ═══════════════════════════════════════════════════════════════════════

class GitHubWatcher:
    """Watch for new GitHub activity across all repos."""

    def check_notifications(self) -> list[dict]:
        r = _run(["gh", "api", "notifications", "--method", "GET",
                   "-f", "all=false", "--jq",
                   '.[] | {id: .id, repo: .repository.full_name, type: .subject.type, title: .subject.title, reason: .reason, updated: .updated_at}'],
                  timeout=15)
        if not r["ok"]:
            return []
        results = []
        for line in r["stdout"].splitlines():
            try:
                results.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        return results

    def check_repo_activity(self, owner: str, repo: str) -> dict:
        """Check for recent issues + PRs in a repo."""
        activity = {"repo": f"{owner}/{repo}", "new_issues": [], "new_prs": [], "new_comments": []}

        # Issues opened in last 24h
        since = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        r = _run(["gh", "issue", "list", "--repo", f"{owner}/{repo}", "--state", "open",
                   "--json", "number,title,createdAt,author", "--limit", "5"], timeout=15)
        if r["ok"]:
            try:
                issues = json.loads(r["stdout"])
                for issue in issues:
                    if issue.get("createdAt", "") > since:
                        activity["new_issues"].append(issue)
            except json.JSONDecodeError:
                pass

        # PRs opened in last 24h
        r = _run(["gh", "pr", "list", "--repo", f"{owner}/{repo}", "--state", "open",
                   "--json", "number,title,createdAt,author,headRefName", "--limit", "5"], timeout=15)
        if r["ok"]:
            try:
                prs = json.loads(r["stdout"])
                for pr in prs:
                    if pr.get("createdAt", "") > since:
                        activity["new_prs"].append(pr)
            except json.JSONDecodeError:
                pass

        return activity

    def scan_all_repos(self, registry) -> dict:
        """Scan all registered repos for new activity."""
        all_activity = {"notifications": [], "repos": []}
        all_activity["notifications"] = self.check_notifications()

        if registry:
            for proj in registry.list_all(active_only=True):
                for url in proj.get("repo_urls", []):
                    parts = url.rstrip("/").split("/")
                    if len(parts) >= 2:
                        owner, repo = parts[-2], parts[-1].replace(".git", "")
                        activity = self.check_repo_activity(owner, repo)
                        if activity["new_issues"] or activity["new_prs"]:
                            all_activity["repos"].append(activity)

        return all_activity


# ═══════════════════════════════════════════════════════════════════════
#  5. PRIORITY ENGINE — "what should I work on next?"
# ═══════════════════════════════════════════════════════════════════════

class PriorityEngine:
    """Score projects by launch readiness, blockers, momentum, staleness."""

    def __init__(self, registry=None, state_engine=None, decisions=None):
        self.registry = registry
        self.state_engine = state_engine
        self.decisions = decisions

    def rank_projects(self) -> list[dict]:
        """Return projects ranked by what needs attention most."""
        if not self.registry:
            return []

        scored = []
        for proj in self.registry.list_all(active_only=True):
            score = self._score_project(proj)
            scored.append(score)

        scored.sort(key=lambda x: -x["urgency_score"])
        return scored

    def _score_project(self, proj: dict) -> dict:
        pid = proj["id"]
        name = proj["name"]
        score = 0
        reasons = []

        # Unresolved blockers = high urgency
        blockers = [b for b in proj.get("known_blockers", []) if not b.get("resolved")]
        if blockers:
            score += len(blockers) * 15
            reasons.append(f"{len(blockers)} blocker(s)")

        # Missing credentials
        missing_creds = proj.get("required_creds", [])
        if missing_creds:
            score += len(missing_creds) * 5
            reasons.append(f"{len(missing_creds)} creds needed")

        # Checklist readiness
        if self.state_engine:
            readiness = self.state_engine.project_readiness(pid)
            pct = readiness.get("readiness_pct", 0)
            if 50 <= pct < 80:
                score += 20  # close to done — push it over the line
                reasons.append(f"{pct}% ready — almost there")
            elif pct < 50:
                score += 5

        # Open decisions blocking this project
        if self.decisions:
            open_d = self.decisions.list_all(project_id=pid, status="open")
            if open_d:
                score += len(open_d) * 10
                reasons.append(f"{len(open_d)} unresolved decision(s)")

        # State-based scoring
        state = proj.get("operational_state", "unknown")
        if state == "setup":
            score += 10
            reasons.append("still in setup")
        elif state == "active":
            score += 5

        # Repos with recent activity get lower urgency (they're moving)
        if proj.get("repo_urls"):
            score += 3

        return {
            "project": name,
            "project_id": pid,
            "urgency_score": score,
            "reasons": reasons,
            "state": state,
            "recommendation": self._recommend(name, reasons, score),
        }

    def _recommend(self, name: str, reasons: list[str], score: int) -> str:
        if not reasons:
            return f"{name} is in good shape"
        top = reasons[0]
        if "blocker" in top:
            return f"Clear blockers on {name}"
        if "creds" in top:
            return f"Set up credentials for {name}"
        if "almost there" in top:
            return f"{name} is close to launch — push it over the line"
        if "decision" in top:
            return f"Resolve open decisions for {name}"
        if "setup" in top:
            return f"Complete setup for {name}"
        return f"Review {name}"

    def top_recommendation(self) -> str:
        """Single sentence: what Dean should work on next."""
        ranked = self.rank_projects()
        if not ranked:
            return "All projects are in good shape."
        top = ranked[0]
        return f"Focus on {top['project']}: {top['recommendation']}. " + \
               (f"({', '.join(top['reasons'][:2])})" if top["reasons"] else "")


# ═══════════════════════════════════════════════════════════════════════
#  6. DAILY REPORT DELIVERY
# ═══════════════════════════════════════════════════════════════════════

class DailyReporter:
    """Generate and deliver the daily operator report."""

    def __init__(self, executor=None, registry=None, priority=None,
                 broadcast=None, tts_say=None, notifier=None):
        self.executor = executor
        self.registry = registry
        self.priority = priority
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._notifier = notifier or DesktopNotifier()

    def generate_and_deliver(self) -> dict:
        """Generate full daily report and push it everywhere."""
        report = {}

        # Executor stats
        if self.executor:
            report = self.executor.generate_daily_report()

        # Priority ranking
        if self.priority:
            report["priority_ranking"] = self.priority.rank_projects()[:5]
            report["top_recommendation"] = self.priority.top_recommendation()

        # Project summary
        if self.registry:
            report["project_summary"] = self.registry.summary()

        # Build text
        text = self._format_report(report)
        voice = self._format_voice(report)

        # Daily report delivery DISABLED (2026-06-23): the report was
        # broadcasting empty "DAILY OPERATOR REPORT / Actions: 0" messages
        # to the dashboard with blank lines, making Leon look broken.
        # The report data is still generated and returned — just not
        # pushed to the dashboard/voice/notification. Re-enable when
        # there's actually meaningful data to report.
        # if text:
        #     try:
        #         from server.helpers import broadcast_response
        #         broadcast_response(text, source="daily_report",
        #                            user_label="[Daily Report]", audio=False)
        #     except Exception:
        #         pass

        return report

    def _format_report(self, r: dict) -> str:
        lines = ["DAILY OPERATOR REPORT"]
        lines.append(f"Actions: {r.get('total_actions',0)} total, {r.get('succeeded',0)} succeeded, {r.get('failed',0)} failed")
        lines.append(f"Projects touched: {len(r.get('projects_touched',[]))}")
        if r.get("top_recommendation"):
            lines.append(f"Priority: {r['top_recommendation']}")
        if r.get("failures"):
            lines.append("Failures:")
            for f in r["failures"][:3]:
                lines.append(f"  {f['action']}: {f['error'][:80]}")
        if r.get("awaiting_approval"):
            lines.append(f"Awaiting approval: {len(r['awaiting_approval'])}")
        return "\n".join(lines)

    def _format_voice(self, r: dict) -> str:
        parts = []
        total = r.get("total_actions", 0)
        if total:
            parts.append(f"I ran {total} actions today across {len(r.get('projects_touched',[]))} projects")
        failed = r.get("failed", 0)
        if failed:
            parts.append(f"{failed} failed")
        if r.get("top_recommendation"):
            parts.append(r["top_recommendation"])
        if not parts:
            return ""
        return "Sir. End of day report. " + ". ".join(parts) + "."


# ═══════════════════════════════════════════════════════════════════════
#  7. PR CREATION — after fixes
# ═══════════════════════════════════════════════════════════════════════

class PRCreator:
    """Create GitHub PRs for Leon's fixes."""

    @staticmethod
    def create_pr(owner: str, repo: str, branch: str, title: str, body: str,
                  base: str = "main") -> dict:
        r = _run(["gh", "pr", "create", "--repo", f"{owner}/{repo}",
                   "--head", branch, "--base", base,
                   "--title", title, "--body", body], timeout=30)
        if r["ok"]:
            return {"ok": True, "url": r["stdout"].strip(), "detail": "PR created"}
        return {"ok": False, "detail": r["stderr"][:200]}


# ═══════════════════════════════════════════════════════════════════════
#  8. CODEMAGIC TRIGGERS
# ═══════════════════════════════════════════════════════════════════════

class CodemagicTrigger:
    """Trigger Codemagic builds."""

    @staticmethod
    def trigger_build(app_id: str, workflow_id: str, branch: str = "main") -> dict:
        token = os.environ.get("CODEMAGIC_API_TOKEN", "")
        if not token:
            return {"ok": False, "detail": "CODEMAGIC_API_TOKEN not set"}
        import urllib.request
        data = json.dumps({"appId": app_id, "workflowId": workflow_id, "branch": branch}).encode()
        req = urllib.request.Request(
            "https://api.codemagic.io/builds",
            data=data,
            headers={"x-auth-token": token, "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return {"ok": True, "data": json.loads(resp.read().decode())}
        except Exception as e:
            return {"ok": False, "detail": str(e)[:200]}


# ═══════════════════════════════════════════════════════════════════════
#  9. SELF-HEALTH MONITOR
# ═══════════════════════════════════════════════════════════════════════

class SelfHealthMonitor:
    """Monitor Leon's own health — autopilot running, brain alive, memory growing."""

    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or DB_PATH
        self._last_check: float = 0
        self._consecutive_failures: int = 0

    def check(self) -> dict:
        report = {"healthy": True, "issues": [], "timestamp": time.time()}

        # Check brain process
        r = _run(["pgrep", "-f", "python3 run.py"])
        if not r["ok"]:
            report["healthy"] = False
            report["issues"].append("Leon brain process not running")

        # Skip self-HTTP-check — causes deadlock. Process check above is sufficient.

        # Check knowledge.db exists and isn't ancient
        kb_path = os.path.join(os.path.dirname(self.db_path), "knowledge.db")
        if os.path.exists(kb_path):
            age = time.time() - os.path.getmtime(kb_path)
            if age > 7200:  # 2 hours
                report["issues"].append(f"knowledge.db not modified in {int(age/60)}min")

        # Check autopilot DB
        if os.path.exists(self.db_path):
            try:
                conn = sqlite3.connect(self.db_path, timeout=3)
                row = conn.execute("SELECT MAX(created_at) FROM autopilot_actions").fetchone()
                if row and row[0]:
                    age = time.time() - row[0]
                    if age > 900:  # 15 min
                        report["issues"].append(f"No autopilot action in {int(age/60)}min")
                conn.close()
            except Exception:
                pass

        # Check disk space
        r = _run(["df", "-h", "--output=avail", "/"])
        if r["ok"]:
            avail = r["stdout"].splitlines()[-1].strip()
            if avail.endswith("G"):
                gb = float(avail.replace("G", ""))
                if gb < 5:
                    report["issues"].append(f"Low disk space: {avail} free")

        if report["issues"]:
            report["healthy"] = False

        return report


# ═══════════════════════════════════════════════════════════════════════
#  10. MORNING BRIEFING
# ═══════════════════════════════════════════════════════════════════════

class MorningBriefing:
    """7am scan + spoken summary + desktop notification."""

    def __init__(self, registry=None, state_engine=None, connectors=None,
                 decisions=None, priority=None, github_watcher=None,
                 broadcast=None, tts_say=None, notifier=None):
        self.registry = registry
        self.state = state_engine
        self.connectors = connectors
        self.decisions = decisions
        self.priority = priority
        self.github = github_watcher
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._notifier = notifier or DesktopNotifier()

    def deliver(self) -> dict:
        """Run the full morning briefing."""
        briefing = {"sections": [], "voice": "", "text": ""}

        # 1. Project overview
        if self.registry:
            summary = self.registry.summary()
            briefing["sections"].append({
                "title": "Projects",
                "detail": f"{summary['active_projects']} active, {summary['total_open_blockers']} blockers",
            })

        # 2. Priority recommendation
        if self.priority:
            rec = self.priority.top_recommendation()
            briefing["sections"].append({"title": "Focus", "detail": rec})

        # 3. Open decisions
        if self.decisions:
            ds = self.decisions.summary()
            if ds.get("open_count", 0) > 0:
                briefing["sections"].append({
                    "title": "Decisions",
                    "detail": f"{ds['open_count']} unresolved decisions",
                })

        # 4. GitHub activity overnight
        if self.github and self.registry:
            activity = self.github.scan_all_repos(self.registry)
            notifs = activity.get("notifications", [])
            if notifs:
                briefing["sections"].append({
                    "title": "GitHub",
                    "detail": f"{len(notifs)} notification(s)",
                })

        # Build text
        lines = ["GOOD MORNING — Leon Operator Briefing"]
        for s in briefing["sections"]:
            lines.append(f"{s['title']}: {s['detail']}")
        briefing["text"] = "\n".join(lines)

        # Build voice
        parts = []
        for s in briefing["sections"]:
            parts.append(f"{s['title']}: {s['detail']}")
        briefing["voice"] = "Good morning Sir. " + ". ".join(parts) + "." if parts else ""

        # Deliver
        if briefing["text"]:
            # Desktop notification
            self._notifier.notify("Good Morning", briefing["text"][:300])
            self._notifier.sound()

            # Dashboard (via unified broadcast gate)
            try:
                from server.helpers import broadcast_response
                broadcast_response(briefing["text"], source="morning_briefing",
                                   user_label="[Morning Briefing]", audio=False)
            except Exception:
                pass

            # Voice
            if briefing["voice"] and self._tts_say:
                try:
                    tts_result = self._tts_say(briefing["voice"])
                    if tts_result and self._broadcast:
                        self._broadcast({"type": "brain_audio",
                                          "response_id": f"morning_{int(time.time()*1000)}",
                                          "sentence_index": 0, "is_filler": False, **tts_result})
                except Exception:
                    pass

        return briefing
