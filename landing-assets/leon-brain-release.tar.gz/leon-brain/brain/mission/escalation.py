"""Escalation for refused payloads — because silence is the failure mode.

Every gate in this system refuses things: origin mismatch, allowlist
miss, banner hold, bypass unknown, stale orphan. A refusal that produces
no row is indistinguishable from a loop that never ran, and "the agent
sat there doing nothing" is the exact complaint this whole subsystem
exists to answer.

So: an allowlist miss — or any refusal — writes an escalation row. The
pane stays adopt-only throughout. Nothing here submits anything; this
module has no path to Enter by construction.

Two properties worth keeping:

  * EDGE-TRIGGERED, like the banner recorder. The same refusal repeating
    every tick would drown the file and get the alerts muted, which is
    how a monitoring system becomes decorative. First occurrence emits;
    repeats increment a counter and emit again only on a new reason.

  * The row says what DEAN would do about it. An escalation that reports
    a state without naming an action is a log line wearing a hat.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Optional

STATE_DIR = os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
ESCALATIONS_PATH = os.path.join(STATE_DIR, "autoloop_escalations.jsonl")
PREVIEW_MAX = 80

#: reason -> what a human is being asked to do. A reason without an
#: action is not an escalation, it is a status line.
ACTIONS = {
    "allowlist_miss": "Review the payload. If it is a shape the loop should be "
                      "able to send, add it to ALLOWED_SHAPES deliberately; "
                      "otherwise send it by hand.",
    "deny_shape": "The allowlist matched something destructive — treat as a BUG "
                  "in ALLOWED_SHAPES, not as a routine refusal.",
    "origin_unverified": "Text in the box was not authored by the loop. Only the "
                         "author can decide to send it; nobody else can supply "
                         "that intent.",
    "already_delivered": "The original send landed. Adopting would deliver it "
                         "twice — confirm before resending by hand.",
    "banner_hold": "Pane is near a context wipe. It needs a restart before it "
                   "can take work; a payload adopted now may land after the "
                   "wipe and be misapplied.",
    "bypass_unknown": "Could not read the bypass indicator. Pane stays "
                      "adopt-only; capture an OFF specimen if auto-submit is "
                      "ever to be enabled.",
    "stale_orphan": "Orphan older than the freshness window — it may have been "
                    "superseded. Resend by hand if still wanted.",
    "pane_wedged": "Pane has produced no new content for longer than its own "
                   "p99 gap and is not burning CPU. It is not thinking — "
                   "check it, and restart it if the turn is lost.",
    "debt_orphaned_by_restart": "A message was sent to this pane before its current process started, so it was never received — the agent that owed the reply is gone. Resend it by hand if it still matters; nothing is stuck.",
    "reader_geometry_lost": "Most panes stopped reporting cursor geometry at once. That is the reader breaking, not many stranded drafts — check tmux is answering display-message before trusting any box read.",
    "pane_undecidable": "Pane has been silent past its own threshold with a turn owed, but its spinner is still animating and CPU is low — which is what waiting on a long call looks like. LOOK at it; do not restart on this alone.",
    "pane_dead": "The terminal process is gone (pane_dead=1). Nothing is "
                 "running there; respawn the pane if that agent is still "
                 "expected to be working.",
    "pane_never_started": "Pane exists but has never rendered any content — no "
                          "agent was ever launched in it. Start one or ignore "
                          "the pane; it will self-heal on first output.",
    "channel_quarantined": "The reader that produced this claim fabricates "
                           "provenance. The instruction may still be correct — "
                           "act on it if you agree, but it was not verified "
                           "present in the pane.",
}

_seen: dict = {}          # (window, reason, payload_sha) -> {"n": int, "first": ts}


def _sha(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", "replace")).hexdigest()


def preview(text: str) -> str:
    p = " ".join((text or "").split())
    return p[:PREVIEW_MAX] + ("…" if len(p) > PREVIEW_MAX else "")


def _write(row: dict) -> None:
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(ESCALATIONS_PATH, "a") as fh:
            fh.write(json.dumps(row) + "\n")
    except Exception:
        pass          # instrumentation must never break the loop it observes


def escalate(window: str, reason: str, payload: str = "",
             channel_quarantined: bool = True,
             pane_state: Optional[dict] = None,
             detail: str = "") -> Optional[dict]:
    """Record a refusal. Returns the row, or None if suppressed as a repeat.

    NEVER submits. The pane remains adopt-only regardless of reason —
    this function's only effect is a line in a file and, downstream, a
    notification to Dean.
    """
    key = (window, reason, _sha(payload)[:16])
    prior = _seen.get(key)
    if prior is not None:
        prior["n"] += 1
        return None                    # edge-triggered: suppress the repeat
    _seen[key] = {"n": 1, "first": time.time()}
    row = {
        "ts": time.time(),
        "event": "escalation",
        "window": window,
        "reason": reason,
        "action_for_dean": ACTIONS.get(reason, "Unclassified refusal — inspect."),
        "payload_sha256": _sha(payload),
        "payload_preview": preview(payload),
        "payload_len": len(payload or ""),
        "channel_quarantined": bool(channel_quarantined),
        "submitted": False,            # invariant, asserted in tests
        "pane_state": pane_state or {},
        "detail": detail,
    }
    _write(row)
    return row


def resolve(window: str, reason: str, payload: str = "") -> int:
    """Clear the latch for a refusal that has stopped happening.

    Edge-triggered means BOTH edges. Without this, a condition that fires,
    clears, and returns is suppressed forever as a "repeat" — the second
    wedge of the night would be silent, which is the same silence the
    escalation path exists to remove. Returns how many times it repeated
    while latched, so a recovery can still report how long it went on.
    """
    key = (window, reason, _sha(payload)[:16])
    prior = _seen.pop(key, None)
    return prior["n"] if prior else 0


def repeat_counts() -> dict:
    """How many times each suppressed refusal recurred. A refusal that
    repeats hundreds of times is a stuck condition, not noise, and the
    counter is what makes that visible without emitting the rows."""
    return {f"{w}|{r}|{p}": v["n"] for (w, r, p), v in _seen.items()}
