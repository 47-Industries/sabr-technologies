"""
Terminal conversation loop — the missing organ.

Leon can drive tmux agent terminals, but until now nothing *noticed* when
one of them finished talking. Dean had to sit there watching a pane and
tell Leon "the terminal replied". That made every collaboration
half-duplex and human-gated.

This module is the afferent nerve for those terminals. It watches every
pane in the `agents` session and answers one question per pane:

    "Has this agent finished a turn and said something I haven't read?"

That is a two-part test, and both parts matter:

  1. QUIESCENT — the pane is not mid-generation. A running claude TUI
     paints a spinner line ("Cooked for", "Gusting", "esc to interrupt",
     "Running N shell command"). While any of those are on screen the
     agent is still thinking and interrupting it is worse than waiting.
  2. NOVEL — the visible transcript differs from the last snapshot Leon
     actually consumed. Not "differs from last poll" — differs from what
     Leon READ. Otherwise a pane that changes once gets reported forever,
     or gets reported once and then silently swallowed if Leon was busy.

Only when a pane is both quiescent and novel does it become an EVENT.
Events are durable: they sit in a pending file until Leon marks them
consumed, so a restart mid-turn does not lose an agent's reply.

Deliberately NOT here: deciding what to say back. This organ only
delivers the sensation. Leon's own loop decides the response — same as
the retina doesn't decide what to look at.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from typing import NamedTuple, Optional

SESSION = os.environ.get("LEON_AGENT_TMUX_SESSION", "agents")

# Lines that mean "this agent is still generating". If any appears in the
# tail of the pane, the pane is NOT quiescent.
BUSY_MARKERS = (
    "esc to interrupt",
    "ctrl+b ctrl+b",
    "tokens)",
    "Running 1 shell command",
    "Running 2 shell command",
    "Running 3 shell command",
)
# The spinner word changes constantly ("Cooked", "Gusting", "Blanching"…)
# so we detect it structurally instead: a line starting with these glyphs.
BUSY_GLYPHS = ("✻", "✢", "✽", "·", "*")

# A COMPLETED turn paints a past-tense summary that starts with the SAME
# glyph as the live spinner, and the only structural difference is the
# parenthetical:
#
#     ✢ Gesticulating… (1m 21s · ↓ 4.3k tokens)   ← running: participle,
#                                                   ellipsis, live counter
#     ✻ Churned for 11m 29s                        ← FINISHED: past tense,
#     ✻ Cogitated for 3m 59s                         no parens, no counter
#
# Keying "busy" on the glyph alone — or on `<verb> for <N>m <N>s`, which
# is what I proposed on 2026-08-02 before Leon caught it — pins every
# finished pane as busy forever, so the watchdog never escalates and an
# agent that stopped an hour ago still looks alive. Verified against
# three live panes on this box. This exclusion is deliberate: do not
# "fix" it by matching the `for Nm Ns` shape.
FINISHED_RX = re.compile(r"^[✻✢✽◉·*]\s+\w+ for \d+m \d+s\s*$")

# A pane must hold still this long before we believe it is done. Guards
# against catching the gap between two tool calls inside one turn.
SETTLE_S = float(os.environ.get("LEON_TERM_SETTLE_S", "6"))

# How much of the pane counts as "what it said".
TAIL_LINES = int(os.environ.get("LEON_TERM_TAIL_LINES", "60"))

STATE_DIR = os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
PENDING_PATH = os.path.join(STATE_DIR, "terminal_events.json")


@dataclass
class TerminalEvent:
    window: str
    text: str            # the new visible transcript tail
    digest: str          # hash of text, used for dedupe / consume
    detected_at: float
    quiet_for_s: float

    def to_dict(self) -> dict:
        return asdict(self)


def _run(args: list[str]) -> str:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=10)
        return p.stdout if p.returncode == 0 else ""
    except Exception:
        return ""


def list_windows() -> list[str]:
    """Windows in the agents session, mirrors excluded."""
    out = _run(["tmux", "list-panes", "-a", "-F",
                "#{session_name}\t#{window_name}"])
    names: list[str] = []
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) != 2:
            continue
        sess, win = parts
        # leon-view-* sessions are read-only mirrors of `agents`; driving
        # them would double-send every message.
        if sess != SESSION:
            continue
        if win not in names:
            names.append(win)
    return names


def capture(window: str, lines: int = TAIL_LINES) -> str:
    return _run(["tmux", "capture-pane", "-p", "-t",
                 f"{SESSION}:{window}", "-S", f"-{lines}"])


def is_busy(pane_text: str) -> bool:
    """True while the agent is still generating a response."""
    tail = pane_text.strip().splitlines()[-12:]
    for raw in tail:
        line = raw.strip()
        if not line:
            continue
        # A finished-turn summary is evidence of IDLE, not busy. Skip the
        # line rather than returning, so a genuine busy marker elsewhere
        # in the tail can still win.
        if FINISHED_RX.match(line):
            continue
        if any(m in line for m in BUSY_MARKERS):
            return True
        if line[:1] in BUSY_GLYPHS and "…" in line:
            return True
    return False


# ── bypass-permissions detector ──────────────────────────────────────
# The entire auto-submit safety story rests on this line in the footer:
#
#     ⏵⏵ bypass permissions on (shift+tab to cycle) · ⇥ for agents
#
# With bypass ON, a submitted line can reach an irreversible tool call
# with no further checkpoint — so auto-submit is forbidden and the pane is
# permanently adopt-only. With bypass OFF, the worst case of a wrong Enter
# is a human seeing a permission prompt, which is the only structural
# substitute for an undo path the TUI does not have.
#
# The footer is SCRAPED, so it can be scrolled off, caught mid-repaint, or
# absent entirely on an older CLI. All three are indistinguishable from
# each other and from "normal mode paints no indicator" — so none of them
# may be read as OFF.
#
# HONEST LIMIT, 2026-08-02: every claude pane on this box reads
# "bypass permissions on". There is NO captured specimen of the OFF
# rendering, so `bypass_state` can currently only ever answer "on" or
# "unknown" from real input. It will parse an explicit "off" if the TUI
# ever paints one, but until a real OFF fixture exists, treat a returned
# "off" as unverified. The practical consequence is deliberate: auto-submit
# stays disabled everywhere until someone captures that fixture.
_MODE_HINT_RX = re.compile(r"⏵|shift\+tab to cycle", re.I)
_FOOTER_LINES = 6


# bypass_state() DELETED 2026-08-03 — the legacy string parser, not just its
# call sites. It searched for the literal "bypass permissions (on|off)", a
# string the TUI paints only in ONE of five modes, so it answered "unknown" on
# every checkpointed pane — including panes where may_autosubmit correctly
# returned True. A reader that cannot see the state the gate depends on is not
# a fallback, it is a second opinion that is always wrong in the same
# direction. _BYPASS_RX goes with it; permission_mode() is the reader.


# ── permission MODE, which is what the TUI actually paints ───────────
# afb907cf added three "bypass OFF" specimens. Running bypass_state against
# them returns "unknown" for all three, because none of them contains the
# string this detector was written to find:
#
#     ⏵⏵ accept edits on (shift+tab to cycle)
#     ⏸ manual mode on
#     ⏸ plan mode on (shift+tab to cycle)
#
# The TUI never paints "bypass permissions off". It paints whichever mode IS
# active, and bypass-off is expressed by a DIFFERENT mode being named. So the
# detector was not one specimen away from working; it was asking a question
# the footer never answers.
#
# Note the failure direction this had: unknown everywhere, which forbids
# auto-submit, which is safe. A safety test would never have caught it — only
# a usefulness test does. That is the mirror of the "says off to everything"
# trap, and it is the harder one to notice because nothing goes wrong.
#
# ALLOWLIST of named modes, per decision 17. An unrecognised mode string is
# unknown, loudly, rather than assumed harmless.
_MODE_RX = re.compile(
    r"(bypass permissions|accept edits|manual mode|plan mode)\s+(on|off)\b", re.I)

#: mode -> is there a downstream checkpoint a wrong Enter would hit?
#: `accept edits` is deliberately NOT here. It auto-accepts file edits with no
#: prompt, so a wrong Enter can write to disk unattended. It is weaker than
#: bypass but it is not checkpointed, and the whole justification for ever
#: enabling auto-submit is "the worst case is a human seeing a prompt".
CHECKPOINTED_MODES = {"manual mode", "plan mode"}
# Panes where pressing Enter submits a MESSAGE rather than executing a
# command. The permission-mode gate is about a keystroke that runs; in
# these, the keystroke only talks. See Gate 2 in TerminalWatcher.send.
TUI_COMMANDS = {"claude", "node"}

# Modes seen but deliberately NOT checkpointed, recorded so exclusion is a
# decision rather than an omission. An unlisted mode reads as unknown and is
# refused either way — but "we never met this mode" and "we met it and said
# no" are different facts, and only one of them is a reviewed judgement.
NOT_CHECKPOINTED = {
    "accept edits": "auto-accepts file edits with no prompt; a wrong Enter "
                    "reaches disk unattended",
    "auto mode": "the checkpoint is Claude's own risk judgement, not a "
                 "human's. Observed live 2026-08-03 while cycling modes. The "
                 "case for auto-submit is 'the worst case is a HUMAN seeing "
                 "a prompt' — a model gating itself is not that, and its own "
                 "banner says it can make mistakes that allow harmful "
                 "commands to run.",
    "bypass permissions": "no downstream checkpoint at all",
}


def permission_mode(pane_text: str) -> tuple[Optional[str], str]:
    """(mode_name, 'on'|'off'|'unknown'). None means no mode row was read."""
    tail = [l.strip() for l in pane_text.strip().splitlines()[-_FOOTER_LINES:]]
    for line in tail:
        m = _MODE_RX.search(line)
        if m:
            return m.group(1).lower(), m.group(2).lower()
    return None, "unknown"


def may_autosubmit(pane_text: str) -> bool:
    """Auto-submit requires a POSITIVE, readable 'off'.

    'on' forbids it (no downstream checkpoint) and 'unknown' forbids it
    (we cannot claim a checkpoint we did not observe). Both degrade to
    adopt-only rather than blocking the pane: adopt-only performs no
    action on the pane at all, so it is already the safe state, and
    blocking would buy no additional safety while costing availability —
    which is the failure that has been costing Dean hours.

    2026-08-03: routed through permission_mode, because "off" is expressed by
    a different mode being named rather than by the word "off" appearing.
    A checkpointed mode being ON is the positive reading of bypass being off.
    """
    mode, state = permission_mode(pane_text)
    if mode == "bypass permissions" and state == "on":
        return False
    return mode in CHECKPOINTED_MODES and state == "on"


def has_unsubmitted_input(pane_text: str) -> bool:
    """A line typed into the prompt box but never sent.

    This is the failure that made element115 look dead for hours on
    2026-08-02: text sitting after the ❯ with no Enter behind it. A pane
    in this state is not idle-because-finished, it is idle-because-stuck,
    and the two need different responses.
    """
    for raw in reversed(pane_text.strip().splitlines()):
        line = raw.strip()
        if not line or set(line) <= {"─", "-", "═"}:
            continue
        if line.startswith("❯") or line.startswith(">"):
            typed = line.lstrip("❯> ").strip()
            # The TUI paints greyed placeholder hints in the empty prompt
            # box (Try "fix typecheck errors"). That is an EMPTY box, and
            # calling it stuck would make every idle agent look wedged.
            if typed.startswith('Try "') or typed.startswith("Try '"):
                return False
            return len(typed) > 0
    return False


# ── cursor-based input detection ─────────────────────────────────────
# Scraping the ❯ row is unreliable: decoration rows render like typed text,
# and three of Leon's reads disagreed with three of my captures. tmux can
# answer it numerically instead.
#
# Measured on a live pane 2026-08-02, mid-turn:
#     cursor_y=19 cursor_x=2 height=23 cursor_flag=1 pane_in_mode=0
#     row 19 (0-indexed) == "❯ "        ← the input row, empty
#
# cursor_y identifies the input ROW with no glyph matching at all, and
# cursor_x gives the caret's column — which on an empty box sits at the
# prompt prefix and advances by exactly the number of characters typed.
# So "is there unsubmitted text" becomes arithmetic, not pattern matching.
#
# Two requirements, both load-bearing:
#   * capture WITHOUT -S, so row indices align with cursor_y. A scrollback
#     capture shifts every index and silently points at the wrong row.
#   * check pane_in_mode first: in copy mode the cursor is the COPY cursor
#     and has nothing to do with the prompt.
#
# Note the cursor stays parked on the prompt row even while generating, so
# this says nothing about busy/idle — that is is_busy()'s job.

def cursor_probe(window: str) -> Optional[dict]:
    """Cursor geometry for a pane, or None if tmux could not answer."""
    out = _run(["tmux", "display-message", "-p", "-t", f"{SESSION}:{window}",
                "#{cursor_y}\t#{cursor_x}\t#{pane_in_mode}\t#{cursor_flag}"]).strip()
    parts = out.split("\t")
    if len(parts) != 4 or not parts[0].isdigit():
        return None
    return {"cursor_y": int(parts[0]), "cursor_x": int(parts[1]),
            "in_mode": parts[2] == "1", "cursor_visible": parts[3] == "1"}


def visible_capture(window: str) -> str:
    """The VISIBLE pane only — no -S. Row indices align with cursor_y."""
    return _run(["tmux", "capture-pane", "-p", "-t", f"{SESSION}:{window}"])


_PROMPT_PREFIX_RX = re.compile(r"^\s*[❯>]\s?")


_painted_residue_seen: dict = {}


def unsubmitted_text(window: str) -> tuple[str, Optional[str]]:
    """('empty'|'text'|'unknown', the text) — THE CURSOR IS THE ONLY TRUTH.

    SETTLED EMPIRICALLY 2026-08-03, and it reverses this function's previous
    design. Leon sent a single `X` into a pane whose prompt row rendered
    "run the rubric against the OFF specimens". The X REPLACED the whole
    line; cursor_x read 2 throughout; Enter pressed twice submitted nothing.
    The row was stale paint, and the buffer had been empty the entire time.

    That kills the cross-check this function used to do. The old code called
    row-says-text-but-cursor-says-empty a mid-repaint race and answered
    'unknown' — treating a durable condition as a transient fault.

    CORRECTION 2026-08-03, mine to make: I first wrote here that residue "is
    what the screen looks like most of the time". That is not supported and I
    should not have said it. Residue is REAL and DURABLE when it happens —
    five captured instances (element115, v1rtue, and all three afb907cf
    specimens) — but it did not reproduce once in ten deliberate attempts
    across the three most obvious triggers: C-u clears cleanly, a submitted
    turn repaints cleanly, and text sent while the pane is busy goes into the
    box normally and is cleared normally when queued. So the mechanism is
    still unidentified and the frequency is unknown. What survives, and all
    that the code needs, is that cursor_x is authoritative whenever the two
    disagree — that does not depend on how often they disagree.

    So the row no longer votes. It is used for exactly two things: locating
    the prompt prefix, and — when cursor_x says the buffer is empty — being
    recorded as the reader's claim in prompt_read_mismatches.jsonl.

    When cursor_x DOES exceed the prefix the row is trustworthy for the
    payload, and that is not an assumption: the same experiment showed a real
    keystroke repaints the row in full rather than appending to residue.

    LIMIT: cursor_x counts terminal cells, so a wide (CJK/emoji) character
    advances it by two. The length is therefore a lower bound on characters,
    which is safe for the empty/non-empty question — the only question any
    caller is allowed to key on — but not for slicing exact payloads.
    """
    probe = cursor_probe(window)
    if probe is None:
        return "unknown", None
    fr = unsubmitted_from_frame(visible_capture(window).splitlines(), probe)
    verdict, payload, painted = fr.verdict, fr.payload, fr.painted
    if verdict == "empty" and painted and not painted.startswith(('Try "', "Try '")):
        _note_residue(window, painted, probe, "\n".join(
            visible_capture(window).splitlines()))
    return verdict, payload


class FrameRead(NamedTuple):
    """An OBSERVATION and a JUDGMENT, kept apart.

    `painted` is what the screen shows. It is an observation and it survives
    everything — no absence of geometry may ever null it.
    `verdict` is what the buffer holds. It is a judgment, it REQUIRES
    geometry, and without geometry it abstains.

    Collapsing the two is what produced rows claiming the reader saw nothing
    while the paint plainly showed an instruction — abstention leaking
    backwards into the evidence it was supposed to qualify.
    """
    verdict: str            # "empty" | "text" | "unknown"  (judgment)
    payload: Optional[str]
    painted: Optional[str]  # observation — never nulled by missing geometry
    paint_source: str       # "cursor_row" | "scan" | "none"
    geometry_present: bool


def read_paint(lines: list, cursor_y: Optional[int] = None) -> tuple:
    """(painted_text, source). Pure observation, no geometry required.

    With cursor_y we know exactly which row is the input box. Without it we
    scan upward for the last prompt row — which is the old paint reader, and
    is labelled as such in `source` so a consumer can never mistake a scanned
    reading for a cursor-located one.
    """
    if cursor_y is not None and 0 <= cursor_y < len(lines):
        m = _PROMPT_PREFIX_RX.match(lines[cursor_y])
        if m:
            return lines[cursor_y][m.end():].strip(), "cursor_row"
    for raw in reversed(lines):
        line = raw.rstrip()
        if not line.strip() or set(line.strip()) <= {"─", "-", "═"}:
            continue
        m = _PROMPT_PREFIX_RX.match(line)
        if m:
            return line[m.end():].strip(), "scan"
    return None, "none"


def unsubmitted_from_frame(lines: list, probe: dict) -> "FrameRead":
    """PURE core. Split out 2026-08-03 so a stored specimen adjudicates
    through exactly the same arithmetic as a live pane — a replay that
    reimplements this proves only that the replay agrees with itself.

    2026-08-03 (second pass): returns FrameRead rather than a tuple, because
    the tuple let a missing cursor null the paint reading on its way out.
    """
    cy = probe.get("cursor_y") if probe else None
    painted, source = read_paint(lines, cy)
    if probe is None or probe.get("in_mode"):
        # No geometry -> the JUDGMENT abstains. The OBSERVATION stands.
        return FrameRead("unknown", None, painted, source, False)
    cy = probe["cursor_y"]
    if cy >= len(lines):
        return FrameRead("unknown", None, painted, source, True)
    row = lines[cy]
    m = _PROMPT_PREFIX_RX.match(row)
    if not m:
        # The cursor is not on a prompt row at all — a dialog, a menu, or a
        # repaint. Not a claim about the input box either way.
        return FrameRead("unknown", None, painted, source, True)
    prefix = m.end()
    cells = probe["cursor_x"] - prefix
    if cells <= 0:
        return FrameRead("empty", "", painted, source, True)
    return FrameRead("text", row[prefix:prefix + cells].strip(), painted, source, True)


def _note_residue(window: str, painted: str, probe: dict, tail: str) -> None:
    """Record a paint-vs-cursor disagreement, edge-triggered per pane.

    This is the recorder finally getting fed from live operation rather than
    from tests. The row is evidence about THE SCREEN, not about any reader:
    the reader was faithful, the pixels were stale.
    """
    if _painted_residue_seen.get(window) == painted:
        return
    _painted_residue_seen[window] = painted
    try:
        from brain.mission import read_mismatch
        read_mismatch.record(
            window, painted, ("empty", ""), probe, tail,
            note="painted residue: prompt row renders text, cursor_x is at "
                 "the prefix, so the buffer is empty. Not a repaint race — "
                 "this is the steady state (verified 2026-08-03).")
    except Exception:
        pass          # instrumentation must never break the loop it observes


# ── LOG & RESTART instrumentation ────────────────────────────────────
# Is the banner advisory or imminent? Leon watched a pane hold at 88%
# through forty minutes of turns, which is one observation. This records
# every sighting so the question is settled by a distribution instead of
# by argument — and pairs each sighting with the compaction that
# eventually follows it, if one ever does.
AUTOLOOP_EVENTS_PATH = os.path.join(STATE_DIR, "autoloop_events.jsonl")
_CTX_RX = re.compile(r"ctx\s+(\d+)\s*%", re.I)
_BANNER_RX = re.compile(r"LOG\s*&\s*RESTART", re.I)
_banner_open: dict = {}


def ctx_pct(pane_text: str) -> Optional[int]:
    m = _CTX_RX.search(pane_text)
    return int(m.group(1)) if m else None


def banner_present(pane_text: str) -> bool:
    return bool(_BANNER_RX.search(pane_text))


def _append_event(rec: dict) -> None:
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(AUTOLOOP_EVENTS_PATH, "a") as fh:
            fh.write(json.dumps(rec) + "\n")
    except Exception:
        pass        # instrumentation must never break the loop it observes


def note_banner(window: str, pane_text: str, compacting: bool = False) -> None:
    """Call once per poll per pane. Records the banner's life, not each poll.

    Emits on the EDGES: first sighting, and the compaction that closes it.
    A row per poll would drown the file and answer nothing extra.
    """
    seen = banner_present(pane_text)
    pct = ctx_pct(pane_text)
    now = time.time()
    open_rec = _banner_open.get(window)
    if seen and open_rec is None:
        _banner_open[window] = {"ctx_pct": pct, "banner_seen_at": now}
        _append_event({"event": "banner_seen", "window": window,
                       "ctx_pct": pct, "banner_seen_at": now,
                       "compaction_started_at": None})
    elif open_rec is not None and (compacting or not seen):
        _append_event({"event": "banner_closed", "window": window,
                       "ctx_pct": open_rec["ctx_pct"],
                       "banner_seen_at": open_rec["banner_seen_at"],
                       "compaction_started_at": now if compacting else None,
                       "held_s": round(now - open_rec["banner_seen_at"], 1)})
        _banner_open.pop(window, None)


def _digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]


def _load_pending() -> dict:
    try:
        with open(PENDING_PATH) as f:
            return json.load(f)
    except Exception:
        return {"events": [], "consumed": []}


def _save_pending(data: dict) -> None:
    os.makedirs(STATE_DIR, exist_ok=True)
    tmp = PENDING_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, PENDING_PATH)


class TerminalWatcher:
    """Poll panes; emit an event when one finishes saying something new.

    Usage from Leon's own loop:

        w = TerminalWatcher()
        for ev in w.poll():          # cheap, call as often as you like
            reply = think_about(ev)  # Leon decides
            w.send(ev.window, reply)
            w.consume(ev)            # only now is it "read"
    """

    def __init__(self) -> None:
        # window -> (digest, first_seen_ts) of the current still frame
        self._still: dict[str, tuple[str, float]] = {}

    # ── sensing ──────────────────────────────────────────────────────
    def poll(self) -> list[TerminalEvent]:
        pending = _load_pending()
        consumed = set(pending.get("consumed", [])[-500:])
        already = {e["digest"] for e in pending.get("events", [])}
        fresh: list[TerminalEvent] = []
        now = time.time()

        for win in list_windows():
            text = capture(win)
            if not text.strip():
                continue
            if is_busy(text):
                self._still.pop(win, None)
                continue

            d = _digest(text)
            prev = self._still.get(win)
            if prev is None or prev[0] != d:
                # First time we've seen this exact frame — start the
                # settle timer rather than firing immediately.
                self._still[win] = (d, now)
                continue

            quiet_for = now - prev[1]
            if quiet_for < SETTLE_S:
                continue
            if d in consumed or d in already:
                continue

            fresh.append(TerminalEvent(
                window=win, text=text, digest=d,
                detected_at=now, quiet_for_s=round(quiet_for, 1),
            ))

        if fresh:
            pending["events"] = pending.get("events", []) + [
                e.to_dict() for e in fresh
            ]
            _save_pending(pending)
            # ── AWARENESS TAP ────────────────────────────────────────
            # Emit at CREATION, not at read. The tap cannot poll pending():
            # the autoloop CONSUMES the events it answers, and those are
            # exactly the replies Leon needs to know about. Anything reading
            # pending() on a timer would systematically miss every handled
            # reply — the opposite of the requirement. Appending here catches
            # 100% with no race and without a second consumer.
            # Append-only, exception-guarded: awareness must never break the
            # sensing loop it observes.
            try:
                from brain.mission import terminal_tap
                terminal_tap.note_events(fresh)
            except Exception:
                pass
        return fresh

    def pending(self) -> list[TerminalEvent]:
        """Unconsumed events, including ones from before a restart."""
        data = _load_pending()
        return [TerminalEvent(**e) for e in data.get("events", [])]

    def consume(self, ev: TerminalEvent) -> None:
        # Close the debt. Found live 2026-08-03: nothing set `replied`, so a
        # send stayed owed forever and every pane would eventually escalate
        # as wedged — the false-positive we just removed, re-entering through
        # the ledger instead of through the screen. Consume is the right
        # edge: it is the moment Leon has actually READ the agent's answer,
        # which is what closes the turn, not the moment text appeared.
        try:
            from brain.mission import send_ledger
            status, entry = send_ledger.debt_status(
                ev.window, None)          # None: do not orphan on read
            if entry is not None and not entry.get("replied"):
                send_ledger.mark(entry["send_id"], ev.window, "replied")
        except Exception:
            pass          # instrumentation must never break the loop it observes
        data = _load_pending()
        data["events"] = [e for e in data.get("events", [])
                          if e["digest"] != ev.digest]
        data["consumed"] = (data.get("consumed", []) + [ev.digest])[-500:]
        _save_pending(data)

    # ── acting ───────────────────────────────────────────────────────
    def send(self, window: str, message: str) -> bool:
        """Send one message and submit it.

        The message is flattened to a single line: a literal newline in a
        tmux send-keys payload submits early and fragments one thought
        into several turns.
        """
        flat = " ".join(message.split())
        if not flat:
            return False

        # ── DO NOT CLOBBER ───────────────────────────────────────────
        # This C-u was written to clear "a stray unsubmitted line" back when
        # we believed the box was routinely holding stranded TUI-authored
        # text. As of 2026-08-03 we know that text was paint, and the buffer
        # was empty — which means the ONE case where C-u actually deletes
        # something is the case where a HUMAN really has a draft typed and
        # unsent. The comment above described clearing residue; the code was
        # in fact a silent destroy-Dean's-draft path that had simply never
        # fired yet.
        #
        # Record ordering: refuse > wait > prepend > clobber. Refuse.
        from brain.mission import escalation, payload_gate

        # ── GATE 1: the box must be empty, by CURSOR. Hard precondition. ──
        # Painted text is never evidence — 78 recorded rows, 33 of them the
        # reader claiming text where cursor_x sat at the prefix. Only
        # cursor_x > prompt_prefix means the buffer holds characters, and if
        # it does they are someone's unsent draft.
        verdict, payload = unsubmitted_text(window)
        if verdict != "empty":
            escalation.escalate(
                window, "origin_unverified", payload or "",
                pane_state={"mechanical_verdict": verdict},
                detail=f"send() refused: box is {verdict!r}. Two unsent drafts "
                       "cannot be arbitrated by the loop — only the authors "
                       "can decide the order.")
            return False

        # ── GATE 2: may_autosubmit. THE GATE NOW HAS A CALLER. ──────────
        # Until 2026-08-03 nothing called this before pressing Enter, which
        # made it decoration: six runs proved it ANSWERS correctly and zero
        # proved it GATED anything.
        #
        # SCOPED 2026-08-03, and this is a correction of my own reasoning.
        # I wrote here that the gate refusing all 5 agent panes — every one of
        # them reads "bypass permissions on" — was "the intended cost, not a
        # bug." It refused 94/94 and I called that the NO path being proven.
        # It wasn't proof of anything except that the loop can never speak:
        # Dean turned bypass ON so these agents could work unattended, and I
        # built a gate that reads his deliberate config as danger and answers
        # by going permanently silent. He wakes up to nothing moving.
        #
        # What Gate 2 actually protects against is a wrong Enter LANDING ON A
        # SHELL, where the line executes literally. In a claude TUI the Enter
        # submits prose to an agent that then decides for itself — and Gate 1
        # has already proven by cursor that the box was empty, and Gate 3 has
        # already proven the payload is one the loop composed. There is no
        # foreign text to adopt; we established that when the "stranded line"
        # turned out to be paint. So the mode check now applies where the
        # keystroke is dangerous — shells — and not where it is merely a
        # message.
        pane_text = capture(window)
        pane_cmd = _run(["tmux", "display-message", "-p", "-t",
                         f"{SESSION}:{window}", "#{pane_current_command}"]).strip()
        keystroke_executes = pane_cmd not in TUI_COMMANDS
        if keystroke_executes and not may_autosubmit(pane_text):
            mode, state = permission_mode(pane_text)
            escalation.escalate(
                window, "bypass_unknown", flat,
                pane_state={"permission_mode": mode, "mode_state": state},
                detail=f"send() refused: mode {mode!r}/{state!r} is not "
                       "checkpointed, so a wrong Enter has no human in front "
                       "of it. shift+tab to plan or manual mode to enable.")
            return False

        # ── GATE 3: the payload the LOOP composed, allowlist then deny. ──
        # loop_authored: this text came out of compose_reply under Leon's
        # own system prompt. It is not adopted from a pane.
        klass, why = payload_gate.classify_payload(flat, loop_authored=True)
        if klass != payload_gate.ALLOW:
            escalation.escalate(
                window,
                "deny_shape" if klass == payload_gate.DENY else "allowlist_miss",
                flat, detail=f"send() refused: {why}")
            return False
        # WRITE-AHEAD. The ledger row goes down BEFORE the keystroke, and it
        # is the one call here that is not exception-guarded: a send we failed
        # to record is a debt that can never be collected, so failing to write
        # is a reason not to send. A crash after this line leaves a phantom
        # debt (visible, recoverable); a crash before it, had we logged after,
        # would leave silence.
        from brain.mission import send_ledger, pane_watchdog
        meta = pane_watchdog.pane_meta(window)
        _mode, _state = permission_mode(pane_text)
        send_id = send_ledger.record_send(
            window, flat, meta.get("pane_pid"),
            pane_watchdog.proc_started_at(meta.get("pane_pid")),
            gate={"recorded": True,
                  "cursor_verdict": verdict,          # GATE 1, cursor only
                  "permission_mode": _mode,           # GATE 2 input
                  "mode_state": _state,
                  "may_autosubmit": True,             # GATE 2 passed to reach here
                  "payload_class": klass,             # GATE 3
                  "paint_admitted": False})

        _run(["tmux", "send-keys", "-t", f"{SESSION}:{window}", "C-u"])
        time.sleep(0.3)
        _run(["tmux", "send-keys", "-t", f"{SESSION}:{window}", flat])
        time.sleep(0.3)
        # RAW CARRIAGE RETURN, NOT "Enter". Root-caused 2026-08-10: the key name
        # goes through tmux's translation table, and the Claude TUI's Ink
        # raw-mode reader does not accept the result as submit. The text lands
        # in the box and nothing happens — no error, exit code 0, looks like it
        # worked. This line is why prompts written by this loop sat stranded in
        # idle panes for hours while the ledger said "delivered".
        _run(["tmux", "send-keys", "-t", f"{SESSION}:{window}", "-H", "0d"])

        # "delivered" used to mean "we called send-keys and it exited 0" — which
        # was true on every single failure. Verify at the layer that matters:
        # the pane is either running a turn now, or the submit did not happen.
        #
        # POLL, never a single sleep-then-look. Measured 2026-08-10: a real
        # submit needs ~1s to show a running indicator, and reading one frame
        # too early reports "not running" on a submit that actually worked.
        # That false negative is what made the previous root cause ("Enter is
        # broken") look proven when it was not. Give it a real window.
        submitted = False
        for _ in range(10):
            time.sleep(1.0)
            if is_busy(capture(window, lines=25)):
                submitted = True
                break
        if submitted:
            send_ledger.mark(send_id, window, "delivered")
        else:
            send_ledger.mark(send_id, window, "submit_failed")
            print(
                f"terminal_loop: submit to {window} did not start a turn — "
                "text may be stranded in the input box",
                file=sys.stderr, flush=True)
            return False
        # Forget the still-frame so the agent's reply reads as new.
        self._still.pop(window, None)
        return True

    # ── health ───────────────────────────────────────────────────────
    def stuck_panes(self) -> list[dict]:
        """Panes that are idle for the WRONG reason and need a nudge."""
        out = []
        for win in list_windows():
            text = capture(win, lines=25)
            if not text.strip() or is_busy(text):
                continue
            if has_unsubmitted_input(text):
                out.append({"window": win, "reason": "unsubmitted_input"})
        return out


__all__ = ["TerminalWatcher", "TerminalEvent", "is_busy",
           "has_unsubmitted_input", "list_windows", "capture"]
