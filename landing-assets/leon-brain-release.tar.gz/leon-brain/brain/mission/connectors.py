"""
External Connectors — safe, read-first integrations for external systems.

Supports: GitHub (via gh CLI), Codemagic (API), RevenueCat (API),
Apple App Store Connect (API), generic backend health checks.

Priority: read/check APIs first. Browser automation only as fallback.
All methods return dicts with {ok, data, error} shape.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from typing import Any, Optional
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

log = logging.getLogger("leon.mission.connectors")

_TIMEOUT = 15  # seconds for HTTP requests


def _http_get(url: str, headers: dict | None = None, timeout: int = _TIMEOUT) -> dict:
    try:
        req = Request(url, headers=headers or {})
        with urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode()
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                data = body
            return {"ok": True, "status": resp.status, "data": data}
    except HTTPError as e:
        return {"ok": False, "status": e.code, "error": str(e), "data": None}
    except (URLError, OSError) as e:
        return {"ok": False, "status": 0, "error": str(e), "data": None}


def _run_cmd(cmd: list[str], timeout: int = 30) -> dict:
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"ok": result.returncode == 0, "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(), "code": result.returncode}
    except FileNotFoundError:
        return {"ok": False, "stdout": "", "stderr": f"Command not found: {cmd[0]}", "code": -1}
    except subprocess.TimeoutExpired:
        return {"ok": False, "stdout": "", "stderr": "Command timed out", "code": -2}


class ExternalConnectors:
    """Read-first external system integrations."""

    def __init__(self):
        self._cache: dict[str, tuple[float, Any]] = {}
        self._cache_ttl = 60  # seconds
        log.info("ExternalConnectors ready")

    def _cached(self, key: str) -> Any | None:
        if key in self._cache:
            ts, data = self._cache[key]
            if time.time() - ts < self._cache_ttl:
                return data
        return None

    def _set_cache(self, key: str, data: Any):
        self._cache[key] = (time.time(), data)

    # ── GitHub (via gh CLI) ─────────────────────────────────────────────

    def github_repo_info(self, owner: str, repo: str) -> dict:
        key = f"gh_repo_{owner}/{repo}"
        cached = self._cached(key)
        if cached:
            return cached
        r = _run_cmd(["gh", "repo", "view", f"{owner}/{repo}", "--json",
                       "name,defaultBranchRef,isPrivate,url,description,pushedAt"])
        if r["ok"]:
            try:
                data = json.loads(r["stdout"])
                result = {"ok": True, "data": data}
            except json.JSONDecodeError:
                result = {"ok": True, "data": r["stdout"]}
        else:
            result = {"ok": False, "error": r["stderr"]}
        self._set_cache(key, result)
        return result

    def github_pr_status(self, owner: str, repo: str, pr_number: int) -> dict:
        r = _run_cmd(["gh", "pr", "view", str(pr_number), "--repo", f"{owner}/{repo}",
                       "--json", "number,title,state,mergeable,merged,headRefName,baseRefName,url"])
        if r["ok"]:
            try:
                return {"ok": True, "data": json.loads(r["stdout"])}
            except json.JSONDecodeError:
                return {"ok": True, "data": r["stdout"]}
        return {"ok": False, "error": r["stderr"]}

    def github_latest_pr(self, owner: str, repo: str) -> dict:
        r = _run_cmd(["gh", "pr", "list", "--repo", f"{owner}/{repo}", "--limit", "1",
                       "--json", "number,title,state,merged,url,createdAt"])
        if r["ok"]:
            try:
                prs = json.loads(r["stdout"])
                return {"ok": True, "data": prs[0] if prs else None}
            except json.JSONDecodeError:
                return {"ok": True, "data": r["stdout"]}
        return {"ok": False, "error": r["stderr"]}

    def github_workflow_runs(self, owner: str, repo: str, limit: int = 5) -> dict:
        r = _run_cmd(["gh", "run", "list", "--repo", f"{owner}/{repo}", "--limit", str(limit),
                       "--json", "databaseId,name,status,conclusion,headBranch,createdAt,url"])
        if r["ok"]:
            try:
                return {"ok": True, "data": json.loads(r["stdout"])}
            except json.JSONDecodeError:
                return {"ok": True, "data": r["stdout"]}
        return {"ok": False, "error": r["stderr"]}

    # ── Codemagic ───────────────────────────────────────────────────────

    def codemagic_builds(self, app_id: str, limit: int = 5) -> dict:
        token = os.environ.get("CODEMAGIC_API_TOKEN", "")
        if not token:
            return {"ok": False, "error": "CODEMAGIC_API_TOKEN not set"}
        r = _http_get(
            f"https://api.codemagic.io/builds?appId={app_id}&limit={limit}",
            headers={"x-auth-token": token},
        )
        return r

    def codemagic_latest_build(self, app_id: str) -> dict:
        r = self.codemagic_builds(app_id, limit=1)
        if r["ok"] and isinstance(r["data"], dict):
            builds = r["data"].get("builds", [])
            return {"ok": True, "data": builds[0] if builds else None}
        return r

    # ── RevenueCat ──────────────────────────────────────────────────────

    def revenuecat_project_info(self, project_id: str) -> dict:
        key = os.environ.get("REVENUECAT_V2_SECRET", "") or os.environ.get("REVENUECAT_API_KEY", "")
        if not key:
            return {"ok": False, "error": "REVENUECAT_V2_SECRET not set"}
        r = _http_get(
            f"https://api.revenuecat.com/v2/projects/{project_id}",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        )
        return r

    def revenuecat_products(self, project_id: str) -> dict:
        key = os.environ.get("REVENUECAT_V2_SECRET", "") or os.environ.get("REVENUECAT_API_KEY", "")
        if not key:
            return {"ok": False, "error": "REVENUECAT_V2_SECRET not set"}
        r = _http_get(
            f"https://api.revenuecat.com/v2/projects/{project_id}/products",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        )
        return r

    # ── Apple App Store Connect ─────────────────────────────────────────

    def asc_app_info(self, app_id: str) -> dict:
        """Check if an App Store Connect app record exists.
        Requires ASC_API_KEY_ID, ASC_ISSUER_ID, ASC_PRIVATE_KEY env vars.
        Falls back to noting creds are missing."""
        key_id = os.environ.get("ASC_API_KEY_ID", "")
        if not key_id:
            return {"ok": False, "error": "ASC_API_KEY_ID not set — Apple App Store Connect credentials required"}
        # ASC requires JWT auth — complex. For now, flag the capability.
        return {"ok": False, "error": "ASC JWT auth not yet implemented — use browser fallback",
                "needs_implementation": True}

    # ── Generic backend health ──────────────────────────────────────────

    def health_check(self, url: str) -> dict:
        """GET a health/version endpoint and report status."""
        # Skip self-check — Leon can't HTTP-GET itself synchronously without deadlock
        if any(h in url for h in ("127.0.0.1:8000", "localhost:8000")):
            return {"ok": True, "url": url, "status_code": 200,
                    "data": "self (Leon)", "checked_at": time.time(), "self_check": True}
        key = f"health_{url}"
        cached = self._cached(key)
        if cached:
            return cached
        r = _http_get(url, timeout=10)
        result = {
            "ok": r["ok"],
            "url": url,
            "status_code": r.get("status", 0),
            "data": r.get("data"),
            "checked_at": time.time(),
        }
        if not r["ok"]:
            result["error"] = r.get("error", "unknown")
        self._set_cache(key, result)
        return result

    def backend_version(self, url: str) -> dict:
        """Check a /version or /api/version endpoint."""
        for suffix in ("", "/version", "/api/version", "/health"):
            endpoint = url.rstrip("/") + suffix
            r = self.health_check(endpoint)
            if r["ok"]:
                return r
        return {"ok": False, "url": url, "error": "No reachable version/health endpoint found"}

    # ── Aggregate check ─────────────────────────────────────────────────

    def check_all_for_project(self, project: dict) -> dict:
        """Run all available checks for a project dict (from ProjectRegistry)."""
        results = {}

        # GitHub
        for repo_url in project.get("repo_urls", []):
            parts = repo_url.rstrip("/").split("/")
            if len(parts) >= 2:
                owner, repo = parts[-2], parts[-1]
                repo = repo.replace(".git", "")
                results[f"github_{owner}/{repo}"] = self.github_repo_info(owner, repo)
                results[f"github_{owner}/{repo}_latest_pr"] = self.github_latest_pr(owner, repo)
                results[f"github_{owner}/{repo}_workflows"] = self.github_workflow_runs(owner, repo, limit=3)

        # Codemagic
        for wf_name, wf_id in (project.get("codemagic_ids") or {}).items():
            results[f"codemagic_{wf_name}"] = self.codemagic_latest_build(wf_id)

        # RevenueCat
        for rc_name, rc_id in (project.get("revenuecat_ids") or {}).items():
            results[f"revenuecat_{rc_name}"] = self.revenuecat_project_info(rc_id)

        # Backend health
        for backend_url in project.get("backend_urls", []):
            results[f"backend_{backend_url}"] = self.health_check(backend_url)

        return results
