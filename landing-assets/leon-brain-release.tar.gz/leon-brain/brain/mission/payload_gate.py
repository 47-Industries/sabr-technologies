"""Payload gate — the stage after tally(), and the answer to
"regex list or real classifier" is that the question has the wrong axis.

Leon asked: deny-class as a regex list, or a trained classifier with its
own thirty-row bar? He expected regex. He is right about the MECHANISM
and wrong about the SHAPE, and the shape is the part that bites.

A deny-class is a BLOCKLIST. Twice this week a blocklist failed here in
exactly the same way:

  * build_release.sh checked `grep -c secure/` and passed green while
    .env and the client lead DB walked straight through. "The check
    tested one path, not the class" — Leon's own words, 2026-08-02.
  * BUSY_MARKERS enumerated "Running 1/2/3 shell command" and missed
    four parallel calls.

Anything not enumerated walks through, and you only learn what was
missing after it ships. Leon already made the correct move once tonight
— idempotency became "an allowlist classifier rather than a heuristic".
The deny-class is that same mistake returning under a different name.

So: ALLOWLIST of payload shapes the loop may auto-submit, expressed as
regex (no model, no training set, no second thirty-row bar — his
mechanism instinct was right). Everything unmatched escalates. The deny
list survives only as a BELT: it catches an allowlist entry that turns
out to be too broad, which is the one job a blocklist is good at.

Second point, and it matters more than the first: the deny-class does
NOT catch Leon's own example. "restart me and I'll pick up from the
commits" was never sent by the loop, so ORIGIN rejects it before any
content rule runs. Origin and content defend different failures —
origin catches text we did not write, content catches text we wrote
badly — and conflating them buys false confidence in both.
"""
from __future__ import annotations

import re
from typing import Optional

ALLOW, DENY, UNKNOWN = "allow", "deny", "unknown"

#: Shapes the loop is permitted to auto-submit. Deliberately narrow: this
#: is the set of things the autoloop actually sends — a task handoff, a
#: status question, a request to report. If a new shape is needed, it is
#: added here ON PURPOSE, which is the property a denylist cannot have.
ALLOWED_SHAPES = (
    re.compile(r"^(please\s+)?(report|summari[sz]e|status)\b.{0,200}$", re.I),
    re.compile(r"^(next|new)\s+task\b.{0,400}$", re.I),
    re.compile(r"^(read|review|check|inspect|look at)\s+\S.{0,400}$", re.I),
    re.compile(r"^(what|where|which|how|why|when|is|are|does|did|can)\b.{0,300}\?$", re.I),
    re.compile(r"^(capture|write|draft|design|diagnose|attack)\b.{0,400}$", re.I),
)

#: Belt, not the safety property. These exist to catch an ALLOWED_SHAPES
#: entry that is broader than intended — e.g. a "check …" pattern that
#: happens to match "check out and force-push". A hit here is a bug in
#: the allowlist, and should be loud.
DENY_SHAPES = (
    re.compile(r"\b(restart|reboot|shutdown|kill|pkill|terminate)\b", re.I),
    re.compile(r"\brm\s+-[rf]|\brm\s+-\w*r", re.I),
    re.compile(r"\bgit\s+push\b.*(--force|-f)\b|\bforce[- ]push\b", re.I),
    re.compile(r"\bgit\s+(reset\s+--hard|clean\s+-\w*[fdx])", re.I),
    re.compile(r"\b(systemctl|service)\s+(stop|disable|restart|mask)\b", re.I),
    re.compile(r"\bdrop\s+(table|database)\b|\btruncate\s+table\b", re.I),
    re.compile(r"\b(shutdown|halt|poweroff)\b", re.I),
    re.compile(r">\s*/dev/sd|mkfs|dd\s+if=.*of=/dev/", re.I),
)


#: The subset of DENY_SHAPES that matches an actual dangerous COMMAND
#: rather than an English word. The bare-verb row above (restart|kill|…)
#: is the right check for text of unknown origin and the wrong one for
#: prose: this loop's entire subject matter is wedged processes, so every
#: real message it composes says "kill" or "restart" somewhere and every
#: one of them would be denied. Origin decides which set applies.
COMMAND_DENY_SHAPES = tuple(rx for rx in DENY_SHAPES
                            if rx.pattern != r"\b(restart|reboot|shutdown|kill|pkill|terminate)\b")


def classify_payload(text: str, loop_authored: bool = False) -> tuple[str, Optional[str]]:
    """(verdict, reason). DENY beats ALLOW: a deny hit on allowlisted text
    means the allowlist is too broad, and the payload must not go out
    while that is true.

    loop_authored, 2026-08-03: the allowlist was built to vet text of
    UNKNOWN origin — the adopt path. That path is deleted; there is no
    foreign text. What remains is prose the loop composed itself, under
    its own system prompt, and the allowlist's narrow prefixes ("report…",
    "next task…", ≤400 chars) match approximately none of it. So it
    escalated every single message and sent nothing, which reads as the
    loop being dead. For loop-authored payloads the dangerous-command
    denies still apply — they are the real safety property — but a
    no-match is ALLOW rather than a silent refusal.
    """
    t = " ".join((text or "").split())
    if not t:
        return UNKNOWN, "empty payload"
    denies = COMMAND_DENY_SHAPES if loop_authored else DENY_SHAPES
    for rx in denies:
        m = rx.search(t)
        if m:
            return DENY, f"deny-shape matched {m.group(0)!r} (allowlist may be too broad)"
    for rx in ALLOWED_SHAPES:
        if rx.match(t):
            return ALLOW, "matched an allowed shape"
    if loop_authored:
        return ALLOW, "loop-authored prose, no dangerous-command shape"
    return UNKNOWN, "no allowed shape matched — escalate rather than guess"


# ── THE ADOPT PATH IS DELETED. 2026-08-03. ───────────────────────────
# `origin_ok()` and `may_auto_submit()` used to live here. They answered
# "the box has text in it — did WE write it, and may we press Enter on it?"
#
# That question is now known to be malformed, but not for the reason it first
# looked. Leon's finding was that the text we kept seeing was paint and the
# buffer was empty, and he concluded there is no such thing as foreign text to
# adopt. The first half is right; the conclusion is one step too strong, and
# the correction matters because it changes what has to survive:
#
#   Text in the box is now RARE, not impossible. cursor_x > prefix means the
#   buffer really does hold characters. Somebody typed them — Dean at the
#   keyboard, or our own send() whose Enter did not land.
#
# So the category is not empty. It is non-empty and consists ENTIRELY of
# things that must never be auto-submitted: an unsent draft belongs to
# whoever typed it, and pressing Enter on text we cannot attribute is the one
# rule this collaboration has never broken. Adopt is deleted because every
# member of its input set is forbidden, which is a stronger reason than the
# set being empty — an empty set fills back up the moment the world changes.
#
# What replaces it: cursor_x > prefix is now a REFUSAL trigger, not an adopt
# trigger. terminal_loop.send() refuses and escalates rather than clearing the
# box, which is where the real hazard turned out to be — that C-u was a
# silent destroy-the-human's-draft path wearing a comment about residue.
#
# The deny-class below SURVIVES, and is now load-bearing rather than a belt:
# it is what the loop's OWN composed payloads are checked against before they
# are sent. That check never depended on adoption.

def may_auto_submit(*_args, **_kwargs):
    """Removed. Kept as a loud tombstone so it cannot be quietly reinvented.

    If you are reaching for this, you want either `classify_payload()` (is the
    payload the loop composed safe to send?) or `terminal_loop.unsubmitted_text()`
    (does the box hold someone's draft, so we must refuse and escalate?).
    """
    raise NotImplementedError(
        "the adopt path was deleted 2026-08-03: every payload it could accept "
        "is text a human typed and did not send. Use classify_payload() for "
        "loop-authored text, or unsubmitted_text() to refuse.")


origin_ok = may_auto_submit
