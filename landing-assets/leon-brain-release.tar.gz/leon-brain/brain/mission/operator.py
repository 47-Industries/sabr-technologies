"""
Phase 17+ — Full Operator: Leon doesn't just diagnose. He acts.

Terminal resurrection, auto-fix pipeline, proactive project advancement,
PR preparation, and cross-project coordination.

This is the layer that makes Leon behave like a human operator who
actually moves projects forward instead of waiting for Dean to notice
a dashboard.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from datetime import datetime
from typing import Any, Callable, Optional

log = logging.getLogger("leon.mission.operator")


def _run(cmd: list[str], cwd: str | None = None, timeout: int = 30) -> dict:
    try:
        env = os.environ.copy()
        flutter_bin = os.path.expanduser("~/.flutter-sdk/bin")
        if os.path.isdir(flutter_bin) and flutter_bin not in env.get("PATH", ""):
            env["PATH"] = flutter_bin + ":" + env.get("PATH", "")
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd, env=env)
        return {"ok": r.returncode == 0, "stdout": r.stdout.strip()[:4000],
                "stderr": r.stderr.strip()[:1000], "code": r.returncode}
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "code": -1}


class Operator:
    """Leon's hands. Takes fixer diagnoses and actually does the work."""

    def __init__(self, registry=None, consciousness=None,
                 knowledge_store=None, broadcast=None, tts_say=None):
        self.registry = registry
        self._consciousness = consciousness
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._knowledge = knowledge_store
        self._session_path = os.path.expanduser("~/.openclaw/forever-sessions.json")
        self._project_paths: dict[str, str] = {}
        self._load_project_paths()
        self._actions_taken: list[dict] = []
        self._last_push_cache: dict[str, float] = {}  # project_name -> last push timestamp
        self._last_dep_update: dict[str, float] = {}  # project_name -> last dep update timestamp
        log.info("Operator ready")

    def _load_project_paths(self):
        try:
            if os.path.exists(self._session_path):
                with open(self._session_path) as f:
                    data = json.load(f)
                for s in data.get("forever", []):
                    self._project_paths[s.get("windowName", "")] = s.get("path", "")
        except Exception:
            pass

    def _find_path(self, project_name: str) -> str | None:
        slug = project_name.lower().replace(" ", "-")
        # Exact match first
        if slug in self._project_paths:
            p = self._project_paths[slug]
            if os.path.isdir(p):
                return p
        # Partial match — but require slug to be a full word boundary
        for wn, path in self._project_paths.items():
            if slug == wn or wn == slug:
                if os.path.isdir(path):
                    return path
        # Looser match only if no exact match found
        for wn, path in self._project_paths.items():
            if len(slug) > 4 and (slug in wn or wn in slug):
                if os.path.isdir(path):
                    return path
        return None

    def _find_window(self, project_name: str) -> str | None:
        slug = project_name.lower().replace(" ", "-")
        for wn in self._project_paths:
            if slug == wn or slug in wn or wn in slug:
                return wn
        return None

    # ── Full operate cycle ──────────────────────────────────────────────

    def operate(self, fixer_report: dict, findings: dict) -> dict:
        """Main entry: take fixer diagnosis + raw findings, DO everything safe."""
        self._actions_taken = []
        result = {
            "fixed": [],
            "advanced": [],
            "terminal_actions": [],
            "pr_prepared": [],
            "needs_dean": [],
            "voice_lines": [],
        }

        # 1. Fix diagnosed CI issues that are fixable
        for diag in fixer_report.get("diagnosed", []):
            if diag.get("fixable") and diag.get("fix_action"):
                fix = self._execute_fix(diag)
                if fix.get("success"):
                    result["fixed"].append(fix)
                    # If we made code changes, prepare a commit
                    if fix.get("changed_files"):
                        pr = self._prepare_commit(diag, fix)
                        if pr:
                            result["pr_prepared"].append(pr)

        # 2. Resurrect stuck terminals
        for terminal in findings.get("stuck_terminals", []):
            action = self._resurrect_terminal(terminal)
            if action:
                result["terminal_actions"].append(action)

        # 3. Proactive project advancement — check each active project
        #    for things we can push forward
        if self.registry:
            for proj in self.registry.list_all(active_only=True):
                advancement = self._try_advance(proj)
                if advancement:
                    result["advanced"].extend(advancement)

        # 4. Things Dean needs to handle
        for cant in fixer_report.get("cant_fix", []):
            result["needs_dean"].append({
                "project": cant.get("project", ""),
                "issue": cant.get("cause", cant.get("type", "unknown")),
                "instructions": cant.get("instructions", []),
            })

        # 5. Build voice summary
        result["voice_lines"] = self._build_voice(result)
        result["summary_text"] = self._build_summary(result)

        # 6. Surface everything to Dean (dashboard + voice)
        if result["summary_text"]:
            self._surface(result)

        # 7. Write to Leon's memory so he can recall what he did in conversation
        self._remember(result)

        return result

    # ── Fix execution ───────────────────────────────────────────────────

    def _execute_fix(self, diagnosis: dict) -> dict:
        """Execute a fixable diagnosis."""
        action = diagnosis.get("fix_action", "")
        local_path = diagnosis.get("local_path", "")
        project = diagnosis.get("project", "")

        if not local_path:
            local_path = self._find_path(project)
        if not local_path or not os.path.isdir(local_path):
            return {"success": False, "project": project, "reason": "no local path"}

        result = {"success": False, "project": project, "action": action,
                  "changed_files": False, "detail": ""}

        # Snapshot git state first
        pre_status = _run(["git", "status", "--porcelain"], cwd=local_path)
        pre_dirty = pre_status.get("stdout", "")

        if action == "run_flutter_pub_get":
            r = _run(["flutter", "pub", "get"], cwd=local_path, timeout=120)
            result["success"] = r["ok"]
            result["detail"] = "flutter pub get " + ("succeeded" if r["ok"] else f"failed: {r['stderr'][:100]}")

        elif action == "run_flutter_analyze_fix":
            # Try dart fix first
            _run(["dart", "fix", "--apply"], cwd=local_path, timeout=60)
            # Then check
            r = _run(["flutter", "analyze", "--no-fatal-infos", "lib/"], cwd=local_path, timeout=60)
            result["success"] = r["ok"]
            result["detail"] = "dart fix applied, analyze " + ("passing" if r["ok"] else "still has issues")

        elif action == "run_npm_install":
            r = _run(["npm", "install"], cwd=local_path, timeout=120)
            result["success"] = r["ok"]
            result["detail"] = "npm install " + ("succeeded" if r["ok"] else f"failed: {r['stderr'][:100]}")

        elif action == "run_npm_lint_fix":
            r = _run(["npm", "run", "lint:fix"], cwd=local_path, timeout=60)
            if not r["ok"]:
                r = _run(["npx", "eslint", "--fix", "."], cwd=local_path, timeout=60)
            result["success"] = r["ok"]
            result["detail"] = "lint fix " + ("applied" if r["ok"] else "failed")

        # Check if files changed
        post_status = _run(["git", "status", "--porcelain"], cwd=local_path)
        post_dirty = post_status.get("stdout", "")
        if post_dirty != pre_dirty:
            result["changed_files"] = True

        self._actions_taken.append(result)
        return result

    # ── Git: commit + branch + PR prep ──────────────────────────────────

    def _prepare_commit(self, diagnosis: dict, fix: dict) -> dict | None:
        """After a fix, create a branch, commit, and prepare PR text.
        Does NOT push — that's Tier 3 (needs Dean's approval)."""
        project = diagnosis.get("project", "")
        local_path = diagnosis.get("local_path") or self._find_path(project)
        if not local_path:
            return None

        branch_name = f"leon/auto-fix-{int(time.time())}"
        commit_msg = f"fix: {diagnosis.get('cause', 'auto-fix by Leon')}"

        # Create branch
        r = _run(["git", "checkout", "-b", branch_name], cwd=local_path)
        if not r["ok"]:
            # Already on a non-main branch? Just commit there
            branch_r = _run(["git", "branch", "--show-current"], cwd=local_path)
            branch_name = branch_r.get("stdout", "unknown")

        # Stage only tracked changed files — never stage .env or secrets
        r = _run(["git", "diff", "--name-only"], cwd=local_path)
        if r["ok"] and r["stdout"]:
            safe_files = [f for f in r["stdout"].splitlines()
                          if not f.startswith(".env") and "secret" not in f.lower()
                          and "credential" not in f.lower()]
            for f in safe_files:
                _run(["git", "add", f], cwd=local_path)

        # Commit
        r = _run(["git", "commit", "-m", commit_msg], cwd=local_path)
        if not r["ok"]:
            return None

        pr_body = f"""## Auto-fix by Leon

**Project:** {project}
**Diagnosis:** {diagnosis.get('cause', 'unknown')}
**Fix applied:** {fix.get('detail', 'unknown')}

This fix was automatically applied by Leon's autopilot.
Pushed for review — Leon does not merge without approval.
"""
        return {
            "project": project,
            "branch": branch_name,
            "commit_msg": commit_msg,
            "pr_body": pr_body,
            "local_path": local_path,
            "ready_to_push": True,
        }

    # ── Terminal resurrection ───────────────────────────────────────────

    def _resurrect_terminal(self, terminal: dict) -> dict | None:
        """Check what a stuck terminal needs and try to continue it."""
        name = terminal.get("name", "")
        idle_min = terminal.get("idle_min", 0)

        if idle_min < 30:
            return None  # not stuck enough

        # Capture what's on screen
        r = _run(["tmux", "capture-pane", "-t", f"agents:{name}", "-p", "-S", "-20"])
        if not r["ok"]:
            return None

        screen = r["stdout"]
        action = {"terminal": name, "idle_min": idle_min, "action": "none", "detail": ""}

        lower = screen.lower()
        last_lines = screen.strip().splitlines()[-3:] if screen.strip() else []
        last_line = last_lines[-1] if last_lines else ""

        # Detect state and act
        if "y/n" in lower or "[y/n]" in lower or "(yes/no)" in lower:
            # Terminal is waiting for confirmation — DON'T auto-answer
            action["action"] = "needs_input"
            action["detail"] = f"Waiting for yes/no confirmation: {last_line.strip()}"

        elif "error" in lower and ("$" in last_line or ">" in last_line):
            # Error happened but shell is back — report it
            action["action"] = "error_at_prompt"
            # Find the error line
            for line in reversed(screen.splitlines()):
                if "error" in line.lower():
                    action["detail"] = f"Error occurred: {line.strip()[:100]}"
                    break

        elif last_line.strip().endswith("$") or last_line.strip().endswith(">"):
            # At a shell prompt — terminal is just sitting there
            action["action"] = "idle_at_prompt"
            action["detail"] = f"Shell idle for {idle_min}min"

        elif "permission denied" in lower:
            action["action"] = "permission_error"
            action["detail"] = "Permission denied — needs Dean"

        elif any(x in lower for x in ["compiling", "building", "downloading", "installing"]):
            action["action"] = "still_working"
            action["detail"] = "Process still running (compiling/building)"

        else:
            action["action"] = "unknown_state"
            action["detail"] = f"Last line: {last_line.strip()[:80]}"

        return action

    # ── Proactive advancement — ACTUALLY DO THE WORK ───────────────────

    def _try_advance(self, project: dict) -> list[dict]:
        """Find things to advance and DO them, not just report."""
        advancements = []
        name = project["name"]
        local_path = self._find_path(name)

        if not local_path:
            return advancements

        # Skip if we just pushed/updated this project (cooldown: 30 min)
        now = time.time()
        if now - self._last_push_cache.get(name, 0) < 1800:
            return advancements

        # What branch are we on?
        branch_r = _run(["git", "branch", "--show-current"], cwd=local_path)
        branch = branch_r.get("stdout", "unknown")
        is_main = branch in ("main", "master")

        # ── Push unpushed commits ───────────────────────────────────
        r = _run(["git", "log", "--oneline", "@{u}..HEAD"], cwd=local_path)
        if r["ok"] and r["stdout"]:
            commits_ahead = len(r["stdout"].splitlines())
            remote_r = _run(["git", "remote", "get-url", "origin"], cwd=local_path)
            if remote_r["ok"]:
                # Pull first to avoid rejected pushes
                pull_r = _run(["git", "pull", "--rebase", "origin", branch], cwd=local_path, timeout=60)
                if not pull_r["ok"] and "conflict" in (pull_r["stdout"] + pull_r["stderr"]).lower():
                    # Try to auto-resolve lockfile conflicts
                    resolved = self._auto_resolve_conflict(local_path)
                    if resolved:
                        advancements.append({
                            "project": name, "type": "conflict_resolved",
                            "detail": f"Auto-resolved lockfile conflict on '{branch}'",
                            "acted": True,
                        })
                    else:
                        _run(["git", "rebase", "--abort"], cwd=local_path)
                        advancements.append({
                            "project": name, "type": "push_conflict",
                            "detail": f"Merge conflict on '{branch}' — needs manual resolution",
                            "acted": False,
                        })
                        # Skip push below
                        return advancements
                else:
                    push_r = _run(["git", "push", "origin", branch], cwd=local_path, timeout=60)
                    if push_r["ok"]:
                        self._last_push_cache[name] = time.time()
                        advancements.append({
                            "project": name, "type": "pushed",
                            "detail": f"Pulled + pushed {commits_ahead} commit(s) on '{branch}'",
                            "acted": True,
                        })
                    else:
                        advancements.append({
                            "project": name, "type": "push_failed",
                            "detail": f"Push failed: {push_r['stderr'][:100]}",
                            "acted": False,
                        })

        # ── Update outdated dependencies ────────────────────────────
        # Only check deps once per hour per project
        if now - self._last_dep_update.get(name, 0) >= 3600:
            has_pubspec = os.path.exists(os.path.join(local_path, "pubspec.yaml"))
            has_package = os.path.exists(os.path.join(local_path, "package.json"))

            if has_pubspec:
                adv = self._update_flutter_deps(name, local_path, branch)
                if adv:
                    advancements.append(adv)
                self._last_dep_update[name] = time.time()
            elif has_package:
                adv = self._update_npm_deps(name, local_path, branch)
                if adv:
                    advancements.append(adv)
                self._last_dep_update[name] = time.time()

        return advancements

    def _auto_resolve_conflict(self, local_path: str) -> bool:
        """Try to auto-resolve lockfile conflicts (package-lock.json, pubspec.lock).
        These are safe to regenerate — they're derived from the manifest files.
        Returns True if resolved and rebase continued successfully."""
        # Check which files are conflicted
        r = _run(["git", "diff", "--name-only", "--diff-filter=U"], cwd=local_path)
        if not r["ok"]:
            return False
        conflicted = r["stdout"].strip().splitlines()

        # Only auto-resolve if ALL conflicts are lockfiles
        lockfiles = {"package-lock.json", "pubspec.lock", "pnpm-lock.yaml", "yarn.lock"}
        if not conflicted or not all(f.strip() in lockfiles for f in conflicted):
            return False

        # Resolve each lockfile by regenerating it
        for f in conflicted:
            f = f.strip()
            if f == "package-lock.json":
                # Accept theirs then regenerate with npm install
                _run(["git", "checkout", "--theirs", f], cwd=local_path)
                has_legacy = os.path.exists(os.path.join(local_path, "node_modules", ".package-lock.json"))
                cmd = ["npm", "install"]
                if has_legacy:
                    cmd.append("--legacy-peer-deps")
                install_r = _run(cmd, cwd=local_path, timeout=120)
                if not install_r["ok"]:
                    # Try with legacy-peer-deps as fallback
                    _run(["npm", "install", "--legacy-peer-deps"], cwd=local_path, timeout=120)
            elif f == "pubspec.lock":
                _run(["git", "checkout", "--theirs", f], cwd=local_path)
                _run(["flutter", "pub", "get"], cwd=local_path, timeout=120)
            elif f in ("pnpm-lock.yaml", "yarn.lock"):
                _run(["git", "checkout", "--theirs", f], cwd=local_path)

            _run(["git", "add", f], cwd=local_path)

        # Continue the rebase
        import subprocess as _sp
        env = os.environ.copy()
        env["GIT_EDITOR"] = "true"
        try:
            _sp.run(["git", "rebase", "--continue"], cwd=local_path,
                     capture_output=True, text=True, timeout=30, env=env)
        except Exception:
            return False

        # Verify we're no longer in rebase state
        r2 = _run(["git", "status"], cwd=local_path)
        if "rebase" in r2["stdout"].lower():
            return False
        return True

    def _update_npm_deps(self, name: str, local_path: str, branch: str) -> dict | None:
        """Run npm update, commit, and push if there are changes."""
        # Check what's outdated first
        r = _run(["npm", "outdated", "--json"], cwd=local_path, timeout=30)
        if not r["stdout"] or r["stdout"].strip() == "{}":
            return None
        try:
            outdated = json.loads(r["stdout"])
            if not outdated:
                return None
            count = len(outdated)
        except json.JSONDecodeError:
            return None

        # Snapshot git state
        pre = _run(["git", "status", "--porcelain"], cwd=local_path).get("stdout", "")

        # Run npm update — try normal first, fall back to --legacy-peer-deps
        update_r = _run(["npm", "update"], cwd=local_path, timeout=120)
        if not update_r["ok"]:
            # ERESOLVE = peer dep conflict, retry with legacy flag
            if "ERESOLVE" in update_r["stderr"]:
                update_r = _run(["npm", "update", "--legacy-peer-deps"], cwd=local_path, timeout=120)
            if not update_r["ok"]:
                return {"project": name, "type": "dep_update_failed",
                        "detail": f"npm update failed: {update_r['stderr'][:100]}", "acted": False}

        # Check if anything changed
        post = _run(["git", "status", "--porcelain"], cwd=local_path).get("stdout", "")
        if post == pre:
            return None  # nothing actually changed

        changed_files = len(post.strip().splitlines()) - len(pre.strip().splitlines()) if pre else len(post.strip().splitlines())

        # Commit the changes
        _run(["git", "add", "package.json", "package-lock.json"], cwd=local_path)
        commit_r = _run(["git", "commit", "-m", f"chore: update {count} npm dependencies\n\nAutomated by Leon autopilot"],
                         cwd=local_path)
        if not commit_r["ok"]:
            return {"project": name, "type": "dep_update_uncommitted",
                    "detail": f"Updated {count} deps but commit failed: {commit_r['stderr'][:80]}", "acted": True}

        # Push
        remote_r = _run(["git", "remote", "get-url", "origin"], cwd=local_path)
        if remote_r["ok"]:
            push_r = _run(["git", "push", "origin", branch], cwd=local_path, timeout=60)
            if push_r["ok"]:
                return {"project": name, "type": "deps_updated_pushed",
                        "detail": f"Updated {count} npm deps, committed and pushed on '{branch}'",
                        "acted": True}
            else:
                return {"project": name, "type": "deps_updated_local",
                        "detail": f"Updated {count} npm deps and committed locally, push failed: {push_r['stderr'][:80]}",
                        "acted": True}

        return {"project": name, "type": "deps_updated_local",
                "detail": f"Updated {count} npm deps and committed locally (no remote)",
                "acted": True}

    def _update_flutter_deps(self, name: str, local_path: str, branch: str) -> dict | None:
        """Run flutter pub upgrade, commit, and push if there are changes."""
        # Check outdated
        r = _run(["flutter", "pub", "outdated", "--no-color"], cwd=local_path, timeout=60)
        if not r["ok"] or "newer versions" not in r["stdout"].lower():
            return None

        pre = _run(["git", "status", "--porcelain"], cwd=local_path).get("stdout", "")

        # Upgrade
        upgrade_r = _run(["flutter", "pub", "upgrade"], cwd=local_path, timeout=120)
        if not upgrade_r["ok"]:
            return {"project": name, "type": "dep_update_failed",
                    "detail": f"flutter pub upgrade failed: {upgrade_r['stderr'][:100]}", "acted": False}

        post = _run(["git", "status", "--porcelain"], cwd=local_path).get("stdout", "")
        if post == pre:
            return None

        # Commit
        _run(["git", "add", "pubspec.lock"], cwd=local_path)
        commit_r = _run(["git", "commit", "-m", "chore: upgrade Flutter dependencies\n\nAutomated by Leon autopilot"],
                         cwd=local_path)
        if not commit_r["ok"]:
            return {"project": name, "type": "dep_update_uncommitted",
                    "detail": "Upgraded Flutter deps but commit failed", "acted": True}

        # Push
        remote_r = _run(["git", "remote", "get-url", "origin"], cwd=local_path)
        if remote_r["ok"]:
            push_r = _run(["git", "push", "origin", branch], cwd=local_path, timeout=60)
            if push_r["ok"]:
                return {"project": name, "type": "deps_updated_pushed",
                        "detail": f"Upgraded Flutter deps, committed and pushed on '{branch}'",
                        "acted": True}

        return {"project": name, "type": "deps_updated_local",
                "detail": "Upgraded Flutter deps and committed locally",
                "acted": True}

    # ── Memory: write to Leon's knowledge store ───────────────────────

    def _remember(self, result: dict):
        """Write operator actions to Leon's knowledge store.
        ONLY write meaningful actions — not routine checks or terminal noise."""
        if not self._knowledge:
            return
        lines = []
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")

        for fix in result.get("fixed", []):
            lines.append(f"[{ts}] Leon auto-fixed {fix['project']}: {fix['detail']}")
        for pr in result.get("pr_prepared", []):
            lines.append(f"[{ts}] Leon prepared PR for {pr['project']} on branch {pr['branch']}")
        for adv in result.get("advanced", []):
            if adv.get("acted"):
                lines.append(f"[{ts}] Leon {adv['type'].replace('_',' ')} for {adv['project']}: {adv['detail']}")
        # Skip terminal checks and setup-needed — those are noise

        if not lines:
            return  # nothing meaningful happened this tick

        text = "Leon autopilot activity:\n" + "\n".join(lines)
        try:
            self._knowledge.store(
                text=text,
                source="leon_autopilot",
                tags=["autopilot", "operator", "activity"],
                metadata={"type": "autopilot_activity", "timestamp": ts},
            )
        except Exception as e:
            log.error("Failed to store autopilot memory: %s", e)

    # ── Output formatting ───────────────────────────────────────────────

    def _build_summary(self, result: dict) -> str:
        lines = []
        for fix in result.get("fixed", []):
            lines.append(f"FIXED: {fix['project']} — {fix['detail']}")
        for pr in result.get("pr_prepared", []):
            lines.append(f"PR READY: {pr['project']} on branch {pr['branch']} — awaiting push approval")
        for ta in result.get("terminal_actions", []):
            if ta["action"] != "none":
                icon = {"needs_input": "WAITING", "error_at_prompt": "ERROR",
                        "idle_at_prompt": "IDLE", "still_working": "WORKING",
                        "permission_error": "BLOCKED"}.get(ta["action"], "INFO")
                lines.append(f"TERMINAL {icon}: {ta['terminal']} — {ta['detail']}")
        for adv in result.get("advanced", []):
            if adv.get("acted"):
                lines.append(f"DONE: {adv['project']} — {adv['detail']}")
            else:
                lines.append(f"ADVANCE: {adv['project']} — {adv['detail']}")
        for need in result.get("needs_dean", []):
            if need.get("instructions"):
                lines.append(f"SETUP: {need['project']} — {need['issue']}")
                for inst in need["instructions"][:2]:
                    lines.append(f"  → {inst[:100]}")
            else:
                lines.append(f"NEEDS YOU: {need['project']} — {need['issue']}")
        return "\n".join(lines)

    def _build_voice(self, result: dict) -> list[str]:
        parts = []
        if result["fixed"]:
            names = [f["project"] for f in result["fixed"]]
            parts.append(f"fixed {', '.join(names)}")
        if result["pr_prepared"]:
            parts.append(f"{len(result['pr_prepared'])} fixes ready to push when you approve")

        # Report what we actually did
        acted = [a for a in result["advanced"] if a.get("acted")]
        pushed = [a for a in acted if a["type"] == "pushed"]
        deps_done = [a for a in acted if "deps_updated" in a["type"]]
        push_failed = [a for a in acted if a["type"] == "push_failed"]

        if pushed:
            names = [a["project"] for a in pushed]
            parts.append(f"pushed commits for {', '.join(names)}")
        if deps_done:
            names = [a["project"] for a in deps_done]
            parts.append(f"updated dependencies for {', '.join(names)}")
        if push_failed:
            names = [a["project"] for a in push_failed]
            parts.append(f"push failed for {', '.join(names)}")

        terminals_needing_attention = [t for t in result["terminal_actions"]
                                        if t and t.get("action") in ("needs_input", "error_at_prompt")]
        if terminals_needing_attention:
            names = [t["terminal"] for t in terminals_needing_attention]
            parts.append(f"terminals needing attention: {', '.join(names)}")
        if not parts:
            return []
        return ["Sir. " + ". ".join(parts) + "."]

    def _surface(self, result: dict):
        """Queue operator results for Leon's unified consciousness."""
        summary = result.get("summary_text", "")
        voice_lines = result.get("voice_lines", [])
        if not summary and not voice_lines:
            return
        if self._consciousness:
            self._consciousness.observe(
                source="operator",
                summary=voice_lines[0] if voice_lines else summary.split("\n")[0],
                detail=summary,
                urgency="medium",
            )
