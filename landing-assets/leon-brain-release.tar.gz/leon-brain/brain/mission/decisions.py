"""
Decision Registry — persistent product/engineering decision tracking.

Tracks unresolved decisions, surfaces blockers, remembers approvals,
connects decisions to projects/features.

Persists in brain_state/projects.db.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
import uuid
from typing import Any, Optional

log = logging.getLogger("leon.mission.decisions")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions (
    id              TEXT PRIMARY KEY,
    project_id      TEXT,                   -- NULL = cross-project
    title           TEXT NOT NULL,
    description     TEXT DEFAULT '',
    category        TEXT DEFAULT 'general',  -- product|engineering|monetization|ops|legal
    status          TEXT NOT NULL DEFAULT 'open',  -- open|decided|deferred|superseded
    decision        TEXT DEFAULT '',          -- the actual decision made
    rationale       TEXT DEFAULT '',
    decided_by      TEXT DEFAULT '',
    decided_at      REAL,
    alternatives    TEXT DEFAULT '[]',        -- JSON array of considered alternatives
    blockers        TEXT DEFAULT '[]',        -- JSON array of what this blocks
    blocked_by      TEXT DEFAULT '[]',        -- what blocks this decision
    tags            TEXT DEFAULT '[]',
    linked_decisions TEXT DEFAULT '[]',       -- JSON array of related decision IDs
    created_at      REAL NOT NULL,
    updated_at      REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS decision_comments (
    id          TEXT PRIMARY KEY,
    decision_id TEXT NOT NULL REFERENCES decisions(id),
    author      TEXT DEFAULT 'leon',
    content     TEXT NOT NULL,
    created_at  REAL NOT NULL
);
"""

_JSON_FIELDS = {"alternatives", "blockers", "blocked_by", "tags", "linked_decisions"}

# Columns a caller may set via update(). The key `k` is interpolated straight
# into the SET clause, so it MUST come from this allowlist — never from raw
# request JSON — or a crafted key injects SQL. (id/created_at/updated_at are
# managed internally and intentionally excluded.)
_UPDATABLE_FIELDS = _JSON_FIELDS | {
    "project_id", "title", "description", "category", "status",
    "decision", "rationale", "decided_by", "decided_at",
}


def _decode_row(row: sqlite3.Row) -> dict:
    d = dict(row)
    for f in _JSON_FIELDS:
        if f in d and isinstance(d[f], str):
            try:
                d[f] = json.loads(d[f])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


class DecisionRegistry:
    def __init__(self, db_path: str | None = None):
        self.db_path = os.path.abspath(db_path or DB_PATH)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        log.info("DecisionRegistry ready")

    # ── CRUD ────────────────────────────────────────────────────────────

    def create(self, title: str, project_id: str | None = None, **kwargs) -> dict:
        did = uuid.uuid4().hex[:12]
        now = time.time()
        fields = {"id": did, "title": title, "project_id": project_id,
                  "created_at": now, "updated_at": now}
        for k, v in kwargs.items():
            if k in _JSON_FIELDS:
                fields[k] = json.dumps(v) if not isinstance(v, str) else v
            elif k in ("description", "category", "status", "decision", "rationale", "decided_by"):
                fields[k] = v
        cols = ", ".join(fields.keys())
        placeholders = ", ".join(["?"] * len(fields))
        self._conn.execute(f"INSERT INTO decisions ({cols}) VALUES ({placeholders})", list(fields.values()))
        self._conn.commit()
        return self.get(did)

    def get(self, decision_id: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM decisions WHERE id = ?", (decision_id,)).fetchone()
        if not row:
            return None
        d = _decode_row(row)
        d["comments"] = self._get_comments(decision_id)
        return d

    def list_all(self, project_id: str | None = None, status: str | None = None) -> list[dict]:
        q = "SELECT * FROM decisions WHERE 1=1"
        params: list = []
        if project_id:
            q += " AND project_id = ?"
            params.append(project_id)
        if status:
            q += " AND status = ?"
            params.append(status)
        q += " ORDER BY updated_at DESC"
        return [_decode_row(r) for r in self._conn.execute(q, params).fetchall()]

    def update(self, decision_id: str, **kwargs) -> dict | None:
        d = self.get(decision_id)
        if not d:
            return None
        sets = []
        vals = []
        for k, v in kwargs.items():
            if k not in _UPDATABLE_FIELDS:
                continue  # ignore unknown/crafted keys — k is interpolated into the SQL
            if k in _JSON_FIELDS:
                sets.append(f"{k} = ?")
                vals.append(json.dumps(v) if not isinstance(v, str) else v)
            else:
                sets.append(f"{k} = ?")
                vals.append(v)
        if "status" in kwargs and kwargs["status"] == "decided" and "decided_at" not in kwargs:
            sets.append("decided_at = ?")
            vals.append(time.time())
        sets.append("updated_at = ?")
        vals.append(time.time())
        vals.append(decision_id)
        self._conn.execute(f"UPDATE decisions SET {', '.join(sets)} WHERE id = ?", vals)
        self._conn.commit()
        return self.get(decision_id)

    def decide(self, decision_id: str, decision: str, rationale: str = "",
               decided_by: str = "Dean") -> dict | None:
        return self.update(decision_id, status="decided", decision=decision,
                          rationale=rationale, decided_by=decided_by)

    def delete(self, decision_id: str) -> bool:
        cur = self._conn.execute("DELETE FROM decisions WHERE id = ?", (decision_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ── Comments ────────────────────────────────────────────────────────

    def add_comment(self, decision_id: str, content: str, author: str = "leon") -> dict:
        cid = uuid.uuid4().hex[:12]
        now = time.time()
        self._conn.execute(
            "INSERT INTO decision_comments (id, decision_id, author, content, created_at) VALUES (?,?,?,?,?)",
            (cid, decision_id, author, content, now),
        )
        self._conn.execute("UPDATE decisions SET updated_at = ? WHERE id = ?", (now, decision_id))
        self._conn.commit()
        return {"id": cid, "author": author, "content": content, "created_at": now}

    def _get_comments(self, decision_id: str) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM decision_comments WHERE decision_id = ? ORDER BY created_at",
            (decision_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Summary ─────────────────────────────────────────────────────────

    def summary(self) -> dict:
        all_d = self.list_all()
        by_status: dict[str, int] = {}
        by_category: dict[str, int] = {}
        open_decisions = []
        for d in all_d:
            s = d["status"]
            by_status[s] = by_status.get(s, 0) + 1
            c = d.get("category", "general")
            by_category[c] = by_category.get(c, 0) + 1
            if s == "open":
                open_decisions.append({
                    "id": d["id"], "title": d["title"],
                    "project_id": d.get("project_id"),
                    "category": d.get("category"),
                    "created_at": d["created_at"],
                })
        return {
            "total": len(all_d),
            "by_status": by_status,
            "by_category": by_category,
            "open_count": len(open_decisions),
            "open_decisions": open_decisions,
        }
