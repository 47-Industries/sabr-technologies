"""
Shared resources for the mission package.

Fixes:
- 6 modules each opening separate SQLite connections to projects.db
- 5 modules each parsing forever-sessions.json independently
- Unclosed connections in one-off functions

All mission modules should import from here instead of creating their own.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
from typing import Any, Optional

log = logging.getLogger("leon.mission.shared")

_STATE_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state")
DB_PATH = os.path.abspath(os.path.join(_STATE_DIR, "projects.db"))

# ── Shared DB connection (thread-safe via WAL + serialized writes) ──────

_db_conn: Optional[sqlite3.Connection] = None
_db_lock = threading.Lock()


def get_db() -> sqlite3.Connection:
    """Get the shared projects.db connection. Thread-safe."""
    global _db_conn
    with _db_lock:
        if _db_conn is None:
            os.makedirs(_STATE_DIR, exist_ok=True)
            _db_conn = sqlite3.connect(DB_PATH, check_same_thread=False)
            _db_conn.row_factory = sqlite3.Row
            _db_conn.execute("PRAGMA journal_mode=WAL")
            _db_conn.execute("PRAGMA busy_timeout=5000")
            log.info("Shared DB connection opened: %s", DB_PATH)
        return _db_conn


# ── Shared forever-sessions.json (loaded once, cached) ──────────────────

_sessions_cache: Optional[dict] = None
_sessions_mtime: float = 0.0
_sessions_lock = threading.Lock()
_SESSIONS_PATH = os.path.expanduser("~/.openclaw/forever-sessions.json")


def get_project_paths() -> dict[str, str]:
    """Get {window_name: local_path} from forever-sessions.json. Cached."""
    global _sessions_cache, _sessions_mtime
    with _sessions_lock:
        try:
            mtime = os.path.getmtime(_SESSIONS_PATH) if os.path.exists(_SESSIONS_PATH) else 0
            if _sessions_cache is not None and mtime == _sessions_mtime:
                return _sessions_cache
            with open(_SESSIONS_PATH) as f:
                data = json.load(f)
            result = {}
            for s in data.get("forever", []):
                wn = s.get("windowName", "")
                path = s.get("path", "")
                if wn and path:
                    result[wn] = path
            _sessions_cache = result
            _sessions_mtime = mtime
            return result
        except Exception:
            return _sessions_cache or {}


def find_project_path(project_name: str) -> str | None:
    """Find local path for a project by name. Uses shared cache."""
    paths = get_project_paths()
    slug = project_name.lower().replace(" ", "-")
    # Exact match
    if slug in paths:
        p = paths[slug]
        if os.path.isdir(p):
            return p
    # Partial match (>4 chars to avoid false matches)
    if len(slug) > 4:
        for wn, path in paths.items():
            if slug in wn or wn in slug:
                if os.path.isdir(path):
                    return path
    return None
