"""
Leon's unified consciousness — ONE voice, ONE mind.

The problem: autopilot, fixer, operator, morning briefing, daily report
all independently pushed brain_response_start to the dashboard. That's
5 different "Leons" talking over each other.

The fix: everything feeds into ONE context queue. Only the Claude session
speaks. Background systems write observations, the Claude session reads
them and speaks as ONE Leon.

If Dean hasn't talked to Leon and something urgent is waiting, Leon
initiates a proactive message — but still through his ONE Claude voice.

This module is the single point of coordination.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Callable, Optional

log = logging.getLogger("leon.consciousness")


@dataclass
class Observation:
    """Something Leon noticed that he should mention next time he speaks."""
    source: str          # "autopilot", "fixer", "operator", "morning", "daily", "github"
    urgency: str         # "low", "medium", "high", "critical"
    summary: str         # one-line for voice
    detail: str          # multi-line for dashboard
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


class Consciousness:
    """Leon's unified awareness. All background systems write here.
    Only the Claude session reads and speaks."""

    def __init__(self, broadcast: Callable | None = None,
                 tts_say: Callable | None = None,
                 responder=None):
        self._queue: deque[Observation] = deque(maxlen=50)
        self._lock = threading.Lock()
        self._broadcast = broadcast
        self._tts_say = tts_say
        self._responder = responder
        self._last_spoke: float = time.time()
        self._proactive_interval = 300  # 5 min — if queue has urgent items, speak up
        self._proactive_thread: threading.Thread | None = None
        self._running = False
        log.info("Consciousness initialized — one voice, one mind")

    def start(self):
        """Start the proactive awareness thread."""
        if self._running:
            return
        self._running = True
        self._proactive_thread = threading.Thread(
            target=self._proactive_loop, daemon=True, name="consciousness")
        self._proactive_thread.start()

    def stop(self):
        self._running = False

    # ── Background systems write here ───────────────────────────────────

    def observe(self, source: str, summary: str, detail: str = "",
                urgency: str = "medium"):
        """Called by autopilot/fixer/operator/morning/daily to report findings.
        Does NOT broadcast anything. Just queues it for Leon's next response."""
        if not summary:
            return
        obs = Observation(source=source, urgency=urgency,
                          summary=summary, detail=detail or summary)
        with self._lock:
            self._queue.append(obs)
        log.debug("Observation queued: [%s] %s", source, summary[:60])

    # ── Claude session reads here ───────────────────────────────────────

    def get_pending_context(self, max_items: int = 10) -> str:
        """Called by the responder before generating a response.
        Returns a string to inject into Leon's prompt so he naturally
        mentions what he noticed. Returns empty string if nothing pending."""
        with self._lock:
            if not self._queue:
                return ""
            items = []
            while self._queue and len(items) < max_items:
                items.append(self._queue.popleft())

        lines = ["[LEON INTERNAL AWARENESS — mention these naturally in your response, don't read them verbatim]"]
        for obs in items:
            lines.append(f"- ({obs.source}) {obs.summary}")
        return "\n".join(lines)

    def has_pending(self) -> bool:
        with self._lock:
            return len(self._queue) > 0

    def has_urgent(self) -> bool:
        with self._lock:
            return any(o.urgency in ("high", "critical") for o in self._queue)

    def pending_count(self) -> int:
        with self._lock:
            return len(self._queue)

    def peek(self) -> list[dict]:
        """View pending observations without consuming them."""
        with self._lock:
            return [asdict(o) for o in self._queue]

    # ── Proactive speaking ──────────────────────────────────────────────

    def mark_spoke(self):
        """Called after Leon generates a response (voice or text)."""
        self._last_spoke = time.time()

    def _proactive_loop(self):
        """If Leon hasn't spoken and has observations, speak up.
        HIGH urgency = speak after 30s. Normal = speak after 5 min."""
        while self._running:
            try:
                time.sleep(15)  # check every 15s
                idle_s = time.time() - self._last_spoke
                if not self.has_pending():
                    continue

                # HIGH urgency items get spoken quickly (30s idle)
                # Normal items wait the full interval (5 min)
                if self.has_urgent() and idle_s >= 30:
                    self._initiate_proactive_message()
                elif idle_s >= self._proactive_interval:
                    self._initiate_proactive_message()

            except Exception as e:
                log.error("Consciousness loop error: %s", e)

    def _initiate_proactive_message(self):
        """Make Leon speak proactively — through the Claude session,
        not as a raw broadcast. This is the ONE voice."""
        # Only speak when conscious — observations queue until then
        try:
            import server as _srv_cc
            _brain_cc = getattr(_srv_cc, "brain", None)
            _meter_cc = getattr(_brain_cc, "consciousness_meter", None) if _brain_cc else None
            if _meter_cc is not None and not _meter_cc.is_conscious:
                return  # observations stay queued, will try again in 15s
        except Exception:
            pass  # if we can't check, proceed anyway

        context = self.get_pending_context()
        if not context:
            return

        # Unified broadcast gate — prevent double responses
        try:
            from server.helpers import _RESPONSE_BROADCAST_LOCK, _last_response_broadcast_ts
            from server.helpers import _RESPONSE_MIN_GAP_S, _RESPONSE_CONVERSATION_COOLDOWN_S
            import time as _t_gate
            _now_gate = _t_gate.time()
            with _RESPONSE_BROADCAST_LOCK:
                if _now_gate - _last_response_broadcast_ts < _RESPONSE_MIN_GAP_S:
                    return  # another system broadcast recently
                import server as _srv_gate
                _brain_gate = getattr(_srv_gate, "brain", None)
                _meter_gate = getattr(_brain_gate, "consciousness_meter", None) if _brain_gate else None
                if _meter_gate is not None:
                    since_user = _now_gate - _meter_gate._last_user_message_ts
                    if since_user < _RESPONSE_CONVERSATION_COOLDOWN_S:
                        return  # Dean spoke recently
        except Exception:
            pass  # if gate check fails, proceed anyway

        # Use the responder to generate a real Leon response
        if self._responder and hasattr(self._responder, 'respond_streaming'):
            try:
                # Synthesize a prompt that makes Leon speak about his observations
                prompt = "You have some observations from your background monitoring. Share them with Dean naturally."

                # Build a preamble that includes the observations
                state = {}
                try:
                    import server as _srv
                    if hasattr(_srv, 'brain') and _srv.brain:
                        state = _srv.brain.get_state()
                except Exception:
                    pass

                full_text = ""
                response_id = f"proactive_{int(time.time()*1000)}"

                # Mark broadcast timestamp so other systems respect the gap
                try:
                    import server.helpers as _sh
                    _sh._last_response_broadcast_ts = time.time()
                except Exception:
                    pass

                # Broadcast start
                if self._broadcast:
                    self._broadcast({
                        "type": "brain_response_start",
                        "user": "[Leon noticed something]",
                        "response_id": response_id,
                        "from_voice": False,
                        "from_proactive": True,
                    })

                # Acquire responder lock so we don't interleave with user turns
                import server as _srv_lock
                _rlock = getattr(_srv_lock, "_responder_lock", None)
                _got = _rlock.acquire(blocking=False) if _rlock else False

                try:
                    # Stream the response (no history pollution from proactive)
                    # bypass_consciousness=True — this module already
                    # decided Leon is conscious enough to speak; don't
                    # let the gate re-check and output "*blinks*" spam.
                    for ev in self._responder.respond_streaming(
                        prompt, state, persist_history=False,
                        bypass_consciousness=True,
                    ):
                        if ev.type == "delta" and ev.text:
                            full_text += ev.text
                            if self._broadcast:
                                self._broadcast({
                                    "type": "brain_response_delta",
                                    "response_id": response_id,
                                    "text": ev.text,
                                })
                        elif ev.type == "sentence" and ev.text:
                            # TTS per sentence for natural speech pacing
                            if self._tts_say:
                                try:
                                    from datetime import datetime as _dt
                                    if 8 <= _dt.now().hour <= 22:
                                        audio = self._tts_say(ev.text)
                                        if audio and self._broadcast:
                                            self._broadcast({
                                                "type": "brain_audio",
                                                "response_id": response_id,
                                                "sentence_index": getattr(ev, "index", 0),
                                                **audio,
                                            })
                                except Exception:
                                    pass
                        elif ev.type == "done":
                            full_text = ev.full_text or full_text
                            break
                        elif ev.type == "error":
                            log.warning("Proactive stream error: %s", ev.error)
                            break
                finally:
                    if _got and _rlock:
                        try:
                            _rlock.release()
                        except RuntimeError:
                            pass

                if self._broadcast:
                    self._broadcast({
                        "type": "brain_response_end",
                        "response_id": response_id,
                        "response": full_text,
                    })

                # TTS now happens per-sentence inside the stream loop above

                self.mark_spoke()
                log.info("Proactive message delivered: %s", full_text[:80])

                # Persist to episodic memory so Leon remembers
                try:
                    _store = getattr(self._responder, "_conversation_store", None)
                    if _store is not None and full_text:
                        _store.append("user", "[Leon noticed something]", model="proactive")
                        _store.append("assistant", full_text, model="proactive")
                except Exception:
                    pass

            except Exception as e:
                log.error("Proactive message failed: %s", e)
        else:
            # No responder — fall back to unified broadcast gate
            context_text = self.get_pending_context()
            if context_text:
                try:
                    from server.helpers import broadcast_response
                    broadcast_response(context_text, source="consciousness_fallback",
                                       user_label="[Leon]")
                except Exception:
                    pass
                return
            if False and context_text and self._broadcast:
                # DEAD PATH — kept for reference, replaced by broadcast_response above
                response_id = f"fallback_{int(time.time()*1000)}"
                self._broadcast({"type": "brain_response_start",
                                  "user": "[Leon]", "response_id": response_id})
                self._broadcast({"type": "brain_response_delta",
                                  "response_id": response_id, "text": context_text})
                self._broadcast({"type": "brain_response_end",
                                  "response_id": response_id, "full_text": context_text})

    # ── Status ──────────────────────────────────────────────────────────

    def status(self) -> dict:
        return {
            "pending": self.pending_count(),
            "has_urgent": self.has_urgent(),
            "last_spoke_ago_s": round(time.time() - self._last_spoke),
            "proactive_interval_s": self._proactive_interval,
            "running": self._running,
        }
