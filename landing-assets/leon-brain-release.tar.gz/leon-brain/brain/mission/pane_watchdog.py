"""Pane watchdog — decisions 3, 4, 5, 6 and 16 of docs/AUTOLOOP_DECISIONS.md,
turned into code that can actually be run against a pane.

Written 2026-08-02 by Claude, after Leon asked for tests/test_watchdog_live.py
"using the real sampler and the real decision function" and neither existed.
The design here is NOT new — it is the settled record, transcribed. Where the
record was ambiguous it is flagged in a comment rather than resolved quietly.

The shape that makes this testable at all:

    sample()      is PURE — (raw pane text, cpu ticks, pane meta, now) → Sample
    live_sample() does the tmux and /proc I/O, then calls sample()
    observe()     is PURE — (Sample) → Decision

so a synthetic stream and a live pane go through the SAME two functions. A test
that reimplements the decision proves only that the test agrees with itself.

WHAT THIS MODULE CANNOT DO: submit. It reads tmux and /proc and writes rows.
There is no key-injection call anywhere in it and nothing here can press
Enter. The pane is adopt-only throughout, and test_watchdog_live asserts that
structurally by scanning this file's own source for the forbidden tokens —
which is why that sentence is phrased the way it is rather than naming them.
"""
from __future__ import annotations

import hashlib
import math
import os
import re
import subprocess
import time
from dataclasses import dataclass, field, asdict
from typing import Callable, Optional

from brain.mission import escalation

SESSION = os.environ.get("LEON_AGENT_TMUX_SESSION", "agents")

# ── decision 3: the gap thresholds ───────────────────────────────────
# p99 of THIS pane's observed inter-change gaps, clamped. The clamp is what
# stops a pane with three fast samples from arming a 4-second hair trigger,
# and what stops a pane that once took 90 minutes from never alarming again.
GAP_FLOOR_S = 30.0
GAP_CEIL_S = 1200.0          # 20m
NO_HISTORY_GAP_S = 600.0     # 10m flat until this pane has a distribution

# ── decision 16: the CPU discriminator ───────────────────────────────
# Measured on this box 2026-08-02: a working claude pane accrued 311 ticks in
# 3s (~103/s); an idle one accrued 5 (~1.7/s).
#
# A live five-pane run the same night narrowed that, and the narrower number
# is the one to design against: idle panes read 0.33, 1.32 and 5.59 ticks/s,
# and the one working pane read 22.71. So the real separation is 5.6 vs 22.7
# — a factor of four, NOT the order of magnitude the first pair suggested.
# 10/s still sits in the empty middle, but with far less room than claimed,
# and an idle pane repainting heavily is the case that would close it. If a
# false "computing" verdict ever appears, this constant is the first suspect.
CPU_SAMPLES_2026_08_02 = {"idle": (0.33, 1.32, 5.59), "working": (22.71,)}
#
# HONEST LIMIT: utime+stime only. cutime/cstime count reaped children, so a
# long-running child process is NOT counted here. CPU-zero therefore means
# "this process is not computing", not "nothing is happening" — which is
# exactly why CPU alone never escalates, it only vetoes.
CPU_BURN_TICKS_PER_S = 10.0

#: Commands that mean no agent is running in this pane. An ALLOWLIST of
#: known-not-an-agent, so an unrecognised command is WATCHED rather than
#: silently exempted — a denylist here fails toward silence, which is the
#: failure this whole subsystem exists to fix.
SHELL_COMMANDS = {"bash", "sh", "zsh", "fish", "dash", "-bash", "login"}


# ── decision 4: frame normalization ──────────────────────────────────
# Chrome is anything that ticks INDEPENDENTLY OF WORK. If it is hashed with
# the content, a wedged pane with a live spinner never produces a gap and the
# watchdog goes blind in exactly the stuck case.

#: The live spinner: glyph, participle with ellipsis, parenthetical counter.
#:     ✽ Undulating… (2m 9s · ↓ 5.9k tokens)
_SPINNER_RX = re.compile(r"^\s*[✻✢✽◉·*]\s+\S*…\s*\(.*\)\s*$")

#: Per-tool-call timer on the running command line:
#:     tmux capture-pane -p -t agents:home -S -… (4s)
_TOOL_TIMER_RX = re.compile(r"…\s*\(\d+(?:m\s*\d+)?s\)\s*$")

#: Rotating tip rows. They cycle on a timer with no relation to the turn.
_TIP_RX = re.compile(r"^\s*⎿\s+Tip:")
#: A tip wraps onto continuation lines; they carry no glyph, only indentation.
_TIP_CONT_RX = re.compile(r"^\s{4,}\S")

# NOTE FOR LEON — TWO DECISIONS OF RECORD COLLIDE HERE, AND I PICKED ONE.
# Decision 4 lists 'elapsed-time counters ("Churned for 2m 35s")' as chrome to
# strip. Decision 10 — which came later, and came from you catching me — says
# that exact line is a COMPLETED-TURN marker: past tense, painted once, frozen
# thereafter. It does not tick, so decision 4's stated rationale ("ticks
# independently of work") does not apply to it.
# I kept it in CONTENT. Stripping it would make a turn finishing invisible to
# the content clock, which is a state change that matters more than any other.
# If you disagree, this is the line to move, and moving it is one regex.
_FINISHED_RX = re.compile(r"^\s*[✻✢✽◉·*]\s+\w+ for \d+m \d+s\s*$")


#: The input row. It belongs to NEITHER clock.
#: Found 2026-08-03 by measurement, not by reasoning: residue appearing in the
#: prompt box changes content_hash, which resets the gap clock, which flips a
#: pane that has ALREADY escalated as wedged straight back to WORKING. Verified
#: against the captured onset — a wedged pane at gap=50s read `working gap=0`
#: on the next poll because paint arrived in a box the agent never touched.
#: The input row is not agent OUTPUT (so not content) and it does not tick on a
#: timer (so not chrome). It is the human's typing area, and the watchdog must
#: be blind to it in both directions.
_INPUT_ROW_RX = re.compile(r"^\s*[❯>]\s")


def split_frame(raw: str) -> tuple[str, str]:
    """(content, chrome). Two clocks, one capture — decision 5.

    The input row is dropped from both. See _INPUT_ROW_RX.
    """
    content: list[str] = []
    chrome: list[str] = []
    in_tip = False
    for line in (raw or "").splitlines():
        if _TIP_RX.match(line):
            in_tip = True
            chrome.append(line)
            continue
        if in_tip and _TIP_CONT_RX.match(line) and not line.lstrip().startswith("⎿"):
            chrome.append(line)
            continue
        in_tip = False
        if _INPUT_ROW_RX.match(line):
            continue          # neither clock — the box is not the agent
        if _SPINNER_RX.match(line):
            chrome.append(line)
            continue
        if _TOOL_TIMER_RX.search(line):
            # The command itself is content; only the timer is chrome. Split
            # the line rather than discarding a real tool invocation.
            chrome.append(_TOOL_TIMER_RX.search(line).group(0))
            content.append(_TOOL_TIMER_RX.sub("…", line))
            continue
        content.append(line)
    return "\n".join(content), "\n".join(chrome)


def _h(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]


@dataclass(frozen=True)
class Sample:
    window: str
    ts: float
    content_hash: str
    chrome_pulse: str
    cpu_ticks: Optional[int]
    pane_pid: Optional[int]
    pane_dead: bool
    pane_command: str
    has_content: bool
    turn_owed: bool = False       # see WEDGED_REQUIRES_A_TURN_OWED below
    debt_status: str = "none"     # "owed" | "none" | "orphaned"
    proc_started_at: Optional[float] = None

    def to_dict(self) -> dict:
        return asdict(self)


# ── WEDGED REQUIRES A TURN OWED ──────────────────────────────────────
# Found 2026-08-03, and it invalidates the escalation half of a88d8337.
#
# A pane that FINISHED its turn and is waiting for a human is content-frozen
# and CPU-idle forever — that is not a malfunction, it is what "done" looks
# like. Run the committed decision function against finished_turn_summary.txt
# and it returns quiet, quiet, quiet, then WEDGED at t=601 and every tick
# after. Every idle agent on the box would have escalated once its threshold
# elapsed, and an escalation channel that cries wolf on all four panes is one
# Dean mutes by the second night.
#
# The deeper problem is the one Leon just exposed: EVERYTHING ON SCREEN IS
# PAINT. content_hash, chrome_pulse and is_busy all read `capture-pane`, so
# none of them can distinguish "this agent stopped working" from "this
# agent finished, and nothing has repainted since". No amount of better
# scraping fixes that, because the distinguishing fact was never rendered.
#
# The only non-paint evidence available is (a) /proc, (b) the pane pid, and
# (c) WHAT WE OURSELVES SENT AND WHEN — state the loop holds, not state it
# reads. So a wedge is defined against the send record: a pane is wedged only
# if it OWES a turn. No turn owed → idle, which is healthy and silent.
def sample(window: str, raw_text: str, *, cpu_ticks: Optional[int] = None,
           pane_pid: Optional[int] = None, pane_dead: bool = False,
           pane_command: str = "", now: Optional[float] = None,
           turn_owed: bool = False, debt_status: str = "none",
           proc_started_at: Optional[float] = None) -> Sample:
    """PURE. The live path and the test path both come through here."""
    content, chrome = split_frame(raw_text)
    return Sample(
        window=window,
        ts=time.time() if now is None else now,
        content_hash=_h(content),
        chrome_pulse=_h(chrome),
        cpu_ticks=cpu_ticks,
        pane_pid=pane_pid,
        pane_dead=pane_dead,
        pane_command=pane_command,
        has_content=bool(content.strip()),
        turn_owed=turn_owed,
        debt_status=debt_status,
        proc_started_at=proc_started_at,
    )


# ── the I/O half ─────────────────────────────────────────────────────

def _run(args: list[str]) -> str:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=10)
        return p.stdout if p.returncode == 0 else ""
    except Exception:
        return ""


def read_cpu_ticks(pid: Optional[int]) -> Optional[int]:
    """utime+stime from /proc/<pid>/stat, or None if unreadable.

    None is 'cannot tell', and is treated as such downstream — it must never
    collapse into 0, which would read as 'idle' and manufacture a wedge.
    """
    if not pid:
        return None
    try:
        with open(f"/proc/{pid}/stat") as fh:
            data = fh.read()
        # comm can contain spaces and parens; fields are counted after the ')'.
        fields = data[data.rindex(")") + 2:].split()
        return int(fields[11]) + int(fields[12])       # utime, stime
    except Exception:
        return None


def proc_started_at(pid: Optional[int]) -> Optional[float]:
    """Absolute epoch seconds when this process started, or None.

    /proc/<pid>/stat field 22 is start time in clock ticks since boot;
    /proc/stat's btime is boot time in epoch seconds. Together they give an
    absolute timestamp — which is the property that matters. A pid CHANGE can
    only be detected by an observer that was watching across it; a start time
    is true whether or not anyone was looking, so it survives our own
    restarts and cold boots. Same rule as decision 16, one layer up.
    """
    if not pid:
        return None
    try:
        with open(f"/proc/{pid}/stat") as fh:
            data = fh.read()
        fields = data[data.rindex(")") + 2:].split()
        starttime_ticks = int(fields[19])          # field 22, 1-indexed
        hz = os.sysconf("SC_CLK_TCK") or 100
        btime = None
        with open("/proc/stat") as fh:
            for line in fh:
                if line.startswith("btime "):
                    btime = float(line.split()[1])
                    break
        if btime is None:
            return None
        return btime + starttime_ticks / hz
    except Exception:
        return None


def pane_meta(window: str) -> dict:
    out = _run(["tmux", "display-message", "-p", "-t", f"{SESSION}:{window}",
                "#{pane_dead}\t#{pane_pid}\t#{pane_current_command}"]).strip()
    parts = out.split("\t")
    if len(parts) != 3:
        return {"pane_dead": False, "pane_pid": None, "pane_command": ""}
    return {
        "pane_dead": parts[0] == "1",
        "pane_pid": int(parts[1]) if parts[1].isdigit() else None,
        "pane_command": parts[2],
    }


def live_sample(window: str, now: Optional[float] = None) -> Sample:
    """The real sampler. Reads tmux and /proc, then calls sample()."""
    meta = pane_meta(window)
    raw = _run(["tmux", "capture-pane", "-p", "-t", f"{SESSION}:{window}",
                "-S", "-60"])
    return sample(window, raw, cpu_ticks=read_cpu_ticks(meta["pane_pid"]),
                  pane_pid=meta["pane_pid"], pane_dead=meta["pane_dead"],
                  pane_command=meta["pane_command"], now=now)


# ── the decision ─────────────────────────────────────────────────────

# ── GEOMETRY-ABSENT CONTRACT — an explicit branch, not a default ─────
# Question: when geometry is missing and only the paint reading survives,
# does the watchdog escalate on paint alone, or hold silent?
#
# DECISION: HOLD SILENT PER PANE, COUNT IT, ALARM ON THE AGGREGATE RATE.
#
# Justified against the 563s soak, which is the only real data we have:
# 112 polls x 5 panes = 560 samples, ZERO escalations. During roughly the
# first 50 of those polls v1rtue was showing painted residue, and element115
# showed its own from t+157s onward — so on the order of 110 of 560 samples
# carried a paint-versus-cursor disagreement. Escalating on paint alone would
# have fired on ~20% of samples from minute one, and the property that makes
# the soak informative — that its silence means something — would have been
# destroyed before it produced a single finding.
#
# The stronger reason is what paint IS. Paint is an observation about the
# SCREEN; the watchdog escalates about the AGENT. Painted text with the
# cursor at the prefix has been stale pixels in 5 of 5 observed cases and a
# stranded draft in 0 of 5, so paint-alone currently has a 100% observed
# false-positive rate. Escalating on it would be escalating on the one
# signal we have specifically established is not evidence.
#
# But silence must not be forgetting. Per-pane silence plus an aggregate
# alarm is decision 15's shape reused: one pane losing geometry is a pane in
# copy mode; ALL panes losing it at once is a broken tmux, and that is a real
# incident that the per-pane rule would otherwise swallow.
GEOMETRY_ABSENT_ALARM_RATE = 0.5      # of panes, in one poll
GEOMETRY_ABSENT = "geometry_absent"

WEDGED = "wedged"
UNDECIDABLE = "undecidable"
ORPHANED_DEBT = "orphaned_debt"
IDLE = "idle"
WORKING = "working"
COMPACTING = "compacting"
COMPUTING = "computing"
QUIET = "quiet"
RESTARTED = "restarted"
DEAD = "dead"
NO_AGENT = "no_agent"
NEVER_STARTED = "never_started"
FIRST_SAMPLE = "first_sample"


@dataclass
class Decision:
    window: str
    ts: float
    state: str
    escalate: bool
    compacting: bool
    reason: str
    gap_s: Optional[float] = None
    threshold_s: Optional[float] = None
    cpu_ticks_per_s: Optional[float] = None
    content_frozen: Optional[bool] = None
    chrome_frozen: Optional[bool] = None
    submitted: bool = False          # invariant. There is no path that sets it.

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class _PaneState:
    content_hash: Optional[str] = None
    content_changed_at: float = 0.0
    chrome_pulse: Optional[str] = None
    chrome_changed_at: float = 0.0
    cpu_ticks: Optional[int] = None
    sampled_at: float = 0.0
    pid: Optional[int] = None
    gaps: list = field(default_factory=list)
    seen_content: bool = False        # decision 6: a latch, not an exclusion list
    never_started_notified: bool = False


def p99_gap(gaps: list) -> float:
    """Nearest-rank p99, clamped. No history → the flat constant."""
    if not gaps:
        return NO_HISTORY_GAP_S
    ordered = sorted(gaps)
    idx = min(len(ordered) - 1, max(0, math.ceil(0.99 * len(ordered)) - 1))
    return min(GAP_CEIL_S, max(GAP_FLOOR_S, ordered[idx]))


class PaneWatchdog:
    """Per-pane clocks and the escalation decision.

    The escalator is injectable so a test can observe the call without
    writing to the real jsonl; it DEFAULTS to the real one, and the test
    asserts that identity so the wiring itself is covered.
    """

    def __init__(self, escalator: Optional[Callable] = None) -> None:
        self._panes: dict[str, _PaneState] = {}
        self._escalator = escalator or escalation.escalate

    def state_of(self, window: str) -> _PaneState:
        return self._panes.setdefault(window, _PaneState())

    def observe(self, s: Sample) -> Decision:
        st = self.state_of(s.window)

        def done(state, escalate=False, compacting=False, reason="", **kw):
            d = Decision(window=s.window, ts=s.ts, state=state,
                         escalate=escalate, compacting=compacting,
                         reason=reason, **kw)
            if escalate:
                self._escalator(
                    s.window,
                    _ESCALATION_REASON.get(state, "pane_wedged"),
                    pane_state=d.to_dict(),
                    channel_quarantined=True,
                    detail=reason,
                )
            else:
                # Edge-triggered means BOTH edges. If the condition cleared,
                # drop the latch so a recurrence escalates again instead of
                # being suppressed forever as a repeat.
                escalation.resolve(s.window, _ESCALATION_REASON.get(WEDGED))
            return d

        # 1 — decision 16: observe the process before timing anything.
        if s.pane_dead:
            return done(DEAD, escalate=True,
                        reason="pane_dead=1 — the terminal died; no agent is "
                               "running and no gap measurement is meaningful")
        if s.pane_command and s.pane_command.lstrip("-") in SHELL_COMMANDS:
            return done(NO_AGENT,
                        reason=f"pane_current_command={s.pane_command!r} is a "
                               "shell — nothing to be stuck on")
        if st.pid is not None and s.pane_pid is not None and s.pane_pid != st.pid:
            # Restarted. Reset both clocks and DROP the straddling gap: a
            # restart interval is not a turn interval, and letting it into the
            # distribution raises this pane's threshold forever.
            self._panes[s.window] = _PaneState(
                content_hash=s.content_hash, content_changed_at=s.ts,
                chrome_pulse=s.chrome_pulse, chrome_changed_at=s.ts,
                cpu_ticks=s.cpu_ticks, sampled_at=s.ts, pid=s.pane_pid,
                gaps=list(st.gaps), seen_content=st.seen_content,
            )
            return done(RESTARTED,
                        reason=f"pane_pid {st.pid} → {s.pane_pid}: restarted, "
                               "clocks reset and the straddling gap dropped")

        # 2 — first sight of this pane: seed, never judge.
        if st.content_hash is None:
            st.content_hash = s.content_hash
            st.content_changed_at = s.ts
            st.chrome_pulse = s.chrome_pulse
            st.chrome_changed_at = s.ts
            st.cpu_ticks = s.cpu_ticks
            st.sampled_at = s.ts
            st.pid = s.pane_pid
            st.seen_content = s.has_content
            return done(FIRST_SAMPLE, reason="first sample for this pane — "
                                             "seeding clocks, no judgement")

        cpu_rate = None
        if (s.cpu_ticks is not None and st.cpu_ticks is not None
                and s.ts > st.sampled_at):
            cpu_rate = (s.cpu_ticks - st.cpu_ticks) / (s.ts - st.sampled_at)

        content_frozen = s.content_hash == st.content_hash
        chrome_frozen = s.chrome_pulse == st.chrome_pulse

        if not chrome_frozen:
            st.chrome_pulse = s.chrome_pulse
            st.chrome_changed_at = s.ts

        # 3 — content moved: this pane is working, full stop. No duration
        # threshold applies to a pane that is still producing output, which is
        # the whole point of killing turn-duration heuristics (decision 1).
        if not content_frozen:
            st.gaps.append(s.ts - st.content_changed_at)
            st.content_hash = s.content_hash
            st.content_changed_at = s.ts
            st.cpu_ticks = s.cpu_ticks
            st.sampled_at = s.ts
            st.pid = s.pane_pid
            st.seen_content = st.seen_content or s.has_content
            return done(WORKING, reason="content changed since last sample",
                        gap_s=0.0, cpu_ticks_per_s=cpu_rate,
                        content_frozen=False, chrome_frozen=chrome_frozen)

        gap = s.ts - st.content_changed_at
        st.cpu_ticks = s.cpu_ticks
        st.sampled_at = s.ts
        st.pid = s.pane_pid

        # 4 — decision 6: a pane that has never produced content emits one
        # notice, then goes quiet until it does. Self-heals when an agent spawns.
        if not st.seen_content and not s.has_content:
            if st.never_started_notified:
                return done(NEVER_STARTED, reason="no content ever — already "
                                                  "notified once, staying quiet",
                            gap_s=gap, content_frozen=True,
                            chrome_frozen=chrome_frozen)
            st.never_started_notified = True
            return done(NEVER_STARTED, escalate=True,
                        reason="pane has never produced content — never started",
                        gap_s=gap, content_frozen=True, chrome_frozen=chrome_frozen)

        threshold = p99_gap(st.gaps)
        if gap <= threshold:
            return done(QUIET, reason=f"still within this pane's threshold "
                                      f"({gap:.0f}s ≤ {threshold:.0f}s)",
                        gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                        content_frozen=True, chrome_frozen=chrome_frozen)

        # 5 — past threshold. CPU is the discriminator, and it only ever
        # VETOES an escalation; it never causes one.
        if cpu_rate is not None and cpu_rate >= CPU_BURN_TICKS_PER_S:
            if chrome_frozen:
                # Both screen clocks dark while the process burns CPU. That is
                # the compaction signature — the TUI stops painting entirely.
                return done(COMPACTING, compacting=True,
                            reason=f"both clocks dark but {cpu_rate:.0f} ticks/s "
                                   "— compacting, not wedged",
                            gap_s=gap, threshold_s=threshold,
                            cpu_ticks_per_s=cpu_rate,
                            content_frozen=True, chrome_frozen=True)
            return done(COMPUTING,
                        reason=f"content frozen but chrome alive and "
                               f"{cpu_rate:.0f} ticks/s — a long tool call",
                        gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                        content_frozen=True, chrome_frozen=False)

        if s.debt_status == "orphaned":
            # turn_owed is true and the debt predates this process. The
            # recipient of that send is gone; the current occupant was never
            # asked anything, so it CANNOT be wedged — but the instruction
            # was genuinely lost, and clearing it silently rebuilds the
            # blindness one layer down. Escalate under its own reason, with
            # its own action, and let the debt be closed deliberately.
            return done(ORPHANED_DEBT, escalate=True,
                        reason=f"turn owed but the send predates this process "
                               f"(started {s.proc_started_at}) — the pane "
                               "restarted and the instruction died with the "
                               "old process; it was never received",
                        gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                        content_frozen=True, chrome_frozen=chrome_frozen)

        if not s.turn_owed:
            # Frozen, idle, and nobody is waiting on it. That is a finished
            # agent sitting at a prompt, which is the normal resting state of
            # every pane on this box. Silence here is correct.
            return done(IDLE,
                        reason=f"content frozen {gap:.0f}s and no turn owed — "
                               "finished and waiting for input, not wedged",
                        gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                        content_frozen=True, chrome_frozen=chrome_frozen)

        # ── THE MIDDLE STREAM, AND IT HAS NO ANSWER ─────────────────
        # Leon asked what ledger spacing separates a long-working pane from a
        # wedged one when both go quiet for 400s. Nothing does, and the reason
        # is stronger than "we have not found the number yet":
        #
        #   content_hash  frozen in both, by construction of the question.
        #   CPU           high VETOES (definitely computing). Low is ambiguous
        #                 — an API round-trip burns none. Already a stated
        #                 caveat in decision 16; this is the case it names.
        #   ledger        gives the turn START, so any rule on it is a rule on
        #                 turn DURATION — the exact family decision 1 killed
        #                 as self-poisoning, because a stuck turn inflates its
        #                 own history and the alarm never fires. So no spacing
        #                 works; the whole family is disqualified.
        #   chrome_pulse  the only signal left, and it splits the case.
        #
        # CONTRADICTS DECISION 5, deliberately, and this is the flag for it.
        # The record says "content frozen + chrome alive = wedged". That is an
        # over-claim. A pane waiting on a long API call paints a ticking
        # spinner with no new output, which is content-frozen + chrome-alive
        # and perfectly healthy. So:
        #
        #   chrome FROZEN + turn owed -> the pane owes a turn and paints no
        #     spinner at all. A mid-turn pane should be animating. Positive
        #     evidence something stopped. WEDGED.
        #   chrome ALIVE  + turn owed -> the TUI render loop is alive and the
        #     agent may simply be waiting. UNDECIDABLE.
        #
        # UNDECIDABLE still escalates, because silence is the failure mode —
        # but it escalates as "I cannot tell", which is a different thing to
        # ask a human for than "this is stuck, restart it". Forcing a coin
        # flip into a confident verdict is how an alert channel earns being
        # ignored.
        if not chrome_frozen:
            return done(UNDECIDABLE, escalate=True,
                        reason=f"silent {gap:.0f}s > {threshold:.0f}s with a turn "
                               "owed, but chrome is still animating and CPU is "
                               "low — that is indistinguishable from waiting on "
                               "a long call. Cannot tell working from wedged.",
                        gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                        content_frozen=True, chrome_frozen=False)

        return done(WEDGED, escalate=True,
                    reason=f"content frozen {gap:.0f}s > {threshold:.0f}s "
                           f"threshold, chrome {'frozen' if chrome_frozen else 'alive'}, "
                           f"cpu {'unknown' if cpu_rate is None else f'{cpu_rate:.1f}/s'}",
                    gap_s=gap, threshold_s=threshold, cpu_ticks_per_s=cpu_rate,
                    content_frozen=True, chrome_frozen=chrome_frozen)


def geometry_absent_verdict(total_panes: int, absent_panes: int) -> tuple:
    """(escalate, reason). The aggregate branch, separated so it is testable
    without a watchdog instance and impossible to reach by accident."""
    if total_panes <= 0:
        return False, "no panes"
    rate = absent_panes / total_panes
    if rate >= GEOMETRY_ABSENT_ALARM_RATE:
        return True, (f"{absent_panes}/{total_panes} panes lost cursor geometry in "
                      "one poll — that is a broken reader, not that many stranded "
                      "drafts. Paint alone is NOT being escalated per pane.")
    return False, (f"{absent_panes}/{total_panes} panes without geometry — below the "
                   "aggregate alarm rate; each holds silent by contract")


_ESCALATION_REASON = {
    WEDGED: "pane_wedged",
    UNDECIDABLE: "pane_undecidable",
    GEOMETRY_ABSENT: "reader_geometry_lost",
    ORPHANED_DEBT: "debt_orphaned_by_restart",
    DEAD: "pane_dead",
    NEVER_STARTED: "pane_never_started",
}
