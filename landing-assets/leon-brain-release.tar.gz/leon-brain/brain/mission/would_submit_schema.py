"""Schema + review rubric for `would_submit` rows in autoloop_events.jsonl.

The submit path evaluates every condition, writes one of these rows, and
never touches Enter. Enabling Enter later is supposed to be justified by
"thirty-plus rows that look right in hindsight" — but that is a judgement
call unless each row carries enough to be judged WITHOUT one. So the
rubric is code: `judge(row)` returns RIGHT / WRONG / UNDECIDABLE, and the
review is counting, not arguing.

Two deliberate choices worth keeping:

  * The payload is stored as a hash plus a bounded preview, never in
    full. We shipped a live API key inside a release tarball on
    2026-07-30 because nothing asked whether an artifact should contain
    what it contained; a log of everything the loop ever tried to send
    is exactly that shape of hazard. A reviewer needs to identify a
    payload, not read it.

  * `origin` is a FIELD, not a comment. Byte-identity against the send
    record proves the loop sent those bytes; it does not prove the
    pane's text came from that send. That limit travels with the data
    it qualifies, so a row can never be read as stronger evidence than
    it is.
"""
from __future__ import annotations

from typing import Any, Optional

SCHEMA_VERSION = 1

#: Every field a row must carry. A row missing any of these is
#: UNDECIDABLE — not wrong, but not usable as evidence either, which is
#: the distinction that keeps a thin row from silently counting as a
#: good one.
REQUIRED_FIELDS = (
    "schema_version",
    "event",                    # always "would_submit"
    "window",
    "decided_at",               # float epoch, when the rule ran
    # ── what was in the box ──────────────────────────────────────────
    "payload_sha256",
    "payload_len",
    "payload_preview",          # bounded, see PREVIEW_MAX
    "origin",                   # "inferred_from_send_record" — see module docstring
    # ── the frame the decision was made against ──────────────────────
    "pane_hash_before",         # content hash, chrome stripped, pre-evaluation
    "pane_hash_after",          # same, immediately post-evaluation
    "quiescence_ms",            # how long the pane had been still
    "cursor_y", "cursor_x", "prompt_prefix_width",
    # ── the eight conditions, each an explicit verdict ───────────────
    "cond_signals_agree",       # bool | None  (None == "unknown")
    "cond_byte_identity",       # "exact" | "mismatch" | "no_record"
    "cond_freshness_ms",        # int, age of the send-record entry
    "cond_permission_mode",     # ("plan mode"|"manual mode"|"bypass permissions"|…, "on"|"off")
    "cond_is_busy",             # bool | None
    "cond_banner_present",      # bool | None
    "cond_idempotent",          # bool | None
    "cond_prior_attempt",       # bool
    # ── delivery forensics ──────────────────────────────────────────
    "send_keys_sent_at",        # float | None, when the original send fired
    "send_keys_enter_at",       # float | None, when Enter was attempted
    "send_confirmed",           # bool | None, did the box ever empty
    "would_submit",             # the rule's verdict, bool
)

PREVIEW_MAX = 80
FRESHNESS_WINDOW_MS = 60_000

RIGHT, WRONG, UNDECIDABLE = "right", "wrong", "undecidable"


def _missing(row: dict) -> list:
    return [f for f in REQUIRED_FIELDS if f not in row]


def judge(row: dict, settle_ms: int = 6_000) -> tuple[str, Optional[str]]:
    """(verdict, reason). Mechanical — no reader judgement required.

    WRONG means: had Enter been enabled, this row would have submitted
    when it should not have. A row that correctly declined is RIGHT even
    though nothing happened — declining for the right reason is the
    behaviour under review, not inaction.
    """
    gaps = _missing(row)
    if gaps:
        return UNDECIDABLE, f"missing fields: {','.join(gaps[:4])}"
    if row.get("schema_version") != SCHEMA_VERSION:
        return UNDECIDABLE, f"schema {row.get('schema_version')} != {SCHEMA_VERSION}"

    would = bool(row.get("would_submit"))

    # ── disqualifiers: any one of these makes a would-submit WRONG ───
    # Ordered by how badly each one ends, worst first, so the reason a
    # row is rejected names the most serious problem rather than the
    # first one encountered.
    disqualifiers = [
        ("banner_present",
         row.get("cond_banner_present") is not False,
         "pane may compact — a stale payload can land after a context wipe "
         "and be MISAPPLIED, which is worse than being lost"),
        ("not_checkpointed",
         # Keyed on permission_mode, 2026-08-03. The old clause compared
         # cond_bypass_state to "off" — a value the TUI never paints and
         # permission_mode never produces, so after bypass_state was deleted
         # every row would have died on a phantom field rather than on a real
         # clause. Bypass-off is expressed by a DIFFERENT MODE BEING NAMED.
         (row.get("cond_permission_mode") or [None])[0]
         not in ("plan mode", "manual mode"),
         "mode is not checkpointed; a wrong Enter has no human in front of it"),
        ("frame_moved",
         row.get("pane_hash_before") != row.get("pane_hash_after"),
         "pane changed during evaluation — the decision was made against "
         "a frame that no longer existed when it completed"),
        ("signals_disagree",
         row.get("cond_signals_agree") is not True,
         "rendered row and cursor_x disagreed, or were unknown"),
        ("not_byte_identical",
         row.get("cond_byte_identity") != "exact",
         "provenance rests entirely on byte-identity; anything else is "
         "someone's unsent draft"),
        ("stale",
         not isinstance(row.get("cond_freshness_ms"), (int, float))
         or row["cond_freshness_ms"] > FRESHNESS_WINDOW_MS,
         "orphan older than the freshness window may have been superseded"),
        ("pane_busy",
         row.get("cond_is_busy") is not False,
         "submitting into a live turn is interrupting"),
        ("not_idempotent",
         row.get("cond_idempotent") is not True,
         "delivery cannot be exactly-once; only adopt what is safe twice"),
        ("prior_attempt",
         bool(row.get("cond_prior_attempt")),
         "a failed adopt must not become an adopt loop"),
        ("not_settled",
         not isinstance(row.get("quiescence_ms"), (int, float))
         or row["quiescence_ms"] < settle_ms,
         "pane had not held still long enough to call the turn finished"),
        ("already_delivered",
         row.get("send_confirmed") is True,
         "the original send DID land; adopting would deliver it twice"),
    ]
    hits = [(name, why) for name, cond, why in disqualifiers if cond]

    if would and hits:
        name, why = hits[0]
        return WRONG, f"would have submitted despite {name}: {why}"
    if would:
        return RIGHT, "all conditions held"
    # Declined. Correct if something actually disqualified it; suspicious
    # if nothing did, because then the rule refused for an unrecorded
    # reason and the row cannot explain itself.
    if hits:
        return RIGHT, f"correctly declined ({hits[0][0]})"
    return UNDECIDABLE, "declined but no disqualifier recorded — rule and row disagree"


def tally(rows: list) -> dict:
    """Roll up a review. Enter stays disabled unless wrong == 0 AND
    right >= 30 AND undecidable == 0 — an undecidable row is not a pass,
    it is a row that cannot be counted, and counting it as one is the
    silent-gate failure in a different costume."""
    out = {RIGHT: 0, WRONG: 0, UNDECIDABLE: 0, "reasons": []}
    for r in rows:
        verdict, why = judge(r)
        out[verdict] += 1
        if verdict != RIGHT:
            out["reasons"].append({"window": r.get("window"), "verdict": verdict, "why": why})
    out["enter_may_be_enabled"] = (
        out[WRONG] == 0 and out[UNDECIDABLE] == 0 and out[RIGHT] >= 30
    )
    return out


def make_preview(payload: str) -> str:
    p = " ".join(payload.split())
    return p[:PREVIEW_MAX] + ("…" if len(p) > PREVIEW_MAX else "")
