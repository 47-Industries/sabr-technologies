"""
Operational Awareness Loop — periodic checks, summaries, blocker reports,
and "next best actions" generation.

Runs on a configurable interval. Each tick:
  1. Checks build status for all active projects
  2. Checks deployment health (backend URLs)
  3. Checks PR merge state
  4. Checks for failed workflows
  5. Detects stale projects (no activity in N days)
  6. Generates operational summary + next-best-actions

Results persist in brain_state/projects.db (ops_checks table).
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
import uuid
from typing import Any, Optional

log = logging.getLogger("leon.mission.ops_loop")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS ops_checks (
    id          TEXT PRIMARY KEY,
    project_id  TEXT NOT NULL,
    check_type  TEXT NOT NULL,       -- build|health|pr|workflow|creds|custom
    target      TEXT DEFAULT '',     -- URL, repo, etc
    result      TEXT NOT NULL,       -- pass|fail|warn|unknown
    detail      TEXT DEFAULT '',
    checked_at  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS ops_summaries (
    id          TEXT PRIMARY KEY,
    summary     TEXT NOT NULL,       -- JSON
    actions     TEXT NOT NULL,       -- JSON array of next-best-actions
    created_at  REAL NOT NULL
);
"""


class OpsLoop:
    def __init__(self, registry=None, state_engine=None, connectors=None,
                 cred_awareness=None, decisions=None, db_path: str | None = None):
        self.registry = registry
        self.state_engine = state_engine
        self.connectors = connectors
        self.cred_awareness = cred_awareness
        self.decisions = decisions
        self.db_path = os.path.abspath(db_path or DB_PATH)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._last_tick: float = 0
        self._tick_interval = 300  # 5 minutes default
        log.info("OpsLoop ready")

    # ── Core tick ───────────────────────────────────────────────────────

    def tick(self, force: bool = False) -> dict:
        """Run a full operational check cycle."""
        now = time.time()
        if not force and (now - self._last_tick) < self._tick_interval:
            return {"skipped": True, "reason": "too soon", "next_in_s": int(self._tick_interval - (now - self._last_tick))}

        self._last_tick = now
        results = {"checks": [], "timestamp": now}

        if not self.registry:
            return {"error": "No project registry attached"}

        projects = self.registry.list_all(active_only=True)
        for proj in projects:
            proj_checks = self._check_project(proj)
            results["checks"].extend(proj_checks)

        # Generate summary and next-best-actions
        summary = self._generate_summary(results["checks"], projects)
        results["summary"] = summary

        # Persist
        sid = uuid.uuid4().hex[:12]
        self._conn.execute(
            "INSERT INTO ops_summaries (id, summary, actions, created_at) VALUES (?,?,?,?)",
            (sid, json.dumps(summary), json.dumps(summary.get("next_actions", [])), now),
        )
        self._conn.commit()

        return results

    def _check_project(self, project: dict) -> list[dict]:
        """Run all available checks for a single project."""
        checks = []
        pid = project["id"]

        # Backend health
        if self.connectors:
            for url in project.get("backend_urls", []):
                r = self.connectors.health_check(url)
                check = self._record_check(pid, "health", url,
                                            "pass" if r.get("ok") else "fail",
                                            json.dumps(r))
                checks.append(check)

            # GitHub workflows
            for repo_url in project.get("repo_urls", []):
                parts = repo_url.rstrip("/").split("/")
                if len(parts) >= 2:
                    owner, repo = parts[-2], parts[-1].replace(".git", "")
                    wf = self.connectors.github_workflow_runs(owner, repo, limit=1)
                    if wf.get("ok") and wf.get("data"):
                        runs = wf["data"] if isinstance(wf["data"], list) else []
                        if runs:
                            latest = runs[0]
                            result = "pass" if latest.get("conclusion") == "success" else "fail"
                            if latest.get("status") == "in_progress":
                                result = "warn"
                            check = self._record_check(pid, "workflow", f"{owner}/{repo}",
                                                       result, json.dumps(latest))
                            checks.append(check)

                    # Latest PR
                    pr = self.connectors.github_latest_pr(owner, repo)
                    if pr.get("ok") and pr.get("data"):
                        pr_data = pr["data"]
                        result = "pass" if pr_data.get("merged") or pr_data.get("state") == "MERGED" else "warn"
                        check = self._record_check(pid, "pr", f"{owner}/{repo}",
                                                   result, json.dumps(pr_data))
                        checks.append(check)

        # Credential check
        if self.cred_awareness:
            cred_result = self.cred_awareness.check_project_creds(project)
            result = "pass" if cred_result.get("all_present") else "fail"
            check = self._record_check(pid, "creds", project["name"],
                                       result, json.dumps(cred_result))
            checks.append(check)

        # Checklist readiness
        if self.state_engine:
            readiness = self.state_engine.project_readiness(pid)
            result = "pass" if readiness.get("readiness_pct", 0) >= 80 else "warn"
            if readiness.get("blockers"):
                result = "fail"
            check = self._record_check(pid, "checklist", project["name"],
                                       result, json.dumps(readiness))
            checks.append(check)

        return checks

    def _record_check(self, project_id: str, check_type: str, target: str,
                      result: str, detail: str = "") -> dict:
        cid = uuid.uuid4().hex[:12]
        now = time.time()
        self._conn.execute(
            "INSERT INTO ops_checks (id, project_id, check_type, target, result, detail, checked_at) VALUES (?,?,?,?,?,?,?)",
            (cid, project_id, check_type, target, result, detail, now),
        )
        return {"id": cid, "project_id": project_id, "check_type": check_type,
                "target": target, "result": result, "checked_at": now}

    # ── Summary generation ──────────────────────────────────────────────

    def _generate_summary(self, checks: list[dict], projects: list[dict]) -> dict:
        failing = [c for c in checks if c["result"] == "fail"]
        warnings = [c for c in checks if c["result"] == "warn"]
        passing = [c for c in checks if c["result"] == "pass"]

        next_actions = []

        # Generate next-best-actions from failures
        for c in failing:
            if c["check_type"] == "health":
                next_actions.append({
                    "action": f"Investigate failing backend: {c['target']}",
                    "project_id": c["project_id"],
                    "priority": "high",
                    "tier": "READ_ONLY",
                })
            elif c["check_type"] == "workflow":
                next_actions.append({
                    "action": f"Fix failing CI workflow: {c['target']}",
                    "project_id": c["project_id"],
                    "priority": "high",
                    "tier": "APPROVAL_REQUIRED",
                })
            elif c["check_type"] == "creds":
                next_actions.append({
                    "action": f"Configure missing credentials for: {c['target']}",
                    "project_id": c["project_id"],
                    "priority": "medium",
                    "tier": "APPROVAL_REQUIRED",
                })
            elif c["check_type"] == "checklist":
                next_actions.append({
                    "action": f"Address checklist blockers for: {c['target']}",
                    "project_id": c["project_id"],
                    "priority": "medium",
                    "tier": "SAFE_AUTOMATION",
                })

        # Unresolved decisions
        if self.decisions:
            open_decisions = self.decisions.list_all(status="open")
            for d in open_decisions[:5]:  # top 5
                next_actions.append({
                    "action": f"Resolve decision: {d['title']}",
                    "project_id": d.get("project_id"),
                    "priority": "medium",
                    "tier": "APPROVAL_REQUIRED",
                })

        return {
            "total_checks": len(checks),
            "passing": len(passing),
            "warnings": len(warnings),
            "failing": len(failing),
            "health_score": round(100 * len(passing) / len(checks), 1) if checks else 0,
            "next_actions": next_actions,
            "checked_at": time.time(),
        }

    # ── History ─────────────────────────────────────────────────────────

    def recent_checks(self, project_id: str | None = None, limit: int = 50) -> list[dict]:
        q = "SELECT * FROM ops_checks"
        params: list = []
        if project_id:
            q += " WHERE project_id = ?"
            params.append(project_id)
        q += " ORDER BY checked_at DESC LIMIT ?"
        params.append(limit)
        return [dict(r) for r in self._conn.execute(q, params).fetchall()]

    def latest_summary(self) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM ops_summaries ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["summary"] = json.loads(d["summary"]) if isinstance(d["summary"], str) else d["summary"]
        d["actions"] = json.loads(d["actions"]) if isinstance(d["actions"], str) else d["actions"]
        return d

    def stale_projects(self, days: int = 14) -> list[dict]:
        """Find projects with no ops checks in N days."""
        if not self.registry:
            return []
        cutoff = time.time() - (days * 86400)
        projects = self.registry.list_all(active_only=True)
        stale = []
        for p in projects:
            last_check = self._conn.execute(
                "SELECT MAX(checked_at) as last FROM ops_checks WHERE project_id = ?",
                (p["id"],),
            ).fetchone()
            last = last_check["last"] if last_check and last_check["last"] else 0
            if last < cutoff:
                stale.append({"project": p["name"], "id": p["id"],
                              "last_checked": last, "days_stale": int((time.time() - last) / 86400) if last else -1})
        return stale
