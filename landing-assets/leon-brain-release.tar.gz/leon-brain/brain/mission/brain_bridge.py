"""
Brain Bridge — connects the SNN to real operational behavior.

This is the missing piece that turns the 10,000-neuron brain from
decorative to functional. Neuromodulators now CAUSE behavioral changes
in the autopilot, and autopilot outcomes feed BACK into the brain
as reward signals.

The brain literally learns from experience.

Reads:
  brain.neuromodulators → SNNGates → behavioral parameters

Writes:
  autopilot outcomes → brain.reward_pulse() → dopamine → STDP learning
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, asdict
from typing import Any, Optional

log = logging.getLogger("leon.mission.brain_bridge")


@dataclass
class BrainDrivenConfig:
    """Behavioral parameters derived from live brain state.
    These ACTUALLY change how the autopilot operates."""

    # How many Tier 2 (auto-with-rollback) actions to attempt per tick
    # High dopamine → more aggressive, try more fixes
    max_tier2_actions: int = 3

    # How often to scan (multiplier on base interval)
    # High norepinephrine → scan more frequently
    scan_interval_multiplier: float = 1.0

    # Whether to attempt deep CI diagnosis (pull logs, check schemas)
    # High acetylcholine → deeper investigation
    deep_diagnosis: bool = True

    # Max retries for failed operations before giving up
    # High serotonin → more patient, more retries
    retry_limit: int = 2

    # Whether to proactively push commits and update deps
    # High dopamine + low norepinephrine → push aggressively
    auto_push: bool = True

    # Whether to surface minor findings (low-priority stuff)
    # High acetylcholine → report everything. Low → only critical.
    verbose_reporting: bool = False

    # Minimum confidence to attempt a Tier 2 fix
    # High norepinephrine → require higher confidence
    fix_confidence_threshold: float = 0.5


class BrainBridge:
    """Bidirectional bridge between SNN brain state and autopilot behavior."""

    def __init__(self, brain=None):
        self.brain = brain
        self._snn_gates = None
        self._last_config: Optional[BrainDrivenConfig] = None
        self._last_update: float = 0
        self._cache_ttl = 0.5  # recompute every 500ms — 10 brain ticks at 20Hz

        # Wire up SNN gates if brain is available
        if brain:
            try:
                from brain.cognition.snn_gating import SNNGates
                self._snn_gates = SNNGates(brain)
                log.info("BrainBridge wired to SNN gates")
            except Exception as e:
                log.warning("BrainBridge: SNN gates not available: %s", e)

    def get_config(self) -> BrainDrivenConfig:
        """Get current behavioral config derived from brain state."""
        now = time.time()
        if self._last_config and (now - self._last_update) < self._cache_ttl:
            return self._last_config

        if not self._snn_gates:
            self._last_config = BrainDrivenConfig()  # defaults
            return self._last_config

        try:
            gates = self._snn_gates.current()
            nm = self._read_nm()

            config = BrainDrivenConfig(
                # Dopamine drives aggression: 0.2→1 action, 0.8→6 actions
                max_tier2_actions=max(1, min(6, int(1 + 5 * nm["dopamine"]))),

                # Norepinephrine drives scan frequency: high NE = scan 2x faster
                scan_interval_multiplier=max(0.5, 1.5 - nm["norepinephrine"]),

                # Acetylcholine drives investigation depth
                deep_diagnosis=nm["acetylcholine"] > 0.3,

                # Serotonin drives patience
                retry_limit=gates.retry_budget,

                # Push only when dopamine is up and NE isn't too high
                auto_push=nm["dopamine"] > 0.3 and nm["norepinephrine"] < 0.7,

                # Report verbosely when attention is high
                verbose_reporting=nm["acetylcholine"] > 0.5,

                # Fix confidence from NE
                fix_confidence_threshold=gates.confidence_threshold,
            )

            self._last_config = config
            self._last_update = now
            return config

        except Exception as e:
            log.debug("BrainBridge config fallback: %s", e)
            self._last_config = BrainDrivenConfig()
            return self._last_config

    def _read_nm(self) -> dict:
        try:
            nm = getattr(self.brain, "neuromodulators", {}) or {}
            return {
                "dopamine": float(nm.get("dopamine", 0.5)),
                "serotonin": float(nm.get("serotonin", 0.5)),
                "norepinephrine": float(nm.get("norepinephrine", 0.3)),
                "acetylcholine": float(nm.get("acetylcholine", 0.4)),
            }
        except Exception:
            return {"dopamine": 0.5, "serotonin": 0.5,
                    "norepinephrine": 0.3, "acetylcholine": 0.4}

    # ── Reward feedback — outcomes shape the brain ──────────────────────

    def reward_success(self, action_name: str, project: str = ""):
        """A fix/push/advance succeeded → dopamine reward."""
        if not self.brain:
            return
        try:
            self.brain.reward_pulse(+0.3, source=f"autopilot:{action_name}")
            log.debug("Reward +0.3 for %s on %s", action_name, project)
        except Exception:
            pass

    def reward_big_success(self, action_name: str, project: str = ""):
        """A major fix (CI green, deploy success) → strong dopamine."""
        if not self.brain:
            return
        try:
            self.brain.reward_pulse(+0.6, source=f"autopilot:{action_name}")
            log.info("Big reward +0.6 for %s on %s", action_name, project)
        except Exception:
            pass

    def reward_failure(self, action_name: str, project: str = ""):
        """An action failed → small dopamine dip → brain becomes cautious."""
        if not self.brain:
            return
        try:
            self.brain.reward_pulse(-0.2, source=f"autopilot:{action_name}")
            log.debug("Penalty -0.2 for %s on %s", action_name, project)
        except Exception:
            pass

    def reward_dean_approval(self):
        """Dean approved a queued action → positive signal."""
        if not self.brain:
            return
        try:
            self.brain.reward_pulse(+0.4, source="autopilot:dean_approved")
        except Exception:
            pass

    def reward_dean_rejection(self):
        """Dean rejected → negative signal → more cautious."""
        if not self.brain:
            return
        try:
            self.brain.reward_pulse(-0.4, source="autopilot:dean_rejected")
        except Exception:
            pass

    # ── Explain current state ───────────────────────────────────────────

    def explain(self) -> dict:
        """Human-readable explanation of how brain state drives behavior."""
        config = self.get_config()
        nm = self._read_nm()
        return {
            "neuromodulators": {k: round(v, 3) for k, v in nm.items()},
            "behavioral_config": asdict(config),
            "explanation": {
                "aggression": f"dopamine={nm['dopamine']:.2f} → max {config.max_tier2_actions} Tier 2 actions/tick",
                "scan_speed": f"norepinephrine={nm['norepinephrine']:.2f} → interval ×{config.scan_interval_multiplier:.1f}",
                "investigation": f"acetylcholine={nm['acetylcholine']:.2f} → deep_diagnosis={'ON' if config.deep_diagnosis else 'OFF'}",
                "patience": f"serotonin={nm['serotonin']:.2f} → {config.retry_limit} retries before giving up",
                "auto_push": f"dopamine={nm['dopamine']:.2f} + NE={nm['norepinephrine']:.2f} → push={'YES' if config.auto_push else 'NO'}",
            },
        }
