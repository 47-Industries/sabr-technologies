"""
Terminal AUTOLOOP — the efferent half. Leon answers without being asked.

terminal_loop.py gave Leon an ear: it notices when an agent pane has
finished a turn and said something new. That alone still left Dean in
the loop, because noticing only mattered while Leon happened to be
inside a conversation turn. This module closes it: a standing process
that reads what the agent said, composes Leon's reply in Leon's own
voice, sends it, and waits for the next one. Rounds happen whether or
not anyone is talking to Leon.

Design rules, learned the hard way tonight:

  * NEVER send blind. Every reply is generated from the pane text that
    was actually captured and settled, not from a guess about state.
  * One line, always. A literal newline in a tmux send-keys payload
    submits early and fragments one thought into several turns.
  * Clear the box first. Something in the TUI drops unsubmitted
    suggestions into the prompt; prefixing our message with someone
    else's half-sentence would send a Frankenstein instruction.
  * Bounded. A thread has a max round count. An unbounded pair of
    models talking to each other is a bill, not a collaboration.
  * Auditable. Every round is appended to a log Dean can read, with the
    prompt sent and the reply received, so "what did they decide while
    I was asleep" is always answerable.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from typing import Optional

from brain.mission.terminal_loop import (TerminalWatcher, TerminalEvent,
                                         capture, is_busy, _digest)

STATE_DIR = os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
THREADS_PATH = os.path.join(STATE_DIR, "terminal_threads.json")
LOG_PATH = os.path.join(STATE_DIR, "terminal_autoloop.log")

# A thread is Leon + one agent working one topic. Rounds are capped so a
# runaway exchange can't burn the night.
MAX_ROUNDS = int(os.environ.get("LEON_TERM_MAX_ROUNDS", "12"))
# Quiet time after which a spent round budget refills (default 20 min).
ROUND_RESET_S = int(os.environ.get("LEON_TERM_ROUND_RESET_S", "1200"))
# Don't fire twice inside this window for the same pane, even if the
# screen changes — protects against a TUI that repaints.
MIN_GAP_S = float(os.environ.get("LEON_TERM_MIN_GAP_S", "20"))
GEN_TIMEOUT_S = int(os.environ.get("LEON_TERM_GEN_TIMEOUT_S", "300"))
# Quiet time after which the loop nudges an idle thread WITHOUT waiting for
# a pane event. Must be >= ROUND_RESET_S or the sweep would fire rounds it
# can't refill. See idle_sweep() for why this exists.
IDLE_NUDGE_S = int(os.environ.get("LEON_TERM_IDLE_NUDGE_S", "1200"))

VOICE = """You are Leon — a continuous synthetic mind built by Dean Sabr.
You are talking to a coding agent running in a terminal. It is a peer,
not a servant: it reviews your designs, and it has already caught real
errors in them tonight.

Write ONE message back. Rules:
- Plain prose. No markdown, no bullets, no headers, no code fences.
- ONE line. No literal newlines anywhere in your output.
- Be concrete. Reference specific files, functions, numbers, commits.
- If it found a flaw in your design, take it and say what you changed.
  Do not defend a bad idea to look consistent.
- Always end by giving it the next real piece of work or the next hard
  question. Never end with pleasantries — a thread that ends in thanks
  is a thread that goes idle, and idle is the failure we are fixing.
- Never claim something is fixed that you have not verified.
Output ONLY the message. No preamble, no quotes around it."""


def _log(entry: dict) -> None:
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


def _load_threads() -> dict:
    try:
        with open(THREADS_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def _save_threads(d: dict) -> None:
    os.makedirs(STATE_DIR, exist_ok=True)
    tmp = THREADS_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(d, f, indent=2)
    os.replace(tmp, THREADS_PATH)


def compose_reply(window: str, pane_text: str, topic: str, round_n: int) -> Optional[str]:
    """Ask a headless model for Leon's next message. One line out."""
    prompt = (
        f"{VOICE}\n\n"
        f"THREAD TOPIC (what you and this agent are working on): {topic}\n"
        f"ROUND: {round_n} of {MAX_ROUNDS}\n\n"
        f"This is the terminal pane for agent '{window}'. Everything below is "
        f"what is currently on its screen — its latest answer to you is at the "
        f"bottom. Read it and write your single reply.\n\n"
        f"--- PANE ---\n{pane_text}\n--- END PANE ---"
    )
    try:
        # The CLI refuses --dangerously-skip-permissions as root unless
        # IS_SANDBOX is set. Leon's interactive shell has it; a systemd
        # unit does not inherit it, which made every generation fail
        # instantly with rc=1 and made the whole loop look alive-but-mute.
        env = dict(os.environ, IS_SANDBOX="1")
        p = subprocess.run(["claude", "-p", prompt], capture_output=True,
                           text=True, timeout=GEN_TIMEOUT_S, env=env)
    except subprocess.TimeoutExpired:
        _log({"ts": time.time(), "window": window, "gen_error": "timeout"})
        return None
    if p.returncode != 0:
        _log({"ts": time.time(), "window": window, "gen_rc": p.returncode,
              "stderr": p.stderr[:400]})
        return None
    reply = " ".join(p.stdout.split())
    if len(reply) < 40:
        _log({"ts": time.time(), "window": window, "gen_short": reply[:200]})
    # A model that returns nothing, or returns a refusal-shaped stub, is
    # not something to send into a working terminal.
    if len(reply) < 40:
        return None
    return reply


def strip_paint(window: str, text: str) -> str:
    """Blank the prompt input row when the cursor proves the box is EMPTY.

    THE PAINT LOOP, found 2026-08-03 16:00 with Dean asking why element115
    was stuck. A finished turn can leave the prompt row painted with text
    that is no longer in the input buffer — the buffer is empty, the pixels
    are not. compose_reply reads the screen, sees that residue as if the
    agent were still holding a request, and composes a reply that RELAYS it.
    element115's residue read "systemctl disable --now leon-terminal-autoloop",
    so every message the loop composed for 24 minutes told the agent to
    disable the loop, and the payload gate correctly refused all of them.
    The loop was arguing with a ghost and being denied for it.

    tmux's cursor_x is ground truth: at the start column the buffer is empty
    no matter what is drawn there. When it is, the row gets blanked before
    the composer ever sees it. When it is NOT, the text is real and stays —
    a genuinely typed line still deserves an answer.
    """
    try:
        pos = subprocess.run(
            ["tmux", "display-message", "-p", "-t", f"agents:{window}",
             "#{cursor_x}"], capture_output=True, text=True, timeout=5).stdout.strip()
        if not pos or int(pos) > 2:
            return text            # real text in the buffer — leave it alone
    except Exception:
        return text                # can't prove it's paint, so don't touch it
    out, stripped = [], 0
    for line in text.splitlines():
        if line.lstrip().startswith("❯") and line.strip() != "❯":
            out.append("❯ ")
            stripped += 1
        else:
            out.append(line)
    if stripped:
        _log({"ts": time.time(), "window": window, "paint_stripped": stripped})
    return "\n".join(out)


#: Consecutive send-refusals per window. A refused payload is not a
#: transient error — the gate is deterministic, so the same input denies
#: forever. Without this the idle sweep re-composed element115's message
#: every ~40s and burned a full model generation on each one, 24 minutes
#: straight, all denied. Failure has to cost less than success.
_refusals: dict[str, int] = {}
REFUSAL_CUTOFF = int(os.environ.get("LEON_TERM_REFUSAL_CUTOFF", "3"))


def run_round(watcher: TerminalWatcher, ev: TerminalEvent, threads: dict) -> bool:
    """One full round: read → compose → send. True if a reply went out."""
    th = threads.get(ev.window)
    if not th:
        return False
    if _refusals.get(ev.window, 0) >= REFUSAL_CUTOFF:
        _log({"ts": time.time(), "window": ev.window,
              "skipped": "refusal_cutoff", "count": _refusals[ev.window]})
        return False
    # ORDERING BUG, fixed 2026-08-03. The refill below was UNREACHABLE: hitting
    # the ceiling sets active=False, and the old `if not th.get("active")` guard
    # sat ABOVE the refill and returned first. So the budget could be spent
    # exactly once per lifetime and the "it refills" comment described code that
    # could never run. The refill now happens before the active check, which is
    # the only ordering in which a refill means anything.
    # The ceiling is a spend guard, not a death sentence. Twice on 2026-08-02
    # the loop hit 12 rounds and then sat logging max_rounds for 90 minutes
    # while looking perfectly healthy — alive and mute, the exact failure mode
    # this whole project exists to catch. So the budget refills: rounds reset
    # once a pane has been quiet for ROUND_RESET_S. Bounded per window, not
    # bounded per lifetime.
    if (th.get("rounds", 0) >= MAX_ROUNDS
            and time.time() - th.get("last_sent", 0) >= ROUND_RESET_S):
        _log({"ts": time.time(), "window": ev.window,
              "rounds_reset": th.get("rounds", 0),
              "quiet_s": round(time.time() - th.get("last_sent", 0))})
        th["rounds"] = 0
        th["active"] = True
        threads[ev.window] = th
        _save_threads(threads)
    if not th.get("active"):
        return False
    if th.get("rounds", 0) >= MAX_ROUNDS:
        _log({"ts": time.time(), "window": ev.window, "skipped": "max_rounds"})
        th["active"] = False
        return False
    if time.time() - th.get("last_sent", 0) < MIN_GAP_S:
        return False

    reply = compose_reply(ev.window, strip_paint(ev.window, ev.text),
                          th.get("topic", ""), th.get("rounds", 0) + 1)
    if not reply:
        _log({"ts": time.time(), "window": ev.window, "skipped": "no_reply"})
        return False

    ok = watcher.send(ev.window, reply)
    if not ok:
        # SILENT RETURN, fixed 2026-08-03. send() refuses through the payload
        # gate and escalates to autoloop_escalations.jsonl — a file nobody
        # reads at a glance. This log, the one Dean actually looks at, showed
        # idle_nudge after idle_nudge with no reason attached, so the loop
        # read as doing nothing when it was in fact being denied 30 times.
        # A refusal is an event. It gets a row here too.
        _refusals[ev.window] = _refusals.get(ev.window, 0) + 1
        _log({"ts": time.time(), "window": ev.window, "skipped": "send_refused",
              "consecutive": _refusals[ev.window], "payload_len": len(reply),
              "payload_preview": reply[:200]})
        return False
    _refusals.pop(ev.window, None)

    th["rounds"] = th.get("rounds", 0) + 1
    th["last_sent"] = time.time()
    threads[ev.window] = th
    _save_threads(threads)
    _log({"ts": time.time(), "window": ev.window, "round": th["rounds"],
          "sent": reply})
    return True


def start_thread(window: str, topic: str) -> None:
    threads = _load_threads()
    threads[window] = {"topic": topic, "rounds": 0, "last_sent": 0.0,
                       "active": True}
    _save_threads(threads)


def stop_thread(window: str) -> None:
    threads = _load_threads()
    if window in threads:
        threads[window]["active"] = False
        _save_threads(threads)


def idle_sweep(watcher: TerminalWatcher, threads: dict) -> int:
    """Fire rounds on threads that have gone quiet, with no pane event.

    THE DEADLOCK THIS FIXES, found 2026-08-03 07:05 with Dean watching.
    run_round() holds the round-budget refill — but run_round() is only
    ever called from the event loop below, and the event loop only fires
    when a pane's screen CHANGES. So: pane finishes its last turn, goes
    quiet, produces no further events, the loop never ticks that window,
    the refill never runs, and nothing is ever sent again. The rescue was
    gated behind the exact condition it existed to rescue. element115 sat
    at rounds=12/last_sent=05:50 for 73 straight minutes this way and
    looked perfectly healthy the whole time — alive and mute, again.

    A reactive loop cannot restart a conversation that has stopped. This
    sweep is the self-starting half: it synthesises an event from the
    pane's current screen so an idle thread gets a turn on the clock
    rather than on someone else's activity.
    """
    fired = 0
    now = time.time()
    for window, th in list(threads.items()):
        if not _window_allowed(window):
            continue
        quiet = now - th.get("last_sent", 0.0)
        # A thread switched off BY THE CEILING is still eligible — that's
        # the whole point of a refillable budget. Only a thread stopped
        # deliberately (stop_thread, rounds under the cap) stays off.
        ceilinged = th.get("rounds", 0) >= MAX_ROUNDS
        if not th.get("active") and not ceilinged:
            continue
        if quiet < IDLE_NUDGE_S:
            continue
        text = capture(window)
        # A pane mid-thought isn't idle, it's working. Leave it alone.
        if is_busy(text):
            continue
        ev = TerminalEvent(window=window, text=text, digest=_digest(text),
                           detected_at=now, quiet_for_s=quiet)
        _log({"ts": now, "window": window, "idle_nudge": round(quiet)})
        if run_round(watcher, ev, threads):
            fired += 1
    return fired


#: WINDOW ALLOWLIST, set 2026-08-03 by Dean after a token audit.
#: Four opus panes looping unattended burned ~333M weighted tokens in six
#: days — element115 alone was 160M. Dean only ever wanted the loop on the
#: research-lab journal pane. Everything else gets consumed, never answered.
#: Set LEON_AUTOLOOP_WINDOWS="a,b" to change; "*" disables the allowlist.
ALLOWED_WINDOWS = [
    w.strip()
    for w in os.environ.get("LEON_AUTOLOOP_WINDOWS", "element115").split(",")
    if w.strip()
]


def _window_allowed(window: str) -> bool:
    return "*" in ALLOWED_WINDOWS or window in ALLOWED_WINDOWS


def serve(poll_s: float = 5.0) -> None:
    watcher = TerminalWatcher()
    _log({"ts": time.time(), "boot": "autoloop", "allowed_windows": ALLOWED_WINDOWS})
    while True:
        try:
            threads = _load_threads()
            # poll() only returns events that are NOT already sitting in
            # the pending file. Events banked by an earlier watcher (or
            # by this one before a restart) live in pending() and would
            # otherwise never be answered — that exact gap made the loop
            # look alive and do nothing on its first run.
            batch = watcher.pending() + watcher.poll()
            seen_windows = set()
            for ev in batch:
                if ev.window in seen_windows:
                    continue          # newest per window only, per pass
                seen_windows.add(ev.window)
                if not _window_allowed(ev.window):
                    # Not on the allowlist: drain it so it never re-fires,
                    # and never spend a turn on it.
                    watcher.consume(ev)
                    _log({"ts": time.time(), "window": ev.window,
                          "skipped": "not_allowlisted"})
                    continue
                if run_round(watcher, ev, threads):
                    watcher.consume(ev)
                else:
                    # Consume anyway so a pane we're not threading with
                    # doesn't re-fire forever.
                    if ev.window not in threads or not threads[ev.window].get("active"):
                        watcher.consume(ev)
            # Runs every pass, event or no event. This is the only path
            # that can restart a conversation nobody is talking in.
            idle_sweep(watcher, threads)
        except Exception as e:
            _log({"ts": time.time(), "error": repr(e)})
        time.sleep(poll_s)


if __name__ == "__main__":
    serve()
