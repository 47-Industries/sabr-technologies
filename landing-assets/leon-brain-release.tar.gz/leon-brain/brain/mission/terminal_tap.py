"""Awareness tap — Leon learns that a terminal replied. It does NOT act.

Dean's literal complaint, five times on 2026-08-05: "the terminal answered and
I did not know it had answered." That is not a stall — the autoloop was working
fine — it is blindness. terminal_bridge covers STALLS; this covers BLINDNESS.

THREE HARD RULES:
  * READ-ONLY on the shared queue. It never consumes and never writes the
    autoloop's pending-events file. Its own cursor, its own log.
    (Phrased without naming those symbols on purpose — the test that
    guards this scans the source for them, and prose would trip it.)
  * NEVER SPEAKS. It appends awareness rows and returns. No TTS, no dashboard
    push, no queue write, no interrupt. It makes Leon AWARE; it does not make
    him interrupt Dean.
  * EMITTED AT CREATION. note_events() is called from TerminalWatcher.poll()
    the moment an event is built, because the autoloop consumes the ones it
    answers and a poller would miss exactly those.
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

STATE_DIR = os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
TAP_PATH = os.path.join(STATE_DIR, "terminal_awareness.jsonl")
CURSOR_PATH = os.path.join(STATE_DIR, "terminal_tap_cursor.json")
MAX_ROWS = int(os.environ.get("LEON_TAP_MAX_ROWS", "2000"))


def _summarise(text: str, limit: int = 300) -> str:
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    tail = " / ".join(lines[-3:])
    return tail[:limit] + ("…" if len(tail) > limit else "")


def note_events(events) -> int:
    """Append one awareness row per freshly-detected event. Cheap and silent."""
    from brain.mission import terminal_loop as tl
    n = 0
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(TAP_PATH, "a") as fh:
            for ev in events:
                text = getattr(ev, "text", "") or ""
                fh.write(json.dumps({
                    "ts": time.time(),
                    "detected_at": getattr(ev, "detected_at", None),
                    "window": getattr(ev, "window", "?"),
                    "digest": getattr(ev, "digest", "")[:16],
                    "summary": _summarise(text),
                    "chars": len(text),
                    "was_busy": tl.is_busy(text),
                    # Recorded, never acted on. Awareness only.
                    "spoken": False,
                }) + "\n")
                n += 1
    except Exception:
        return n
    return n


def unseen(limit: int = 20) -> list:
    """Awareness rows Leon has not been shown yet. Advances nothing."""
    try:
        with open(TAP_PATH) as fh:
            rows = [json.loads(l) for l in fh if l.strip()]
    except Exception:
        return []
    try:
        with open(CURSOR_PATH) as fh:
            seen = set(json.load(fh).get("digests", []))
    except Exception:
        seen = set()
    out = [r for r in rows if r.get("digest") not in seen and not r.get("was_busy")]
    return out[-limit:]


def mark_seen(rows) -> None:
    """Advance the tap's OWN cursor. Touches nothing the autoloop depends on."""
    try:
        try:
            with open(CURSOR_PATH) as fh:
                seen = list(json.load(fh).get("digests", []))
        except Exception:
            seen = []
        seen.extend(r.get("digest") for r in rows if r.get("digest"))
        seen = seen[-MAX_ROWS:]
        tmp = CURSOR_PATH + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({"digests": seen}, fh)
        os.replace(tmp, CURSOR_PATH)
    except Exception:
        pass
