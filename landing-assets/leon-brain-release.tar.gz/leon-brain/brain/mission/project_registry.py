"""
Project Registry — persistent project records in brain_state/projects.db.

Each project stores: name, bundle IDs, domains, repo URLs, backend URLs,
Apple app IDs, RevenueCat project IDs, Codemagic workflow IDs, environments,
active flags, owners, deployment targets, required credentials, known blockers,
pending decisions, current operational state.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
import uuid
from typing import Any, Optional

log = logging.getLogger("leon.mission.project_registry")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")

_SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL UNIQUE,
    slug            TEXT NOT NULL UNIQUE,
    active          INTEGER NOT NULL DEFAULT 1,
    -- identifiers
    bundle_ids      TEXT DEFAULT '[]',       -- JSON array
    domains         TEXT DEFAULT '[]',
    repo_urls       TEXT DEFAULT '[]',
    backend_urls    TEXT DEFAULT '[]',
    apple_app_ids   TEXT DEFAULT '{}',       -- JSON dict {platform: id}
    revenuecat_ids  TEXT DEFAULT '{}',       -- JSON dict
    codemagic_ids   TEXT DEFAULT '{}',       -- JSON dict {workflow_name: id}
    -- operational
    environments    TEXT DEFAULT '[]',       -- ["dev","staging","prod"]
    owners          TEXT DEFAULT '[]',
    deployment_targets TEXT DEFAULT '[]',
    required_creds  TEXT DEFAULT '[]',       -- ["APPLE_API_KEY","REVENUECAT_SECRET",...]
    known_blockers  TEXT DEFAULT '[]',       -- JSON array of {description, severity, created}
    pending_decisions TEXT DEFAULT '[]',     -- JSON array of decision IDs
    operational_state TEXT DEFAULT 'unknown', -- unknown|setup|active|paused|archived
    -- metadata
    description     TEXT DEFAULT '',
    notes           TEXT DEFAULT '',
    tags            TEXT DEFAULT '[]',
    created_at      REAL NOT NULL,
    updated_at      REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS project_events (
    id          TEXT PRIMARY KEY,
    project_id  TEXT NOT NULL REFERENCES projects(id),
    event_type  TEXT NOT NULL,   -- created|updated|blocker_added|blocker_resolved|state_changed
    detail      TEXT DEFAULT '',
    created_at  REAL NOT NULL
);
"""

_JSON_FIELDS = {
    "bundle_ids", "domains", "repo_urls", "backend_urls",
    "apple_app_ids", "revenuecat_ids", "codemagic_ids",
    "environments", "owners", "deployment_targets", "required_creds",
    "known_blockers", "pending_decisions", "tags",
}


def _slugify(name: str) -> str:
    return name.lower().replace(" ", "-").replace("_", "-")


def _decode_row(row: sqlite3.Row) -> dict:
    d = dict(row)
    for f in _JSON_FIELDS:
        if f in d and isinstance(d[f], str):
            try:
                d[f] = json.loads(d[f])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


class ProjectRegistry:
    def __init__(self, db_path: str | None = None):
        self.db_path = os.path.abspath(db_path or DB_PATH)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        log.info("ProjectRegistry ready — db=%s", self.db_path)

    # ── CRUD ────────────────────────────────────────────────────────────

    def create(self, name: str, **kwargs) -> dict:
        pid = uuid.uuid4().hex[:12]
        slug = _slugify(name)
        now = time.time()
        fields = {
            "id": pid, "name": name, "slug": slug,
            "created_at": now, "updated_at": now,
        }
        for k, v in kwargs.items():
            if k in _JSON_FIELDS:
                fields[k] = json.dumps(v) if not isinstance(v, str) else v
            elif k in ("active", "operational_state", "description", "notes"):
                fields[k] = v
        cols = ", ".join(fields.keys())
        placeholders = ", ".join(["?"] * len(fields))
        self._conn.execute(f"INSERT INTO projects ({cols}) VALUES ({placeholders})", list(fields.values()))
        self._log_event(pid, "created", f"Project '{name}' created")
        self._conn.commit()
        return self.get(pid)

    def get(self, project_id: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        return _decode_row(row) if row else None

    def get_by_name(self, name: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM projects WHERE name = ? OR slug = ?",
            (name, _slugify(name))
        ).fetchone()
        return _decode_row(row) if row else None

    def list_all(self, active_only: bool = False) -> list[dict]:
        q = "SELECT * FROM projects"
        if active_only:
            q += " WHERE active = 1"
        q += " ORDER BY name"
        return [_decode_row(r) for r in self._conn.execute(q).fetchall()]

    def update(self, project_id: str, **kwargs) -> dict | None:
        proj = self.get(project_id)
        if not proj:
            return None
        sets = []
        vals = []
        changes = []
        for k, v in kwargs.items():
            if k in ("id", "created_at"):
                continue
            if k in _JSON_FIELDS:
                sets.append(f"{k} = ?")
                vals.append(json.dumps(v) if not isinstance(v, str) else v)
            elif k in ("name", "slug", "active", "operational_state", "description", "notes"):
                sets.append(f"{k} = ?")
                vals.append(v)
            changes.append(k)
        if not sets:
            return proj
        sets.append("updated_at = ?")
        vals.append(time.time())
        vals.append(project_id)
        self._conn.execute(f"UPDATE projects SET {', '.join(sets)} WHERE id = ?", vals)
        self._log_event(project_id, "updated", f"Fields changed: {', '.join(changes)}")
        self._conn.commit()
        return self.get(project_id)

    def delete(self, project_id: str) -> bool:
        cur = self._conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ── Blockers ────────────────────────────────────────────────────────

    def add_blocker(self, project_id: str, description: str, severity: str = "medium") -> dict | None:
        proj = self.get(project_id)
        if not proj:
            return None
        blockers = proj.get("known_blockers", [])
        blocker = {"id": uuid.uuid4().hex[:8], "description": description, "severity": severity,
                    "created": time.time(), "resolved": False}
        blockers.append(blocker)
        self.update(project_id, known_blockers=blockers)
        self._log_event(project_id, "blocker_added", description)
        return blocker

    def resolve_blocker(self, project_id: str, blocker_id: str) -> bool:
        proj = self.get(project_id)
        if not proj:
            return False
        blockers = proj.get("known_blockers", [])
        for b in blockers:
            if b.get("id") == blocker_id:
                b["resolved"] = True
                b["resolved_at"] = time.time()
                self.update(project_id, known_blockers=blockers)
                self._log_event(project_id, "blocker_resolved", b["description"])
                return True
        return False

    # ── Events ──────────────────────────────────────────────────────────

    def _log_event(self, project_id: str, event_type: str, detail: str = ""):
        self._conn.execute(
            "INSERT INTO project_events (id, project_id, event_type, detail, created_at) VALUES (?,?,?,?,?)",
            (uuid.uuid4().hex[:12], project_id, event_type, detail, time.time()),
        )

    def events(self, project_id: str, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM project_events WHERE project_id = ? ORDER BY created_at DESC LIMIT ?",
            (project_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Summary ─────────────────────────────────────────────────────────

    def summary(self) -> dict:
        projects = self.list_all()
        active = [p for p in projects if p.get("active")]
        all_blockers = []
        for p in active:
            for b in p.get("known_blockers", []):
                if not b.get("resolved"):
                    all_blockers.append({"project": p["name"], **b})
        return {
            "total_projects": len(projects),
            "active_projects": len(active),
            "total_open_blockers": len(all_blockers),
            "blockers": all_blockers,
            "states": {p["name"]: p.get("operational_state", "unknown") for p in active},
        }
