"""
Phase 17 — Guarded Autonomy: 4-tier action classification, execution,
pre-action snapshots, rollback, and full audit trail.

TIER 1 — AUTO_ALLOWED:     read-only checks, status scans, evidence gathering
TIER 2 — AUTO_WITH_ROLLBACK: local edits with snapshot/rollback capability
TIER 3 — APPROVAL_REQUIRED: push, merge, deploy, billing, secrets, public actions
TIER 4 — BLOCKED:           credential exposure, destructive ops, safety bypass
"""
from __future__ import annotations

import copy
import hashlib
import json
import logging
import os
import shutil
import sqlite3
import subprocess
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum, IntEnum
from typing import Any, Callable, Optional

log = logging.getLogger("leon.mission.autonomy")

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "projects.db")


class Tier(IntEnum):
    AUTO_ALLOWED = 1
    AUTO_WITH_ROLLBACK = 2
    APPROVAL_REQUIRED = 3
    BLOCKED = 4


class ActionStatus(Enum):
    PENDING = "pending"
    EXECUTING = "executing"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    BLOCKED = "blocked"


# ── Granular action classification ──────────────────────────────────────

_TIER1_ACTIONS = {
    # read-only checks
    "check_status", "health_check", "get_info", "list_items", "view_pr",
    "view_build", "check_creds", "check_version", "check_dns", "scan_environment",
    "github_pr_status", "github_workflow_status", "github_repo_info",
    "codemagic_build_status", "revenuecat_read", "asc_read",
    "backend_health", "backend_version", "terminal_status", "git_status",
    "git_branch_list", "git_log", "read_logs", "read_journal",
    "workspace_summary", "blocker_detect", "next_action_generate",
    "create_local_note", "create_report", "update_mission_state",
    "mark_checklist_evidence", "npm_test", "npm_lint", "run_smoke_test",
    "credential_scan", "decision_scan", "project_scan",
}

_TIER2_ACTIONS = {
    # local edits with rollback
    "local_config_edit", "local_code_fix", "create_branch", "commit_feature_branch",
    "regenerate_report", "update_project_metadata", "restart_dev_service",
    "apply_self_repair_patch", "run_local_test_suite", "update_local_env",
    "fix_lint_errors", "format_code", "update_dependencies_local",
}

_TIER3_ACTIONS = {
    # approval required
    "push_code", "merge_pr", "deploy_production", "deploy_staging",
    "modify_asc_record", "create_iap", "modify_iap", "modify_revenuecat",
    "modify_secrets", "send_email", "send_message", "send_notification",
    "billing_action", "payment_action", "delete_file", "delete_resource",
    "change_main_branch", "install_global_package", "disable_safety",
    "trigger_ci_build", "create_paid_resource", "modify_apple_config",
}

_TIER4_ACTIONS = {
    # blocked — never autonomous
    "expose_credentials", "bypass_safety", "delete_production_data",
    "drop_database", "change_billing", "move_payment", "destructive_shell",
    "disable_audit_log", "impersonate", "spam", "affect_client_accounts",
    "force_push_main", "revoke_certificate", "wipe_data",
}

# Keyword fallback (ordered most restrictive first)
_KEYWORD_TIERS = [
    (Tier.BLOCKED, ["expose_cred", "bypass_safe", "drop_", "wipe", "force_push",
                     "impersonate", "spam", "disable_audit"]),
    (Tier.APPROVAL_REQUIRED, ["push", "merge", "deploy", "delete", "send_",
                               "modify_secret", "install_global", "billing",
                               "payment", "disable", "iap", "trigger_ci"]),
    (Tier.AUTO_WITH_ROLLBACK, ["edit", "fix", "patch", "commit_feature",
                                "create_branch", "restart_dev", "format",
                                "update_local", "regenerate"]),
    (Tier.AUTO_ALLOWED, ["check", "get", "list", "view", "scan", "read",
                          "fetch", "ping", "status", "health", "detect",
                          "generate_report", "summarize", "mark_"]),
]


def classify(action_name: str) -> Tier:
    """Classify an action into a guarded autonomy tier."""
    if action_name in _TIER1_ACTIONS:
        return Tier.AUTO_ALLOWED
    if action_name in _TIER2_ACTIONS:
        return Tier.AUTO_WITH_ROLLBACK
    if action_name in _TIER3_ACTIONS:
        return Tier.APPROVAL_REQUIRED
    if action_name in _TIER4_ACTIONS:
        return Tier.BLOCKED
    # Keyword fallback
    al = action_name.lower()
    for tier, keywords in _KEYWORD_TIERS:
        for kw in keywords:
            if kw in al:
                return tier
    # Conservative default
    return Tier.APPROVAL_REQUIRED


# ── Action record ───────────────────────────────────────────────────────

@dataclass
class Action:
    id: str = ""
    project_id: str = ""
    action_name: str = ""
    tier: int = 3
    status: str = "pending"
    description: str = ""
    evidence: str = ""          # JSON string of evidence collected
    rollback_plan: str = ""     # how to undo
    snapshot_path: str = ""     # file path to pre-action snapshot if any
    result: str = ""            # outcome
    error: str = ""
    created_at: float = 0.0
    started_at: float = 0.0
    completed_at: float = 0.0
    approved_by: str = ""
    approved_at: float = 0.0

    def __post_init__(self):
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        if not self.created_at:
            self.created_at = time.time()


# ── Schema ──────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS autopilot_actions (
    id              TEXT PRIMARY KEY,
    project_id      TEXT,
    action_name     TEXT NOT NULL,
    tier            INTEGER NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',
    description     TEXT DEFAULT '',
    evidence        TEXT DEFAULT '',
    rollback_plan   TEXT DEFAULT '',
    snapshot_path   TEXT DEFAULT '',
    result          TEXT DEFAULT '',
    error           TEXT DEFAULT '',
    created_at      REAL NOT NULL,
    started_at      REAL DEFAULT 0,
    completed_at    REAL DEFAULT 0,
    approved_by     TEXT DEFAULT '',
    approved_at     REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS autopilot_daily_reports (
    id          TEXT PRIMARY KEY,
    date_str    TEXT NOT NULL UNIQUE,
    report      TEXT NOT NULL,   -- JSON
    created_at  REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_actions_status ON autopilot_actions(status);
CREATE INDEX IF NOT EXISTS idx_actions_project ON autopilot_actions(project_id);
CREATE INDEX IF NOT EXISTS idx_actions_tier ON autopilot_actions(tier);
"""

_SNAPSHOT_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "brain_state", "autopilot_snapshots")


# ── Action Executor ─────────────────────────────────────────────────────

class ActionExecutor:
    """Execute actions according to their tier with full audit trail."""

    def __init__(self, db_path: str | None = None):
        self.db_path = os.path.abspath(db_path or DB_PATH)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        os.makedirs(_SNAPSHOT_DIR, exist_ok=True)
        self._handlers: dict[str, Callable] = {}
        log.info("ActionExecutor ready")

    def register_handler(self, action_name: str, handler: Callable):
        """Register a callable for an action. Handler receives (action, context) -> dict."""
        self._handlers[action_name] = handler

    def submit(self, action_name: str, project_id: str = "",
               description: str = "", rollback_plan: str = "",
               context: dict | None = None) -> Action:
        """Submit an action for execution. Tier determines behavior."""
        tier = classify(action_name)
        action = Action(
            project_id=project_id,
            action_name=action_name,
            tier=tier.value,
            description=description,
            rollback_plan=rollback_plan,
        )

        if tier == Tier.BLOCKED:
            action.status = ActionStatus.BLOCKED.value
            action.error = "Action is BLOCKED by safety policy"
            self._persist(action)  # always log blocked attempts
            log.warning("BLOCKED action: %s", action_name)
            return action

        if tier == Tier.APPROVAL_REQUIRED:
            action.status = ActionStatus.AWAITING_APPROVAL.value
            self._persist(action)  # always log approval requests
            log.info("Queued for approval: %s", action_name)
            return action

        # Tier 1 or 2: execute
        result = self._execute(action, context or {})
        # Only persist Tier 1 if it FAILED — routine successes are noise
        if tier == Tier.AUTO_ALLOWED and result.status == ActionStatus.SUCCEEDED.value:
            pass  # don't persist — saves ~8K rows/day
        return result

    def approve(self, action_id: str, approved_by: str = "Dean") -> Action | None:
        """Approve a Tier 3 action and execute it."""
        action = self.get(action_id)
        if not action:
            return None
        if action.status != ActionStatus.AWAITING_APPROVAL.value:
            return action
        action.status = ActionStatus.APPROVED.value
        action.approved_by = approved_by
        action.approved_at = time.time()
        self._persist(action)
        return self._execute(action, {})

    def reject(self, action_id: str, reason: str = "") -> Action | None:
        """Reject a Tier 3 action."""
        action = self.get(action_id)
        if not action:
            return None
        action.status = ActionStatus.REJECTED.value
        action.error = reason or "Rejected by operator"
        action.completed_at = time.time()
        self._persist(action)
        return action

    def rollback(self, action_id: str) -> Action | None:
        """Roll back a completed Tier 2 action using its snapshot."""
        action = self.get(action_id)
        if not action:
            return None
        if action.tier != Tier.AUTO_WITH_ROLLBACK.value:
            return action
        if action.snapshot_path and os.path.exists(action.snapshot_path):
            # Snapshot is a JSON file with pre-state
            try:
                with open(action.snapshot_path) as f:
                    _snapshot = json.load(f)
                # The rollback handler should be registered
                rb_handler = self._handlers.get(f"rollback_{action.action_name}")
                if rb_handler:
                    rb_handler(action, _snapshot)
                action.status = ActionStatus.ROLLED_BACK.value
                action.completed_at = time.time()
                self._persist(action)
                log.info("Rolled back: %s", action.id)
            except Exception as e:
                action.error = f"Rollback failed: {e}"
                self._persist(action)
        return action

    def _execute(self, action: Action, context: dict) -> Action:
        """Actually execute an action."""
        action.status = ActionStatus.EXECUTING.value
        action.started_at = time.time()
        skip_persist = (action.tier == Tier.AUTO_ALLOWED.value)
        if not skip_persist:
            self._persist(action)

        # Take snapshot for Tier 2
        if action.tier == Tier.AUTO_WITH_ROLLBACK.value:
            snapshot_path = os.path.join(_SNAPSHOT_DIR, f"{action.id}.json")
            try:
                snapshot_data = {"action": action.action_name, "project_id": action.project_id,
                                 "pre_state": context.get("pre_state", {}), "timestamp": time.time()}
                with open(snapshot_path, "w") as f:
                    json.dump(snapshot_data, f)
                action.snapshot_path = snapshot_path
            except Exception as e:
                log.warning("Snapshot failed for %s: %s", action.id, e)

        # Find and call handler
        handler = self._handlers.get(action.action_name)
        if not handler:
            action.status = ActionStatus.SUCCEEDED.value
            action.result = "No handler registered — action logged only"
            action.completed_at = time.time()
            if not skip_persist:
                self._persist(action)
            return action

        try:
            result = handler(action, context)
            action.status = ActionStatus.SUCCEEDED.value
            action.result = json.dumps(result) if isinstance(result, dict) else str(result)
            action.evidence = json.dumps(result.get("evidence", {})) if isinstance(result, dict) else ""
            # Tier 2: validate after execution
            if action.tier == Tier.AUTO_WITH_ROLLBACK.value:
                validation = result.get("validation_ok", True) if isinstance(result, dict) else True
                if not validation:
                    log.warning("Post-execution validation failed for %s, rolling back", action.id)
                    self.rollback(action.id)
                    return self.get(action.id) or action
        except Exception as e:
            action.status = ActionStatus.FAILED.value
            action.error = f"{type(e).__name__}: {e}"
            log.error("Action %s failed: %s", action.id, e)
            skip_persist = False  # always persist failures
            # Auto-rollback Tier 2 failures
            if action.tier == Tier.AUTO_WITH_ROLLBACK.value and action.snapshot_path:
                self.rollback(action.id)
                return self.get(action.id) or action

        action.completed_at = time.time()
        if not skip_persist:
            self._persist(action)
        return action

    # ── Persistence ─────────────────────────────────────────────────────

    def _persist(self, action: Action):
        self._conn.execute("""
            INSERT OR REPLACE INTO autopilot_actions
            (id, project_id, action_name, tier, status, description, evidence,
             rollback_plan, snapshot_path, result, error,
             created_at, started_at, completed_at, approved_by, approved_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (action.id, action.project_id, action.action_name, action.tier,
              action.status, action.description, action.evidence,
              action.rollback_plan, action.snapshot_path, action.result, action.error,
              action.created_at, action.started_at, action.completed_at,
              action.approved_by, action.approved_at))
        self._conn.commit()

    def get(self, action_id: str) -> Action | None:
        row = self._conn.execute(
            "SELECT * FROM autopilot_actions WHERE id = ?", (action_id,)
        ).fetchone()
        if not row:
            return None
        return Action(**{k: row[k] for k in row.keys()})

    def list_actions(self, status: str | None = None, project_id: str | None = None,
                     tier: int | None = None, limit: int = 100) -> list[dict]:
        q = "SELECT * FROM autopilot_actions WHERE 1=1"
        params: list = []
        if status:
            q += " AND status = ?"
            params.append(status)
        if project_id:
            q += " AND project_id = ?"
            params.append(project_id)
        if tier is not None:
            q += " AND tier = ?"
            params.append(tier)
        q += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        return [dict(r) for r in self._conn.execute(q, params).fetchall()]

    def pending_approvals(self) -> list[dict]:
        return self.list_actions(status=ActionStatus.AWAITING_APPROVAL.value)

    def recent_activity(self, limit: int = 50) -> list[dict]:
        return self.list_actions(limit=limit)

    def cleanup(self, max_age_days: int = 7):
        """Prune old succeeded actions and snapshots to prevent DB bloat."""
        cutoff = time.time() - (max_age_days * 86400)
        # Delete old succeeded Tier 1 actions (noise)
        cur = self._conn.execute(
            "DELETE FROM autopilot_actions WHERE tier = 1 AND status = 'succeeded' AND created_at < ?",
            (cutoff,),
        )
        deleted = cur.rowcount
        # Delete old succeeded Tier 2 actions (keep failures/approvals longer)
        cur2 = self._conn.execute(
            "DELETE FROM autopilot_actions WHERE tier = 2 AND status = 'succeeded' AND created_at < ?",
            (cutoff,),
        )
        deleted += cur2.rowcount
        # Clean up old snapshots
        if os.path.isdir(_SNAPSHOT_DIR):
            for f in os.listdir(_SNAPSHOT_DIR):
                fp = os.path.join(_SNAPSHOT_DIR, f)
                if os.path.isfile(fp) and (time.time() - os.path.getmtime(fp)) > max_age_days * 86400:
                    try:
                        os.remove(fp)
                    except Exception:
                        pass
        self._conn.commit()
        if deleted:
            log.info("Cleanup: pruned %d old actions", deleted)
        return {"pruned": deleted}

    def stats(self) -> dict:
        rows = self._conn.execute("""
            SELECT status, COUNT(*) as cnt FROM autopilot_actions GROUP BY status
        """).fetchall()
        by_status = {r["status"]: r["cnt"] for r in rows}
        tier_rows = self._conn.execute("""
            SELECT tier, COUNT(*) as cnt FROM autopilot_actions GROUP BY tier
        """).fetchall()
        by_tier = {r["tier"]: r["cnt"] for r in tier_rows}
        return {
            "total": sum(by_status.values()),
            "by_status": by_status,
            "by_tier": by_tier,
            "pending_approvals": by_status.get("awaiting_approval", 0),
        }

    # ── Daily report ────────────────────────────────────────────────────

    def generate_daily_report(self) -> dict:
        """Generate a daily operator report."""
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        cutoff = time.time() - 86400  # last 24h

        actions = self._conn.execute(
            "SELECT * FROM autopilot_actions WHERE created_at > ? ORDER BY created_at",
            (cutoff,),
        ).fetchall()
        actions = [dict(r) for r in actions]

        succeeded = [a for a in actions if a["status"] == "succeeded"]
        failed = [a for a in actions if a["status"] == "failed"]
        pending = [a for a in actions if a["status"] == "awaiting_approval"]
        blocked = [a for a in actions if a["status"] == "blocked"]
        rolled_back = [a for a in actions if a["status"] == "rolled_back"]

        projects_touched = list(set(a["project_id"] for a in actions if a["project_id"]))

        report = {
            "date": today,
            "total_actions": len(actions),
            "succeeded": len(succeeded),
            "failed": len(failed),
            "pending_approvals": len(pending),
            "blocked_attempts": len(blocked),
            "rolled_back": len(rolled_back),
            "projects_touched": projects_touched,
            "actions_by_tier": {},
            "top_actions": [],
            "failures": [{"id": a["id"], "action": a["action_name"],
                          "error": a["error"][:200]} for a in failed[:10]],
            "awaiting_approval": [{"id": a["id"], "action": a["action_name"],
                                    "description": a["description"][:200]} for a in pending],
        }

        # Count by tier
        for a in actions:
            t = str(a["tier"])
            report["actions_by_tier"][t] = report["actions_by_tier"].get(t, 0) + 1

        # Top action names
        name_counts: dict[str, int] = {}
        for a in actions:
            name_counts[a["action_name"]] = name_counts.get(a["action_name"], 0) + 1
        report["top_actions"] = sorted(name_counts.items(), key=lambda x: -x[1])[:10]

        # Persist
        self._conn.execute("""
            INSERT OR REPLACE INTO autopilot_daily_reports (id, date_str, report, created_at)
            VALUES (?, ?, ?, ?)
        """, (uuid.uuid4().hex[:12], today, json.dumps(report), time.time()))
        self._conn.commit()

        return report

    def get_daily_report(self, date_str: str | None = None) -> dict | None:
        from datetime import datetime
        if not date_str:
            date_str = datetime.now().strftime("%Y-%m-%d")
        row = self._conn.execute(
            "SELECT * FROM autopilot_daily_reports WHERE date_str = ?", (date_str,)
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["report"] = json.loads(d["report"]) if isinstance(d["report"], str) else d["report"]
        return d
