"""The send ledger — the only witness to `turn_owed` that isn't paint.

Nothing on a screen can tell you whether an agent OWES you a reply. A
finished pane and a stuck pane render identically, forever. The one fact
that separates them is what the loop itself did: it sent something, and
nothing came back. That fact lives here.

WRITE-AHEAD, AND THAT ORDERING IS THE WHOLE POINT.

Leon's instruction was to log the moment a send fires rather than on the
next tick, because a crash in between recreates the blindness one layer
down. Correct, and it goes one step further: log BEFORE the keystroke, not
after it. The two failure directions are not symmetric.

  * log after send, crash in between  → the send happened and we have no
    record of it. The pane owes a turn nobody knows about. That is exactly
    the silence this subsystem exists to remove, and it is undetectable.

  * log before send, crash in between → we have a record of a send that
    never landed. The pane appears to owe a turn it was never asked for, so
    the watchdog escalates, Dean looks, finds nothing was sent, and resends.
    Noisy, visible, recoverable.

A phantom debt costs a false alarm. A lost debt costs the failure mode. So
the record goes down first and is CONFIRMED afterwards, which also means
`delivered` is a field rather than an assumption — an unconfirmed row is a
send we cannot prove happened, and it says so.

Each row also pins the RECIPIENT, not just the pane: pid plus process start
time. A pane name is a mailbox that outlives its occupants, and a debt owed
by a process that no longer exists is not a debt this process can pay.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Optional

STATE_DIR = os.environ.get("LEON_BRAIN_STATE") or os.path.join(
    __import__("pathlib").Path(__file__).resolve().parents[2], "brain_state")
LEDGER_PATH = os.path.join(STATE_DIR, "send_ledger.jsonl")
PREVIEW_MAX = 80

OWED, NONE, ORPHANED = "owed", "none", "orphaned"


def _sha(t: str) -> str:
    return hashlib.sha256((t or "").encode("utf-8", "replace")).hexdigest()


def _preview(t: str) -> str:
    p = " ".join((t or "").split())
    return p[:PREVIEW_MAX] + ("…" if len(p) > PREVIEW_MAX else "")


def _append(row: dict) -> None:
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(LEDGER_PATH, "a") as fh:
        fh.write(json.dumps(row) + "\n")
        fh.flush()
        os.fsync(fh.fileno())     # write-ahead is not write-ahead if it is
                                  # sitting in a buffer when the process dies


def record_send(window: str, payload: str, pane_pid: Optional[int],
                proc_started_at: Optional[float],
                now: Optional[float] = None,
                gate: Optional[dict] = None) -> str:
    """Call BEFORE the keystroke. Returns send_id.

    Not exception-guarded, deliberately, and it is the only thing in this
    subsystem that isn't. Everywhere else instrumentation must never break
    the loop it observes; here, a send we failed to record is a debt that
    can never be collected, so failing to write is a reason not to send.
    """
    ts = time.time() if now is None else now
    send_id = _sha(f"{window}|{ts}|{payload}")[:16]
    _append({
        "ts": ts, "event": "send", "send_id": send_id, "window": window,
        "payload_sha256": _sha(payload), "payload_preview": _preview(payload),
        "payload_len": len(payload or ""),
        "pane_pid": pane_pid, "proc_started_at": proc_started_at,
        "delivered": False, "replied": False,
        # WHY THIS SEND WAS PERMITTED, not merely that it happened.
        # Added 2026-08-03: the ledger recorded pane_pid, proc_started_at,
        # delivered and replied — and NO gate verdict. So a wrong YES on the
        # yes-path would have looked exactly like a correct one: a normal send
        # row. That is the "answers correctly while gating nothing" failure one
        # level up — the record proved a send occurred and could not show
        # whether it should have. 94/94 refusals say nothing about this,
        # because a refusal writes an escalation row, not a send row.
        "gate": gate or {"recorded": False,
                         "why": "caller did not supply gate verdicts"},
    })
    return send_id


def mark(send_id: str, window: str, field: str, now: Optional[float] = None) -> None:
    """Append a state change. Append-only: the ledger is a log, not a table,
    so a torn write can never destroy the original record of the send."""
    _append({"ts": time.time() if now is None else now, "event": field,
             "send_id": send_id, "window": window})


def _replay(path: Optional[str] = None) -> dict:
    """Fold the log into per-send state. Later rows win."""
    sends: dict = {}
    try:
        with open(path or LEDGER_PATH) as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except Exception:
                    continue          # a torn final line loses one row, not the log
                sid = r.get("send_id")
                if not sid:
                    continue
                if r.get("event") == "send":
                    sends[sid] = dict(r)
                elif sid in sends:
                    sends[sid][r["event"]] = True
    except FileNotFoundError:
        pass
    return sends


def debt_status(window: str, proc_started_at: Optional[float],
                path: Optional[str] = None) -> tuple[str, Optional[dict]]:
    """(OWED | NONE | ORPHANED, the oldest unanswered send).

    ORPHANED is the answer to Leon's question, and it is mechanical rather
    than a judgement call: if the pane's process started AFTER the send was
    recorded, the process that received the send no longer exists. The
    current occupant was never asked anything, so it cannot be wedged — but
    the instruction was genuinely lost, which is a fault in its own right and
    must not be silently cleared.

    Note this uses process START TIME, not a pid change. Detecting a restart
    by watching pid change requires that WE were observing across it; start
    time is absolute and survives our own restarts, crashes, and cold boots.
    Decision 16 said observe the process instead of timing the gap — this is
    the same rule applied to the ledger rather than to the screen.
    """
    unanswered = [s for s in _replay(path).values()
                  if s.get("window") == window and not s.get("replied")]
    if not unanswered:
        return NONE, None
    oldest = min(unanswered, key=lambda s: s["ts"])
    if proc_started_at is not None and proc_started_at > oldest["ts"]:
        return ORPHANED, oldest
    return OWED, oldest
