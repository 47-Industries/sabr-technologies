"""
Project Context Crawler — walks Dean's ~/Desktop and slurps every project's
README, CLAUDE.md, and SESSION_LOG.md into the knowledge_store so Leon
"knows" what Dean's working on without burning tokens on a fresh re-read
every conversation.

Idempotent: each file is hashed; unchanged files are skipped on re-runs.
Run on server boot in a background thread (cheap — only the first cold
crawl actually touches Claude-side context; later runs no-op).

Each file becomes ONE knowledge entry tagged like:
  ["project", "<dirname>", "<filetype>"]
so a search for "what's MotoRev" can pull the README of ~/Desktop/motorev/
without scanning the whole DB.

Heads-up:
- Any node_modules / .git / .venv / dist / build dir is skipped wholesale.
- Files larger than 200KB are truncated (Leon doesn't need a 30k-line log).
- Symlinks are not followed — keeps us from chasing into unrelated trees.
"""

from __future__ import annotations

import hashlib
import os
import threading
import time
from typing import Iterable, List, Optional

# Files we always want — top-priority project context
PRIMARY_FILES = (
    "README.md", "README", "README.txt",
    "CLAUDE.md", "CLAUDE.MD",
    "SESSION_LOG.md", "SESSION_LOG.MD",
    "ROADMAP.md", "ARCHITECTURE.md",
)

# Directory names that explode storage / contain no useful context
SKIP_DIRS = frozenset({
    "node_modules", ".git", ".svn", ".hg", ".venv", "venv", "env",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "dist", "build", ".next", ".nuxt", ".cache", ".idea", ".vscode",
    "target", ".gradle", ".cargo", "vendor", "Pods",
})

MAX_FILE_BYTES = 200_000
MAX_DEPTH = 3            # how deep into each project we recurse
RECRAWL_INTERVAL = 6 * 3600  # 6h — re-walk to pick up new SESSION_LOG entries


def _safe_read(path: str, max_bytes: int = MAX_FILE_BYTES) -> Optional[str]:
    """Read a file as UTF-8, truncated. Returns None if unreadable."""
    try:
        sz = os.path.getsize(path)
        with open(path, "rb") as f:
            data = f.read(max_bytes)
        text = data.decode("utf-8", errors="replace")
        if sz > max_bytes:
            text += f"\n\n…[truncated, original was {sz} bytes]"
        return text
    except Exception:
        return None


def _hash(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", errors="replace")).hexdigest()[:16]


def _walk_project(project_dir: str, max_depth: int = MAX_DEPTH) -> Iterable[str]:
    """Yield absolute paths of context files under project_dir."""
    base_depth = project_dir.rstrip(os.sep).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(project_dir, followlinks=False):
        # Prune SKIP_DIRS in place so os.walk doesn't descend
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        depth = dirpath.count(os.sep) - base_depth
        if depth > max_depth:
            dirnames[:] = []
            continue
        for fn in filenames:
            if fn in PRIMARY_FILES:
                yield os.path.join(dirpath, fn)


class ProjectCrawler:
    """Crawls ~/Desktop/* and feeds project docs into knowledge_store."""

    def __init__(
        self,
        knowledge_store,
        roots: Optional[List[str]] = None,
        recrawl_interval: int = RECRAWL_INTERVAL,
    ):
        self.knowledge_store = knowledge_store
        self.roots = roots or [os.path.expanduser("~/Desktop")]
        self.recrawl_interval = recrawl_interval
        # path → content hash, so we skip re-storing unchanged files. Seeded
        # from any existing project_crawler rows in the DB so a fresh server
        # boot doesn't churn through every file again.
        self._seen: dict[str, str] = {}
        self._seed_seen_from_db()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self.last_run: float = 0.0
        self.files_indexed: int = 0
        self.files_skipped: int = 0

    # ── Idempotency helpers ──────────────────────────────────────────────
    def _seed_seen_from_db(self) -> None:
        """Populate _seen from existing project_crawler rows. Each row's
        text starts with '# Project: <name> — <fname>\\n\\n<content>' so
        we recompute the hash on the original content portion."""
        if not hasattr(self.knowledge_store, "db_path"):
            return
        try:
            import sqlite3
            with sqlite3.connect(self.knowledge_store.db_path, timeout=10) as conn:
                rows = conn.execute(
                    "SELECT json_extract(metadata, '$.source_path'), text "
                    "FROM knowledge WHERE source = 'project_crawler'"
                ).fetchall()
            for src_path, text in rows:
                if not src_path:
                    continue
                # Strip the synthetic header we added on store
                marker = "\n\n"
                idx = text.find(marker)
                content = text[idx + len(marker):] if idx >= 0 else text
                self._seen[src_path] = _hash(content)
            print(f"[CRAWL] seeded _seen with {len(self._seen)} prior paths")
        except Exception as e:
            print(f"[CRAWL] _seed_seen_from_db: {e}")

    def _delete_prior_for_path(self, source_path: str) -> int:
        """Drop any existing project_crawler rows that point to the same
        on-disk file. Lets us rebuild the row each crawl without piling
        up duplicates across server restarts."""
        if not hasattr(self.knowledge_store, "db_path"):
            return 0
        try:
            import sqlite3
            with sqlite3.connect(self.knowledge_store.db_path, timeout=10) as conn:
                c = conn.cursor()
                c.execute(
                    "DELETE FROM knowledge "
                    "WHERE source = 'project_crawler' "
                    "  AND json_extract(metadata, '$.source_path') = ?",
                    (source_path,),
                )
                # Mirror the delete into the FTS shadow table if present.
                try:
                    c.execute(
                        "DELETE FROM knowledge_fts "
                        "WHERE rowid NOT IN (SELECT id FROM knowledge)"
                    )
                except sqlite3.OperationalError:
                    pass
                conn.commit()
                return c.rowcount or 0
        except Exception as e:
            print(f"[CRAWL] _delete_prior_for_path: {e}")
            return 0

    # ── Manual one-shot crawl ─────────────────────────────────────────────
    def crawl_once(self) -> dict:
        """Walk all roots once. Returns a stats dict."""
        new_count = 0
        unchanged_count = 0
        scanned = 0
        for root in self.roots:
            if not os.path.isdir(root):
                continue
            try:
                projects = sorted(
                    p for p in os.listdir(root)
                    if os.path.isdir(os.path.join(root, p))
                    and p not in SKIP_DIRS
                    and not p.startswith(".")
                )
            except PermissionError:
                continue
            for proj in projects:
                proj_dir = os.path.join(root, proj)
                for path in _walk_project(proj_dir):
                    scanned += 1
                    text = _safe_read(path)
                    if not text:
                        continue
                    h = _hash(text)
                    if self._seen.get(path) == h:
                        unchanged_count += 1
                        continue
                    fname = os.path.basename(path)
                    ftype = (
                        "session_log" if "SESSION_LOG" in fname.upper()
                        else "claude_md" if "CLAUDE" in fname.upper()
                        else "roadmap" if "ROADMAP" in fname.upper()
                        else "architecture" if "ARCHITECTURE" in fname.upper()
                        else "readme"
                    )
                    tags = ["project", proj, ftype]
                    metadata = {
                        "project": proj,
                        "filetype": ftype,
                        "source_path": path,
                        "indexed_at": time.time(),
                        "size_bytes": len(text),
                    }
                    try:
                        # Delete any prior project_crawler entries for the
                        # same source_path BEFORE inserting. Keeps the DB
                        # idempotent even when the in-memory _seen cache
                        # is empty (e.g. fresh server boot).
                        self._delete_prior_for_path(path)
                        self.knowledge_store.store(
                            text=f"# Project: {proj} — {fname}\n\n{text}",
                            source="project_crawler",
                            tags=tags,
                            metadata=metadata,
                        )
                        self._seen[path] = h
                        new_count += 1
                    except Exception as e:
                        print(f"[CRAWL] failed to store {path}: {e}")
        self.last_run = time.time()
        self.files_indexed += new_count
        self.files_skipped += unchanged_count
        return {
            "scanned": scanned,
            "new_or_changed": new_count,
            "unchanged": unchanged_count,
            "ts": self.last_run,
        }

    # ── Background daemon ────────────────────────────────────────────────
    def start_background(self) -> None:
        """Run an immediate crawl, then re-crawl every recrawl_interval s."""
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="project-crawler",
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        # Small initial delay so server boot logs aren't drowned by us
        if self._stop.wait(timeout=4.0):
            return
        while not self._stop.is_set():
            try:
                stats = self.crawl_once()
                print(f"[CRAWL] indexed {stats['new_or_changed']} new/changed, "
                      f"{stats['unchanged']} unchanged across {stats['scanned']} files")
            except Exception as e:
                print(f"[CRAWL] error: {e}")
            if self._stop.wait(timeout=self.recrawl_interval):
                return

    # ── State for the dashboard ──────────────────────────────────────────
    def get_state(self) -> dict:
        return {
            "roots": self.roots,
            "files_indexed_total": self.files_indexed,
            "files_skipped_total": self.files_skipped,
            "last_run": self.last_run,
            "last_run_age": (time.time() - self.last_run) if self.last_run else -1,
            "tracked_paths": len(self._seen),
        }
