"""
Reminder scheduler — Leon's "ping me in 5 minutes" capability.

Lives in the brain server (not the actuator) because it owns the
persisted state and runs a long-lived scheduler thread. When a reminder
fires, it dispatches `notify` through the actuator client so Dean sees
a desktop notification AND optionally broadcasts a `reminder_fired` WS
event to the dashboard.

Persisted to brain_state/reminders.json. On boot, any reminders that
fired while the server was down are flushed immediately (so a 9am
"start workout" reminder still goes off if you booted at 9:30am).

Reminders are append-only by design — `cancel` marks the row as
cancelled rather than deleting it, so we have a paper trail.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional


@dataclass
class Reminder:
    id: str
    text: str
    due_ts: float            # absolute unix time
    created_ts: float
    title: str = "Leon"
    fired: bool = False
    fired_ts: float = 0.0
    cancelled: bool = False
    urgency: str = "normal"


# Quick natural-language duration parser. Handles "5m", "30s", "1h30m",
# "2h", "90 minutes", etc. Returns seconds, or None if unparseable.
_DURATION_RE = re.compile(
    r"(?P<num>\d+(?:\.\d+)?)\s*"
    r"(?P<unit>seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d)\b",
    re.IGNORECASE,
)
_UNIT_FACTORS = {
    "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
    "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
    "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
    "d": 86400, "day": 86400, "days": 86400,
}


def parse_duration(text: str) -> Optional[float]:
    """Parse '5m' / '1h30m' / '90 minutes' style strings to seconds.
    Sums all matched components (so '1h 5m 10s' → 3910s)."""
    if not text:
        return None
    total = 0.0
    matched = False
    for m in _DURATION_RE.finditer(text):
        num = float(m.group("num"))
        unit = m.group("unit").lower().rstrip("s") if m.group("unit").lower() not in ("ms",) else m.group("unit").lower()
        # Re-resolve cleanly via factor table
        for k, factor in _UNIT_FACTORS.items():
            if unit == k or unit + "s" == k or k == unit:
                total += num * factor
                matched = True
                break
    return total if matched else None


class ReminderScheduler:
    """Thread-safe reminder store + 1Hz dispatch loop."""

    def __init__(
        self,
        persist_path: Optional[str] = None,
        notify_callable: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
        broadcast_callable: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        if persist_path is None:
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            persist_path = os.path.join(project_root, "brain_state", "reminders.json")
        self.persist_path = persist_path
        # Callable that fires a desktop notification (typically the actuator
        # client's `notify` tool wrapper). Falls back to a no-op log.
        self.notify_callable = notify_callable
        # Optional callable to broadcast a reminder_fired event to WS clients
        self.broadcast_callable = broadcast_callable

        self._lock = threading.Lock()
        self._reminders: Dict[str, Reminder] = {}
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._load_persisted()

    # ── Persistence ──────────────────────────────────────────────────────
    def _load_persisted(self) -> None:
        if not os.path.exists(self.persist_path):
            return
        try:
            with open(self.persist_path) as f:
                payload = json.load(f)
            for r in payload.get("reminders", []):
                rem = Reminder(**r)
                self._reminders[rem.id] = rem
            print(f"[REMIND] loaded {len(self._reminders)} from {self.persist_path}")
        except Exception as e:
            print(f"[REMIND] load failed: {e}")

    def _save(self) -> None:
        try:
            os.makedirs(os.path.dirname(self.persist_path), exist_ok=True)
            tmp = self.persist_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(
                    {"reminders": [asdict(r) for r in self._reminders.values()]},
                    f, indent=2,
                )
            os.replace(tmp, self.persist_path)
        except Exception as e:
            print(f"[REMIND] save failed: {e}")

    # ── Public API ───────────────────────────────────────────────────────
    def add(
        self,
        text: str,
        in_seconds: Optional[float] = None,
        at_unix: Optional[float] = None,
        title: str = "Leon",
        urgency: str = "normal",
    ) -> Reminder:
        """Schedule a new reminder. Specify exactly one of in_seconds or at_unix."""
        now = time.time()
        if in_seconds is not None:
            due = now + max(1.0, float(in_seconds))
        elif at_unix is not None:
            due = max(now + 1.0, float(at_unix))
        else:
            raise ValueError("must specify in_seconds or at_unix")
        rid = "rem_" + secrets.token_hex(4)
        rem = Reminder(
            id=rid, text=text or "(no text)",
            due_ts=due, created_ts=now,
            title=title, urgency=urgency,
        )
        with self._lock:
            self._reminders[rid] = rem
            self._save()
        return rem

    def cancel(self, rid: str) -> bool:
        with self._lock:
            r = self._reminders.get(rid)
            if r is None or r.fired or r.cancelled:
                return False
            r.cancelled = True
            self._save()
        return True

    def list_active(self) -> List[Reminder]:
        with self._lock:
            return [r for r in self._reminders.values()
                    if not r.fired and not r.cancelled]

    def list_all(self, limit: int = 50) -> List[Reminder]:
        with self._lock:
            rems = sorted(self._reminders.values(),
                          key=lambda r: r.created_ts, reverse=True)
        return rems[:limit]

    # ── Background dispatch loop ─────────────────────────────────────────
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="reminder-scheduler",
        )
        self._thread.start()
        print(f"[REMIND] scheduler running ({len(self.list_active())} active)")

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None

    def _loop(self) -> None:
        while not self._stop.is_set():
            self._tick()
            self._stop.wait(timeout=1.0)

    def _tick(self) -> None:
        now = time.time()
        due_list: List[Reminder] = []
        with self._lock:
            for r in self._reminders.values():
                if r.fired or r.cancelled:
                    continue
                if now >= r.due_ts:
                    r.fired = True
                    r.fired_ts = now
                    due_list.append(r)
            if due_list:
                self._save()
        for r in due_list:
            self._fire(r)

    def _fire(self, r: Reminder) -> None:
        body = r.text
        from brain.identity import si_name as _sn
        title = r.title or _sn()
        # 1) Desktop notification via actuator (if wired)
        if self.notify_callable is not None:
            try:
                self.notify_callable({
                    "title": title, "body": body, "urgency": r.urgency,
                })
            except Exception as e:
                print(f"[REMIND] notify-send failed for {r.id}: {e}")
        else:
            print(f"[REMIND] FIRED {r.id}: {title} — {body}")
        # 2) WebSocket broadcast (if wired)
        if self.broadcast_callable is not None:
            try:
                self.broadcast_callable({
                    "type": "reminder_fired",
                    "id": r.id, "title": title, "body": body,
                    "ts": r.fired_ts,
                })
            except Exception as e:
                print(f"[REMIND] broadcast failed for {r.id}: {e}")

    def get_state(self) -> Dict[str, Any]:
        active = self.list_active()
        return {
            "active_count": len(active),
            "total_count": len(self._reminders),
            "next_due_ts": min((r.due_ts for r in active), default=None),
            "next_due_in_s": (min((r.due_ts for r in active), default=time.time()) - time.time()) if active else None,
            "active": [asdict(r) for r in sorted(active, key=lambda r: r.due_ts)[:10]],
        }
