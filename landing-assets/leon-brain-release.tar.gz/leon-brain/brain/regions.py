"""
Brain Regions — 18 anatomically-named neural populations.

Phase-0 rebuild (2026-05-11): replaced the 11-region mixed naming
(sensory_cortex, feature_layer, concept_layer, predictive, reflex_arc, ...)
with 18 real anatomical regions. Special behaviors from the old
classes are preserved but rehoused on the anatomically-correct region:

  - Lateral inhibition         → visual_cortex (V1 receptive-field competition)
  - Prediction error/surprise  → anterior_cingulate (ACC: real error monitor)
  - Sparse coding (WTA)        → prefrontal_cortex
  - Memory buffer + replay     → hippocampus (kept)
  - Persistent working memory  → prefrontal_cortex (kept)
  - Energy + arousal           → brainstem (kept)
  - Reflex urgency             → basal_ganglia (action selection, fast-loop gating)

Coordinate system (normalized -1 to 1, RAS-aligned):
  +X = right hemisphere · -X = left
  +Y = anterior (front) · -Y = posterior (back)
  +Z = dorsal (up)      · -Z = ventral (down)
"""

import numpy as np
from brain.neurons import NeuronPopulation
from brain.config import BrainConfig


# ── Base class ───────────────────────────────────────────────────────────────

class BrainRegion:
    """Base class for a brain region."""

    def __init__(self, name: str, n_neurons: int, params: dict, dt: float = 1.0):
        self.name = name
        self.n_neurons = n_neurons
        self.neurons = NeuronPopulation(n_neurons, **params, dt=dt)
        self.dt = dt
        self.activity_history = []
        self.max_history = 100
        # Output gain — multiplied against the fired array before it
        # propagates to downstream regions.  Default 1.0 (passthrough).
        # The ablation suite sets this to 0.0 during region_lesion runs.
        self.output_gain = 1.0
        # 3D position for visualization (normalized coordinates, RAS)
        self.position = np.array([0.0, 0.0, 0.0])

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = self.neurons.step(external_input, t, noise_amplitude=BrainConfig.THALAMIC_NOISE)
        rate = self.neurons.get_firing_rate()
        self.activity_history.append(rate)
        if len(self.activity_history) > self.max_history:
            self.activity_history.pop(0)
        return fired

    def get_state(self) -> dict:
        return {
            "name": self.name,
            "n_neurons": self.n_neurons,
            "firing_rate": float(self.neurons.get_firing_rate()),
            "mean_potential": float(np.mean(self.neurons.v)),
            "position": self.position.tolist(),
            **self.neurons.get_state(),
        }


# ── Primary sensory cortices ─────────────────────────────────────────────────

class VisualCortex(BrainRegion):
    """V1-V5 in the occipital lobe. Carries retinotopic representation.
    Has lateral inhibition (active neurons suppress neighbors) — classic V1
    receptive-field competition that sharpens edge detection."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("visual_cortex", n_neurons,
                         BrainConfig.NEURON_PARAMS["visual_cortex"], dt)
        self.position = np.array([0.0, -0.9, 0.2])
        self.inhibition_strength = 0.3
        self._prev_fired: np.ndarray | None = None

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        # Lateral inhibition: previously-fired neurons suppress their neighbors
        inhibition = np.zeros(self.n_neurons)
        if self._prev_fired is not None and np.any(self._prev_fired):
            fired_idx = np.where(self._prev_fired)[0]
            for idx in fired_idx[:100]:
                lo = max(0, idx - 5)
                hi = min(self.n_neurons, idx + 6)
                inhibition[lo:hi] -= self.inhibition_strength
            inhibition[fired_idx] = 0  # don't self-inhibit
        fired = super().step(external_input + inhibition, t)
        self._prev_fired = fired.copy()
        return fired

    def encode_vision(self, image_features: np.ndarray) -> np.ndarray:
        """Map visual features to a per-neuron current vector. Used by
        the screen-observer + webcam-vision pipelines."""
        current = np.zeros(self.n_neurons)
        if len(image_features) > 0:
            mapped = np.interp(
                np.linspace(0, 1, self.n_neurons),
                np.linspace(0, 1, len(image_features)),
                image_features,
            )
            current[:] = mapped * 20.0
        return current


class AuditoryCortex(BrainRegion):
    """A1 in the superior temporal gyrus. Tonotopic organization —
    different neurons respond to different frequencies."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("auditory_cortex", n_neurons,
                         BrainConfig.NEURON_PARAMS["auditory_cortex"], dt)
        self.position = np.array([0.7, 0.0, 0.0])

    def encode_audio(self, spectral_features: np.ndarray) -> np.ndarray:
        current = np.zeros(self.n_neurons)
        if len(spectral_features) > 0:
            mapped = np.interp(
                np.linspace(0, 1, self.n_neurons),
                np.linspace(0, 1, len(spectral_features)),
                spectral_features,
            )
            current[:] = mapped * 15.0
        return current


class SomatosensoryCortex(BrainRegion):
    """S1, postcentral gyrus. Touch, proprioception, body schema."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("somatosensory_cortex", n_neurons,
                         BrainConfig.NEURON_PARAMS["somatosensory_cortex"], dt)
        self.position = np.array([0.0, 0.0, 0.9])


# ── Motor + coordination ─────────────────────────────────────────────────────

class MotorCortex(BrainRegion):
    """M1, precentral gyrus. Generates motor commands. The motor_output
    is read by the safety kernel + downstream actuators."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("motor_cortex", n_neurons,
                         BrainConfig.NEURON_PARAMS["motor_cortex"], dt)
        self.position = np.array([0.0, 0.3, 0.9])
        self.motor_output = np.zeros(n_neurons)

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        self.motor_output = fired.astype(np.float32)
        return fired

    def get_motor_command(self) -> np.ndarray:
        return self.motor_output


class Cerebellum(BrainRegion):
    """Timing, motor coordination, and increasingly: cognitive prediction.
    Real cerebellum holds ~80% of brain neurons; we stylize down to 15%
    to keep the visualization legible."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("cerebellum", n_neurons,
                         BrainConfig.NEURON_PARAMS["cerebellum"], dt)
        self.position = np.array([0.0, -0.8, -0.5])
        self.timing_buffer = np.zeros((10, n_neurons))
        self.timing_idx = 0

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        self.timing_buffer[self.timing_idx % 10] = fired.astype(np.float32)
        self.timing_idx += 1
        return fired


# ── Association cortex ───────────────────────────────────────────────────────

class ParietalAssociation(BrainRegion):
    """Multimodal integration (parietal lobe). Binds touch, vision, and
    body schema into a unified spatial representation. Tracks which
    neurons consistently fire together (Hebbian binding)."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("parietal_association", n_neurons,
                         BrainConfig.NEURON_PARAMS["parietal_association"], dt)
        self.position = np.array([0.0, -0.3, 0.7])
        self.binding_strength = np.zeros(n_neurons)

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        if np.any(fired):
            self.binding_strength[fired] += 0.01
            self.binding_strength *= 0.999
        return fired


class TemporalAssociation(BrainRegion):
    """Object recognition, face recognition, semantic memory (temporal
    lobe). Where 'what is this thing' processing lives."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("temporal_association", n_neurons,
                         BrainConfig.NEURON_PARAMS["temporal_association"], dt)
        self.position = np.array([-0.7, 0.0, 0.0])
        self.binding_strength = np.zeros(n_neurons)

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        if np.any(fired):
            self.binding_strength[fired] += 0.01
            self.binding_strength *= 0.999
        return fired


# ── Executive ────────────────────────────────────────────────────────────────

class PrefrontalCortex(BrainRegion):
    """Working memory + planning + concept abstraction.

    Maintains persistent activity (working memory).
    Uses winner-take-all competition for sparse concept representation —
    only the top ~5% most-active neurons fire on any given step. This is
    where 'I am thinking about X' gets encoded as a sparse pattern."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("prefrontal_cortex", n_neurons,
                         BrainConfig.NEURON_PARAMS["prefrontal_cortex"], dt)
        self.position = np.array([0.0, 0.9, 0.5])
        self.working_memory = np.zeros(n_neurons, dtype=np.float32)
        self.wm_decay = 0.995
        self.wta_top_pct = 0.05   # top 5% fire per step

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        total_input = external_input + self.working_memory * 3.0
        fired = super().step(total_input, t)
        # Winner-take-all: keep only top-K firing neurons
        if np.sum(fired) > 0:
            k = max(1, int(self.n_neurons * self.wta_top_pct))
            if np.sum(fired) > k:
                potentials = self.neurons.v.copy()
                potentials[~fired] = -100
                threshold = np.partition(potentials, -k)[-k]
                suppress = fired & (potentials < threshold)
                self.neurons.v[suppress] = self.neurons.c[suppress]
                fired[suppress] = False
        # Update working memory
        self.working_memory *= self.wm_decay
        if np.any(fired):
            self.working_memory[fired] = np.minimum(
                self.working_memory[fired] + 0.1, 1.0,
            )
        return fired


class AnteriorCingulate(BrainRegion):
    """ACC. Conflict monitoring + prediction error. When the brain's
    current input differs from its prediction, ACC fires harder → drives
    attention. This is what 'surprise' was tracking on the old
    PredictiveLayer; rehoused on the anatomically-correct region."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("anterior_cingulate", n_neurons,
                         BrainConfig.NEURON_PARAMS["anterior_cingulate"], dt)
        self.position = np.array([0.0, 0.5, 0.2])
        self.prediction = np.zeros(n_neurons)
        self.prediction_error = 0.0
        self.surprise = 0.0

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        actual = fired.astype(np.float32)
        self.prediction_error = float(np.mean(np.abs(actual - self.prediction)))
        self.surprise = min(1.0, self.prediction_error * 5.0)
        self.prediction = 0.9 * self.prediction + 0.1 * actual
        return fired

    def get_state(self) -> dict:
        state = super().get_state()
        state["prediction_error"] = self.prediction_error
        state["surprise"] = self.surprise
        return state


class Insula(BrainRegion):
    """Interoception — the brain's representation of its own body/state.
    Linked to subjective awareness and 'gut feelings.' Reads neuromod
    levels and signals high arousal/discomfort."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("insula", n_neurons,
                         BrainConfig.NEURON_PARAMS["insula"], dt)
        self.position = np.array([0.6, 0.2, 0.0])
        self.arousal_signal = 0.0

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        # Insula tracks overall activation as a proxy for subjective state
        self.arousal_signal = float(self.neurons.get_firing_rate())
        return fired


# ── Language ─────────────────────────────────────────────────────────────────

class Broca(BrainRegion):
    """Speech/language production. In left hemisphere (most humans).
    Outputs to motor_cortex for speech articulation."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("broca", n_neurons,
                         BrainConfig.NEURON_PARAMS["broca"], dt)
        self.position = np.array([-0.5, 0.5, 0.4])


class Wernicke(BrainRegion):
    """Language comprehension. Receives text+speech, produces semantic
    activation. This is where 'reading' lives — text features get
    injected here, not into somatosensory cortex like the old code did."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("wernicke", n_neurons,
                         BrainConfig.NEURON_PARAMS["wernicke"], dt)
        self.position = np.array([-0.6, -0.3, 0.2])

    def encode_text(self, text_features: np.ndarray) -> np.ndarray:
        """Map text features to a per-neuron current vector. Called when
        Dean's chat input arrives."""
        current = np.zeros(self.n_neurons)
        if len(text_features) > 0:
            mapped = np.interp(
                np.linspace(0, 1, self.n_neurons),
                np.linspace(0, 1, len(text_features)),
                text_features,
            )
            current[:] = mapped * 18.0
        return current


# ── Memory + emotion (limbic) ────────────────────────────────────────────────

class Hippocampus(BrainRegion):
    """Episodic memory consolidation. Stores spike-pattern snapshots
    of significant activity, replays them during low-activity periods.
    The pattern-strength tracking persists what got reinforced."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("hippocampus", n_neurons,
                         BrainConfig.NEURON_PARAMS["hippocampus"], dt)
        self.position = np.array([0.3, -0.2, -0.2])
        self.memory_buffer = []
        self._memory_strength = []
        self._memory_labels = []  # semantic text for each memory (for dream content)
        self.max_memories = 1000
        self.replay_mode = False

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        rate = self.neurons.get_firing_rate()

        # Encode novel patterns
        if rate > 0.05 and not self.replay_mode:
            pattern = fired.copy()
            is_novel = True
            # Check against recent history, not just the last pattern,
            # to avoid re-encoding the same pattern a few steps later.
            check_window = self.memory_buffer[-10:] if self.memory_buffer else []
            for prev in check_window:
                overlap = np.sum(pattern & prev) / max(np.sum(pattern | prev), 1)
                if overlap > 0.8:
                    is_novel = False
                    break
            if is_novel:
                self.memory_buffer.append(pattern)
                self._memory_strength.append(1.0)
                self._memory_labels.append("")  # no label for spontaneous encoding
                if len(self.memory_buffer) > self.max_memories:
                    weakest = int(np.argmin(self._memory_strength))
                    self.memory_buffer.pop(weakest)
                    self._memory_strength.pop(weakest)
                    if weakest < len(self._memory_labels):
                        self._memory_labels.pop(weakest)

        # Replay during quiet periods
        if rate < 0.01 and self.memory_buffer:
            self.replay_mode = True
            n = len(self.memory_buffer)
            # Sync strength list if it got out of sync (e.g. after migration)
            while len(self._memory_strength) < n:
                self._memory_strength.append(1.0)
            while len(self._memory_strength) > n:
                self._memory_strength.pop()
            recency = np.linspace(0.3, 1.0, n)
            strength = np.array(self._memory_strength)
            weights = recency * strength
            weights /= weights.sum()
            idx = int(np.random.choice(n, p=weights))
            replay_pattern = self.memory_buffer[idx]
            self.neurons.inject_current(replay_pattern.astype(np.float32) * 10.0)
            self._memory_strength[idx] = min(self._memory_strength[idx] * 1.05, 5.0)
            for i in range(n):
                if i != idx:
                    self._memory_strength[i] *= 0.999
        else:
            self.replay_mode = False

        return fired

    def get_state(self) -> dict:
        state = super().get_state()
        state["memories_stored"] = len(self.memory_buffer)
        state["replay_mode"] = self.replay_mode
        return state


class Amygdala(BrainRegion):
    """Salience + threat + reward weighting. Fires when something
    matters — high-arousal, novel, or threatening input. Feeds into
    prefrontal (top-down regulation), insula (subjective feeling),
    and hippocampus (emotional memory binding)."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("amygdala", n_neurons,
                         BrainConfig.NEURON_PARAMS["amygdala"], dt)
        self.position = np.array([0.4, 0.1, -0.3])
        self.salience = 0.0

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        # Salience tracks instantaneous activation
        self.salience = float(self.neurons.get_firing_rate())
        return fired


# ── Subcortical relays + action selection ────────────────────────────────────

class Thalamus(BrainRegion):
    """Relay station — every sensory afferent (except smell) passes
    through thalamus on its way to cortex. Also gates attention by
    selectively amplifying or suppressing different channels."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("thalamus", n_neurons,
                         BrainConfig.NEURON_PARAMS["thalamus"], dt)
        self.position = np.array([0.0, 0.0, 0.0])
        self.gating_strength = 1.0   # global attention gain (modulated externally)


class BasalGanglia(BrainRegion):
    """Action selection + habit formation. Inhibits competing motor
    plans so a single action wins. Also handles urgent-response gating —
    the closest anatomically to what the old 'reflex_arc' was doing."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("basal_ganglia", n_neurons,
                         BrainConfig.NEURON_PARAMS["basal_ganglia"], dt)
        self.position = np.array([0.2, 0.2, 0.0])
        self.action_urgent = False
        self.urgency_threshold = 0.3
        # Alias for backward compat with claude_bridge.py / safety logic
        # that used to read reflex_arc.reflex_active.
        self.reflex_active = False

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        rate = self.neurons.get_firing_rate()
        self.action_urgent = rate > self.urgency_threshold
        self.reflex_active = self.action_urgent
        return fired


# ── Brainstem trunk ──────────────────────────────────────────────────────────

class Brainstem(BrainRegion):
    """Arousal + homeostasis. Houses (conceptually for now) the
    modulatory nuclei: locus coeruleus (NE), raphe (5-HT), VTA (DA),
    substantia nigra. We'll split these out as sub-clusters in a
    later phase — for now they live as one trunk."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("brainstem", n_neurons,
                         BrainConfig.NEURON_PARAMS["brainstem"], dt)
        self.position = np.array([0.0, -0.5, -0.7])
        self.energy = 1.0
        self.arousal = 0.5

    def step(self, external_input: np.ndarray, t: float) -> np.ndarray:
        fired = super().step(external_input, t)
        total_activity = self.neurons.get_firing_rate()
        self.energy -= total_activity * 0.001
        self.energy = float(np.clip(self.energy + 0.0005, 0.1, 1.0))
        self.arousal = 0.95 * self.arousal + 0.05 * total_activity
        return fired

    def get_state(self) -> dict:
        state = super().get_state()
        state["energy"] = float(self.energy)
        state["arousal"] = float(self.arousal)
        return state


# ── Resting state ────────────────────────────────────────────────────────────

class DefaultModeNetwork(BrainRegion):
    """The DMN fires when the brain is at rest — mind-wandering,
    self-referential thought, simulating other people, imagining the
    future. In Leon, this is the substrate that the proactive loop will
    eventually couple to (phase 7): when DMN activation patterns drift
    near a stored memory fingerprint, the memory becomes available for
    spontaneous association."""

    def __init__(self, n_neurons: int, dt: float = 1.0):
        super().__init__("default_mode_network", n_neurons,
                         BrainConfig.NEURON_PARAMS["default_mode_network"], dt)
        self.position = np.array([0.0, 0.0, 0.4])


# ── Factory ──────────────────────────────────────────────────────────────────

REGION_CLASSES = {
    "visual_cortex":         VisualCortex,
    "auditory_cortex":       AuditoryCortex,
    "somatosensory_cortex":  SomatosensoryCortex,
    "motor_cortex":          MotorCortex,
    "cerebellum":            Cerebellum,
    "parietal_association":  ParietalAssociation,
    "temporal_association":  TemporalAssociation,
    "prefrontal_cortex":     PrefrontalCortex,
    "anterior_cingulate":    AnteriorCingulate,
    "insula":                Insula,
    "broca":                 Broca,
    "wernicke":              Wernicke,
    "hippocampus":           Hippocampus,
    "amygdala":              Amygdala,
    "thalamus":              Thalamus,
    "basal_ganglia":         BasalGanglia,
    "brainstem":             Brainstem,
    "default_mode_network":  DefaultModeNetwork,
}


def create_all_regions(total_neurons: int = None, dt: float = 1.0) -> dict:
    """Create all 18 anatomical brain regions with neuron counts derived
    from REGION_PROPORTIONS. Returns name → BrainRegion mapping."""
    if total_neurons is None:
        total_neurons = BrainConfig.TOTAL_NEURONS
    regions = {}
    for name, cls in REGION_CLASSES.items():
        n = max(100, int(total_neurons * BrainConfig.REGION_PROPORTIONS[name]))
        regions[name] = cls(n, dt=dt)
    return regions
