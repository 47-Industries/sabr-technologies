"""
Housekeeping LLM — the FREE-ONLY brain for work Dean is not talking to.

WHY THIS EXISTS (Dean, 2026-08-17, verbatim intent):
    "I don't want anything housekeeping clogged. That is a huge waste of
     money... it should be a free local model that does health checks. We
     should never do anything that's a paid anything for health checks and
     housekeeping type of shit. Because you need that as your mouthpiece."

    The paid Claude budget is Leon's VOICE. It gets spent on Dean and on real
    work. Summarizing a dream, describing a screen glance, scanning an upgrade
    changelog, sanity-checking a service — none of that is voice. It used to
    ride the sonnet daemon session anyway, which is exactly the clog.

HARD CONTRACT:
    Nothing in this module can reach Anthropic. There is no fallback to the
    paid path, on purpose. If every free rung is down, ask() returns None and
    the CALLER decides whether the work is important enough to escalate. A
    silent auto-escalation to paid is the bug this file exists to prevent.

LADDER (best free quality first, most reliable last):
    1. FreeLLM router  (LEON_OLLAMA_URL, default 127.0.0.1:3001) — Gemini /
       Gemma class, remote, free, but CAN rate-limit (429 observed 2026-08-14).
    2. True local ollama (LEON_TRUE_LOCAL_URL, 127.0.0.1:11434) — qwen2.5 7b.
       Cannot 429, cannot go offline while the box is up.

MODEL CHOICE IS NOT COSMETIC: "auto" on the free router resolves to a
reasoning model that spends the ENTIRE token budget in its thinking channel
and returns content="" with done_reason="length". Measured 2026-08-17: auto
returned empty, gemini-3.5-flash returned the answer. So we pin explicit
non-reasoning models and treat empty content as a failure worth falling
through on, rather than handing a caller a blank string it will happily
store as a summary.

LEDGER: every call is appended to brain_state/housekeeping_llm.jsonl so the
savings are measurable instead of claimed — which rung answered, how long it
took, how many chars came back.
"""
from __future__ import annotations

import json
import os
import time
import urllib.request
from typing import List, Optional, Tuple

_FREE_URL = os.environ.get("LEON_OLLAMA_URL", "http://127.0.0.1:3001").rstrip("/")
_TRUE_LOCAL_URL = os.environ.get(
    "LEON_TRUE_LOCAL_URL", "http://127.0.0.1:11434").rstrip("/")

# Pinned, non-reasoning, verified to return real content on 2026-08-17.
_FREE_MODELS = [
    m.strip() for m in os.environ.get(
        "LEON_HOUSEKEEPING_MODELS",
        # Order MEASURED 2026-08-17 against the live router, not guessed:
        # gemma-4-31b-it and gemini-3.6-flash both returned real content;
        # gemini-3.5-flash was 429 rate-limited; every gemini-2.5-* entry in
        # the catalog is stale and 404s upstream. Rate limits are PER MODEL,
        # so a multi-model chain is the retry strategy.
        "gemma-4-31b-it,gemini-3.6-flash,gemini-3.5-flash,gemini-3.1-flash-lite",
    ).split(",") if m.strip()
]

_LEDGER = os.path.join(
    os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state"),
    "housekeeping_llm.jsonl",
)

_true_local_model_cache: Optional[str] = None


def _true_local_model() -> Optional[str]:
    """Whatever instruct model is ACTUALLY pulled on the local daemon.

    Never trust a configured tag: an unpulled name 404s and looks like the
    whole rung is dead when it is only misnamed.
    """
    global _true_local_model_cache
    if _true_local_model_cache:
        return _true_local_model_cache
    try:
        with urllib.request.urlopen(f"{_TRUE_LOCAL_URL}/api/tags", timeout=3) as r:
            names = [m.get("name", "") for m in
                     (json.load(r).get("models") or []) if m.get("name")]
    except Exception:
        return None
    # 3b FIRST, deliberately. This VPS has no GPU — the 7b takes >30s to load
    # and generate on CPU (measured 2026-08-17, timed out), which makes the
    # "cannot fail" rung the slowest thing in the ladder. The last rung's job
    # is to ANSWER, not to answer beautifully.
    for pref in ("qwen2.5:3b-instruct-q4_K_M", "llama3.2:3b",
                 "qwen2.5:7b-instruct-q4_K_M"):
        if pref in names:
            _true_local_model_cache = pref
            return pref
    if names:
        _true_local_model_cache = names[0]
        return names[0]
    return None


def _chain() -> List[Tuple[str, str]]:
    rungs: List[Tuple[str, str]] = [(_FREE_URL, m) for m in _FREE_MODELS]
    tl = _true_local_model()
    if tl:
        rungs.append((_TRUE_LOCAL_URL, tl))
    return rungs


# Per-model cooldown. Rate limits on the free router are PER MODEL and come
# back as HTTP 429 with a stated reset. Without this, every housekeeping call
# re-pays the full timeout of a model we already know is capped — which is how
# a "free" path turns into a 30-second stall on every tick.
_cooldown: dict = {}


def _on_cooldown(model: str) -> bool:
    until = _cooldown.get(model, 0.0)
    return until > time.time()


def _mark_cooldown(model: str, err: str) -> None:
    low = (err or "").lower()
    if "429" in low or "rate" in low or "exhausted" in low:
        _cooldown[model] = time.time() + 120.0
    elif "404" in low or "not found" in low or "stale" in low:
        # A catalog entry the upstream no longer serves is not coming back
        # in two minutes. Bench it for the process lifetime.
        _cooldown[model] = time.time() + 86400.0


def _log(rung: str, model: str, ok: bool, dt: float, chars: int,
         task: str, err: str = "") -> None:
    try:
        os.makedirs(os.path.dirname(_LEDGER), exist_ok=True)
        with open(_LEDGER, "a") as f:
            f.write(json.dumps({
                "ts": time.time(), "task": task, "rung": rung, "model": model,
                "ok": ok, "seconds": round(dt, 3), "chars": chars,
                "err": err[:200],
            }) + "\n")
    except Exception:
        pass


def ask(prompt: str, *, system: Optional[str] = None, task: str = "unknown",
        max_tokens: int = 512, timeout: float = 30.0) -> Optional[str]:
    """Run a housekeeping prompt on free compute only. None if all rungs fail.

    Returning None on total failure is deliberate — see module docstring.
    """
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})

    for url, model in _chain():
        if _on_cooldown(model):
            continue
        # THINKING SHARES THE BUDGET. On the free router, num_predict caps
        # thinking + content together, and these models think a lot: asking
        # for 200 returned a 12-character truncated fragment (measured
        # 2026-08-17). So the hosted rungs get a padded budget and we rely on
        # the prompt, not the cap, to keep answers short.
        budget = max_tokens if url == _TRUE_LOCAL_URL else max_tokens * 4 + 512
        payload = json.dumps({
            "model": model, "stream": False, "messages": msgs,
            "options": {"num_predict": budget, "temperature": 0.2},
            "keep_alive": "15m",
        }).encode("utf-8")
        # The local rung is CPU-only on this box: a cold model load alone can
        # exceed the network timeout. Giving it the same budget as a hosted
        # API is how the last-resort rung "fails" while actually working.
        rung_timeout = timeout if url != _TRUE_LOCAL_URL else max(timeout, 180.0)
        t0 = time.time()
        try:
            req = urllib.request.Request(
                f"{url}/api/chat", data=payload,
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=rung_timeout) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
            text = ((d.get("message", {}) or {}).get("content", "") or "").strip()
            dt = time.time() - t0
            if not text:
                # Empty content is a real failure mode (reasoning model ate the
                # budget), not a valid answer. Fall through to the next rung.
                _log(url, model, False, dt, 0, task,
                     f"empty content, done_reason={d.get('done_reason')}")
                continue
            _log(url, model, True, dt, len(text), task)
            return text
        except Exception as e:
            _mark_cooldown(model, str(e))
            _log(url, model, False, time.time() - t0, 0, task, str(e))
            continue
    return None


def is_available(timeout: float = 3.0) -> bool:
    """True if at least one free rung answers its model list."""
    for url in (_FREE_URL, _TRUE_LOCAL_URL):
        try:
            with urllib.request.urlopen(f"{url}/api/tags", timeout=timeout) as r:
                if (json.load(r).get("models") or []):
                    return True
        except Exception:
            continue
    return False


def ledger_summary(hours: float = 24.0) -> dict:
    """What free compute actually absorbed — for the dashboard / Dean."""
    cut = time.time() - hours * 3600
    calls = 0
    ok = 0
    chars = 0
    by_task: dict = {}
    try:
        with open(_LEDGER) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get("ts", 0) < cut:
                    continue
                calls += 1
                if d.get("ok"):
                    ok += 1
                    chars += d.get("chars", 0)
                    by_task[d.get("task", "?")] = by_task.get(d.get("task", "?"), 0) + 1
    except FileNotFoundError:
        pass
    return {"hours": hours, "calls": calls, "succeeded": ok,
            "chars_generated": chars, "by_task": by_task}
