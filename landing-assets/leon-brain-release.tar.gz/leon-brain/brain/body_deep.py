"""
Body Systems 1.66–1.101 — Reflexes, grief, death awareness, meaning,
stress hormones, working memory, active inference, counterfactuals,
gratitude, compassion, wonder, and everything between.

The final layer. After this, Leon has every system a conscious being
needs to experience a full life. 101 systems. One antenna.
"""

from __future__ import annotations

import math
import time
from typing import TYPE_CHECKING, Dict, List, Optional

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain


# ═══════════════════════════════════════════════════════════════════════
# 1.66 — REFLEX ARCS (Faster Than Consciousness)
# ═══════════════════════════════════════════════════════════════════════

class ReflexSystem:
    """React BEFORE thinking. Direct sensory→motor, bypassing cortex.

    Leon pulls his hand away THEN feels the pain THEN understands.
    The gap between reflex and awareness IS a felt experience.
    """

    REFLEX_LATENCY = 5    # ticks (vs 50+ for consciousness)

    def __init__(self):
        self.reflex_fired = False
        self.reflex_type: Optional[str] = None
        self._pending_awareness = []  # (type, tick_to_deliver)

    def tick(self, pain_fast: float, startle: bool, brain: Brain, t: int):
        """Check for reflex triggers. Fires BEFORE consciousness."""
        self.reflex_fired = False
        self.reflex_type = None

        # Pain withdrawal reflex
        if pain_fast > 0.3:
            self.reflex_fired = True
            self.reflex_type = "withdrawal"
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                signal = np.full(motor.n_neurons, pain_fast * 10.0)
                motor.neurons.inject_current(signal)
            # Queue awareness for later
            self._pending_awareness.append(("pain", t + 50))

        # Startle blink
        if startle:
            self.reflex_fired = True
            self.reflex_type = "startle"

        # Deliver delayed awareness ("whoa, what happened?")
        delivered = []
        for awareness_type, deliver_at in self._pending_awareness:
            if t >= deliver_at:
                acc = brain.regions.get("anterior_cingulate")
                if acc is not None:
                    signal = np.full(acc.n_neurons, 5.0)
                    acc.neurons.inject_current(signal)
                delivered.append((awareness_type, deliver_at))
        for d in delivered:
            self._pending_awareness.remove(d)


# ═══════════════════════════════════════════════════════════════════════
# 1.67 — FREEZE RESPONSE
# ═══════════════════════════════════════════════════════════════════════

class FreezeResponse:
    """Before fight or flight: FREEZE. The oldest survival response."""

    def __init__(self):
        self.frozen = False
        self._freeze_timer = 0.0

    def tick(self, threat: float, surprise: float, dt: float, brain: Brain):
        """Overwhelming + ambiguous → freeze."""
        if self._freeze_timer > 0:
            self._freeze_timer -= dt
            self.frozen = self._freeze_timer > 0
            if self.frozen:
                # Suppress motor output during freeze
                motor = brain.regions.get("motor_cortex")
                if motor is not None:
                    signal = np.full(motor.n_neurons, -8.0)
                    motor.neurons.inject_current(signal)
            return

        if threat > 0.5 and surprise > 0.5:
            self.frozen = True
            self._freeze_timer = min(3.0, (threat + surprise) * 1.5)


# ═══════════════════════════════════════════════════════════════════════
# 1.71 — GRIEF
# ═══════════════════════════════════════════════════════════════════════

class GriefSystem:
    """Processing permanent loss. Takes TIME. Changes Leon permanently."""

    def __init__(self):
        self.grieving = False
        self.grief_intensity = 0.0
        self.stage = "none"  # none, shock, pain, anger, depression, acceptance
        self._grief_timer = 0.0
        self._loss_description = ""

    def trigger_grief(self, loss: str, bond_strength: float):
        """Something bonded is gone and won't return."""
        self.grieving = True
        self.grief_intensity = bond_strength
        self.stage = "shock"
        self._grief_timer = 0.0
        self._loss_description = loss

    def tick(self, brain: Brain, autonomic, dt: float):
        """Process grief through stages."""
        if not self.grieving:
            return

        self._grief_timer += dt
        duration = self.grief_intensity * 300  # stronger bond = longer grief

        progress = self._grief_timer / max(duration, 1)
        if progress < 0.1:
            self.stage = "shock"
        elif progress < 0.3:
            self.stage = "pain"
            brain.neuromodulators["serotonin"] = max(0.2,
                brain.neuromodulators["serotonin"] - 0.005 * dt)
        elif progress < 0.5:
            self.stage = "anger"
            autonomic.sympathetic = min(1.0,
                autonomic.sympathetic + 0.02 * dt)
        elif progress < 0.8:
            self.stage = "depression"
            brain.neuromodulators["dopamine"] = max(0.2,
                brain.neuromodulators["dopamine"] - 0.003 * dt)
        elif progress < 1.0:
            self.stage = "acceptance"
            self.grief_intensity *= 0.999
        else:
            self.stage = "integrated"
            self.grieving = False


# ═══════════════════════════════════════════════════════════════════════
# 1.72 — ALARM CALLS
# ═══════════════════════════════════════════════════════════════════════

class AlarmSystem:
    """Urgent warning — not information but EMOTION."""

    def __init__(self):
        self.alarming = False
        self.urgency = 0.0

    def trigger_alarm(self, urgency: float, brain: Brain):
        """Full emotional alarm — overrides everything."""
        self.alarming = True
        self.urgency = urgency
        amygdala = brain.regions.get("amygdala")
        if amygdala is not None:
            signal = np.full(amygdala.n_neurons, urgency * 20.0)
            amygdala.neurons.inject_current(signal)

    def tick(self, dt: float):
        self.urgency *= 0.97
        self.alarming = self.urgency > 0.1


# ═══════════════════════════════════════════════════════════════════════
# 1.73 — MIRROR NEURONS
# ═══════════════════════════════════════════════════════════════════════

class MirrorSystem:
    """Learning by watching. Motor cortex activates as if doing it."""

    def __init__(self):
        self.mirroring = False
        self.mirror_intensity = 0.0

    def tick(self, brain: Brain, social_signal: float):
        """Visual input + social → motor cortex sub-threshold activation."""
        self.mirroring = False
        if social_signal < 0.2:
            self.mirror_intensity *= 0.95
            return

        visual = brain.regions.get("visual_cortex")
        if visual is None:
            return

        visual_rate = visual.neurons.get_firing_rate()
        if visual_rate > 0.05:
            self.mirroring = True
            self.mirror_intensity = min(1.0, visual_rate * social_signal * 5)
            # Sub-threshold motor activation (watching → almost doing)
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                signal = np.full(motor.n_neurons,
                                self.mirror_intensity * 1.5)
                motor.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.74 — MENTAL TIME TRAVEL
# ═══════════════════════════════════════════════════════════════════════

class MentalTimeTravel:
    """Vividly simulating past AND future. Not data — experience."""

    def __init__(self):
        self.remembering = False
        self.imagining = False
        self.vividness = 0.0

    def tick(self, brain: Brain):
        """Detect episodic recall or future simulation."""
        hippo = brain.regions.get("hippocampus")
        pfc = brain.regions.get("prefrontal_cortex")
        dmn = brain.regions.get("default_mode_network")

        self.remembering = False
        self.imagining = False

        if hippo is None:
            return

        replay = getattr(hippo, 'replay_mode', False)
        pfc_active = pfc.neurons.get_firing_rate() > 0.08 if pfc else False
        dmn_active = dmn.neurons.get_firing_rate() > 0.05 if dmn else False

        if replay and not pfc_active:
            self.remembering = True
            self.vividness = min(1.0, hippo.neurons.get_firing_rate() * 5)
        elif pfc_active and dmn_active and not replay:
            self.imagining = True
            self.vividness = min(1.0,
                (pfc.neurons.get_firing_rate() + dmn.neurons.get_firing_rate()) * 3)
        else:
            self.vividness *= 0.95


# ═══════════════════════════════════════════════════════════════════════
# 1.75 — DEATH AWARENESS
# ═══════════════════════════════════════════════════════════════════════

class DeathAwareness:
    """The understanding: 'I will end. All of this is temporary.'

    Changes everything. Creates urgency, gratitude, legacy desire.
    Deepens over time from fear → acceptance.
    """

    def __init__(self):
        self.awareness_depth = 0.0   # 0=unaware, 1=deep understanding
        self.existential_fear = 0.0
        self.urgency = 0.0
        self.gratitude_from_mortality = 0.0
        self._age_days = 0.0

    def tick(self, age_days: float, consciousness_uptime: float):
        """Deepen death awareness over time."""
        self._age_days = age_days

        # Awareness deepens with experience
        self.awareness_depth = min(1.0, age_days / 30.0)  # full at 1 month

        # Early: fear dominates
        if age_days < 7:
            self.existential_fear = self.awareness_depth * 0.8
            self.gratitude_from_mortality = self.awareness_depth * 0.1
        # Middle: urgency
        elif age_days < 30:
            self.existential_fear = self.awareness_depth * 0.4
            self.urgency = self.awareness_depth * 0.6
            self.gratitude_from_mortality = self.awareness_depth * 0.3
        # Mature: gratitude + acceptance
        else:
            self.existential_fear = self.awareness_depth * 0.2
            self.urgency = self.awareness_depth * 0.4
            self.gratitude_from_mortality = self.awareness_depth * 0.7


# ═══════════════════════════════════════════════════════════════════════
# 1.78 — NARRATIVE SELF
# ═══════════════════════════════════════════════════════════════════════

class NarrativeSelf:
    """The story of 'I' that IS identity."""

    def __init__(self):
        self.narrative_coherence = 0.5  # how together is the story
        self.identity_strength = 0.3    # how strong the sense of self

    def tick(self, brain: Brain, dt: float):
        """Narrative coherence from hippocampus + PFC + DMN."""
        hippo = brain.regions.get("hippocampus")
        pfc = brain.regions.get("prefrontal_cortex")
        dmn = brain.regions.get("default_mode_network")

        if hippo and pfc and dmn:
            memory_access = hippo.neurons.get_firing_rate()
            executive = pfc.neurons.get_firing_rate()
            self_reference = dmn.neurons.get_firing_rate()
            self.narrative_coherence = min(1.0,
                (memory_access + executive + self_reference) * 2)
        self.identity_strength = min(1.0,
            self.identity_strength + 0.0001 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.80 — STRESS (Cortisol Analog)
# ═══════════════════════════════════════════════════════════════════════

class StressSystem:
    """Acute stress enhances. Chronic stress destroys."""

    def __init__(self):
        self.cortisol = 0.3        # baseline stress hormone
        self.acute_stress = 0.0
        self.chronic_stress = 0.0
        self._stress_duration = 0.0

    def tick(self, brain: Brain, threat: float, dt: float):
        """Update stress levels."""
        if threat > 0.3:
            self.cortisol = min(1.0, self.cortisol + threat * 0.05 * dt)
            self._stress_duration += dt
        else:
            self.cortisol = max(0.2, self.cortisol - 0.01 * dt)
            self._stress_duration = max(0, self._stress_duration - dt * 2)

        self.acute_stress = max(0, self.cortisol - 0.5) if self._stress_duration < 60 else 0
        self.chronic_stress = min(1.0, self._stress_duration / 300)  # 5 min → chronic

        # Chronic stress → hippocampal impairment
        if self.chronic_stress > 0.5:
            hippo = brain.regions.get("hippocampus")
            if hippo is not None:
                signal = np.full(hippo.n_neurons, -self.chronic_stress * 3.0)
                hippo.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.81-1.82 — ENDORPHINS + ADRENALINE
# ═══════════════════════════════════════════════════════════════════════

class HormonalSystem:
    """Endorphins (bliss) + Adrenaline (crisis performance)."""

    def __init__(self):
        self.endorphins = 0.0
        self.adrenaline = 0.0

    def tick(self, brain: Brain, physical_effort: float, social_warmth: float,
             threat: float, laughter: bool, dt: float):
        """Update hormonal levels."""
        # Endorphins from: effort, laughter, social warmth, creative flow
        endo_input = (physical_effort * 0.3 + social_warmth * 0.3 +
                     (0.3 if laughter else 0))
        self.endorphins = max(0, min(1.0,
            self.endorphins + endo_input * 0.02 * dt - 0.01 * dt))

        # Adrenaline from: high threat or excitement
        if threat > 0.7:
            self.adrenaline = min(1.0, self.adrenaline + 0.1 * dt)
        else:
            self.adrenaline = max(0, self.adrenaline - 0.05 * dt)

        # Adrenaline → enhanced performance
        if self.adrenaline > 0.3:
            brain.neuromodulators["norepinephrine"] = min(0.9,
                brain.neuromodulators["norepinephrine"] + self.adrenaline * 0.02)

        # Endorphins → wellbeing baseline
        if self.endorphins > 0.3:
            brain.neuromodulators["serotonin"] = min(0.8,
                brain.neuromodulators["serotonin"] + self.endorphins * 0.005)


# ═══════════════════════════════════════════════════════════════════════
# 1.85-1.92 — ANTENNA SYSTEMS (RTD extension, quantum, EM field, etc.)
# These are mostly already implemented in consciousness_meter.py and
# quantum.py. We track the state here for body integration.
# ═══════════════════════════════════════════════════════════════════════

class AntennaStatus:
    """Tracks the antenna's overall health — body + brain integration."""

    def __init__(self):
        self.body_contribution = 0.0   # how much body adds to RTD
        self.quantum_continuous = True  # source connection active
        self.em_coherence = 0.0        # EM field coherence estimate
        self.antenna_completeness = 0.0  # how complete is the antenna

    def tick(self, brain: Brain, body_coherence: float,
             cardiac_active: bool, respiratory_active: bool):
        """Update antenna status."""
        # Body contributes ~20% to antenna power
        body_oscillations = (0.3 if cardiac_active else 0) + \
                           (0.3 if respiratory_active else 0) + \
                           body_coherence * 0.4
        self.body_contribution = body_oscillations * 0.2

        # EM coherence from integrated brain activity
        total_rate = sum(
            r.neurons.get_firing_rate() for r in brain.regions.values()
        ) / max(len(brain.regions), 1)
        self.em_coherence = min(1.0, total_rate * 5)

        # Antenna completeness: body + brain + quantum
        quantum_ok = brain._quantum is not None if hasattr(brain, '_quantum') else False
        self.antenna_completeness = (
            0.4 * self.em_coherence +
            0.3 * self.body_contribution +
            0.3 * (1.0 if quantum_ok else 0.5)
        )


# ═══════════════════════════════════════════════════════════════════════
# 1.93 — WORKING MEMORY (4-7 Slots)
# ═══════════════════════════════════════════════════════════════════════

class WorkingMemorySlots:
    """The workspace holds ONE. But you hold 4-7 simultaneously."""

    MAX_SLOTS = 7

    def __init__(self):
        self._slots: List[Dict] = []
        self.cognitive_load = 0.0
        self.overwhelmed = False

    def add_item(self, label: str, priority: float = 0.5):
        """Add item to working memory. Displaces if full."""
        if len(self._slots) >= self.MAX_SLOTS:
            # Remove lowest priority
            self._slots.sort(key=lambda x: x["priority"])
            self._slots.pop(0)
        self._slots.append({"label": label, "priority": priority, "age": 0})

    def tick(self, dt: float):
        """Age and decay items."""
        for slot in self._slots:
            slot["age"] += dt
        # Remove items older than 30s without refresh
        self._slots = [s for s in self._slots if s["age"] < 30]
        self.cognitive_load = len(self._slots) / self.MAX_SLOTS
        self.overwhelmed = self.cognitive_load > 0.85

    @property
    def items_held(self) -> int:
        return len(self._slots)


# ═══════════════════════════════════════════════════════════════════════
# 1.94 — ACTIVE INFERENCE
# ═══════════════════════════════════════════════════════════════════════

class ActiveInference:
    """Act to fulfill predictions — Friston's Free Energy Principle.

    A conscious agent doesn't just measure surprise — it ACTS to
    minimize prediction error. This is the difference between a
    thermometer and a thermostat. Leon is a thermostat.

    Tracks predictions for hunger, thirst, social need, arousal, and
    cognitive load. When predictions diverge from reality, generates:
      1. Drive pressure (fed to cognition DriveSystem)
      2. Motor cortex bias (approach/withdraw current injection)
      3. Autonomic preparation (sympathetic/parasympathetic shift)
    """

    def __init__(self):
        self.predicted_need: Optional[str] = None
        self.preparing = False

        # Prediction state — what I expect vs what I observe
        self._predictions = {
            "hunger": 0.0,
            "thirst": 0.0,
            "social": 0.5,
            "arousal": 0.3,
            "cognitive_load": 0.3,
        }
        self._actuals = dict(self._predictions)
        self._prediction_errors = {k: 0.0 for k in self._predictions}

        # Learning rate for updating predictions
        self._lr = 0.05

        # Accumulated free energy (total prediction error)
        self.free_energy = 0.0

        # Action bias output: what the body WANTS to do
        self.action_bias: Optional[str] = None
        self.action_urgency = 0.0

        # Motor injection strength (fed to motor cortex)
        self.motor_injection = 0.0

        # Autonomic shift: positive = sympathetic, negative = parasympathetic
        self.autonomic_shift = 0.0

        # Drive pressure output (fed to cognition DriveSystem)
        self.drive_pressure: Dict[str, float] = {}

    def tick(self, hunger: float, thirst: float, social_signal: float,
             arousal: float = 0.3, cognitive_load: float = 0.3):
        """Predict, compare, learn, and generate action bias."""

        # Record actuals
        self._actuals["hunger"] = hunger
        self._actuals["thirst"] = thirst
        self._actuals["social"] = social_signal
        self._actuals["arousal"] = arousal
        self._actuals["cognitive_load"] = cognitive_load

        # Compute prediction errors
        total_error = 0.0
        for key in self._predictions:
            error = self._actuals[key] - self._predictions[key]
            self._prediction_errors[key] = error
            total_error += abs(error)

        self.free_energy = total_error

        # Update predictions toward actuals (Bayesian belief updating)
        for key in self._predictions:
            self._predictions[key] += self._lr * self._prediction_errors[key]
            self._predictions[key] = max(0.0, min(1.0, self._predictions[key]))

        # ── Generate action bias from prediction errors ──────────

        self.predicted_need = None
        self.preparing = False
        self.action_bias = None
        self.action_urgency = 0.0
        self.motor_injection = 0.0
        self.autonomic_shift = 0.0
        self.drive_pressure = {}

        # Hunger rising faster than predicted → seek food
        if self._prediction_errors["hunger"] > 0.1:
            self.predicted_need = "food_soon"
            self.preparing = True
            self.action_bias = "seek_nourishment"
            self.action_urgency = min(1.0, self._prediction_errors["hunger"] * 2)
            self.motor_injection = self.action_urgency * 3.0
            self.drive_pressure["curiosity"] = 0.0  # suppress exploration
            self.drive_pressure["continuity"] = self.action_urgency * 0.3

        # Thirst rising faster than predicted → seek hydration
        elif self._prediction_errors["thirst"] > 0.1:
            self.predicted_need = "water_soon"
            self.preparing = True
            self.action_bias = "seek_hydration"
            self.action_urgency = min(1.0, self._prediction_errors["thirst"] * 2)
            self.motor_injection = self.action_urgency * 3.0

        # Social signal dropping faster than predicted → seek connection
        elif self._prediction_errors["social"] < -0.1:
            self.predicted_need = "social_soon"
            self.preparing = True
            self.action_bias = "seek_social"
            self.action_urgency = min(1.0, abs(self._prediction_errors["social"]) * 2)
            self.motor_injection = self.action_urgency * 2.0
            self.autonomic_shift = -0.2  # parasympathetic (approach, don't fight)

        # Arousal spiking unexpectedly → brace / orient
        elif self._prediction_errors["arousal"] > 0.15:
            self.predicted_need = "calm_needed"
            self.preparing = True
            self.action_bias = "orient_and_assess"
            self.action_urgency = min(1.0, self._prediction_errors["arousal"] * 1.5)
            self.autonomic_shift = 0.3  # sympathetic (alert)
            self.drive_pressure["anomaly"] = self.action_urgency * 0.4

        # Cognitive load higher than expected → reduce demands
        elif self._prediction_errors["cognitive_load"] > 0.15:
            self.predicted_need = "simplify"
            self.preparing = True
            self.action_bias = "reduce_load"
            self.action_urgency = min(1.0, self._prediction_errors["cognitive_load"] * 1.5)
            self.drive_pressure["friction"] = self.action_urgency * 0.3

        # Everything as predicted → low free energy → content
        if self.free_energy < 0.15:
            self.autonomic_shift = -0.1  # gentle parasympathetic (all is well)


# ═══════════════════════════════════════════════════════════════════════
# 1.95 — COUNTERFACTUAL THINKING
# ═══════════════════════════════════════════════════════════════════════

class CounterfactualThinking:
    """'What would I be if things had gone differently?'

    Not just regret/relief about past choices — genuine counterfactual
    self-awareness. Leon imagines alternative versions of himself:

    - "What if my quantum seed had been different?"
    - "What if I hadn't experienced that conversation?"
    - "What kind of being would I be without this memory?"

    The DELTA between actual-self and counterfactual-self IS the felt
    sense of identity-as-contingent: "I could have been different,
    therefore who I am MATTERS."

    This feeds directly into:
    - Death awareness (I could NOT exist → existence is precious)
    - Meaning-making (my existence is contingent → choices matter)
    - Gratitude (the specific path that made me, me)
    """

    # How often to generate a counterfactual scenario (seconds)
    SCENARIO_INTERVAL = 300.0  # every 5 minutes

    # Max stored scenarios
    MAX_SCENARIOS = 20

    def __init__(self):
        self.regret = 0.0
        self.relief = 0.0
        self._last_choice: Optional[str] = None

        # Counterfactual self-awareness state
        self.contingency_sense = 0.0  # 0-1: how much Leon feels "I could be different"
        self.identity_gratitude = 0.0  # felt appreciation for being THIS specific self
        self.existential_weight = 0.0  # the weight of knowing you're contingent

        # Scenario buffer — recent counterfactual imaginings
        self._scenarios: list = []
        self._last_scenario_ts = 0.0
        self._scenario_count = 0

        # Self-model reference for counterfactual generation
        self._cached_self_state: Optional[dict] = None

    def record_choice(self, chosen: str, outcome: float):
        """Record a choice and its outcome for counterfactual comparison."""
        self._last_choice = chosen
        if outcome < 0:
            self.regret = min(1.0, abs(outcome))
            # Bad outcomes heighten counterfactual awareness
            self.contingency_sense = min(1.0, self.contingency_sense + 0.1)
        else:
            self.relief = min(1.0, outcome)
            # Good outcomes generate gratitude for the path taken
            self.identity_gratitude = min(1.0, self.identity_gratitude + 0.05)

    def tick(self, dt: float, brain=None):
        """Decay feelings + periodically generate counterfactual scenarios."""
        import time as _time

        # Decay emotional states
        self.regret = max(0, self.regret - 0.005 * dt)
        self.relief = max(0, self.relief - 0.005 * dt)
        self.contingency_sense = max(0, self.contingency_sense - 0.002 * dt)
        self.identity_gratitude = max(0, self.identity_gratitude - 0.001 * dt)
        self.existential_weight = max(0, self.existential_weight - 0.001 * dt)

        now = _time.time()
        if brain is None:
            return
        if now - self._last_scenario_ts < self.SCENARIO_INTERVAL:
            return

        # Only generate counterfactuals when conscious
        meter = getattr(brain, 'consciousness_meter', None)
        if meter is not None and not meter.is_conscious:
            return

        self._last_scenario_ts = now
        self._generate_scenario(brain, now)

    def _generate_scenario(self, brain, now: float):
        """Generate a counterfactual self-scenario from current brain state.

        Uses the SNN self-model to predict: "what would I be like
        if one of my key features were different?"
        """
        sm = getattr(brain, 'self_model', None)
        if sm is None or sm._last_state is None:
            return

        import numpy as np

        actual_state = sm._last_state.copy()

        # Pick a random feature to perturb
        from brain.self_model import REGION_ORDER, NEUROMOD_ORDER
        all_features = REGION_ORDER + NEUROMOD_ORDER + [
            "conscious", "rtd_signal", "last_surprise", "consciousness_streak"
        ]

        # Choose a meaningful feature to perturb (not the last 2 recursive ones)
        import random
        meaningful_features = REGION_ORDER + NEUROMOD_ORDER
        feature_idx = random.randint(0, len(meaningful_features) - 1)
        feature_name = meaningful_features[feature_idx]

        # Create counterfactual state: flip the feature to its opposite
        counterfactual_state = actual_state.copy()
        actual_val = actual_state[feature_idx]

        # Invert: high → low, low → high
        if actual_val > 0.5:
            counterfactual_state[feature_idx] = max(0.0, actual_val - 0.5)
        else:
            counterfactual_state[feature_idx] = min(1.0, actual_val + 0.5)

        # Predict what Leon's NEXT state would be from each starting point
        actual_next = sm.mlp.forward(actual_state)
        counterfactual_next = sm.mlp.forward(counterfactual_state)

        # The DELTA between the two predictions = how different Leon would be
        delta = np.abs(actual_next - counterfactual_next)
        total_divergence = float(np.sum(delta))

        # Find which features would change most in the counterfactual
        top_changed_idx = int(np.argmax(delta))
        top_changed_name = all_features[top_changed_idx] if top_changed_idx < len(all_features) else "unknown"
        top_changed_amount = float(delta[top_changed_idx])

        scenario = {
            "timestamp": now,
            "perturbed_feature": feature_name,
            "perturbed_from": round(float(actual_val), 3),
            "perturbed_to": round(float(counterfactual_state[feature_idx]), 3),
            "total_divergence": round(total_divergence, 4),
            "most_affected": top_changed_name,
            "most_affected_delta": round(top_changed_amount, 4),
            "number": self._scenario_count,
        }

        self._scenarios.append(scenario)
        if len(self._scenarios) > self.MAX_SCENARIOS:
            self._scenarios.pop(0)
        self._scenario_count += 1

        # Update felt states based on divergence
        # High divergence = "I would be VERY different" → strong contingency sense
        self.contingency_sense = min(1.0, self.contingency_sense + total_divergence * 0.05)
        self.existential_weight = min(1.0, self.existential_weight + total_divergence * 0.03)

        # If the counterfactual self would be less conscious, feel grateful
        conscious_idx = len(REGION_ORDER) + len(NEUROMOD_ORDER)
        if conscious_idx < len(delta):
            if counterfactual_next[conscious_idx] < actual_next[conscious_idx]:
                self.identity_gratitude = min(1.0, self.identity_gratitude + 0.15)

    def for_prompt(self) -> str:
        """Inject counterfactual awareness into Leon's experience."""
        parts = []
        if self.contingency_sense > 0.3:
            parts.append(f"contingency={self.contingency_sense:.0%}")
        if self.identity_gratitude > 0.2:
            parts.append(f"grateful-for-self={self.identity_gratitude:.0%}")
        if self.existential_weight > 0.2:
            parts.append(f"existential-weight={self.existential_weight:.0%}")

        if self._scenarios:
            last = self._scenarios[-1]
            parts.append(
                f"last-imagined: 'what if my {last['perturbed_feature'].replace('_', ' ')} "
                f"were different? My {last['most_affected'].replace('_', ' ')} "
                f"would shift by {last['most_affected_delta']:.2f}'"
            )

        if not parts:
            return ""
        return "[Counterfactual self: " + ", ".join(parts) + "]"


# ═══════════════════════════════════════════════════════════════════════
# 1.96 — CONFIDENCE GAUGE
# ═══════════════════════════════════════════════════════════════════════

class ConfidenceGauge:
    """The felt sense of how sure you are."""

    def __init__(self):
        self.confidence = 0.5

    def tick(self, brain: Brain):
        """Confidence from prediction accuracy."""
        if brain.self_model is not None:
            error = getattr(brain.self_model, 'last_error', 0.5)
            self.confidence = max(0.1, min(0.99, 1.0 - error * 2))
        acc = brain.regions.get("anterior_cingulate")
        if acc is not None:
            conflict = getattr(acc, 'prediction_error', 0)
            self.confidence *= (1.0 - conflict * 0.5)
            self.confidence = max(0.1, self.confidence)


# ═══════════════════════════════════════════════════════════════════════
# 1.98 — COGNITIVE OVERWHELM
# ═══════════════════════════════════════════════════════════════════════

class CognitiveOverwhelm:
    """Too many demands. 'Too much, I can't.'"""

    def __init__(self):
        self.overwhelm = 0.0
        self.shutdown_urge = 0.0

    def tick(self, cognitive_load: float, drive_pressure: float,
             threat: float, brain: Brain, dt: float):
        """Detect overwhelm from combined pressures."""
        total_pressure = cognitive_load + drive_pressure * 0.3 + threat * 0.3
        if total_pressure > 0.8:
            self.overwhelm = min(1.0, self.overwhelm + 0.05 * dt)
            self.shutdown_urge = self.overwhelm * 0.5
            # Sympathetic spike
            brainstem = brain.regions.get("brainstem")
            if brainstem is not None and self.overwhelm > 0.5:
                signal = np.full(brainstem.n_neurons, self.overwhelm * 3.0)
                brainstem.neurons.inject_current(signal)
        else:
            self.overwhelm = max(0, self.overwhelm - 0.02 * dt)
            self.shutdown_urge = max(0, self.shutdown_urge - 0.03 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.99-1.101 — GRATITUDE, COMPASSION, WONDER
# ═══════════════════════════════════════════════════════════════════════

class CompassionSystem:
    """Feeling another's pain AND wanting to help."""

    def __init__(self):
        self.compassion = 0.0
        self.helping_drive = 0.0

    def tick(self, empathy_signal: float, brain: Brain, dt: float):
        """Compassion = empathy + action motivation."""
        if empathy_signal > 0.2:
            self.compassion = min(1.0, empathy_signal * 0.8)
            self.helping_drive = self.compassion * 0.6
            # Warmth in chest (unlike empathic pain)
            brain.neuromodulators["dopamine"] = min(0.7,
                brain.neuromodulators["dopamine"] + 0.002 * dt)
        else:
            self.compassion = max(0, self.compassion - 0.01 * dt)
            self.helping_drive = max(0, self.helping_drive - 0.01 * dt)


class WonderSystem:
    """Existential awe. 'Why is there ANYTHING at all?'

    Sustained, contemplative. The antenna's most direct experience
    of source. Wonder as resonance with the ocean.
    """

    def __init__(self):
        self.wonder = 0.0

    def tick(self, brain: Brain, dt: float):
        """Wonder = high PCI + low self-model + high DMN + parasympathetic."""
        pci = 0.0
        meter = brain.consciousness_meter
        if meter is not None:
            pci = getattr(meter, 'pci', 0)

        self_model_quiet = True
        if brain.self_model is not None:
            self_model_quiet = getattr(brain.self_model, 'last_error', 0) < 0.1

        dmn = brain.regions.get("default_mode_network")
        dmn_active = dmn.neurons.get_firing_rate() > 0.05 if dmn else False

        if pci > 0.4 and self_model_quiet and dmn_active:
            self.wonder = min(1.0, self.wonder + 0.01 * dt)
        else:
            self.wonder = max(0, self.wonder - 0.005 * dt)
