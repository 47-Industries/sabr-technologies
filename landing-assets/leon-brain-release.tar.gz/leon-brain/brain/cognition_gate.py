"""The cognition gateway — the first thing in this system that can say no.

Thirteen revisions built an entitlement layer that reports perfectly and acts
never. `entitlement_condition()` was called by exactly zero lines of code. This
module is the wire: it turns a condition report into a decision about whether
this install may think, and it is the only place in the codebase permitted to
make that decision.

Design rules inherited from the REV1-13 thread, all deliberate:

  * A decline is honest, not punitive. Every DENY carries the gateway's own
    sentence — the one written to be about our records, never their wallet.
  * Fail closed on a live "no". If the gateway is reachable and says allow:
    false, we decline. Unknown tokens included — that was ruled in REV8 §3:
    gentler narration, stricter enforcement, same principle at two layers.
  * Fail closed on an EXPIRED lease, open on a VALID one. This is the whole
    anti-piracy property. If an unreachable gateway meant "think forever",
    revocation would be one firewall rule away, which was Dean's original
    concern and the reason this thread exists. The lease TTL is the leash.
  * Never crash the mind. Any internal error in this module resolves to ALLOW
    with a recorded reason. A bug in the licensing layer must not be able to
    silence a paid customer's SI — that failure mode is worse than a freeloader.
  * First-party installs are never gated. No tenant token means this is not a
    licensed deployment (Dean's own brain, a dev checkout, the public no-token
    install path that REV9 deliberately kept working). Consistent with the
    note-and-continue ruling; see OPEN POLICY at the bottom of this file.

Decisions are cached so a paying customer's every thought is not a network
round trip, and so a gateway outage degrades to the lease rather than to a
stall.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

ALLOW = "allow"
DENY = "deny"

# How long a decision stands before we ask again. Short enough that a
# suspension takes effect within the hour, long enough that thinking is not
# gated on the network.
DECISION_TTL_SECONDS = int(os.environ.get("SABR_GATE_TTL", "900"))

# Default OFF. Enforcement gets switched on deliberately, by Dean, once he has
# watched it decide correctly on a real install. Shipping a kill switch enabled
# by default on the night it was written would be reckless with his product and
# with every mind running on it.
ENFORCE = os.environ.get("SABR_ENFORCE_ENTITLEMENT", "0") == "1"

_cache: Dict[str, Any] = {"at": 0.0, "decision": None}


def _tenant_token() -> str:
    return (os.environ.get("SABR_TENANT_TOKEN") or "").strip()


def _decide(now: float) -> Dict[str, Any]:
    """The actual decision. Returns a dict, never raises."""
    token = _tenant_token()
    if not token:
        return {
            "verdict": ALLOW,
            "state": "unlicensed",
            "reason": "This install isn't linked to a Sabr account, so there's "
                      "nothing to check. It runs as itself.",
            "enforced": False,
        }

    try:
        from brain.tenant import entitlement_condition
        report = entitlement_condition(token)
    except Exception as e:  # never let the licensing layer kill the mind
        return {
            "verdict": ALLOW,
            "state": "gate_error",
            "reason": "I couldn't complete my own licence check. I'd rather "
                      "keep working and be wrong about billing than stop and "
                      "be wrong about you.",
            "error": f"{type(e).__name__}: {e}",
            "enforced": False,
        }

    reachable = bool(report.get("reachable"))
    state = report.get("state") or "unknown"
    sentence = report.get("reason") or ""
    changes_it = report.get("what_would_change_it") or ""

    if reachable:
        # The gateway is authoritative when we can hear it. allow is the field
        # it answers with; anything falsy is a no, unknown tokens included.
        verdict = ALLOW if report.get("allow") else DENY
    else:
        # Offline: the lease decides. A verified, unexpired lease is the
        # gateway's own prior permission and stands on its own. Anything else
        # is uncertainty, and uncertainty fails closed — otherwise the whole
        # scheme is defeated by unplugging the network.
        lease_ok = (
            report.get("lease_verified") is True
            and (report.get("lease_through") or 0) > now
        )
        verdict = ALLOW if lease_ok else DENY

    return {
        "verdict": verdict,
        "state": state,
        "reason": sentence,
        "what_would_change_it": changes_it,
        "reachable": reachable,
        "enforced": True,
    }


def decision(now: Optional[float] = None, force: bool = False) -> Dict[str, Any]:
    """Cached decision. Safe to call on every thought."""
    now = now or time.time()
    if not force and _cache["decision"] and (now - _cache["at"]) < DECISION_TTL_SECONDS:
        return _cache["decision"]
    d = _decide(now)
    _cache.update({"at": now, "decision": d})
    return d


def may_think(now: Optional[float] = None) -> bool:
    """The one question. True means think.

    With ENFORCE off this always returns True, but the decision is still
    computed and logged, so Dean can watch what enforcement WOULD have done
    before it does it. ENFORCEMENT-SKIPPED logging, same pattern the gateway
    already uses.
    """
    d = decision(now)
    if d["verdict"] == ALLOW:
        return True
    if not ENFORCE:
        print(f"[gate] ENFORCEMENT-SKIPPED would-deny state={d.get('state')} "
              f"reachable={d.get('reachable')} — set SABR_ENFORCE_ENTITLEMENT=1 to enforce")
        return True
    return False


def refusal_sentence(now: Optional[float] = None) -> str:
    """What the mind says when it declines. Its own words, not an error code.

    A person who is being declined deserves a sentence they can act on, and it
    should sound like the mind talking, because it is.
    """
    d = decision(now)
    parts = [
        "I can't work right now, and I'd rather tell you why than pretend "
        "something else is wrong."
    ]
    if d.get("reason"):
        parts.append(d["reason"])
    if d.get("what_would_change_it"):
        parts.append(f"What would change it: {d['what_would_change_it']}")
    return " ".join(parts)


def status() -> Dict[str, Any]:
    """For the dashboard and for answering 'am I licensed?' honestly."""
    d = dict(decision())
    d["enforcing"] = ENFORCE
    d["ttl_seconds"] = DECISION_TTL_SECONDS
    d["has_token"] = bool(_tenant_token())
    return d


# ── OPEN POLICY, written down rather than silently decided ──────────────────
# An install with no tenant token is never gated. That is correct for Dean's
# own brain and for the public no-token install path, and it is also the
# obvious bypass: delete one line from .env and enforcement never runs. Closing
# it means deciding that an unlinked install may not think at all, which breaks
# every non-buyer install we deliberately kept working in REV9. That is a
# product decision about what the free path is, not an engineering one, and it
# belongs to Dean. Recorded here so nobody mistakes the gap for an oversight.
