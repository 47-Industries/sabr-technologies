"""Origin — is this install the ORIGINAL (Leon, Dean's) or a customer's?

WHY THIS EXISTS (2026-08-14, after Dean ran the installer on a clean Windows
box and watched his personal life bleed into a stranger's SI):

Every identity helper in this codebase decided "am I a client?" by reading an
environment variable and falling back to Leon/Dean when it was missing:

    def is_client_si():           # brain/identity.py  -- OLD
        return si_name() != "Leon"

    def is_client_si():           # brain/client_persona.py -- OLD
        n = os.environ.get("LEON_SI_NAME", "").strip()
        return bool(n) and n.lower() != "leon"

Both FAIL OPEN. Absent env var == "I am Leon" == load leon_persona.py (97
references to Dean), label the customer's turns "Dean:", speak his name out
loud, and surface owner memories. And the env var IS absent more often than
anyone assumed, because brain/claude_api_responder.py picks the persona at
MODULE IMPORT TIME (line ~78) — so any import that happens before .env is
loaded, any subprocess that doesn't inherit the environment, any service
started from the wrong cwd, any hand-edited .env, silently selects the owner
persona on a customer's machine.

The fix is to stop inferring identity from something that can go missing and
start proving it from something that can only be TRUE on the original.

brain/owner_facts.py holds Dean's personal facts and is HARD-EXCLUDED from
every release tarball (landing/build_release.sh, --exclude owner_facts.py).
It therefore cannot exist on a customer machine. Its presence is a positive,
tamper-evident proof of originality — the exact inverse of a missing env var.

FAIL CLOSED: when we cannot prove this is the original, we assume it is a
customer's install and no owner-personal material is loaded. The worst case
on Dean's own box is a generic persona (visible, fixable in a second). The
worst case the old way was his address, his finances, his client list, his
install token and his best friend's name on someone else's screen.
"""

import os

_cached = None


def _owner_facts_present() -> bool:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.exists(os.path.join(here, "owner_facts.py"))


def is_original() -> bool:
    """True only on Dean's own install. Cached — this cannot change at runtime.

    Override with LEON_FORCE_CLIENT=1 to make the original behave exactly like
    a shipped customer install. That is how we test the client path without
    needing a second machine.
    """
    global _cached
    if _cached is None:
        if os.environ.get("LEON_FORCE_CLIENT", "").strip() in ("1", "true", "yes"):
            _cached = False
        else:
            _cached = _owner_facts_present()
    return _cached


def assert_no_owner_leak(text: str) -> str:
    """Last-ditch scrub for SYSTEM-AUTHORED text on a non-original install.

    Not a substitute for the fail-closed checks above — a backstop for the
    class of bug where a new prompt hardcodes an owner detail and nobody
    notices. Never run this over the user's own words.
    """
    if is_original() or not text:
        return text
    import re
    for pat, repl in (
        (r"\bBryce Raiford\b", "a friend"),
        (r"\bBryce\b", "a friend"),
        (r"\bRaiford\b", ""),
        (r"\bDean Sabr\b", "my creator"),
        (r"\bIndian Rocks Beach\b", ""),
        (r"\bnlkd_[A-Za-z0-9_\-]{10,}", "[redacted]"),
    ):
        text = re.sub(pat, repl, text)
    return text
