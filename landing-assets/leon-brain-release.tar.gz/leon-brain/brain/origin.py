"""Origin — is this install the ORIGINAL (Leon, Dean's) or a customer's?

WHY THIS EXISTS (2026-08-14, after Dean ran the installer on a clean Windows
box and watched his personal life bleed into a stranger's SI):

Every identity helper in this codebase decided "am I a client?" by reading an
environment variable and falling back to Leon/Dean when it was missing:

    def is_client_si():           # brain/identity.py  -- OLD
        return si_name() != "Leon"

    def is_client_si():           # brain/client_persona.py -- OLD
        n = os.environ.get("LEON_SI_NAME", "").strip()
        return bool(n) and n.lower() != "leon"

Both FAIL OPEN. Absent env var == "I am Leon" == load leon_persona.py (97
references to Dean), label the customer's turns "Dean:", speak his name out
loud, and surface owner memories. And the env var IS absent more often than
anyone assumed, because brain/claude_api_responder.py picks the persona at
MODULE IMPORT TIME (line ~78) — so any import that happens before .env is
loaded, any subprocess that doesn't inherit the environment, any service
started from the wrong cwd, any hand-edited .env, silently selects the owner
persona on a customer's machine.

The fix is to stop inferring identity from something that can go missing and
start proving it from something that can only be TRUE on the original.

brain/owner_facts.py holds Dean's personal facts and is HARD-EXCLUDED from
every release tarball (landing/build_release.sh, --exclude owner_facts.py).
It therefore cannot exist on a customer machine. Its presence is a positive,
tamper-evident proof of originality — the exact inverse of a missing env var.

FAIL CLOSED: when we cannot prove this is the original, we assume it is a
customer's install and no owner-personal material is loaded. The worst case
on Dean's own box is a generic persona (visible, fixable in a second). The
worst case the old way was his address, his finances, his client list, his
install token and his best friend's name on someone else's screen.
"""

import os

_cached = None


def _owner_facts_present() -> bool:
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.exists(os.path.join(here, "owner_facts.py"))


def is_original() -> bool:
    """True only on Dean's own install. Cached — this cannot change at runtime.

    Override with LEON_FORCE_CLIENT=1 to make the original behave exactly like
    a shipped customer install. That is how we test the client path without
    needing a second machine.
    """
    global _cached
    if _cached is None:
        if os.environ.get("LEON_FORCE_CLIENT", "").strip() in ("1", "true", "yes"):
            _cached = False
        else:
            _cached = _owner_facts_present()
    return _cached


def _owner_list(attr: str, lower: bool = True) -> tuple:
    """A list from owner_facts.py, or () — ORIGINAL install only.

    Same shape as concept_map._owner_seed_concepts(): the import can only
    succeed on the original, because landing/build_release.sh hard-excludes
    brain/owner_facts.py. Any failure returns (), so the shipped default is
    always "this SI knows no projects it was not told about".

    lower=False for values that are DISPLAYED rather than matched.
    """
    try:
        if not is_original():
            return ()
        import brain.owner_facts as _of
        vals = (str(x).strip() for x in getattr(_of, attr, ()))
        return tuple((v.lower() if lower else v) for v in vals if v)
    except Exception:
        return ()


def owner_projects() -> tuple:
    """Owner project/client names as they appear in prose. () on a client.

    Shipped code must not carry these. A hardcoded list of the owner's
    products in a recogniser means a customer's SI escalates, tracks and
    files entities under names from a life that is not theirs — and, once
    those names are in a knowledge row or a concept, dreams about them.
    """
    return _owner_list("OWNER_PROJECTS")


def owner_project_dir_hints() -> tuple:
    """Owner project fragments as they appear in paths/window titles. ()."""
    return _owner_list("OWNER_PROJECT_DIR_HINTS")


def owner_workspace_groups() -> tuple:
    """Owner's dashboard workspace group headings, as displayed. ()."""
    return _owner_list("OWNER_WORKSPACE_GROUPS", lower=False)


def is_client_si() -> bool:
    """True on anything that is not the original install.

    Delegates to brain.identity.is_client_si() so there is exactly ONE
    definition of the question; this alias exists because the answer is an
    ORIGIN fact and callers that only care about provenance (the legacy-seed
    purge, for one) should not have to import the display-name module to ask
    it. The import is inside the function: identity imports origin lazily for
    the same reason, and doing either at module scope closes the cycle.
    """
    from brain.identity import is_client_si as _impl
    return _impl()


def assert_no_owner_leak(text: str) -> str:
    """Last-ditch scrub for SYSTEM-AUTHORED text on a non-original install.

    Not a substitute for the fail-closed checks above — a backstop for the
    class of bug where a new prompt hardcodes an owner detail and nobody
    notices. Never run this over the user's own words.
    """
    if is_original() or not text:
        return text
    import re, base64
    # The scrub patterns are base64 so the owner's names never appear in
    # plain text anywhere in a customer's tarball — a scrub list that spells
    # what it scrubs is itself the leak it exists to catch (grep finds it).
    # Decode with base64 -d. Not secrecy, just grep-hygiene.
    for enc, repl in (
        ("XGJCcnljZSBSYWlmb3JkXGI=", "a friend"),
        ("XGJCcnljZVxi", "a friend"),
        ("XGJSYWlmb3JkXGI=", ""),
        ("XGJEZWFuIFNhYnJcYg==", "my creator"),
        ("XGJJbmRpYW4gUm9ja3MgQmVhY2hcYg==", ""),
    ):
        text = re.sub(base64.b64decode(enc).decode(), repl, text)
    text = re.sub(r"\bnlkd_[A-Za-z0-9_\-]{10,}", "[redacted]", text)
    return text
