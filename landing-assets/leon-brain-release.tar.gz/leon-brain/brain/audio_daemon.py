"""
audio_daemon.py — Continuous ears for Leon.

Same architecture as vision_daemon: background thread, change detection
before heavy processing, direct SNN injection, graceful degradation.

Design constraints:
  - Always-on mic via sounddevice (low-latency, callback-based).
  - Change detection on spectral energy — cheap FFT comparison.
    "Nothing changed" frames cost < 2ms.
  - NO speech-to-text on ambient audio. Same principle as no OCR on screen.
    Leon hears the room as spectral texture, not transcribed words.
    Speech-to-text only runs on Dean's direct voice input (wake word path).
  - Spectral features go directly into auditory_cortex via
    brain.inject_sensory_input('audio', ...). No text encoder.
  - Graceful degradation: no mic → daemon runs but with hearing disabled.
  - Thread-safe: all shared state behind a single RLock.

What Leon hears:
  - Silence vs activity (room presence)
  - Sudden sounds (door, clap, notification) → amygdala startle
  - Ambient tone shifts (music, fan, rain) → mood/atmosphere
  - Voice presence (someone is speaking) without knowing WHAT is said
  - Rhythmic patterns (typing, tapping) → behavioral inference

Public API:
  start(brain, knowledge_store)
  stop()
  get_state()
"""

from __future__ import annotations

import io
import os
import time
import threading
from typing import Any, Dict, Optional, Tuple

import numpy as np

# ── Module-level state ─────────────────────────────────────────────────
_lock = threading.RLock()
_thread: Optional[threading.Thread] = None
_running = False

_brain = None
_knowledge_store = None
_stt = None        # faster-whisper STT instance (lazy-loaded)
_stt_lock = threading.Lock()

# Tunables
SAMPLE_RATE: int = 16000           # 16kHz — enough for room audio
CHUNK_DURATION_S: float = 0.5      # 500ms per chunk
CHUNK_SAMPLES: int = int(SAMPLE_RATE * CHUNK_DURATION_S)
ANALYSIS_INTERVAL_S: float = 2.0   # analyze every 2s (4 chunks)
IDLE_STRETCH_FACTOR: float = 3.0
IDLE_THRESHOLD_FRAMES: int = 8     # 8 consecutive no-change → stretch
CHANGE_THRESHOLD: float = 0.15     # spectral diff to count as change
STARTLE_THRESHOLD: float = 0.6     # sudden energy spike → amygdala
SILENCE_THRESHOLD: float = 0.01    # below this = silence
N_BANDS: int = 32                  # spectral bands for comparison
AUDIO_FEATURE_DIM: int = 256       # dimension for SNN injection

_state: Dict[str, Any] = {
    "running": False,
    "mic_available": False,
    "analyses": 0,
    "changes_detected": 0,
    "startles": 0,
    "last_event": "",
    "last_event_ts": 0.0,
    "ambient_level": 0.0,
    "consecutive_idle": 0,
    "current_interval_s": ANALYSIS_INTERVAL_S,
    "silence_streak_s": 0.0,
    "presence_detected": False,
    # System audio (calls, music, notifications)
    "system_audio_available": False,
    "system_scene": "",
    "system_rms": 0.0,
    "call_detected": False,
    # Continuous listening — always-on speech comprehension
    "last_transcript": "",
    "last_transcript_ts": 0.0,
    "speech_detected": False,
    "addressed_to_leon": False,
    "transcripts_total": 0,
}

_prev_spectrum: Optional[np.ndarray] = None
_prev_system_spectrum: Optional[np.ndarray] = None
_audio_buffer: list = []           # ring buffer of recent mic chunks
_system_buffer: list = []          # ring buffer of system audio (calls, music, etc.)
_buffer_lock = threading.Lock()

# ── TTS self-hearing suppression ──────────────────────────────────────
# When Leon speaks (TTS plays through speakers), the mic picks up his own
# voice. There used to be a module-local `_tts_playing_until` deadline here,
# a second copy of the same state in sensor_relay's tts-gate thread, and a
# third in the wake listener's `_paused` flag. Three copies, three different
# latencies, all evaluated at CONSUME time against the current wall clock —
# which is why every timing patch raced.
#
# There is now exactly ONE owner: brain.voice.audio_gate.LEDGER, a ledger of
# [start_ts, end_ts] speaker-active intervals that the TTS player publishes
# into directly. Everything below is a thin shim over it, and every gating
# decision is made against the CAPTURE timestamp of the audio in question.
from brain.voice import audio_gate as _gate   # noqa: E402


def pause_for(seconds: float) -> None:
    """Publish a speaker-active interval of `seconds` starting now.

    Kept under the old name because the TTS dispatch calls it, but it no
    longer sets a deadline anyone polls — it writes one interval into the
    single ledger, which is then queried per captured chunk.
    """
    _gate.publish_playback(max(0.0, float(seconds)), source="tts")


def barge_in(stop_ts: Optional[float] = None) -> float:
    """Playback was cut off — Dean took the floor (push-to-talk) or the
    turn was aborted.

    Push-to-talk does NOT bypass the gate; it ENDS the speaker interval.
    The interval closes at stop_ts + audio_gate.SINK_DRAIN_S because the
    audio already inside the sound sink is still on its way to the
    speakers when stop() returns — feeding that drain window to STT as
    "Dean said it" is the exact bug a bypass flag would reintroduce.
    Fire on the RISING edge only: a floor claim that refreshes itself
    while held must not keep truncating intervals.
    """
    return _gate.note_barge_in(stop_ts=stop_ts)


def is_paused() -> bool:
    """True if the speakers are live RIGHT NOW.

    Only valid for "should I start something now?" questions. Never use
    it to judge already-captured audio — use `_gate.audio_is_speaker(ts)`
    with that audio's capture timestamp instead.
    """
    return _gate.speaker_active_now()


# ── Live room-voice signal (fed by /api/relay/audio from the PC mic) ──
# The PC-side wake/STT path only reports Dean's words AFTER he finishes a
# sentence, so cooldowns keyed on _last_user_message_ts cannot stop Leon
# from talking over him mid-utterance. The sensor relay streams mic RMS
# continuously — stamp it here so unsolicited speech can yield in realtime.
_last_room_voice_ts: float = 0.0


def note_room_voice(rms: float) -> None:
    """Stamp live voice energy from the relayed PC mic. Ignores Leon's own
    TTS playback window so he doesn't gate himself on his own voice."""
    global _last_room_voice_ts
    if rms >= _SPEECH_RMS_THRESHOLD and not is_paused():
        _last_room_voice_ts = time.time()


# ── Push-to-talk floor (the dashboard toggle) ─────────────────────────
# RMS relay is not enough. When Dean arms the dashboard toggle, the BROWSER
# grabs the mic — the relay can lose the device or go quiet, so room-voice
# energy never lands here and Leon thinks the room is empty while Dean is
# mid-sentence. That is exactly how an unsolicited line ("three files newer
# than me") landed on top of him. The floor is an explicit claim: while the
# toggle is armed, Dean has the floor, full stop. Capped so a closed tab or a
# lost key-up can never mute Leon permanently.
_ptt_floor_until: float = 0.0


def hold_floor(seconds: float = 45.0) -> None:
    """Dean armed the toggle — he owns the room until he releases it."""
    global _ptt_floor_until
    _ptt_floor_until = time.time() + seconds
    _arm_floor()


def release_floor(grace_s: float = 8.0) -> None:
    """Toggle released. Keep the floor a few more seconds: the audio still has
    to upload, transcribe and send, and an unsolicited line landing in that gap
    still reads as Leon talking over him."""
    global _ptt_floor_until
    _ptt_floor_until = time.time() + grace_s
    _disarm_floor()


def floor_held() -> bool:
    return time.time() < _ptt_floor_until


# ── HARD MUTE while Dean holds the mic (Dean, 2026-08-06) ─────────────
# floor_held() only ever gated UNSOLICITED speech (proactive/outbound).
# Every other path — a normal reply, a filler, a routine — went straight to
# the synthesizer and landed on top of him mid-sentence. Dean's rule is
# absolute: while the toggle is armed he is the only voice in the room, and
# whatever Leon was about to say is DEFERRED, not dropped. `_ptt_armed` is
# edge-state (armed until key-up), deliberately separate from the release
# grace in _ptt_floor_until — the grace exists to suppress unsolicited lines,
# but a direct answer to what he just said must not eat an 8s delay.
_ptt_armed: bool = False
# Hard cap so a lost key-up / closed tab can never mute Leon permanently.
_PTT_ARM_CAP_S: float = 120.0
_ptt_armed_since: float = 0.0


def _arm_floor() -> None:
    global _ptt_armed, _ptt_armed_since
    if not _ptt_armed:
        _ptt_armed_since = time.time()
    _ptt_armed = True


def _disarm_floor() -> None:
    global _ptt_armed
    _ptt_armed = False


def mic_armed() -> bool:
    """True while Dean physically holds the floor. Self-heals past the cap."""
    if not _ptt_armed:
        return False
    if (time.time() - _ptt_armed_since) > _PTT_ARM_CAP_S:
        return False
    return True


def await_floor(max_wait_s: float = 90.0, poll_s: float = 0.1) -> float:
    """Block until Dean is done talking. Returns seconds waited.

    Called at the mouth — every synthesis path — so there is exactly one
    answer to 'may I speak right now', and it is 'not while he is'.
    """
    if not mic_armed():
        return 0.0
    t0 = time.time()
    while mic_armed() and (time.time() - t0) < max_wait_s:
        time.sleep(poll_s)
    waited = time.time() - t0
    if waited > 0.2:
        print(f"[VOICE] deferred speech {waited:.1f}s — Dean had the floor")
    return waited


def user_speaking(window_s: float = 4.0) -> bool:
    """True if someone is talking in the room right now (explicit push-to-talk
    floor, local mic VAD, or relayed mic energy within the last few seconds).
    Unsolicited speech — proactive, goal pursuit, outbound — must stay quiet
    while this is True."""
    if floor_held():
        return True
    if _speech_active and not is_paused():
        return True
    return (time.time() - _last_room_voice_ts) < window_s


# ── 1. Spectral feature extraction ────────────────────────────────────

def _compute_spectrum(audio: np.ndarray) -> np.ndarray:
    """Compute N_BANDS log-mel-ish spectral energy from raw audio.
    Returns normalized float32 array of shape (N_BANDS,).
    Target: < 1ms.
    """
    # FFT
    windowed = audio * np.hanning(len(audio))
    fft = np.abs(np.fft.rfft(windowed))
    freqs = fft.size

    # Bin into N_BANDS mel-spaced bands (approximate with log spacing)
    bands = np.zeros(N_BANDS, dtype=np.float32)
    edges = np.logspace(np.log10(1), np.log10(freqs), N_BANDS + 1).astype(int)
    for i in range(N_BANDS):
        lo, hi = edges[i], edges[i + 1]
        if hi <= lo:
            hi = lo + 1
        bands[i] = np.mean(fft[lo:hi]) if lo < freqs else 0.0

    # Log scale + normalize
    bands = np.log1p(bands)
    mx = bands.max()
    if mx > 0:
        bands /= mx
    return bands


def _compute_features(audio: np.ndarray) -> np.ndarray:
    """Build AUDIO_FEATURE_DIM vector for SNN injection.
    Combines: spectral bands, energy envelope, zero-crossing rate,
    spectral centroid, spectral flux.
    """
    n = len(audio)
    if n == 0:
        return np.zeros(AUDIO_FEATURE_DIM, dtype=np.float32)

    # Spectral bands (32-dim)
    spectrum = _compute_spectrum(audio)

    # RMS energy
    rms = float(np.sqrt(np.mean(audio ** 2)))

    # Zero-crossing rate (proxy for pitch/noise)
    zcr = float(np.sum(np.abs(np.diff(np.sign(audio)))) / (2 * n))

    # Spectral centroid
    fft_mag = np.abs(np.fft.rfft(audio))
    freqs = np.arange(len(fft_mag))
    total = fft_mag.sum()
    centroid = float(np.sum(freqs * fft_mag) / total) if total > 0 else 0.0
    centroid /= len(fft_mag)  # normalize to 0-1

    # Pack into feature vector
    # [0:32] = spectral bands
    # [32:33] = rms
    # [33:34] = zcr
    # [34:35] = centroid
    # [35:256] = expanded spectrum (interpolated for richer SNN input)
    features = np.zeros(AUDIO_FEATURE_DIM, dtype=np.float32)
    features[:N_BANDS] = spectrum
    features[N_BANDS] = min(1.0, rms * 10)  # scale RMS
    features[N_BANDS + 1] = min(1.0, zcr * 5)
    features[N_BANDS + 2] = centroid

    # Fill remaining with interpolated spectrum for spatial richness
    remaining = AUDIO_FEATURE_DIM - (N_BANDS + 3)
    if remaining > 0:
        features[N_BANDS + 3:] = np.interp(
            np.linspace(0, N_BANDS - 1, remaining),
            np.arange(N_BANDS),
            spectrum,
        )

    return features


# ── 2. Change detection ───────────────────────────────────────────────

def detect_change(spectrum: np.ndarray, rms: float) -> Tuple[bool, float, bool]:
    """Compare current spectrum against previous.
    Returns (changed, diff_score, is_startle).
    """
    global _prev_spectrum

    if _prev_spectrum is None:
        _prev_spectrum = spectrum.copy()
        return True, 1.0, False

    diff = float(np.mean(np.abs(spectrum - _prev_spectrum)))

    # Startle: sudden energy spike relative to recent ambient
    ambient = _state["ambient_level"]
    is_startle = rms > STARTLE_THRESHOLD and rms > ambient * 3.0

    _prev_spectrum = spectrum.copy()
    return diff >= CHANGE_THRESHOLD, diff, is_startle


# ── 3. Classify ambient scene ────────────────────────────────────────

def classify_scene(spectrum: np.ndarray, rms: float, zcr: float) -> str:
    """Quick heuristic classification of what's happening acoustically.
    No ML, no STT — just spectral shape analysis.
    """
    if rms < SILENCE_THRESHOLD:
        return "silence"

    # High ZCR + moderate energy = voice-like
    if zcr > 0.1 and rms > 0.02:
        return "voice_present"

    # Low frequency dominant + steady = fan/AC/ambient
    low_energy = float(np.mean(spectrum[:8]))
    high_energy = float(np.mean(spectrum[20:]))
    if low_energy > 0.5 and high_energy < 0.2:
        return "ambient_hum"

    # Rhythmic check (high variance in recent buffers = rhythmic)
    # Broad spectrum + moderate energy = music-like
    spectral_flatness = float(np.exp(np.mean(np.log(spectrum + 1e-10)))) / (float(np.mean(spectrum)) + 1e-10)
    if spectral_flatness > 0.3 and rms > 0.03:
        return "music_or_activity"

    # Sharp transient + high energy = impact sound
    if rms > 0.1:
        return "impact"

    return "ambient"


# ── 4. Route to brain ────────────────────────────────────────────────

def route_audio(features: np.ndarray, scene: str, rms: float,
                diff_score: float, is_startle: bool) -> None:
    """Push audio observation into Leon's awareness.

    Pipeline:
      1. brain.inject_sensory_input('audio', features) — auditory_cortex direct
      2. Startle → amygdala + brainstem injection
      3. Knowledge store gets scene label only (no raw audio, no transcription)
      4. Update state
    """
    try:
        # 1. Auditory cortex injection — always when above silence
        # All brain mutations go through the request_* API so the sim
        # thread applies them on its next tick, no cross-thread races
        # (audit fix #4 / finding #5).
        if _brain is not None and rms > SILENCE_THRESHOLD:
            try:
                _brain.inject_sensory_input("audio", features)
                if diff_score > 0.2:
                    _brain.request_neuromod_delta("acetylcholine", 0.03, cap=1.0)
            except Exception as e:
                print(f"[AUDIO_DAEMON] brain injection error: {e}")

        # 2. Startle → amygdala blast
        if _brain is not None and is_startle:
            try:
                intensity = min(1.0, rms * 5)
                amygdala = _brain.regions.get("amygdala")
                if amygdala is not None:
                    _brain.request_inject_current(
                        "amygdala", np.full(amygdala.n_neurons, intensity * 8.0)
                    )
                brainstem = _brain.regions.get("brainstem")
                if brainstem is not None:
                    _brain.request_inject_current(
                        "brainstem", np.full(brainstem.n_neurons, intensity * 6.0)
                    )
                # Norepinephrine spike
                _brain.request_neuromod_delta("norepinephrine", 0.2, cap=0.9)
                with _lock:
                    _state["startles"] += 1
            except Exception as e:
                print(f"[AUDIO_DAEMON] startle injection error: {e}")

        # 3. Knowledge store — scene label only, never raw audio
        if _knowledge_store is not None and scene != "silence":
            try:
                _knowledge_store.store(
                    text=f"Audio: {scene} (level {rms:.3f}, change {diff_score:.3f})",
                    source="audio_daemon",
                    tags=["audio", scene, "daemon"],
                    metadata={
                        "scene": scene,
                        "rms": round(rms, 4),
                        "diff_score": round(diff_score, 4),
                        "startle": is_startle,
                        "ts": time.time(),
                    },
                )
            except Exception:
                pass

        # 4. Presence dashboard event
        if scene not in ("silence", "ambient_hum"):
            try:
                from brain import presence
                presence.dashboard_event(
                    event_type="audio",
                    data={"scene": scene, "rms": round(rms, 3),
                          "diff": round(diff_score, 3), "startle": is_startle},
                )
            except Exception:
                pass

        # 5. Update state
        with _lock:
            _state["last_event"] = scene
            _state["last_event_ts"] = time.time()
            _state["ambient_level"] = _state["ambient_level"] * 0.95 + rms * 0.05
            _state["presence_detected"] = scene in ("voice_present", "impact",
                                                      "music_or_activity")
            if scene == "silence":
                _state["silence_streak_s"] += ANALYSIS_INTERVAL_S
            else:
                _state["silence_streak_s"] = 0.0

    except Exception as e:
        print(f"[AUDIO_DAEMON] route_audio error: {e}")


# ── 5. Mic callback + daemon loop ────────────────────────────────────

# ── 6. Continuous listening — always-on speech comprehension ──────────

_speech_buffer: list = []      # accumulates chunks during speech
_speech_active: bool = False
_speech_start_ts: float = 0.0
_SPEECH_RMS_THRESHOLD: float = 0.015   # energy above this = likely speech
_SPEECH_SILENCE_TIMEOUT_S: float = 1.5  # silence this long = utterance ended
_SPEECH_MIN_DURATION_S: float = 0.5    # ignore sub-500ms blips
_SPEECH_MAX_DURATION_S: float = 30.0   # cap at 30s to prevent memory issues
_last_speech_rms_ts: float = 0.0
_speech_first_chunk_ts: float = 0.0    # CAPTURE time of the utterance's first chunk


def _get_stt():
    """Lazy-load the STT model. Shared with wake word system if available."""
    global _stt
    if _stt is not None:
        return _stt
    with _stt_lock:
        if _stt is not None:
            return _stt
        # Try to reuse the server's pre-warmed STT
        try:
            import server as _srv
            prewarmed = getattr(_srv, "_prewarmed_stt", None)
            if prewarmed is not None:
                _stt = prewarmed
                print("[AUDIO_DAEMON] reusing pre-warmed STT")
                return _stt
        except Exception:
            pass
        # Load our own
        try:
            from brain.voice.stt import STT
            size = os.environ.get("LEON_STT_MODEL", "base")
            _stt = STT(model_size=size)
            print(f"[AUDIO_DAEMON] STT loaded: {_stt.backend_name} ({size})")
        except Exception as e:
            print(f"[AUDIO_DAEMON] STT unavailable: {e}")
    return _stt


def _check_continuous_speech(audio_chunk: np.ndarray,
                             chunk_ts: Optional[float] = None) -> None:
    """VAD + STT on continuous mic audio. Detects speech, transcribes it,
    routes to Leon's awareness.

    Not gated by wake word. Leon always hears. He decides whether to respond
    based on whether he's addressed.

    Self-hearing suppression is decided on `chunk_ts` — the instant this
    audio was CAPTURED, stamped in the mic callback — against the speaker
    ledger. It used to be `is_paused()`, i.e. "are the speakers live at
    the moment this function happens to run", which let audio recorded
    during playback slip through whenever processing lagged behind.
    """
    global _speech_active, _speech_start_ts, _last_speech_rms_ts

    chunk_dur = len(audio_chunk) / float(SAMPLE_RATE) if len(audio_chunk) else 0.0
    if chunk_ts is None:
        chunk_ts = time.time() - chunk_dur

    # This chunk was recorded while Leon's own voice was coming out of
    # the speakers → it is his voice, whatever the clock says now.
    if _gate.audio_is_speaker(chunk_ts, chunk_dur):
        # If we were mid-utterance, discard it — it's Leon's own voice
        if _speech_active:
            _speech_active = False
            _speech_buffer.clear()
        return

    rms = float(np.sqrt(np.mean(audio_chunk ** 2)))
    now = time.time()

    global _speech_first_chunk_ts
    if rms > _SPEECH_RMS_THRESHOLD:
        _last_speech_rms_ts = now
        if not _speech_active:
            _speech_active = True
            _speech_start_ts = now
            _speech_first_chunk_ts = chunk_ts
            _speech_buffer.clear()
        _speech_buffer.append(audio_chunk.copy())

        # Cap buffer length
        duration = now - _speech_start_ts
        if duration > _SPEECH_MAX_DURATION_S:
            _finalize_utterance()
    elif _speech_active:
        # Still accumulating during short silence gaps
        _speech_buffer.append(audio_chunk.copy())
        silence_duration = now - _last_speech_rms_ts
        if silence_duration > _SPEECH_SILENCE_TIMEOUT_S:
            _finalize_utterance()


def _finalize_utterance() -> None:
    """Speech ended — transcribe and route."""
    global _speech_active
    _speech_active = False

    if not _speech_buffer:
        return

    duration = len(_speech_buffer) * CHUNK_DURATION_S
    if duration < _SPEECH_MIN_DURATION_S:
        _speech_buffer.clear()
        return

    # Concatenate speech chunks
    audio = np.concatenate(_speech_buffer)
    _speech_buffer.clear()

    # Convert to PCM16 for STT
    pcm16 = (audio * 32767).astype(np.int16).tobytes()

    # ── Second line of defence: loopback correlation ──────────────────
    # Independent of every clock. If this window's envelope matches what
    # actually left the speakers (captured by _system_callback from the
    # PulseAudio monitor source), it is Leon's own voice coming back —
    # drop it even if the ledger says nothing was playing.
    try:
        started = _speech_first_chunk_ts or (time.time() - duration)
        is_echo, corr = _gate.looks_like_echo(pcm16, started, SAMPLE_RATE)
        if is_echo:
            print(f"[AUDIO_DAEMON] utterance dropped — correlates with played "
                  f"output (corr={corr:.2f})")
            return
    except Exception:
        pass

    # Transcribe in background to not block the main loop
    threading.Thread(
        target=_transcribe_and_route,
        args=(pcm16, duration),
        daemon=True,
        name="stt-transcribe",
    ).start()


def _transcribe_and_route(pcm16: bytes, duration: float) -> None:
    """Run STT and route the result to Leon's awareness."""
    stt = _get_stt()
    if stt is None:
        return

    try:
        result = stt.transcribe(pcm16, sample_rate=SAMPLE_RATE)
        text = result.text.strip()
        if not text or len(text) < 3:
            return

        # Text-level self-echo check — clock-free. If most of what we
        # "heard" is words Leon himself just spoke, this is the speakers.
        try:
            echoed, overlap = _gate.transcript_is_self_echo(text)
            if echoed:
                print(f"[AUDIO_DAEMON] transcript dropped — matches Leon's own "
                      f"last speech (overlap={overlap:.2f}): {text[:60]!r}")
                return
        except Exception:
            pass

        # Near-duplicate check — the SAME human utterance re-transcribed a few
        # seconds later with different wording. Distinct from the self-echo
        # check above (that one is Leon hearing himself); this one is Dean
        # getting answered twice for saying something once.
        try:
            with _lock:
                _prev = _state.get("last_transcript", "")
                _prev_ts = float(_state.get("last_transcript_ts", 0.0) or 0.0)
            repeat, sim = _gate.transcript_is_near_repeat(
                text, _prev, dt=time.time() - _prev_ts)
            if repeat:
                print(f"[AUDIO_DAEMON] transcript dropped — near-repeat of the "
                      f"previous utterance (sim={sim:.2f}): {text[:60]!r}")
                return
        except Exception:
            pass

        # Check if addressed to Leon
        lower = text.lower()
        addressed = any(w in lower for w in (
            "leon", "hey leon", "yo leon", "are you there",
            "you listening", "can you hear", "hey man",
        ))

        now = time.time()
        with _lock:
            _state["last_transcript"] = text
            _state["last_transcript_ts"] = now
            _state["speech_detected"] = True
            _state["addressed_to_leon"] = addressed
            _state["transcripts_total"] += 1

        print(f"[AUDIO_DAEMON] heard ({duration:.1f}s): \"{text[:80]}\" addressed={addressed}")

        # Activity status
        try:
            from server.helpers import broadcast_activity
            if addressed:
                broadcast_activity("hearing", f"Heard: \"{text[:60]}\" (talking to me)", 8000)
            else:
                broadcast_activity("hearing", f"Heard speech ({duration:.1f}s)", 5000)
        except Exception:
            pass

        # Look at who's talking — curiosity-driven vision
        if addressed:
            try:
                from brain import vision_daemon
                vision_daemon.look_now("addressed_by_voice", source="webcam")
            except Exception:
                pass

        # Continuous hearing feeds Leon's INNER experience only (SNN
        # awareness, knowledge store, activity status). It must NEVER
        # trigger a spoken response — that's the job of:
        #   1. Wake word ("hey leon") via sensor_relay → /api/relay/heard
        #   2. Mic button (push-to-talk) via dashboard
        # Allowing continuous hearing to trigger responses caused an
        # unbreakable self-hearing loop: Leon speaks → mic picks up his
        # voice → "leon" detected → responds → loop. Killed 2026-06-23.

        # Store in knowledge (awareness, not conversation)
        if _knowledge_store is not None and not addressed:
            try:
                _knowledge_store.store(
                    text=f"Overheard: {text[:500]}",
                    source="continuous_hearing",
                    tags=["audio", "overheard", "speech"],
                    metadata={"duration": round(duration, 1), "addressed": False},
                )
            except Exception:
                pass

        # Inject into SNN — hearing speech is neurally stimulating.
        # Routed through request_inject_current so the sim thread applies
        # them on next tick (no cross-thread race with step()).
        if _brain is not None:
            try:
                temporal = _brain.regions.get("temporal_cortex")
                if temporal is not None:
                    _brain.request_inject_current(
                        "temporal_cortex", np.full(temporal.n_neurons, 4.0)
                    )
                wernicke = _brain.regions.get("wernicke")
                if wernicke is not None:
                    _brain.request_inject_current(
                        "wernicke", np.full(wernicke.n_neurons, 5.0)
                    )
            except Exception:
                pass

    except Exception as e:
        print(f"[AUDIO_DAEMON] transcription failed: {e}")


def _respond_to_speech(text: str) -> None:
    """Handle speech directed at Leon — trigger a full response."""
    try:
        import server as _srv
        responder = getattr(_srv, "brain_api_responder", None)
        broadcast = getattr(_srv, "_broadcast_threadsafe", None)
        if responder is None or broadcast is None:
            return

        # Acquire responder lock
        rlock = getattr(_srv, "_responder_lock", None)
        if rlock and not rlock.acquire(timeout=5):
            return

        try:
            response_id = f"heard_{int(time.time()*1000)}"
            bstate = {}
            try:
                brain = getattr(_srv, "brain", None)
                if brain:
                    bstate = brain.get_state()
            except Exception:
                pass

            broadcast({
                "type": "brain_response_start",
                "user": text,
                "response_id": response_id,
                "from_voice": True,
            })

            full_text = ""
            sentence_idx = 0
            tts_fn = getattr(_srv, "_tts_synthesize_b64", None)

            for ev in responder.respond_streaming(
                text, bstate,
                replay_history=True,
                persist_history=True,
            ):
                if ev.type == "delta" and ev.text:
                    full_text += ev.text
                    broadcast({
                        "type": "brain_response_delta",
                        "response_id": response_id,
                        "text": ev.text,
                    })
                elif ev.type == "sentence":
                    if tts_fn is not None:
                        try:
                            audio = tts_fn(ev.text)
                            if audio:
                                broadcast({
                                    "type": "brain_audio",
                                    "response_id": response_id,
                                    "sentence_index": sentence_idx,
                                    **audio,
                                })
                                sentence_idx += 1
                        except Exception:
                            pass
                elif ev.type == "done":
                    full_text = ev.full_text or full_text
                    break

            broadcast({
                "type": "brain_response_end",
                "response_id": response_id,
                "response": full_text,
            })
        finally:
            if rlock:
                try:
                    rlock.release()
                except RuntimeError:
                    pass
    except Exception as e:
        print(f"[AUDIO_DAEMON] speech response failed: {e}")


def _mic_callback(indata, frames, time_info, status):
    """sounddevice callback — buffer raw samples, no processing.

    The ONE thing it does beyond buffering: stamp the capture instant.
    Everything downstream that has to decide "was this Leon's own voice?"
    needs the moment the air hit the mic, not the moment it got looked at.
    """
    if status:
        pass  # Ignore xruns silently
    chunk = indata[:, 0].copy()
    chunk_ts = time.time() - (frames / float(SAMPLE_RATE) if frames else 0.0)
    with _buffer_lock:
        _audio_buffer.append(chunk)
        # Keep only last 10 seconds
        max_chunks = int(10.0 / CHUNK_DURATION_S)
        while len(_audio_buffer) > max_chunks:
            _audio_buffer.pop(0)
    # Continuous speech detection — runs on every mic chunk
    try:
        _check_continuous_speech(chunk, chunk_ts)
    except Exception:
        pass


def _system_callback(indata, frames, time_info, status):
    """System audio callback — captures what's playing through speakers.

    This is the loopback REFERENCE for echo rejection: publishing it into
    the audio gate gives a clock-independent way to recognise Leon's own
    output coming back in through the mic.
    """
    if status:
        pass
    sys_chunk = indata[:, 0].copy()
    try:
        _gate.note_reference_audio(sys_chunk, SAMPLE_RATE)
    except Exception:
        pass
    with _buffer_lock:
        _system_buffer.append(sys_chunk)
        max_chunks = int(10.0 / CHUNK_DURATION_S)
        while len(_system_buffer) > max_chunks:
            _system_buffer.pop(0)


def _find_monitor_source():
    """Find the PulseAudio/PipeWire monitor source for system audio.

    Monitor sources don't always show up in sounddevice's device list.
    We find a usable input device and the monitor name, then open it
    by setting PULSE_SOURCE env var.
    Returns (device_index, monitor_name) or (None, None).
    """
    import sounddevice as sd
    import subprocess

    # Find any usable input device — prefer 'pulse', fall back to 'default'
    input_idx = None
    for i, d in enumerate(sd.query_devices()):
        if d['max_input_channels'] > 0 and d['name'] in ('pulse', 'pipewire', 'default'):
            input_idx = i
            break
    if input_idx is None:
        # Just use the default input device
        try:
            input_idx = sd.default.device[0]
        except Exception:
            return None, None

    # Find the monitor source name via pactl
    monitor_name = None
    try:
        result = subprocess.run(
            ["pactl", "list", "sources", "short"],
            capture_output=True, text=True, timeout=5,
            env={**os.environ, "XDG_RUNTIME_DIR": f"/run/user/{os.getuid()}"},
        )
        for line in result.stdout.splitlines():
            parts = line.split('\t')
            if len(parts) >= 2 and '.monitor' in parts[1].lower():
                # Prefer non-HDMI monitor
                if 'hdmi' not in parts[1].lower():
                    monitor_name = parts[1]
                    break
                elif monitor_name is None:
                    monitor_name = parts[1]
    except Exception:
        pass

    if monitor_name is None:
        return None, None

    return input_idx, monitor_name


def _daemon_loop() -> None:
    """Main background loop. Opens BOTH mic + system audio streams."""
    global _prev_system_spectrum
    import sounddevice as sd

    consecutive_idle = 0
    mic_stream = None
    system_stream = None

    # Open mic (room audio — Dean's voice, room sounds)
    try:
        mic_stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            blocksize=CHUNK_SAMPLES,
            callback=_mic_callback,
        )
        mic_stream.start()
        with _lock:
            _state["mic_available"] = True
        print("[AUDIO_DAEMON] mic opened — hearing the room")
    except Exception as e:
        print(f"[AUDIO_DAEMON] mic unavailable: {e}")
        with _lock:
            _state["mic_available"] = False

    # Open system audio monitor (calls, music, notifications — everything
    # playing through speakers. This is how Leon hears Jovanni's voice.)
    try:
        pulse_idx, monitor_name = _find_monitor_source()
        if pulse_idx is not None and monitor_name is not None:
            # Tell PulseAudio to use the monitor source for this stream
            os.environ["PULSE_SOURCE"] = monitor_name
            system_stream = sd.InputStream(
                device=pulse_idx,
                samplerate=SAMPLE_RATE,
                channels=1,
                dtype="float32",
                blocksize=CHUNK_SAMPLES,
                callback=_system_callback,
            )
            system_stream.start()
            # Restore env
            os.environ.pop("PULSE_SOURCE", None)
            with _lock:
                _state["system_audio_available"] = True
            print(f"[AUDIO_DAEMON] system audio monitor opened ({monitor_name}) — hearing calls/music")
        else:
            print("[AUDIO_DAEMON] no monitor source found — system audio unavailable")
    except Exception as e:
        os.environ.pop("PULSE_SOURCE", None)
        print(f"[AUDIO_DAEMON] system audio monitor failed: {e}")

    last_analysis = 0.0
    print("[AUDIO_DAEMON] loop started — always-on ears")

    while True:
        with _lock:
            if not _running:
                break
            interval = _state["current_interval_s"]

        now = time.time()

        if now - last_analysis >= interval:
            last_analysis = now

            # ── Process mic (room) audio ──
            with _buffer_lock:
                if len(_audio_buffer) >= 2:
                    n_chunks = min(len(_audio_buffer), int(ANALYSIS_INTERVAL_S / CHUNK_DURATION_S))
                    audio = np.concatenate(_audio_buffer[-n_chunks:])
                else:
                    audio = None

            if audio is not None:
                with _lock:
                    _state["analyses"] += 1

                spectrum = _compute_spectrum(audio)
                features = _compute_features(audio)
                rms = float(np.sqrt(np.mean(audio ** 2)))
                zcr = float(np.sum(np.abs(np.diff(np.sign(audio)))) / (2 * len(audio)))

                changed, diff_score, is_startle = detect_change(spectrum, rms)

                if changed or is_startle:
                    consecutive_idle = 0
                    scene = classify_scene(spectrum, rms, zcr)
                    route_audio(features, scene, rms, diff_score, is_startle)
                    with _lock:
                        _state["changes_detected"] += 1
                else:
                    consecutive_idle += 1

            # ── Process system audio (calls, music) ──
            with _buffer_lock:
                if len(_system_buffer) >= 2:
                    n_chunks = min(len(_system_buffer), int(ANALYSIS_INTERVAL_S / CHUNK_DURATION_S))
                    sys_audio = np.concatenate(_system_buffer[-n_chunks:])
                else:
                    sys_audio = None

            if sys_audio is not None:
                sys_spectrum = _compute_spectrum(sys_audio)
                sys_features = _compute_features(sys_audio)
                sys_rms = float(np.sqrt(np.mean(sys_audio ** 2)))
                sys_zcr = float(np.sum(np.abs(np.diff(np.sign(sys_audio)))) / (2 * len(sys_audio)))

                sys_scene = classify_scene(sys_spectrum, sys_rms, sys_zcr)

                # Inject system audio into brain too — Leon hears calls/music
                if _brain is not None and sys_rms > SILENCE_THRESHOLD:
                    try:
                        _brain.inject_sensory_input("audio", sys_features)
                    except Exception:
                        pass

                # Detect call (mic has voice + system has voice = two-way call)
                mic_voice = _state.get("last_event") == "voice_present"
                sys_voice = sys_scene == "voice_present"

                with _lock:
                    _state["system_scene"] = sys_scene
                    _state["system_rms"] = round(sys_rms, 4)
                    _state["call_detected"] = mic_voice and sys_voice

            # Idle stretching
            with _lock:
                _state["consecutive_idle"] = consecutive_idle
                if consecutive_idle >= IDLE_THRESHOLD_FRAMES:
                    _state["current_interval_s"] = ANALYSIS_INTERVAL_S * IDLE_STRETCH_FACTOR
                elif audio is not None and consecutive_idle == 0:
                    _state["current_interval_s"] = ANALYSIS_INTERVAL_S

        time.sleep(0.25)

    # Cleanup
    for s in (mic_stream, system_stream):
        if s is not None:
            try:
                s.stop()
                s.close()
            except Exception:
                pass

    print("[AUDIO_DAEMON] loop exited cleanly")


# ── 6. start / stop / get_state ──────────────────────────────────────

def start(brain=None, knowledge_store=None) -> bool:
    """Start the audio daemon. Idempotent."""
    global _running, _thread, _brain, _knowledge_store

    with _lock:
        if _running:
            print("[AUDIO_DAEMON] already running")
            return False

        _brain = brain
        _knowledge_store = knowledge_store

        _running = True
        _state["running"] = True
        _state["current_interval_s"] = ANALYSIS_INTERVAL_S

    _thread = threading.Thread(target=_daemon_loop, name="audio_daemon", daemon=True)
    _thread.start()

    print("[AUDIO_DAEMON] started")
    return True


def stop() -> None:
    """Stop the daemon. Blocks until thread joins (max 3s)."""
    global _running, _thread

    with _lock:
        _running = False
        _state["running"] = False

    if _thread is not None:
        _thread.join(timeout=3.0)
        _thread = None

    print("[AUDIO_DAEMON] stopped")


def get_state() -> Dict[str, Any]:
    """Thread-safe snapshot of current daemon state."""
    with _lock:
        return dict(_state)
