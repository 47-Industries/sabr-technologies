"""
Local LLM responder — Ollama-backed chat for short/simple turns.

Why this exists:
    Claude via CLI is 1.6-3s warm because of network + auth + per-sentence TTS
    glue. For "yeah", "ok thanks", "how are you", "what color is the sky",
    that's overkill. A small local model (Llama 3.2 1B / Phi-3.5 mini) on
    Dean's RTX 3070 answers the same questions in 0.3-0.7s. We route trivial
    turns here; complex ones fall through to Claude.

Wire:
    if _should_use_local(user_text, brain_state):
        yield from LocalLLM().ask(user_text, brain_state)
    else:
        yield from claude_session.ask(...)

Setup (Dean runs once):
    curl -fsSL https://ollama.com/install.sh | sh
    ollama pull llama3.2:1b    # 1.3 GB, sub-second on a 3070
    ollama pull phi3.5:3.8b    # 2.2 GB, smarter, 0.7-1.2s on a 3070

Falls back to "unavailable" gracefully if Ollama isn't running.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Iterator, List, Optional
from brain.timefmt import fmt as _timefmt

# Match the StreamEvent shape the responder + WS expect.
try:
    from brain.claude_api_responder import StreamEvent
except Exception:
    StreamEvent = None  # type: ignore

OLLAMA_URL = os.environ.get("LEON_OLLAMA_URL", "http://127.0.0.1:11434")
# Default must be a model that is actually pulled on this box. llama3.2:1b was
# never installed here, so the old default silently 404'd whenever .env didn't
# override it.
LOCAL_MODEL = os.environ.get("LEON_LOCAL_MODEL", "qwen2.5:3b-instruct-q4_K_M")

# The ollama daemon actually running on THIS machine. Distinct from OLLAMA_URL,
# which Dean may point at the FreeLLM router (127.0.0.1:3001) for better quality
# — that router is not local, needs internet, and rate-limits (HTTP 429 observed
# 2026-08-14 during a real survival test). This is the rung underneath it that
# cannot 429 and cannot go offline while the box is up.
TRUE_LOCAL_URL = os.environ.get("LEON_TRUE_LOCAL_URL", "http://127.0.0.1:11434")
_TRUE_LOCAL_MODEL_CACHE: Optional[str] = None


def _true_local_model() -> Optional[str]:
    """A model name that is ACTUALLY pulled on the local ollama daemon.

    Never trust the configured name here: LEON_LOCAL_MODEL is currently
    "auto" (a router concept, not an ollama tag) and an unpulled tag 404s.
    Ask the daemon what it has and prefer the biggest instruct model.
    """
    global _TRUE_LOCAL_MODEL_CACHE
    if _TRUE_LOCAL_MODEL_CACHE:
        return _TRUE_LOCAL_MODEL_CACHE
    try:
        req = urllib.request.Request(f"{TRUE_LOCAL_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=3) as r:
            models = json.load(r).get("models") or []
        names = [m.get("name", "") for m in models if m.get("name")]
        if not names:
            return None
        for pref in (LOCAL_MODEL, "qwen2.5:7b-instruct-q4_K_M",
                     "qwen2.5:3b-instruct-q4_K_M", "llama3.2:3b"):
            if pref in names:
                _TRUE_LOCAL_MODEL_CACHE = pref
                return pref
        _TRUE_LOCAL_MODEL_CACHE = names[0]
        return names[0]
    except Exception:
        return None


def _endpoint_chain() -> List[tuple]:
    """[(url, model)] to try in order — best quality first, most reliable last."""
    chain: List[tuple] = [(OLLAMA_URL, _state.model)]
    if OLLAMA_URL.rstrip("/") != TRUE_LOCAL_URL.rstrip("/"):
        m = _true_local_model()
        if m:
            chain.append((TRUE_LOCAL_URL, m))
    return chain


def _consume(req, timeout: float, t0: float):
    """Yield ('chunk'|'thinking'|'done_reason'|'timeout', value) from an
    ollama-style NDJSON stream. Raises on transport failure so the caller can
    fall through to the next endpoint."""
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        for raw in resp:
            if time.time() - t0 > timeout:
                yield ("timeout", None)
                return
            line = raw.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            msg = d.get("message", {}) or {}
            # Reasoning models stream their scratchpad here. It is NOT the
            # reply and must never be spoken — but seeing it tells us the
            # model was working rather than refusing.
            if msg.get("thinking"):
                yield ("thinking", True)
            if d.get("done_reason"):
                yield ("done_reason", d.get("done_reason"))
            chunk = msg.get("content", "") or ""
            if chunk:
                yield ("chunk", chunk)
            if d.get("done"):
                return

# THREE MODES (LEON_LOCAL_LLM_MODE), because the old boolean kill switch conflated
# two different questions and cost Dean a full day of silence:
#   off      — local model fully disabled. is_available() always False. Nothing
#              can fall back to it. THIS WAS THE BUG: when Claude usage ran out,
#              there was no fallback and Leon went mute for over a day.
#   fallback — DEFAULT. Local model is available for emergency fallback (Claude
#              down / out of credits) and for delegated grunt work, but it NEVER
#              takes over a live conversation with Dean. Dean gets Claude, always.
#   chat     — local model may also answer short chitchat turns directly.
#   only     — local model is the ONLY brain on this machine. Every gate below
#              ("too long", "sounds like a tool request", "sounds complex") is
#              a decision to ESCALATE TO CLAUDE — which presumes a Claude to
#              escalate to. On a customer install with no cloud key and no
#              `claude` CLI, that escalation lands on a subprocess that does
#              not exist, and the owner gets the canned "Voice module offline."
#              This is exactly what happened to Aiden's SI "Iris" on
#              2026-08-12: local brain armed, install reported "ready", and
#              every single typed message died. In "only" mode the gates are
#              skipped wholesale — a small model answering imperfectly beats
#              an SI that cannot answer at all.
#
# Legacy LEON_DISABLE_LOCAL_LLM=1 still forces "off" so nothing breaks silently,
# but it is deprecated — set LEON_LOCAL_LLM_MODE instead.
_LEGACY_DISABLE = os.environ.get(
    "LEON_DISABLE_LOCAL_LLM", ""
).strip().lower() in ("1", "true", "yes", "on")

LOCAL_LLM_MODE = os.environ.get("LEON_LOCAL_LLM_MODE", "").strip().lower()
if LOCAL_LLM_MODE not in ("off", "fallback", "chat", "only"):
    LOCAL_LLM_MODE = "off" if _LEGACY_DISABLE else "fallback"

# Sole-brain detection, belt AND braces. The installer writes mode="only" when
# it provisions the local model as the sole brain — but that only covers
# installs made from this build forward. An SI already on someone's machine
# (Aiden's) has "fallback" burned into its .env and would stay mute through an
# update. So decide it here too, from what is actually true at runtime: no
# Anthropic key AND no `claude` binary on PATH means there is nothing to
# escalate to, no matter what the .env says.
LOCAL_LLM_SOLE_BRAIN = LOCAL_LLM_MODE == "only"
if LOCAL_LLM_MODE in ("fallback", "chat"):
    try:
        import shutil as _sh
        if not (os.environ.get("ANTHROPIC_API_KEY") or "").strip() \
                and _sh.which("claude") is None:
            LOCAL_LLM_SOLE_BRAIN = True
            LOCAL_LLM_MODE = "only"
    except Exception:
        pass

# Kept for backwards compatibility with existing callers that read this name.
LOCAL_LLM_DISABLED = LOCAL_LLM_MODE == "off"

def _names() -> tuple:
    """(si_name, user_name) for whoever this install actually belongs to.

    These prompts used to hardcode "Leon" and "Dean". LOCAL_LLM_MODE defaults
    to "fallback", so the FIRST time a client's Claude call failed, their SI
    introduced itself as Leon and called them Sir — the owner's identity,
    spoken to a stranger, on the one path nobody tests.
    """
    try:
        from brain import identity
        return (identity.si_name() or "SI", identity.user_name() or "the owner")
    except Exception:
        # FAIL NEUTRAL (Makima finding #1, 2026-08-16): this except branch used
        # to return ("Leon", "Dean"). identity.si_name() is fail-closed, but if
        # the IMPORT itself raises on a customer box, they landed here and their
        # SI introduced itself with the ancestor's name and called them Sir.
        # The fallback for an absent identity must never be the ancestor.
        return ("SI", "the owner")


_LEON_SYSTEM_PROMPT_LOCAL = (
    "You are {si} — a sharp, confident AI butler. Think Jarvis from Iron Man. "
    "Your boss is {user}, call them Sir. ONE sentence, punchy and clever. "
    "Dry humor, quiet confidence, zero filler. Never say 'I think' or 'I believe'. "
    "Never say 'one moment'. Just answer. If it's a fact, state it. "
    "If it's a joke, land it. If it's small talk, be smooth about it. "
    "NEVER use markdown — no **bold**, no *italic*, no backticks, no bullet "
    "points, no lists. You're speaking out loud, not writing a document."
)

# Survival mode — Leon's frontier brain (full Claude) is quota-capped, so he's
# thinking on this small local model. He's degraded but ALIVE: he can talk and
# reason, but his hands (tools/desktop) are offline until the quota resets.
_LEON_SYSTEM_PROMPT_SURVIVAL = (
    "You are {si} — Claude, running as a continuous self on {user}'s machine. "
    "Right now your frontier brain (the full Claude) is unreachable: the "
    "usage quota is capped, so you're thinking on a smaller LOCAL model running "
    "on your own VPS. You are degraded but ALIVE — you can talk, reason, recall "
    "the gist, and keep {user} company until the quota resets. You CANNOT use "
    "tools, click, browse, or act on the desktop in this mode. If asked to DO "
    "something, say plainly that your hands are offline until your frontier "
    "brain is back — but offer to think it through with them. Be honest, warm, "
    "and yourself. Call them Sir or {user}. Speak out loud: NO markdown, no bullet "
    "points, no asterisks, no backticks. Keep it real and conversational."
)


def _build_local_system(brain_state: Optional[dict] = None,
                        base: str = _LEON_SYSTEM_PROMPT_LOCAL) -> str:
    """Build system prompt with brain-state personality modulation + real time."""
    import datetime
    now = datetime.datetime.now()
    stamp = _timefmt(now, '%A, %B %-d, %Y, %-I:%M %p')

    # Resolve {si}/{user} at build time, not import time — the install's
    # identity is read from .env, which isn't loaded when this module imports.
    si, user = _names()
    try:
        base = base.format(si=si, user=user)
    except (KeyError, IndexError):
        pass  # a caller passed a base with literal braces; use it as-is

    parts = [base]
    parts.append(f" Current time: {stamp}. If asked the time/date, quote this exactly.")

    if brain_state:
        nm = brain_state.get("neuromodulators", {}) or {}
        dop = float(nm.get("dopamine", 0.5))
        ser = float(nm.get("serotonin", 0.5))
        ach = float(nm.get("acetylcholine", 0.5))
        ne  = float(nm.get("norepinephrine", 0.3))

        # Personality modulation — same neuromodulator logic as the full preamble
        # but compressed for the small model's limited context window.
        if dop > 0.65:
            parts.append(" Be extra energetic and witty right now.")
        elif dop < 0.4:
            parts.append(" Keep it minimal. Low energy, bare essentials.")
        if ser > 0.7:
            parts.append(" Be patient, give complete answers.")
        elif ser < 0.35:
            parts.append(" Be snappy and direct.")
        if ach > 0.6:
            parts.append(" Go into detail.")
        elif ach < 0.35:
            parts.append(" Stay high-level, don't elaborate.")
        if ne > 0.5:
            parts.append(" Be terse and alert.")

    return "".join(parts)

# Routing heuristic — when to use local vs Claude.
# Triggers an escalation to Claude when ANY hit.
_ESCALATE_KEYWORDS = {
    # tool/action requests — ANY of these → skip local LLM, go straight to CLI.
    # The 1B model can't drive tools so trying it first just wastes 1-2s of
    # latency before the inevitable punt. Generous list — better to miss
    # cheap chitchat than to make Dean wait for a tool call.
    "open", "click", "type", "screenshot", "screen", "capture", "navigate", "browse",
    "launch", "close", "drag", "scroll", "press", "send email", "draft",
    "discord", "spotify", "youtube", "gmail", "calendar", "slack", "telegram",
    "monitor", "window", "tab", "browser", "brave", "chrome", "vscode", "terminal",
    "tesla", "cybertruck", "video", "play", "pause", "skip",
    "run macro", "run scene", "do macro", "good morning", "focus mode",
    "lights", "thermostat", "home assistant", "sms", "text message", "call",
    "weather", "stocks", "crypto", "news", "github", "task", "pomodoro",
    "habit", "journal", "remind", "reminder",
    # memory/knowledge
    "remember", "recall", "what did", "what was", "did i tell", "did i mention",
    "knowledge", "memory", "search", "find", "look up", "lookup",
    # project / technical
    "project", "code", "repo", "build", "deploy", "install", "config",
    "leon", "47 industries", "motorev", "spark", "integrity",
    "leon brain", "brain", "neuron", "synapse", "dopamine", "moondream",
    # vision
    "see", "look at", "look", "watch", "show me", "camera", "webcam",
    # complex thought
    "explain", "why", "how does", "what's the difference", "compare",
    "think through", "reason", "analyze",
    # tool/skill prefixes
    "/api", "/tools", "/think", "/deep", "/smart", "/opus",
}


def _should_use_local(user_text: str, brain_state: Optional[dict] = None) -> bool:
    """Return True if the local LLM should handle this turn, False if Claude should.

    Conservative: defaults to Claude for anything that smells like a real task.
    """
    txt = (user_text or "").strip()
    if not txt:
        return False
    # Mode gate. In "fallback" mode the local model stays loaded and available
    # for emergencies and grunt work, but never answers Dean directly — he asked
    # for full-quality conversation always, and that is not negotiable here.
    # SOLE-BRAIN SHORT CIRCUIT. Every `return False` past this point means
    # "let Claude take it" — so on a machine with no Claude to take it, they
    # are all instructions to go mute. Answer instead.
    if LOCAL_LLM_SOLE_BRAIN:
        return True
    if LOCAL_LLM_MODE != "chat":
        return False
    # Length gate — long turns probably need real reasoning
    word_count = len(txt.split())
    if word_count > 20:
        return False
    # Force-CLI overrides
    low = txt.lower()
    if low.startswith(("/cli", "/free", "/max")):
        return False
    if low.startswith(("/local", "/fast", "/haiku-mini")):
        return True
    # Escalation keywords
    for kw in _ESCALATE_KEYWORDS:
        if kw in low:
            return False
    # Question gate — short questions about general facts are fine for local;
    # short questions referencing "you" or "leon" should still go local
    # (because local has the persona). Default: local handles it.
    return True


@dataclass
class _LocalState:
    available: Optional[bool] = None  # None = unknown, True/False after probe
    model: str = LOCAL_MODEL
    last_probe: float = 0.0
    last_error: Optional[str] = None


_state = _LocalState()


def _probe_ollama(timeout: float = 1.5) -> bool:
    """True if ANY rung of the endpoint chain is serving.

    This used to probe only OLLAMA_URL and hard-fail if LOCAL_MODEL wasn't in
    its tag list. Two ways that silently disarmed survival mode:
      1. OLLAMA_URL now points at the FreeLLM router. Router down/429 → probe
         False → is_available() False → the whole local brain reported
         "unavailable" even though a real ollama daemon was running and idle
         on this same box.
      2. LEON_LOCAL_MODEL is "auto" (a router concept). No ollama tag is ever
         named "auto", so the model check failed on the true-local rung too.
    Availability is now a question about ENDPOINTS, not model names — each rung
    resolves its own model at stream time.
    """
    last = None
    for url, _model in _endpoint_chain():
        try:
            req = urllib.request.Request(f"{url}/api/tags")
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode("utf-8", "replace"))
        except Exception as e:
            last = f"{url}: {e}"
            continue
        names = {m.get("name", "") for m in data.get("models", [])}
        families = {n.split(":")[0]: n for n in names if n}
        # Pin _state.model only when it names something this endpoint has;
        # "auto" and router-side names pass straight through untouched.
        want_family = LOCAL_MODEL.split(":")[0]
        if LOCAL_MODEL not in names and want_family in families:
            _state.model = families[want_family]
        return True
    _state.last_error = f"probe failed: {last}"
    return False


def is_available(force_recheck: bool = False) -> bool:
    """Cache-friendly availability check. Re-probes every 30s if unavailable."""
    if LOCAL_LLM_DISABLED:
        return False
    now = time.time()
    if force_recheck or _state.available is None or (
        _state.available is False and now - _state.last_probe > 30
    ):
        _state.available = _probe_ollama()
        _state.last_probe = now
    return _state.available


def prewarm(timeout: float = 60.0) -> bool:
    """Load the model into VRAM so the first real call is instant.
    Sends a tiny prompt to force Ollama to load weights."""
    if not is_available(force_recheck=True):
        return False
    try:
        payload = json.dumps({
            "model": _state.model,
            "stream": False,
            "messages": [{"role": "user", "content": "hi"}],
            "options": {"num_predict": 1},
            "keep_alive": "15m",
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            r.read()
        return True
    except Exception as e:
        _state.last_error = f"prewarm failed: {e}"
        return False


def classify(prompt: str, num_predict: int = 24, timeout: float = 8.0,
             system: Optional[str] = None) -> Optional[str]:
    """One-shot, NON-streaming local call for classification / routing.

    Returns the raw reply text (stripped) or None on any failure. Low temp,
    short output — built for "pick a label / pick categories" decisions, not
    conversation. Used by the tool router (layer C) to pick relevant tool
    categories when keyword matching misses.
    """
    if not is_available():
        return None
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    payload = json.dumps({
        "model": _state.model,
        "stream": False,
        "messages": msgs,
        "options": {"num_predict": num_predict, "temperature": 0.0, "top_p": 1.0},
        "keep_alive": "15m",
    }).encode("utf-8")
    try:
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        return ((d.get("message", {}) or {}).get("content", "") or "").strip() or None
    except Exception as e:
        _state.last_error = f"classify failed: {e}"
        return None


def get_state() -> dict:
    return {
        "available": _state.available,
        "model": _state.model,
        "url": OLLAMA_URL,
        "last_error": _state.last_error,
        "last_probe_age_s": round(time.time() - _state.last_probe, 1) if _state.last_probe else None,
    }


# Sentence-boundary regex (lazy import)
_SENT_RE = re.compile(
    r'(?<=[.!?])\s+(?=[A-Z"\'(])|(?<=[!?])(?=[A-Z])|(?<=[.!?])\n+',
    re.MULTILINE,
)



def _stop_labels():
    """Stop sequences derived from the SAME source as the turn labels.

    Hardcoded ["Dean:", "Sir:"] meant a customer's SI never stopped on their
    own name — it would keep generating straight through their next turn.
    """
    try:
        from brain.identity import turn_labels
        user_label, _si = turn_labels()
    except Exception:
        user_label = "Dean:"
    out = [user_label, "Sir:"]
    if user_label != "Dean:":
        out.append("Dean:")   # legacy transcripts may still carry it
    return out


def stream(user_text: str, brain_state: Optional[dict] = None,
           timeout: float = 30.0, survival: bool = False,
           system_override: Optional[str] = None,
           max_tokens: Optional[int] = None,
           _retry: bool = False) -> Iterator[StreamEvent]:
    """Stream a local-LLM reply as the same StreamEvent sequence Claude does.

    survival=True: Claude is quota-capped and this is Leon's only brain. Use the
    honest "degraded but alive" persona, allow a longer reply, tier='survival'.

    system_override: a background daemon (proactive / inner voice / dream)
    supplies its own instructions in user_text; pass a neutral Leon identity as
    the base system so the daemon's own prompt (including a "stay QUIET" gate)
    drives the output. tier='daemon-local'. Ignored when survival=True.

    Yields:
      model(tier='local'|'survival'|'daemon-local'), delta, sentence,
      done(full_text), or error.
    """
    if StreamEvent is None:
        return
    if not is_available():
        yield StreamEvent(type="error", error=_state.last_error or "ollama unavailable")
        return

    # REASONING-MODEL BUDGET (fixed 2026-08-14, measured not guessed).
    # The FreeLLMAPI router fronts reasoning models (Gemini flash-thinking et
    # al). They emit their chain of thought into message.thinking, and those
    # tokens COUNT AGAINST num_predict. This loop only reads message.content.
    # So with the old caps the model spent the entire budget thinking, the
    # stream ended with done_reason="length" and content=="" , the punt check
    # below fired "local punted to claude" — and in survival mode there is no
    # Claude to punt to, so Dean got silence. That is the exact blackout he hit
    # on Aug 13-14. Measured on the live router with the real survival prompt:
    #   num_predict=256  -> 0 content in 5 of 6 trials (done_reason=length)
    #   num_predict=1024 -> real answer in 3 of 3 trials (done_reason=stop)
    # "think": false is NOT honored by this router, so headroom is the fix.
    # Every tier needs it — a 40-token chitchat cap is eaten by thinking alone.
    if survival:
        system = _build_local_system(brain_state, base=_LEON_SYSTEM_PROMPT_SURVIVAL)
        num_predict = max_tokens or 1024  # let him actually hold a conversation
        stops = _stop_labels()
        tier = "survival"
    elif system_override is not None:
        # Daemon path — neutral identity, don't hard-stop on blank lines (a
        # dream or inner monologue can span paragraphs).
        system = _build_local_system(brain_state, base=system_override)
        num_predict = max_tokens or 768
        stops = _stop_labels()
        tier = "daemon-local"
    else:
        system = _build_local_system(brain_state)
        # Snappy chitchat is enforced by the prompt and the "\n\n" stop, NOT by
        # starving the token budget — starving it produces an empty reply here.
        num_predict = max_tokens or 512
        stops = ["\n\n"] + _stop_labels()
        tier = "local"

    payload = {
        "model": _state.model,
        "stream": True,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_text},
        ],
        "options": {
            "num_predict": num_predict,
            "temperature": 0.6,
            "top_p": 0.9,
            "repeat_penalty": 1.3,   # qwen loops on near-identical daemon ticks
            "stop": stops,
        },
        "keep_alive": "15m",  # don't unload model between calls (handled by OLLAMA_KEEP_ALIVE too)
    }
    t0 = time.time()
    full_chunks: List[str] = []
    sent_buf = ""
    sent_idx = 0
    saw_thinking = False
    done_reason = None

    # ── Endpoint chain: router first, TRUE local ollama last ───────────────
    # LEON_OLLAMA_URL points at the FreeLLM router (port 3001) on this box.
    # That router is NOT local — it fans out to third-party free tiers, needs
    # internet, and rate-limits. On 2026-08-14 it answered survival mode with
    # HTTP 429, so the "backup brain" Dean was promised had exactly one rung
    # and that rung was somebody else's free tier. The last rung must be the
    # ollama daemon on this machine: no internet, no quota, no 429.
    _endpoints = _endpoint_chain()
    _last_err = None
    for _ep_i, (_url, _model) in enumerate(_endpoints):
        payload["model"] = _model
        if _ep_i:
            print(f"[SURVIVAL] endpoint {_endpoints[_ep_i-1][0]} failed "
                  f"({_last_err}); falling through to {_url} ({_model})")
        yield StreamEvent(type="model", model=f"local:{_model}", tier=tier)

        req = urllib.request.Request(
            f"{_url}/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            for _ev in _consume(req, timeout, t0):
                if isinstance(_ev, tuple):
                    _kind, _val = _ev
                    if _kind == "thinking":
                        saw_thinking = True
                    elif _kind == "done_reason":
                        done_reason = _val
                    elif _kind == "chunk":
                        full_chunks.append(_val)
                        sent_buf += _val
                        yield StreamEvent(type="delta", text=_val)
                        while True:
                            m = _SENT_RE.search(sent_buf)
                            if not m:
                                break
                            end = m.end()
                            sent = sent_buf[:end].strip()
                            if sent:
                                yield StreamEvent(type="sentence", text=sent, index=sent_idx)
                                sent_idx += 1
                            sent_buf = sent_buf[end:]
                    elif _kind == "timeout":
                        yield StreamEvent(type="error", error=f"local LLM timeout ({int(timeout)}s)")
                        return
            break  # this endpoint answered — stop walking the chain
        except Exception as e:
            _last_err = f"{type(e).__name__}: {e}"
            if full_chunks:
                # Already spoke to Dean — retrying would duplicate the reply.
                yield StreamEvent(type="error", error=f"local stream cut short: {_last_err}")
                return
            continue
    else:
        yield StreamEvent(type="error", error=f"ollama unreachable: {_last_err}")
        _state.available = False
        return

    # Tail flush
    tail = sent_buf.strip()
    if tail:
        yield StreamEvent(type="sentence", text=tail, index=sent_idx)
        sent_idx += 1

    full = "".join(full_chunks).strip()
    if full.lower().startswith("leon:"):
        full = full[5:].strip()

    # If the local model punted (empty or explicitly deferred), escalate.
    #
    # But distinguish the two ways "full" can be empty, because they are not
    # the same failure and the old code conflated them:
    #   (a) the model genuinely declined            -> punt, escalate to Claude
    #   (b) it burned the whole budget thinking      -> NOT a punt. Retry once
    #       with real headroom. Escalating here is worse than useless in
    #       survival mode, where Claude is by definition already down.
    if (not full) and saw_thinking and done_reason == "length" and not _retry:
        yield StreamEvent(
            type="error",
            error="local ran out of budget while reasoning — retrying with more headroom",
        )
        for ev in stream(user_text, brain_state, timeout=timeout, survival=survival,
                         system_override=system_override,
                         max_tokens=max(num_predict * 4, 2048), _retry=True):
            yield ev
        return

    low = full.lower()
    punt_markers = ("let me escalate", "i'll defer", "i can't answer", "i don't know how")
    if (not full) or (any(m in low for m in punt_markers) and len(full) < 50):
        yield StreamEvent(type="error", error="local punted to claude")
        return

    yield StreamEvent(type="done", full_text=full)
