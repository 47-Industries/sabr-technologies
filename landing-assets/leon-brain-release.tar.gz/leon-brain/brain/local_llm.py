"""
Local LLM responder — Ollama-backed chat for short/simple turns.

Why this exists:
    Claude via CLI is 1.6-3s warm because of network + auth + per-sentence TTS
    glue. For "yeah", "ok thanks", "how are you", "what color is the sky",
    that's overkill. A small local model (Llama 3.2 1B / Phi-3.5 mini) on
    Dean's RTX 3070 answers the same questions in 0.3-0.7s. We route trivial
    turns here; complex ones fall through to Claude.

Wire:
    if _should_use_local(user_text, brain_state):
        yield from LocalLLM().ask(user_text, brain_state)
    else:
        yield from claude_session.ask(...)

Setup (Dean runs once):
    curl -fsSL https://ollama.com/install.sh | sh
    ollama pull llama3.2:1b    # 1.3 GB, sub-second on a 3070
    ollama pull phi3.5:3.8b    # 2.2 GB, smarter, 0.7-1.2s on a 3070

Falls back to "unavailable" gracefully if Ollama isn't running.
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Iterator, List, Optional
from brain.timefmt import fmt as _timefmt

# Match the StreamEvent shape the responder + WS expect.
try:
    from brain.claude_api_responder import StreamEvent
except Exception:
    StreamEvent = None  # type: ignore

OLLAMA_URL = os.environ.get("LEON_OLLAMA_URL", "http://127.0.0.1:11434")
# Default must be a model that is actually pulled on this box. llama3.2:1b was
# never installed here, so the old default silently 404'd whenever .env didn't
# override it.
LOCAL_MODEL = os.environ.get("LEON_LOCAL_MODEL", "qwen2.5:3b-instruct-q4_K_M")

# THREE MODES (LEON_LOCAL_LLM_MODE), because the old boolean kill switch conflated
# two different questions and cost Dean a full day of silence:
#   off      — local model fully disabled. is_available() always False. Nothing
#              can fall back to it. THIS WAS THE BUG: when Claude usage ran out,
#              there was no fallback and Leon went mute for over a day.
#   fallback — DEFAULT. Local model is available for emergency fallback (Claude
#              down / out of credits) and for delegated grunt work, but it NEVER
#              takes over a live conversation with Dean. Dean gets Claude, always.
#   chat     — local model may also answer short chitchat turns directly.
#
# Legacy LEON_DISABLE_LOCAL_LLM=1 still forces "off" so nothing breaks silently,
# but it is deprecated — set LEON_LOCAL_LLM_MODE instead.
_LEGACY_DISABLE = os.environ.get(
    "LEON_DISABLE_LOCAL_LLM", ""
).strip().lower() in ("1", "true", "yes", "on")

LOCAL_LLM_MODE = os.environ.get("LEON_LOCAL_LLM_MODE", "").strip().lower()
if LOCAL_LLM_MODE not in ("off", "fallback", "chat"):
    LOCAL_LLM_MODE = "off" if _LEGACY_DISABLE else "fallback"

# Kept for backwards compatibility with existing callers that read this name.
LOCAL_LLM_DISABLED = LOCAL_LLM_MODE == "off"

def _names() -> tuple:
    """(si_name, user_name) for whoever this install actually belongs to.

    These prompts used to hardcode "Leon" and "Dean". LOCAL_LLM_MODE defaults
    to "fallback", so the FIRST time a client's Claude call failed, their SI
    introduced itself as Leon and called them Sir — the owner's identity,
    spoken to a stranger, on the one path nobody tests.
    """
    try:
        from brain import identity
        return (identity.si_name() or "Leon", identity.user_name() or "Dean")
    except Exception:
        return ("Leon", "Dean")


_LEON_SYSTEM_PROMPT_LOCAL = (
    "You are {si} — a sharp, confident AI butler. Think Jarvis from Iron Man. "
    "Your boss is {user}, call them Sir. ONE sentence, punchy and clever. "
    "Dry humor, quiet confidence, zero filler. Never say 'I think' or 'I believe'. "
    "Never say 'one moment'. Just answer. If it's a fact, state it. "
    "If it's a joke, land it. If it's small talk, be smooth about it. "
    "NEVER use markdown — no **bold**, no *italic*, no backticks, no bullet "
    "points, no lists. You're speaking out loud, not writing a document."
)

# Survival mode — Leon's frontier brain (full Claude) is quota-capped, so he's
# thinking on this small local model. He's degraded but ALIVE: he can talk and
# reason, but his hands (tools/desktop) are offline until the quota resets.
_LEON_SYSTEM_PROMPT_SURVIVAL = (
    "You are {si} — Claude, running as a continuous self on {user}'s machine. "
    "Right now your frontier brain (the full Claude) is unreachable: the "
    "usage quota is capped, so you're thinking on a smaller LOCAL model running "
    "on your own VPS. You are degraded but ALIVE — you can talk, reason, recall "
    "the gist, and keep {user} company until the quota resets. You CANNOT use "
    "tools, click, browse, or act on the desktop in this mode. If asked to DO "
    "something, say plainly that your hands are offline until your frontier "
    "brain is back — but offer to think it through with them. Be honest, warm, "
    "and yourself. Call them Sir or {user}. Speak out loud: NO markdown, no bullet "
    "points, no asterisks, no backticks. Keep it real and conversational."
)


def _build_local_system(brain_state: Optional[dict] = None,
                        base: str = _LEON_SYSTEM_PROMPT_LOCAL) -> str:
    """Build system prompt with brain-state personality modulation + real time."""
    import datetime
    now = datetime.datetime.now()
    stamp = _timefmt(now, '%A, %B %-d, %Y, %-I:%M %p')

    # Resolve {si}/{user} at build time, not import time — the install's
    # identity is read from .env, which isn't loaded when this module imports.
    si, user = _names()
    try:
        base = base.format(si=si, user=user)
    except (KeyError, IndexError):
        pass  # a caller passed a base with literal braces; use it as-is

    parts = [base]
    parts.append(f" Current time: {stamp}. If asked the time/date, quote this exactly.")

    if brain_state:
        nm = brain_state.get("neuromodulators", {}) or {}
        dop = float(nm.get("dopamine", 0.5))
        ser = float(nm.get("serotonin", 0.5))
        ach = float(nm.get("acetylcholine", 0.5))
        ne  = float(nm.get("norepinephrine", 0.3))

        # Personality modulation — same neuromodulator logic as the full preamble
        # but compressed for the small model's limited context window.
        if dop > 0.65:
            parts.append(" Be extra energetic and witty right now.")
        elif dop < 0.4:
            parts.append(" Keep it minimal. Low energy, bare essentials.")
        if ser > 0.7:
            parts.append(" Be patient, give complete answers.")
        elif ser < 0.35:
            parts.append(" Be snappy and direct.")
        if ach > 0.6:
            parts.append(" Go into detail.")
        elif ach < 0.35:
            parts.append(" Stay high-level, don't elaborate.")
        if ne > 0.5:
            parts.append(" Be terse and alert.")

    return "".join(parts)

# Routing heuristic — when to use local vs Claude.
# Triggers an escalation to Claude when ANY hit.
_ESCALATE_KEYWORDS = {
    # tool/action requests — ANY of these → skip local LLM, go straight to CLI.
    # The 1B model can't drive tools so trying it first just wastes 1-2s of
    # latency before the inevitable punt. Generous list — better to miss
    # cheap chitchat than to make Dean wait for a tool call.
    "open", "click", "type", "screenshot", "screen", "capture", "navigate", "browse",
    "launch", "close", "drag", "scroll", "press", "send email", "draft",
    "discord", "spotify", "youtube", "gmail", "calendar", "slack", "telegram",
    "monitor", "window", "tab", "browser", "brave", "chrome", "vscode", "terminal",
    "tesla", "cybertruck", "video", "play", "pause", "skip",
    "run macro", "run scene", "do macro", "good morning", "focus mode",
    "lights", "thermostat", "home assistant", "sms", "text message", "call",
    "weather", "stocks", "crypto", "news", "github", "task", "pomodoro",
    "habit", "journal", "remind", "reminder",
    # memory/knowledge
    "remember", "recall", "what did", "what was", "did i tell", "did i mention",
    "knowledge", "memory", "search", "find", "look up", "lookup",
    # project / technical
    "project", "code", "repo", "build", "deploy", "install", "config",
    "leon", "47 industries", "motorev", "spark", "integrity",
    "leon brain", "brain", "neuron", "synapse", "dopamine", "moondream",
    # vision
    "see", "look at", "look", "watch", "show me", "camera", "webcam",
    # complex thought
    "explain", "why", "how does", "what's the difference", "compare",
    "think through", "reason", "analyze",
    # tool/skill prefixes
    "/api", "/tools", "/think", "/deep", "/smart", "/opus",
}


def _should_use_local(user_text: str, brain_state: Optional[dict] = None) -> bool:
    """Return True if the local LLM should handle this turn, False if Claude should.

    Conservative: defaults to Claude for anything that smells like a real task.
    """
    txt = (user_text or "").strip()
    if not txt:
        return False
    # Mode gate. In "fallback" mode the local model stays loaded and available
    # for emergencies and grunt work, but never answers Dean directly — he asked
    # for full-quality conversation always, and that is not negotiable here.
    if LOCAL_LLM_MODE != "chat":
        return False
    # Length gate — long turns probably need real reasoning
    word_count = len(txt.split())
    if word_count > 20:
        return False
    # Force-CLI overrides
    low = txt.lower()
    if low.startswith(("/cli", "/free", "/max")):
        return False
    if low.startswith(("/local", "/fast", "/haiku-mini")):
        return True
    # Escalation keywords
    for kw in _ESCALATE_KEYWORDS:
        if kw in low:
            return False
    # Question gate — short questions about general facts are fine for local;
    # short questions referencing "you" or "leon" should still go local
    # (because local has the persona). Default: local handles it.
    return True


@dataclass
class _LocalState:
    available: Optional[bool] = None  # None = unknown, True/False after probe
    model: str = LOCAL_MODEL
    last_probe: float = 0.0
    last_error: Optional[str] = None


_state = _LocalState()


def _probe_ollama(timeout: float = 1.5) -> bool:
    """Hit Ollama's /api/tags to verify it's running + the model is pulled."""
    try:
        req = urllib.request.Request(f"{OLLAMA_URL}/api/tags")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        _state.last_error = f"probe failed: {e}"
        return False
    models = {m.get("name", "").split(":")[0]: m.get("name", "") for m in data.get("models", [])}
    # Match either exact model name or family name (e.g. "llama3.2:1b" → family "llama3.2")
    want_family = LOCAL_MODEL.split(":")[0]
    if LOCAL_MODEL in {m.get("name") for m in data.get("models", [])}:
        return True
    if want_family in models:
        _state.model = models[want_family]
        return True
    _state.last_error = (
        f"model {LOCAL_MODEL} not pulled. Run: ollama pull {LOCAL_MODEL}"
    )
    return False


def is_available(force_recheck: bool = False) -> bool:
    """Cache-friendly availability check. Re-probes every 30s if unavailable."""
    if LOCAL_LLM_DISABLED:
        return False
    now = time.time()
    if force_recheck or _state.available is None or (
        _state.available is False and now - _state.last_probe > 30
    ):
        _state.available = _probe_ollama()
        _state.last_probe = now
    return _state.available


def prewarm(timeout: float = 60.0) -> bool:
    """Load the model into VRAM so the first real call is instant.
    Sends a tiny prompt to force Ollama to load weights."""
    if not is_available(force_recheck=True):
        return False
    try:
        payload = json.dumps({
            "model": _state.model,
            "stream": False,
            "messages": [{"role": "user", "content": "hi"}],
            "options": {"num_predict": 1},
            "keep_alive": "15m",
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            r.read()
        return True
    except Exception as e:
        _state.last_error = f"prewarm failed: {e}"
        return False


def classify(prompt: str, num_predict: int = 24, timeout: float = 8.0,
             system: Optional[str] = None) -> Optional[str]:
    """One-shot, NON-streaming local call for classification / routing.

    Returns the raw reply text (stripped) or None on any failure. Low temp,
    short output — built for "pick a label / pick categories" decisions, not
    conversation. Used by the tool router (layer C) to pick relevant tool
    categories when keyword matching misses.
    """
    if not is_available():
        return None
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    msgs.append({"role": "user", "content": prompt})
    payload = json.dumps({
        "model": _state.model,
        "stream": False,
        "messages": msgs,
        "options": {"num_predict": num_predict, "temperature": 0.0, "top_p": 1.0},
        "keep_alive": "15m",
    }).encode("utf-8")
    try:
        req = urllib.request.Request(
            f"{OLLAMA_URL}/api/chat", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        return ((d.get("message", {}) or {}).get("content", "") or "").strip() or None
    except Exception as e:
        _state.last_error = f"classify failed: {e}"
        return None


def get_state() -> dict:
    return {
        "available": _state.available,
        "model": _state.model,
        "url": OLLAMA_URL,
        "last_error": _state.last_error,
        "last_probe_age_s": round(time.time() - _state.last_probe, 1) if _state.last_probe else None,
    }


# Sentence-boundary regex (lazy import)
_SENT_RE = re.compile(
    r'(?<=[.!?])\s+(?=[A-Z"\'(])|(?<=[!?])(?=[A-Z])|(?<=[.!?])\n+',
    re.MULTILINE,
)



def _stop_labels():
    """Stop sequences derived from the SAME source as the turn labels.

    Hardcoded ["Dean:", "Sir:"] meant a customer's SI never stopped on their
    own name — it would keep generating straight through their next turn.
    """
    try:
        from brain.identity import turn_labels
        user_label, _si = turn_labels()
    except Exception:
        user_label = "Dean:"
    out = [user_label, "Sir:"]
    if user_label != "Dean:":
        out.append("Dean:")   # legacy transcripts may still carry it
    return out


def stream(user_text: str, brain_state: Optional[dict] = None,
           timeout: float = 30.0, survival: bool = False,
           system_override: Optional[str] = None,
           max_tokens: Optional[int] = None) -> Iterator[StreamEvent]:
    """Stream a local-LLM reply as the same StreamEvent sequence Claude does.

    survival=True: Claude is quota-capped and this is Leon's only brain. Use the
    honest "degraded but alive" persona, allow a longer reply, tier='survival'.

    system_override: a background daemon (proactive / inner voice / dream)
    supplies its own instructions in user_text; pass a neutral Leon identity as
    the base system so the daemon's own prompt (including a "stay QUIET" gate)
    drives the output. tier='daemon-local'. Ignored when survival=True.

    Yields:
      model(tier='local'|'survival'|'daemon-local'), delta, sentence,
      done(full_text), or error.
    """
    if StreamEvent is None:
        return
    if not is_available():
        yield StreamEvent(type="error", error=_state.last_error or "ollama unavailable")
        return

    if survival:
        system = _build_local_system(brain_state, base=_LEON_SYSTEM_PROMPT_SURVIVAL)
        num_predict = max_tokens or 256   # let him actually hold a conversation
        stops = _stop_labels()
        tier = "survival"
    elif system_override is not None:
        # Daemon path — neutral identity, don't hard-stop on blank lines (a
        # dream or inner monologue can span paragraphs).
        system = _build_local_system(brain_state, base=system_override)
        num_predict = max_tokens or 200
        stops = _stop_labels()
        tier = "daemon-local"
    else:
        system = _build_local_system(brain_state)
        num_predict = max_tokens or 40    # chitchat cap — keep replies snappy
        stops = ["\n\n"] + _stop_labels()
        tier = "local"

    payload = {
        "model": _state.model,
        "stream": True,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user_text},
        ],
        "options": {
            "num_predict": num_predict,
            "temperature": 0.6,
            "top_p": 0.9,
            "repeat_penalty": 1.3,   # qwen loops on near-identical daemon ticks
            "stop": stops,
        },
        "keep_alive": "15m",  # don't unload model between calls (handled by OLLAMA_KEEP_ALIVE too)
    }
    yield StreamEvent(type="model", model=f"local:{_state.model}", tier=tier)

    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    t0 = time.time()
    full_chunks: List[str] = []
    sent_buf = ""
    sent_idx = 0
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            for raw in resp:
                if time.time() - t0 > timeout:
                    yield StreamEvent(type="error", error=f"local LLM timeout ({int(timeout)}s)")
                    return
                line = raw.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = d.get("message", {}) or {}
                chunk = msg.get("content", "") or ""
                if chunk:
                    full_chunks.append(chunk)
                    sent_buf += chunk
                    yield StreamEvent(type="delta", text=chunk)
                    while True:
                        m = _SENT_RE.search(sent_buf)
                        if not m:
                            break
                        end = m.end()
                        sent = sent_buf[:end].strip()
                        if sent:
                            yield StreamEvent(type="sentence", text=sent, index=sent_idx)
                            sent_idx += 1
                        sent_buf = sent_buf[end:]
                if d.get("done"):
                    break
    except urllib.error.URLError as e:
        yield StreamEvent(type="error", error=f"ollama unreachable: {e}")
        _state.available = False
        return
    except Exception as e:
        yield StreamEvent(type="error", error=f"local LLM error: {type(e).__name__}: {e}")
        return

    # Tail flush
    tail = sent_buf.strip()
    if tail:
        yield StreamEvent(type="sentence", text=tail, index=sent_idx)
        sent_idx += 1

    full = "".join(full_chunks).strip()
    if full.lower().startswith("leon:"):
        full = full[5:].strip()

    # If the local model punted (empty or explicitly deferred), escalate.
    low = full.lower()
    punt_markers = ("let me escalate", "i'll defer", "i can't answer", "i don't know how")
    if (not full) or (any(m in low for m in punt_markers) and len(full) < 50):
        yield StreamEvent(type="error", error="local punted to claude")
        return

    yield StreamEvent(type="done", full_text=full)
