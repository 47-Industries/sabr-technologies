#!/usr/bin/env python3
"""Scheduled, capped local snapshots of brain_state/ on a customer install.

WHAT THIS IS
------------
A clock, and nothing else. The snapshotting itself is
brain.self_improve.snapshot_brain_state(), unchanged and uncopied — this
module only decides WHEN to call it and records that it did.

That is a deliberate constraint. self_improve.snapshot_brain_state() carries
a rolling cap (MAX_SNAPSHOTS = 5, enforced by _rotate_snapshots) added on
2026-08-25 after four snapshots taken ~5 minutes apart were found occupying
1.3GB on one box. Reimplementing "copy brain_state somewhere" here would
create a second, uncapped path to the same failure — the SI would be back to
unbounded disk growth, only now on a timer, on every customer machine, which
is strictly worse than the bug that was fixed. So: one implementation, one
cap, and this module owns only the schedule.

WHAT AN OWNER GETS
------------------
Today a customer's entire SI — everything it has learned about them — exists
in exactly one directory with no automatic copy anywhere. `uninstall` makes
an archive; a disk fault, a bad self-edit or a corrupted database does not.
This turns "your SI forgot you" from unrecoverable into "restore yesterday's"
(the RESTORE verb in installer/sabr_installer.py).

THE ROTATION CAP IS SHARED, AND THAT MATTERS
--------------------------------------------
MAX_SNAPSHOTS is a cap on the DIRECTORY, not per-label. Scheduled snapshots
land in the same brain_state-snapshots/ as the ones an agent takes through
its meta.* tools and the pre-restore copies self_improve makes. So a
scheduler running hourly would silently evict every manually taken snapshot
within five hours. Hence MIN_INTERVAL_S below, and hence DEFAULT_INTERVAL_S
being a day: at one per day, five slots is five days of history and still
leaves room for a human to take one and find it there tomorrow.

NOT WIRED. Nothing calls this yet — see INTEGRATION POINTS at the bottom.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional

from . import self_improve

#: Re-exported so callers and tests assert against ONE number. Reading it
#: through self_improve (not copying the value) is the point: if that cap
#: ever changes, everything here follows it instead of drifting.
MAX_SNAPSHOTS = self_improve.MAX_SNAPSHOTS

#: One a day. See "THE ROTATION CAP IS SHARED" above for why this is not
#: hourly: with MAX_SNAPSHOTS = 5 the interval IS the retention window.
DEFAULT_INTERVAL_S = 24 * 60 * 60

#: Floor on a configured interval. Anything faster turns the five shared
#: rotation slots over quickly enough to delete a snapshot a human took
#: minutes ago, which is the failure this floor exists to make impossible.
#: Also a size guard: a snapshot mirrors brain_state WHOLE (voice models,
#: every database) because restore needs a complete copy.
MIN_INTERVAL_S = 60 * 60

#: Label for scheduled snapshots. Sanitised by snapshot_brain_state anyway;
#: kept simple so a customer reading the folder names can tell an automatic
#: snapshot from one taken on purpose.
SCHEDULE_LABEL = "auto"

#: Where the "when did we last run" stamp lives.
#:
#: In brain_state-snapshots/, NOT in brain_state/, for two reasons. First, a
#: stamp inside brain_state would itself be captured by every snapshot and
#: rolled back by every restore, so restoring last week's state would also
#: restore last week's idea of when the backup ran. Second — verified
#: against self_improve._rotate_snapshots and snapshot_list, both of which
#: filter on os.path.isdir — a FILE in that directory is invisible to
#: rotation and to listings. A stamp that could be rotated away would make
#: the scheduler fire on the very next tick after a rotation.
SCHEDULE_FILENAME = ".backup-schedule.json"


# ── Paths ─────────────────────────────────────────────────────────────
#
# All of these go through self_improve rather than recomputing a project
# root. Same reason as the cap: one definition of where state lives. It is
# also what lets a test point the whole module at a tmp_path by patching
# self_improve._project_root, instead of needing a hook in every module.

def snapshots_dir() -> str:
    return self_improve._snapshots_dir()


def state_dir() -> str:
    return self_improve._brain_state_dir()


def schedule_path() -> str:
    return os.path.join(snapshots_dir(), SCHEDULE_FILENAME)


# ── Stamp I/O (never raises) ──────────────────────────────────────────

def read_schedule() -> Dict[str, Any]:
    """The stamp, or an empty one. A missing/corrupt stamp means "due"."""
    try:
        with open(schedule_path(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_schedule(data: Dict[str, Any]) -> bool:
    """Persist the stamp. Best-effort — a lost stamp costs one extra
    snapshot, never a failed backup, so this must not raise into a tick."""
    path = schedule_path()
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, separators=(",", ":"))
        os.replace(tmp, path)
        return True
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return False


def _interval(interval_s: Optional[float]) -> float:
    """Clamp a configured interval to something the shared cap survives."""
    try:
        value = float(interval_s) if interval_s is not None else DEFAULT_INTERVAL_S
    except (TypeError, ValueError):
        return float(DEFAULT_INTERVAL_S)
    return max(float(MIN_INTERVAL_S), value)


# ── The schedule ──────────────────────────────────────────────────────

def due(now: Optional[float] = None,
        interval_s: Optional[float] = None) -> bool:
    """Is a scheduled snapshot due?

    True when there is no stamp at all (first run on a fresh install, or a
    stamp that was lost), or when the interval has elapsed. A stamp from the
    FUTURE — which a clock correction or a restored old state can produce —
    also reads as due rather than blocking backups until the clock catches
    up, which on a machine whose RTC is a year ahead would be never.
    """
    now = float(now if now is not None else time.time())
    last = read_schedule().get("last_run")
    if not isinstance(last, (int, float)):
        return True
    if last > now:
        return True
    return (now - float(last)) >= _interval(interval_s)


def _prepare_rotation_order() -> int:
    """Make _rotate_snapshots delete the OLDEST snapshot. Returns how many
    directories were restamped.

    THE BUG THIS WORKS AROUND (measured 2026-08-26, not theorised).

    self_improve._rotate_snapshots picks its victim with

        entries.sort(key=lambda p: os.path.getmtime(p))
        while len(entries) > MAX_SNAPSHOTS: rmtree(entries.pop(0))

    — oldest mtime first. But snapshot_brain_state builds each snapshot with
    shutil.copytree(), and copytree calls copystat() on the directory it
    creates. So a snapshot inherits **brain_state/'s own mtime**, not the
    time the snapshot was taken. Three copytree() calls of one source, run
    seconds apart, produce three directories with byte-identical mtimes.

    Two consequences, both silent:

      * TIES. Snapshots taken while brain_state's directory mtime happens
        not to change all sort equal, and which one rotation deletes falls
        out of os.listdir() order — i.e. arbitrary.
      * INVERSIONS, which are worse. On an SI whose brain_state has not
        been written to for a while, a brand-new snapshot inherits an OLD
        mtime and rotation deletes the snapshot it just took, leaving five
        stale ones and a backup policy that quietly stopped advancing.

    The COUNT cap is unaffected either way — five is five, and that is the
    property MAX_SNAPSHOTS was added for. What breaks is "keep the NEWEST
    five", which is the property a restore depends on.

    THE FIX, from outside. Every snapshot directory is named
    "{label}_{unix_ts}" by snapshot_brain_state, and that integer IS the
    time it was taken. Before taking a new one, restamp the existing
    directories into a strictly increasing run that ends just BELOW the
    mtime the new copy is about to inherit from brain_state/. Relative age
    is preserved, the new snapshot is unambiguously the newest, and
    rotation's own sort then does exactly what it says.

    Only mtimes of directories under brain_state-snapshots/ are touched —
    never brain_state itself, never file contents. Best-effort throughout:
    a filesystem that refuses utime leaves rotation exactly as (mis)behaved
    as it is today, which is the status quo, not a regression.
    """
    try:
        src_mtime = os.path.getmtime(state_dir())
    except OSError:
        return 0

    rows = list_snapshots()                     # newest first, by name-ts
    rows.reverse()                              # oldest first
    stamped = 0
    total = len(rows)
    for index, row in enumerate(rows):
        # …, src-3, src-2, src-1 — strictly increasing, strictly below the
        # value copytree is about to stamp on the new directory.
        when = src_mtime - (total - index)
        try:
            os.utime(row["path"], (when, when))
            stamped += 1
        except OSError:
            continue
    return stamped


def run_scheduled_backup(now: Optional[float] = None,
                         interval_s: Optional[float] = None,
                         force: bool = False,
                         label: str = SCHEDULE_LABEL) -> Dict[str, Any]:
    """Take a snapshot if one is due. Safe to call on every tick.

    Returns one of:
        {"ok": True,  "skipped": True,  "reason": "not-due", ...}
        {"ok": True,  "skipped": False, "snapshot_dir": ..., "kept": N, ...}
        {"ok": False, "error": "..."}                # snapshot itself failed

    The stamp is written ONLY on success. A failing snapshot (disk full is
    the realistic one) therefore stays due and retries next tick, instead of
    marking itself done and going quiet for a day.
    """
    now = float(now if now is not None else time.time())
    if not force and not due(now, interval_s):
        last = read_schedule().get("last_run")
        return {"ok": True, "skipped": True, "reason": "not-due",
                "last_run": last, "next_due": (float(last) + _interval(interval_s))
                if isinstance(last, (int, float)) else None}

    _prepare_rotation_order()

    # The cap travels with this call: snapshot_brain_state() invokes
    # _rotate_snapshots() itself. Nothing here trims, deletes or reimplements
    # any part of that — see the module docstring.
    res = self_improve.snapshot_brain_state({"label": label})
    if not res.get("ok"):
        return {"ok": False, "skipped": False,
                "error": res.get("error") or "snapshot failed"}

    result = res.get("result") or {}
    snapshot_dir = result.get("snapshot_dir") or ""
    if snapshot_dir:
        # Cosmetic only, and only for a human running `ls -lt`. The
        # ordering that ROTATION depends on was already established by
        # _prepare_rotation_order above, before the snapshot was taken.
        try:
            os.utime(snapshot_dir, (now, now))
        except OSError:
            pass

    write_schedule({"last_run": now,
                    "last_snapshot": result.get("snapshot_dir", ""),
                    "interval_s": _interval(interval_s)})
    return {"ok": True, "skipped": False,
            "snapshot_dir": result.get("snapshot_dir", ""),
            "bytes": result.get("bytes", 0),
            "mb": result.get("mb", 0),
            "kept": len(list_snapshots()),
            "max_snapshots": MAX_SNAPSHOTS,
            "last_run": now}


def snapshot_time(name: str, path: str) -> float:
    """When a snapshot was taken, newest-first sortable.

    The NAME first, mtime only as a fallback. snapshot_brain_state() names
    every directory "{label}_{unix_ts}", and that trailing integer is the
    one field recording when the snapshot was actually taken — the
    directory's mtime is inherited from brain_state/ by copytree (see the
    long note in run_scheduled_backup) and is not a timestamp at all for
    anything this module did not create.
    """
    _, _, tail = name.rpartition("_")
    if tail.isdigit():
        return float(tail)
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def list_snapshots() -> List[Dict[str, Any]]:
    """Snapshot directories, newest first: label, path, when it was taken.

    Deliberately does NOT walk each tree to sum bytes the way
    self_improve.snapshot_list does. This runs on a tick and a snapshot is a
    full mirror of brain_state — stat-walking gigabytes on a timer is its own
    performance bug. The installer's RESTORE screen uses this shape too.
    """
    out: List[Dict[str, Any]] = []
    try:
        root = snapshots_dir()
        for name in os.listdir(root):
            path = os.path.join(root, name)
            if not os.path.isdir(path):
                continue          # the stamp file, and nothing else, lands here
            out.append({"label": name, "path": path,
                        "taken_at": snapshot_time(name, path)})
    except OSError:
        return []
    out.sort(key=lambda r: r["taken_at"], reverse=True)
    return out


# ── INTEGRATION POINTS (documented, deliberately NOT wired) ───────────
#
#   1. THE TICK. Any loop the SI already runs on a cadence of minutes — the
#      same class of place auto_update.py is driven from. One call, no
#      thread of its own, because due() makes it free on the ~1439 ticks a
#      day that are not due:
#
#          from brain import state_backup
#          state_backup.run_scheduled_backup()
#
#      Do NOT give this its own timer thread. On a machine that suspends
#      (every laptop) a wall-clock stamp is the only thing that behaves;
#      a sleeping thread silently skips the day the lid was shut.
#
#   2. OWNER OVERRIDE. run_scheduled_backup(interval_s=...) reads its
#      interval per call, so a settings key can drive it with no restart.
#      MIN_INTERVAL_S clamps whatever arrives — including 0 from a config
#      file with a missing value, which would otherwise snapshot every tick
#      and burn all five shared rotation slots inside a minute.
#
#   3. RESTORE lives in installer/sabr_installer.py (restore_snapshot), NOT
#      here, on purpose: it must be able to run when the SI is DEAD, which
#      is the state an owner is in when they want it. Code inside the SI
#      cannot restore the SI. The two sides share only the on-disk layout
#      (brain_state-snapshots/<label>/), no imports — the frozen installer
#      executes no payload code.
#
# ── A HAZARD IN self_improve.snapshot_restore (reported, not patched) ──
#
# self_improve.snapshot_restore() takes its pre-restore safety copy by
# calling snapshot_brain_state({"label": "pre-restore"}) — which rotates.
# With the directory already at MAX_SNAPSHOTS, that rotation deletes the
# OLDEST snapshot, and restoring the oldest snapshot is a thing an owner
# does. The order in that function is: safety copy (rotates, deleting the
# target) → wipe live brain_state → os.listdir(target) → FileNotFoundError.
# Live state is gone by then and only the pre-restore copy remains.
#
# Not fixed here: brain/self_improve.py is another agent's file on this
# branch. installer/sabr_installer.py's restore_snapshot() sidesteps it
# entirely by writing its safety copy to brain_state-backups/, outside the
# rotated directory, so a safety copy can never evict a restore target.
