"""
Multi-tenant brain management — V1.3

Problem V1.2 had: one install = one brain = one user. No good for a
10-person marketing agency. They'd have to spin up 10 separate installs
and their team knowledge lived in 10 silos.

Solution in V1.3: one install runs N isolated brains, PLUS shared
"channels" that teams can subscribe to. Marketing team shares campaign
knowledge; sales team shares customer knowledge; everyone sees
"company-wide" knowledge if they're subscribed.

Architecture:
  brain_state/
    tenants/
      <tenant_id>/
        knowledge.db         - isolated semantic memory
        meta.json            - tenant metadata
        drafts/
        sheets/
        ...
    channels/
      <channel_id>.db        - shared memory bus
    registry.json            - tenant registry + keys + subscriptions

Each tenant gets a unique token. Pass it as `X-NL-Tenant-Token` header
or `?token=` param on API calls. The manager routes to the right
knowledge store and enforces roles (admin / user / readonly).
"""

from __future__ import annotations

import hashlib
import json
import os
import secrets
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from brain.knowledge_store import KnowledgeStore


def _app_root() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _tenants_dir() -> str:
    """Per-tenant knowledge stores. LEON_TENANTS_DIR is the test override
    that pairs with LEON_REGISTRY_PATH — without it a test that adopts a
    token creates a real uuid-named SQLite store in the developer's live
    brain_state/tenants, which is the same pollution problem one directory
    over."""
    override = (os.environ.get("LEON_TENANTS_DIR") or "").strip()
    d = override or os.path.join(_app_root(), "brain_state", "tenants")
    os.makedirs(d, exist_ok=True)
    return d


def _channels_dir() -> str:
    d = os.path.join(_app_root(), "brain_state", "channels")
    os.makedirs(d, exist_ok=True)
    return d


def _registry_path() -> str:
    """Where the tenant registry lives.

    LEON_REGISTRY_PATH exists for TESTS (audit §5.1, 2026-08-25). Without
    it, any test that exercises tenant_manager writes through the module
    singleton into the developer's REAL registry.json — which is how the
    live VPS registry came to hold 120 hex-encoded test strings
    ("paid1786…", "pasted…", "twice…") and 9 PreflightProbe rows, sitting
    alongside actual paying customers. `SABR_LICENSE_STATE_PATH` already
    does exactly this for the heartbeat's state file; the registry, which
    is the more valuable of the two, had no equivalent.
    """
    override = (os.environ.get("LEON_REGISTRY_PATH") or "").strip()
    if override:
        return override
    return os.path.join(_app_root(), "brain_state", "registry.json")


VALID_ROLES = {"admin", "user", "readonly"}


@dataclass
class Tenant:
    tenant_id: str
    name: str
    role: str = "user"
    token: str = ""
    subscribed_channels: List[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def public_dict(self) -> dict:
        """Safe-to-return dict (NO token)."""
        d = asdict(self)
        d.pop("token", None)
        return d

    def full_dict(self) -> dict:
        """Full dict including token — only returned on create or to admins."""
        return asdict(self)


@dataclass
class Channel:
    channel_id: str
    name: str
    description: str = ""
    created_at: float = field(default_factory=time.time)
    subscriber_count: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


class TenantManager:
    """Routes API calls to the right tenant's knowledge store."""

    def __init__(self):
        self._tenants: Dict[str, Tenant] = {}
        self._channels: Dict[str, Channel] = {}
        self._stores: Dict[str, KnowledgeStore] = {}         # tenant_id -> KnowledgeStore
        self._channel_stores: Dict[str, KnowledgeStore] = {} # channel_id -> KnowledgeStore
        self._token_index: Dict[str, str] = {}               # token -> tenant_id
        # Serialises _save_registry within this process. Per-instance on
        # purpose — see the docstring there.
        self._save_lock = threading.Lock()
        self._load_registry()

    # ---------- Registry persistence ----------

    def _load_registry(self):
        path = _registry_path()
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for t_data in data.get("tenants", []):
                # Only known fields — ignores extras from future versions
                known = {k: v for k, v in t_data.items() if k in Tenant.__dataclass_fields__}
                t = Tenant(**known)
                self._tenants[t.tenant_id] = t
                if t.token:
                    self._token_index[t.token] = t.tenant_id
            for c_data in data.get("channels", []):
                known = {k: v for k, v in c_data.items() if k in Channel.__dataclass_fields__}
                c = Channel(**known)
                self._channels[c.channel_id] = c
        except Exception as e:
            print(f"[TENANT] Failed to load registry: {e}")

    def _save_registry(self):
        """Persist the registry atomically, safely under concurrent writers.

        THE BUG THIS FIXES (2026-08-26): the temp file used to be a FIXED,
        process-independent name — `registry.json.tmp`. Two writers at once
        (the checkout provisioning path and a heartbeat, two workers, a
        test run beside the server) both opened THAT SAME PATH. Writer B
        truncated writer A's half-written file, then whichever `os.replace`
        ran second either raised FileNotFoundError — the tmp had already
        been renamed away — or landed a truncated registry over the real
        one. This is the token store corrupting itself, and it is the
        single file the fleet view, install-config and the heartbeat all
        depend on.

        Two independent defences, because the two races are different:
          * `tempfile.mkstemp` gives every writer, in every PROCESS, its own
            temp name. Nobody can truncate anybody.
          * `self._save_lock` serialises writers inside ONE process, so the
            snapshot below can't be taken mid-mutation by another thread.

        fsync before replace: `os.replace` is atomic with respect to
        readers, but it does not promise the bytes reached the disk. Without
        the fsync a power loss can leave the directory entry pointing at a
        file whose contents were never flushed — an empty registry, which
        reads as "every customer is gone".

        Note the lock is per-INSTANCE, not global: two TenantManager objects
        (or two processes) are still concurrent writers, which is exactly
        the case the mkstemp half covers.
        """
        path = _registry_path()
        directory = os.path.dirname(path) or "."
        os.makedirs(directory, exist_ok=True)
        with self._save_lock:
            data = {
                "tenants": [t.full_dict() for t in list(self._tenants.values())],
                "channels": [c.to_dict() for c in list(self._channels.values())],
            }
            payload = json.dumps(data, indent=2)
            # Same directory as the target: os.replace is only atomic within
            # a filesystem, and /tmp is frequently a different one.
            fd, tmp = tempfile.mkstemp(dir=directory, prefix=".registry-",
                                       suffix=".json.tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(payload)
                    f.flush()
                    os.fsync(f.fileno())
                # os.replace not os.rename: Windows refuses rename onto an
                # existing file (WinError 183); POSIX overwrites. Atomic on both.
                os.replace(tmp, path)
            except BaseException:
                # Never leave a .registry-*.json.tmp behind to accumulate.
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise

    # ---------- Tenant CRUD ----------

    def create_tenant(self, name: str, role: str = "user", metadata: Optional[dict] = None) -> Tenant:
        if role not in VALID_ROLES:
            raise ValueError(f"role must be one of {VALID_ROLES}")
        tenant_id = str(uuid.uuid4())
        # Tenant API token: 32 chars, URL-safe
        token = "nlkd_" + secrets.token_urlsafe(24)
        t = Tenant(
            tenant_id=tenant_id,
            name=name,
            role=role,
            token=token,
            metadata=metadata or {},
        )
        self._tenants[tenant_id] = t
        self._token_index[token] = tenant_id
        # Ensure tenant folder + knowledge store
        self._ensure_tenant_store(tenant_id)
        self._save_registry()
        print(f"[TENANT] Created tenant {name!r} id={tenant_id[:8]}... role={role}")
        return t

    def adopt_paid_token(self, token: str, name: str, metadata: Optional[dict] = None) -> Tenant:
        """Create a tenant whose token is one the CHECKOUT service already minted.

        Two token universes existed until now: checkout mints a bare 32-hex
        entitlement token at purchase, while create_tenant() mints an
        `nlkd_`-prefixed one. The installer redeems its token here — so every
        paying customer's token was, by construction, unrecognisable. Found
        2026-07-30 with a real buyer staring at "token not recognized" after
        paying. This binds the token he was actually given to a real tenant.

        Idempotent: redeeming the same token twice returns the same tenant, so
        a customer re-running the installer never gets a second brain.
        """
        existing = self.auth(token)
        if existing is not None:
            return existing
        tenant_id = str(uuid.uuid4())
        t = Tenant(
            tenant_id=tenant_id,
            name=name,
            role="user",
            token=token,
            metadata=metadata or {},
        )
        self._tenants[tenant_id] = t
        self._token_index[token] = tenant_id
        self._ensure_tenant_store(tenant_id)
        self._save_registry()
        print(f"[TENANT] Adopted paid token for {name!r} id={tenant_id[:8]}...")
        return t

    def delete_tenant(self, tenant_id: str, wipe_data: bool = False) -> bool:
        t = self._tenants.pop(tenant_id, None)
        if t is None:
            return False
        if t.token in self._token_index:
            self._token_index.pop(t.token, None)
        self._stores.pop(tenant_id, None)
        if wipe_data:
            import shutil
            path = os.path.join(_tenants_dir(), tenant_id)
            if os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
        self._save_registry()
        return True

    def list_tenants(self) -> List[Tenant]:
        return list(self._tenants.values())

    def get_tenant(self, tenant_id: str) -> Optional[Tenant]:
        return self._tenants.get(tenant_id)

    def rotate_token(self, tenant_id: str) -> Optional[str]:
        t = self._tenants.get(tenant_id)
        if t is None:
            return None
        if t.token in self._token_index:
            self._token_index.pop(t.token)
        t.token = "nlkd_" + secrets.token_urlsafe(24)
        self._token_index[t.token] = tenant_id
        self._save_registry()
        return t.token

    # ---------- Auth ----------

    def auth(self, token: Optional[str]) -> Optional[Tenant]:
        """Resolve token -> tenant (or None). Updates last_seen on success."""
        if not token:
            return None
        tid = self._token_index.get(token)
        if tid is None:
            return None
        t = self._tenants.get(tid)
        if t is not None:
            t.last_seen = time.time()
        return t

    def require_role(self, token: Optional[str], *allowed_roles: str) -> Tenant:
        """Raise if the token is invalid or the role is not allowed."""
        t = self.auth(token)
        if t is None:
            raise PermissionError("Invalid tenant token")
        if t.role not in allowed_roles:
            raise PermissionError(
                f"Tenant role {t.role!r} not in required roles {allowed_roles}"
            )
        return t

    # ---------- Knowledge routing ----------

    def _tenant_db_path(self, tenant_id: str) -> str:
        d = os.path.join(_tenants_dir(), tenant_id)
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "knowledge.db")

    def _channel_db_path(self, channel_id: str) -> str:
        return os.path.join(_channels_dir(), f"{channel_id}.db")

    def _ensure_tenant_store(self, tenant_id: str) -> KnowledgeStore:
        """Get or create the tenant's isolated KnowledgeStore."""
        if tenant_id in self._stores:
            return self._stores[tenant_id]
        store = KnowledgeStore(db_path=self._tenant_db_path(tenant_id))
        self._stores[tenant_id] = store
        return store

    def _ensure_channel_store(self, channel_id: str) -> KnowledgeStore:
        if channel_id in self._channel_stores:
            return self._channel_stores[channel_id]
        store = KnowledgeStore(db_path=self._channel_db_path(channel_id))
        self._channel_stores[channel_id] = store
        return store

    def get_store(self, tenant_id: str) -> Optional[KnowledgeStore]:
        if tenant_id not in self._tenants:
            return None
        return self._ensure_tenant_store(tenant_id)

    # ---------- Channels ----------

    def create_channel(self, name: str, description: str = "") -> Channel:
        channel_id = str(uuid.uuid4())
        ch = Channel(channel_id=channel_id, name=name, description=description)
        self._channels[channel_id] = ch
        self._ensure_channel_store(channel_id)
        self._save_registry()
        print(f"[TENANT] Created channel {name!r} id={channel_id[:8]}...")
        return ch

    def delete_channel(self, channel_id: str) -> bool:
        ch = self._channels.pop(channel_id, None)
        if ch is None:
            return False
        # Unsubscribe all tenants
        for t in self._tenants.values():
            if channel_id in t.subscribed_channels:
                t.subscribed_channels.remove(channel_id)
        self._channel_stores.pop(channel_id, None)
        self._save_registry()
        return True

    def list_channels(self) -> List[Channel]:
        # Update subscriber counts
        for ch in self._channels.values():
            ch.subscriber_count = sum(
                1 for t in self._tenants.values() if ch.channel_id in t.subscribed_channels
            )
        return list(self._channels.values())

    def subscribe(self, tenant_id: str, channel_id: str) -> bool:
        t = self._tenants.get(tenant_id)
        if t is None or channel_id not in self._channels:
            return False
        if channel_id not in t.subscribed_channels:
            t.subscribed_channels.append(channel_id)
            self._save_registry()
        return True

    def unsubscribe(self, tenant_id: str, channel_id: str) -> bool:
        t = self._tenants.get(tenant_id)
        if t is None:
            return False
        if channel_id in t.subscribed_channels:
            t.subscribed_channels.remove(channel_id)
            self._save_registry()
            return True
        return False

    def publish_to_channel(self, channel_id: str, text: str, source: str = "tenant",
                           tags: Optional[list] = None) -> dict:
        if channel_id not in self._channels:
            return {"ok": False, "error": "channel not found"}
        store = self._ensure_channel_store(channel_id)
        try:
            entry_id = store.store(text=text, source=source, tags=tags or [])
            return {"ok": True, "entry_id": entry_id, "channel_id": channel_id}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # ---------- Unified query (tenant + their subscribed channels) ----------

    def recall(self, tenant_id: str, query: str, limit: int = 20,
               include_channels: bool = True) -> List[dict]:
        """
        Semantic recall that merges tenant's own memory + anything in
        channels they've subscribed to. Perfect for the "every employee
        gets institutional memory on day one" pitch.
        """
        t = self._tenants.get(tenant_id)
        if t is None:
            return []
        results: List[dict] = []
        store = self._ensure_tenant_store(tenant_id)
        for r in store.semantic_search(query, limit=limit):
            r["_origin"] = "tenant"
            results.append(r)
        if include_channels:
            for ch_id in t.subscribed_channels:
                if ch_id in self._channels:
                    ch_store = self._ensure_channel_store(ch_id)
                    for r in ch_store.semantic_search(query, limit=limit):
                        r["_origin"] = f"channel:{self._channels[ch_id].name}"
                        results.append(r)
        # Re-sort combined results by similarity
        results.sort(key=lambda r: r.get("_similarity", 0), reverse=True)
        return results[:limit]

    def store(self, tenant_id: str, text: str, source: str = "tenant",
              tags: Optional[list] = None) -> dict:
        store = self.get_store(tenant_id)
        if store is None:
            return {"ok": False, "error": "unknown tenant"}
        try:
            entry_id = store.store(text=text, source=source, tags=tags or [])
            return {"ok": True, "entry_id": entry_id, "tenant_id": tenant_id}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # ---------- Stats ----------

    def stats(self) -> dict:
        return {
            "tenant_count": len(self._tenants),
            "channel_count": len(self._channels),
            "by_role": {
                role: sum(1 for t in self._tenants.values() if t.role == role)
                for role in VALID_ROLES
            },
            "total_subscriptions": sum(
                len(t.subscribed_channels) for t in self._tenants.values()
            ),
        }


# ============================================================================
# Entitlement lease client — self-knowledge, not a lock (ENTITLEMENT REV 4)
#
# The gateway decides whether this install may think; nothing here gates
# anything. This section exists so the SI can tell the TRUTH about itself
# with no network: is this a connection problem or a lapse? Every successful
# gateway call refreshes a signed "entitled through <date>" statement on
# disk; when the gateway is unreachable, local arithmetic on that statement
# picks which pre-written sentence the body speaks. Forging the lease buys a
# nicer error message and zero cognition, which is why it is safe for the
# verify key to live on this machine.
# ============================================================================

# The two offline states live HERE and not in the service, because they are
# precisely the states in which the service is unreachable — a copy on the
# server could never be rendered, only drift. Version tracks the service's
# CONDITION_TEMPLATES_VERSION; bump both together.
OFFLINE_CONDITION_TEMPLATES_VERSION = 3
OFFLINE_CONDITION_TEMPLATES = {
    "offline_lease_valid": {
        "state": "offline",
        "reason": (
            "I can't reach my cortex — that's a connection problem, not a "
            "billing one. I checked before saying so: my lease is still good. "
            "I'll be myself again the moment we're back online."
        ),
        "what_would_change_it": "Network access to the gateway.",
    },
    "offline_lease_expired": {
        "state": "unknown",
        "reason": (
            "I've been away from home longer than my lease covers, so I "
            "honestly can't tell you whether this is the connection or a "
            "lapsed subscription. I'd rather say I don't know than guess."
        ),
        "what_would_change_it": "One successful gateway call would settle it either way.",
    },
}

# The gateway's Ed25519 PUBLIC key (hex), shipped in the install command —
# safe in shell history and plaintext email by construction; the signing half
# never leaves the gateway, so possession of this key forges nothing.
# Empty means "can't verify" — which is reported honestly, never upgraded.
_LEASE_VERIFY_KEY = os.environ.get("SABR_LEASE_VERIFY_KEY", "")
_ENTITLEMENT_URL = os.environ.get(
    "SABR_ENTITLEMENT_URL",
    "https://sabr-checkout-production.up.railway.app/entitlement",
)


def _lease_path() -> str:
    override = os.environ.get("SABR_LEASE_PATH")
    if override:
        return override
    d = os.path.join(_app_root(), "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "entitlement_lease.json")


def store_lease(envelope: Dict[str, Any]) -> None:
    """Persist the gateway's {lease, sig, signed} envelope atomically."""
    path = _lease_path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(envelope, f, indent=2)
    os.replace(tmp, path)


def _load_lease() -> Optional[Dict[str, Any]]:
    try:
        with open(_lease_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def verify_lease(envelope: Dict[str, Any]) -> Optional[bool]:
    """True/False = Ed25519 signature checked against the gateway's public
    key; None = no key or no crypto library, honestly unverifiable. Never
    raises — a broken envelope is a False, not an exception, because this
    path runs precisely when things are already going wrong."""
    if not _LEASE_VERIFY_KEY:
        return None
    # Rotation honesty: False must mean someone tampered; None must mean "I
    # can't tell." A scheme this client doesn't recognize — a future rotation,
    # an older gateway — is CAN'T TELL, never an accusation of forgery.
    if envelope.get("sig_alg") != "ed25519":
        return None
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
    except ImportError:
        return None
    sig = envelope.get("sig")
    if not sig:
        return False
    raw = json.dumps(envelope.get("lease") or {}, sort_keys=True, separators=(",", ":"))
    try:
        key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(_LEASE_VERIFY_KEY))
        key.verify(bytes.fromhex(sig), raw.encode())
        return True
    except (InvalidSignature, ValueError):
        return False


def refresh_lease(token: str, timeout: float = 10.0) -> Dict[str, Any]:
    """One gateway call. Reachable → the gateway's answer is authoritative and
    any lease in it is stored. Unreachable → {"reachable": False} and the
    caller falls back to local_condition(). Never raises."""
    import urllib.parse
    import urllib.request

    url = f"{_ENTITLEMENT_URL}?token={urllib.parse.quote(token)}"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            answer = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"reachable": False, "error": type(e).__name__}
    if answer.get("lease"):
        store_lease(answer["lease"])
    return {"reachable": True, "answer": answer}


def local_condition(now: Optional[float] = None) -> Dict[str, Any]:
    """The offline three-way, minus the reachable case the caller already
    ruled out: lease valid → connection problem; expired or absent → honest
    uncertainty. Pure narration; gates nothing."""
    now = now or time.time()
    envelope = _load_lease()
    verified = verify_lease(envelope) if envelope else False
    through = ((envelope or {}).get("lease") or {}).get("through") or 0
    key = "offline_lease_valid" if through > now else "offline_lease_expired"
    tpl = OFFLINE_CONDITION_TEMPLATES[key]
    return {
        "state": tpl["state"],
        "reason": tpl["reason"],
        "what_would_change_it": tpl["what_would_change_it"],
        "since": int(now),
        "templates_version": OFFLINE_CONDITION_TEMPLATES_VERSION,
        "lease_through": through or None,
        "lease_verified": verified,
    }


def entitlement_condition(token: str) -> Dict[str, Any]:
    """The one call the substrate makes: reachable → the gateway's report
    verbatim (and a refreshed lease on disk); unreachable → the local
    three-way. Narration only — enforcement lives at the gateway."""
    live = refresh_lease(token)
    if live.get("reachable"):
        answer = live["answer"]
        report = dict(answer.get("report") or {})
        report["allow"] = answer.get("allow")
        report["reachable"] = True
        return report
    report = local_condition()
    report["reachable"] = False
    return report


# Module singleton. Import and use: from brain.tenant import tenant_manager
tenant_manager = TenantManager()
