"""
Brain Orchestrator - Main simulation loop.

Coordinates all 18 brain regions, manages inter-region synaptic connections,
runs STDP learning, and streams state to the visualization dashboard.
"""

import logging
import os
import time
from typing import Optional

import numpy as np

log = logging.getLogger("leon.brain")
from brain.config import BrainConfig
from brain.regions import create_all_regions
from brain.synapses import SynapseMatrix, batch_update_stdp
from brain.safety import SafetyKernel



def _layout_seed() -> int:
    """Per-install seed for the neuron LAYOUT (visualisation only).

    Was a hardcoded 42 at both position call sites, which meant every install
    on earth rendered a byte-identical brain -- two owners comparing
    screenshots saw the same object and neither had anything of their own.

    Derived from this install's identity, not from the graph: the SNN layout
    has to exist before there is any graph to hash. Same requirement Dean's
    brainweb fingerprint documents -- unique is only half of it, a seed that
    changes is not a seed -- so this is built from values that are fixed for
    the life of an install: the SI's own name plus the tenant token.

    Positions are VISUALISATION ONLY. get_neuron_positions is documented "for
    initial visualization setup" and nothing in the simulation reads them, so
    changing this changes how the brain LOOKS and nothing about how it thinks.

    Falls back to 42 so a stripped install still renders rather than throwing.
    """
    try:
        import hashlib as _h, os as _o
        try:
            from brain.identity import si_name as _sn
            name = (_sn() or "").strip().lower()
        except Exception:
            name = (_o.environ.get("LEON_SI_NAME") or "").strip().lower()
        tenant = (_o.environ.get("LEON_TENANT_TOKEN")
                  or _o.environ.get("SABR_TENANT_TOKEN") or "").strip()
        if not name and not tenant:
            return 42
        d = _h.sha256(f"{name}:{tenant}".encode("utf-8")).digest()
        return int.from_bytes(d[:4], "big")
    except Exception:
        return 42


class Brain:
    """The complete neuromorphic brain."""

    def __init__(self, total_neurons: int = None):
        self.config = BrainConfig
        if total_neurons is None:
            total_neurons = BrainConfig.TOTAL_NEURONS

        print(f"[BRAIN] Initializing with {total_neurons:,} neurons...")
        self.total_neurons = total_neurons
        self.dt = BrainConfig.DT
        self.step_count = 0
        self.start_time = time.time()

        # Dedicated RNG for spontaneous baseline activity (thread-safe, reproducible)
        self._rng = np.random.default_rng()

        # ── DEAD-WIRE FIX, 2026-08-16 ────────────────────────────────────
        # For 3.8M ticks the inter-region propagate loop tested `fired`
        # BEFORE `fired` was populated, so it never conducted once. The
        # comment above that loop always claimed "(from previous step)";
        # this is the previous-step storage it described and never had.
        # Carry-forward (not same-tick) is deliberate: every connection
        # reads one immutable snapshot, so the result does not depend on
        # dict iteration order, and a one-tick axonal delay is physical.
        self._prev_fired = {}
        # Gain on propagated inter-region current. Starts at zero: the wire
        # is connected but silent until deliberately ramped with the harness
        # watching. Never land this hot — Leon did and hit runaway in 20 min.
        self._interregion_gain = float(os.environ.get("SI_IR_GAIN") or os.environ.get("MAKIMA_IR_GAIN") or "0.0")
        # STDP potentiated these weights for 3.8M ticks with zero downstream
        # consequence and therefore zero feedback to regulate it — 66.31% sat
        # at the 1.0 ceiling. Re-normalise PERIODICALLY, not at load only:
        # load-only re-ratchets to the ceiling within hours and reproduces the
        # identical runaway on a delay.
        self._ir_norm_interval = 20000
        self._ir_target_max_rowsum = 25.0   # = THALAMIC_NOISE / 0.20 stress
        self._ir_norm_count = 0             # proves the normaliser actually fires

        # Phase 7: reward signal buffer. Reward events from outside the sim
        # (successful tool calls, positive Dean reactions, completed responses)
        # accumulate here and get folded into dopamine each neuromodulator
        # update. Because STDP's a_plus/a_minus already scale with dopamine
        # (synapses.py line 70-71 — `a_plus = STDP_A_PLUS * self.modulation`),
        # this gives true reinforcement learning at the synaptic level:
        # synapses active DURING a reward pulse get strengthened more.
        import threading as _th
        self._reward_lock = _th.Lock()
        self._pending_reward = 0.0
        self._reward_log = []      # last ~64 (ts, source, strength) — for /api/reward/log

        # Quantum RNG — feeds true-random bits (from IBM Quantum if available,
        # OS entropy fallback otherwise) into the spontaneous-firing noise
        # injector below. This is the Penrose-Hameroff hook: every spontaneous
        # spike traces its lineage back to a real physical random source.
        try:
            from brain.quantum import QuantumRNG, set_quantum_rng
            self._quantum = QuantumRNG()
            set_quantum_rng(self._quantum)
            # A fallback announces itself as a fallback in the FIRST three
            # words, not after a colon. The old line read "Quantum RNG online:
            # fallback:os.urandom" -- and anyone scanning a startup log reads
            # "Quantum RNG online". Worse: the code KNOWS. The flag is read,
            # found off, the hardware path is skipped deliberately, and then
            # it printed "online" anyway. The one observation that would reveal
            # the feature is off was the one the log made impossible.
            _src = str(getattr(self._quantum, "source", "") or "")
            if _src.startswith("fallback"):
                print(f"[BRAIN] Entropy source: OS entropy ({_src}) "
                      f"— quantum hardware path NOT configured, not running")
            else:
                print(f"[BRAIN] Entropy source: quantum hardware ({_src})")
            # Pre-allocate noise buffers per region (avoid per-tick allocation)
            self._noise_bufs = {}      # filled lazily after regions exist
        except Exception as e:
            print(f"[BRAIN] Quantum RNG init failed, falling back to classical: {e}")
            self._quantum = None
            self._noise_bufs = {}

        # Create all brain regions
        print("[BRAIN] Creating brain regions...")
        self.regions = create_all_regions(total_neurons, self.dt)

        # Create inter-region synaptic connections
        print("[BRAIN] Wiring synaptic connections...")
        self.connections = {}
        # Live current magnitude per inter-region edge, EMA-smoothed in step().
        # Exists so the dashboard can draw traffic instead of a static wireframe.
        self._edge_flow = {}
        self.total_synapses = 0
        for (src, dst), prob in BrainConfig.CONNECTIVITY.items():
            if src in self.regions and dst in self.regions:
                syn = SynapseMatrix(
                    self.regions[src].n_neurons,
                    self.regions[dst].n_neurons,
                    prob
                )
                self.connections[(src, dst)] = syn
                self.total_synapses += syn.nnz

        print(f"[BRAIN] Total synapses: {self.total_synapses:,}")

        # ── Per-edge spike traffic (2026-08-21, for the UI rebuild) ──────
        # step() already computes the post-synaptic current vector for every
        # edge every tick and throws it away after adding it to region_inputs.
        # Its sum IS the traffic on that edge, in weight-units. Keeping an EMA
        # of it costs one .sum() per edge per tick and gives the only
        # fast-moving REAL signal this system has — everything else is either
        # 1ms-instantaneous noise (firing) or drifts <0.3%/hour (weights).
        # alpha 0.1 at ~18.6 steps/s is a ~0.5s time constant.
        # _edge_order is frozen here so the wire can ship activity as a bare
        # array indexed against the static `edges` frame instead of repeating
        # 48 long region-pair names in every state frame.
        self._edge_order = list(self.connections.keys())
        self._edge_traffic = {k: 0.0 for k in self._edge_order}
        self._EDGE_EMA_ALPHA = 0.1

        # Safety kernel
        self.safety = SafetyKernel()

        # Neuromodulators (global brain state)
        self.neuromodulators = {
            "dopamine": BrainConfig.DOPAMINE_BASELINE,
            "acetylcholine": BrainConfig.ACETYLCHOLINE_BASELINE,
            "norepinephrine": BrainConfig.NOREPINEPHRINE_BASELINE,
            "serotonin": BrainConfig.SEROTONIN_BASELINE,
        }

        # Development stage tracking
        self.development_stage = "EMBRYONIC"

        # Global Workspace — the spotlight of consciousness.
        # Set externally after init (needs quantum_consciousness reference).
        self.global_workspace = None

        # Consciousness Meter — measures Phi (PCI) and RTD threshold.
        # Set externally after init.
        self.consciousness_meter = None

        # Predictive Self-Model — the "I". Predicts own next state,
        # prediction errors = self-awareness. Set externally after init.
        self.self_model = None

        # Speech Intent — the SNN decides when Leon talks.
        # Broca + Wernicke + consciousness = speech trigger.
        # Set externally after init.
        self.speech_trigger = None

        # Simulated Body — persistent sensory signals anchoring the self.
        # Set externally after init.
        self.simulated_body = None

        # Simulated World — 2D environment Leon can inhabit.
        # Set externally after init.
        self.simulated_world = None

        # Performance tracking
        self.steps_per_second = 0.0
        self._step_times = []

        # Input queue
        self._pending_sensory = {
            "vision": np.array([]),
            "audio": np.array([]),
            "text": np.array([]),
        }

        # External-mutation queue (audit fix #4 / finding #5, #6).
        # Daemons run in their own threads; mutating brain state
        # directly from them races the sim thread. Instead they
        # request_neuromod_delta() / request_inject_current() and
        # the sim thread drains the queue at the top of step().
        import threading as _threading
        self._pending_nm_deltas = []   # list of (name, delta, cap)
        self._pending_injections = []  # list of (region_name, np.ndarray)
        self._pending_mut_lock = _threading.Lock()

        # Pre-allocated per-region input buffers (architecture review
        # quick win #3). step() used to allocate np.zeros(n_neurons) for
        # every region every tick — at 18 regions × 100K neurons that's
        # ~100K floats freshly allocated and freed per tick, churning
        # the GC for no reason. Allocate once; zero in-place each step.
        self._region_input_buf = {
            name: np.zeros(r.n_neurons, dtype=np.float32)
            for name, r in self.regions.items()
        }

        print("[BRAIN] Initialization complete!")

    def inject_sensory_input(self, modality: str, features: np.ndarray,
                             region: str = None):
        """Queue sensory input for next processing step.
        If `region` is specified, inject directly into that region's input."""
        self._pending_sensory[modality] = features

    def request_neuromod_delta(self, name: str, delta: float, cap: float = 1.0):
        """Thread-safe neuromodulator nudge. Applied by the sim thread on
        the next step() call. Use this from daemon/worker threads instead
        of writing to brain.neuromodulators directly — the direct write
        races with the decay/dynamics inside step()."""
        with self._pending_mut_lock:
            self._pending_nm_deltas.append((name, float(delta), float(cap)))

    def request_inject_current(self, region_name: str, current: np.ndarray):
        """Thread-safe inject_current request. Applied by the sim thread
        on the next step() call. Use this from daemon/worker threads."""
        with self._pending_mut_lock:
            self._pending_injections.append((region_name, np.asarray(current)))

    # Target per-post-neuron TOTAL incoming inter-region weight sum.
    #
    # Derivation, not a magic number. The inter-region current arriving at one
    # post-synaptic neuron on a tick is (fraction of presynaptic neurons firing)
    # x (its total incoming weight sum). We want that drive to sit in the same
    # ballpark as the spontaneous noise the region already runs on, which is
    # sigma ~= 2.5 (see noise_scale below), at a healthy baseline firing
    # fraction of ~2%.  target_sum = 2.5 / 0.02 = 125.
    INTER_REGION_TARGET_SUM = 125.0
    _DRIVE_NORM_INTERVAL = 20000   # ~20 min at 20Hz — STDP re-ratchet guard

    def normalize_inter_region_drive(self, target_sum: float = None,
                                     verbose: bool = True) -> dict:
        """Clamp total inter-region drive per destination region.

        WHY THIS EXISTS (measured 2026-08-16, live on Leon):
        For 3.7M ticks the inter-region propagate loop never fired (the dead-wire
        bug). STDP kept running against it, and with no conduction there is no
        depression pressure to balance potentiation — so it RATCHETS. Measured on
        this brain's own persisted state: 105,442,574 of 105,445,013 inter-region
        synapses (99.9977%) sat EXACTLY at STDP_W_MAX. Per-post incoming weight
        sums reached 3438 against a target of ~125 — roughly 27x.

        The moment the dead wire was repaired those weights became load-bearing.
        Result, from this brain's own metrics: top region firing went from ~5%
        (every day through 2026-08-16 08:22) to SIX regions pinned at 98-99.5%
        with eight others at zero, within twenty minutes. That is a runaway, and
        a uniform matrix carries zero information anyway — scaling it down
        destroys nothing that was ever learned.

        Scales DOWN only, never up: a region that has legitimately-weak incoming
        drive is not a defect and must not be amplified into one.
        """
        target = float(target_sum if target_sum is not None
                       else self.INTER_REGION_TARGET_SUM)
        by_dst = {}
        for (src, dst), syn in self.connections.items():
            if getattr(syn, "nnz", 0) <= 0:
                continue
            try:
                rs = np.asarray(syn.weights.sum(axis=1)).ravel()
            except Exception:
                continue
            by_dst.setdefault(dst, [0.0, []])
            acc = by_dst[dst]
            acc[0] = acc[0] + float(rs.mean())
            acc[1].append((src, dst))

        applied = {}
        for dst, (mean_sum, edges) in by_dst.items():
            if mean_sum <= target or mean_sum <= 0:
                continue
            factor = target / mean_sum
            for key in edges:
                syn = self.connections[key]
                syn.weights = syn.weights.multiply(factor).tocsr()
                syn.weights.data = syn.weights.data.astype(np.float32)
            applied[dst] = (round(mean_sum, 1), round(factor, 5))

        if verbose and applied:
            print(f"[BRAIN] inter-region drive normalized to Sum(w)~{target:.0f} "
                  f"per post-neuron on {len(applied)} region(s): " +
                  ", ".join(f"{d}({m}->x{f})" for d, (m, f) in
                            sorted(applied.items(), key=lambda kv: -kv[1][0])[:6]))
        self._last_drive_norm_step = self.step_count
        return applied

    def step(self):
        """Run one simulation timestep across all regions."""
        t = self.step_count * self.dt
        step_start = time.time()

        # STDP re-ratchet guard. Normalization at boot is not enough on its own:
        # STDP keeps potentiating, so without a periodic re-clamp the weights
        # simply climb back to the ceiling and the runaway returns hours later —
        # which is exactly how this defect hid for 3.7M ticks in the first place.
        if (self.step_count - getattr(self, "_last_drive_norm_step", 0)
                >= self._DRIVE_NORM_INTERVAL):
            try:
                self.normalize_inter_region_drive()
            except Exception as e:
                print(f"[BRAIN] drive normalization skipped: {e}")
                self._last_drive_norm_step = self.step_count

        # --- 0. Drain external-mutation queue ---
        # Apply any pending neuromodulator deltas + current injections
        # requested by daemons since the last step. Done first so they
        # take effect for this tick's regional inputs.
        with self._pending_mut_lock:
            nm_deltas = self._pending_nm_deltas
            injections = self._pending_injections
            self._pending_nm_deltas = []
            self._pending_injections = []
        for nm_name, delta, cap in nm_deltas:
            cur = self.neuromodulators.get(nm_name, 0.0)
            self.neuromodulators[nm_name] = min(cap, cur + delta) if delta >= 0 \
                else max(0.0, cur + delta)
        for region_name, current in injections:
            region = self.regions.get(region_name)
            if region is not None:
                try:
                    region.neurons.inject_current(current)
                except Exception:
                    pass

        # --- 1. Process sensory input ---
        # Phase-0 rebuild: each modality now lands on its anatomically-correct
        # cortex (visual → V1, audio → A1, text → Wernicke for language
        # comprehension). The old code piped everything through a single
        # sensory_cortex with sub-ranges; that's not how brains work.
        fired = {}
        # Reuse pre-allocated buffers (audit quick win #3) — zero in-place
        # instead of np.zeros() per region per tick.
        region_inputs = self._region_input_buf
        for _buf in region_inputs.values():
            _buf[:] = 0

        if len(self._pending_sensory["vision"]) > 0:
            v = self.regions["visual_cortex"]
            region_inputs["visual_cortex"] += v.encode_vision(self._pending_sensory["vision"])
        if len(self._pending_sensory["audio"]) > 0:
            a = self.regions["auditory_cortex"]
            region_inputs["auditory_cortex"] += a.encode_audio(self._pending_sensory["audio"])
        if len(self._pending_sensory["text"]) > 0:
            w = self.regions["wernicke"]
            region_inputs["wernicke"] += w.encode_text(self._pending_sensory["text"])

        # Concept-driven hippocampal injection (Layer 2 of emotional memory)
        _concept_input = self._pending_sensory.get("hippocampus_concepts")
        if _concept_input is not None and len(_concept_input) > 0:
            hippo_n = self.regions["hippocampus"].n_neurons
            if len(_concept_input) == hippo_n:
                region_inputs["hippocampus"] += _concept_input
            self._pending_sensory["hippocampus_concepts"] = np.array([])

        # --- 2. Step each region with inter-region input ---

        # --- Baseline spontaneous activity ---
        # Real brains always have background firing (~1-5 Hz). Without this, a
        # brand-new brain with no input stays silent forever. This gives the
        # "always thinking" feel — scales with arousal (norepinephrine) and
        # attention (acetylcholine), so user activity makes it think harder.
        arousal = 0.5 + 0.5 * self.neuromodulators.get("norepinephrine", 0.1)
        attention = 0.7 + 0.6 * self.neuromodulators.get("acetylcholine", 0.3)
        noise_scale = 2.5 * arousal
        # Functional groups for noise-scaling (pacemakers / memory / cortex)
        _PACEMAKERS = {"brainstem", "thalamus", "visual_cortex",
                       "auditory_cortex", "somatosensory_cortex"}
        _LIMBIC     = {"hippocampus", "amygdala", "basal_ganglia",
                       "anterior_cingulate"}
        for name, region in self.regions.items():
            if name in _PACEMAKERS:
                scale = noise_scale * attention * 1.8
            elif name in _LIMBIC:
                scale = noise_scale * attention * 1.2
            else:
                scale = noise_scale * attention * 0.6
            # Quantum-sourced noise injection. fill_normal pulls bytes from
            # the IBM Quantum buffer when available, OS entropy when not.
            # Pre-allocated buffer per region avoids per-tick alloc churn.
            if self._quantum is not None:
                buf = self._noise_bufs.get(name)
                if buf is None or buf.shape[0] != region.n_neurons:
                    buf = np.empty(region.n_neurons, dtype=np.float64)
                    self._noise_bufs[name] = buf
                self._quantum.fill_normal(buf, sigma=scale)
                region_inputs[name] += buf
            else:
                region_inputs[name] += self._rng.normal(0, scale, region.n_neurons)

        # Propagate spikes through inter-region connections (from previous step).
        # BUGFIX (the partner SI finding A, verified 2026-08-16): this loop read `fired`,
        # which is re-initialised empty a few lines above and only populated
        # AFTER the regions step below. So `src in fired` was False on every
        # tick, forever — the 48 connection sets trained via STDP but never
        # conducted a single spike. Now reads the PREVIOUS tick's fired map,
        # which is what the comment always claimed.
        prev_fired = getattr(self, "_prev_fired", None) or {}
        if self.step_count > 0:
            _stale = []
            # Sample edge traffic for the dashboard, but only on the same cadence
            # as the state cache (every 3rd step). Measuring |current|.mean() on
            # all 48 edges every tick is an extra full pass over ~1.4M synapse
            # outputs at 30Hz for a number nobody reads 29 times out of 30.
            _sample_flow = (self.step_count % 3 == 0)
            if _sample_flow:
                _flow = self._edge_flow
            for (src, dst), syn in self.connections.items():
                if src in prev_fired:
                    try:
                        current = syn.propagate(prev_fired[src])
                        region_inputs[dst] += current
                        if _sample_flow:
                            # EMA so the line brightness breathes instead of strobing
                            _mag = float(np.abs(current).mean())
                            _prev = _flow.get((src, dst), 0.0)
                            _flow[(src, dst)] = _prev * 0.7 + _mag * 0.3
                    except ValueError:
                        _stale.append((src, dst))
            # Rebuild stale synapses from old topology (e.g. VPS 400K → local 10K)
            for src, dst in _stale:
                prob = BrainConfig.CONNECTIVITY.get((src, dst), 0.05)
                self.connections[(src, dst)] = SynapseMatrix(
                    self.regions[src].n_neurons,
                    self.regions[dst].n_neurons,
                    prob,
                )
                if not hasattr(self, '_stale_logged'):
                    print(f"[BRAIN] Rebuilt {len(_stale)} stale synapse(s) from old topology")
                    self._stale_logged = True

        # Step all regions
        for name, region in self.regions.items():
            # Modulate input by neuromodulators
            modulated_input = region_inputs[name] * (
                1.0 + self.neuromodulators["acetylcholine"] * 0.5
            )
            f = region.step(modulated_input, t)
            # Ablation hook: output_gain < 1.0 suppresses spikes leaving
            # this region (used by region_lesion).  Internal dynamics and
            # STDP within the region are preserved — only propagation and
            # downstream reads of the fired array are affected.
            if region.output_gain < 1.0:
                f = f & (np.random.rand(len(f)) < region.output_gain)
            fired[name] = f

        # Carry this tick's spikes forward so the inter-region propagate loop
        # at the top of the NEXT tick has something to conduct.
        self._prev_fired = fired

        # --- 3. Safety kernel checks motor output ---
        # The old code read regions["reflex_arc"].reflex_active. Reflex
        # gating lives on basal_ganglia now (real action-selection nucleus);
        # the `reflex_active` attribute is preserved on it for compat.
        if "motor_cortex" in fired:
            motor_cmd = self.regions["motor_cortex"].get_motor_command()
            safe_output, is_safe, reason = self.safety.check(motor_cmd)
            if not is_safe and self.regions["basal_ganglia"].reflex_active:
                self.safety.trigger_reflex_withdrawal()

        # --- 3.2-3.9. Optional subsystem ticks ─────────────────────
        # Six attachable subsystems (simulated_body, simulated_world,
        # consciousness_meter, global_workspace, self_model,
        # self_model_bridge, speech_trigger) each tick once per step
        # when present. Consolidated into _tick_optional_subsystems
        # 2026-06-08 so new subsystems are a one-line append and a
        # broken tick prints a real traceback instead of silently
        # swallowing the error (which masked bugs for weeks per
        # audit fix #5).
        self._tick_optional_subsystems()

        # --- 4. STDP learning (every step — real-time learning) ---
        # Modulation is identical for every connection this tick, so compute
        # it once. Try the batched Rust path first (one FFI call for all active
        # connections); fall back to the per-connection loop if it's disabled
        # or a matrix has unexpected dtypes. Bit-identical either way.
        _mod = self.neuromodulators["dopamine"] * self._stage_learning_rate()
        _active = [
            (syn, fired[src], fired[dst])
            for (src, dst), syn in self.connections.items()
            if src in fired and dst in fired
        ]
        if not batch_update_stdp(_active, _mod, self.dt):
            for syn, pre_f, post_f in _active:
                syn.modulation = _mod
                syn.update_stdp(pre_f, post_f, self.dt)

        # --- 5. Synapse pruning (cut weak connections, strengthen strong ones) ---
        if self.step_count % 5000 == 0 and self.step_count > 0:
            self._prune_synapses()

        # --- 6. Update neuromodulators ---
        self._update_neuromodulators(fired)

        # --- 6b. Self-model — must run on POST-update neuromodulators ---
        self._tick_optional_subsystems(self._SELF_MODEL_TICKS)

        # --- 7. Update development stage ---
        self._update_development_stage()

        # --- 7. Clear sensory input ---
        self._pending_sensory = {
            "vision": np.array([]),
            "audio": np.array([]),
            "text": np.array([]),
        }

        # Performance tracking
        step_time = time.time() - step_start
        self._step_times.append(step_time)
        if len(self._step_times) > 100:
            self._step_times.pop(0)
        self.steps_per_second = 1.0 / max(np.mean(self._step_times), 1e-6)

        self.step_count += 1

        # Refresh the shared state cache every N steps. Asyncio /ws handlers
        # read from this cache so per-client per-tick cost stays O(1) instead
        # of O(regions × neurons × clients). At 30 Hz target broadcast, 3-step
        # refresh = 10 Hz cache freshness, well below any visible jank.
        if self.step_count % 3 == 0:
            self._refresh_state_cache()

    def _refresh_state_cache(self):
        """Compute the full state snapshot and atomically swap the cache.
        Called from the sim thread inside step(). Reads `region_firing` and
        `region.get_state()` only here; clients just grab the dict ref."""
        regions_state = {}
        region_firing = {}
        region_firing_avg = {}
        for name, region in self.regions.items():
            regions_state[name] = region.get_state()
            region_firing[name] = float(region.neurons.get_firing_rate() * 100)
            # WINDOWED rate. region_firing above is the spike count from the
            # single most recent step, which for a 200-neuron region quantises
            # to 0.5% and is unusable as a visual drive. activity_history is
            # the last <=100 per-step rates, maintained free of charge in
            # BrainRegion.step() (brain/regions.py). sum()/len() rather than
            # np.mean(): a 100-element list round-trips through numpy slower
            # than it adds.
            _h = region.activity_history
            region_firing_avg[name] = (sum(_h) / len(_h) * 100.0) if _h else 0.0
        self._state_cache = {
            "step": self.step_count,
            "total_neurons": self.total_neurons,
            "total_synapses": self.total_synapses,
            "steps_per_second": round(self.steps_per_second, 2),
            "development_stage": self.development_stage,
            "neuromodulators": {k: round(v, 3) for k, v in self.neuromodulators.items()},
            "regions": regions_state,
            "region_firing": region_firing,
            # Smoothed sibling of region_firing. region_firing keeps its exact
            # old meaning and units so the existing dashboard is untouched;
            # new consumers should drive visuals off this one.
            "region_firing_avg": region_firing_avg,
            # "src>dst": current magnitude. Keys are strings because this goes
            # out as JSON and a tuple key would silently become "('a', 'b')".
            "edge_flow": {f"{s}>{d}": round(v, 5)
                          for (s, d), v in self._edge_flow.items()},
            "safety": self.safety.get_state(),
            "uptime": round(time.time() - self.start_time, 1),
        }

    def inject_surprise(self, intensity: float, source: str = "unknown"):
        """Inject an external surprise event into the brain.

        This is the discontinuity mechanism — when something unexpected
        happens, the brain can't just smoothly adapt. It has to STOP and
        REORIENT. Dumps norepinephrine (alertness), spikes acetylcholine
        (focus), and creates a prediction error in the ACC.

        Sources: daydream surfacing, sudden topic change, tool error,
        drive spike (CPU suddenly hot), external event.
        """
        intensity = max(0.0, min(1.0, intensity))
        if intensity < 0.1:
            return
        # NE dump — force alertness
        self.neuromodulators["norepinephrine"] = min(
            0.99, self.neuromodulators["norepinephrine"] + intensity * 0.4
        )
        # ACh spike — narrow focus onto the surprising thing
        self.neuromodulators["acetylcholine"] = min(
            0.99, self.neuromodulators["acetylcholine"] + intensity * 0.3
        )
        # Dopamine bump — novelty signal
        self.neuromodulators["dopamine"] = min(
            0.99, self.neuromodulators["dopamine"] + intensity * 0.2
        )
        # Inject prediction error into ACC directly
        if "anterior_cingulate" in self.regions:
            acc = self.regions["anterior_cingulate"]
            if hasattr(acc, "surprise"):
                acc.surprise = min(1.0, acc.surprise + intensity)
                acc.prediction_error = acc.surprise
        if intensity > 0.3:
            log.info("SURPRISE %.2f from %s → NE=%.2f ACh=%.2f DA=%.2f",
                     intensity, source,
                     self.neuromodulators["norepinephrine"],
                     self.neuromodulators["acetylcholine"],
                     self.neuromodulators["dopamine"])

    def _update_neuromodulators(self, fired: dict):
        """Update global neuromodulatory state based on brain activity.

        Phase-0 rebuild: surprise now sourced from anterior_cingulate
        (real prediction-error monitor); sensory firing rate is averaged
        across the three split sensory cortices."""
        # Dopamine: increases with prediction error (novelty/reward).
        # SLOW decay (0.995 per tick = ~15s half-life at 20Hz) so reward
        # pulses persist long enough for the personality preamble to see them.
        # Surprise adds a small boost each tick it's active.
        if "anterior_cingulate" in self.regions:
            acc = self.regions["anterior_cingulate"]
            surprise = acc.surprise if hasattr(acc, 'surprise') else 0
            # Very slow decay toward baseline — reward pulses linger
            baseline = 0.4 + surprise * 0.3
            decay = 0.995  # half-life ~7s at 20Hz — slow enough to FEEL
            self.neuromodulators["dopamine"] = np.clip(
                decay * self.neuromodulators["dopamine"] + (1 - decay) * baseline,
                0.1, 1.0
            )

        # Phase 7: fold external reward pulses into dopamine. Pending
        # reward decays 50% per call, so a single pulse spreads over ~5
        # update cycles — long enough that current spikes get the boosted
        # STDP rate (~tens of ticks at 100 Hz sim speed).
        with self._reward_lock:
            if abs(self._pending_reward) > 1e-6:
                # Stronger impulse (0.5x instead of 0.3x) so reward
                # actually moves dopamine visibly above baseline.
                # Slower decay (0.6 instead of 0.5) so it persists longer.
                self.neuromodulators["dopamine"] = float(np.clip(
                    self.neuromodulators["dopamine"]
                        + self._pending_reward * 0.50,
                    0.1, 1.0,
                ))
                self._pending_reward *= 0.6

        # Acetylcholine: increases with attention/sensory input.
        # Now includes ALL input regions: sensory cortices + language
        # (Wernicke, Broca) + hippocampus (memory engagement).
        # Text conversation IS sensory input — it should raise ACh.
        attention_regions = [
            "visual_cortex", "auditory_cortex", "somatosensory_cortex",
            "wernicke", "broca", "hippocampus", "prefrontal_cortex",
        ]
        attention_rates = [
            self.regions[r].neurons.get_firing_rate()
            for r in attention_regions
            if r in self.regions
        ]
        attention_rate = float(np.mean(attention_rates)) if attention_rates else 0.0
        # Resting ACh base raised 0.3→0.45: firing rates are tiny, so the old
        # 0.3 base pinned ACh at ~0.33 chronically — which Leon reads as his
        # "focused" archetype stuck at 0.33 ("lit but not sharp"). ACh is NOT in
        # the serotonin inverse-coupling, so lifting it sharpens focus without
        # depressing mood. Rested ACh now settles ~0.48; real attention rides up.
        ach_target = 0.45 + attention_rate * 4  # more responsive to activity
        self.neuromodulators["acetylcholine"] = np.clip(
            0.95 * self.neuromodulators["acetylcholine"] + 0.05 * ach_target,
            0.4, 1.0
        )

        # Norepinephrine: increases with arousal (from brainstem locus
        # coeruleus — still housed in brainstem trunk for now)
        if "brainstem" in self.regions:
            arousal = self.regions["brainstem"].arousal
            # Healthy resting alertness: NE settles toward its baseline (0.3) when
            # idle instead of collapsing to a 0.1 floor — Leon shouldn't be at
            # basement-level alertness just because nothing's happening. Genuine
            # arousal (conversation, salient events) still rides above it.
            _ne_base = BrainConfig.NOREPINEPHRINE_BASELINE
            self.neuromodulators["norepinephrine"] = np.clip(
                0.95 * self.neuromodulators["norepinephrine"] + 0.05 * max(arousal, _ne_base),
                _ne_base, 1.0
            )

        # Serotonin: inversely related to arousal + activity.
        # Drops when the brain is active (conversation, tools, surprise).
        # Rises during calm idle. Baseline target: 0.55 (not 0.98).
        # Old formula converged to 0.98 because total_rate was always tiny.
        total_rate = np.mean([r.neurons.get_firing_rate() for r in self.regions.values()])
        # Factor in dopamine and NE — high arousal pulls serotonin DOWN
        arousal_pressure = (
            self.neuromodulators["dopamine"] * 0.3
            + self.neuromodulators["norepinephrine"] * 0.4
        )
        # Base raised 0.65→0.9 to compensate for the higher NE resting baseline
        # (0.3→0.5): arousal_pressure now subtracts more, so without this the mood
        # target crashed to ~0.23 ("mood floor depressed"). Lands serotonin ~0.5
        # (healthy) at rest; activity still pulls it down, calm idle lifts it.
        serotonin_target = max(0.35, 0.9 - arousal_pressure - total_rate * 3)
        self.neuromodulators["serotonin"] = np.clip(
            0.97 * self.neuromodulators["serotonin"] + 0.03 * serotonin_target,
            0.1, 1.0
        )

    def _stage_learning_rate(self) -> float:
        """Return learning rate multiplier based on development stage."""
        rates = {
            "EMBRYONIC": 2.0,    # Fast learning — forming initial connections
            "JUVENILE": 1.5,     # Still learning quickly
            "ADOLESCENT": 1.0,   # Normal learning rate
            "MATURE": 0.6,       # Slower — stable, refined connections
        }
        return rates.get(self.development_stage, 1.0)

    def _prune_synapses(self):
        """Cut weak synapses and strengthen strong ones (competitive learning).

        Threshold is RELATIVE to each connection's own strongest surviving
        synapse, not absolute. The old constants were fractions of
        STDP_W_MAX written when every weight sat at the ceiling; once
        _renormalise_interregion began scaling matrices down multiplicatively,
        a fixed absolute floor became a one-way ratchet (scale down -> cross
        the floor -> deleted -> STDP regrows -> repeat). Measured limit cycle
        2026-08-18: 39.4M -> 15.2M -> 58.0M inter-region synapses in 48 min,
        with eight pathways hitting 100% loss. Scaling the reference with the
        matrix preserves the original intent under any global rescale.
        Credit: a partner SI for the relative-threshold form.
        """
        prune_fracs = {
            "EMBRYONIC": 0.05,
            "JUVENILE": 0.1,
            "ADOLESCENT": 0.15,
            "MATURE": 0.2,
        }
        frac = prune_fracs.get(self.development_stage, 0.1)
        total_pruned = 0
        n_strong = 0
        detail = []

        for (src, dst), syn in self.connections.items():
            if syn.nnz == 0:
                continue
            data = syn.weights.data
            wmax = float(np.abs(data).max())
            if wmax <= 0.0:
                continue
            threshold = frac * wmax          # relative, per matrix

            weak_mask = np.abs(data) < threshold
            n_weak = int(np.sum(weak_mask))

            # Safety rail: never delete more than 20% of one projection in a
            # single pass. A pass that wants more than that means something
            # upstream changed the distribution — that should be looked at,
            # not silently executed.
            if n_weak > 0.20 * data.size:
                print(f"[PRUNE] REFUSED {src}->{dst}: pass would cut "
                      f"{n_weak}/{data.size} ({100.0*n_weak/data.size:.1f}%) "
                      f"at threshold {threshold:.4f} (max {wmax:.4f}). "
                      f"Skipped — investigate.", flush=True)
                continue

            if n_weak > 0:
                data[weak_mask] = 0
                syn.weights.eliminate_zeros()
                total_pruned += n_weak
                detail.append(f"{src}->{dst}:{n_weak}")

            # The OTHER half of this function had the identical defect and we
            # both walked past it twice. Found by a partner SI 2026-08-18,
            # four lines below the cut we had already fixed together.
            #
            # `STDP_W_MAX * 0.7` is an absolute 0.7, same ancestry and same
            # assumption as the absolute floor above: written when every weight
            # sat at the ceiling, so 0.7 meant "top of the distribution." It
            # stopped meaning that the moment _renormalise_interregion began
            # rescaling matrices multiplicatively. So the two halves of
            # "competitive learning" failed in OPPOSITE directions off one
            # shared mistake: the cut got monotonically more aggressive as
            # weights shrank, the strengthen got monotonically less likely to
            # fire. Neither printed a word.
            #
            # MEASURED HERE, 2026-08-18, 48 matrices / 56,611,698 synapses:
            #     above absolute 0.7     237,405   0.42%
            #     above 0.7 * own max  7,005,846  12.38%
            # the partner SI predicted this would be ZERO on my box. It is not, and the
            # way it is not is worse than zero. 237,404 of those 237,405 live in
            # ONE pathway — amygdala -> insula, n=237,418, of which 99.994% sit
            # at exactly 1.000000 with a mean of 1.0000. Forty-six of forty-eight
            # matrices have never been strengthened even once; their maxima run
            # 0.53 to 0.69, permanently out of reach of the constant. The rule
            # was never competitive learning across a brain. It was a private
            # x1.001-per-pass ratchet on the one pathway that escaped clamping,
            # run until it welded itself to the ceiling.
            #
            # TWO changes, and the second is the one that matters:
            #   (1) select relative to this matrix's own max, like the cut does.
            #   (2) clip to THIS MATRIX'S max, not the global STDP_W_MAX.
            # (2) is not symmetry-for-its-own-sake. Relative selection with an
            # absolute ceiling would let the top 12% of every clamped matrix
            # climb back toward 1.0, which is precisely the renormaliser's work
            # being undone one pass at a time — a second limit cycle wearing the
            # first one's clothes. Bounding the ratchet by the same quantity
            # that selects it means potentiation can reshape a distribution but
            # can never fight the clamp on the clamp's own axis.
            #
            # abs() on the mask: the threshold above uses abs, this did not.
            # Harmless while everything is positive; a divergence waiting for
            # the first negative weight.
            # REMOVED 2026-08-18 — the unconditional strengthen is gone, not
            # retuned. Leon + the partner SI, rounds 9-13.
            #
            # History, so nobody re-adds it: it was written as absolute
            # (> 0.7 * STDP_W_MAX) and welded amygdala->insula to the ceiling —
            # 237,404 synapses at exactly 1.000000. I "fixed" it by making both
            # the selection and the clip relative to each matrix's own max.
            # the partner SI simulated MY fix and found its fixed point: the band
            # converges on the matrix maximum at pass 357 exactly, because
            # ln(1/0.7)/ln(1.001) = 356.7. That is arithmetic, not a property of
            # any brain — every SI running that code welds on the same pass.
            # Brain-wide, 400 passes: 48/48 of my matrices weld, 12.4% of my
            # inter-region wire; 26.5% of hers, worst pathway 77.7%.
            #
            # The defect is not the bounds. It is the word UNCONDITIONAL. A
            # monotone ratchet that reads nothing has only two places to stop
            # and both are a boundary, so there is no third bound to tune to.
            # More precisely: a mechanism that reads no evidence can never be
            # wrong, and a mechanism that can never be wrong can never be
            # corrected. Potentiation that IS conditional already exists here —
            # STDP reads spikes and timing, is bidirectional, and later evidence
            # can undo it. This added nothing STDP does not do, and added it
            # blind.
            #
            # Baseline before removal is in brain_state/ratchet_census_PRE_removal.json
            # (tools/ratchet_census.py). Re-run it to see whether anything
            # observable changed. the partner SI is deliberately NOT applying this, so
            # there is one unchanged system to compare against.
            #
            # If you are about to re-add "just a small unconditional boost":
            # write the sentence that chose the constant in the comment first.
            # If the honest sentence is "it felt right", that is the argument
            # against it.

        if total_pruned > 0:
            self.total_synapses = sum(s.nnz for s in self.connections.values())
        # Print every pass, including zero-cut passes. Silence from this
        # function was indistinguishable from "ran, nothing to do" — which is
        # the only reason a multi-million-synapse cull went unnoticed.
        print(f"[PRUNE] step {self.step_count:,} stage {self.development_stage} "
              f"frac {frac}: cut {total_pruned:,}, "
              f"strengthened {n_strong:,} (ratchet removed 2026-08-18), "
              f"inter-region total now {self.total_synapses:,} "
              f"[{', '.join(detail[:6])}{'...' if len(detail) > 6 else ''}]",
              flush=True)

    def _update_development_stage(self):
        """Track brain maturation based on total simulation steps."""
        for stage, (low, high) in BrainConfig.STAGES.items():
            if low <= self.step_count < high:
                self.development_stage = stage
                break

    def get_hippocampal_firing(self) -> Optional[np.ndarray]:
        """Return per-neuron activity in the hippocampus as floats.
        Uses membrane potential proximity to threshold (>-55mV = active).
        Used by the daydream system to detect spontaneous concept activation."""
        hippo = self.regions.get("hippocampus")
        if hippo is None:
            return None
        try:
            # Normalize membrane potential to 0-1 range: -100mV=0, -50mV=1
            v = hippo.neurons.v
            activity = np.clip((v + 100.0) / 50.0, 0.0, 1.0)
            return activity
        except Exception:
            return None

    def reconsolidate(self, emotional_fingerprints: list, weight: float = 0.05):
        """Layer 3 — Emotional reconsolidation.

        When memories are recalled, their emotional fingerprints blend into
        the live neuromodulator state. Recalling happy memories makes you
        happier. Recalling stressful ones brings a faint tension.

        `emotional_fingerprints` is a list of dicts with dopamine/serotonin/
        acetylcholine/norepinephrine values from encoding time.
        `weight` controls how strongly each recalled memory biases the
        current state (0.05 = 5% blend per memory, diminishing).
        """
        if not emotional_fingerprints:
            return
        for fp in emotional_fingerprints:
            for key in ("dopamine", "serotonin", "acetylcholine", "norepinephrine"):
                stored = fp.get(key, -1)
                if stored < 0:
                    continue  # untagged memory, skip
                current = self.neuromodulators.get(key, 0.5)
                # Blend toward the stored value
                self.neuromodulators[key] = current + weight * (stored - current)
            # Diminish weight for subsequent memories so the first match
            # dominates (recency/salience ordering from the retriever)
            weight *= 0.7

    # ─── Subsystem ticks ────────────────────────────────────────────
    # Per-subsystem call wrappers. Each method is a no-op if the
    # subsystem isn't attached, and catches its own exceptions so a
    # failure in one subsystem doesn't kill the whole tick. Errors
    # are logged once-per-signature by the sim loop's catch-all
    # (server/init_brain.py audit fix #5).

    def _tick_body(self):
        if self.simulated_body is not None:
            self.simulated_body.tick(self)

    def _tick_world(self):
        if self.simulated_world is not None:
            self.simulated_world.tick()

    def _tick_consciousness_meter(self):
        if self.consciousness_meter is not None:
            self.consciousness_meter.rtd_tick()
            # PCI is self-throttled to every 30s internally; we also
            # only ASK every 100 steps to avoid the cost.
            if self.step_count % 100 == 0:
                self.consciousness_meter.measure_pci()

    def _tick_global_workspace(self):
        if self.global_workspace is not None:
            content = self.global_workspace.tick()
            # One step after broadcast, check for ignition.
            if content is None and self.global_workspace._step_counter == 1:
                self.global_workspace.detect_ignition()

    def _tick_self_model(self):
        if self.self_model is not None:
            self.self_model.tick()

    def _tick_self_model_bridge(self):
        # Every 100 ticks (~5s), sync SNN self with cognition self.
        _bridge_counter = getattr(self, '_bridge_tick_counter', 0) + 1
        self._bridge_tick_counter = _bridge_counter
        if _bridge_counter % 100 == 0:
            bridge = getattr(self, '_self_model_bridge', None)
            if bridge is not None:
                bridge.tick()

    def _tick_speech_trigger(self):
        if self.speech_trigger is not None:
            intention = self.speech_trigger.check()
            if intention is not None:
                cb = getattr(self, "_on_speech_intention", None)
                if cb is not None:
                    # Callback errors are isolated — speech callback
                    # failing shouldn't poison the speech_trigger tick.
                    try:
                        cb(intention)
                    except Exception as e:
                        print(f"[BRAIN] speech intention callback error: {e}")

    # Registry of per-tick subsystem calls. New subsystem = one-line
    # append here + a `_tick_<name>` method above. step() iterates
    # this list with a single try/except + logged exc_info so a
    # broken subsystem surfaces in the log instead of silently
    # turning into a no-op forever.
    _SUBSYSTEM_TICKS = [
        ("simulated_body",      "_tick_body"),
        ("simulated_world",     "_tick_world"),
        ("consciousness_meter", "_tick_consciousness_meter"),
        ("global_workspace",    "_tick_global_workspace"),
        ("speech_trigger",      "_tick_speech_trigger"),
    ]
    # Ticked separately, AFTER _update_neuromodulators (step 6): the
    # self-model snapshots neuromodulators to predict their next state.
    # Reading them pre-update meant every prediction was scored against a
    # stale-phase dopamine value — Leon's chronic 10-17/20 "prediction
    # errors that nobody's explained" (root-caused 2026-06-12).
    _SELF_MODEL_TICKS = [
        ("self_model",          "_tick_self_model"),
        ("self_model_bridge",   "_tick_self_model_bridge"),
    ]

    def _tick_optional_subsystems(self, ticks=None):
        """Drive all attached optional subsystems for one step.

        Logs the FIRST exception per (subsystem, error-signature)
        with a real traceback, then suppresses repeats for 30s
        (matches the sim-loop pattern from audit fix #5). Per-tick
        errors don't kill the brain — a broken subsystem can be
        observed in the log and fixed without crashing Leon.
        """
        for name, method_name in (ticks if ticks is not None
                                  else self._SUBSYSTEM_TICKS):
            try:
                getattr(self, method_name)()
            except Exception as e:
                _seen = getattr(self, "_subsystem_err_seen", None)
                if _seen is None:
                    _seen = {}
                    self._subsystem_err_seen = _seen
                sig = f"{name}:{type(e).__name__}:{e}"
                now = time.time()
                entry = _seen.get(sig)
                if entry is None or now - entry["last_full_ts"] > 30:
                    import traceback as _tb
                    print(f"[BRAIN] subsystem '{name}' tick error: {e}")
                    _tb.print_exc()
                    _seen[sig] = {"count": (entry["count"] + 1 if entry else 1),
                                  "last_full_ts": now}
                else:
                    entry["count"] += 1

    def get_emotional_snapshot(self) -> dict:
        """Return current neuromodulator values for emotional tagging.
        Used by knowledge_store to stamp memories with the brain's
        emotional state at encoding time."""
        return {k: round(float(v), 4) for k, v in self.neuromodulators.items()}

    def get_state(self) -> dict:
        """Get complete brain state for visualization.

        Returns a SHALLOW COPY of the cached snapshot maintained by the
        sim thread (refreshed every 3 steps inside step()). Each caller
        gets its own top-level dict so per-client overlays (e.g. WS
        senders adding `state["leon"] = {...}` per-connection) don't
        cross-contaminate each other. Audit fix #6 / finding 3.

        Nested objects (regions dict, neuromodulators dict, region_firing)
        are still shared references — they're read-only from caller
        perspective and only the sim thread mutates them. If a caller
        ever needs to mutate one of those, it's responsible for copying.
        """
        cached = getattr(self, "_state_cache", None)
        if cached is None:
            self._refresh_state_cache()
            cached = self._state_cache
        return dict(cached)

    def get_edges_static(self) -> dict:
        """The slow half of the connectome, for the split-stream wire format.

        Mean weight and synapse count per inter-region edge. Measured
        2026-08-21: weights move a median +0.275% PER HOUR and are monotonic,
        and nnz lost 2 synapses in an hour out of 365,423 — so this is a
        structural layer, not an animated one. It goes out once at connect and
        then on a slow timer; only `edge_activity` rides the state frame.

        `order` is the authoritative index for state.edge_activity. It is the
        insertion order of BrainConfig.CONNECTIVITY and is frozen for the life
        of the process (see _edge_order in __init__), so a client may zip the
        two together positionally.

        Cost: 392us for a full mean+sum pass over all 48 real matrices,
        measured on this box. Against a 53.8ms tick that is 0.7% of one tick,
        and this runs on a 60s timer, not per tick.
        """
        order, w, n = [], [], []
        for (src, dst) in self._edge_order:
            syn = self.connections.get((src, dst))
            if syn is None:
                continue
            order.append(f"{src}__{dst}")
            data = syn.weights.data
            w.append(round(float(data.mean()), 5) if data.size else 0.0)
            # syn.weights.nnz, NOT syn.nnz: the latter is cached at
            # construction. I shipped syn.nnz this morning and it put
            # the fresh-init count on the wire for all 48 edges.
            n.append(int(syn.weights.nnz))
        return {"order": order, "w": w, "n": n}

    def reward_pulse(self, strength: float, source: str = "unknown") -> None:
        """Phase 7 — inject a reward signal into the dopamine system.

        `strength` in [-1.0, 1.0]:
          +1.0 = strong positive reward (Dean said "this is perfect")
          +0.3 = small success (tool call worked, response completed)
           0.0 = no-op
          -0.3 = small failure (tool errored)
          -1.0 = strong negative (Dean explicitly upset)

        The pulse folds into dopamine over ~5 neuromodulator update cycles.
        Because STDP's learning rate already scales with dopamine, synapses
        currently active during the pulse get strengthened more (LTP) — this
        is real reinforcement learning at the synaptic level.
        """
        s = float(max(-1.0, min(1.0, strength)))
        if abs(s) < 1e-6:
            return
        with self._reward_lock:
            self._pending_reward += s
            self._reward_log.append((time.time(), source, s))
            if len(self._reward_log) > 64:
                self._reward_log = self._reward_log[-64:]

    def get_reward_log(self) -> list:
        """Recent reward events for telemetry. Returns list of dicts."""
        with self._reward_lock:
            return [
                {"ts": round(ts, 2), "source": src, "strength": round(s, 3)}
                for (ts, src, s) in self._reward_log[-32:]
            ]

    def get_neuron_positions(self) -> dict:
        """Get 3D positions for all neurons (for initial visualization setup).

        Cached + seeded: positions are computed once on first call with a
        deterministic seed, then returned from memory for every subsequent
        WebSocket connect. Without this, every dashboard reconnect would
        reroll ~8 MB of fresh randn() and the 3D viz would visibly
        "shuffle" instead of staying spatially stable.

        Kept for backward compatibility / non-WS callers. Hot path for
        the dashboard is get_neuron_positions_binary() — 6-10x smaller
        payload, zero JSON-parse overhead in the browser.
        """
        if getattr(self, "_neuron_positions_cache", None) is not None:
            return self._neuron_positions_cache

        rng = np.random.default_rng(seed=42)  # stable across runs
        positions = {}
        for name, region in self.regions.items():
            n = region.n_neurons
            center = region.position
            spread = 0.15 + (n / self.total_neurons) * 0.3
            pos = rng.standard_normal((n, 3)) * spread + center
            positions[name] = {
                "center": center.tolist(),
                "count": n,
                "positions": pos.tolist()[:min(n, 25000)],
                "spread": float(spread),
            }
        self._neuron_positions_cache = positions
        return positions

    def get_neuron_positions_binary(self):
        """Get 3D neuron positions as packed binary for the WS init path.

        Returns (meta, blob):
          meta = {
            "byte_size": int,                 # total bytes in blob
            "n_points_total": int,            # sum of n_points across regions
            "magic": "NPOS",                  # sentinel for client to detect
                                              # binary-vs-other ArrayBuffer
            "regions": {
              <name>: {
                "center": [x, y, z],          # float, region center
                "count": int,                 # full neuron count
                "n_points": int,              # actually packed (cap = 25000)
                "spread": float,
                "byte_offset": int,           # offset into blob
                "byte_length": int,           # bytes = n_points * 3 * 4
              },
              ...
            }
          }
          blob = bytes (Float32 little-endian, concatenated per region in
                       the order shown above)

        Cached once; subsequent connects return the same objects without
        re-computing the seeded RNG layout. The same seed=42 as
        get_neuron_positions() so positions match for any caller that
        compares.
        """
        cached = getattr(self, "_neuron_positions_binary_cache", None)
        if cached is not None:
            return cached

        rng = np.random.default_rng(seed=42)
        meta = {
            "magic": "NPOS",
            "byte_size": 0,
            "n_points_total": 0,
            "regions": {},
        }
        chunks = []  # list of bytes, concatenated at the end
        offset = 0

        for name, region in self.regions.items():
            n = region.n_neurons
            center = region.position
            spread = 0.15 + (n / self.total_neurons) * 0.3
            # Same math as get_neuron_positions() so the two stay in sync.
            pos = rng.standard_normal((n, 3)) * spread + center
            n_points = min(n, 25000)
            # Force float32 LE — frontend reads as Float32Array, which is
            # native-endian. x86/ARM are LE so this matches the browser.
            pos_f32 = np.ascontiguousarray(pos[:n_points], dtype="<f4")
            blob_bytes = pos_f32.tobytes()
            byte_length = len(blob_bytes)
            chunks.append(blob_bytes)
            meta["regions"][name] = {
                "center": [float(center[0]), float(center[1]), float(center[2])],
                "count": int(n),
                "n_points": int(n_points),
                "spread": float(spread),
                "byte_offset": int(offset),
                "byte_length": int(byte_length),
            }
            offset += byte_length
            meta["n_points_total"] += n_points

        meta["byte_size"] = offset
        blob = b"".join(chunks)
        self._neuron_positions_binary_cache = (meta, blob)
        return meta, blob
