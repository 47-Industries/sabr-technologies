"""
notes.py — Leon's note-taking tool surface.

Four backends, one contract:

  - Local "quick notes" SQLite at  brain_state/quick_notes.db
    (always works, no creds — Leon's fallback scratchpad)
  - Obsidian: a local markdown vault on disk
    (vault path resolved from arg → OBSIDIAN_VAULT_PATH → ~/Documents/ObsidianVault)
  - Notion: cloud API, gated on NOTION_API_TOKEN
  - Apple Notes: macOS only — gracefully no-op on Linux

Each tool takes a single `args` dict and returns either
`{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`. The
EXTRA_TOOLS dict at the bottom maps dotted names (e.g.
`notes.quick_add`) to the implementing function — import this dict from
the responder / MCP server to register them in one shot.

Style mirrors `brain/memory_extras.py`: `_`-prefixed helpers, lazy
shared SQLite connection guarded by a lock, defensive try/except on
every external call.
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import sqlite3
import subprocess
import threading
import time
import urllib.error
import urllib.request
from datetime import date, datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# PATHS, CONNECTIONS, ENV
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/). The file lives at
    brain/integrations/notes.py so we walk up two parents."""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(os.path.dirname(here))


def _quick_db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "quick_notes.db")


_QUICK_CONN: Optional[sqlite3.Connection] = None
_QUICK_LOCK = threading.Lock()


_QUICK_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    tags TEXT,
    source TEXT,
    created_at REAL NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX IF NOT EXISTS idx_notes_created ON notes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notes_tags ON notes(tags);
"""


def _quick_conn() -> sqlite3.Connection:
    """Lazy shared connection. `check_same_thread=False` so the same
    connection can be used from responder threads — all writes guarded
    by `_QUICK_LOCK`."""
    global _QUICK_CONN
    if _QUICK_CONN is not None:
        return _QUICK_CONN
    with _QUICK_LOCK:
        if _QUICK_CONN is None:
            conn = sqlite3.connect(_quick_db_path(), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.executescript(_QUICK_SCHEMA_SQL)
            conn.commit()
            _QUICK_CONN = conn
    return _QUICK_CONN


def _row_to_dict(row: sqlite3.Row) -> Optional[Dict[str, Any]]:
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _now_ts() -> float:
    return time.time()


def _today_iso() -> str:
    return date.today().isoformat()


def _parse_since(since: Any) -> Optional[float]:
    """Accept a unix ts (number) or an ISO date/datetime string."""
    if since is None or since == "":
        return None
    if isinstance(since, (int, float)):
        return float(since)
    s = str(since).strip()
    # Try ISO formats
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc).timestamp()
        except ValueError:
            continue
    # Final fallback: a raw float string
    try:
        return float(s)
    except ValueError:
        return None


def _normalize_tags(tags: Any) -> Optional[str]:
    """Tags stored as a comma-separated string. Accept list, tuple, or
    string from callers; strip empties; lower-case for consistency."""
    if tags is None:
        return None
    if isinstance(tags, (list, tuple, set)):
        items = [str(t).strip().lower().lstrip("#") for t in tags if str(t).strip()]
    else:
        items = [
            t.strip().lower().lstrip("#")
            for t in str(tags).replace("#", "").split(",")
            if t.strip()
        ]
    return ",".join(items) if items else None


def _split_tags(tags_str: Optional[str]) -> List[str]:
    if not tags_str:
        return []
    return [t for t in (s.strip() for s in tags_str.split(",")) if t]


# ──────────────────────────────────────────────────────────────────────────
# QUICK NOTES (local SQLite — always works)
# ──────────────────────────────────────────────────────────────────────────


def quick_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Append a quick note. `text` is required, `tags` may be a list or
    comma-string, `source` is a free-form label (e.g. 'voice',
    'dashboard')."""
    text = (args.get("text") or "").strip()
    if not text:
        return _err("text is required")
    tags = _normalize_tags(args.get("tags"))
    source = args.get("source")
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            cur = conn.execute(
                "INSERT INTO notes (text, tags, source, created_at) VALUES (?, ?, ?, ?)",
                (text, tags, source, _now_ts()),
            )
            conn.commit()
            note_id = cur.lastrowid
            row = conn.execute(
                "SELECT * FROM notes WHERE id = ?", (note_id,)
            ).fetchone()
        return _ok(_row_to_dict(row))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List notes, newest first. Optional `tag` filter and `since`
    cutoff (unix ts or ISO date)."""
    try:
        limit = int(args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    tag = args.get("tag")
    since_ts = _parse_since(args.get("since"))
    where: List[str] = []
    params: List[Any] = []
    if tag:
        where.append("(',' || COALESCE(tags,'') || ',') LIKE ?")
        params.append(f"%,{str(tag).strip().lower().lstrip('#')},%")
    if since_ts is not None:
        where.append("created_at >= ?")
        params.append(since_ts)
    sql = "SELECT * FROM notes"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            rows = conn.execute(sql, params).fetchall()
        return _ok([_row_to_dict(r) for r in rows])
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Case-insensitive substring search across text + tags."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        limit = int(args.get("limit") or 30)
    except (TypeError, ValueError):
        limit = 30
    pat = f"%{query.lower()}%"
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            rows = conn.execute(
                """
                SELECT * FROM notes
                WHERE LOWER(text) LIKE ? OR LOWER(COALESCE(tags,'')) LIKE ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (pat, pat, limit),
            ).fetchall()
        return _ok([_row_to_dict(r) for r in rows])
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a note by id. Returns `{deleted: bool}`."""
    note_id = args.get("note_id")
    if note_id is None:
        return _err("note_id is required")
    try:
        note_id = int(note_id)
    except (TypeError, ValueError):
        return _err("note_id must be an integer")
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            cur = conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
            conn.commit()
        return _ok({"deleted": cur.rowcount > 0, "note_id": note_id})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update a note's text / tags / source by id. Returns the new
    row, or an error if the note doesn't exist."""
    note_id = args.get("note_id")
    if note_id is None:
        return _err("note_id is required")
    try:
        note_id = int(note_id)
    except (TypeError, ValueError):
        return _err("note_id must be an integer")

    fields: List[Tuple[str, Any]] = []
    if "text" in args and args["text"] is not None:
        text = str(args["text"]).strip()
        if not text:
            return _err("text cannot be empty")
        fields.append(("text", text))
    if "tags" in args:
        fields.append(("tags", _normalize_tags(args["tags"])))
    if "source" in args:
        fields.append(("source", args["source"]))
    if not fields:
        return _err("at least one of text / tags / source is required")

    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            exists = conn.execute(
                "SELECT 1 FROM notes WHERE id = ?", (note_id,)
            ).fetchone()
            if exists is None:
                return _err(f"no note with id {note_id}")
            sets = ", ".join(f"{k} = ?" for k, _ in fields)
            params = [v for _, v in fields] + [note_id]
            conn.execute(f"UPDATE notes SET {sets} WHERE id = ?", params)
            conn.commit()
            row = conn.execute(
                "SELECT * FROM notes WHERE id = ?", (note_id,)
            ).fetchone()
        return _ok(_row_to_dict(row))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """All notes created since local midnight today, newest first."""
    midnight = datetime.combine(date.today(), datetime.min.time()).timestamp()
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            rows = conn.execute(
                "SELECT * FROM notes WHERE created_at >= ? ORDER BY created_at DESC",
                (midnight,),
            ).fetchall()
        return _ok([_row_to_dict(r) for r in rows])
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def quick_stats(args: Dict[str, Any]) -> Dict[str, Any]:
    """Total note count + per-tag breakdown + oldest/newest timestamps."""
    try:
        conn = _quick_conn()
        with _QUICK_LOCK:
            total = conn.execute("SELECT COUNT(*) FROM notes").fetchone()[0]
            bounds = conn.execute(
                "SELECT MIN(created_at), MAX(created_at) FROM notes"
            ).fetchone()
            tag_rows = conn.execute(
                "SELECT tags FROM notes WHERE tags IS NOT NULL AND tags != ''"
            ).fetchall()
        by_tag: Dict[str, int] = {}
        for r in tag_rows:
            for t in _split_tags(r["tags"]):
                by_tag[t] = by_tag.get(t, 0) + 1
        by_tag_sorted = dict(
            sorted(by_tag.items(), key=lambda kv: (-kv[1], kv[0]))
        )
        return _ok(
            {
                "total": total,
                "by_tag": by_tag_sorted,
                "oldest_ts": bounds[0],
                "newest_ts": bounds[1],
            }
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# OBSIDIAN (local markdown vault)
# ──────────────────────────────────────────────────────────────────────────


def _resolve_vault(arg: Any = None) -> Tuple[Optional[str], Optional[str]]:
    """Resolve the Obsidian vault path. Order:
      1. explicit `vault` arg
      2. OBSIDIAN_VAULT_PATH env var
      3. ~/Documents/ObsidianVault (only if it exists)
    Returns (path, None) on success or (None, error_msg) on failure."""
    candidate: Optional[str] = None
    if arg:
        candidate = os.path.expanduser(str(arg))
    elif os.environ.get("OBSIDIAN_VAULT_PATH"):
        candidate = os.path.expanduser(os.environ["OBSIDIAN_VAULT_PATH"])
    else:
        default = os.path.expanduser("~/Documents/ObsidianVault")
        if os.path.isdir(default):
            candidate = default
    if not candidate:
        return None, (
            "no Obsidian vault found — set OBSIDIAN_VAULT_PATH, pass "
            "`vault`, or create ~/Documents/ObsidianVault"
        )
    if not os.path.isdir(candidate):
        return None, f"vault path does not exist or is not a directory: {candidate}"
    return os.path.abspath(candidate), None


def _safe_vault_join(vault: str, rel: str) -> Optional[str]:
    """Join a relative vault path safely — refuse to escape the vault."""
    if not rel:
        return None
    rel = rel.lstrip("/\\")
    full = os.path.abspath(os.path.join(vault, rel))
    vault_abs = os.path.abspath(vault) + os.sep
    if not (full + os.sep).startswith(vault_abs) and full != os.path.abspath(vault):
        return None
    return full


def _iter_md_files(root: str, folder: Optional[str] = None):
    """Yield absolute paths to all .md files under root (or root/folder).
    Skips hidden dirs (.obsidian, .trash, .git)."""
    start = root
    if folder:
        joined = _safe_vault_join(root, folder)
        if joined and os.path.isdir(joined):
            start = joined
    for dirpath, dirnames, filenames in os.walk(start):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for fn in filenames:
            if fn.lower().endswith(".md"):
                yield os.path.join(dirpath, fn)


def obsidian_list_files(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all .md files in the vault, optionally scoped to `folder`."""
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    folder = args.get("folder")
    try:
        files: List[Dict[str, Any]] = []
        for path in _iter_md_files(vault, folder):
            try:
                st = os.stat(path)
                files.append(
                    {
                        "path": os.path.relpath(path, vault),
                        "size": st.st_size,
                        "modified_ts": st.st_mtime,
                    }
                )
            except OSError:
                continue
        files.sort(key=lambda f: f["modified_ts"], reverse=True)
        return _ok({"vault": vault, "count": len(files), "files": files})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def obsidian_read(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read a markdown file from the vault. `file_path_in_vault` is
    relative to the vault root."""
    rel = (args.get("file_path_in_vault") or "").strip()
    if not rel:
        return _err("file_path_in_vault is required")
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    full = _safe_vault_join(vault, rel)
    if full is None:
        return _err("file_path_in_vault escapes the vault")
    if not full.lower().endswith(".md"):
        full = full + ".md"
    if not os.path.isfile(full):
        return _err(f"file not found: {os.path.relpath(full, vault)}")
    try:
        with open(full, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        st = os.stat(full)
        return _ok(
            {
                "path": os.path.relpath(full, vault),
                "content": content,
                "size": st.st_size,
                "modified_ts": st.st_mtime,
            }
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def obsidian_write(args: Dict[str, Any]) -> Dict[str, Any]:
    """Write or append to a markdown file in the vault. Creates parent
    directories as needed."""
    rel = (args.get("file_path_in_vault") or "").strip()
    if not rel:
        return _err("file_path_in_vault is required")
    content = args.get("content")
    if content is None:
        return _err("content is required")
    append = bool(args.get("append"))
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    full = _safe_vault_join(vault, rel)
    if full is None:
        return _err("file_path_in_vault escapes the vault")
    if not full.lower().endswith(".md"):
        full = full + ".md"
    try:
        os.makedirs(os.path.dirname(full), exist_ok=True)
        mode = "a" if append else "w"
        text = str(content)
        with open(full, mode, encoding="utf-8") as f:
            if append and text and not text.startswith("\n"):
                # Ensure appended content lands on its own line
                f.write("\n")
            f.write(text)
        st = os.stat(full)
        return _ok(
            {
                "path": os.path.relpath(full, vault),
                "appended": append,
                "size": st.st_size,
                "modified_ts": st.st_mtime,
            }
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def obsidian_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Grep-like substring search across all .md files. Returns matched
    files with line numbers and snippets."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    needle = query.lower()
    hits: List[Dict[str, Any]] = []
    try:
        for path in _iter_md_files(vault):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    matches: List[Dict[str, Any]] = []
                    for i, line in enumerate(f, 1):
                        if needle in line.lower():
                            matches.append(
                                {"line": i, "text": line.rstrip("\n")[:300]}
                            )
                            if len(matches) >= 5:
                                break
                if matches:
                    hits.append(
                        {
                            "path": os.path.relpath(path, vault),
                            "matches": matches,
                        }
                    )
                    if len(hits) >= limit:
                        break
            except OSError:
                continue
        return _ok({"query": query, "hits": hits, "count": len(hits)})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _daily_note_relpath(date_iso: Optional[str]) -> str:
    iso = (date_iso or _today_iso()).strip()
    # Validate shape — accept YYYY-MM-DD only
    try:
        datetime.strptime(iso, "%Y-%m-%d")
    except ValueError:
        iso = _today_iso()
    return f"Daily Notes/{iso}.md"


def obsidian_daily_note(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read today's (or `date_iso`'s) daily note. Creates an empty stub
    with a `# YYYY-MM-DD` heading if missing."""
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    rel = _daily_note_relpath(args.get("date_iso"))
    full = _safe_vault_join(vault, rel)
    if full is None:
        return _err("daily note path escaped vault — unexpected")
    try:
        if not os.path.isfile(full):
            os.makedirs(os.path.dirname(full), exist_ok=True)
            heading = os.path.basename(full)[:-3]  # strip .md
            with open(full, "w", encoding="utf-8") as f:
                f.write(f"# {heading}\n\n")
        with open(full, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        st = os.stat(full)
        return _ok(
            {
                "path": os.path.relpath(full, vault),
                "content": content,
                "created_if_missing": True,
                "size": st.st_size,
                "modified_ts": st.st_mtime,
            }
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def obsidian_add_to_daily(args: Dict[str, Any]) -> Dict[str, Any]:
    """Append a bullet to today's daily note. Creates the daily note if
    it doesn't exist."""
    text = (args.get("text") or "").strip()
    if not text:
        return _err("text is required")
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    rel = _daily_note_relpath(None)
    full = _safe_vault_join(vault, rel)
    if full is None:
        return _err("daily note path escaped vault — unexpected")
    try:
        os.makedirs(os.path.dirname(full), exist_ok=True)
        is_new = not os.path.isfile(full)
        with open(full, "a", encoding="utf-8") as f:
            if is_new:
                heading = os.path.basename(full)[:-3]
                f.write(f"# {heading}\n\n")
            stamp = datetime.now().strftime("%H:%M")
            f.write(f"- {stamp} — {text}\n")
        st = os.stat(full)
        return _ok(
            {
                "path": os.path.relpath(full, vault),
                "appended": text,
                "created_if_missing": is_new,
                "size": st.st_size,
                "modified_ts": st.st_mtime,
            }
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


_WIKILINK_RE = re.compile(r"\[\[([^\]\|#]+)(?:#[^\]\|]*)?(?:\|[^\]]*)?\]\]")


def obsidian_backlinks(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find all vault files that link to `file_path_in_vault` via
    `[[basename]]` wiki-link syntax."""
    rel = (args.get("file_path_in_vault") or "").strip()
    if not rel:
        return _err("file_path_in_vault is required")
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    target_full = _safe_vault_join(vault, rel)
    if target_full is None:
        return _err("file_path_in_vault escapes the vault")
    target_base = os.path.basename(target_full)
    if target_base.lower().endswith(".md"):
        target_base = target_base[:-3]
    target_base_lc = target_base.lower()

    hits: List[Dict[str, Any]] = []
    try:
        for path in _iter_md_files(vault):
            if os.path.abspath(path) == os.path.abspath(target_full):
                continue
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read()
            except OSError:
                continue
            matches: List[Dict[str, Any]] = []
            for m in _WIKILINK_RE.finditer(text):
                link = m.group(1).strip()
                link_base = os.path.basename(link)
                if link_base.lower() == target_base_lc:
                    line_no = text.count("\n", 0, m.start()) + 1
                    matches.append({"line": line_no, "link": m.group(0)})
            if matches:
                hits.append(
                    {"path": os.path.relpath(path, vault), "matches": matches}
                )
        return _ok(
            {"target": target_base, "backlinks": hits, "count": len(hits)}
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


_TAG_RE = re.compile(r"(?<![\w#/])#([A-Za-z][\w/\-]{0,63})")


def obsidian_tags_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """Scan every .md file for `#tag` references and return a count map
    sorted by frequency (descending)."""
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    counts: Dict[str, int] = {}
    try:
        for path in _iter_md_files(vault):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    text = f.read()
            except OSError:
                continue
            for m in _TAG_RE.finditer(text):
                tag = m.group(1)
                counts[tag] = counts.get(tag, 0) + 1
        sorted_counts = dict(
            sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
        )
        return _ok(
            {"total_unique": len(sorted_counts), "tags": sorted_counts}
        )
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


_UNFINISHED_RE = re.compile(r"^\s*[-*+]\s*\[\s\]\s+(.+?)\s*$")


def obsidian_unfinished_tasks(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find all `- [ ]` style unfinished tasks across the vault."""
    vault, err = _resolve_vault(args.get("vault"))
    if err:
        return _err(err)
    tasks: List[Dict[str, Any]] = []
    try:
        for path in _iter_md_files(vault):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        m = _UNFINISHED_RE.match(line)
                        if m:
                            tasks.append(
                                {
                                    "path": os.path.relpath(path, vault),
                                    "line": i,
                                    "text": m.group(1)[:300],
                                }
                            )
            except OSError:
                continue
        return _ok({"count": len(tasks), "tasks": tasks})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# NOTION (cloud API)
# ──────────────────────────────────────────────────────────────────────────


NOTION_API_BASE = "https://api.notion.com/v1"
NOTION_API_VERSION = "2022-06-28"


def _notion_token() -> Optional[str]:
    return os.environ.get("NOTION_API_TOKEN") or os.environ.get(
        "NOTION_TOKEN"
    )


def _notion_request(
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
    timeout: float = 15.0,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """Low-level Notion API call. Returns (parsed_json, None) on success
    or (None, error_message)."""
    token = _notion_token()
    if not token:
        return None, (
            "NOTION_API_TOKEN not set — Notion tools are disabled. "
            "Create an integration at notion.so/my-integrations, share "
            "your page/database with it, and export the token."
        )
    url = NOTION_API_BASE + path
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method.upper())
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Notion-Version", NOTION_API_VERSION)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return {}, None
            return json.loads(raw.decode("utf-8")), None
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            err_body = ""
        return None, f"HTTP {e.code}: {err_body[:500]}"
    except urllib.error.URLError as e:
        return None, f"URLError: {e.reason}"
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


def _md_to_notion_blocks(md: str) -> List[Dict[str, Any]]:
    """Convert a small subset of Markdown (headings #/##/###, bullets
    -/*/+, numbered 1., todo `- [ ]`/`- [x]`, code fences, blank lines)
    into Notion block objects. Anything else becomes a paragraph."""
    blocks: List[Dict[str, Any]] = []
    if not md:
        return blocks

    def _rt(text: str) -> List[Dict[str, Any]]:
        return [{"type": "text", "text": {"content": text[:1900]}}]

    lines = md.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Code fence
        if stripped.startswith("```"):
            lang = stripped[3:].strip() or "plain text"
            buf: List[str] = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1  # skip closing fence
            blocks.append(
                {
                    "object": "block",
                    "type": "code",
                    "code": {
                        "rich_text": _rt("\n".join(buf)),
                        "language": lang,
                    },
                }
            )
            continue

        if not stripped:
            i += 1
            continue

        # Headings
        if stripped.startswith("### "):
            blocks.append(
                {
                    "object": "block",
                    "type": "heading_3",
                    "heading_3": {"rich_text": _rt(stripped[4:])},
                }
            )
            i += 1
            continue
        if stripped.startswith("## "):
            blocks.append(
                {
                    "object": "block",
                    "type": "heading_2",
                    "heading_2": {"rich_text": _rt(stripped[3:])},
                }
            )
            i += 1
            continue
        if stripped.startswith("# "):
            blocks.append(
                {
                    "object": "block",
                    "type": "heading_1",
                    "heading_1": {"rich_text": _rt(stripped[2:])},
                }
            )
            i += 1
            continue

        # Todo
        m = re.match(r"^[-*+]\s+\[([ xX])\]\s+(.+)$", stripped)
        if m:
            checked = m.group(1).lower() == "x"
            blocks.append(
                {
                    "object": "block",
                    "type": "to_do",
                    "to_do": {
                        "rich_text": _rt(m.group(2)),
                        "checked": checked,
                    },
                }
            )
            i += 1
            continue

        # Bulleted
        m = re.match(r"^[-*+]\s+(.+)$", stripped)
        if m:
            blocks.append(
                {
                    "object": "block",
                    "type": "bulleted_list_item",
                    "bulleted_list_item": {"rich_text": _rt(m.group(1))},
                }
            )
            i += 1
            continue

        # Numbered
        m = re.match(r"^\d+\.\s+(.+)$", stripped)
        if m:
            blocks.append(
                {
                    "object": "block",
                    "type": "numbered_list_item",
                    "numbered_list_item": {"rich_text": _rt(m.group(1))},
                }
            )
            i += 1
            continue

        # Default paragraph
        blocks.append(
            {
                "object": "block",
                "type": "paragraph",
                "paragraph": {"rich_text": _rt(stripped)},
            }
        )
        i += 1

    return blocks


def notion_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """POST /v1/search — query across pages and databases the
    integration has access to."""
    query = args.get("query") or ""
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    body = {"query": str(query), "page_size": max(1, min(100, limit))}
    data, err = _notion_request("POST", "/search", body)
    if err:
        return _err(err)
    results = (data or {}).get("results", [])
    return _ok({"count": len(results), "results": results})


def notion_query_database(args: Dict[str, Any]) -> Dict[str, Any]:
    """POST /v1/databases/{id}/query — optionally with a `filter_json`
    Notion-format filter."""
    database_id = (args.get("database_id") or "").strip()
    if not database_id:
        return _err("database_id is required")
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    body: Dict[str, Any] = {"page_size": max(1, min(100, limit))}
    filter_json = args.get("filter_json")
    if filter_json:
        if isinstance(filter_json, str):
            try:
                filter_json = json.loads(filter_json)
            except json.JSONDecodeError as e:
                return _err(f"filter_json is not valid JSON: {e}")
        body["filter"] = filter_json
    data, err = _notion_request(
        "POST", f"/databases/{database_id}/query", body
    )
    if err:
        return _err(err)
    results = (data or {}).get("results", [])
    return _ok({"count": len(results), "results": results})


def notion_get_page(args: Dict[str, Any]) -> Dict[str, Any]:
    """GET /v1/pages/{id}."""
    page_id = (args.get("page_id") or "").strip()
    if not page_id:
        return _err("page_id is required")
    data, err = _notion_request("GET", f"/pages/{page_id}")
    if err:
        return _err(err)
    return _ok(data)


def notion_create_page_in_database(args: Dict[str, Any]) -> Dict[str, Any]:
    """POST /v1/pages with `parent.database_id`. `properties` must be
    the Notion JSON shape, e.g. `{"Name": {"title": [{"text":
    {"content": "Hi"}}]}}`."""
    database_id = (args.get("database_id") or "").strip()
    if not database_id:
        return _err("database_id is required")
    properties = args.get("properties")
    if not isinstance(properties, dict) or not properties:
        return _err("properties (dict) is required, in Notion property shape")
    body = {
        "parent": {"database_id": database_id},
        "properties": properties,
    }
    data, err = _notion_request("POST", "/pages", body)
    if err:
        return _err(err)
    return _ok(data)


def notion_create_page_in_parent(args: Dict[str, Any]) -> Dict[str, Any]:
    """POST /v1/pages under a parent page. Builds the title property
    and (optionally) appends `content_markdown` as child blocks."""
    parent_page_id = (args.get("parent_page_id") or "").strip()
    if not parent_page_id:
        return _err("parent_page_id is required")
    title = (args.get("title") or "").strip()
    if not title:
        return _err("title is required")
    content_md = args.get("content_markdown") or ""
    body: Dict[str, Any] = {
        "parent": {"page_id": parent_page_id},
        "properties": {
            "title": {
                "title": [{"type": "text", "text": {"content": title[:1900]}}]
            }
        },
    }
    children = _md_to_notion_blocks(content_md) if content_md else []
    if children:
        body["children"] = children[:100]  # Notion caps at 100 per request
    data, err = _notion_request("POST", "/pages", body)
    if err:
        return _err(err)
    return _ok(data)


def notion_append_block(args: Dict[str, Any]) -> Dict[str, Any]:
    """PATCH /v1/blocks/{id}/children — convert `content_markdown` to
    blocks and append to a page/block."""
    page_id = (args.get("page_id") or "").strip()
    if not page_id:
        return _err("page_id is required")
    content_md = args.get("content_markdown") or ""
    if not content_md.strip():
        return _err("content_markdown is required")
    children = _md_to_notion_blocks(content_md)
    if not children:
        return _err("content_markdown produced no blocks")
    body = {"children": children[:100]}
    data, err = _notion_request("PATCH", f"/blocks/{page_id}/children", body)
    if err:
        return _err(err)
    return _ok(data)


def notion_get_block_children(args: Dict[str, Any]) -> Dict[str, Any]:
    """GET /v1/blocks/{id}/children?page_size=N."""
    block_id = (args.get("block_id") or "").strip()
    if not block_id:
        return _err("block_id is required")
    try:
        limit = int(args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    limit = max(1, min(100, limit))
    data, err = _notion_request(
        "GET", f"/blocks/{block_id}/children?page_size={limit}"
    )
    if err:
        return _err(err)
    results = (data or {}).get("results", [])
    return _ok({"count": len(results), "results": results})


def notion_update_page(args: Dict[str, Any]) -> Dict[str, Any]:
    """PATCH /v1/pages/{id} — update properties (Notion JSON shape)."""
    page_id = (args.get("page_id") or "").strip()
    if not page_id:
        return _err("page_id is required")
    properties = args.get("properties")
    if not isinstance(properties, dict) or not properties:
        return _err("properties (dict) is required")
    body = {"properties": properties}
    data, err = _notion_request("PATCH", f"/pages/{page_id}", body)
    if err:
        return _err(err)
    return _ok(data)


def notion_list_databases(args: Dict[str, Any]) -> Dict[str, Any]:
    """POST /v1/search filtered to objects of type `database`."""
    try:
        limit = int(args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    body = {
        "filter": {"value": "database", "property": "object"},
        "page_size": max(1, min(100, limit)),
    }
    data, err = _notion_request("POST", "/search", body)
    if err:
        return _err(err)
    results = (data or {}).get("results", [])
    return _ok({"count": len(results), "results": results})


# ──────────────────────────────────────────────────────────────────────────
# APPLE NOTES (macOS only — gracefully no-op on Linux)
# ──────────────────────────────────────────────────────────────────────────


def _is_macos() -> bool:
    return platform.system() == "Darwin"


def _osascript_available() -> bool:
    return _is_macos() and shutil.which("osascript") is not None


def _apple_notes_unavailable() -> Dict[str, Any]:
    return _err(
        f"Apple Notes is macOS-only; current platform is {platform.system()}. "
        "Use notes.obsidian_* or notes.quick_* instead."
    )


def _run_osascript(script: str, timeout: float = 10.0) -> Tuple[Optional[str], Optional[str]]:
    try:
        proc = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if proc.returncode != 0:
            return None, proc.stderr.strip() or f"osascript exit {proc.returncode}"
        return proc.stdout.strip(), None
    except subprocess.TimeoutExpired:
        return None, "osascript timed out"
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"


def apple_notes_create(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a new Apple Note. No-op on non-macOS systems."""
    if not _osascript_available():
        return _apple_notes_unavailable()
    title = (args.get("title") or "Untitled").replace('"', '\\"')
    body = (args.get("body") or "").replace('"', '\\"').replace("\n", "<br>")
    script = (
        f'tell application "Notes"\n'
        f'  set newNote to make new note with properties '
        f'{{name:"{title}", body:"<h1>{title}</h1><p>{body}</p>"}}\n'
        f'  return id of newNote\n'
        f'end tell'
    )
    out, err = _run_osascript(script)
    if err:
        return _err(err)
    return _ok({"id": out, "title": args.get("title") or "Untitled"})


def apple_notes_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List recent Apple Notes (name + id). No-op on non-macOS systems."""
    if not _osascript_available():
        return _apple_notes_unavailable()
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    script = (
        'tell application "Notes"\n'
        '  set out to ""\n'
        '  set n to 0\n'
        '  repeat with theNote in notes\n'
        '    set out to out & (id of theNote) & "\t" & (name of theNote) & linefeed\n'
        '    set n to n + 1\n'
        f'    if n >= {limit} then exit repeat\n'
        '  end repeat\n'
        '  return out\n'
        'end tell'
    )
    out, err = _run_osascript(script, timeout=20.0)
    if err:
        return _err(err)
    rows: List[Dict[str, Any]] = []
    for line in (out or "").splitlines():
        if "\t" in line:
            note_id, name = line.split("\t", 1)
            rows.append({"id": note_id.strip(), "name": name.strip()})
    return _ok({"count": len(rows), "notes": rows})


# ──────────────────────────────────────────────────────────────────────────
# CROSS-TOOL HELPERS
# ──────────────────────────────────────────────────────────────────────────


def capture_thought(args: Dict[str, Any]) -> Dict[str, Any]:
    """One-shot capture. `target` selects the backend:
      - "auto" (default): Notion → Obsidian daily → quick_add
      - "notion" | "obsidian" | "quick": force a specific backend
    Falls back gracefully if the chosen backend isn't configured."""
    text = (args.get("text") or "").strip()
    if not text:
        return _err("text is required")
    target = (args.get("target") or "auto").lower()

    def _do_notion() -> Optional[Dict[str, Any]]:
        if not _notion_token():
            return None
        parent = os.environ.get("NOTION_INBOX_PAGE_ID") or os.environ.get(
            "NOTION_PARENT_PAGE_ID"
        )
        if not parent:
            return None
        title = text[:80].replace("\n", " ").strip() or "Thought"
        res = notion_create_page_in_parent(
            {
                "parent_page_id": parent,
                "title": title,
                "content_markdown": text,
            }
        )
        if res.get("ok"):
            res["result"] = {"backend": "notion", "page": res["result"]}
        return res

    def _do_obsidian() -> Optional[Dict[str, Any]]:
        vault, err = _resolve_vault(None)
        if err:
            return None
        res = obsidian_add_to_daily({"text": text})
        if res.get("ok"):
            res["result"] = {"backend": "obsidian", **res["result"]}
        return res

    def _do_quick() -> Dict[str, Any]:
        res = quick_add({"text": text, "source": "capture_thought"})
        if res.get("ok"):
            res["result"] = {"backend": "quick", "note": res["result"]}
        return res

    if target == "notion":
        r = _do_notion()
        if r is None:
            return _err(
                "Notion not configured (need NOTION_API_TOKEN and "
                "NOTION_INBOX_PAGE_ID / NOTION_PARENT_PAGE_ID)"
            )
        return r
    if target == "obsidian":
        r = _do_obsidian()
        if r is None:
            return _err(
                "Obsidian vault not found — set OBSIDIAN_VAULT_PATH or "
                "create ~/Documents/ObsidianVault"
            )
        return r
    if target == "quick":
        return _do_quick()
    if target != "auto":
        return _err(f"unknown target {target!r}; use auto/notion/obsidian/quick")

    # auto
    for fn in (_do_notion, _do_obsidian):
        r = fn()
        if r is not None and r.get("ok"):
            return r
    return _do_quick()


def search_everywhere(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search every available backend in parallel-ish (sequential calls,
    but cheap) and return a unified `{backend → results}` map. Backends
    that aren't configured are reported with their reason, never crash."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        per = int(args.get("limit_per_source") or 5)
    except (TypeError, ValueError):
        per = 5

    out: Dict[str, Any] = {}

    # Quick notes (always available)
    q = quick_search({"query": query, "limit": per})
    out["quick"] = (
        {"ok": True, "results": q["result"]}
        if q.get("ok")
        else {"ok": False, "error": q.get("error")}
    )

    # Obsidian (available if vault resolves)
    vault, err = _resolve_vault(None)
    if err:
        out["obsidian"] = {"ok": False, "error": err}
    else:
        o = obsidian_search({"query": query, "limit": per})
        out["obsidian"] = (
            {"ok": True, "results": o["result"].get("hits", [])}
            if o.get("ok")
            else {"ok": False, "error": o.get("error")}
        )

    # Notion (available if token present)
    if not _notion_token():
        out["notion"] = {"ok": False, "error": "NOTION_API_TOKEN not set"}
    else:
        n = notion_search({"query": query, "limit": per})
        out["notion"] = (
            {"ok": True, "results": n["result"].get("results", [])}
            if n.get("ok")
            else {"ok": False, "error": n.get("error")}
        )

    # Apple Notes (macOS only — we don't search, but report status honestly)
    if _osascript_available():
        out["apple_notes"] = {
            "ok": False,
            "error": "apple_notes search not implemented; use apple_notes_list",
        }
    else:
        out["apple_notes"] = {
            "ok": False,
            "error": f"macOS only (current: {platform.system()})",
        }

    total = sum(
        len(v.get("results", []))
        for v in out.values()
        if isinstance(v, dict) and v.get("ok")
    )
    return _ok({"query": query, "total_hits": total, "by_backend": out})


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted-name registry
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # Quick (local SQLite)
    "notes.quick_add": quick_add,
    "notes.quick_list": quick_list,
    "notes.quick_search": quick_search,
    "notes.quick_delete": quick_delete,
    "notes.quick_update": quick_update,
    "notes.quick_today": quick_today,
    "notes.quick_stats": quick_stats,
    # Obsidian (local markdown vault)
    "notes.obsidian_list_files": obsidian_list_files,
    "notes.obsidian_read": obsidian_read,
    "notes.obsidian_write": obsidian_write,
    "notes.obsidian_search": obsidian_search,
    "notes.obsidian_daily_note": obsidian_daily_note,
    "notes.obsidian_add_to_daily": obsidian_add_to_daily,
    "notes.obsidian_backlinks": obsidian_backlinks,
    "notes.obsidian_tags_list": obsidian_tags_list,
    "notes.obsidian_unfinished_tasks": obsidian_unfinished_tasks,
    # Notion (API)
    "notes.notion_search": notion_search,
    "notes.notion_query_database": notion_query_database,
    "notes.notion_get_page": notion_get_page,
    "notes.notion_create_page_in_database": notion_create_page_in_database,
    "notes.notion_create_page_in_parent": notion_create_page_in_parent,
    "notes.notion_append_block": notion_append_block,
    "notes.notion_get_block_children": notion_get_block_children,
    "notes.notion_update_page": notion_update_page,
    "notes.notion_list_databases": notion_list_databases,
    # Apple Notes (macOS only — gracefully no-op on Linux)
    "notes.apple_notes_create": apple_notes_create,
    "notes.apple_notes_list": apple_notes_list,
    # Cross-tool helpers
    "notes.capture_thought": capture_thought,
    "notes.search_everywhere": search_everywhere,
}
