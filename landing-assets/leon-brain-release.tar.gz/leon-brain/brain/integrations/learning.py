"""
learning.py — Leon's learning & study tool surface.

Gives Leon the ability to manage Dean's learning: flashcards with SM-2
spaced repetition, study sessions, course/skill tracking, reading goals,
quiz generation, and knowledge checks.

All persistence is local SQLite at `brain_state/learning.db` (auto-created
on first call). Each tool takes a single `args` dict and returns
`{"ok": True, ...}` or `{"ok": False, "error": "..."}` — tools never raise.
The `EXTRA_TOOLS` dict at the bottom maps dotted tool names (e.g.
`learn.deck_create`) to the implementing function.

Style matches `brain/integrations/productivity.py` (SQLite-backed).
"""

from __future__ import annotations

import os
import random
import sqlite3
import threading
from datetime import datetime, date, timedelta
from typing import Any, Callable, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONNECTION
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/)."""
    # this file lives at brain/integrations/learning.py — two levels up
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "learning.db")


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS decks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS cards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    deck_id INTEGER NOT NULL,
    front TEXT NOT NULL,
    back TEXT NOT NULL,
    ease REAL DEFAULT 2.5,
    interval_days REAL DEFAULT 0,
    due_date REAL DEFAULT (strftime('%s','now')),
    reps INTEGER DEFAULT 0,
    lapses INTEGER DEFAULT 0,
    created_at REAL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS study_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    deck_id INTEGER,
    started_at REAL DEFAULT (strftime('%s','now')),
    ended_at REAL,
    cards_reviewed INTEGER DEFAULT 0,
    cards_correct INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    provider TEXT,
    url TEXT,
    status TEXT DEFAULT 'not_started',
    progress_pct REAL DEFAULT 0,
    started_at REAL,
    target_date TEXT,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    current_level INTEGER DEFAULT 1,
    target_level INTEGER DEFAULT 10,
    hours_practiced REAL DEFAULT 0,
    last_practiced REAL,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS reading_list (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT,
    type TEXT DEFAULT 'book',
    status TEXT DEFAULT 'to_read',
    progress_pct REAL DEFAULT 0,
    rating REAL,
    added_at REAL DEFAULT (strftime('%s','now')),
    finished_at REAL,
    notes TEXT
);
"""


def _conn() -> sqlite3.Connection:
    """Lazily open the shared SQLite connection and ensure the schema."""
    global _DB_CONN
    if _DB_CONN is None:
        with _DB_LOCK:
            if _DB_CONN is None:
                conn = sqlite3.connect(_db_path(), check_same_thread=False)
                conn.row_factory = sqlite3.Row
                conn.executescript(_SCHEMA_SQL)
                conn.commit()
                _DB_CONN = conn
    return _DB_CONN


# ──────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _ok(**kw: Any) -> Dict[str, Any]:
    out: Dict[str, Any] = {"ok": True}
    out.update(kw)
    return out


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": str(msg)}


def _now() -> float:
    return datetime.now().timestamp()


def _today_start() -> float:
    d = date.today()
    return datetime(d.year, d.month, d.day).timestamp()


def _end_of_today() -> float:
    return _today_start() + 86400.0


def _iso(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    try:
        return datetime.fromtimestamp(ts).isoformat(timespec="seconds")
    except Exception:
        return None


def _day_str(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
    except Exception:
        return None


def _row(r: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
    return dict(r) if r is not None else None


def _rows(rs: List[sqlite3.Row]) -> List[Dict[str, Any]]:
    return [dict(r) for r in rs]


def _card_dict(r: sqlite3.Row) -> Dict[str, Any]:
    d = dict(r)
    d["due_date_iso"] = _iso(d.get("due_date"))
    interval = d.get("interval_days") or 0
    if interval > 21:
        d["maturity"] = "mature"
    elif d.get("reps", 0) == 0:
        d["maturity"] = "new"
    elif interval >= 1:
        d["maturity"] = "young"
    else:
        d["maturity"] = "learning"
    return d


def _try_import(name: str):
    try:
        return __import__(name)
    except Exception:
        return None


def _require(args: Dict[str, Any], *keys: str):
    """Return (values..., None) or (..., error_dict)."""
    missing = [k for k in keys if args.get(k) in (None, "")]
    if missing:
        return None, _err(f"missing required arg(s): {', '.join(missing)}")
    return [args.get(k) for k in keys], None


# ──────────────────────────────────────────────────────────────────────────
# SM-2 SPACED REPETITION
# ──────────────────────────────────────────────────────────────────────────

_EASE_FLOOR = 1.3
_EASE_DEFAULT = 2.5


def _sm2(ease: float, interval: float, reps: int, lapses: int,
         quality: int) -> Dict[str, Any]:
    """Apply one SM-2 review step.

    quality 0-2 = failed recall (lapse): interval resets, ease drops.
    quality 3-5 = successful recall: interval grows by ease.
    """
    quality = max(0, min(5, int(quality)))
    ease = ease if ease else _EASE_DEFAULT

    if quality < 3:
        # lapse — reset learning, penalise ease
        reps = 0
        lapses += 1
        interval = 1.0
        ease = max(_EASE_FLOOR, ease - 0.20)
    else:
        reps += 1
        if reps == 1:
            interval = 1.0
        elif reps == 2:
            interval = 6.0
        else:
            interval = round((interval or 1.0) * ease, 2)
        # standard SM-2 ease adjustment
        ease = ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
        ease = max(_EASE_FLOOR, round(ease, 4))

    due = _now() + interval * 86400.0
    return {
        "ease": round(ease, 4),
        "interval_days": interval,
        "reps": reps,
        "lapses": lapses,
        "due_date": due,
    }


# ──────────────────────────────────────────────────────────────────────────
# FLASHCARDS — DECKS
# ──────────────────────────────────────────────────────────────────────────


def deck_create(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "name")
        if err:
            return err
        name = vals[0]
        desc = args.get("description")
        c = _conn()
        cur = c.execute(
            "INSERT INTO decks (name, description) VALUES (?, ?)",
            (name, desc),
        )
        c.commit()
        return _ok(deck_id=cur.lastrowid, name=name)
    except Exception as e:
        return _err(e)


def deck_list(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        rs = c.execute(
            """
            SELECT d.id, d.name, d.description, d.created_at,
                   (SELECT COUNT(*) FROM cards WHERE deck_id = d.id) AS card_count,
                   (SELECT COUNT(*) FROM cards
                      WHERE deck_id = d.id AND due_date <= ?) AS due_count
            FROM decks d ORDER BY d.created_at DESC
            """,
            (_end_of_today(),),
        ).fetchall()
        decks = _rows(rs)
        for d in decks:
            d["created_at_iso"] = _iso(d.get("created_at"))
        return _ok(decks=decks, count=len(decks))
    except Exception as e:
        return _err(e)


def deck_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id")
        if err:
            return err
        deck_id = int(vals[0])
        c = _conn()
        row = c.execute("SELECT id FROM decks WHERE id = ?", (deck_id,)).fetchone()
        if not row:
            return _err(f"deck {deck_id} not found")
        ncards = c.execute(
            "SELECT COUNT(*) AS n FROM cards WHERE deck_id = ?", (deck_id,)
        ).fetchone()["n"]
        c.execute("DELETE FROM cards WHERE deck_id = ?", (deck_id,))
        c.execute("DELETE FROM decks WHERE id = ?", (deck_id,))
        c.commit()
        return _ok(deck_id=deck_id, cards_deleted=ncards)
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# FLASHCARDS — CARDS
# ──────────────────────────────────────────────────────────────────────────


def card_add(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id", "front", "back")
        if err:
            return err
        deck_id, front, back = int(vals[0]), vals[1], vals[2]
        c = _conn()
        if not c.execute("SELECT id FROM decks WHERE id = ?", (deck_id,)).fetchone():
            return _err(f"deck {deck_id} not found")
        cur = c.execute(
            """INSERT INTO cards (deck_id, front, back, ease, interval_days, due_date)
               VALUES (?, ?, ?, ?, 0, ?)""",
            (deck_id, front, back, _EASE_DEFAULT, _now()),
        )
        c.commit()
        return _ok(card_id=cur.lastrowid, deck_id=deck_id)
    except Exception as e:
        return _err(e)


def card_add_bulk(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id", "cards")
        if err:
            return err
        deck_id = int(vals[0])
        cards = vals[1]
        if not isinstance(cards, list):
            return _err("'cards' must be a list of {front, back}")
        c = _conn()
        if not c.execute("SELECT id FROM decks WHERE id = ?", (deck_id,)).fetchone():
            return _err(f"deck {deck_id} not found")
        added, skipped = [], 0
        for item in cards:
            if not isinstance(item, dict):
                skipped += 1
                continue
            front = item.get("front")
            back = item.get("back")
            if not front or not back:
                skipped += 1
                continue
            cur = c.execute(
                """INSERT INTO cards (deck_id, front, back, ease, interval_days, due_date)
                   VALUES (?, ?, ?, ?, 0, ?)""",
                (deck_id, front, back, _EASE_DEFAULT, _now()),
            )
            added.append(cur.lastrowid)
        c.commit()
        return _ok(deck_id=deck_id, added=len(added), card_ids=added, skipped=skipped)
    except Exception as e:
        return _err(e)


def cards_due(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        deck_id = args.get("deck_id")
        limit = int(args.get("limit", 20) or 20)
        c = _conn()
        cutoff = _end_of_today()
        if deck_id is not None:
            rs = c.execute(
                """SELECT * FROM cards WHERE deck_id = ? AND due_date <= ?
                   ORDER BY due_date ASC LIMIT ?""",
                (int(deck_id), cutoff, limit),
            ).fetchall()
        else:
            rs = c.execute(
                """SELECT * FROM cards WHERE due_date <= ?
                   ORDER BY due_date ASC LIMIT ?""",
                (cutoff, limit),
            ).fetchall()
        cards = [_card_dict(r) for r in rs]
        return _ok(cards=cards, count=len(cards))
    except Exception as e:
        return _err(e)


def card_review(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "card_id", "quality_0_5")
        if err:
            return err
        card_id = int(vals[0])
        quality = int(vals[1])
        if quality < 0 or quality > 5:
            return _err("quality_0_5 must be 0-5")
        c = _conn()
        r = c.execute("SELECT * FROM cards WHERE id = ?", (card_id,)).fetchone()
        if not r:
            return _err(f"card {card_id} not found")
        upd = _sm2(r["ease"], r["interval_days"], r["reps"], r["lapses"], quality)
        c.execute(
            """UPDATE cards SET ease=?, interval_days=?, reps=?, lapses=?, due_date=?
               WHERE id=?""",
            (upd["ease"], upd["interval_days"], upd["reps"], upd["lapses"],
             upd["due_date"], card_id),
        )
        c.commit()
        return _ok(card_id=card_id, correct=quality >= 3, **upd,
                   due_date_iso=_iso(upd["due_date"]))
    except Exception as e:
        return _err(e)


def deck_stats(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id")
        if err:
            return err
        deck_id = int(vals[0])
        c = _conn()
        deck = c.execute("SELECT * FROM decks WHERE id = ?", (deck_id,)).fetchone()
        if not deck:
            return _err(f"deck {deck_id} not found")
        rs = c.execute("SELECT * FROM cards WHERE deck_id = ?", (deck_id,)).fetchall()
        cutoff = _end_of_today()
        total = len(rs)
        due = mature = young = learning = new = 0
        for r in rs:
            interval = r["interval_days"] or 0
            if r["due_date"] <= cutoff:
                due += 1
            if interval > 21:
                mature += 1
            elif r["reps"] == 0:
                new += 1
            elif interval >= 1:
                young += 1
            else:
                learning += 1
        return _ok(
            deck_id=deck_id, name=deck["name"], total=total,
            due_today=due, mature=mature, young=young,
            learning=learning, new=new,
        )
    except Exception as e:
        return _err(e)


def card_edit(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "card_id")
        if err:
            return err
        card_id = int(vals[0])
        front = args.get("front")
        back = args.get("back")
        if front is None and back is None:
            return _err("nothing to edit — provide front and/or back")
        c = _conn()
        r = c.execute("SELECT * FROM cards WHERE id = ?", (card_id,)).fetchone()
        if not r:
            return _err(f"card {card_id} not found")
        sets, params = [], []
        if front is not None:
            sets.append("front=?")
            params.append(front)
        if back is not None:
            sets.append("back=?")
            params.append(back)
        params.append(card_id)
        c.execute(f"UPDATE cards SET {', '.join(sets)} WHERE id=?", params)
        c.commit()
        return _ok(card_id=card_id, updated=True)
    except Exception as e:
        return _err(e)


def card_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "card_id")
        if err:
            return err
        card_id = int(vals[0])
        c = _conn()
        if not c.execute("SELECT id FROM cards WHERE id = ?", (card_id,)).fetchone():
            return _err(f"card {card_id} not found")
        c.execute("DELETE FROM cards WHERE id = ?", (card_id,))
        c.commit()
        return _ok(card_id=card_id, deleted=True)
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# STUDY SESSIONS
# ──────────────────────────────────────────────────────────────────────────


def study_start(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id")
        if err:
            return err
        deck_id = int(vals[0])
        c = _conn()
        if not c.execute("SELECT id FROM decks WHERE id = ?", (deck_id,)).fetchone():
            return _err(f"deck {deck_id} not found")
        cur = c.execute(
            "INSERT INTO study_sessions (deck_id, started_at) VALUES (?, ?)",
            (deck_id, _now()),
        )
        c.commit()
        first = c.execute(
            """SELECT * FROM cards WHERE deck_id = ? AND due_date <= ?
               ORDER BY due_date ASC LIMIT 1""",
            (deck_id, _end_of_today()),
        ).fetchone()
        due_n = c.execute(
            "SELECT COUNT(*) AS n FROM cards WHERE deck_id = ? AND due_date <= ?",
            (deck_id, _end_of_today()),
        ).fetchone()["n"]
        return _ok(
            session_id=cur.lastrowid, deck_id=deck_id,
            due_count=due_n,
            next_card=_card_dict(first) if first else None,
        )
    except Exception as e:
        return _err(e)


def study_answer(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "session_id", "card_id", "quality_0_5")
        if err:
            return err
        session_id = int(vals[0])
        card_id = int(vals[1])
        quality = int(vals[2])
        if quality < 0 or quality > 5:
            return _err("quality_0_5 must be 0-5")
        c = _conn()
        sess = c.execute(
            "SELECT * FROM study_sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if not sess:
            return _err(f"session {session_id} not found")
        if sess["ended_at"] is not None:
            return _err(f"session {session_id} already ended")
        r = c.execute("SELECT * FROM cards WHERE id = ?", (card_id,)).fetchone()
        if not r:
            return _err(f"card {card_id} not found")
        upd = _sm2(r["ease"], r["interval_days"], r["reps"], r["lapses"], quality)
        c.execute(
            """UPDATE cards SET ease=?, interval_days=?, reps=?, lapses=?, due_date=?
               WHERE id=?""",
            (upd["ease"], upd["interval_days"], upd["reps"], upd["lapses"],
             upd["due_date"], card_id),
        )
        correct = 1 if quality >= 3 else 0
        c.execute(
            """UPDATE study_sessions
               SET cards_reviewed = cards_reviewed + 1,
                   cards_correct = cards_correct + ?
               WHERE id = ?""",
            (correct, session_id),
        )
        c.commit()
        # next due card in this deck not yet rescheduled past today
        nxt = c.execute(
            """SELECT * FROM cards WHERE deck_id = ? AND due_date <= ? AND id != ?
               ORDER BY due_date ASC LIMIT 1""",
            (sess["deck_id"], _end_of_today(), card_id),
        ).fetchone()
        return _ok(
            session_id=session_id, card_id=card_id, correct=bool(correct),
            next_card=_card_dict(nxt) if nxt else None,
            done=nxt is None,
        )
    except Exception as e:
        return _err(e)


def study_end(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "session_id")
        if err:
            return err
        session_id = int(vals[0])
        c = _conn()
        sess = c.execute(
            "SELECT * FROM study_sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if not sess:
            return _err(f"session {session_id} not found")
        if sess["ended_at"] is None:
            c.execute(
                "UPDATE study_sessions SET ended_at = ? WHERE id = ?",
                (_now(), session_id),
            )
            c.commit()
            sess = c.execute(
                "SELECT * FROM study_sessions WHERE id = ?", (session_id,)
            ).fetchone()
        reviewed = sess["cards_reviewed"] or 0
        correct = sess["cards_correct"] or 0
        accuracy = round(100.0 * correct / reviewed, 1) if reviewed else 0.0
        duration = None
        if sess["ended_at"] and sess["started_at"]:
            duration = round((sess["ended_at"] - sess["started_at"]) / 60.0, 1)
        return _ok(
            session_id=session_id, cards_reviewed=reviewed,
            cards_correct=correct, accuracy_pct=accuracy,
            duration_min=duration,
        )
    except Exception as e:
        return _err(e)


def study_history(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        limit = int(args.get("limit", 20) or 20)
        c = _conn()
        rs = c.execute(
            """SELECT s.*, d.name AS deck_name
               FROM study_sessions s LEFT JOIN decks d ON d.id = s.deck_id
               ORDER BY s.started_at DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        out = []
        for r in rs:
            d = dict(r)
            reviewed = d.get("cards_reviewed") or 0
            correct = d.get("cards_correct") or 0
            d["accuracy_pct"] = round(100.0 * correct / reviewed, 1) if reviewed else 0.0
            d["started_at_iso"] = _iso(d.get("started_at"))
            d["ended_at_iso"] = _iso(d.get("ended_at"))
            out.append(d)
        return _ok(sessions=out, count=len(out))
    except Exception as e:
        return _err(e)


def study_streak(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        rs = c.execute(
            "SELECT started_at FROM study_sessions ORDER BY started_at DESC"
        ).fetchall()
        days = sorted({_day_str(r["started_at"]) for r in rs if r["started_at"]},
                      reverse=True)
        if not days:
            return _ok(current_streak=0, longest_streak=0, days_studied=0,
                       last_studied=None)
        # current streak from today (or yesterday) backwards
        today = date.today()
        current = 0
        cursor = today
        day_set = set(days)
        if cursor.strftime("%Y-%m-%d") not in day_set:
            cursor = today - timedelta(days=1)
        while cursor.strftime("%Y-%m-%d") in day_set:
            current += 1
            cursor -= timedelta(days=1)
        # longest streak across all studied days
        longest = run = 1
        parsed = sorted(datetime.strptime(d, "%Y-%m-%d").date() for d in days)
        for i in range(1, len(parsed)):
            if (parsed[i] - parsed[i - 1]).days == 1:
                run += 1
            else:
                run = 1
            longest = max(longest, run)
        return _ok(
            current_streak=current, longest_streak=longest,
            days_studied=len(days), last_studied=days[0],
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# COURSES
# ──────────────────────────────────────────────────────────────────────────

_COURSE_STATUSES = {"not_started", "in_progress", "completed", "dropped"}


def course_add(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "name")
        if err:
            return err
        name = vals[0]
        c = _conn()
        cur = c.execute(
            """INSERT INTO courses (name, provider, url, status, progress_pct,
                                    target_date, notes)
               VALUES (?, ?, ?, 'not_started', 0, ?, ?)""",
            (name, args.get("provider"), args.get("url"),
             args.get("target_date"), args.get("notes")),
        )
        c.commit()
        return _ok(course_id=cur.lastrowid, name=name)
    except Exception as e:
        return _err(e)


def course_list(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        status = args.get("status")
        c = _conn()
        if status:
            if status not in _COURSE_STATUSES:
                return _err(f"status must be one of {sorted(_COURSE_STATUSES)}")
            rs = c.execute(
                "SELECT * FROM courses WHERE status = ? ORDER BY id DESC", (status,)
            ).fetchall()
        else:
            rs = c.execute("SELECT * FROM courses ORDER BY id DESC").fetchall()
        out = _rows(rs)
        for r in out:
            r["started_at_iso"] = _iso(r.get("started_at"))
        return _ok(courses=out, count=len(out))
    except Exception as e:
        return _err(e)


def course_update_progress(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "course_id", "progress_pct")
        if err:
            return err
        course_id = int(vals[0])
        pct = max(0.0, min(100.0, float(vals[1])))
        c = _conn()
        r = c.execute("SELECT * FROM courses WHERE id = ?", (course_id,)).fetchone()
        if not r:
            return _err(f"course {course_id} not found")
        status = r["status"]
        started = r["started_at"]
        if pct >= 100:
            status = "completed"
        elif pct > 0 and status in ("not_started", "dropped"):
            status = "in_progress"
        if started is None and pct > 0:
            started = _now()
        c.execute(
            "UPDATE courses SET progress_pct=?, status=?, started_at=? WHERE id=?",
            (pct, status, started, course_id),
        )
        c.commit()
        return _ok(course_id=course_id, progress_pct=pct, status=status)
    except Exception as e:
        return _err(e)


def course_complete(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "course_id")
        if err:
            return err
        course_id = int(vals[0])
        c = _conn()
        r = c.execute("SELECT * FROM courses WHERE id = ?", (course_id,)).fetchone()
        if not r:
            return _err(f"course {course_id} not found")
        started = r["started_at"] or _now()
        c.execute(
            """UPDATE courses SET status='completed', progress_pct=100,
                                  started_at=? WHERE id=?""",
            (started, course_id),
        )
        c.commit()
        return _ok(course_id=course_id, status="completed", progress_pct=100)
    except Exception as e:
        return _err(e)


def courses_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        rs = c.execute("SELECT status, progress_pct FROM courses").fetchall()
        counts = {s: 0 for s in _COURSE_STATUSES}
        total_pct = 0.0
        for r in rs:
            st = r["status"] if r["status"] in counts else "not_started"
            counts[st] += 1
            total_pct += r["progress_pct"] or 0
        n = len(rs)
        return _ok(
            total=n,
            by_status=counts,
            avg_progress_pct=round(total_pct / n, 1) if n else 0.0,
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SKILLS
# ──────────────────────────────────────────────────────────────────────────


def skill_add(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "name")
        if err:
            return err
        name = vals[0]
        current = int(args.get("current_level", 1) or 1)
        target = int(args.get("target_level", 10) or 10)
        c = _conn()
        cur = c.execute(
            """INSERT INTO skills (name, current_level, target_level, notes)
               VALUES (?, ?, ?, ?)""",
            (name, current, target, args.get("notes")),
        )
        c.commit()
        return _ok(skill_id=cur.lastrowid, name=name,
                   current_level=current, target_level=target)
    except Exception as e:
        return _err(e)


def skill_log_practice(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "skill_id", "hours")
        if err:
            return err
        skill_id = int(vals[0])
        hours = float(vals[1])
        if hours <= 0:
            return _err("hours must be positive")
        c = _conn()
        r = c.execute("SELECT * FROM skills WHERE id = ?", (skill_id,)).fetchone()
        if not r:
            return _err(f"skill {skill_id} not found")
        total = (r["hours_practiced"] or 0) + hours
        notes = args.get("notes")
        merged = r["notes"]
        if notes:
            stamp = datetime.now().strftime("%Y-%m-%d")
            line = f"[{stamp}] {notes}"
            merged = f"{merged}\n{line}" if merged else line
        c.execute(
            "UPDATE skills SET hours_practiced=?, last_practiced=?, notes=? WHERE id=?",
            (total, _now(), merged, skill_id),
        )
        c.commit()
        return _ok(skill_id=skill_id, hours_added=hours,
                   total_hours=round(total, 2))
    except Exception as e:
        return _err(e)


def skill_list(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        rs = c.execute("SELECT * FROM skills ORDER BY name ASC").fetchall()
        out = []
        for r in rs:
            d = dict(r)
            cur = d.get("current_level") or 0
            tgt = d.get("target_level") or 0
            d["pct_to_target"] = round(100.0 * cur / tgt, 1) if tgt else 0.0
            d["last_practiced_iso"] = _iso(d.get("last_practiced"))
            out.append(d)
        return _ok(skills=out, count=len(out))
    except Exception as e:
        return _err(e)


def skill_level_up(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "skill_id")
        if err:
            return err
        skill_id = int(vals[0])
        c = _conn()
        r = c.execute("SELECT * FROM skills WHERE id = ?", (skill_id,)).fetchone()
        if not r:
            return _err(f"skill {skill_id} not found")
        new_level = (r["current_level"] or 0) + 1
        c.execute(
            "UPDATE skills SET current_level=? WHERE id=?", (new_level, skill_id)
        )
        c.commit()
        reached = new_level >= (r["target_level"] or 0)
        return _ok(skill_id=skill_id, current_level=new_level,
                   target_level=r["target_level"], target_reached=reached)
    except Exception as e:
        return _err(e)


def skill_progress(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "skill_id")
        if err:
            return err
        skill_id = int(vals[0])
        c = _conn()
        r = c.execute("SELECT * FROM skills WHERE id = ?", (skill_id,)).fetchone()
        if not r:
            return _err(f"skill {skill_id} not found")
        cur = r["current_level"] or 0
        tgt = r["target_level"] or 0
        return _ok(
            skill_id=skill_id, name=r["name"],
            current_level=cur, target_level=tgt,
            hours_practiced=round(r["hours_practiced"] or 0, 2),
            pct_to_target=round(100.0 * cur / tgt, 1) if tgt else 0.0,
            levels_remaining=max(0, tgt - cur),
            last_practiced=_iso(r["last_practiced"]),
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# READING LIST
# ──────────────────────────────────────────────────────────────────────────

_READING_STATUSES = {"to_read", "reading", "finished", "abandoned"}
_READING_TYPES = {"book", "article", "paper", "course"}


def reading_add(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "title")
        if err:
            return err
        title = vals[0]
        rtype = args.get("type", "book") or "book"
        if rtype not in _READING_TYPES:
            return _err(f"type must be one of {sorted(_READING_TYPES)}")
        c = _conn()
        cur = c.execute(
            """INSERT INTO reading_list (title, author, type, status, progress_pct,
                                         notes)
               VALUES (?, ?, ?, 'to_read', 0, ?)""",
            (title, args.get("author"), rtype, args.get("notes")),
        )
        c.commit()
        return _ok(item_id=cur.lastrowid, title=title, type=rtype)
    except Exception as e:
        return _err(e)


def reading_list_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        status = args.get("status")
        c = _conn()
        if status:
            if status not in _READING_STATUSES:
                return _err(f"status must be one of {sorted(_READING_STATUSES)}")
            rs = c.execute(
                "SELECT * FROM reading_list WHERE status = ? ORDER BY id DESC",
                (status,),
            ).fetchall()
        else:
            rs = c.execute("SELECT * FROM reading_list ORDER BY id DESC").fetchall()
        out = _rows(rs)
        for r in out:
            r["added_at_iso"] = _iso(r.get("added_at"))
            r["finished_at_iso"] = _iso(r.get("finished_at"))
        return _ok(items=out, count=len(out))
    except Exception as e:
        return _err(e)


def reading_update_progress(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "item_id", "progress_pct")
        if err:
            return err
        item_id = int(vals[0])
        pct = max(0.0, min(100.0, float(vals[1])))
        c = _conn()
        r = c.execute(
            "SELECT * FROM reading_list WHERE id = ?", (item_id,)
        ).fetchone()
        if not r:
            return _err(f"reading item {item_id} not found")
        status = r["status"]
        finished_at = r["finished_at"]
        if pct >= 100:
            status = "finished"
            finished_at = finished_at or _now()
        elif pct > 0 and status in ("to_read", "abandoned"):
            status = "reading"
        c.execute(
            """UPDATE reading_list SET progress_pct=?, status=?, finished_at=?
               WHERE id=?""",
            (pct, status, finished_at, item_id),
        )
        c.commit()
        return _ok(item_id=item_id, progress_pct=pct, status=status)
    except Exception as e:
        return _err(e)


def reading_finish(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "item_id")
        if err:
            return err
        item_id = int(vals[0])
        rating = args.get("rating")
        if rating is not None:
            rating = float(rating)
            if rating < 0 or rating > 5:
                return _err("rating must be 0-5")
        c = _conn()
        r = c.execute(
            "SELECT * FROM reading_list WHERE id = ?", (item_id,)
        ).fetchone()
        if not r:
            return _err(f"reading item {item_id} not found")
        c.execute(
            """UPDATE reading_list SET status='finished', progress_pct=100,
                                       finished_at=?, rating=COALESCE(?, rating)
               WHERE id=?""",
            (_now(), rating, item_id),
        )
        c.commit()
        return _ok(item_id=item_id, status="finished", rating=rating)
    except Exception as e:
        return _err(e)


def reading_stats(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        rs = c.execute("SELECT * FROM reading_list").fetchall()
        year = date.today().year
        year_start = datetime(year, 1, 1).timestamp()
        finished_year = 0
        in_progress = 0
        to_read = 0
        ratings: List[float] = []
        for r in rs:
            st = r["status"]
            if st == "finished":
                if r["finished_at"] and r["finished_at"] >= year_start:
                    finished_year += 1
                if r["rating"] is not None:
                    ratings.append(r["rating"])
            elif st == "reading":
                in_progress += 1
            elif st == "to_read":
                to_read += 1
        return _ok(
            total=len(rs),
            finished_this_year=finished_year,
            in_progress=in_progress,
            to_read=to_read,
            avg_rating=round(sum(ratings) / len(ratings), 2) if ratings else None,
            year=year,
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# QUIZ / KNOWLEDGE CHECK
# ──────────────────────────────────────────────────────────────────────────


def quiz_from_deck(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "deck_id")
        if err:
            return err
        deck_id = int(vals[0])
        count = int(args.get("count", 10) or 10)
        c = _conn()
        deck = c.execute("SELECT * FROM decks WHERE id = ?", (deck_id,)).fetchone()
        if not deck:
            return _err(f"deck {deck_id} not found")
        rs = c.execute(
            "SELECT id, front, back FROM cards WHERE deck_id = ?", (deck_id,)
        ).fetchall()
        if not rs:
            return _err(f"deck {deck_id} has no cards")
        pool = _rows(rs)
        random.shuffle(pool)
        quiz = pool[:max(1, count)]
        for i, q in enumerate(quiz, 1):
            q["number"] = i
        return _ok(deck_id=deck_id, deck_name=deck["name"],
                   questions=quiz, count=len(quiz))
    except Exception as e:
        return _err(e)


def knowledge_check(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        vals, err = _require(args, "topic")
        if err:
            return err
        topic = vals[0]
        prompt = (
            f"Generate exactly 3 quiz questions to test understanding of "
            f"'{topic}'. Mix recall and application. For each, give the "
            f"question and a concise model answer."
        )
        key = os.environ.get("ANTHROPIC_API_KEY")
        if key:
            anthropic = _try_import("anthropic")
            if anthropic is not None:
                try:
                    client = anthropic.Anthropic(api_key=key)
                    msg = client.messages.create(
                        model="claude-haiku-4-5",
                        max_tokens=800,
                        messages=[{"role": "user", "content": prompt}],
                    )
                    text = "".join(
                        b.text for b in msg.content if getattr(b, "type", "") == "text"
                    )
                    return _ok(topic=topic, source="anthropic", questions=text)
                except Exception as e:
                    # fall through to templated prompt
                    return _ok(
                        topic=topic, source="template",
                        note=f"AI call failed ({e}); use prompt manually",
                        prompt=prompt,
                    )
        okey = os.environ.get("OPENAI_API_KEY")
        if okey:
            openai = _try_import("openai")
            if openai is not None:
                try:
                    client = openai.OpenAI(api_key=okey)
                    res = client.chat.completions.create(
                        model="gpt-4o-mini",
                        max_tokens=800,
                        messages=[{"role": "user", "content": prompt}],
                    )
                    return _ok(topic=topic, source="openai",
                               questions=res.choices[0].message.content)
                except Exception as e:
                    return _ok(
                        topic=topic, source="template",
                        note=f"AI call failed ({e}); use prompt manually",
                        prompt=prompt,
                    )
        return _ok(
            topic=topic, source="template",
            note="No ANTHROPIC_API_KEY/OPENAI_API_KEY set — feed this prompt "
                 "to Leon's claude CLI to generate the quiz.",
            prompt=prompt,
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CONVENIENCE
# ──────────────────────────────────────────────────────────────────────────


def daily_review(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        cutoff = _end_of_today()
        rs = c.execute(
            """SELECT d.id, d.name,
                   (SELECT COUNT(*) FROM cards
                      WHERE deck_id = d.id AND due_date <= ?) AS due
               FROM decks d ORDER BY d.name ASC""",
            (cutoff,),
        ).fetchall()
        per_deck = [
            {"deck_id": r["id"], "name": r["name"], "due": r["due"]}
            for r in rs if r["due"] > 0
        ]
        total_due = sum(d["due"] for d in per_deck)
        streak = study_streak({})
        cur_streak = streak.get("current_streak", 0) if streak.get("ok") else 0
        # rough pace: ~10s/card review, suggest in minutes, capped 45
        suggested_min = min(45, max(5, round(total_due * 10 / 60)))
        if total_due == 0:
            suggestion = "Nothing due — optionally review a deck ahead or add new cards."
        else:
            suggestion = (
                f"{total_due} cards due across {len(per_deck)} deck(s). "
                f"Plan ~{suggested_min} min."
            )
        return _ok(
            total_due=total_due,
            decks=per_deck,
            current_streak=cur_streak,
            suggested_session_min=suggested_min,
            suggestion=suggestion,
        )
    except Exception as e:
        return _err(e)


def weekly_learning_report(args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        c = _conn()
        week_ago = _now() - 7 * 86400.0
        # study sessions in last 7 days
        sess = c.execute(
            "SELECT * FROM study_sessions WHERE started_at >= ?", (week_ago,)
        ).fetchall()
        reviewed = sum(s["cards_reviewed"] or 0 for s in sess)
        correct = sum(s["cards_correct"] or 0 for s in sess)
        accuracy = round(100.0 * correct / reviewed, 1) if reviewed else 0.0
        streak = study_streak({})
        cur_streak = streak.get("current_streak", 0) if streak.get("ok") else 0

        # courses
        courses = c.execute("SELECT * FROM courses").fetchall()
        active_courses = [r for r in courses if r["status"] == "in_progress"]
        done_courses = [r for r in courses if r["status"] == "completed"]

        # skills practiced this week
        skills = c.execute(
            "SELECT * FROM skills WHERE last_practiced >= ?", (week_ago,)
        ).fetchall()

        # reading finished this week
        reading_done = c.execute(
            "SELECT * FROM reading_list WHERE status='finished' AND finished_at >= ?",
            (week_ago,),
        ).fetchall()
        reading_active = c.execute(
            "SELECT * FROM reading_list WHERE status='reading'"
        ).fetchall()

        lines: List[str] = []
        lines.append("# Weekly Learning Report")
        lines.append(f"_Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}_")
        lines.append("")
        lines.append("## Flashcards")
        lines.append(f"- Study sessions: **{len(sess)}**")
        lines.append(f"- Cards reviewed: **{reviewed}** (accuracy {accuracy}%)")
        lines.append(f"- Current study streak: **{cur_streak} day(s)**")
        lines.append("")
        lines.append("## Courses")
        if active_courses:
            for r in active_courses:
                lines.append(
                    f"- *{r['name']}* — {round(r['progress_pct'] or 0)}% "
                    f"({r['provider'] or 'n/a'})"
                )
        else:
            lines.append("- No courses in progress")
        if done_courses:
            lines.append(f"- Completed total: **{len(done_courses)}**")
        lines.append("")
        lines.append("## Skills practiced this week")
        if skills:
            for r in skills:
                lines.append(
                    f"- {r['name']} — level {r['current_level']}/{r['target_level']}, "
                    f"{round(r['hours_practiced'] or 0, 1)}h total"
                )
        else:
            lines.append("- No skill practice logged")
        lines.append("")
        lines.append("## Reading")
        lines.append(f"- Finished this week: **{len(reading_done)}**")
        for r in reading_done:
            rating = f" ({r['rating']}/5)" if r["rating"] is not None else ""
            lines.append(f"  - {r['title']} — {r['author'] or 'unknown'}{rating}")
        lines.append(f"- Currently reading: **{len(reading_active)}**")
        for r in reading_active:
            lines.append(
                f"  - {r['title']} — {round(r['progress_pct'] or 0)}%"
            )
        markdown = "\n".join(lines)
        return _ok(
            markdown=markdown,
            summary={
                "sessions": len(sess),
                "cards_reviewed": reviewed,
                "accuracy_pct": accuracy,
                "current_streak": cur_streak,
                "active_courses": len(active_courses),
                "skills_practiced": len(skills),
                "reading_finished": len(reading_done),
            },
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # flashcards — decks
    "learn.deck_create": deck_create,
    "learn.deck_list": deck_list,
    "learn.deck_delete": deck_delete,
    # flashcards — cards
    "learn.card_add": card_add,
    "learn.card_add_bulk": card_add_bulk,
    "learn.cards_due": cards_due,
    "learn.card_review": card_review,
    "learn.deck_stats": deck_stats,
    "learn.card_edit": card_edit,
    "learn.card_delete": card_delete,
    # study sessions
    "learn.study_start": study_start,
    "learn.study_answer": study_answer,
    "learn.study_end": study_end,
    "learn.study_history": study_history,
    "learn.study_streak": study_streak,
    # courses
    "learn.course_add": course_add,
    "learn.course_list": course_list,
    "learn.course_update_progress": course_update_progress,
    "learn.course_complete": course_complete,
    "learn.courses_summary": courses_summary,
    # skills
    "learn.skill_add": skill_add,
    "learn.skill_log_practice": skill_log_practice,
    "learn.skill_list": skill_list,
    "learn.skill_level_up": skill_level_up,
    "learn.skill_progress": skill_progress,
    # reading list
    "learn.reading_add": reading_add,
    "learn.reading_list": reading_list_tool,
    "learn.reading_update_progress": reading_update_progress,
    "learn.reading_finish": reading_finish,
    "learn.reading_stats": reading_stats,
    # quiz / knowledge check
    "learn.quiz_from_deck": quiz_from_deck,
    "learn.knowledge_check": knowledge_check,
    # convenience
    "learn.daily_review": daily_review,
    "learn.weekly_learning_report": weekly_learning_report,
}
