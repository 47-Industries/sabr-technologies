"""
netsys.py — Leon's networking + system-deep diagnostics tool surface.

This module gives Leon the ability to introspect the *machine's* network
and hardware state: DNS lookups, whois, ping/traceroute, port checks,
Wi-Fi (NetworkManager), Bluetooth scan/pair info, PulseAudio mixer state,
screen brightness, DPMS, and power / thermal summary.

Everything shells out via `subprocess` with hard timeouts and reports
"tool not installed" gracefully when a binary is missing — there is no
hard dependency on any single network tool. Privileged operations
(packet capture, low-level scanning) are avoided: traceroute prefers
`mtr -r` (unprivileged on most distros) or falls back to `traceroute`;
"port scan local" reads currently-listening sockets via `ss` rather than
actually scanning the loopback range.

Each tool is a function taking a single `args` dict and returning either
`{"ok": True, ...}` or `{"ok": False, "error": "..."}`. The EXTRA_TOOLS
dict at the bottom maps dotted tool names (e.g. `net.dns_lookup`,
`sys.audio_volume_get`) to the implementing function — import this dict
from the responder / MCP server to register them in one shot.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import time
import urllib.request
import urllib.error
from typing import Any, Callable, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# SHELL HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _have(binary: str) -> bool:
    """Return True if `binary` is on PATH."""
    return shutil.which(binary) is not None


def _run(
    cmd: List[str],
    timeout: float = 10.0,
    input_text: Optional[str] = None,
) -> Tuple[int, str, str]:
    """Run `cmd` and return (returncode, stdout, stderr). Never raises on
    non-zero exit. Raises on missing binary (callers should _have() first)."""
    try:
        proc = subprocess.run(
            cmd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: not installed"


def _missing(binary: str) -> Dict[str, Any]:
    return {"ok": False, "error": f"{binary} not installed"}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _http_get_json(url: str, timeout: float = 5.0) -> Optional[Any]:
    """GET a JSON URL, return parsed JSON or None on any failure."""
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Leon/1.0", "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError, socket.timeout, Exception):
        return None


def _http_get_text(url: str, timeout: float = 5.0) -> Optional[str]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Leon/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────────────────
# DNS / DOMAIN
# ──────────────────────────────────────────────────────────────────────────


def _parse_dig_short(output: str) -> List[str]:
    """Parse `dig +short` output into a list of records, skipping blanks
    and CNAME chain intermediates that don't resolve to a final value."""
    lines = [ln.strip() for ln in output.splitlines() if ln.strip()]
    return lines


def dns_lookup(args: dict) -> dict:
    hostname = (args or {}).get("hostname")
    record_type = ((args or {}).get("record_type") or "A").upper()
    if not hostname:
        return _err("hostname required")

    if _have("dig"):
        rc, out, errout = _run(
            ["dig", "+short", "+time=3", "+tries=1", hostname, record_type],
            timeout=8.0,
        )
        if rc == 0:
            records = _parse_dig_short(out)
            return {
                "ok": True,
                "hostname": hostname,
                "record_type": record_type,
                "records": records,
                "source": "dig",
            }
        # dig failed — fall through to stdlib if it's a basic A/AAAA query

    # stdlib fallback only handles A / AAAA (no MX/TXT/etc)
    if record_type not in ("A", "AAAA"):
        return _err(f"dig not installed; stdlib fallback only supports A/AAAA, not {record_type}")
    family = socket.AF_INET if record_type == "A" else socket.AF_INET6
    try:
        infos = socket.getaddrinfo(hostname, None, family=family, type=socket.SOCK_STREAM)
        records = sorted({info[4][0] for info in infos})
        return {
            "ok": True,
            "hostname": hostname,
            "record_type": record_type,
            "records": records,
            "source": "socket",
        }
    except socket.gaierror as e:
        return _err(f"resolution failed: {e}")


def reverse_dns(args: dict) -> dict:
    ip = (args or {}).get("ip")
    if not ip:
        return _err("ip required")
    try:
        host, _aliases, _addrs = socket.gethostbyaddr(ip)
        return {"ok": True, "ip": ip, "hostname": host}
    except socket.herror as e:
        return _err(f"no PTR record: {e}")
    except socket.gaierror as e:
        return _err(f"invalid ip: {e}")


def whois_lookup(args: dict) -> dict:
    domain = (args or {}).get("domain")
    if not domain:
        return _err("domain required")

    if _have("whois"):
        rc, out, errout = _run(["whois", domain], timeout=15.0)
        if rc == 0 and out.strip():
            return {"ok": True, "domain": domain, "raw": out, "source": "whois"}
        # fall through to RDAP if whois empty

    # RDAP fallback — public, no auth needed
    data = _http_get_json(f"https://rdap.org/domain/{domain}", timeout=8.0)
    if data is None:
        return _err("whois not installed and RDAP query failed")
    return {"ok": True, "domain": domain, "rdap": data, "source": "rdap"}


def dns_check_propagation(args: dict) -> dict:
    """Query 5 public resolvers and report inconsistency. Uses `dig @resolver`
    if dig is installed; otherwise reports unavailable (stdlib can't pick
    resolver portably)."""
    hostname = (args or {}).get("hostname")
    expected = (args or {}).get("expected_value")
    if not hostname:
        return _err("hostname required")
    if not _have("dig"):
        return _missing("dig")

    resolvers = [
        ("cloudflare", "1.1.1.1"),
        ("google", "8.8.8.8"),
        ("quad9", "9.9.9.9"),
        ("opendns", "208.67.222.222"),
        ("level3", "4.2.2.2"),
    ]
    results: Dict[str, List[str]] = {}
    for name, ip in resolvers:
        rc, out, _ = _run(
            ["dig", f"@{ip}", "+short", "+time=3", "+tries=1", hostname, "A"],
            timeout=6.0,
        )
        results[name] = _parse_dig_short(out) if rc == 0 else []

    all_seen = {tuple(sorted(v)) for v in results.values() if v}
    consistent = len(all_seen) <= 1
    matches_expected: Optional[Dict[str, bool]] = None
    if expected is not None:
        matches_expected = {
            name: (expected in recs) for name, recs in results.items()
        }
    return {
        "ok": True,
        "hostname": hostname,
        "results": results,
        "consistent": consistent,
        "expected_value": expected,
        "matches_expected": matches_expected,
    }


# ──────────────────────────────────────────────────────────────────────────
# CONNECTIVITY
# ──────────────────────────────────────────────────────────────────────────


_PING_RTT_RE = re.compile(
    r"min/avg/max(?:/mdev)?\s*=\s*([\d.]+)/([\d.]+)/([\d.]+)"
)
_PING_LOSS_RE = re.compile(r"(\d+(?:\.\d+)?)%\s*packet\s*loss")


def ping(args: dict) -> dict:
    host = (args or {}).get("host")
    count = int((args or {}).get("count", 4))
    timeout = int((args or {}).get("timeout", 2))
    if not host:
        return _err("host required")
    if not _have("ping"):
        return _missing("ping")

    rc, out, errout = _run(
        ["ping", "-c", str(count), "-W", str(timeout), host],
        timeout=(count * timeout) + 5,
    )
    rtt = _PING_RTT_RE.search(out)
    loss = _PING_LOSS_RE.search(out)
    parsed: Dict[str, Any] = {
        "host": host,
        "count": count,
        "returncode": rc,
    }
    if rtt:
        parsed["rtt_min_ms"] = float(rtt.group(1))
        parsed["rtt_avg_ms"] = float(rtt.group(2))
        parsed["rtt_max_ms"] = float(rtt.group(3))
    if loss:
        parsed["packet_loss_pct"] = float(loss.group(1))
    if rc != 0 and not rtt:
        return {"ok": False, "error": errout.strip() or out.strip() or "ping failed", **parsed}
    return {"ok": True, **parsed}


def traceroute(args: dict) -> dict:
    host = (args or {}).get("host")
    max_hops = int((args or {}).get("max_hops", 20))
    if not host:
        return _err("host required")

    if _have("mtr"):
        rc, out, errout = _run(
            ["mtr", "-r", "-c", "1", "-m", str(max_hops), host],
            timeout=max_hops * 3 + 10,
        )
        if rc == 0:
            return {"ok": True, "host": host, "raw": out, "source": "mtr"}
        return _err(f"mtr failed: {errout.strip() or out.strip()}")

    if _have("traceroute"):
        rc, out, errout = _run(
            ["traceroute", "-n", "-m", str(max_hops), host],
            timeout=max_hops * 3 + 10,
        )
        if rc == 0:
            return {"ok": True, "host": host, "raw": out, "source": "traceroute"}
        return _err(f"traceroute failed: {errout.strip() or out.strip()}")

    return _err("neither mtr nor traceroute installed")


def public_ip(args: dict) -> dict:
    """Public IP as seen from the outside, for the netsys mental model.
    Tries a few HTTPS endpoints with short timeouts."""
    endpoints = [
        "https://api.ipify.org",
        "https://ifconfig.me/ip",
        "https://ipv4.icanhazip.com",
    ]
    for url in endpoints:
        txt = _http_get_text(url, timeout=4.0)
        if txt:
            ip = txt.strip().splitlines()[0].strip()
            if ip:
                return {"ok": True, "public_ip": ip, "source": url}
    return _err("all public-ip endpoints failed")


def port_check(args: dict) -> dict:
    host = (args or {}).get("host")
    port = (args or {}).get("port")
    timeout = float((args or {}).get("timeout", 2))
    if not host or port is None:
        return _err("host and port required")
    try:
        port = int(port)
    except (TypeError, ValueError):
        return _err("port must be integer")

    t0 = time.time()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            elapsed_ms = round((time.time() - t0) * 1000, 2)
            return {
                "ok": True,
                "host": host,
                "port": port,
                "state": "open",
                "elapsed_ms": elapsed_ms,
            }
    except socket.timeout:
        return {"ok": True, "host": host, "port": port, "state": "filtered"}
    except ConnectionRefusedError:
        return {"ok": True, "host": host, "port": port, "state": "closed"}
    except OSError as e:
        return {"ok": True, "host": host, "port": port, "state": "error", "detail": str(e)}


def _parse_ss_listen(output: str) -> List[Dict[str, Any]]:
    """Parse `ss -tulnp` output into a list of listening sockets."""
    rows: List[Dict[str, Any]] = []
    for line in output.splitlines()[1:]:  # skip header
        parts = line.split()
        if len(parts) < 5:
            continue
        proto = parts[0].lower()
        local = parts[4]
        # local is host:port — port is after last ':'
        if ":" not in local:
            continue
        port_str = local.rsplit(":", 1)[1]
        try:
            port = int(port_str)
        except ValueError:
            continue
        proc_info = " ".join(parts[6:]) if len(parts) > 6 else ""
        rows.append({
            "proto": proto,
            "local": local,
            "port": port,
            "process": proc_info,
        })
    return rows


def port_scan_local(args: dict) -> dict:
    start = int((args or {}).get("start", 1))
    end = int((args or {}).get("end", 1024))
    if not _have("ss"):
        return _missing("ss")
    rc, out, errout = _run(["ss", "-tulnH"], timeout=5.0)
    # -H may not be supported on older ss; fall back to -tuln
    if rc != 0:
        rc, out, errout = _run(["ss", "-tuln"], timeout=5.0)
        if rc != 0:
            return _err(f"ss failed: {errout.strip()}")
    rows = _parse_ss_listen(out) if "Local" in out.splitlines()[0] else _parse_ss_listen("HDR\n" + out)
    in_range = [r for r in rows if start <= r["port"] <= end]
    return {
        "ok": True,
        "range": [start, end],
        "listening": in_range,
        "total_listening": len(rows),
    }


# ──────────────────────────────────────────────────────────────────────────
# NETWORKMANAGER / WI-FI
# ──────────────────────────────────────────────────────────────────────────


def wifi_list_networks(args: dict) -> dict:
    if not _have("nmcli"):
        return _missing("nmcli")
    rc, out, errout = _run(
        ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi"],
        timeout=10.0,
    )
    if rc != 0:
        return _err(f"nmcli failed: {errout.strip() or out.strip()}")
    networks: List[Dict[str, Any]] = []
    for line in out.splitlines():
        if not line.strip():
            continue
        # nmcli -t uses ':' as separator; escape with '\:' so split with care
        parts = re.split(r"(?<!\\):", line)
        parts = [p.replace("\\:", ":") for p in parts]
        if len(parts) < 2:
            continue
        ssid = parts[0]
        if not ssid:
            continue  # hidden network
        try:
            signal = int(parts[1])
        except (ValueError, IndexError):
            signal = None
        security = parts[2] if len(parts) > 2 else ""
        networks.append({"ssid": ssid, "signal": signal, "security": security})
    return {"ok": True, "networks": networks, "count": len(networks)}


def wifi_current(args: dict) -> dict:
    if not _have("nmcli"):
        return _missing("nmcli")
    rc, out, errout = _run(
        ["nmcli", "-t", "-f", "NAME,TYPE,DEVICE", "con", "show", "--active"],
        timeout=5.0,
    )
    if rc != 0:
        return _err(f"nmcli failed: {errout.strip()}")
    active: List[Dict[str, str]] = []
    for line in out.splitlines():
        parts = re.split(r"(?<!\\):", line)
        if len(parts) >= 3:
            active.append({
                "name": parts[0].replace("\\:", ":"),
                "type": parts[1],
                "device": parts[2],
            })
    wifi = [a for a in active if "wireless" in a["type"]]
    return {
        "ok": True,
        "active_connections": active,
        "wifi": wifi[0] if wifi else None,
    }


def wifi_disconnect(args: dict) -> dict:
    """MEDIUM risk — disconnects the currently active wireless connection."""
    if not _have("nmcli"):
        return _missing("nmcli")
    current = wifi_current({})
    if not current.get("ok") or not current.get("wifi"):
        return _err("no active wifi connection found")
    name = current["wifi"]["name"]
    rc, out, errout = _run(["nmcli", "con", "down", "id", name], timeout=10.0)
    if rc != 0:
        return _err(f"disconnect failed: {errout.strip() or out.strip()}")
    return {"ok": True, "disconnected": name, "risk": "medium"}


def network_interfaces(args: dict) -> dict:
    if not _have("ip"):
        return _missing("ip")
    rc, out, errout = _run(["ip", "-j", "addr"], timeout=5.0)
    if rc != 0:
        return _err(f"ip addr failed: {errout.strip()}")
    try:
        data = json.loads(out)
    except json.JSONDecodeError as e:
        return _err(f"failed to parse ip json: {e}")
    return {"ok": True, "interfaces": data, "count": len(data)}


# ──────────────────────────────────────────────────────────────────────────
# BLUETOOTH
# ──────────────────────────────────────────────────────────────────────────


_BT_DEVICE_RE = re.compile(r"Device\s+([0-9A-Fa-f:]{17})\s+(.+)")


def bluetooth_scan(args: dict) -> dict:
    duration = int((args or {}).get("duration_sec", 8))
    if not _have("bluetoothctl"):
        return _missing("bluetoothctl")
    # Use --timeout to scan for N seconds non-interactively
    rc, out, errout = _run(
        ["bluetoothctl", "--timeout", str(duration), "scan", "on"],
        timeout=duration + 10,
    )
    # Even on success bluetoothctl may not return 0; still parse output.
    devices: List[Dict[str, str]] = []
    seen = set()
    for line in out.splitlines():
        m = _BT_DEVICE_RE.search(line)
        if m:
            mac, name = m.group(1), m.group(2).strip()
            if mac not in seen:
                seen.add(mac)
                devices.append({"mac": mac, "name": name})
    return {
        "ok": True,
        "duration_sec": duration,
        "devices": devices,
        "count": len(devices),
    }


def bluetooth_paired_list(args: dict) -> dict:
    if not _have("bluetoothctl"):
        return _missing("bluetoothctl")
    rc, out, errout = _run(["bluetoothctl", "devices", "Paired"], timeout=5.0)
    if rc != 0:
        # older bluetoothctl uses just `devices` for paired
        rc, out, errout = _run(["bluetoothctl", "paired-devices"], timeout=5.0)
        if rc != 0:
            return _err(f"bluetoothctl failed: {errout.strip()}")
    devices: List[Dict[str, str]] = []
    for line in out.splitlines():
        m = _BT_DEVICE_RE.search(line)
        if m:
            devices.append({"mac": m.group(1), "name": m.group(2).strip()})
    return {"ok": True, "paired": devices, "count": len(devices)}


def bluetooth_connect(args: dict) -> dict:
    """MEDIUM risk — initiates a bluetooth connection."""
    mac = (args or {}).get("device_mac")
    if not mac:
        return _err("device_mac required")
    if not _have("bluetoothctl"):
        return _missing("bluetoothctl")
    rc, out, errout = _run(["bluetoothctl", "connect", mac], timeout=15.0)
    success = "Connection successful" in out or rc == 0
    return {
        "ok": success,
        "device_mac": mac,
        "raw": out.strip(),
        "risk": "medium",
        **({"error": errout.strip() or out.strip()} if not success else {}),
    }


# ──────────────────────────────────────────────────────────────────────────
# AUDIO (PulseAudio / PipeWire via pactl)
# ──────────────────────────────────────────────────────────────────────────


_VOLUME_RE = re.compile(r"(\d+)%")


def audio_volume_get(args: dict) -> dict:
    if not _have("pactl"):
        return _missing("pactl")
    rc, out, errout = _run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"], timeout=3.0)
    if rc != 0:
        return _err(f"pactl failed: {errout.strip() or out.strip()}")
    matches = _VOLUME_RE.findall(out)
    pct = int(matches[0]) if matches else None

    # also fetch mute state
    rc2, out2, _ = _run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"], timeout=3.0)
    muted = "yes" in out2.lower() if rc2 == 0 else None

    return {"ok": True, "volume_pct": pct, "muted": muted, "raw": out.strip()}


def audio_volume_set(args: dict) -> dict:
    """MEDIUM risk — changes system audio volume."""
    percent = (args or {}).get("percent")
    if percent is None:
        return _err("percent required")
    try:
        pct = int(percent)
    except (TypeError, ValueError):
        return _err("percent must be integer 0-150")
    if pct < 0 or pct > 150:
        return _err("percent out of range (0-150)")
    if not _have("pactl"):
        return _missing("pactl")
    rc, out, errout = _run(
        ["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{pct}%"],
        timeout=3.0,
    )
    if rc != 0:
        return _err(f"pactl failed: {errout.strip() or out.strip()}")
    return {"ok": True, "volume_pct": pct, "risk": "medium"}


def audio_mute_toggle(args: dict) -> dict:
    if not _have("pactl"):
        return _missing("pactl")
    rc, out, errout = _run(
        ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"],
        timeout=3.0,
    )
    if rc != 0:
        return _err(f"pactl failed: {errout.strip() or out.strip()}")
    # report new state
    rc2, out2, _ = _run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"], timeout=3.0)
    muted = "yes" in out2.lower() if rc2 == 0 else None
    return {"ok": True, "muted": muted}


def _parse_pactl_list(output: str, kind: str) -> List[Dict[str, str]]:
    """Parse `pactl list short sinks|sources` into [{index, name, driver, ...}]."""
    rows: List[Dict[str, str]] = []
    for line in output.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2:
            rows.append({
                "index": parts[0],
                "name": parts[1],
                "driver": parts[2] if len(parts) > 2 else "",
                "spec": parts[3] if len(parts) > 3 else "",
                "state": parts[4] if len(parts) > 4 else "",
                "kind": kind,
            })
    return rows


def audio_list_sinks(args: dict) -> dict:
    if not _have("pactl"):
        return _missing("pactl")
    rc, out, errout = _run(["pactl", "list", "short", "sinks"], timeout=3.0)
    if rc != 0:
        return _err(f"pactl failed: {errout.strip()}")
    return {"ok": True, "sinks": _parse_pactl_list(out, "sink")}


def audio_list_sources(args: dict) -> dict:
    if not _have("pactl"):
        return _missing("pactl")
    rc, out, errout = _run(["pactl", "list", "short", "sources"], timeout=3.0)
    if rc != 0:
        return _err(f"pactl failed: {errout.strip()}")
    return {"ok": True, "sources": _parse_pactl_list(out, "source")}


# ──────────────────────────────────────────────────────────────────────────
# DISPLAY
# ──────────────────────────────────────────────────────────────────────────


_XRANDR_BRIGHTNESS_RE = re.compile(r"Brightness:\s*([\d.]+)")
_XRANDR_OUTPUT_RE = re.compile(r"^(\S+)\s+connected", re.MULTILINE)


def _xrandr_outputs() -> List[str]:
    if not _have("xrandr"):
        return []
    rc, out, _ = _run(["xrandr"], timeout=3.0)
    if rc != 0:
        return []
    return _XRANDR_OUTPUT_RE.findall(out)


def screen_brightness_get(args: dict) -> dict:
    # Prefer brightnessctl (works on laptops with backlight class)
    if _have("brightnessctl"):
        rc, out, errout = _run(["brightnessctl", "-m", "get"], timeout=3.0)
        rc_max, out_max, _ = _run(["brightnessctl", "-m", "max"], timeout=3.0)
        if rc == 0 and rc_max == 0:
            try:
                cur = int(out.strip().splitlines()[0])
                mx = int(out_max.strip().splitlines()[0])
                pct = round((cur / mx) * 100, 1) if mx > 0 else None
                return {
                    "ok": True,
                    "brightness_pct": pct,
                    "raw_current": cur,
                    "raw_max": mx,
                    "source": "brightnessctl",
                }
            except (ValueError, IndexError):
                pass

    # Fall back to xrandr software brightness (0.0–1.0)
    if _have("xrandr"):
        rc, out, errout = _run(["xrandr", "--verbose"], timeout=3.0)
        if rc == 0:
            matches = _XRANDR_BRIGHTNESS_RE.findall(out)
            if matches:
                # report the first/primary output
                values = [float(m) for m in matches]
                primary = values[0]
                return {
                    "ok": True,
                    "brightness_pct": round(primary * 100, 1),
                    "per_output": values,
                    "source": "xrandr",
                }
        return _err("xrandr returned no Brightness field")

    return _err("neither brightnessctl nor xrandr installed")


def screen_brightness_set(args: dict) -> dict:
    """MEDIUM risk — changes screen brightness."""
    percent = (args or {}).get("percent")
    if percent is None:
        return _err("percent required")
    try:
        pct = int(percent)
    except (TypeError, ValueError):
        return _err("percent must be integer 1-100")
    if pct < 1 or pct > 100:
        return _err("percent out of range (1-100)")

    if _have("brightnessctl"):
        rc, out, errout = _run(["brightnessctl", "set", f"{pct}%"], timeout=3.0)
        if rc == 0:
            return {"ok": True, "brightness_pct": pct, "source": "brightnessctl", "risk": "medium"}
        # fall through

    if _have("xrandr"):
        outputs = _xrandr_outputs()
        if not outputs:
            return _err("xrandr found no connected outputs")
        fraction = round(pct / 100.0, 3)
        errors = []
        for o in outputs:
            rc, out, errout = _run(
                ["xrandr", "--output", o, "--brightness", str(fraction)],
                timeout=3.0,
            )
            if rc != 0:
                errors.append(f"{o}: {errout.strip() or out.strip()}")
        if errors and len(errors) == len(outputs):
            return _err("; ".join(errors))
        return {
            "ok": True,
            "brightness_pct": pct,
            "outputs": outputs,
            "errors": errors,
            "source": "xrandr",
            "risk": "medium",
        }

    return _err("neither brightnessctl nor xrandr installed")


def dpms_off(args: dict) -> dict:
    if not _have("xset"):
        return _missing("xset")
    rc, out, errout = _run(["xset", "dpms", "force", "off"], timeout=3.0)
    if rc != 0:
        return _err(f"xset failed: {errout.strip() or out.strip()}")
    return {"ok": True, "state": "off"}


def dpms_on(args: dict) -> dict:
    if not _have("xset"):
        return _missing("xset")
    rc, out, errout = _run(["xset", "dpms", "force", "on"], timeout=3.0)
    if rc != 0:
        return _err(f"xset failed: {errout.strip() or out.strip()}")
    return {"ok": True, "state": "on"}


# ──────────────────────────────────────────────────────────────────────────
# POWER / THERMAL
# ──────────────────────────────────────────────────────────────────────────


def _read_first_line(path: str) -> Optional[str]:
    try:
        with open(path, "r") as f:
            return f.readline().strip()
    except (OSError, IOError):
        return None


def _battery_info() -> Optional[Dict[str, Any]]:
    """Read /sys/class/power_supply/BAT* if present. None on desktops."""
    base = "/sys/class/power_supply"
    if not os.path.isdir(base):
        return None
    for name in sorted(os.listdir(base)):
        if not name.upper().startswith("BAT"):
            continue
        d = os.path.join(base, name)
        capacity = _read_first_line(os.path.join(d, "capacity"))
        status = _read_first_line(os.path.join(d, "status"))
        info: Dict[str, Any] = {"name": name}
        if capacity is not None:
            try:
                info["capacity_pct"] = int(capacity)
            except ValueError:
                pass
        if status:
            info["status"] = status
        return info
    return None


def _load_avg() -> Optional[Tuple[float, float, float]]:
    try:
        return os.getloadavg()
    except (OSError, AttributeError):
        return None


def _cpu_temp_celsius() -> Optional[float]:
    """Read max CPU/SoC temp from /sys/class/thermal/thermal_zone*. Returns
    the hottest zone in Celsius, or None if unavailable."""
    base = "/sys/class/thermal"
    if not os.path.isdir(base):
        return None
    max_c: Optional[float] = None
    for name in os.listdir(base):
        if not name.startswith("thermal_zone"):
            continue
        raw = _read_first_line(os.path.join(base, name, "temp"))
        if not raw:
            continue
        try:
            milli = int(raw)
        except ValueError:
            continue
        celsius = milli / 1000.0
        if max_c is None or celsius > max_c:
            max_c = celsius
    return max_c


def power_state(args: dict) -> dict:
    battery = _battery_info()
    load = _load_avg()
    temp = _cpu_temp_celsius()

    summary = {
        "battery": battery,
        "load_avg_1m": load[0] if load else None,
        "load_avg_5m": load[1] if load else None,
        "load_avg_15m": load[2] if load else None,
        "cpu_temp_c": round(temp, 1) if temp is not None else None,
    }
    # quick narrative
    if battery is None:
        summary["form_factor"] = "desktop"
    else:
        summary["form_factor"] = "laptop"
    return {"ok": True, **summary}


def power_settle(args: dict) -> dict:
    """REPORT-ONLY. If CPU temp > 80C, surface the top heavy processes so
    Dean (or a higher-level routine) can decide what to kill. Never kills
    anything itself."""
    temp = _cpu_temp_celsius()
    hot = (temp is not None) and (temp > 80.0)

    top_procs: List[Dict[str, Any]] = []
    if _have("ps"):
        rc, out, _ = _run(
            ["ps", "-eo", "pid,pcpu,pmem,comm", "--sort=-pcpu"],
            timeout=3.0,
        )
        if rc == 0:
            for line in out.splitlines()[1:11]:  # top 10
                parts = line.split(None, 3)
                if len(parts) == 4:
                    try:
                        top_procs.append({
                            "pid": int(parts[0]),
                            "cpu_pct": float(parts[1]),
                            "mem_pct": float(parts[2]),
                            "command": parts[3],
                        })
                    except ValueError:
                        continue
    return {
        "ok": True,
        "cpu_temp_c": round(temp, 1) if temp is not None else None,
        "hot": hot,
        "threshold_c": 80.0,
        "recommendation": (
            "CPU over threshold — consider killing one of these"
            if hot else "thermals nominal — no action"
        ),
        "top_processes": top_procs,
        "killed": [],  # never auto-kills
    }


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # DNS / domain
    "net.dns_lookup": dns_lookup,
    "net.reverse_dns": reverse_dns,
    "net.whois": whois_lookup,
    "net.dns_check_propagation": dns_check_propagation,
    # Connectivity
    "net.ping": ping,
    "net.traceroute": traceroute,
    "net.public_ip": public_ip,
    "net.port_check": port_check,
    "net.port_scan_local": port_scan_local,
    # NetworkManager / Wi-Fi
    "net.wifi_list_networks": wifi_list_networks,
    "net.wifi_current": wifi_current,
    "net.wifi_disconnect": wifi_disconnect,
    "net.network_interfaces": network_interfaces,
    # Bluetooth
    "net.bluetooth_scan": bluetooth_scan,
    "net.bluetooth_paired_list": bluetooth_paired_list,
    "net.bluetooth_connect": bluetooth_connect,
    # Audio
    "sys.audio_volume_get": audio_volume_get,
    "sys.audio_volume_set": audio_volume_set,
    "sys.audio_mute_toggle": audio_mute_toggle,
    "sys.audio_list_sinks": audio_list_sinks,
    "sys.audio_list_sources": audio_list_sources,
    # Display
    "sys.screen_brightness_get": screen_brightness_get,
    "sys.screen_brightness_set": screen_brightness_set,
    "sys.dpms_off": dpms_off,
    "sys.dpms_on": dpms_on,
    # Power
    "sys.power_state": power_state,
    "sys.power_settle": power_settle,
}
