"""
wellness.py — Health & wellness tracking for Leon.

Manual logging for workouts, sleep, water, calories, mood/energy, vitals,
meditation. SQLite-backed at brain_state/wellness.db. All tools return
{"ok": bool, ...} and never raise.
"""

from __future__ import annotations

import os
import sqlite3
import json
import time
from datetime import datetime, date, timedelta
from typing import Any, Dict, List, Optional, Tuple

# ----------------------------------------------------------------------------
# Paths / constants
# ----------------------------------------------------------------------------

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", ".."))
_DB_DIR = os.path.join(_ROOT, "brain_state")
_DB_PATH = os.path.join(_DB_DIR, "wellness.db")

# Defaults for personal targets; overridable via set_target().
_DEFAULT_TARGETS = {
    "water_ml": 2500,
    "sleep_h": 8.0,
    "calories_in": 2200,
    "calories_burn": 400,
    "workout_min_per_week": 150,
    "meditation_min_per_day": 10,
    "eye_break_min": 45,  # nag if no break in this many minutes
    "water_reminder_min": 90,
}


# ----------------------------------------------------------------------------
# DB helpers
# ----------------------------------------------------------------------------

def _ensure_dir() -> None:
    try:
        os.makedirs(_DB_DIR, exist_ok=True)
    except Exception:
        pass


def _conn() -> sqlite3.Connection:
    _ensure_dir()
    c = sqlite3.connect(_DB_PATH, timeout=10.0)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def _init_db() -> None:
    try:
        with _conn() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS workouts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    type TEXT NOT NULL,
                    duration_min REAL NOT NULL,
                    intensity TEXT NOT NULL,
                    calories_burned REAL,
                    notes TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_workouts_date ON workouts(date);

                CREATE TABLE IF NOT EXISTS sleep (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    date TEXT NOT NULL,
                    hours REAL NOT NULL,
                    quality_1_10 INTEGER NOT NULL,
                    notes TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_sleep_date ON sleep(date);

                CREATE TABLE IF NOT EXISTS water_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    amount_ml REAL NOT NULL,
                    source TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_water_ts ON water_log(ts);

                CREATE TABLE IF NOT EXISTS meals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    name TEXT NOT NULL,
                    calories REAL,
                    protein_g REAL,
                    carbs_g REAL,
                    fat_g REAL,
                    notes TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_meals_ts ON meals(ts);

                CREATE TABLE IF NOT EXISTS mood_check (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    energy_1_10 INTEGER NOT NULL,
                    focus_1_10 INTEGER NOT NULL,
                    mood TEXT,
                    notes TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_mood_ts ON mood_check(ts);

                CREATE TABLE IF NOT EXISTS vitals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    weight_kg REAL,
                    resting_hr REAL,
                    blood_pressure_systolic REAL,
                    blood_pressure_diastolic REAL,
                    notes TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_vitals_ts ON vitals(ts);

                CREATE TABLE IF NOT EXISTS meditation_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    duration_min REAL NOT NULL,
                    type TEXT NOT NULL,
                    notes TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_med_ts ON meditation_sessions(ts);

                CREATE TABLE IF NOT EXISTS targets (
                    metric TEXT PRIMARY KEY,
                    value REAL NOT NULL,
                    updated_at TEXT NOT NULL
                );
                """
            )
    except Exception:
        # Never raise from import.
        pass


_init_db()


# ----------------------------------------------------------------------------
# Small util helpers
# ----------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.utcnow().isoformat(timespec="seconds")


def _today() -> str:
    return date.today().isoformat()


def _parse_date(s: Optional[str]) -> str:
    if not s:
        return _today()
    try:
        # Accept YYYY-MM-DD or ISO datetime.
        return datetime.fromisoformat(s).date().isoformat()
    except Exception:
        try:
            return datetime.strptime(s, "%Y-%m-%d").date().isoformat()
        except Exception:
            return _today()


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def _clamp_int(v: Any, lo: int, hi: int) -> Optional[int]:
    try:
        n = int(v)
    except Exception:
        return None
    if n < lo:
        n = lo
    if n > hi:
        n = hi
    return n


def _get_target(metric: str) -> float:
    try:
        with _conn() as c:
            r = c.execute("SELECT value FROM targets WHERE metric=?", (metric,)).fetchone()
            if r is not None:
                return float(r["value"])
    except Exception:
        pass
    return float(_DEFAULT_TARGETS.get(metric, 0))


def _mean(xs: List[float]) -> Optional[float]:
    xs = [x for x in xs if x is not None]
    if not xs:
        return None
    return sum(xs) / len(xs)


def _pearson(xs: List[float], ys: List[float]) -> Optional[float]:
    """Pearson correlation; returns None if degenerate."""
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    if len(pairs) < 2:
        return None
    xs2 = [p[0] for p in pairs]
    ys2 = [p[1] for p in pairs]
    mx = sum(xs2) / len(xs2)
    my = sum(ys2) / len(ys2)
    num = sum((x - mx) * (y - my) for x, y in pairs)
    dx = sum((x - mx) ** 2 for x in xs2) ** 0.5
    dy = sum((y - my) ** 2 for y in ys2) ** 0.5
    if dx == 0 or dy == 0:
        return None
    return num / (dx * dy)


def _trend_direction(values: List[float]) -> str:
    """Compare first half vs second half; returns 'up' / 'down' / 'flat'."""
    values = [v for v in values if v is not None]
    if len(values) < 2:
        return "flat"
    mid = len(values) // 2
    a = _mean(values[:mid]) if mid > 0 else None
    b = _mean(values[mid:])
    if a is None or b is None:
        return "flat"
    diff = b - a
    if abs(diff) < 1e-6 or abs(diff) / max(abs(a), 1e-6) < 0.02:
        return "flat"
    return "up" if diff > 0 else "down"


# ----------------------------------------------------------------------------
# Workouts
# ----------------------------------------------------------------------------

_VALID_INTENSITY = {"easy", "moderate", "intense"}


def workout_log(
    type: str,
    duration_min: float,
    intensity: str = "moderate",
    calories: Optional[float] = None,
    notes: Optional[str] = None,
    date: Optional[str] = None,
) -> Dict[str, Any]:
    try:
        if not type or not isinstance(type, str):
            return {"ok": False, "error": "type required"}
        try:
            dur = float(duration_min)
        except Exception:
            return {"ok": False, "error": "duration_min must be numeric"}
        if dur <= 0:
            return {"ok": False, "error": "duration_min must be > 0"}
        intensity = (intensity or "moderate").lower()
        if intensity not in _VALID_INTENSITY:
            intensity = "moderate"
        d = _parse_date(date)
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO workouts (date, type, duration_min, intensity, calories_burned, notes, created_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (d, type.strip(), dur, intensity, calories, notes, _now_iso()),
            )
            return {"ok": True, "id": cur.lastrowid, "date": d, "duration_min": dur, "intensity": intensity}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def workout_list(limit: int = 20, since: Optional[str] = None) -> Dict[str, Any]:
    try:
        lim = max(1, min(int(limit or 20), 500))
        with _conn() as c:
            if since:
                d = _parse_date(since)
                rows = c.execute(
                    "SELECT * FROM workouts WHERE date >= ? ORDER BY date DESC, id DESC LIMIT ?",
                    (d, lim),
                ).fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM workouts ORDER BY date DESC, id DESC LIMIT ?",
                    (lim,),
                ).fetchall()
        return {"ok": True, "count": len(rows), "workouts": [_row_to_dict(r) for r in rows]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def workout_summary_week() -> Dict[str, Any]:
    try:
        cutoff = (date.today() - timedelta(days=6)).isoformat()
        with _conn() as c:
            rows = c.execute(
                "SELECT type, duration_min, intensity, calories_burned, date FROM workouts WHERE date >= ?",
                (cutoff,),
            ).fetchall()
        total_min = sum(float(r["duration_min"] or 0) for r in rows)
        total_cal = sum(float(r["calories_burned"] or 0) for r in rows if r["calories_burned"] is not None)
        type_count: Dict[str, int] = {}
        type_min: Dict[str, float] = {}
        for r in rows:
            t = r["type"] or "unknown"
            type_count[t] = type_count.get(t, 0) + 1
            type_min[t] = type_min.get(t, 0.0) + float(r["duration_min"] or 0)
        top_types = sorted(type_min.items(), key=lambda x: -x[1])[:5]
        intensity_map = {"easy": 1, "moderate": 2, "intense": 3}
        intensities = [intensity_map.get(r["intensity"] or "moderate", 2) for r in rows]
        avg_int = _mean(intensities)
        avg_int_label = {1: "easy", 2: "moderate", 3: "intense"}.get(round(avg_int)) if avg_int else None
        target = _get_target("workout_min_per_week")
        return {
            "ok": True,
            "since": cutoff,
            "workouts": len(rows),
            "total_minutes": round(total_min, 1),
            "total_calories": round(total_cal, 1),
            "top_types": [{"type": t, "minutes": round(m, 1)} for t, m in top_types],
            "avg_intensity": avg_int_label,
            "avg_intensity_score": round(avg_int, 2) if avg_int else None,
            "target_minutes": target,
            "pct_of_target": round((total_min / target) * 100, 1) if target else None,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def workout_streak() -> Dict[str, Any]:
    try:
        with _conn() as c:
            rows = c.execute(
                "SELECT DISTINCT date FROM workouts ORDER BY date DESC"
            ).fetchall()
        if not rows:
            return {"ok": True, "streak_days": 0, "last_workout": None}
        days = [r["date"] for r in rows]
        today = date.today()
        # Allow today OR yesterday to be the streak head.
        if days[0] == today.isoformat():
            head = today
        elif days[0] == (today - timedelta(days=1)).isoformat():
            head = today - timedelta(days=1)
        else:
            return {"ok": True, "streak_days": 0, "last_workout": days[0]}
        streak = 0
        cursor = head
        day_set = set(days)
        while cursor.isoformat() in day_set:
            streak += 1
            cursor = cursor - timedelta(days=1)
        return {"ok": True, "streak_days": streak, "last_workout": days[0]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Sleep
# ----------------------------------------------------------------------------

def sleep_log(
    hours: float,
    quality_1_10: int,
    notes: Optional[str] = None,
    date: Optional[str] = None,
) -> Dict[str, Any]:
    try:
        try:
            h = float(hours)
        except Exception:
            return {"ok": False, "error": "hours must be numeric"}
        if h < 0 or h > 24:
            return {"ok": False, "error": "hours out of range (0-24)"}
        q = _clamp_int(quality_1_10, 1, 10)
        if q is None:
            return {"ok": False, "error": "quality_1_10 must be 1-10"}
        d = _parse_date(date)
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO sleep (date, hours, quality_1_10, notes, created_at) VALUES (?,?,?,?,?)",
                (d, h, q, notes, _now_iso()),
            )
            return {"ok": True, "id": cur.lastrowid, "date": d, "hours": h, "quality_1_10": q}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def sleep_list(limit: int = 14) -> Dict[str, Any]:
    try:
        lim = max(1, min(int(limit or 14), 365))
        with _conn() as c:
            rows = c.execute(
                "SELECT * FROM sleep ORDER BY date DESC, id DESC LIMIT ?", (lim,)
            ).fetchall()
        return {"ok": True, "count": len(rows), "sleep": [_row_to_dict(r) for r in rows]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def sleep_summary_week() -> Dict[str, Any]:
    try:
        cutoff = (date.today() - timedelta(days=6)).isoformat()
        with _conn() as c:
            rows = c.execute(
                "SELECT hours, quality_1_10 FROM sleep WHERE date >= ?", (cutoff,)
            ).fetchall()
        if not rows:
            return {"ok": True, "since": cutoff, "nights": 0, "avg_hours": None, "avg_quality": None, "debt_h": 0}
        hours = [float(r["hours"]) for r in rows]
        qual = [float(r["quality_1_10"]) for r in rows]
        target = _get_target("sleep_h")
        debt = max(0.0, target * len(rows) - sum(hours))
        return {
            "ok": True,
            "since": cutoff,
            "nights": len(rows),
            "avg_hours": round(_mean(hours), 2),
            "avg_quality": round(_mean(qual), 2),
            "target_h": target,
            "debt_h": round(debt, 2),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def sleep_debt() -> Dict[str, Any]:
    try:
        with _conn() as c:
            rows = c.execute("SELECT hours FROM sleep").fetchall()
        target = _get_target("sleep_h")
        nights = len(rows)
        total = sum(float(r["hours"]) for r in rows)
        debt = max(0.0, target * nights - total)
        return {
            "ok": True,
            "nights_logged": nights,
            "target_h_per_night": target,
            "total_hours": round(total, 2),
            "debt_h": round(debt, 2),
            "avg_hours": round(total / nights, 2) if nights else None,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Water
# ----------------------------------------------------------------------------

def water_add(amount_ml: float = 250, source: str = "glass") -> Dict[str, Any]:
    try:
        try:
            amt = float(amount_ml)
        except Exception:
            return {"ok": False, "error": "amount_ml must be numeric"}
        if amt <= 0:
            return {"ok": False, "error": "amount_ml must be > 0"}
        src = (source or "glass").strip() or "glass"
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO water_log (ts, amount_ml, source) VALUES (?,?,?)",
                (ts, amt, src),
            )
        today_total = water_today().get("total_ml", 0)
        return {"ok": True, "id": cur.lastrowid, "amount_ml": amt, "source": src, "total_today_ml": today_total}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def water_today() -> Dict[str, Any]:
    try:
        today_prefix = _today()
        with _conn() as c:
            rows = c.execute(
                "SELECT amount_ml FROM water_log WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchall()
        total = sum(float(r["amount_ml"]) for r in rows)
        target = _get_target("water_ml")
        return {
            "ok": True,
            "date": today_prefix,
            "entries": len(rows),
            "total_ml": round(total, 1),
            "target_ml": target,
            "remaining_ml": round(max(0.0, target - total), 1),
            "pct_of_target": round((total / target) * 100, 1) if target else None,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def water_streak() -> Dict[str, Any]:
    try:
        target = _get_target("water_ml")
        with _conn() as c:
            rows = c.execute(
                "SELECT substr(ts,1,10) AS d, SUM(amount_ml) AS total "
                "FROM water_log GROUP BY substr(ts,1,10) ORDER BY d DESC"
            ).fetchall()
        if not rows:
            return {"ok": True, "streak_days": 0, "target_ml": target}
        # Build map and walk backwards from today or yesterday.
        totals = {r["d"]: float(r["total"]) for r in rows}
        today = date.today()
        if totals.get(today.isoformat(), 0) >= target:
            head = today
        elif totals.get((today - timedelta(days=1)).isoformat(), 0) >= target:
            head = today - timedelta(days=1)
        else:
            return {"ok": True, "streak_days": 0, "target_ml": target}
        streak = 0
        cursor = head
        while totals.get(cursor.isoformat(), 0) >= target:
            streak += 1
            cursor = cursor - timedelta(days=1)
        return {"ok": True, "streak_days": streak, "target_ml": target}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def water_reminder() -> Dict[str, Any]:
    try:
        threshold_min = _get_target("water_reminder_min") or 90
        with _conn() as c:
            r = c.execute("SELECT ts FROM water_log ORDER BY id DESC LIMIT 1").fetchone()
        if not r:
            return {"ok": True, "remind": True, "reason": "no water logged yet", "minutes_since_last": None}
        try:
            last = datetime.fromisoformat(r["ts"])
        except Exception:
            return {"ok": True, "remind": True, "reason": "could not parse last ts", "minutes_since_last": None}
        delta_min = (datetime.utcnow() - last).total_seconds() / 60.0
        return {
            "ok": True,
            "remind": delta_min > threshold_min,
            "minutes_since_last": round(delta_min, 1),
            "threshold_min": threshold_min,
            "last_ts": r["ts"],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Meals / calories
# ----------------------------------------------------------------------------

def meal_log(
    name: str,
    calories: Optional[float] = None,
    protein_g: Optional[float] = None,
    carbs_g: Optional[float] = None,
    fat_g: Optional[float] = None,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    try:
        if not name or not isinstance(name, str):
            return {"ok": False, "error": "name required"}
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO meals (ts, name, calories, protein_g, carbs_g, fat_g, notes) VALUES (?,?,?,?,?,?,?)",
                (ts, name.strip(), calories, protein_g, carbs_g, fat_g, notes),
            )
        return {"ok": True, "id": cur.lastrowid, "name": name.strip(), "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def meal_list(limit: int = 20) -> Dict[str, Any]:
    try:
        lim = max(1, min(int(limit or 20), 500))
        with _conn() as c:
            rows = c.execute(
                "SELECT * FROM meals ORDER BY id DESC LIMIT ?", (lim,)
            ).fetchall()
        return {"ok": True, "count": len(rows), "meals": [_row_to_dict(r) for r in rows]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def calories_today() -> Dict[str, Any]:
    try:
        today_prefix = _today()
        with _conn() as c:
            r = c.execute(
                "SELECT COALESCE(SUM(calories),0) AS total, COUNT(*) AS n "
                "FROM meals WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()
        total = float(r["total"] or 0)
        target = _get_target("calories_in")
        return {
            "ok": True,
            "date": today_prefix,
            "meals": int(r["n"]),
            "total_calories": round(total, 1),
            "target_calories": target,
            "remaining": round(target - total, 1) if target else None,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def macros_today() -> Dict[str, Any]:
    try:
        today_prefix = _today()
        with _conn() as c:
            r = c.execute(
                "SELECT COALESCE(SUM(protein_g),0) AS p, COALESCE(SUM(carbs_g),0) AS c, "
                "COALESCE(SUM(fat_g),0) AS f, COUNT(*) AS n FROM meals WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()
        p = float(r["p"] or 0)
        cb = float(r["c"] or 0)
        f = float(r["f"] or 0)
        kcal = p * 4 + cb * 4 + f * 9
        return {
            "ok": True,
            "date": today_prefix,
            "meals": int(r["n"]),
            "protein_g": round(p, 1),
            "carbs_g": round(cb, 1),
            "fat_g": round(f, 1),
            "macro_calories_est": round(kcal, 1),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def calorie_balance() -> Dict[str, Any]:
    try:
        today_prefix = _today()
        with _conn() as c:
            r1 = c.execute(
                "SELECT COALESCE(SUM(calories),0) AS total FROM meals WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()
            r2 = c.execute(
                "SELECT COALESCE(SUM(calories_burned),0) AS total FROM workouts WHERE date=?",
                (today_prefix,),
            ).fetchone()
        cal_in = float(r1["total"] or 0)
        cal_out = float(r2["total"] or 0)
        return {
            "ok": True,
            "date": today_prefix,
            "calories_in": round(cal_in, 1),
            "calories_burned": round(cal_out, 1),
            "net": round(cal_in - cal_out, 1),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Mood / energy
# ----------------------------------------------------------------------------

def mood_check(
    energy_1_10: int,
    focus_1_10: int,
    mood: Optional[str] = None,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    try:
        e = _clamp_int(energy_1_10, 1, 10)
        f = _clamp_int(focus_1_10, 1, 10)
        if e is None or f is None:
            return {"ok": False, "error": "energy_1_10 and focus_1_10 must be 1-10"}
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO mood_check (ts, energy_1_10, focus_1_10, mood, notes) VALUES (?,?,?,?,?)",
                (ts, e, f, mood, notes),
            )
        return {"ok": True, "id": cur.lastrowid, "energy_1_10": e, "focus_1_10": f, "mood": mood, "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _trend_by_day(field: str, days: int) -> Dict[str, Any]:
    try:
        d = max(1, min(int(days or 7), 365))
        cutoff_dt = datetime.utcnow() - timedelta(days=d - 1)
        cutoff = cutoff_dt.date().isoformat()
        with _conn() as c:
            rows = c.execute(
                f"SELECT substr(ts,1,10) AS d, AVG({field}) AS avg, COUNT(*) AS n "
                f"FROM mood_check WHERE substr(ts,1,10) >= ? GROUP BY substr(ts,1,10) ORDER BY d ASC",
                (cutoff,),
            ).fetchall()
        series = [{"date": r["d"], "avg": round(float(r["avg"]), 2), "n": int(r["n"])} for r in rows]
        values = [s["avg"] for s in series]
        return {
            "ok": True,
            "days": d,
            "field": field,
            "series": series,
            "overall_avg": round(_mean(values), 2) if values else None,
            "trend": _trend_direction(values),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def energy_trend(days: int = 7) -> Dict[str, Any]:
    return _trend_by_day("energy_1_10", days)


def focus_trend(days: int = 7) -> Dict[str, Any]:
    return _trend_by_day("focus_1_10", days)


def mood_correlation(metric: str = "sleep") -> Dict[str, Any]:
    """Correlate avg daily energy with another daily metric."""
    try:
        m = (metric or "sleep").lower()
        with _conn() as c:
            mood_rows = c.execute(
                "SELECT substr(ts,1,10) AS d, AVG(energy_1_10) AS e "
                "FROM mood_check GROUP BY substr(ts,1,10)"
            ).fetchall()
            energy_by_day = {r["d"]: float(r["e"]) for r in mood_rows if r["e"] is not None}

            if m == "sleep":
                other_rows = c.execute(
                    "SELECT date AS d, AVG(hours) AS v FROM sleep GROUP BY date"
                ).fetchall()
                metric_label = "sleep_hours"
            elif m in ("water", "water_ml"):
                other_rows = c.execute(
                    "SELECT substr(ts,1,10) AS d, SUM(amount_ml) AS v "
                    "FROM water_log GROUP BY substr(ts,1,10)"
                ).fetchall()
                metric_label = "water_ml"
            elif m in ("workout", "workout_min", "exercise"):
                other_rows = c.execute(
                    "SELECT date AS d, SUM(duration_min) AS v FROM workouts GROUP BY date"
                ).fetchall()
                metric_label = "workout_min"
            elif m in ("calories", "calories_in"):
                other_rows = c.execute(
                    "SELECT substr(ts,1,10) AS d, SUM(calories) AS v "
                    "FROM meals GROUP BY substr(ts,1,10)"
                ).fetchall()
                metric_label = "calories_in"
            elif m in ("meditation", "meditation_min"):
                other_rows = c.execute(
                    "SELECT substr(ts,1,10) AS d, SUM(duration_min) AS v "
                    "FROM meditation_sessions GROUP BY substr(ts,1,10)"
                ).fetchall()
                metric_label = "meditation_min"
            else:
                return {"ok": False, "error": f"unknown metric '{metric}'"}

        other_by_day = {r["d"]: float(r["v"]) for r in other_rows if r["v"] is not None}
        common = sorted(set(energy_by_day) & set(other_by_day))
        xs = [other_by_day[d] for d in common]
        ys = [energy_by_day[d] for d in common]
        r = _pearson(xs, ys)
        return {
            "ok": True,
            "metric": metric_label,
            "n_days": len(common),
            "pearson_r": round(r, 3) if r is not None else None,
            "interpretation": _interpret_r(r),
            "sample": [{"date": d, metric_label: other_by_day[d], "energy": energy_by_day[d]} for d in common[-14:]],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _interpret_r(r: Optional[float]) -> str:
    if r is None:
        return "insufficient data"
    a = abs(r)
    if a < 0.1:
        strength = "none"
    elif a < 0.3:
        strength = "weak"
    elif a < 0.5:
        strength = "moderate"
    elif a < 0.7:
        strength = "strong"
    else:
        strength = "very strong"
    direction = "positive" if r > 0 else "negative"
    return f"{strength} {direction}"


# ----------------------------------------------------------------------------
# Vitals
# ----------------------------------------------------------------------------

def weight_log(weight_kg: float, notes: Optional[str] = None) -> Dict[str, Any]:
    try:
        try:
            w = float(weight_kg)
        except Exception:
            return {"ok": False, "error": "weight_kg must be numeric"}
        if w <= 0 or w > 500:
            return {"ok": False, "error": "weight_kg out of range"}
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO vitals (ts, weight_kg, notes) VALUES (?,?,?)",
                (ts, w, notes),
            )
        return {"ok": True, "id": cur.lastrowid, "weight_kg": w, "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def weight_trend(days: int = 30) -> Dict[str, Any]:
    try:
        d = max(1, min(int(days or 30), 3650))
        cutoff = (date.today() - timedelta(days=d - 1)).isoformat()
        with _conn() as c:
            rows = c.execute(
                "SELECT ts, weight_kg FROM vitals "
                "WHERE weight_kg IS NOT NULL AND substr(ts,1,10) >= ? "
                "ORDER BY ts ASC",
                (cutoff,),
            ).fetchall()
        series = [{"ts": r["ts"], "weight_kg": float(r["weight_kg"])} for r in rows]
        weights = [s["weight_kg"] for s in series]
        if not weights:
            return {"ok": True, "days": d, "n": 0, "first": None, "last": None, "delta": None, "trend": "flat"}
        return {
            "ok": True,
            "days": d,
            "n": len(weights),
            "first": weights[0],
            "last": weights[-1],
            "delta": round(weights[-1] - weights[0], 2),
            "avg": round(_mean(weights), 2),
            "trend": _trend_direction(weights),
            "series": series,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def bp_log(systolic: float, diastolic: float, notes: Optional[str] = None) -> Dict[str, Any]:
    try:
        try:
            s = float(systolic)
            di = float(diastolic)
        except Exception:
            return {"ok": False, "error": "systolic/diastolic must be numeric"}
        if not (40 <= s <= 260) or not (30 <= di <= 200):
            return {"ok": False, "error": "blood pressure values out of range"}
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO vitals (ts, blood_pressure_systolic, blood_pressure_diastolic, notes) "
                "VALUES (?,?,?,?)",
                (ts, s, di, notes),
            )
        # Simple BP classification (US guidelines).
        if s < 120 and di < 80:
            cat = "normal"
        elif s < 130 and di < 80:
            cat = "elevated"
        elif s < 140 or di < 90:
            cat = "stage_1_hypertension"
        elif s < 180 or di < 120:
            cat = "stage_2_hypertension"
        else:
            cat = "hypertensive_crisis"
        return {"ok": True, "id": cur.lastrowid, "systolic": s, "diastolic": di, "category": cat, "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def hr_log(resting_hr: float, notes: Optional[str] = None) -> Dict[str, Any]:
    try:
        try:
            hr = float(resting_hr)
        except Exception:
            return {"ok": False, "error": "resting_hr must be numeric"}
        if not (20 <= hr <= 250):
            return {"ok": False, "error": "resting_hr out of range"}
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO vitals (ts, resting_hr, notes) VALUES (?,?,?)",
                (ts, hr, notes),
            )
        return {"ok": True, "id": cur.lastrowid, "resting_hr": hr, "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def vitals_summary() -> Dict[str, Any]:
    try:
        with _conn() as c:
            latest_weight = c.execute(
                "SELECT ts, weight_kg FROM vitals WHERE weight_kg IS NOT NULL "
                "ORDER BY id DESC LIMIT 1"
            ).fetchone()
            latest_bp = c.execute(
                "SELECT ts, blood_pressure_systolic, blood_pressure_diastolic FROM vitals "
                "WHERE blood_pressure_systolic IS NOT NULL ORDER BY id DESC LIMIT 1"
            ).fetchone()
            latest_hr = c.execute(
                "SELECT ts, resting_hr FROM vitals WHERE resting_hr IS NOT NULL "
                "ORDER BY id DESC LIMIT 1"
            ).fetchone()

            recent_weights = [
                float(r["weight_kg"])
                for r in c.execute(
                    "SELECT weight_kg FROM vitals WHERE weight_kg IS NOT NULL "
                    "ORDER BY id DESC LIMIT 10"
                ).fetchall()
            ]
            recent_hr = [
                float(r["resting_hr"])
                for r in c.execute(
                    "SELECT resting_hr FROM vitals WHERE resting_hr IS NOT NULL "
                    "ORDER BY id DESC LIMIT 10"
                ).fetchall()
            ]

        return {
            "ok": True,
            "latest_weight": _row_to_dict(latest_weight) if latest_weight else None,
            "latest_bp": _row_to_dict(latest_bp) if latest_bp else None,
            "latest_resting_hr": _row_to_dict(latest_hr) if latest_hr else None,
            # Reverse so older→newer for trend direction.
            "weight_trend": _trend_direction(list(reversed(recent_weights))),
            "hr_trend": _trend_direction(list(reversed(recent_hr))),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Meditation / breaks
# ----------------------------------------------------------------------------

def meditation_log(
    duration_min: float,
    type: str = "breath",
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    try:
        try:
            d = float(duration_min)
        except Exception:
            return {"ok": False, "error": "duration_min must be numeric"}
        if d <= 0:
            return {"ok": False, "error": "duration_min must be > 0"}
        t = (type or "breath").strip() or "breath"
        ts = _now_iso()
        with _conn() as c:
            cur = c.execute(
                "INSERT INTO meditation_sessions (ts, duration_min, type, notes) VALUES (?,?,?,?)",
                (ts, d, t, notes),
            )
        return {"ok": True, "id": cur.lastrowid, "duration_min": d, "type": t, "ts": ts}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def meditation_streak() -> Dict[str, Any]:
    try:
        with _conn() as c:
            rows = c.execute(
                "SELECT DISTINCT substr(ts,1,10) AS d FROM meditation_sessions ORDER BY d DESC"
            ).fetchall()
        if not rows:
            return {"ok": True, "streak_days": 0, "last": None}
        days = [r["d"] for r in rows]
        today = date.today()
        if days[0] == today.isoformat():
            head = today
        elif days[0] == (today - timedelta(days=1)).isoformat():
            head = today - timedelta(days=1)
        else:
            return {"ok": True, "streak_days": 0, "last": days[0]}
        streak = 0
        cursor = head
        day_set = set(days)
        while cursor.isoformat() in day_set:
            streak += 1
            cursor = cursor - timedelta(days=1)
        return {"ok": True, "streak_days": streak, "last": days[0]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def eye_break_check() -> Dict[str, Any]:
    """Minutes since last meditation OR break entry."""
    try:
        threshold = _get_target("eye_break_min") or 45
        with _conn() as c:
            r = c.execute(
                "SELECT ts FROM meditation_sessions ORDER BY id DESC LIMIT 1"
            ).fetchone()
        if not r:
            return {
                "ok": True,
                "needs_break": True,
                "minutes_since_last": None,
                "threshold_min": threshold,
                "reason": "no break logged yet",
            }
        try:
            last = datetime.fromisoformat(r["ts"])
        except Exception:
            return {"ok": True, "needs_break": True, "minutes_since_last": None, "threshold_min": threshold}
        delta_min = (datetime.utcnow() - last).total_seconds() / 60.0
        return {
            "ok": True,
            "needs_break": delta_min > threshold,
            "minutes_since_last": round(delta_min, 1),
            "threshold_min": threshold,
            "last_ts": r["ts"],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Convenience / dashboard
# ----------------------------------------------------------------------------

def daily_health_summary() -> Dict[str, Any]:
    try:
        today_prefix = _today()
        yest = (date.today() - timedelta(days=1)).isoformat()
        with _conn() as c:
            # Sleep last night (logged either today for last-night, or on yest date).
            sleep_row = c.execute(
                "SELECT date, hours, quality_1_10 FROM sleep "
                "WHERE date IN (?, ?) ORDER BY date DESC, id DESC LIMIT 1",
                (today_prefix, yest),
            ).fetchone()
            workouts = c.execute(
                "SELECT COUNT(*) AS n, COALESCE(SUM(duration_min),0) AS m "
                "FROM workouts WHERE date=?",
                (today_prefix,),
            ).fetchone()
            water = c.execute(
                "SELECT COALESCE(SUM(amount_ml),0) AS total FROM water_log "
                "WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()
            last_mood = c.execute(
                "SELECT ts, energy_1_10, focus_1_10, mood FROM mood_check "
                "ORDER BY id DESC LIMIT 1"
            ).fetchone()
            meals = c.execute(
                "SELECT COUNT(*) AS n, COALESCE(SUM(calories),0) AS cal "
                "FROM meals WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()
            meditation = c.execute(
                "SELECT COALESCE(SUM(duration_min),0) AS m FROM meditation_sessions "
                "WHERE substr(ts,1,10)=?",
                (today_prefix,),
            ).fetchone()

        water_target = _get_target("water_ml")
        sleep_target = _get_target("sleep_h")
        return {
            "ok": True,
            "date": today_prefix,
            "sleep_last_night": _row_to_dict(sleep_row) if sleep_row else None,
            "sleep_target_h": sleep_target,
            "workouts_today": {
                "count": int(workouts["n"]),
                "total_minutes": float(workouts["m"]),
            },
            "water": {
                "total_ml": float(water["total"] or 0),
                "target_ml": water_target,
                "pct": round(float(water["total"] or 0) / water_target * 100, 1) if water_target else None,
            },
            "last_mood_check": _row_to_dict(last_mood) if last_mood else None,
            "meals": {
                "count": int(meals["n"]),
                "calories": float(meals["cal"] or 0),
            },
            "meditation_minutes": float(meditation["m"] or 0),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def weekly_health_report() -> Dict[str, Any]:
    """Markdown report — designed to feed docgen.markdown_to_pdf."""
    try:
        today = date.today()
        cutoff = (today - timedelta(days=6)).isoformat()

        workouts = workout_summary_week()
        sleep = sleep_summary_week()
        # 7-day water totals.
        with _conn() as c:
            water_rows = c.execute(
                "SELECT substr(ts,1,10) AS d, SUM(amount_ml) AS total "
                "FROM water_log WHERE substr(ts,1,10) >= ? "
                "GROUP BY substr(ts,1,10) ORDER BY d ASC",
                (cutoff,),
            ).fetchall()
            cal_in_row = c.execute(
                "SELECT AVG(daily) AS avg FROM ("
                "SELECT SUM(calories) AS daily FROM meals "
                "WHERE substr(ts,1,10) >= ? GROUP BY substr(ts,1,10))",
                (cutoff,),
            ).fetchone()
            med_row = c.execute(
                "SELECT COALESCE(SUM(duration_min),0) AS total, COUNT(DISTINCT substr(ts,1,10)) AS days "
                "FROM meditation_sessions WHERE substr(ts,1,10) >= ?",
                (cutoff,),
            ).fetchone()
            mood_row = c.execute(
                "SELECT AVG(energy_1_10) AS e, AVG(focus_1_10) AS f "
                "FROM mood_check WHERE substr(ts,1,10) >= ?",
                (cutoff,),
            ).fetchone()

        water_target = _get_target("water_ml")
        water_days_hit = sum(1 for r in water_rows if float(r["total"]) >= water_target)
        water_avg = _mean([float(r["total"]) for r in water_rows]) or 0

        lines: List[str] = []
        lines.append(f"# Weekly Health Report")
        lines.append(f"_Week ending {today.isoformat()}_")
        lines.append("")
        lines.append("## Sleep")
        if sleep.get("ok") and sleep.get("nights"):
            lines.append(f"- Nights logged: **{sleep['nights']}**")
            lines.append(f"- Avg hours: **{sleep['avg_hours']}h** (target {sleep.get('target_h')}h)")
            lines.append(f"- Avg quality: **{sleep['avg_quality']}/10**")
            lines.append(f"- Sleep debt: **{sleep['debt_h']}h**")
        else:
            lines.append("- _No sleep logged this week._")
        lines.append("")

        lines.append("## Workouts")
        if workouts.get("ok") and workouts.get("workouts"):
            lines.append(f"- Sessions: **{workouts['workouts']}**")
            lines.append(f"- Total minutes: **{workouts['total_minutes']}** (target {workouts.get('target_minutes')})")
            lines.append(f"- Avg intensity: **{workouts.get('avg_intensity') or '—'}**")
            if workouts.get("top_types"):
                tops = ", ".join(f"{t['type']} ({t['minutes']}m)" for t in workouts["top_types"])
                lines.append(f"- Top types: {tops}")
        else:
            lines.append("- _No workouts logged this week._")
        lines.append("")

        lines.append("## Hydration")
        lines.append(f"- Avg daily: **{round(water_avg)}ml** (target {water_target}ml)")
        lines.append(f"- Days hit target: **{water_days_hit}/{len(water_rows) or 0}**")
        lines.append("")

        lines.append("## Nutrition")
        avg_cal = float(cal_in_row["avg"] or 0) if cal_in_row else 0
        lines.append(f"- Avg daily calories: **{round(avg_cal)}** (target {_get_target('calories_in')})")
        lines.append("")

        lines.append("## Mind")
        med_min = float(med_row["total"] or 0)
        med_days = int(med_row["days"] or 0)
        lines.append(f"- Meditation: **{med_min} min** across **{med_days} days**")
        if mood_row and mood_row["e"] is not None:
            lines.append(f"- Avg energy: **{round(float(mood_row['e']), 1)}/10**")
            lines.append(f"- Avg focus: **{round(float(mood_row['f']), 1)}/10**")
        lines.append("")

        md = "\n".join(lines)
        return {"ok": True, "markdown": md, "since": cutoff, "until": today.isoformat()}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def set_target(metric: str, value: float) -> Dict[str, Any]:
    try:
        if not metric or not isinstance(metric, str):
            return {"ok": False, "error": "metric required"}
        try:
            v = float(value)
        except Exception:
            return {"ok": False, "error": "value must be numeric"}
        m = metric.strip().lower()
        with _conn() as c:
            c.execute(
                "INSERT INTO targets (metric, value, updated_at) VALUES (?,?,?) "
                "ON CONFLICT(metric) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (m, v, _now_iso()),
            )
        return {"ok": True, "metric": m, "value": v}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ----------------------------------------------------------------------------
# Export
# ----------------------------------------------------------------------------

EXTRA_TOOLS: Dict[str, Any] = {
    # Workouts
    "wellness.workout_log": workout_log,
    "wellness.workout_list": workout_list,
    "wellness.workout_summary_week": workout_summary_week,
    "wellness.workout_streak": workout_streak,
    # Sleep
    "wellness.sleep_log": sleep_log,
    "wellness.sleep_list": sleep_list,
    "wellness.sleep_summary_week": sleep_summary_week,
    "wellness.sleep_debt": sleep_debt,
    # Water
    "wellness.water_add": water_add,
    "wellness.water_today": water_today,
    "wellness.water_streak": water_streak,
    "wellness.water_reminder": water_reminder,
    # Meals
    "wellness.meal_log": meal_log,
    "wellness.meal_list": meal_list,
    "wellness.calories_today": calories_today,
    "wellness.macros_today": macros_today,
    "wellness.calorie_balance": calorie_balance,
    # Mood/Energy
    "wellness.mood_check": mood_check,
    "wellness.energy_trend": energy_trend,
    "wellness.focus_trend": focus_trend,
    "wellness.mood_correlation": mood_correlation,
    # Vitals
    "wellness.weight_log": weight_log,
    "wellness.weight_trend": weight_trend,
    "wellness.bp_log": bp_log,
    "wellness.hr_log": hr_log,
    "wellness.vitals_summary": vitals_summary,
    # Meditation / breaks
    "wellness.meditation_log": meditation_log,
    "wellness.meditation_streak": meditation_streak,
    "wellness.eye_break_check": eye_break_check,
    # Dashboard / convenience
    "wellness.daily_health_summary": daily_health_summary,
    "wellness.weekly_health_report": weekly_health_report,
    "wellness.set_target": set_target,
}


# ── Adapter: brain.integrations modules use the (args: dict) → dict
# convention. The functions above take normal kwargs. Wrap them so the
# dispatcher's `fn({...})` invocation flows correctly via `**args`. ──
def _adapt(fn):
    def _wrapped(args):
        try:
            args = args or {}
            return fn(**args)
        except TypeError as e:
            return {"ok": False, "error": f"bad args for {fn.__name__}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    _wrapped.__name__ = fn.__name__
    _wrapped.__doc__ = fn.__doc__
    return _wrapped


EXTRA_TOOLS = {k: _adapt(v) for k, v in EXTRA_TOOLS.items()}
