"""database.py — Leon's direct database + devops basics integration.

Covers five database flavors (Postgres, MySQL, MongoDB, Redis, SQLite) and a
small set of devops primitives (kubectl, systemd, log grep). Drivers are
imported lazily — a missing driver returns a helpful install hint instead of
crashing import. Every tool returns the standard `{ok, ...}` envelope; nothing
in this module raises.

Connection params:
  - Postgres : env `LEON_PG_DSN`     or arg `dsn` (libpq URI or keyword string)
  - MySQL    : env `LEON_MYSQL_DSN`  or arg `dsn` (mysql://user:pass@host:port/db)
  - Mongo    : env `LEON_MONGO_DSN`  or arg `dsn` (mongodb://...)
  - Redis    : env `LEON_REDIS_DSN`  or arg `dsn` (redis://[:pass@]host:port/db)
  - SQLite   : explicit `path` arg (no DSN)

EXTRA_TOOLS at the bottom maps dotted names (e.g. `db.pg_query`,
`devops.kubectl_get`) to callables that take a single `dict` arg.
"""

from __future__ import annotations

import csv
import io
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse, unquote


# ──────────────────────────────────────────────────────────────────────────
# COMMON HELPERS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_QUERY_TIMEOUT = 15.0
_MAX_ROWS = 5000


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap any exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _missing_driver(pkg: str, purpose: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"{pkg} not installed — `pip install {pkg}` to use {purpose}",
    }


def _serialize(value: Any) -> Any:
    """Make a row value JSON-safe (datetimes, decimals, bytes, etc.)."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8", errors="replace")
        except Exception:
            return f"<{len(value)} bytes>"
    if isinstance(value, (list, tuple)):
        return [_serialize(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _serialize(v) for k, v in value.items()}
    # datetime, Decimal, UUID, etc.
    try:
        return str(value)
    except Exception:
        return repr(value)


def _run_cmd(cmd: List[str], timeout: float = 20.0) -> Dict[str, Any]:
    """Run a subprocess and return {ok, stdout, stderr, returncode}."""
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
    except FileNotFoundError:
        return {"ok": False, "error": f"binary not found: {cmd[0]}"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timeout after {timeout}s: {' '.join(cmd[:3])}"}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# POSTGRES
# ──────────────────────────────────────────────────────────────────────────

def _pg_dsn(args: dict) -> Optional[str]:
    return args.get("dsn") or os.environ.get("LEON_PG_DSN")


def _pg_connect(dsn: str):
    """Lazy-import psycopg2 and connect. Caller wraps errors."""
    try:
        import psycopg2  # type: ignore
    except ImportError:
        return None, _missing_driver("psycopg2-binary", "Postgres")
    try:
        conn = psycopg2.connect(dsn, connect_timeout=8)
        return conn, None
    except Exception as e:
        return None, _err(e)


def _pg_query(args: dict) -> dict:
    """Run a read-only SQL query. Returns rows + columns."""
    try:
        sql = args.get("sql")
        if not sql:
            return {"ok": False, "error": "sql required"}
        dsn = _pg_dsn(args)
        if not dsn:
            return {"ok": False, "error": "no DSN — set LEON_PG_DSN or pass dsn"}
        params = args.get("params")
        conn, err = _pg_connect(dsn)
        if err:
            return err
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                cols = [d[0] for d in (cur.description or [])]
                rows = []
                if cur.description:
                    for row in cur.fetchmany(_MAX_ROWS):
                        rows.append([_serialize(v) for v in row])
                return {
                    "ok": True,
                    "columns": cols,
                    "rows": rows,
                    "row_count": len(rows),
                }
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _pg_execute(args: dict) -> dict:
    """Run an INSERT/UPDATE/DELETE. MEDIUM risk."""
    try:
        sql = args.get("sql")
        if not sql:
            return {"ok": False, "error": "sql required"}
        dsn = _pg_dsn(args)
        if not dsn:
            return {"ok": False, "error": "no DSN — set LEON_PG_DSN or pass dsn"}
        params = args.get("params")
        conn, err = _pg_connect(dsn)
        if err:
            return err
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                affected = cur.rowcount
                conn.commit()
                return {"ok": True, "affected_rows": affected}
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            return _err(e)
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _pg_list_tables(args: dict) -> dict:
    """List tables in a schema (default public)."""
    schema = args.get("schema") or "public"
    return _pg_query({
        "sql": (
            "SELECT table_name, table_type "
            "FROM information_schema.tables "
            "WHERE table_schema = %s ORDER BY table_name"
        ),
        "params": (schema,),
        "dsn": args.get("dsn"),
    })


def _pg_table_schema(args: dict) -> dict:
    """Return column names + types for a table."""
    table = args.get("table")
    if not table:
        return {"ok": False, "error": "table required"}
    schema = args.get("schema") or "public"
    return _pg_query({
        "sql": (
            "SELECT column_name, data_type, is_nullable, column_default "
            "FROM information_schema.columns "
            "WHERE table_schema = %s AND table_name = %s "
            "ORDER BY ordinal_position"
        ),
        "params": (schema, table),
        "dsn": args.get("dsn"),
    })


def _pg_explain(args: dict) -> dict:
    """EXPLAIN ANALYZE a query."""
    sql = args.get("sql")
    if not sql:
        return {"ok": False, "error": "sql required"}
    return _pg_query({
        "sql": f"EXPLAIN ANALYZE {sql}",
        "params": args.get("params"),
        "dsn": args.get("dsn"),
    })


def _pg_dump_table(args: dict) -> dict:
    """Dump a table to CSV (returns text or writes to save_to path)."""
    try:
        table = args.get("table")
        if not table:
            return {"ok": False, "error": "table required"}
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_\.]*$", str(table)):
            return {"ok": False, "error": "invalid table identifier"}
        limit = max(1, min(_MAX_ROWS, int(args.get("limit", 1000))))
        save_to = args.get("save_to")
        res = _pg_query({
            "sql": f"SELECT * FROM {table} LIMIT %s",
            "params": (limit,),
            "dsn": args.get("dsn"),
        })
        if not res.get("ok"):
            return res
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(res["columns"])
        for row in res["rows"]:
            writer.writerow(row)
        csv_text = buf.getvalue()
        out: Dict[str, Any] = {
            "ok": True,
            "rows": res["row_count"],
            "columns": res["columns"],
        }
        if save_to:
            try:
                Path(save_to).write_text(csv_text, encoding="utf-8")
                out["saved_to"] = save_to
                out["bytes"] = len(csv_text)
            except Exception as e:
                return _err(e)
        else:
            out["csv"] = csv_text[:200_000]
        return out
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# MYSQL
# ──────────────────────────────────────────────────────────────────────────

def _mysql_parse_dsn(dsn: str) -> Dict[str, Any]:
    """Parse mysql://user:pass@host:port/db into pymysql kwargs."""
    p = urlparse(dsn)
    return {
        "host": p.hostname or "localhost",
        "port": p.port or 3306,
        "user": unquote(p.username) if p.username else None,
        "password": unquote(p.password) if p.password else None,
        "database": (p.path or "/").lstrip("/") or None,
        "connect_timeout": 8,
        "charset": "utf8mb4",
    }


def _mysql_connect(args: dict):
    """Lazy-import pymysql and connect."""
    try:
        import pymysql  # type: ignore
    except ImportError:
        return None, _missing_driver("pymysql", "MySQL")
    dsn = args.get("dsn") or os.environ.get("LEON_MYSQL_DSN")
    if not dsn:
        return None, {"ok": False, "error": "no DSN — set LEON_MYSQL_DSN or pass dsn"}
    try:
        kwargs = _mysql_parse_dsn(dsn)
        kwargs = {k: v for k, v in kwargs.items() if v is not None}
        conn = pymysql.connect(**kwargs)
        return conn, None
    except Exception as e:
        return None, _err(e)


def _mysql_query(args: dict) -> dict:
    """Run a read-only SQL query."""
    try:
        sql = args.get("sql")
        if not sql:
            return {"ok": False, "error": "sql required"}
        conn, err = _mysql_connect(args)
        if err:
            return err
        try:
            with conn.cursor() as cur:
                cur.execute(sql, args.get("params"))
                cols = [d[0] for d in (cur.description or [])]
                rows = []
                if cur.description:
                    for row in cur.fetchmany(_MAX_ROWS):
                        rows.append([_serialize(v) for v in row])
                return {
                    "ok": True,
                    "columns": cols,
                    "rows": rows,
                    "row_count": len(rows),
                }
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _mysql_execute(args: dict) -> dict:
    """Run INSERT/UPDATE/DELETE. MEDIUM risk."""
    try:
        sql = args.get("sql")
        if not sql:
            return {"ok": False, "error": "sql required"}
        conn, err = _mysql_connect(args)
        if err:
            return err
        try:
            with conn.cursor() as cur:
                cur.execute(sql, args.get("params"))
                affected = cur.rowcount
                conn.commit()
                return {"ok": True, "affected_rows": affected}
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            return _err(e)
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _mysql_list_tables(args: dict) -> dict:
    """List tables in current or specified database."""
    try:
        db_name = args.get("database")
        if db_name:
            if not re.match(r"^[A-Za-z0-9_]+$", str(db_name)):
                return {"ok": False, "error": "invalid database name"}
            sql = f"SHOW TABLES FROM `{db_name}`"
        else:
            sql = "SHOW TABLES"
        return _mysql_query({"sql": sql, "dsn": args.get("dsn")})
    except Exception as e:
        return _err(e)


def _mysql_table_schema(args: dict) -> dict:
    """Return column descriptors for a table."""
    table = args.get("table")
    if not table:
        return {"ok": False, "error": "table required"}
    if not re.match(r"^[A-Za-z0-9_]+$", str(table)):
        return {"ok": False, "error": "invalid table name"}
    db_name = args.get("database")
    if db_name:
        if not re.match(r"^[A-Za-z0-9_]+$", str(db_name)):
            return {"ok": False, "error": "invalid database name"}
        sql = f"DESCRIBE `{db_name}`.`{table}`"
    else:
        sql = f"DESCRIBE `{table}`"
    return _mysql_query({"sql": sql, "dsn": args.get("dsn")})


# ──────────────────────────────────────────────────────────────────────────
# MONGODB
# ──────────────────────────────────────────────────────────────────────────

def _mongo_client(args: dict):
    """Lazy-import pymongo and return (db, None) or (None, err)."""
    try:
        import pymongo  # type: ignore
    except ImportError:
        return None, _missing_driver("pymongo", "MongoDB")
    dsn = args.get("dsn") or os.environ.get("LEON_MONGO_DSN")
    if not dsn:
        return None, {"ok": False, "error": "no DSN — set LEON_MONGO_DSN or pass dsn"}
    try:
        client = pymongo.MongoClient(dsn, serverSelectionTimeoutMS=5000)
        db_name = args.get("db_name")
        if not db_name:
            # try DSN-embedded default db
            parsed = urlparse(dsn)
            db_name = (parsed.path or "/").lstrip("/") or None
        if not db_name:
            client.close()
            return None, {"ok": False, "error": "no db_name (pass db_name or include in DSN)"}
        return (client, client[db_name]), None
    except Exception as e:
        return None, _err(e)


def _mongo_find(args: dict) -> dict:
    """Find documents in a collection."""
    try:
        collection = args.get("collection")
        if not collection:
            return {"ok": False, "error": "collection required"}
        limit = max(1, min(_MAX_ROWS, int(args.get("limit", 20))))
        filt = args.get("filter") or {}
        if not isinstance(filt, dict):
            return {"ok": False, "error": "filter must be a dict"}
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            docs = list(db[collection].find(filt).limit(limit))
            return {
                "ok": True,
                "count": len(docs),
                "docs": [_serialize(d) for d in docs],
            }
        finally:
            client.close()
    except Exception as e:
        return _err(e)


def _mongo_insert(args: dict) -> dict:
    """Insert one document. MEDIUM risk."""
    try:
        collection = args.get("collection")
        doc = args.get("doc")
        if not collection or not isinstance(doc, dict):
            return {"ok": False, "error": "collection and doc (dict) required"}
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            result = db[collection].insert_one(doc)
            return {"ok": True, "inserted_id": str(result.inserted_id)}
        finally:
            client.close()
    except Exception as e:
        return _err(e)


def _mongo_update(args: dict) -> dict:
    """Update many documents. MEDIUM risk."""
    try:
        collection = args.get("collection")
        filt = args.get("filter")
        update = args.get("update")
        if not collection or not isinstance(filt, dict) or not isinstance(update, dict):
            return {"ok": False, "error": "collection, filter (dict), update (dict) required"}
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            # if user passed raw doc without operators, wrap in $set
            if not any(k.startswith("$") for k in update.keys()):
                update = {"$set": update}
            result = db[collection].update_many(filt, update)
            return {
                "ok": True,
                "matched": result.matched_count,
                "modified": result.modified_count,
            }
        finally:
            client.close()
    except Exception as e:
        return _err(e)


def _mongo_delete(args: dict) -> dict:
    """Delete documents matching filter. HIGH risk."""
    try:
        collection = args.get("collection")
        filt = args.get("filter")
        if not collection or not isinstance(filt, dict):
            return {"ok": False, "error": "collection and filter (dict) required"}
        if not filt:
            return {"ok": False, "error": "refusing empty filter — pass explicit filter (use {} via force=true to bypass)"}
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            result = db[collection].delete_many(filt)
            return {"ok": True, "deleted": result.deleted_count}
        finally:
            client.close()
    except Exception as e:
        return _err(e)


def _mongo_list_collections(args: dict) -> dict:
    """List collection names in the database."""
    try:
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            names = db.list_collection_names()
            return {"ok": True, "collections": sorted(names), "count": len(names)}
        finally:
            client.close()
    except Exception as e:
        return _err(e)


def _mongo_aggregate(args: dict) -> dict:
    """Run an aggregation pipeline."""
    try:
        collection = args.get("collection")
        pipeline = args.get("pipeline")
        if not collection or not isinstance(pipeline, list):
            return {"ok": False, "error": "collection and pipeline (list) required"}
        limit = max(1, min(_MAX_ROWS, int(args.get("limit", 20))))
        bundle, err = _mongo_client(args)
        if err:
            return err
        client, db = bundle
        try:
            cursor = db[collection].aggregate(pipeline)
            docs = []
            for i, d in enumerate(cursor):
                if i >= limit:
                    break
                docs.append(_serialize(d))
            return {"ok": True, "count": len(docs), "docs": docs}
        finally:
            client.close()
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# REDIS
# ──────────────────────────────────────────────────────────────────────────

def _redis_client(args: dict):
    """Lazy-import redis and return (client, None) or (None, err)."""
    try:
        import redis  # type: ignore
    except ImportError:
        return None, _missing_driver("redis", "Redis")
    dsn = args.get("dsn") or os.environ.get("LEON_REDIS_DSN") or "redis://127.0.0.1:6379/0"
    try:
        client = redis.Redis.from_url(dsn, socket_timeout=5, decode_responses=True)
        # ping to surface auth/host errors immediately
        client.ping()
        return client, None
    except Exception as e:
        return None, _err(e)


def _redis_get(args: dict) -> dict:
    """GET a key."""
    try:
        key = args.get("key")
        if not key:
            return {"ok": False, "error": "key required"}
        client, err = _redis_client(args)
        if err:
            return err
        try:
            val = client.get(key)
            ttl = client.ttl(key)
            ktype = client.type(key)
            return {
                "ok": True,
                "key": key,
                "value": val,
                "exists": val is not None,
                "ttl": ttl if ttl >= 0 else None,
                "type": ktype,
            }
        finally:
            try:
                client.close()
            except Exception:
                pass
    except Exception as e:
        return _err(e)


def _redis_set(args: dict) -> dict:
    """SET a key (optionally with TTL). MEDIUM risk."""
    try:
        key = args.get("key")
        value = args.get("value")
        if not key or value is None:
            return {"ok": False, "error": "key and value required"}
        ttl = args.get("ttl_seconds")
        client, err = _redis_client(args)
        if err:
            return err
        try:
            if ttl is not None:
                client.setex(key, int(ttl), value)
            else:
                client.set(key, value)
            return {"ok": True, "key": key, "ttl": ttl}
        finally:
            try:
                client.close()
            except Exception:
                pass
    except Exception as e:
        return _err(e)


def _redis_keys(args: dict) -> dict:
    """SCAN keys by pattern (safer than KEYS)."""
    try:
        pattern = args.get("pattern") or "*"
        limit = max(1, min(10_000, int(args.get("limit", 100))))
        client, err = _redis_client(args)
        if err:
            return err
        try:
            found: List[str] = []
            for k in client.scan_iter(match=pattern, count=500):
                found.append(k)
                if len(found) >= limit:
                    break
            return {
                "ok": True,
                "pattern": pattern,
                "count": len(found),
                "keys": found,
                "truncated": len(found) >= limit,
            }
        finally:
            try:
                client.close()
            except Exception:
                pass
    except Exception as e:
        return _err(e)


def _redis_delete(args: dict) -> dict:
    """DEL a key. MEDIUM risk."""
    try:
        key = args.get("key")
        if not key:
            return {"ok": False, "error": "key required"}
        client, err = _redis_client(args)
        if err:
            return err
        try:
            n = client.delete(key)
            return {"ok": True, "deleted": n}
        finally:
            try:
                client.close()
            except Exception:
                pass
    except Exception as e:
        return _err(e)


def _redis_info(args: dict) -> dict:
    """Return Redis server INFO (memory, clients, stats)."""
    try:
        client, err = _redis_client(args)
        if err:
            return err
        try:
            info = client.info()
            slim = {
                "redis_version": info.get("redis_version"),
                "uptime_seconds": info.get("uptime_in_seconds"),
                "connected_clients": info.get("connected_clients"),
                "used_memory_human": info.get("used_memory_human"),
                "used_memory_peak_human": info.get("used_memory_peak_human"),
                "total_commands_processed": info.get("total_commands_processed"),
                "instantaneous_ops_per_sec": info.get("instantaneous_ops_per_sec"),
                "keyspace_hits": info.get("keyspace_hits"),
                "keyspace_misses": info.get("keyspace_misses"),
                "role": info.get("role"),
            }
            return {"ok": True, "info": slim}
        finally:
            try:
                client.close()
            except Exception:
                pass
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SQLITE
# ──────────────────────────────────────────────────────────────────────────

def _sqlite_open(path: str):
    """Open a sqlite file. Returns (conn, None) or (None, err)."""
    try:
        import sqlite3
    except ImportError:
        return None, _missing_driver("sqlite3", "SQLite")  # bundled with python normally
    p = Path(path).expanduser()
    if not p.exists():
        return None, {"ok": False, "error": f"sqlite file not found: {p}"}
    try:
        conn = sqlite3.connect(str(p), timeout=8.0)
        return conn, None
    except Exception as e:
        return None, _err(e)


_SQLITE_READONLY = re.compile(r"^\s*(SELECT|WITH|EXPLAIN|PRAGMA)\b", re.IGNORECASE)


def _sqlite_query(args: dict) -> dict:
    """Run a read-only SQL query against a sqlite file."""
    try:
        path = args.get("path")
        sql = args.get("sql")
        if not path or not sql:
            return {"ok": False, "error": "path and sql required"}
        if not _SQLITE_READONLY.match(sql):
            return {"ok": False, "error": "sqlite_query is read-only — use sqlite_execute for writes"}
        conn, err = _sqlite_open(path)
        if err:
            return err
        try:
            cur = conn.cursor()
            cur.execute(sql, args.get("params") or [])
            cols = [d[0] for d in (cur.description or [])]
            rows = [[_serialize(v) for v in r] for r in cur.fetchmany(_MAX_ROWS)]
            return {
                "ok": True,
                "columns": cols,
                "rows": rows,
                "row_count": len(rows),
            }
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _sqlite_execute(args: dict) -> dict:
    """Run INSERT/UPDATE/DELETE/DDL on a sqlite file. MEDIUM risk."""
    try:
        path = args.get("path")
        sql = args.get("sql")
        if not path or not sql:
            return {"ok": False, "error": "path and sql required"}
        conn, err = _sqlite_open(path)
        if err:
            return err
        try:
            cur = conn.cursor()
            cur.execute(sql, args.get("params") or [])
            affected = cur.rowcount
            conn.commit()
            return {"ok": True, "affected_rows": affected}
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            return _err(e)
        finally:
            conn.close()
    except Exception as e:
        return _err(e)


def _sqlite_list_tables(args: dict) -> dict:
    """List tables in a sqlite file."""
    path = args.get("path")
    if not path:
        return {"ok": False, "error": "path required"}
    return _sqlite_query({
        "path": path,
        "sql": "SELECT name, type FROM sqlite_master WHERE type IN ('table','view') ORDER BY name",
    })


# ──────────────────────────────────────────────────────────────────────────
# DEVOPS — KUBECTL / SYSTEMD / LOGS
# ──────────────────────────────────────────────────────────────────────────

def _kubectl_get(args: dict) -> dict:
    """kubectl get <resource> [-n ns] [name] -o json."""
    try:
        resource = args.get("resource")
        if not resource:
            return {"ok": False, "error": "resource required (e.g. pods, deployments)"}
        if not shutil.which("kubectl"):
            return {"ok": False, "error": "kubectl not on PATH"}
        cmd = ["kubectl", "get", str(resource)]
        if args.get("name"):
            cmd.append(str(args["name"]))
        if args.get("namespace"):
            cmd.extend(["-n", str(args["namespace"])])
        else:
            cmd.append("--all-namespaces")
        cmd.extend(["-o", "json"])
        res = _run_cmd(cmd, timeout=20.0)
        if not res.get("ok"):
            return {"ok": False, "error": res.get("stderr") or res.get("error") or "kubectl failed"}
        try:
            data = json.loads(res["stdout"])
        except Exception:
            return {"ok": True, "raw": res["stdout"][:50_000]}
        # slim down — pull a useful summary if it's a List
        if isinstance(data, dict) and data.get("kind", "").endswith("List"):
            items = data.get("items", [])
            summary = []
            for it in items[:200]:
                meta = it.get("metadata", {}) or {}
                status = it.get("status", {}) or {}
                summary.append({
                    "name": meta.get("name"),
                    "namespace": meta.get("namespace"),
                    "kind": it.get("kind"),
                    "phase": status.get("phase"),
                    "ready": status.get("readyReplicas") or status.get("availableReplicas"),
                    "created": meta.get("creationTimestamp"),
                })
            return {"ok": True, "count": len(items), "items": summary}
        return {"ok": True, "data": data}
    except Exception as e:
        return _err(e)


def _kubectl_logs(args: dict) -> dict:
    """kubectl logs <pod> [-n ns] [--tail N]."""
    try:
        pod = args.get("pod")
        if not pod:
            return {"ok": False, "error": "pod required"}
        if not shutil.which("kubectl"):
            return {"ok": False, "error": "kubectl not on PATH"}
        lines = max(1, min(10_000, int(args.get("lines", 100))))
        cmd = ["kubectl", "logs", str(pod), "--tail", str(lines)]
        if args.get("namespace"):
            cmd.extend(["-n", str(args["namespace"])])
        res = _run_cmd(cmd, timeout=20.0)
        if not res.get("ok"):
            return {"ok": False, "error": res.get("stderr") or res.get("error") or "kubectl logs failed"}
        return {"ok": True, "pod": pod, "lines": lines, "logs": res["stdout"][-200_000:]}
    except Exception as e:
        return _err(e)


def _systemd_list(args: dict, user: bool) -> dict:
    """Shared helper for systemctl list-units."""
    try:
        if not shutil.which("systemctl"):
            return {"ok": False, "error": "systemctl not on PATH"}
        state = str(args.get("state") or "all")
        cmd = ["systemctl"]
        if user:
            cmd.append("--user")
        cmd.extend(["list-units", "--type=service", f"--state={state}",
                    "--no-pager", "--plain", "--no-legend"])
        res = _run_cmd(cmd, timeout=15.0)
        if not res.get("ok"):
            return {"ok": False, "error": res.get("stderr") or res.get("error") or "systemctl failed"}
        services = []
        for line in res["stdout"].splitlines():
            parts = line.split(None, 4)
            if len(parts) >= 4:
                services.append({
                    "unit": parts[0],
                    "load": parts[1],
                    "active": parts[2],
                    "sub": parts[3],
                    "description": parts[4] if len(parts) > 4 else "",
                })
        return {"ok": True, "scope": "user" if user else "system",
                "count": len(services), "services": services}
    except Exception as e:
        return _err(e)


def _systemd_list_user_services(args: dict) -> dict:
    """systemctl --user list-units --type=service."""
    return _systemd_list(args, user=True)


def _systemd_list_system_services(args: dict) -> dict:
    """systemctl list-units --type=service."""
    return _systemd_list(args, user=False)


def _systemd_service_logs(args: dict) -> dict:
    """journalctl for a systemd service (user or system)."""
    try:
        service = args.get("service")
        if not service:
            return {"ok": False, "error": "service required"}
        if not shutil.which("journalctl"):
            return {"ok": False, "error": "journalctl not on PATH"}
        lines = max(1, min(10_000, int(args.get("lines", 200))))
        user = bool(args.get("user", True))
        cmd = ["journalctl"]
        if user:
            cmd.append("--user")
        cmd.extend(["-u", str(service), "-n", str(lines), "--no-pager", "-o", "short-iso"])
        res = _run_cmd(cmd, timeout=15.0)
        if not res.get("ok"):
            return {"ok": False, "error": res.get("stderr") or res.get("error") or "journalctl failed"}
        return {
            "ok": True,
            "service": service,
            "scope": "user" if user else "system",
            "lines": lines,
            "logs": res["stdout"][-200_000:],
        }
    except Exception as e:
        return _err(e)


def _log_grep(args: dict) -> dict:
    """Grep a log file with line numbers + context."""
    try:
        path = args.get("file_path")
        pattern = args.get("pattern")
        if not path or not pattern:
            return {"ok": False, "error": "file_path and pattern required"}
        p = Path(path).expanduser()
        if not p.exists() or not p.is_file():
            return {"ok": False, "error": f"file not found: {p}"}
        lines_around = max(0, min(50, int(args.get("lines_around", 5))))
        limit = max(1, min(1000, int(args.get("limit", 50))))
        try:
            regex = re.compile(pattern)
        except re.error as e:
            return {"ok": False, "error": f"invalid regex: {e}"}
        # stream the file; cap at ~20MB
        max_bytes = 20 * 1024 * 1024
        try:
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read(max_bytes)
        except Exception as e:
            return _err(e)
        lines = raw.splitlines()
        matches: List[Dict[str, Any]] = []
        for i, line in enumerate(lines):
            if regex.search(line):
                start = max(0, i - lines_around)
                end = min(len(lines), i + lines_around + 1)
                context = [
                    {"line_no": j + 1, "text": lines[j], "match": j == i}
                    for j in range(start, end)
                ]
                matches.append({"line_no": i + 1, "text": line, "context": context})
                if len(matches) >= limit:
                    break
        return {
            "ok": True,
            "file": str(p),
            "pattern": pattern,
            "matches": matches,
            "match_count": len(matches),
            "truncated": len(matches) >= limit,
            "bytes_scanned": len(raw),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Postgres
    "db.pg_query": _pg_query,
    "db.pg_execute": _pg_execute,
    "db.pg_list_tables": _pg_list_tables,
    "db.pg_table_schema": _pg_table_schema,
    "db.pg_explain": _pg_explain,
    "db.pg_dump_table": _pg_dump_table,
    # MySQL
    "db.mysql_query": _mysql_query,
    "db.mysql_execute": _mysql_execute,
    "db.mysql_list_tables": _mysql_list_tables,
    "db.mysql_table_schema": _mysql_table_schema,
    # MongoDB
    "db.mongo_find": _mongo_find,
    "db.mongo_insert": _mongo_insert,
    "db.mongo_update": _mongo_update,
    "db.mongo_delete": _mongo_delete,
    "db.mongo_list_collections": _mongo_list_collections,
    "db.mongo_aggregate": _mongo_aggregate,
    # Redis
    "db.redis_get": _redis_get,
    "db.redis_set": _redis_set,
    "db.redis_keys": _redis_keys,
    "db.redis_delete": _redis_delete,
    "db.redis_info": _redis_info,
    # SQLite
    "db.sqlite_query": _sqlite_query,
    "db.sqlite_execute": _sqlite_execute,
    "db.sqlite_list_tables": _sqlite_list_tables,
    # DevOps
    "devops.kubectl_get": _kubectl_get,
    "devops.kubectl_logs": _kubectl_logs,
    "devops.systemd_list_user_services": _systemd_list_user_services,
    "devops.systemd_list_system_services": _systemd_list_system_services,
    "devops.systemd_service_logs": _systemd_service_logs,
    "devops.log_grep": _log_grep,
}
