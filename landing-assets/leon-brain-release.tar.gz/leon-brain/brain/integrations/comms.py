"""comms.py — Leon's outbound comms hub (Discord, Slack, Telegram, webhooks).

Each tool reads credentials lazily (env first, then `~/.openclaw/secrets.json`),
makes a single `requests` call with an 8s default timeout, and returns the
standard `{ok, ...}` contract used by the rest of the brain. Nothing in this
module raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `discord.send_message`)
to callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - DISCORD_BOT_TOKEN
  - SLACK_BOT_TOKEN  (xoxb-…)
  - TELEGRAM_BOT_TOKEN

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object,
e.g. `{"DISCORD_BOT_TOKEN": "...", "SLACK_BOT_TOKEN": "...", ...}`.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 8.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file.

    Returns `{}` on any error — caller will fall through to a missing
    credential message. Never raises, never logs values.
    """
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    """Decode a Response into JSON when possible, else return raw text."""
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": resp.text[:2000]}


# ──────────────────────────────────────────────────────────────────────────
# DISCORD
# ──────────────────────────────────────────────────────────────────────────

_DISCORD_API = "https://discord.com/api/v10"


def _discord_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("DISCORD_BOT_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bot {tok}",
        "Content-Type": "application/json",
        "User-Agent": "LeonBot (47industries, v1.0)",
    }


def _discord_send_message(args: dict) -> dict:
    """POST a message to a Discord channel."""
    try:
        channel_id = str(args.get("channel_id", "")).strip()
        content = str(args.get("content", ""))
        if not channel_id or not content:
            return {"ok": False, "error": "channel_id and content required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.post(
            f"{_DISCORD_API}/channels/{channel_id}/messages",
            headers=headers,
            json={"content": content[:2000]},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "message_id": data.get("id"), "channel_id": channel_id}
    except Exception as e:
        return _err(e)


def _discord_send_dm(args: dict) -> dict:
    """Open (or fetch) a DM channel with a user and post to it."""
    try:
        user_id = str(args.get("user_id", "")).strip()
        content = str(args.get("content", ""))
        if not user_id or not content:
            return {"ok": False, "error": "user_id and content required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        # 1) open DM channel
        r = requests.post(
            f"{_DISCORD_API}/users/@me/channels",
            headers=headers,
            json={"recipient_id": user_id},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"open-dm HTTP {r.status_code}", **_wrap_http(r)}
        dm = r.json()
        dm_channel = dm.get("id")
        if not dm_channel:
            return {"ok": False, "error": "no DM channel id returned"}
        # 2) post
        return _discord_send_message({"channel_id": dm_channel, "content": content})
    except Exception as e:
        return _err(e)


def _discord_list_recent_messages(args: dict) -> dict:
    """GET recent messages from a channel (default limit=20, max 100)."""
    try:
        channel_id = str(args.get("channel_id", "")).strip()
        if not channel_id:
            return {"ok": False, "error": "channel_id required"}
        limit = max(1, min(100, int(args.get("limit", 20))))
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.get(
            f"{_DISCORD_API}/channels/{channel_id}/messages",
            headers=headers,
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        msgs = r.json() or []
        compact = [
            {
                "id": m.get("id"),
                "author": (m.get("author") or {}).get("username"),
                "author_id": (m.get("author") or {}).get("id"),
                "content": m.get("content", ""),
                "ts": m.get("timestamp"),
                "mentions": [u.get("id") for u in m.get("mentions", [])],
            }
            for m in msgs
        ]
        return {"ok": True, "messages": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _discord_list_channels(args: dict) -> dict:
    """List text/voice channels in a guild."""
    try:
        guild_id = str(args.get("guild_id", "")).strip()
        if not guild_id:
            return {"ok": False, "error": "guild_id required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.get(
            f"{_DISCORD_API}/guilds/{guild_id}/channels",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        chans = r.json() or []
        compact = [
            {"id": c.get("id"), "name": c.get("name"), "type": c.get("type")}
            for c in chans
        ]
        return {"ok": True, "channels": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _discord_list_guilds(args: dict) -> dict:
    """List guilds (servers) the bot belongs to."""
    try:
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.get(
            f"{_DISCORD_API}/users/@me/guilds",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        guilds = r.json() or []
        compact = [{"id": g.get("id"), "name": g.get("name")} for g in guilds]
        return {"ok": True, "guilds": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _discord_edit_message(args: dict) -> dict:
    """PATCH a previously-sent message."""
    try:
        channel_id = str(args.get("channel_id", "")).strip()
        message_id = str(args.get("message_id", "")).strip()
        content = str(args.get("content", ""))
        if not channel_id or not message_id or not content:
            return {"ok": False, "error": "channel_id, message_id, content required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.patch(
            f"{_DISCORD_API}/channels/{channel_id}/messages/{message_id}",
            headers=headers,
            json={"content": content[:2000]},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "message_id": message_id}
    except Exception as e:
        return _err(e)


def _discord_delete_message(args: dict) -> dict:
    """DELETE a message."""
    try:
        channel_id = str(args.get("channel_id", "")).strip()
        message_id = str(args.get("message_id", "")).strip()
        if not channel_id or not message_id:
            return {"ok": False, "error": "channel_id and message_id required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        r = requests.delete(
            f"{_DISCORD_API}/channels/{channel_id}/messages/{message_id}",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "message_id": message_id, "deleted": True}
    except Exception as e:
        return _err(e)


def _discord_add_reaction(args: dict) -> dict:
    """Add an emoji reaction to a message. Emoji may be a unicode char or `name:id` for custom."""
    try:
        channel_id = str(args.get("channel_id", "")).strip()
        message_id = str(args.get("message_id", "")).strip()
        emoji = str(args.get("emoji", "")).strip()
        if not channel_id or not message_id or not emoji:
            return {"ok": False, "error": "channel_id, message_id, emoji required"}
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")
        # The emoji must be URL-encoded; requests handles that via params, but
        # the Discord endpoint expects it embedded in the path, so quote it.
        from urllib.parse import quote
        emoji_q = quote(emoji, safe="")
        r = requests.put(
            f"{_DISCORD_API}/channels/{channel_id}/messages/{message_id}/reactions/{emoji_q}/@me",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "message_id": message_id, "emoji": emoji}
    except Exception as e:
        return _err(e)


def _discord_poll_mentions(args: dict) -> dict:
    """Scan recent messages across guild channels for mentions of the bot.

    REST-only — no gateway. Iterates guilds → text channels → last N messages
    and filters for the bot's own user id. Best-effort; tolerant of permission
    errors per channel.
    """
    try:
        since_ts = args.get("since_ts")  # ISO 8601 string or None
        per_channel_limit = max(1, min(50, int(args.get("limit", 10))))
        headers = _discord_headers()
        if not headers:
            return _missing("DISCORD_BOT_TOKEN", "Discord")

        # 1) who am I
        me = requests.get(f"{_DISCORD_API}/users/@me", headers=headers,
                          timeout=_DEFAULT_TIMEOUT)
        if me.status_code >= 400:
            return {"ok": False, "error": f"@me HTTP {me.status_code}", **_wrap_http(me)}
        my_id = (me.json() or {}).get("id")
        if not my_id:
            return {"ok": False, "error": "could not determine bot user id"}

        # 2) iterate guilds → channels
        guilds_r = requests.get(f"{_DISCORD_API}/users/@me/guilds",
                                headers=headers, timeout=_DEFAULT_TIMEOUT)
        if guilds_r.status_code >= 400:
            return {"ok": False, "error": f"guilds HTTP {guilds_r.status_code}",
                    **_wrap_http(guilds_r)}
        guilds = guilds_r.json() or []

        hits: List[Dict[str, Any]] = []
        for g in guilds[:25]:  # safety cap
            gid = g.get("id")
            try:
                cr = requests.get(f"{_DISCORD_API}/guilds/{gid}/channels",
                                  headers=headers, timeout=_DEFAULT_TIMEOUT)
                if cr.status_code >= 400:
                    continue
                for c in (cr.json() or []):
                    # type 0 = GUILD_TEXT; 5 = ANNOUNCEMENT
                    if c.get("type") not in (0, 5):
                        continue
                    cid = c.get("id")
                    try:
                        mr = requests.get(
                            f"{_DISCORD_API}/channels/{cid}/messages",
                            headers=headers,
                            params={"limit": per_channel_limit},
                            timeout=_DEFAULT_TIMEOUT,
                        )
                        if mr.status_code >= 400:
                            continue
                        for m in (mr.json() or []):
                            if since_ts and m.get("timestamp", "") <= str(since_ts):
                                continue
                            mention_ids = [u.get("id") for u in m.get("mentions", [])]
                            if my_id in mention_ids:
                                hits.append({
                                    "guild_id": gid,
                                    "channel_id": cid,
                                    "channel_name": c.get("name"),
                                    "message_id": m.get("id"),
                                    "author": (m.get("author") or {}).get("username"),
                                    "author_id": (m.get("author") or {}).get("id"),
                                    "content": m.get("content", ""),
                                    "ts": m.get("timestamp"),
                                })
                    except Exception:
                        continue
            except Exception:
                continue
        return {"ok": True, "mentions": hits, "count": len(hits)}
    except Exception as e:
        return _err(e)


def _discord_set_status(args: dict) -> dict:
    """Stub — setting bot presence requires a gateway (websocket) connection.

    This module is REST-only, so we return a structured `not_supported` envelope
    rather than silently fail. Callers should treat this as informational.
    """
    activity_type = args.get("activity_type", "")
    name = args.get("name", "")
    return {
        "ok": False,
        "error": "not_supported: Discord presence requires a gateway "
                 "(websocket) connection — this REST module can't set status",
        "requested": {"activity_type": activity_type, "name": name},
    }


# ──────────────────────────────────────────────────────────────────────────
# SLACK
# ──────────────────────────────────────────────────────────────────────────

_SLACK_API = "https://slack.com/api"


def _slack_headers(json_body: bool = True) -> Optional[Dict[str, str]]:
    tok = _get_secret("SLACK_BOT_TOKEN")
    if not tok:
        return None
    h = {"Authorization": f"Bearer {tok}"}
    if json_body:
        h["Content-Type"] = "application/json; charset=utf-8"
    return h


def _slack_ok(payload: dict) -> Dict[str, Any]:
    """Slack returns 200 with `{ok: false, error: "..."}` on logical errors."""
    if not isinstance(payload, dict):
        return {"ok": False, "error": "slack returned non-dict payload"}
    if not payload.get("ok"):
        return {"ok": False, "error": f"slack: {payload.get('error', 'unknown')}",
                "raw": payload}
    return {"ok": True, **{k: v for k, v in payload.items() if k != "ok"}}


def _slack_send_message(args: dict) -> dict:
    """chat.postMessage — send `text` to `channel` (id or name with #)."""
    try:
        channel = str(args.get("channel", "")).strip()
        text = str(args.get("text", ""))
        if not channel or not text:
            return {"ok": False, "error": "channel and text required"}
        headers = _slack_headers()
        if not headers:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        r = requests.post(
            f"{_SLACK_API}/chat.postMessage",
            headers=headers,
            json={"channel": channel, "text": text},
            timeout=_DEFAULT_TIMEOUT,
        )
        return _slack_ok(r.json())
    except Exception as e:
        return _err(e)


def _slack_list_channels(args: dict) -> dict:
    """conversations.list — public + private channels the bot can see."""
    try:
        headers = _slack_headers(json_body=False)
        if not headers:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        r = requests.get(
            f"{_SLACK_API}/conversations.list",
            headers=headers,
            params={"limit": 200, "types": "public_channel,private_channel"},
            timeout=_DEFAULT_TIMEOUT,
        )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"slack: {payload.get('error')}", "raw": payload}
        chans = payload.get("channels", []) or []
        compact = [
            {"id": c.get("id"), "name": c.get("name"),
             "is_private": c.get("is_private", False),
             "num_members": c.get("num_members")}
            for c in chans
        ]
        return {"ok": True, "channels": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _slack_list_users(args: dict) -> dict:
    """users.list — directory."""
    try:
        headers = _slack_headers(json_body=False)
        if not headers:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        r = requests.get(
            f"{_SLACK_API}/users.list",
            headers=headers,
            params={"limit": 200},
            timeout=_DEFAULT_TIMEOUT,
        )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"slack: {payload.get('error')}", "raw": payload}
        members = payload.get("members", []) or []
        compact = [
            {"id": m.get("id"),
             "name": m.get("name"),
             "real_name": m.get("real_name"),
             "is_bot": m.get("is_bot", False),
             "deleted": m.get("deleted", False)}
            for m in members
        ]
        return {"ok": True, "users": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _slack_poll_mentions(args: dict) -> dict:
    """search.messages for the bot's own @mention. Needs `search:read` scope
    (user token usually). Falls back to clean error if Slack rejects."""
    try:
        since_ts = args.get("since_ts")  # unix seconds or slack ts string
        headers = _slack_headers(json_body=False)
        if not headers:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        # discover own user id
        who = requests.get(f"{_SLACK_API}/auth.test", headers=headers,
                           timeout=_DEFAULT_TIMEOUT).json()
        if not who.get("ok"):
            return {"ok": False, "error": f"slack auth.test: {who.get('error')}", "raw": who}
        my_id = who.get("user_id")
        query = f"<@{my_id}>"
        r = requests.get(
            f"{_SLACK_API}/search.messages",
            headers=headers,
            params={"query": query, "count": 50, "sort": "timestamp"},
            timeout=_DEFAULT_TIMEOUT,
        )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"slack: {payload.get('error')}", "raw": payload}
        matches = (payload.get("messages") or {}).get("matches", []) or []
        hits = []
        for m in matches:
            ts = m.get("ts", "")
            if since_ts and ts and float(ts) <= float(since_ts):
                continue
            hits.append({
                "channel": (m.get("channel") or {}).get("id"),
                "channel_name": (m.get("channel") or {}).get("name"),
                "ts": ts,
                "user": m.get("user"),
                "username": m.get("username"),
                "text": m.get("text", ""),
                "permalink": m.get("permalink"),
            })
        return {"ok": True, "mentions": hits, "count": len(hits)}
    except Exception as e:
        return _err(e)


def _slack_upload_file(args: dict) -> dict:
    """files.upload — attach a file from disk into `channel` with optional comment."""
    try:
        channel = str(args.get("channel", "")).strip()
        file_path = str(args.get("file_path", "")).strip()
        comment = str(args.get("comment", ""))
        if not channel or not file_path:
            return {"ok": False, "error": "channel and file_path required"}
        if not os.path.exists(file_path):
            return {"ok": False, "error": f"file not found: {file_path}"}
        tok = _get_secret("SLACK_BOT_TOKEN")
        if not tok:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        # multipart — don't set Content-Type ourselves
        with open(file_path, "rb") as fh:
            r = requests.post(
                f"{_SLACK_API}/files.upload",
                headers={"Authorization": f"Bearer {tok}"},
                data={"channels": channel,
                      "initial_comment": comment,
                      "filename": os.path.basename(file_path)},
                files={"file": fh},
                timeout=_DEFAULT_TIMEOUT,
            )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"slack: {payload.get('error')}", "raw": payload}
        return {"ok": True, "file_id": (payload.get("file") or {}).get("id"),
                "channel": channel}
    except Exception as e:
        return _err(e)


def _slack_add_reaction(args: dict) -> dict:
    """reactions.add — emoji name without colons (e.g. `thumbsup`)."""
    try:
        channel = str(args.get("channel", "")).strip()
        ts = str(args.get("ts", "")).strip()
        emoji = str(args.get("emoji", "")).strip().strip(":")
        if not channel or not ts or not emoji:
            return {"ok": False, "error": "channel, ts, emoji required"}
        headers = _slack_headers()
        if not headers:
            return _missing("SLACK_BOT_TOKEN", "Slack")
        r = requests.post(
            f"{_SLACK_API}/reactions.add",
            headers=headers,
            json={"channel": channel, "timestamp": ts, "name": emoji},
            timeout=_DEFAULT_TIMEOUT,
        )
        return _slack_ok(r.json())
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TELEGRAM
# ──────────────────────────────────────────────────────────────────────────


def _telegram_base() -> Optional[str]:
    tok = _get_secret("TELEGRAM_BOT_TOKEN")
    if not tok:
        return None
    return f"https://api.telegram.org/bot{tok}"


def _telegram_send_message(args: dict) -> dict:
    """sendMessage — text to a chat_id."""
    try:
        chat_id = args.get("chat_id")
        text = str(args.get("text", ""))
        if chat_id in (None, "") or not text:
            return {"ok": False, "error": "chat_id and text required"}
        base = _telegram_base()
        if not base:
            return _missing("TELEGRAM_BOT_TOKEN", "Telegram")
        r = requests.post(
            f"{base}/sendMessage",
            json={"chat_id": chat_id, "text": text},
            timeout=_DEFAULT_TIMEOUT,
        )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"telegram: {payload.get('description')}",
                    "raw": payload}
        return {"ok": True, "message_id": (payload.get("result") or {}).get("message_id")}
    except Exception as e:
        return _err(e)


def _telegram_send_photo(args: dict) -> dict:
    """sendPhoto — upload an image file with optional caption."""
    try:
        chat_id = args.get("chat_id")
        image_path = str(args.get("image_path", "")).strip()
        caption = str(args.get("caption", ""))
        if chat_id in (None, "") or not image_path:
            return {"ok": False, "error": "chat_id and image_path required"}
        if not os.path.exists(image_path):
            return {"ok": False, "error": f"image not found: {image_path}"}
        base = _telegram_base()
        if not base:
            return _missing("TELEGRAM_BOT_TOKEN", "Telegram")
        with open(image_path, "rb") as fh:
            r = requests.post(
                f"{base}/sendPhoto",
                data={"chat_id": chat_id, "caption": caption},
                files={"photo": fh},
                timeout=_DEFAULT_TIMEOUT,
            )
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"telegram: {payload.get('description')}",
                    "raw": payload}
        return {"ok": True, "message_id": (payload.get("result") or {}).get("message_id")}
    except Exception as e:
        return _err(e)


def _telegram_get_updates(args: dict) -> dict:
    """getUpdates — short-poll for new messages (offset = last update_id + 1)."""
    try:
        offset = args.get("offset")
        base = _telegram_base()
        if not base:
            return _missing("TELEGRAM_BOT_TOKEN", "Telegram")
        params: Dict[str, Any] = {"timeout": 0, "limit": 50}
        if offset is not None:
            params["offset"] = offset
        r = requests.get(f"{base}/getUpdates", params=params,
                         timeout=_DEFAULT_TIMEOUT)
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"telegram: {payload.get('description')}",
                    "raw": payload}
        updates = payload.get("result", []) or []
        compact = []
        for u in updates:
            msg = u.get("message") or u.get("edited_message") or {}
            compact.append({
                "update_id": u.get("update_id"),
                "chat_id": (msg.get("chat") or {}).get("id"),
                "from": (msg.get("from") or {}).get("username")
                        or (msg.get("from") or {}).get("first_name"),
                "from_id": (msg.get("from") or {}).get("id"),
                "text": msg.get("text", ""),
                "date": msg.get("date"),
            })
        return {"ok": True, "updates": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _telegram_set_webhook(args: dict) -> dict:
    """setWebhook — register a public URL to receive updates."""
    try:
        url = str(args.get("url", "")).strip()
        if not url:
            return {"ok": False, "error": "url required"}
        base = _telegram_base()
        if not base:
            return _missing("TELEGRAM_BOT_TOKEN", "Telegram")
        r = requests.post(f"{base}/setWebhook", json={"url": url},
                          timeout=_DEFAULT_TIMEOUT)
        payload = r.json()
        if not payload.get("ok"):
            return {"ok": False, "error": f"telegram: {payload.get('description')}",
                    "raw": payload}
        return {"ok": True, "url": url, "description": payload.get("description")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GENERIC
# ──────────────────────────────────────────────────────────────────────────

# Whitelist for `comms.webhook_post`. Anything not matching is rejected — this
# keeps Leon from being weaponized to spray arbitrary endpoints.
_WEBHOOK_WHITELIST = (
    "discord.com",
    "discordapp.com",
    "slack.com",
    "hooks.slack.com",
    "api.telegram.org",
    "your-webhook-server.com",
)
_WEBHOOK_SUFFIXES = (".ifttt.com",)


def _host_allowed(host: str) -> bool:
    host = (host or "").lower()
    if host in _WEBHOOK_WHITELIST:
        return True
    if any(host.endswith(s) for s in _WEBHOOK_SUFFIXES):
        return True
    # also allow subdomains of explicit hosts (e.g. maker.ifttt.com is covered
    # above, hooks.slack.com is already explicit)
    for w in _WEBHOOK_WHITELIST:
        if host.endswith("." + w):
            return True
    return False


def _comms_webhook_post(args: dict) -> dict:
    """Generic JSON POST to a whitelisted host. `json_payload` is the body."""
    try:
        url = str(args.get("url", "")).strip()
        payload = args.get("json_payload")
        if not url:
            return {"ok": False, "error": "url required"}
        if payload is None:
            return {"ok": False, "error": "json_payload required"}
        from urllib.parse import urlparse
        host = urlparse(url).hostname or ""
        if not _host_allowed(host):
            return {"ok": False,
                    "error": f"host not whitelisted: {host} "
                             f"(allowed: {', '.join(_WEBHOOK_WHITELIST)} "
                             f"and *{_WEBHOOK_SUFFIXES[0]})"}
        r = requests.post(url, json=payload, timeout=_DEFAULT_TIMEOUT)
        return {"ok": r.status_code < 400, **_wrap_http(r)}
    except Exception as e:
        return _err(e)


# Heuristic regexes for `comms.send_via_best` routing.
_RE_DISCORD_ID = re.compile(r"^\d{17,20}$")            # snowflake
_RE_SLACK_CHAN = re.compile(r"^[#@]?[a-z0-9][a-z0-9._-]{0,79}$")  # name
_RE_SLACK_ID = re.compile(r"^[CDG][A-Z0-9]{8,}$")       # C…, D…, G… ids
_RE_TG_CHAT = re.compile(r"^-?\d+$")                    # int or negative int


def _comms_send_via_best(args: dict) -> dict:
    """Heuristic router — pick discord/slack/telegram based on `channel` shape.

    Rules:
      - Pure 17–20 digit number → Discord channel id
      - Starts with `C`/`D`/`G` + caps/digits → Slack channel/IM/group id
      - Starts with `#` or matches slack-name pattern → Slack channel name
      - Negative integer or plain integer (≤16 digits) → Telegram chat id
      - Anything else → error
    """
    try:
        channel = str(args.get("channel", "")).strip()
        message = str(args.get("message", ""))
        if not channel or not message:
            return {"ok": False, "error": "channel and message required"}

        if _RE_DISCORD_ID.match(channel):
            res = _discord_send_message({"channel_id": channel, "content": message})
            return {**res, "routed_to": "discord"}
        if _RE_SLACK_ID.match(channel):
            res = _slack_send_message({"channel": channel, "text": message})
            return {**res, "routed_to": "slack"}
        if channel.startswith("#") or (_RE_SLACK_CHAN.match(channel)
                                        and not channel.lstrip("-").isdigit()):
            res = _slack_send_message({"channel": channel, "text": message})
            return {**res, "routed_to": "slack"}
        if _RE_TG_CHAT.match(channel):
            res = _telegram_send_message({"chat_id": int(channel), "text": message})
            return {**res, "routed_to": "telegram"}
        return {"ok": False,
                "error": f"could not infer platform from channel '{channel}'"}
    except Exception as e:
        return _err(e)


def _comms_list_all_unread(args: dict) -> dict:
    """Aggregate poll across Discord mentions, Slack mentions, and Telegram updates.

    Returns a unified list `[{platform, channel, sender, text, ts}, ...]`.
    Per-platform failures are recorded in `errors` but don't fail the call.
    """
    try:
        unified: List[Dict[str, Any]] = []
        errors: Dict[str, str] = {}

        # Discord
        d = _discord_poll_mentions({"limit": 10})
        if d.get("ok"):
            for m in d.get("mentions", []):
                unified.append({
                    "platform": "discord",
                    "channel": m.get("channel_name") or m.get("channel_id"),
                    "sender": m.get("author"),
                    "text": m.get("content", ""),
                    "ts": m.get("ts"),
                })
        else:
            errors["discord"] = d.get("error", "unknown")

        # Slack
        s = _slack_poll_mentions({})
        if s.get("ok"):
            for m in s.get("mentions", []):
                unified.append({
                    "platform": "slack",
                    "channel": m.get("channel_name") or m.get("channel"),
                    "sender": m.get("username") or m.get("user"),
                    "text": m.get("text", ""),
                    "ts": m.get("ts"),
                })
        else:
            errors["slack"] = s.get("error", "unknown")

        # Telegram
        t = _telegram_get_updates({})
        if t.get("ok"):
            for u in t.get("updates", []):
                unified.append({
                    "platform": "telegram",
                    "channel": u.get("chat_id"),
                    "sender": u.get("from"),
                    "text": u.get("text", ""),
                    "ts": u.get("date"),
                })
        else:
            errors["telegram"] = t.get("error", "unknown")

        return {"ok": True, "unread": unified, "count": len(unified),
                "errors": errors or None}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Discord
    "discord.send_message": _discord_send_message,
    "discord.send_dm": _discord_send_dm,
    "discord.list_recent_messages": _discord_list_recent_messages,
    "discord.list_channels": _discord_list_channels,
    "discord.list_guilds": _discord_list_guilds,
    "discord.edit_message": _discord_edit_message,
    "discord.delete_message": _discord_delete_message,
    "discord.add_reaction": _discord_add_reaction,
    "discord.poll_mentions": _discord_poll_mentions,
    "discord.set_status": _discord_set_status,
    # Slack
    "slack.send_message": _slack_send_message,
    "slack.list_channels": _slack_list_channels,
    "slack.list_users": _slack_list_users,
    "slack.poll_mentions": _slack_poll_mentions,
    "slack.upload_file": _slack_upload_file,
    "slack.add_reaction": _slack_add_reaction,
    # Telegram
    "telegram.send_message": _telegram_send_message,
    "telegram.send_photo": _telegram_send_photo,
    "telegram.get_updates": _telegram_get_updates,
    "telegram.set_webhook": _telegram_set_webhook,
    # Generic
    "comms.webhook_post": _comms_webhook_post,
    "comms.send_via_best": _comms_send_via_best,
    "comms.list_all_unread": _comms_list_all_unread,
}
