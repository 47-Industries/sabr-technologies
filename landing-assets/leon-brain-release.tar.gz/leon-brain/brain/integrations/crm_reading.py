"""crm_reading.py — Leon's CRM + read-later hub.

CRMs: Airtable, Pipedrive, HubSpot (deeper).
Read-later: Pocket, Instapaper, Raindrop.io.

Same contract as comms.py:
  - credentials lazy from env then `~/.openclaw/secrets.json`
  - single `requests` call per tool with 12s default timeout
  - never raises — exceptions wrapped to `{"ok": False, "error": ...}`
  - EXTRA_TOOLS dict at the bottom

Credentials read:
  - AIRTABLE_API_KEY, AIRTABLE_BASE_ID
  - PIPEDRIVE_API_KEY, PIPEDRIVE_DOMAIN  (e.g. "47industries" for 47industries.pipedrive.com)
  - HUBSPOT_PRIVATE_APP_TOKEN
  - POCKET_CONSUMER_KEY, POCKET_ACCESS_TOKEN
  - INSTAPAPER_USERNAME, INSTAPAPER_PASSWORD
  - RAINDROP_TOKEN
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 12.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _http_error(resp: requests.Response) -> Dict[str, Any]:
    """Build an error envelope from a non-2xx response."""
    try:
        body = resp.json()
    except Exception:
        body = resp.text[:2000]
    return {
        "ok": False,
        "error": f"HTTP {resp.status_code}",
        "status": resp.status_code,
        "body": body,
    }


def _ok2xx(resp: requests.Response) -> bool:
    return 200 <= resp.status_code < 300


# ──────────────────────────────────────────────────────────────────────────
# AIRTABLE
# ──────────────────────────────────────────────────────────────────────────

_AIRTABLE_API = "https://api.airtable.com/v0"
_AIRTABLE_META = "https://api.airtable.com/v0/meta"


def _airtable_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("AIRTABLE_API_KEY")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _airtable_base(arg_base_id: Optional[str]) -> Optional[str]:
    if arg_base_id:
        return str(arg_base_id).strip()
    return _get_secret("AIRTABLE_BASE_ID")


def _airtable_list_records(args: dict) -> dict:
    """List records from an Airtable table."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")
        table = str(args.get("table", "")).strip()
        if not table:
            return {"ok": False, "error": "table required"}
        limit = int(args.get("limit", 50) or 50)
        params: Dict[str, Any] = {"pageSize": min(max(limit, 1), 100)}
        if args.get("view"):
            params["view"] = str(args["view"])
        if args.get("filter_by_formula"):
            params["filterByFormula"] = str(args["filter_by_formula"])

        url = f"{_AIRTABLE_API}/{base_id}/{requests.utils.quote(table, safe='')}"
        r = requests.get(url, headers=h, params=params, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json()
        records = data.get("records", [])[:limit]
        return {
            "ok": True,
            "table": table,
            "base_id": base_id,
            "count": len(records),
            "records": records,
            "offset": data.get("offset"),
        }
    except Exception as e:
        return _err(e)


def _airtable_get_record(args: dict) -> dict:
    """Get one Airtable record by ID."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")
        table = str(args.get("table", "")).strip()
        record_id = str(args.get("record_id", "")).strip()
        if not table or not record_id:
            return {"ok": False, "error": "table and record_id required"}

        url = f"{_AIRTABLE_API}/{base_id}/{requests.utils.quote(table, safe='')}/{record_id}"
        r = requests.get(url, headers=h, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "record": r.json()}
    except Exception as e:
        return _err(e)


def _airtable_create_record(args: dict) -> dict:
    """Create a record in an Airtable table. MEDIUM."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")
        table = str(args.get("table", "")).strip()
        fields = args.get("fields") or {}
        if not table:
            return {"ok": False, "error": "table required"}
        if not isinstance(fields, dict) or not fields:
            return {"ok": False, "error": "fields (dict) required"}

        url = f"{_AIRTABLE_API}/{base_id}/{requests.utils.quote(table, safe='')}"
        r = requests.post(url, headers=h, json={"fields": fields},
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        rec = r.json()
        return {"ok": True, "record_id": rec.get("id"), "record": rec}
    except Exception as e:
        return _err(e)


def _airtable_update_record(args: dict) -> dict:
    """Patch fields on an Airtable record. MEDIUM."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")
        table = str(args.get("table", "")).strip()
        record_id = str(args.get("record_id", "")).strip()
        fields = args.get("fields") or {}
        if not table or not record_id:
            return {"ok": False, "error": "table and record_id required"}
        if not isinstance(fields, dict) or not fields:
            return {"ok": False, "error": "fields (dict) required"}

        url = f"{_AIRTABLE_API}/{base_id}/{requests.utils.quote(table, safe='')}/{record_id}"
        r = requests.patch(url, headers=h, json={"fields": fields},
                           timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "record": r.json()}
    except Exception as e:
        return _err(e)


def _airtable_delete_record(args: dict) -> dict:
    """Delete an Airtable record by ID. HIGH."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")
        table = str(args.get("table", "")).strip()
        record_id = str(args.get("record_id", "")).strip()
        if not table or not record_id:
            return {"ok": False, "error": "table and record_id required"}

        url = f"{_AIRTABLE_API}/{base_id}/{requests.utils.quote(table, safe='')}/{record_id}"
        r = requests.delete(url, headers=h, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "deleted": True, "record_id": record_id}
    except Exception as e:
        return _err(e)


def _airtable_list_tables(args: dict) -> dict:
    """List tables in a base via the meta API."""
    try:
        h = _airtable_headers()
        if not h:
            return _missing("AIRTABLE_API_KEY", "Airtable")
        base_id = _airtable_base(args.get("base_id"))
        if not base_id:
            return _missing("AIRTABLE_BASE_ID", "Airtable")

        url = f"{_AIRTABLE_META}/bases/{base_id}/tables"
        r = requests.get(url, headers=h, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json()
        tables = data.get("tables", [])
        return {
            "ok": True,
            "base_id": base_id,
            "count": len(tables),
            "tables": [
                {
                    "id": t.get("id"),
                    "name": t.get("name"),
                    "primary_field_id": t.get("primaryFieldId"),
                    "fields": [
                        {"id": f.get("id"), "name": f.get("name"),
                         "type": f.get("type")}
                        for f in (t.get("fields") or [])
                    ],
                }
                for t in tables
            ],
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# PIPEDRIVE
# ──────────────────────────────────────────────────────────────────────────

def _pipedrive_creds() -> Optional[Dict[str, str]]:
    tok = _get_secret("PIPEDRIVE_API_KEY")
    dom = _get_secret("PIPEDRIVE_DOMAIN")
    if not tok or not dom:
        return None
    dom = dom.strip().replace("https://", "").replace("http://", "").rstrip("/")
    # accept either "47industries" or "47industries.pipedrive.com"
    if "." not in dom:
        dom = f"{dom}.pipedrive.com"
    return {"token": tok, "base": f"https://{dom}/api/v1"}


def _pipedrive_deals_list(args: dict) -> dict:
    """List Pipedrive deals (default: open)."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        status = str(args.get("status", "open"))
        limit = int(args.get("limit", 50) or 50)
        params = {
            "api_token": c["token"],
            "status": status,
            "limit": min(max(limit, 1), 500),
        }
        r = requests.get(f"{c['base']}/deals", params=params,
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        deals = data.get("data") or []
        slim = [
            {
                "id": d.get("id"),
                "title": d.get("title"),
                "value": d.get("value"),
                "currency": d.get("currency"),
                "status": d.get("status"),
                "stage_id": d.get("stage_id"),
                "org": (d.get("org_id") or {}).get("name") if isinstance(d.get("org_id"), dict) else d.get("org_name"),
                "person": (d.get("person_id") or {}).get("name") if isinstance(d.get("person_id"), dict) else d.get("person_name"),
                "expected_close": d.get("expected_close_date"),
            }
            for d in deals
        ]
        return {"ok": True, "count": len(slim), "deals": slim}
    except Exception as e:
        return _err(e)


def _pipedrive_deal_get(args: dict) -> dict:
    """Get one Pipedrive deal by ID."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        deal_id = args.get("deal_id")
        if not deal_id:
            return {"ok": False, "error": "deal_id required"}
        r = requests.get(f"{c['base']}/deals/{deal_id}",
                         params={"api_token": c["token"]},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "deal": (r.json() or {}).get("data")}
    except Exception as e:
        return _err(e)


def _pipedrive_deal_create(args: dict) -> dict:
    """Create a Pipedrive deal. MEDIUM."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        title = str(args.get("title", "")).strip()
        if not title:
            return {"ok": False, "error": "title required"}
        payload: Dict[str, Any] = {
            "title": title,
            "value": args.get("value", 0),
            "currency": str(args.get("currency", "USD")),
        }
        if args.get("organization"):
            payload["org_id"] = args["organization"]
        if args.get("person"):
            payload["person_id"] = args["person"]

        r = requests.post(f"{c['base']}/deals",
                          params={"api_token": c["token"]},
                          json=payload, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = (r.json() or {}).get("data") or {}
        return {"ok": True, "deal_id": d.get("id"), "deal": d}
    except Exception as e:
        return _err(e)


def _pipedrive_deal_update_stage(args: dict) -> dict:
    """Move a deal to a different stage. MEDIUM."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        deal_id = args.get("deal_id")
        stage_id = args.get("stage_id")
        if not deal_id or stage_id is None:
            return {"ok": False, "error": "deal_id and stage_id required"}
        r = requests.put(f"{c['base']}/deals/{deal_id}",
                         params={"api_token": c["token"]},
                         json={"stage_id": stage_id},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = (r.json() or {}).get("data") or {}
        return {"ok": True, "deal_id": d.get("id"), "stage_id": d.get("stage_id")}
    except Exception as e:
        return _err(e)


def _pipedrive_persons_list(args: dict) -> dict:
    """List Pipedrive persons."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        limit = int(args.get("limit", 50) or 50)
        r = requests.get(f"{c['base']}/persons",
                         params={"api_token": c["token"],
                                 "limit": min(max(limit, 1), 500)},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        persons = (r.json() or {}).get("data") or []
        slim = [
            {
                "id": p.get("id"),
                "name": p.get("name"),
                "email": [e.get("value") for e in (p.get("email") or []) if isinstance(e, dict)],
                "phone": [ph.get("value") for ph in (p.get("phone") or []) if isinstance(ph, dict)],
                "org": (p.get("org_id") or {}).get("name") if isinstance(p.get("org_id"), dict) else None,
            }
            for p in persons
        ]
        return {"ok": True, "count": len(slim), "persons": slim}
    except Exception as e:
        return _err(e)


def _pipedrive_person_create(args: dict) -> dict:
    """Create a Pipedrive person. MEDIUM."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        payload: Dict[str, Any] = {"name": name}
        if args.get("email"):
            payload["email"] = [{"value": str(args["email"]), "primary": True}]
        if args.get("phone"):
            payload["phone"] = [{"value": str(args["phone"]), "primary": True}]

        r = requests.post(f"{c['base']}/persons",
                          params={"api_token": c["token"]},
                          json=payload, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        p = (r.json() or {}).get("data") or {}
        return {"ok": True, "person_id": p.get("id"), "person": p}
    except Exception as e:
        return _err(e)


def _pipedrive_activities_today(args: dict) -> dict:
    """List today's Pipedrive activities (tasks)."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        from datetime import date
        today = date.today().isoformat()
        r = requests.get(f"{c['base']}/activities",
                         params={
                             "api_token": c["token"],
                             "start_date": today,
                             "end_date": today,
                             "limit": 100,
                         },
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        acts = (r.json() or {}).get("data") or []
        slim = [
            {
                "id": a.get("id"),
                "subject": a.get("subject"),
                "type": a.get("type"),
                "due_date": a.get("due_date"),
                "due_time": a.get("due_time"),
                "done": a.get("done"),
                "deal_id": a.get("deal_id"),
                "person_id": a.get("person_id"),
            }
            for a in acts
        ]
        return {"ok": True, "date": today, "count": len(slim), "activities": slim}
    except Exception as e:
        return _err(e)


def _pipedrive_organizations_list(args: dict) -> dict:
    """List Pipedrive organizations."""
    try:
        c = _pipedrive_creds()
        if not c:
            return _missing("PIPEDRIVE_API_KEY+PIPEDRIVE_DOMAIN", "Pipedrive")
        limit = int(args.get("limit", 50) or 50)
        r = requests.get(f"{c['base']}/organizations",
                         params={"api_token": c["token"],
                                 "limit": min(max(limit, 1), 500)},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        orgs = (r.json() or {}).get("data") or []
        slim = [
            {
                "id": o.get("id"),
                "name": o.get("name"),
                "address": o.get("address"),
                "people_count": o.get("people_count"),
                "open_deals_count": o.get("open_deals_count"),
            }
            for o in orgs
        ]
        return {"ok": True, "count": len(slim), "organizations": slim}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# HUBSPOT
# ──────────────────────────────────────────────────────────────────────────

_HUBSPOT_API = "https://api.hubapi.com"


def _hubspot_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("HUBSPOT_PRIVATE_APP_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _hubspot_contacts_search(args: dict) -> dict:
    """Search HubSpot contacts by free text (name/email)."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = int(args.get("limit", 30) or 30)
        body = {
            "query": query,
            "limit": min(max(limit, 1), 100),
            "properties": ["firstname", "lastname", "email", "phone",
                           "company", "lifecyclestage"],
        }
        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/contacts/search",
                          headers=h, json=body, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        results = data.get("results", [])
        slim = [
            {
                "id": c.get("id"),
                **(c.get("properties") or {}),
            }
            for c in results
        ]
        return {"ok": True, "count": len(slim), "contacts": slim,
                "total": data.get("total")}
    except Exception as e:
        return _err(e)


def _hubspot_contact_create(args: dict) -> dict:
    """Create a HubSpot contact. MEDIUM."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        email = str(args.get("email", "")).strip()
        if not email:
            return {"ok": False, "error": "email required"}
        props: Dict[str, Any] = {"email": email}
        if args.get("firstname"):
            props["firstname"] = str(args["firstname"])
        if args.get("lastname"):
            props["lastname"] = str(args["lastname"])
        extra = args.get("properties") or {}
        if isinstance(extra, dict):
            for k, v in extra.items():
                props[str(k)] = v

        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/contacts",
                          headers=h, json={"properties": props},
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = r.json() or {}
        return {"ok": True, "contact_id": d.get("id"), "contact": d}
    except Exception as e:
        return _err(e)


def _hubspot_deals_pipeline_view(args: dict) -> dict:
    """List deals grouped by stage for a pipeline (default pipeline if omitted)."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        pipeline_id = args.get("pipeline_id") or "default"

        # 1. fetch the pipeline stages so we can group meaningfully
        rp = requests.get(
            f"{_HUBSPOT_API}/crm/v3/pipelines/deals/{pipeline_id}",
            headers=h, timeout=_DEFAULT_TIMEOUT,
        )
        if not _ok2xx(rp):
            return _http_error(rp)
        pdata = rp.json() or {}
        stage_lookup = {
            s.get("id"): s.get("label")
            for s in (pdata.get("stages") or [])
        }

        # 2. search deals in this pipeline
        body = {
            "filterGroups": [{
                "filters": [{
                    "propertyName": "pipeline",
                    "operator": "EQ",
                    "value": pipeline_id,
                }],
            }],
            "limit": 100,
            "properties": ["dealname", "amount", "dealstage",
                           "pipeline", "closedate"],
        }
        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/deals/search",
                          headers=h, json=body, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        results = (r.json() or {}).get("results", [])
        by_stage: Dict[str, List[Dict[str, Any]]] = {}
        for d in results:
            props = d.get("properties") or {}
            stage = props.get("dealstage") or "unknown"
            label = stage_lookup.get(stage, stage)
            by_stage.setdefault(label, []).append({
                "id": d.get("id"),
                "name": props.get("dealname"),
                "amount": props.get("amount"),
                "close_date": props.get("closedate"),
            })

        return {
            "ok": True,
            "pipeline_id": pipeline_id,
            "pipeline": pdata.get("label"),
            "total_deals": len(results),
            "by_stage": by_stage,
        }
    except Exception as e:
        return _err(e)


def _hubspot_deal_create(args: dict) -> dict:
    """Create a HubSpot deal. MEDIUM."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        props: Dict[str, Any] = {
            "dealname": name,
            "amount": args.get("amount", 0),
        }
        if args.get("dealstage"):
            props["dealstage"] = str(args["dealstage"])
        extra = args.get("properties") or {}
        if isinstance(extra, dict):
            for k, v in extra.items():
                props[str(k)] = v

        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/deals",
                          headers=h, json={"properties": props},
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = r.json() or {}
        return {"ok": True, "deal_id": d.get("id"), "deal": d}
    except Exception as e:
        return _err(e)


def _hubspot_companies_search(args: dict) -> dict:
    """Search HubSpot companies."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = int(args.get("limit", 30) or 30)
        body = {
            "query": query,
            "limit": min(max(limit, 1), 100),
            "properties": ["name", "domain", "industry", "city",
                           "country", "numberofemployees"],
        }
        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/companies/search",
                          headers=h, json=body, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        results = data.get("results", [])
        slim = [
            {"id": c.get("id"), **(c.get("properties") or {})}
            for c in results
        ]
        return {"ok": True, "count": len(slim), "companies": slim,
                "total": data.get("total")}
    except Exception as e:
        return _err(e)


def _hubspot_note_create(args: dict) -> dict:
    """Create a note engagement and associate it with a contact. MEDIUM."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        contact_id = str(args.get("contact_id", "")).strip()
        body_text = str(args.get("body", "")).strip()
        if not contact_id or not body_text:
            return {"ok": False, "error": "contact_id and body required"}

        import time as _time
        payload = {
            "properties": {
                "hs_note_body": body_text,
                "hs_timestamp": int(_time.time() * 1000),
            },
            "associations": [{
                "to": {"id": contact_id},
                "types": [{
                    "associationCategory": "HUBSPOT_DEFINED",
                    # 202 = note-to-contact
                    "associationTypeId": 202,
                }],
            }],
        }
        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/notes",
                          headers=h, json=payload,
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = r.json() or {}
        return {"ok": True, "note_id": d.get("id"), "contact_id": contact_id}
    except Exception as e:
        return _err(e)


def _hubspot_email_log(args: dict) -> dict:
    """Log an email engagement against a contact. MEDIUM."""
    try:
        h = _hubspot_headers()
        if not h:
            return _missing("HUBSPOT_PRIVATE_APP_TOKEN", "HubSpot")
        contact_id = str(args.get("contact_id", "")).strip()
        subject = str(args.get("subject", "")).strip()
        body_text = str(args.get("body", "")).strip()
        direction = str(args.get("direction", "OUTGOING")).upper()
        if direction not in ("OUTGOING", "INCOMING"):
            direction = "OUTGOING"
        if not contact_id or not subject:
            return {"ok": False, "error": "contact_id and subject required"}

        import time as _time
        # EMAIL direction in HubSpot is EMAIL or INCOMING_EMAIL
        hs_direction = "EMAIL" if direction == "OUTGOING" else "INCOMING_EMAIL"
        payload = {
            "properties": {
                "hs_email_subject": subject,
                "hs_email_text": body_text,
                "hs_email_direction": hs_direction,
                "hs_timestamp": int(_time.time() * 1000),
            },
            "associations": [{
                "to": {"id": contact_id},
                "types": [{
                    "associationCategory": "HUBSPOT_DEFINED",
                    # 198 = email-to-contact
                    "associationTypeId": 198,
                }],
            }],
        }
        r = requests.post(f"{_HUBSPOT_API}/crm/v3/objects/emails",
                          headers=h, json=payload,
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        d = r.json() or {}
        return {"ok": True, "email_id": d.get("id"),
                "contact_id": contact_id, "direction": direction}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# POCKET
# ──────────────────────────────────────────────────────────────────────────

_POCKET_API = "https://getpocket.com/v3"


def _pocket_creds() -> Optional[Dict[str, str]]:
    consumer = _get_secret("POCKET_CONSUMER_KEY")
    access = _get_secret("POCKET_ACCESS_TOKEN")
    if not consumer or not access:
        return None
    return {"consumer_key": consumer, "access_token": access}


def _pocket_save(args: dict) -> dict:
    """Save a URL to Pocket. MEDIUM."""
    try:
        c = _pocket_creds()
        if not c:
            return _missing("POCKET_CONSUMER_KEY+POCKET_ACCESS_TOKEN", "Pocket")
        url = str(args.get("url", "")).strip()
        if not url:
            return {"ok": False, "error": "url required"}
        payload: Dict[str, Any] = {**c, "url": url}
        if args.get("title"):
            payload["title"] = str(args["title"])
        if args.get("tags"):
            tags = args["tags"]
            if isinstance(tags, list):
                tags = ",".join(str(t) for t in tags)
            payload["tags"] = str(tags)
        r = requests.post(f"{_POCKET_API}/add", json=payload,
                          headers={"X-Accept": "application/json"},
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        item = data.get("item") or {}
        return {"ok": True,
                "item_id": item.get("item_id"),
                "title": item.get("title") or item.get("given_title"),
                "url": item.get("given_url") or url}
    except Exception as e:
        return _err(e)


def _pocket_list(args: dict) -> dict:
    """List Pocket items. state: unread / archive / all."""
    try:
        c = _pocket_creds()
        if not c:
            return _missing("POCKET_CONSUMER_KEY+POCKET_ACCESS_TOKEN", "Pocket")
        count = int(args.get("count", 20) or 20)
        state = str(args.get("state", "unread"))
        if state not in ("unread", "archive", "all"):
            state = "unread"
        payload = {
            **c,
            "count": min(max(count, 1), 100),
            "state": state,
            "detailType": "simple",
            "sort": "newest",
        }
        r = requests.post(f"{_POCKET_API}/get", json=payload,
                          headers={"X-Accept": "application/json"},
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        raw = data.get("list") or {}
        items: List[Dict[str, Any]] = []
        if isinstance(raw, dict):
            for _, v in raw.items():
                items.append({
                    "item_id": v.get("item_id"),
                    "title": v.get("resolved_title") or v.get("given_title"),
                    "url": v.get("resolved_url") or v.get("given_url"),
                    "excerpt": v.get("excerpt"),
                    "word_count": v.get("word_count"),
                    "time_added": v.get("time_added"),
                    "favorite": v.get("favorite"),
                    "status": v.get("status"),
                })
        # newest first
        items.sort(key=lambda x: int(x.get("time_added") or 0), reverse=True)
        return {"ok": True, "count": len(items), "state": state, "items": items}
    except Exception as e:
        return _err(e)


def _pocket_modify(item_id: str, action: str) -> requests.Response:
    """Internal: send a single Pocket /send action."""
    c = _pocket_creds() or {}
    payload = {
        **c,
        "actions": [{"action": action, "item_id": str(item_id)}],
    }
    return requests.post(f"{_POCKET_API}/send", json=payload,
                         headers={"X-Accept": "application/json"},
                         timeout=_DEFAULT_TIMEOUT)


def _pocket_archive(args: dict) -> dict:
    """Archive a Pocket item. MEDIUM."""
    try:
        if not _pocket_creds():
            return _missing("POCKET_CONSUMER_KEY+POCKET_ACCESS_TOKEN", "Pocket")
        item_id = str(args.get("item_id", "")).strip()
        if not item_id:
            return {"ok": False, "error": "item_id required"}
        r = _pocket_modify(item_id, "archive")
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "archived": True, "item_id": item_id}
    except Exception as e:
        return _err(e)


def _pocket_delete(args: dict) -> dict:
    """Delete a Pocket item. HIGH."""
    try:
        if not _pocket_creds():
            return _missing("POCKET_CONSUMER_KEY+POCKET_ACCESS_TOKEN", "Pocket")
        item_id = str(args.get("item_id", "")).strip()
        if not item_id:
            return {"ok": False, "error": "item_id required"}
        r = _pocket_modify(item_id, "delete")
        if not _ok2xx(r):
            return _http_error(r)
        return {"ok": True, "deleted": True, "item_id": item_id}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# INSTAPAPER  (simple HTTP-basic auth)
# ──────────────────────────────────────────────────────────────────────────

_INSTAPAPER_API = "https://www.instapaper.com/api"


def _instapaper_auth() -> Optional[tuple]:
    u = _get_secret("INSTAPAPER_USERNAME")
    p = _get_secret("INSTAPAPER_PASSWORD")
    if not u:
        return None
    # Instapaper allows blank password for free accounts
    return (u, p or "")


def _instapaper_save(args: dict) -> dict:
    """Save a URL to Instapaper via the simple API. MEDIUM."""
    try:
        auth = _instapaper_auth()
        if not auth:
            return _missing("INSTAPAPER_USERNAME(+PASSWORD)", "Instapaper")
        url = str(args.get("url", "")).strip()
        if not url:
            return {"ok": False, "error": "url required"}
        params: Dict[str, Any] = {"url": url}
        if args.get("title"):
            params["title"] = str(args["title"])
        r = requests.post(f"{_INSTAPAPER_API}/add",
                          auth=auth, data=params,
                          timeout=_DEFAULT_TIMEOUT)
        # Instapaper returns 201 on success, 400 on bad url, 403 on auth fail
        if r.status_code == 201:
            return {"ok": True, "url": url,
                    "title": params.get("title")}
        return _http_error(r)
    except Exception as e:
        return _err(e)


def _instapaper_list(args: dict) -> dict:
    """List unread Instapaper bookmarks. Note: the simple API exposes only
    `auth`; to actually list items Instapaper requires the full OAuth API.
    This tool verifies credentials and surfaces that limitation cleanly."""
    try:
        auth = _instapaper_auth()
        if not auth:
            return _missing("INSTAPAPER_USERNAME(+PASSWORD)", "Instapaper")
        # Verify credentials work via /authenticate
        r = requests.get(f"{_INSTAPAPER_API}/authenticate",
                         auth=auth, timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            return _http_error(r)
        return {
            "ok": True,
            "authenticated": True,
            "items": [],
            "note": "Instapaper simple API has no list endpoint — "
                    "OAuth-tier required to fetch bookmarks. "
                    "save() works on the free tier.",
            "limit": int(args.get("limit", 20) or 20),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# RAINDROP.IO
# ──────────────────────────────────────────────────────────────────────────

_RAINDROP_API = "https://api.raindrop.io/rest/v1"


def _raindrop_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("RAINDROP_TOKEN")
    if not tok:
        return None
    return {
        "Authorization": f"Bearer {tok}",
        "Content-Type": "application/json",
    }


def _raindrop_save(args: dict) -> dict:
    """Save a bookmark to Raindrop.io. MEDIUM."""
    try:
        h = _raindrop_headers()
        if not h:
            return _missing("RAINDROP_TOKEN", "Raindrop.io")
        link = str(args.get("link", "")).strip()
        if not link:
            return {"ok": False, "error": "link required"}
        payload: Dict[str, Any] = {
            "link": link,
            "collection": {"$id": int(args.get("collection_id", -1) or -1)},
        }
        if args.get("title"):
            payload["title"] = str(args["title"])
        if args.get("tags"):
            tags = args["tags"]
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]
            payload["tags"] = list(tags) if isinstance(tags, (list, tuple)) else []

        r = requests.post(f"{_RAINDROP_API}/raindrop",
                          headers=h, json=payload,
                          timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        item = data.get("item") or {}
        return {"ok": True,
                "id": item.get("_id"),
                "link": item.get("link") or link,
                "title": item.get("title")}
    except Exception as e:
        return _err(e)


def _raindrop_list(args: dict) -> dict:
    """List bookmarks in a Raindrop collection (0 = all)."""
    try:
        h = _raindrop_headers()
        if not h:
            return _missing("RAINDROP_TOKEN", "Raindrop.io")
        collection_id = int(args.get("collection_id", 0) or 0)
        limit = int(args.get("limit", 20) or 20)
        r = requests.get(f"{_RAINDROP_API}/raindrops/{collection_id}",
                         headers=h,
                         params={"perpage": min(max(limit, 1), 50)},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        data = r.json() or {}
        items = data.get("items") or []
        slim = [
            {
                "id": i.get("_id"),
                "title": i.get("title"),
                "link": i.get("link"),
                "excerpt": i.get("excerpt"),
                "tags": i.get("tags"),
                "created": i.get("created"),
                "collection_id": (i.get("collection") or {}).get("$id") if isinstance(i.get("collection"), dict) else i.get("collectionId"),
            }
            for i in items[:limit]
        ]
        return {"ok": True, "collection_id": collection_id,
                "count": len(slim), "items": slim}
    except Exception as e:
        return _err(e)


def _raindrop_collections_list(args: dict) -> dict:
    """List your Raindrop collections."""
    try:
        h = _raindrop_headers()
        if not h:
            return _missing("RAINDROP_TOKEN", "Raindrop.io")
        r = requests.get(f"{_RAINDROP_API}/collections",
                         headers=h, timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        items = (r.json() or {}).get("items") or []
        slim = [
            {
                "id": c.get("_id"),
                "title": c.get("title"),
                "count": c.get("count"),
                "public": c.get("public"),
                "parent": (c.get("parent") or {}).get("$id") if isinstance(c.get("parent"), dict) else None,
            }
            for c in items
        ]
        return {"ok": True, "count": len(slim), "collections": slim}
    except Exception as e:
        return _err(e)


def _raindrop_search(args: dict) -> dict:
    """Full-text search across Raindrop bookmarks."""
    try:
        h = _raindrop_headers()
        if not h:
            return _missing("RAINDROP_TOKEN", "Raindrop.io")
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = int(args.get("limit", 20) or 20)
        # collection 0 = all
        r = requests.get(f"{_RAINDROP_API}/raindrops/0",
                         headers=h,
                         params={"search": query,
                                 "perpage": min(max(limit, 1), 50)},
                         timeout=_DEFAULT_TIMEOUT)
        if not _ok2xx(r):
            return _http_error(r)
        items = (r.json() or {}).get("items") or []
        slim = [
            {
                "id": i.get("_id"),
                "title": i.get("title"),
                "link": i.get("link"),
                "excerpt": i.get("excerpt"),
                "tags": i.get("tags"),
            }
            for i in items[:limit]
        ]
        return {"ok": True, "query": query, "count": len(slim), "results": slim}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CROSS-CUTTING
# ──────────────────────────────────────────────────────────────────────────

def _local_notes_fallback(url: str, title: Optional[str]) -> Dict[str, Any]:
    """Last-resort: drop the link into Leon's notes via notes.quick_add."""
    try:
        from brain.integrations import notes as _notes_mod  # type: ignore
        notes_tools = getattr(_notes_mod, "EXTRA_TOOLS", {})
        fn = notes_tools.get("notes.quick_add")
        if fn:
            text = f"[READ LATER] {title or ''} {url}".strip()
            res = fn({"text": text})
            if isinstance(res, dict) and res.get("ok"):
                return {"ok": True, "saved_to": "notes.quick_add",
                        "url": url, "title": title}
    except Exception:
        pass
    # final fallback: append to a plain file
    try:
        out = Path.home() / ".openclaw" / "read_later.txt"
        out.parent.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        with open(out, "a", encoding="utf-8") as f:
            f.write(f"{datetime.utcnow().isoformat()}Z\t{title or ''}\t{url}\n")
        return {"ok": True, "saved_to": str(out), "url": url, "title": title}
    except Exception as e:
        return _err(e)


def _read_save_anywhere(args: dict) -> dict:
    """Save a URL to the first available read-later service.
    Try Raindrop → Pocket → local notes/file fallback.
    """
    try:
        url = str(args.get("url", "")).strip()
        if not url:
            return {"ok": False, "error": "url required"}
        title = args.get("title")
        attempts: List[Dict[str, Any]] = []

        if _raindrop_headers():
            res = _raindrop_save({"link": url, "title": title})
            attempts.append({"service": "raindrop", "result": res})
            if res.get("ok"):
                return {"ok": True, "service": "raindrop",
                        "id": res.get("id"), "url": url, "attempts": attempts}

        if _pocket_creds():
            res = _pocket_save({"url": url, "title": title})
            attempts.append({"service": "pocket", "result": res})
            if res.get("ok"):
                return {"ok": True, "service": "pocket",
                        "item_id": res.get("item_id"),
                        "url": url, "attempts": attempts}

        # local fallback never fails the whole call
        fb = _local_notes_fallback(url, title if isinstance(title, str) else None)
        attempts.append({"service": "local", "result": fb})
        if fb.get("ok"):
            return {"ok": True, "service": "local",
                    "url": url, "attempts": attempts}
        return {"ok": False, "error": "no read-later service available",
                "attempts": attempts}
    except Exception as e:
        return _err(e)


def _crm_unified_contact_search(args: dict) -> dict:
    """Fan a query out across every configured CRM and merge results."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}

        unified: List[Dict[str, Any]] = []
        errors: Dict[str, str] = {}
        sources: List[str] = []

        # HubSpot
        if _hubspot_headers():
            sources.append("hubspot")
            h = _hubspot_contacts_search({"query": query, "limit": 20})
            if h.get("ok"):
                for c in h.get("contacts", []):
                    unified.append({
                        "source": "hubspot",
                        "id": c.get("id"),
                        "name": " ".join(filter(None, [c.get("firstname"),
                                                       c.get("lastname")])) or None,
                        "email": c.get("email"),
                        "phone": c.get("phone"),
                        "company": c.get("company"),
                    })
            else:
                errors["hubspot"] = h.get("error", "unknown")

        # Pipedrive — list + filter client-side (free tier lacks a great search)
        if _pipedrive_creds():
            sources.append("pipedrive")
            p = _pipedrive_persons_list({"limit": 500})
            if p.get("ok"):
                q = query.lower()
                for person in p.get("persons", []):
                    haystack = " ".join([
                        str(person.get("name") or ""),
                        " ".join(person.get("email") or []),
                        " ".join(person.get("phone") or []),
                        str(person.get("org") or ""),
                    ]).lower()
                    if q in haystack:
                        unified.append({
                            "source": "pipedrive",
                            "id": person.get("id"),
                            "name": person.get("name"),
                            "email": (person.get("email") or [None])[0],
                            "phone": (person.get("phone") or [None])[0],
                            "company": person.get("org"),
                        })
            else:
                errors["pipedrive"] = p.get("error", "unknown")

        # Airtable — only if a base is configured AND a table hint is provided;
        # without that we'd have to enumerate every base, which is too noisy.
        if _airtable_headers() and _airtable_base(None) and args.get("airtable_table"):
            sources.append("airtable")
            a = _airtable_list_records({
                "table": str(args["airtable_table"]),
                "limit": 100,
            })
            if a.get("ok"):
                q = query.lower()
                for rec in a.get("records", []):
                    fields = rec.get("fields") or {}
                    blob = " ".join(str(v) for v in fields.values()).lower()
                    if q in blob:
                        unified.append({
                            "source": "airtable",
                            "id": rec.get("id"),
                            "name": fields.get("Name") or fields.get("name"),
                            "email": fields.get("Email") or fields.get("email"),
                            "phone": fields.get("Phone") or fields.get("phone"),
                            "company": fields.get("Company") or fields.get("company"),
                        })
            else:
                errors["airtable"] = a.get("error", "unknown")

        return {
            "ok": True,
            "query": query,
            "sources_checked": sources,
            "count": len(unified),
            "contacts": unified,
            "errors": errors or None,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Airtable
    "crm.airtable_list_records": _airtable_list_records,
    "crm.airtable_get_record": _airtable_get_record,
    "crm.airtable_create_record": _airtable_create_record,
    "crm.airtable_update_record": _airtable_update_record,
    "crm.airtable_delete_record": _airtable_delete_record,
    "crm.airtable_list_tables": _airtable_list_tables,
    # Pipedrive
    "crm.pipedrive_deals_list": _pipedrive_deals_list,
    "crm.pipedrive_deal_get": _pipedrive_deal_get,
    "crm.pipedrive_deal_create": _pipedrive_deal_create,
    "crm.pipedrive_deal_update_stage": _pipedrive_deal_update_stage,
    "crm.pipedrive_persons_list": _pipedrive_persons_list,
    "crm.pipedrive_person_create": _pipedrive_person_create,
    "crm.pipedrive_activities_today": _pipedrive_activities_today,
    "crm.pipedrive_organizations_list": _pipedrive_organizations_list,
    # HubSpot deeper
    "crm.hubspot_contacts_search": _hubspot_contacts_search,
    "crm.hubspot_contact_create": _hubspot_contact_create,
    "crm.hubspot_deals_pipeline_view": _hubspot_deals_pipeline_view,
    "crm.hubspot_deal_create": _hubspot_deal_create,
    "crm.hubspot_companies_search": _hubspot_companies_search,
    "crm.hubspot_note_create": _hubspot_note_create,
    "crm.hubspot_email_log": _hubspot_email_log,
    # Pocket
    "read.pocket_save": _pocket_save,
    "read.pocket_list": _pocket_list,
    "read.pocket_archive": _pocket_archive,
    "read.pocket_delete": _pocket_delete,
    # Instapaper
    "read.instapaper_save": _instapaper_save,
    "read.instapaper_list": _instapaper_list,
    # Raindrop.io
    "read.raindrop_save": _raindrop_save,
    "read.raindrop_list": _raindrop_list,
    "read.raindrop_collections_list": _raindrop_collections_list,
    "read.raindrop_search": _raindrop_search,
    # Cross
    "read.save_anywhere": _read_save_anywhere,
    "crm.unified_contact_search": _crm_unified_contact_search,
}
