"""
accounting.py — Leon's accounting / bookkeeping tool surface for Sabr.

Gives Leon eyes and hands on Dean's books across four cloud accounting
backends — QuickBooks Online, Wave, Xero, FreshBooks — plus a fully local
layer that needs no backend at all: receipt OCR (tesseract), an expense
ledger, mileage tracking, expense reports/CSV export, and rough tax
estimates.

Each tool takes a single `args` dict and returns the standard contract
`{"ok": True, ...}` or `{"ok": False, "error": "..."}`. Nothing here ever
raises — every exception is wrapped into an `{"ok": False, "error": ...}`
result. The `EXTRA_TOOLS` dict at the bottom maps dotted tool names
(e.g. `acct.qb_invoices`) to the implementing callables.

Credentials are read lazily — environment first, then the flat JSON file
`~/.openclaw/secrets.json`. Missing credentials produce a helpful error
rather than a crash.

Credentials read:
  - QUICKBOOKS_ACCESS_TOKEN, QUICKBOOKS_REALM_ID
  - WAVE_API_TOKEN
  - XERO_ACCESS_TOKEN, XERO_TENANT_ID
  - FRESHBOOKS_ACCESS_TOKEN, FRESHBOOKS_ACCOUNT_ID

Local persistence: SQLite at `brain_state/expenses.db` (auto-created).

Style matches `brain/integrations/comms.py` + `productivity.py`.

NOTE: Tax helpers produce rough estimates only — NOT tax advice.
"""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import sqlite3
import subprocess
import threading
import time
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 15.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            _SECRETS_CACHE = {}
            return _SECRETS_CACHE
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is None or mtime != _SECRETS_MTIME:
            with open(_SECRETS_PATH, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            _SECRETS_CACHE = {str(k): v for k, v in data.items()} if isinstance(data, dict) else {}
            _SECRETS_MTIME = mtime
    except Exception:
        _SECRETS_CACHE = {}
    return _SECRETS_CACHE


def _cred(name: str) -> Optional[str]:
    """Resolve a credential: environment first, then secrets file."""
    val = os.environ.get(name)
    if val:
        return val
    val = _load_secrets_file().get(name)
    if isinstance(val, str) and val:
        return val
    return None


def _need(*names: str) -> Optional[Dict[str, Any]]:
    """Return an error result if any named credential is missing, else None."""
    missing = [n for n in names if not _cred(n)]
    if missing:
        return {
            "ok": False,
            "error": (
                "missing credentials: " + ", ".join(missing)
                + ". Set them as environment variables or add them to "
                + str(_SECRETS_PATH)
            ),
        }
    return None


def _err(exc: Exception) -> Dict[str, Any]:
    return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def _http(method: str, url: str, **kwargs: Any) -> Dict[str, Any]:
    """Single requests call with the standard timeout. Returns {ok, ...}."""
    kwargs.setdefault("timeout", _DEFAULT_TIMEOUT)
    try:
        resp = requests.request(method, url, **kwargs)
    except requests.exceptions.Timeout:
        return {"ok": False, "error": f"timeout after {_DEFAULT_TIMEOUT}s: {url}"}
    except requests.exceptions.RequestException as exc:
        return _err(exc)
    try:
        body: Any = resp.json()
    except ValueError:
        body = resp.text
    if not resp.ok:
        msg = body
        if isinstance(body, dict):
            msg = body.get("error_description") or body.get("Fault") or body.get("message") or body
        return {"ok": False, "error": f"HTTP {resp.status_code}: {msg}", "status": resp.status_code}
    return {"ok": True, "status": resp.status_code, "body": body}


# ──────────────────────────────────────────────────────────────────────────
# LOCAL DB — expenses / mileage / invoices ledger
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/)."""
    # this file lives at brain/integrations/accounting.py — three levels up
    return os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )


def _db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "expenses.db")


_DB_CONN: Optional[sqlite3.Connection] = None
_DB_LOCK = threading.Lock()


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    amount REAL NOT NULL,
    merchant TEXT,
    category TEXT,
    expense_date TEXT,
    receipt_path TEXT,
    notes TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS mileage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    miles REAL NOT NULL,
    purpose TEXT,
    trip_date TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client TEXT,
    amount REAL NOT NULL,
    issued_date TEXT,
    due_date TEXT,
    status TEXT DEFAULT 'open',
    notes TEXT,
    created_at REAL DEFAULT (strftime('%s','now'))
);
"""


def _db() -> sqlite3.Connection:
    """Return the shared SQLite connection, creating schema on first use."""
    global _DB_CONN
    with _DB_LOCK:
        if _DB_CONN is None:
            conn = sqlite3.connect(_db_path(), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.executescript(_SCHEMA_SQL)
            conn.commit()
            _DB_CONN = conn
        return _DB_CONN


def _today() -> str:
    return date.today().isoformat()


def _norm_date(value: Optional[str]) -> str:
    """Normalise a date string to ISO YYYY-MM-DD, defaulting to today."""
    if not value:
        return _today()
    value = str(value).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%d/%m/%Y", "%Y/%m/%d", "%b %d, %Y", "%B %d, %Y"):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return value  # leave as-is if unparseable


def _month_key(value: Optional[str]) -> Optional[str]:
    """Return a YYYY-MM month key from a date string, or None."""
    if not value:
        return None
    iso = _norm_date(value)
    return iso[:7] if len(iso) >= 7 else None


# ══════════════════════════════════════════════════════════════════════════
# QUICKBOOKS ONLINE
# ══════════════════════════════════════════════════════════════════════════

_QB_BASE = "https://quickbooks.api.intuit.com/v3/company"


def _qb_headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_cred('QUICKBOOKS_ACCESS_TOKEN')}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _qb_query(realm: str, sql: str) -> Dict[str, Any]:
    """Run a QuickBooks SQL-style query and return {ok, ...}."""
    url = f"{_QB_BASE}/{realm}/query"
    return _http("GET", url, headers=_qb_headers(), params={"query": sql})


def _qb_report(realm: str, report: str, params: Dict[str, Any]) -> Dict[str, Any]:
    url = f"{_QB_BASE}/{realm}/reports/{report}"
    return _http("GET", url, headers=_qb_headers(), params=params)


def qb_invoices(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _qb_query(realm, f"SELECT * FROM Invoice ORDERBY MetaData.LastUpdatedTime DESC MAXRESULTS {limit}")
    if not res["ok"]:
        return res
    rows = (res["body"].get("QueryResponse", {}) or {}).get("Invoice", [])
    return {"ok": True, "count": len(rows), "invoices": rows}


def qb_invoice_create(args: Dict[str, Any]) -> Dict[str, Any]:
    """MEDIUM — create a QuickBooks invoice."""
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    customer_id = args.get("customer_id")
    line_items = args.get("line_items")
    due_date = args.get("due_date")
    if not customer_id:
        return {"ok": False, "error": "customer_id is required"}
    if not line_items or not isinstance(line_items, list):
        return {"ok": False, "error": "line_items must be a non-empty list"}
    try:
        lines = []
        for item in line_items:
            amount = float(item.get("amount", 0))
            line: Dict[str, Any] = {
                "DetailType": "SalesItemLineDetail",
                "Amount": amount,
                "Description": item.get("description", ""),
                "SalesItemLineDetail": {},
            }
            if item.get("item_id"):
                line["SalesItemLineDetail"]["ItemRef"] = {"value": str(item["item_id"])}
            if item.get("quantity") is not None:
                line["SalesItemLineDetail"]["Qty"] = float(item["quantity"])
            lines.append(line)
    except (TypeError, ValueError) as exc:
        return _err(exc)
    payload: Dict[str, Any] = {
        "CustomerRef": {"value": str(customer_id)},
        "Line": lines,
    }
    if due_date:
        payload["DueDate"] = _norm_date(due_date)
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _http(
        "POST",
        f"{_QB_BASE}/{realm}/invoice",
        headers=_qb_headers(),
        json=payload,
    )
    if not res["ok"]:
        return res
    return {"ok": True, "invoice": res["body"].get("Invoice", res["body"])}


def qb_expenses(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _qb_query(realm, f"SELECT * FROM Purchase ORDERBY MetaData.LastUpdatedTime DESC MAXRESULTS {limit}")
    if not res["ok"]:
        return res
    rows = (res["body"].get("QueryResponse", {}) or {}).get("Purchase", [])
    return {"ok": True, "count": len(rows), "expenses": rows}


def qb_customers(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _qb_query(realm, "SELECT * FROM Customer MAXRESULTS 200")
    if not res["ok"]:
        return res
    rows = (res["body"].get("QueryResponse", {}) or {}).get("Customer", [])
    return {"ok": True, "count": len(rows), "customers": rows}


def qb_profit_loss(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    realm = _cred("QUICKBOOKS_REALM_ID")
    params: Dict[str, Any] = {}
    if args.get("start_date"):
        params["start_date"] = _norm_date(args["start_date"])
    if args.get("end_date"):
        params["end_date"] = _norm_date(args["end_date"])
    res = _qb_report(realm, "ProfitAndLoss", params)
    if not res["ok"]:
        return res
    return {"ok": True, "report": res["body"]}


def qb_balance_sheet(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _qb_report(realm, "BalanceSheet", {})
    if not res["ok"]:
        return res
    return {"ok": True, "report": res["body"]}


def qb_accounts(args: Dict[str, Any]) -> Dict[str, Any]:
    """Chart of accounts."""
    err = _need("QUICKBOOKS_ACCESS_TOKEN", "QUICKBOOKS_REALM_ID")
    if err:
        return err
    realm = _cred("QUICKBOOKS_REALM_ID")
    res = _qb_query(realm, "SELECT * FROM Account MAXRESULTS 500")
    if not res["ok"]:
        return res
    rows = (res["body"].get("QueryResponse", {}) or {}).get("Account", [])
    return {"ok": True, "count": len(rows), "accounts": rows}


# ══════════════════════════════════════════════════════════════════════════
# WAVE (GraphQL)
# ══════════════════════════════════════════════════════════════════════════

_WAVE_URL = "https://gql.waveapps.com/graphql/public"


def _wave_gql(query: str, variables: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """POST a GraphQL query to Wave. Returns {ok, data} or {ok:False,error}."""
    headers = {
        "Authorization": f"Bearer {_cred('WAVE_API_TOKEN')}",
        "Content-Type": "application/json",
    }
    res = _http(
        "POST",
        _WAVE_URL,
        headers=headers,
        json={"query": query, "variables": variables or {}},
    )
    if not res["ok"]:
        return res
    body = res["body"]
    if isinstance(body, dict) and body.get("errors"):
        msgs = "; ".join(e.get("message", str(e)) for e in body["errors"])
        return {"ok": False, "error": f"GraphQL error: {msgs}"}
    return {"ok": True, "data": (body or {}).get("data", {})}


def wave_businesses(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("WAVE_API_TOKEN")
    if err:
        return err
    query = """
    query { businesses(page: 1, pageSize: 50) {
      edges { node { id name isPersonal currency { code } } }
    } }
    """
    res = _wave_gql(query)
    if not res["ok"]:
        return res
    edges = (res["data"].get("businesses", {}) or {}).get("edges", [])
    biz = [e["node"] for e in edges]
    return {"ok": True, "count": len(biz), "businesses": biz}


def wave_invoices(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("WAVE_API_TOKEN")
    if err:
        return err
    business_id = args.get("business_id")
    if not business_id:
        return {"ok": False, "error": "business_id is required (see acct.wave_businesses)"}
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    query = """
    query ($bid: ID!, $size: Int!) {
      business(id: $bid) {
        invoices(page: 1, pageSize: $size) {
          edges { node {
            id invoiceNumber status total { value } amountDue { value }
            invoiceDate dueDate customer { name }
          } }
        }
      }
    }
    """
    res = _wave_gql(query, {"bid": business_id, "size": limit})
    if not res["ok"]:
        return res
    biz = res["data"].get("business") or {}
    edges = (biz.get("invoices", {}) or {}).get("edges", [])
    rows = [e["node"] for e in edges]
    return {"ok": True, "count": len(rows), "invoices": rows}


def wave_invoice_create(args: Dict[str, Any]) -> Dict[str, Any]:
    """MEDIUM — create a Wave invoice."""
    err = _need("WAVE_API_TOKEN")
    if err:
        return err
    business_id = args.get("business_id")
    customer_id = args.get("customer_id")
    items = args.get("items")
    if not business_id or not customer_id:
        return {"ok": False, "error": "business_id and customer_id are required"}
    if not items or not isinstance(items, list):
        return {"ok": False, "error": "items must be a non-empty list"}
    try:
        gql_items = []
        for it in items:
            entry: Dict[str, Any] = {
                "productId": str(it["product_id"]) if it.get("product_id") else None,
                "quantity": float(it.get("quantity", 1)),
                "unitPrice": float(it.get("unit_price", it.get("amount", 0))),
            }
            if it.get("description"):
                entry["description"] = str(it["description"])
            gql_items.append({k: v for k, v in entry.items() if v is not None})
    except (TypeError, ValueError, KeyError) as exc:
        return _err(exc)
    mutation = """
    mutation ($input: InvoiceCreateInput!) {
      invoiceCreate(input: $input) {
        didSucceed
        inputErrors { message path }
        invoice { id invoiceNumber status total { value } }
      }
    }
    """
    variables = {
        "input": {
            "businessId": business_id,
            "customerId": customer_id,
            "items": gql_items,
        }
    }
    res = _wave_gql(mutation, variables)
    if not res["ok"]:
        return res
    payload = (res["data"].get("invoiceCreate") or {})
    if not payload.get("didSucceed"):
        errs = payload.get("inputErrors") or []
        return {"ok": False, "error": "Wave rejected invoice", "input_errors": errs}
    return {"ok": True, "invoice": payload.get("invoice")}


def wave_transactions(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("WAVE_API_TOKEN")
    if err:
        return err
    business_id = args.get("business_id")
    if not business_id:
        return {"ok": False, "error": "business_id is required (see acct.wave_businesses)"}
    try:
        limit = int(args.get("limit", 30))
    except (TypeError, ValueError):
        limit = 30
    query = """
    query ($bid: ID!, $size: Int!) {
      business(id: $bid) {
        transactions(page: 1, pageSize: $size) {
          edges { node {
            id date description
            total { value }
            transactionType
          } }
        }
      }
    }
    """
    res = _wave_gql(query, {"bid": business_id, "size": limit})
    if not res["ok"]:
        return res
    biz = res["data"].get("business") or {}
    edges = (biz.get("transactions", {}) or {}).get("edges", [])
    rows = [e["node"] for e in edges]
    return {"ok": True, "count": len(rows), "transactions": rows}


# ══════════════════════════════════════════════════════════════════════════
# XERO
# ══════════════════════════════════════════════════════════════════════════

_XERO_BASE = "https://api.xero.com/api.xro/2.0"


def _xero_headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_cred('XERO_ACCESS_TOKEN')}",
        "Xero-Tenant-Id": _cred("XERO_TENANT_ID") or "",
        "Accept": "application/json",
    }


def xero_invoices(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("XERO_ACCESS_TOKEN", "XERO_TENANT_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    res = _http(
        "GET",
        f"{_XERO_BASE}/Invoices",
        headers=_xero_headers(),
        params={"order": "Date DESC", "page": 1},
    )
    if not res["ok"]:
        return res
    rows = (res["body"] or {}).get("Invoices", []) if isinstance(res["body"], dict) else []
    return {"ok": True, "count": len(rows[:limit]), "invoices": rows[:limit]}


def xero_contacts(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("XERO_ACCESS_TOKEN", "XERO_TENANT_ID")
    if err:
        return err
    res = _http("GET", f"{_XERO_BASE}/Contacts", headers=_xero_headers())
    if not res["ok"]:
        return res
    rows = (res["body"] or {}).get("Contacts", []) if isinstance(res["body"], dict) else []
    return {"ok": True, "count": len(rows), "contacts": rows}


def xero_profit_loss(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("XERO_ACCESS_TOKEN", "XERO_TENANT_ID")
    if err:
        return err
    res = _http("GET", f"{_XERO_BASE}/Reports/ProfitAndLoss", headers=_xero_headers())
    if not res["ok"]:
        return res
    rows = (res["body"] or {}).get("Reports", []) if isinstance(res["body"], dict) else []
    return {"ok": True, "report": rows[0] if rows else res["body"]}


def xero_bank_transactions(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("XERO_ACCESS_TOKEN", "XERO_TENANT_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 30))
    except (TypeError, ValueError):
        limit = 30
    res = _http(
        "GET",
        f"{_XERO_BASE}/BankTransactions",
        headers=_xero_headers(),
        params={"order": "Date DESC", "page": 1},
    )
    if not res["ok"]:
        return res
    rows = (res["body"] or {}).get("BankTransactions", []) if isinstance(res["body"], dict) else []
    return {"ok": True, "count": len(rows[:limit]), "transactions": rows[:limit]}


# ══════════════════════════════════════════════════════════════════════════
# FRESHBOOKS
# ══════════════════════════════════════════════════════════════════════════

_FB_BASE = "https://api.freshbooks.com/accounting/account"


def _fb_headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_cred('FRESHBOOKS_ACCESS_TOKEN')}",
        "Api-Version": "alpha",
        "Content-Type": "application/json",
    }


def freshbooks_invoices(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("FRESHBOOKS_ACCESS_TOKEN", "FRESHBOOKS_ACCOUNT_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    acct = _cred("FRESHBOOKS_ACCOUNT_ID")
    res = _http(
        "GET",
        f"{_FB_BASE}/{acct}/invoices/invoices",
        headers=_fb_headers(),
        params={"per_page": limit, "page": 1},
    )
    if not res["ok"]:
        return res
    rows = (((res["body"] or {}).get("response", {}) or {}).get("result", {}) or {}).get("invoices", [])
    return {"ok": True, "count": len(rows), "invoices": rows}


def freshbooks_clients(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("FRESHBOOKS_ACCESS_TOKEN", "FRESHBOOKS_ACCOUNT_ID")
    if err:
        return err
    acct = _cred("FRESHBOOKS_ACCOUNT_ID")
    res = _http(
        "GET",
        f"{_FB_BASE}/{acct}/users/clients",
        headers=_fb_headers(),
        params={"per_page": 100, "page": 1},
    )
    if not res["ok"]:
        return res
    rows = (((res["body"] or {}).get("response", {}) or {}).get("result", {}) or {}).get("clients", [])
    return {"ok": True, "count": len(rows), "clients": rows}


def freshbooks_expenses(args: Dict[str, Any]) -> Dict[str, Any]:
    err = _need("FRESHBOOKS_ACCESS_TOKEN", "FRESHBOOKS_ACCOUNT_ID")
    if err:
        return err
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    acct = _cred("FRESHBOOKS_ACCOUNT_ID")
    res = _http(
        "GET",
        f"{_FB_BASE}/{acct}/expenses/expenses",
        headers=_fb_headers(),
        params={"per_page": limit, "page": 1},
    )
    if not res["ok"]:
        return res
    rows = (((res["body"] or {}).get("response", {}) or {}).get("result", {}) or {}).get("expenses", [])
    return {"ok": True, "count": len(rows), "expenses": rows}


# ══════════════════════════════════════════════════════════════════════════
# RECEIPT OCR + LOCAL EXPENSE / MILEAGE LEDGER
# ══════════════════════════════════════════════════════════════════════════

_AMOUNT_RE = re.compile(r"(?:\$|usd\s*)?(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})|\d+\.\d{2})", re.IGNORECASE)
_TOTAL_RE = re.compile(r"(?:grand\s+)?total\b[^0-9\-]{0,15}\$?\s*(\d+(?:[.,]\d{2}))", re.IGNORECASE)
_TAX_RE = re.compile(r"\b(?:sales\s+)?tax\b[^0-9\-]{0,15}\$?\s*(\d+(?:[.,]\d{2}))", re.IGNORECASE)
_DATE_RE = re.compile(
    r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}[/-]\d{1,2}[/-]\d{1,2}|"
    r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4})\b",
    re.IGNORECASE,
)


def _to_float(token: str) -> Optional[float]:
    try:
        return float(token.replace(",", "").replace(" ", ""))
    except (ValueError, AttributeError):
        return None


def receipt_scan(args: Dict[str, Any]) -> Dict[str, Any]:
    """OCR a receipt image with tesseract and regex-extract key fields."""
    image_path = args.get("image_path")
    if not image_path:
        return {"ok": False, "error": "image_path is required"}
    path = os.path.expanduser(str(image_path))
    if not os.path.isfile(path):
        return {"ok": False, "error": f"image not found: {path}"}
    if shutil.which("tesseract") is None:
        return {
            "ok": False,
            "error": "tesseract is not installed. Install with: sudo apt install tesseract-ocr",
        }
    try:
        proc = subprocess.run(
            ["tesseract", path, "stdout"],
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "tesseract OCR timed out after 60s"}
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if proc.returncode != 0:
        return {"ok": False, "error": f"tesseract failed: {proc.stderr.strip()[:300]}"}

    text = proc.stdout or ""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]

    # merchant: first non-trivial line that is not numeric/address-like
    merchant = None
    for ln in lines[:6]:
        if len(ln) >= 3 and not _AMOUNT_RE.fullmatch(ln) and not re.fullmatch(r"[\d\W]+", ln):
            merchant = ln
            break

    total = None
    m = _TOTAL_RE.search(text)
    if m:
        total = _to_float(m.group(1))
    if total is None:
        # fallback: largest dollar amount on the receipt
        amounts = [_to_float(a) for a in _AMOUNT_RE.findall(text)]
        amounts = [a for a in amounts if a is not None]
        if amounts:
            total = max(amounts)

    tax = None
    mt = _TAX_RE.search(text)
    if mt:
        tax = _to_float(mt.group(1))

    found_date = None
    md = _DATE_RE.search(text)
    if md:
        found_date = _norm_date(md.group(1))

    return {
        "ok": True,
        "image_path": path,
        "merchant": merchant,
        "date": found_date,
        "total": total,
        "tax": tax,
        "raw_text": text.strip(),
        "line_count": len(lines),
    }


def expense_log(args: Dict[str, Any]) -> Dict[str, Any]:
    """Record an expense in the local SQLite ledger."""
    amount = args.get("amount")
    merchant = args.get("merchant")
    category = args.get("category")
    if amount is None:
        return {"ok": False, "error": "amount is required"}
    try:
        amount = float(amount)
    except (TypeError, ValueError):
        return {"ok": False, "error": "amount must be a number"}
    if not merchant:
        return {"ok": False, "error": "merchant is required"}
    if not category:
        return {"ok": False, "error": "category is required"}
    exp_date = _norm_date(args.get("date"))
    try:
        conn = _db()
        with _DB_LOCK:
            cur = conn.execute(
                "INSERT INTO expenses (amount, merchant, category, expense_date, receipt_path, notes) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    amount,
                    str(merchant),
                    str(category),
                    exp_date,
                    args.get("receipt_path"),
                    args.get("notes"),
                ),
            )
            conn.commit()
            new_id = cur.lastrowid
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {
        "ok": True,
        "id": new_id,
        "amount": amount,
        "merchant": str(merchant),
        "category": str(category),
        "date": exp_date,
    }


def expense_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List logged expenses, optionally filtered by category and/or month."""
    try:
        limit = int(args.get("limit", 30))
    except (TypeError, ValueError):
        limit = 30
    category = args.get("category")
    month = args.get("month")
    sql = "SELECT * FROM expenses WHERE 1=1"
    params: List[Any] = []
    if category:
        sql += " AND category = ?"
        params.append(str(category))
    if month:
        sql += " AND substr(expense_date, 1, 7) = ?"
        params.append(str(month)[:7])
    sql += " ORDER BY expense_date DESC, id DESC LIMIT ?"
    params.append(limit)
    try:
        conn = _db()
        with _DB_LOCK:
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    total = round(sum(float(r["amount"]) for r in rows), 2)
    return {"ok": True, "count": len(rows), "total": total, "expenses": rows}


def expense_report(args: Dict[str, Any]) -> Dict[str, Any]:
    """Summarise expenses by category for a month (or all time)."""
    month = args.get("month")
    sql = "SELECT category, COUNT(*) AS n, SUM(amount) AS subtotal FROM expenses WHERE 1=1"
    params: List[Any] = []
    if month:
        sql += " AND substr(expense_date, 1, 7) = ?"
        params.append(str(month)[:7])
    sql += " GROUP BY category ORDER BY subtotal DESC"
    try:
        conn = _db()
        with _DB_LOCK:
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    by_category = [
        {
            "category": r["category"],
            "count": r["n"],
            "subtotal": round(float(r["subtotal"] or 0), 2),
        }
        for r in rows
    ]
    grand_total = round(sum(c["subtotal"] for c in by_category), 2)
    return {
        "ok": True,
        "month": month or "all-time",
        "by_category": by_category,
        "grand_total": grand_total,
        "category_count": len(by_category),
    }


def expense_export_csv(args: Dict[str, Any]) -> Dict[str, Any]:
    """Export expenses to a CSV file, optionally filtered by month."""
    save_to = args.get("save_to")
    if not save_to:
        return {"ok": False, "error": "save_to is required"}
    month = args.get("month")
    path = os.path.expanduser(str(save_to))
    sql = "SELECT id, expense_date, merchant, category, amount, notes, receipt_path FROM expenses WHERE 1=1"
    params: List[Any] = []
    if month:
        sql += " AND substr(expense_date, 1, 7) = ?"
        params.append(str(month)[:7])
    sql += " ORDER BY expense_date ASC, id ASC"
    try:
        conn = _db()
        with _DB_LOCK:
            rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(["id", "date", "merchant", "category", "amount", "notes", "receipt_path"])
            for r in rows:
                writer.writerow([
                    r["id"], r["expense_date"], r["merchant"], r["category"],
                    r["amount"], r["notes"] or "", r["receipt_path"] or "",
                ])
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    total = round(sum(float(r["amount"]) for r in rows), 2)
    return {"ok": True, "path": path, "rows": len(rows), "total": total, "month": month or "all-time"}


def mileage_log(args: Dict[str, Any]) -> Dict[str, Any]:
    """Record a business trip for IRS mileage tracking."""
    miles = args.get("miles")
    purpose = args.get("purpose")
    if miles is None:
        return {"ok": False, "error": "miles is required"}
    try:
        miles = float(miles)
    except (TypeError, ValueError):
        return {"ok": False, "error": "miles must be a number"}
    if not purpose:
        return {"ok": False, "error": "purpose is required"}
    trip_date = _norm_date(args.get("date"))
    try:
        conn = _db()
        with _DB_LOCK:
            cur = conn.execute(
                "INSERT INTO mileage (miles, purpose, trip_date) VALUES (?, ?, ?)",
                (miles, str(purpose), trip_date),
            )
            conn.commit()
            new_id = cur.lastrowid
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"ok": True, "id": new_id, "miles": miles, "purpose": str(purpose), "date": trip_date}


_IRS_MILEAGE_RATE = 0.67  # 2024 standard business mileage rate, $/mile


def mileage_total(args: Dict[str, Any]) -> Dict[str, Any]:
    """Total business miles and standard-mileage deduction estimate."""
    year = args.get("year")
    sql = "SELECT COUNT(*) AS n, COALESCE(SUM(miles), 0) AS miles FROM mileage WHERE 1=1"
    params: List[Any] = []
    if year:
        sql += " AND substr(trip_date, 1, 4) = ?"
        params.append(str(year)[:4])
    try:
        conn = _db()
        with _DB_LOCK:
            row = dict(conn.execute(sql, params).fetchone())
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    miles = round(float(row["miles"] or 0), 1)
    deduction = round(miles * _IRS_MILEAGE_RATE, 2)
    return {
        "ok": True,
        "year": year or "all-time",
        "trips": row["n"],
        "total_miles": miles,
        "rate_per_mile": _IRS_MILEAGE_RATE,
        "deduction_estimate": deduction,
        "note": "Standard mileage deduction estimate at the 2024 IRS rate. Not tax advice.",
    }


# ══════════════════════════════════════════════════════════════════════════
# TAX HELPERS — rough estimates, NOT tax advice
# ══════════════════════════════════════════════════════════════════════════

# 2024 federal ordinary-income brackets (single / married-joint).
_TAX_BRACKETS = {
    "single": [
        (0, 0.10), (11600, 0.12), (47150, 0.22), (100525, 0.24),
        (191950, 0.32), (243725, 0.35), (609350, 0.37),
    ],
    "married": [
        (0, 0.10), (23200, 0.12), (94300, 0.22), (201050, 0.24),
        (383900, 0.32), (487450, 0.35), (731200, 0.37),
    ],
}
_STD_DEDUCTION = {"single": 14600.0, "married": 29200.0}
_SE_TAX_RATE = 0.153          # 12.4% Social Security + 2.9% Medicare
_SE_TAXABLE_FACTOR = 0.9235   # net earnings subject to SE tax
_SS_WAGE_BASE_2024 = 168600.0


def _federal_income_tax(taxable: float, status: str) -> float:
    """Progressive federal income tax on a taxable-income figure."""
    brackets = _TAX_BRACKETS.get(status, _TAX_BRACKETS["single"])
    if taxable <= 0:
        return 0.0
    tax = 0.0
    for i, (floor, rate) in enumerate(brackets):
        ceiling = brackets[i + 1][0] if i + 1 < len(brackets) else float("inf")
        if taxable > floor:
            tax += (min(taxable, ceiling) - floor) * rate
        else:
            break
    return tax


def tax_self_employment(args: Dict[str, Any]) -> Dict[str, Any]:
    """Estimate self-employment tax (15.3%) on net business income."""
    net_income = args.get("net_income")
    if net_income is None:
        return {"ok": False, "error": "net_income is required"}
    try:
        net_income = float(net_income)
    except (TypeError, ValueError):
        return {"ok": False, "error": "net_income must be a number"}
    if net_income <= 0:
        return {
            "ok": True, "net_income": net_income, "se_tax": 0.0,
            "note": "No SE tax on zero or negative net income. Not tax advice.",
        }
    se_taxable = net_income * _SE_TAXABLE_FACTOR
    ss_portion = min(se_taxable, _SS_WAGE_BASE_2024) * 0.124
    medicare_portion = se_taxable * 0.029
    se_tax = round(ss_portion + medicare_portion, 2)
    return {
        "ok": True,
        "net_income": round(net_income, 2),
        "se_taxable_base": round(se_taxable, 2),
        "social_security_portion": round(ss_portion, 2),
        "medicare_portion": round(medicare_portion, 2),
        "se_tax": se_tax,
        "deductible_half": round(se_tax / 2, 2),
        "effective_rate": round(se_tax / net_income, 4),
        "note": "Rough 2024 SE-tax estimate. Half of SE tax is income-tax deductible. Not tax advice.",
    }


def tax_estimate_quarterly(args: Dict[str, Any]) -> Dict[str, Any]:
    """Rough quarterly estimated tax for a sole-prop / single-member LLC."""
    income = args.get("income")
    expenses = args.get("expenses", 0)
    status = str(args.get("filing_status", "single")).lower().strip()
    if status in ("married", "married_joint", "mfj", "joint"):
        status = "married"
    elif status not in ("single", "married"):
        status = "single"
    if income is None:
        return {"ok": False, "error": "income is required"}
    try:
        income = float(income)
        expenses = float(expenses or 0)
    except (TypeError, ValueError):
        return {"ok": False, "error": "income and expenses must be numbers"}

    net = income - expenses
    se = tax_self_employment({"net_income": net})
    se_tax = se.get("se_tax", 0.0) if se.get("ok") else 0.0
    half_se = se.get("deductible_half", 0.0) if se.get("ok") else 0.0

    taxable_income = max(0.0, net - half_se - _STD_DEDUCTION.get(status, _STD_DEDUCTION["single"]))
    income_tax = round(_federal_income_tax(taxable_income, status), 2)
    total_tax = round(income_tax + se_tax, 2)
    quarterly = round(total_tax / 4, 2)
    return {
        "ok": True,
        "filing_status": status,
        "gross_income": round(income, 2),
        "expenses": round(expenses, 2),
        "net_profit": round(net, 2),
        "self_employment_tax": se_tax,
        "taxable_income": round(taxable_income, 2),
        "federal_income_tax": income_tax,
        "total_estimated_tax": total_tax,
        "quarterly_payment": quarterly,
        "effective_rate": round(total_tax / income, 4) if income > 0 else 0.0,
        "note": (
            "Rough 2024 federal estimate only — excludes state tax, credits, QBI "
            "deduction, and other adjustments. Not tax advice; consult a CPA."
        ),
    }


def sales_tax_calc(args: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience: compute sales tax and gross total for an amount."""
    amount = args.get("amount")
    rate_pct = args.get("rate_pct")
    if amount is None or rate_pct is None:
        return {"ok": False, "error": "amount and rate_pct are required"}
    try:
        amount = float(amount)
        rate_pct = float(rate_pct)
    except (TypeError, ValueError):
        return {"ok": False, "error": "amount and rate_pct must be numbers"}
    tax = round(amount * rate_pct / 100.0, 2)
    return {
        "ok": True,
        "subtotal": round(amount, 2),
        "rate_pct": rate_pct,
        "sales_tax": tax,
        "total": round(amount + tax, 2),
    }


def invoice_aging(args: Dict[str, Any]) -> Dict[str, Any]:
    """Report which locally-logged invoices are overdue (aging buckets)."""
    today = date.today()
    try:
        conn = _db()
        with _DB_LOCK:
            rows = [
                dict(r)
                for r in conn.execute(
                    "SELECT * FROM invoices WHERE status != 'paid' ORDER BY due_date ASC"
                ).fetchall()
            ]
    except Exception as exc:  # noqa: BLE001
        return _err(exc)

    buckets = {"current": [], "1-30": [], "31-60": [], "61-90": [], "90+": []}
    overdue_total = 0.0
    for r in rows:
        due = r.get("due_date")
        days_over = 0
        if due:
            try:
                days_over = (today - datetime.strptime(_norm_date(due), "%Y-%m-%d").date()).days
            except ValueError:
                days_over = 0
        entry = {
            "id": r["id"],
            "client": r.get("client"),
            "amount": round(float(r["amount"]), 2),
            "due_date": due,
            "days_overdue": max(0, days_over),
        }
        if days_over <= 0:
            buckets["current"].append(entry)
        elif days_over <= 30:
            buckets["1-30"].append(entry)
            overdue_total += entry["amount"]
        elif days_over <= 60:
            buckets["31-60"].append(entry)
            overdue_total += entry["amount"]
        elif days_over <= 90:
            buckets["61-90"].append(entry)
            overdue_total += entry["amount"]
        else:
            buckets["90+"].append(entry)
            overdue_total += entry["amount"]

    return {
        "ok": True,
        "open_invoices": len(rows),
        "overdue_total": round(overdue_total, 2),
        "buckets": buckets,
        "note": (
            "Aging is computed from invoices logged in the local expenses.db "
            "'invoices' table. Empty if none have been recorded."
        ),
    }


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted name → callable
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # QuickBooks Online
    "acct.qb_invoices": qb_invoices,
    "acct.qb_invoice_create": qb_invoice_create,
    "acct.qb_expenses": qb_expenses,
    "acct.qb_customers": qb_customers,
    "acct.qb_profit_loss": qb_profit_loss,
    "acct.qb_balance_sheet": qb_balance_sheet,
    "acct.qb_accounts": qb_accounts,
    # Wave
    "acct.wave_businesses": wave_businesses,
    "acct.wave_invoices": wave_invoices,
    "acct.wave_invoice_create": wave_invoice_create,
    "acct.wave_transactions": wave_transactions,
    # Xero
    "acct.xero_invoices": xero_invoices,
    "acct.xero_contacts": xero_contacts,
    "acct.xero_profit_loss": xero_profit_loss,
    "acct.xero_bank_transactions": xero_bank_transactions,
    # FreshBooks
    "acct.freshbooks_invoices": freshbooks_invoices,
    "acct.freshbooks_clients": freshbooks_clients,
    "acct.freshbooks_expenses": freshbooks_expenses,
    # Receipt OCR + local expense / mileage ledger
    "acct.receipt_scan": receipt_scan,
    "acct.expense_log": expense_log,
    "acct.expense_list": expense_list,
    "acct.expense_report": expense_report,
    "acct.expense_export_csv": expense_export_csv,
    "acct.mileage_log": mileage_log,
    "acct.mileage_total": mileage_total,
    # Tax helpers
    "acct.tax_estimate_quarterly": tax_estimate_quarterly,
    "acct.tax_self_employment": tax_self_employment,
    "acct.sales_tax_calc": sales_tax_calc,
    "acct.invoice_aging": invoice_aging,
}
