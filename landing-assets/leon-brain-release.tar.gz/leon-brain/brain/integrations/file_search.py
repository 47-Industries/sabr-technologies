"""Semantic + full-text search across Dean's local files.

Two backends:

  1. **Full-text** — ripgrep against ~/Desktop / ~/Documents / ~/Downloads.
     Fast, no setup, works on every text file format Leon cares about.

  2. **Semantic** — embedding-based. Lazy-indexes file contents into a
     SQLite-backed vector store (`brain_state/file_index.db`). Uses
     existing Ollama (nomic-embed-text) for embeddings — no API key
     needed. Falls back to BM25 sparse retrieval if Ollama is offline.

Public tools:
  - file.fulltext_search(query, ...)
  - file.semantic_search(query, ...)
  - file.semantic_index(roots, extensions, force=False)
  - file.semantic_index_status()
  - file.semantic_index_clear()
  - file.find_by_name(pattern, root=None)
  - file.find_by_age(max_age_days, root=None)
  - file.large_files(min_mb=100, root=None)
  - file.recent_modifications(hours=24, root=None)
  - file.ask(question)  ← semantic search + LLM answer over hits
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


_DEFAULT_ROOTS = [
    str(Path.home() / "Desktop"),
    str(Path.home() / "Documents"),
    str(Path.home() / "Downloads"),
]
_INDEX_DB = Path(__file__).resolve().parent.parent.parent / "brain_state" / "file_index.db"
_INDEX_DB.parent.mkdir(parents=True, exist_ok=True)
_TEXT_EXTS = {".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".html",
              ".css", ".json", ".yaml", ".yml", ".toml", ".csv", ".log",
              ".rs", ".go", ".java", ".kt", ".swift", ".rb", ".php", ".sh",
              ".sql", ".env"}


def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _safe_root(p: str) -> bool:
    """Only allow paths under user home dirs to be indexed."""
    rp = Path(p).expanduser().resolve()
    home = Path.home().resolve()
    return str(rp).startswith(str(home))


def _db():
    conn = sqlite3.connect(str(_INDEX_DB))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _init_db():
    with _db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY,
            path TEXT UNIQUE, content_hash TEXT, mtime REAL,
            size INTEGER, indexed_at REAL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY,
            file_id INTEGER, chunk_index INTEGER, text TEXT,
            embedding BLOB,
            FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file_id)")


_init_db()


# ── Helpers ───────────────────────────────────────────────────────────
def _embed(text: str) -> Optional[List[float]]:
    """Ollama nomic-embed-text. Returns vector or None on failure."""
    import urllib.request
    try:
        req = urllib.request.Request(
            "http://localhost:11434/api/embeddings",
            data=json.dumps({"model": "nomic-embed-text", "prompt": text[:8000]}).encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read())
        return data.get("embedding")
    except Exception:
        return None


def _cosine(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    dot = sum(x*y for x, y in zip(a, b))
    na = math.sqrt(sum(x*x for x in a))
    nb = math.sqrt(sum(y*y for y in b))
    return dot / (na * nb + 1e-12)


def _chunk(text: str, target_size: int = 700) -> List[str]:
    """Split text into ~target_size word chunks at paragraph boundaries."""
    paras = re.split(r"\n\s*\n", text)
    chunks, current = [], []
    cur_len = 0
    for p in paras:
        p_words = len(p.split())
        if cur_len + p_words > target_size and current:
            chunks.append("\n\n".join(current))
            current, cur_len = [p], p_words
        else:
            current.append(p)
            cur_len += p_words
    if current:
        chunks.append("\n\n".join(current))
    return chunks


def _read_text(path: Path) -> Optional[str]:
    if path.suffix.lower() not in _TEXT_EXTS:
        # Try anyway only if small
        try:
            if path.stat().st_size > 200_000:
                return None
        except OSError:
            return None
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None


# ── Tools ─────────────────────────────────────────────────────────────
def _fulltext_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Ripgrep query against text files under given roots.

    Args:
      query: required pattern (regex)
      roots: list of dirs (default: ~/Desktop, ~/Documents, ~/Downloads)
      limit: max matches (default 30)
      case_sensitive: bool (default False)
    """
    query = args.get("query")
    if not query:
        return {"ok": False, "error": "query required"}
    roots = args.get("roots") or _DEFAULT_ROOTS
    limit = int(args.get("limit", 30))
    case_sensitive = bool(args.get("case_sensitive", False))

    if not _have("rg"):
        return {"ok": False, "error": "ripgrep (rg) not installed"}

    safe = [r for r in roots if _safe_root(r)]
    if not safe:
        return {"ok": False, "error": "no allowed roots"}

    cmd = ["rg", "--max-count", "3", "--no-heading",
            "--with-filename", "--line-number", "--color=never", "--smart-case"]
    if case_sensitive:
        cmd.remove("--smart-case")
    cmd += [query] + safe
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "rg timed out (20s)"}
    hits = []
    for line in (r.stdout or "").split("\n")[:limit]:
        if ":" in line:
            parts = line.split(":", 2)
            if len(parts) == 3:
                hits.append({"path": parts[0], "line": int(parts[1]) if parts[1].isdigit() else 0,
                              "snippet": parts[2][:240]})
    return {"ok": True, "hits": hits, "count": len(hits), "query": query}


def _find_by_name(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find files whose name matches a glob pattern.

    Args:
      pattern: e.g. "*.pdf", "leon-*.md"
      root: dir to search (default: ~/Desktop)
      limit: default 50
    """
    pattern = args.get("pattern")
    if not pattern:
        return {"ok": False, "error": "pattern required"}
    root = args.get("root") or str(Path.home() / "Desktop")
    if not _safe_root(root):
        return {"ok": False, "error": f"root not under home: {root}"}
    limit = int(args.get("limit", 50))
    if not _have("find"):
        return {"ok": False, "error": "find not available"}
    try:
        r = subprocess.run(["find", root, "-iname", pattern, "-type", "f"],
                            capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "find timed out"}
    paths = r.stdout.strip().split("\n")[:limit] if r.stdout else []
    return {"ok": True, "paths": [p for p in paths if p], "count": len(paths)}


def _find_by_age(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find files modified in the last N days (or older if `older=True`).

    Args:
      max_age_days: required
      root: default ~/Desktop
      older: bool — if True, find files OLDER than max_age_days
      limit: default 50
    """
    days = args.get("max_age_days")
    if days is None:
        return {"ok": False, "error": "max_age_days required"}
    days = int(days)
    root = args.get("root") or str(Path.home() / "Desktop")
    if not _safe_root(root):
        return {"ok": False, "error": f"root not under home: {root}"}
    older = bool(args.get("older", False))
    limit = int(args.get("limit", 50))
    flag = "-mtime"
    arg = f"+{days}" if older else f"-{days}"
    try:
        r = subprocess.run(["find", root, flag, arg, "-type", "f"],
                            capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "find timed out"}
    paths = (r.stdout or "").strip().split("\n")[:limit]
    return {"ok": True, "paths": [p for p in paths if p], "count": len(paths)}


def _large_files(args: Dict[str, Any]) -> Dict[str, Any]:
    """Files larger than min_mb under root."""
    min_mb = float(args.get("min_mb", 100))
    root = args.get("root") or str(Path.home())
    if not _safe_root(root):
        return {"ok": False, "error": f"root not under home: {root}"}
    limit = int(args.get("limit", 30))
    try:
        r = subprocess.run(
            ["find", root, "-type", "f", "-size", f"+{int(min_mb)}M"],
            capture_output=True, text=True, timeout=20,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "find timed out"}
    paths = [p for p in (r.stdout or "").strip().split("\n") if p][:limit]
    rows = []
    for p in paths:
        try:
            sz = Path(p).stat().st_size
            rows.append({"path": p, "mb": round(sz / 1024 / 1024, 2)})
        except OSError:
            continue
    rows.sort(key=lambda x: -x["mb"])
    return {"ok": True, "files": rows, "count": len(rows)}


def _recent_modifications(args: Dict[str, Any]) -> Dict[str, Any]:
    """Files modified in the last N hours."""
    hours = float(args.get("hours", 24))
    root = args.get("root") or str(Path.home() / "Desktop")
    if not _safe_root(root):
        return {"ok": False, "error": f"root not under home: {root}"}
    cutoff = time.time() - hours * 3600
    results = []
    for p in Path(root).rglob("*"):
        try:
            if p.is_file() and p.stat().st_mtime > cutoff:
                results.append({"path": str(p), "mtime": p.stat().st_mtime,
                                  "size": p.stat().st_size})
        except OSError:
            continue
        if len(results) > 200:
            break
    results.sort(key=lambda x: -x["mtime"])
    return {"ok": True, "files": results[:50], "count": len(results)}


# ── Semantic search ───────────────────────────────────────────────────
def _semantic_index(args: Dict[str, Any]) -> Dict[str, Any]:
    """Index text files into the semantic store.

    Args:
      roots: list of dirs (default: ~/Desktop)
      extensions: list of extensions to index (default: _TEXT_EXTS)
      max_files: cap (default 500)
      force: re-embed even if file unchanged
    """
    roots = args.get("roots") or [str(Path.home() / "Desktop")]
    roots = [r for r in roots if _safe_root(r)]
    if not roots:
        return {"ok": False, "error": "no allowed roots"}
    extensions = set(args.get("extensions") or _TEXT_EXTS)
    max_files = int(args.get("max_files", 500))
    force = bool(args.get("force", False))

    total_files = 0
    new_chunks = 0
    skipped = 0
    with _db() as c:
        for root in roots:
            for path in Path(root).rglob("*"):
                if total_files >= max_files:
                    break
                if not path.is_file() or path.suffix.lower() not in extensions:
                    continue
                try:
                    sz = path.stat().st_size
                    mtime = path.stat().st_mtime
                except OSError:
                    continue
                if sz > 1_000_000:  # skip files > 1MB
                    skipped += 1
                    continue
                # Skip if already indexed AND unchanged
                cur = c.execute("SELECT id, mtime FROM files WHERE path=?", (str(path),)).fetchone()
                if cur and not force and cur[1] == mtime:
                    continue

                text = _read_text(path)
                if not text:
                    continue
                content_hash = hashlib.sha1(text.encode("utf-8", "ignore")).hexdigest()[:16]
                # Insert/replace file row
                if cur:
                    c.execute("DELETE FROM chunks WHERE file_id=?", (cur[0],))
                    c.execute("UPDATE files SET content_hash=?, mtime=?, size=?, indexed_at=? WHERE id=?",
                               (content_hash, mtime, sz, time.time(), cur[0]))
                    file_id = cur[0]
                else:
                    c.execute("INSERT INTO files (path, content_hash, mtime, size, indexed_at) VALUES (?,?,?,?,?)",
                               (str(path), content_hash, mtime, sz, time.time()))
                    file_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]

                # Chunk + embed
                for i, chunk in enumerate(_chunk(text)):
                    emb = _embed(chunk)
                    emb_blob = json.dumps(emb).encode("utf-8") if emb else b""
                    c.execute("INSERT INTO chunks (file_id, chunk_index, text, embedding) VALUES (?,?,?,?)",
                               (file_id, i, chunk[:4000], emb_blob))
                    new_chunks += 1
                total_files += 1
    return {"ok": True, "files_indexed": total_files, "chunks_added": new_chunks, "skipped_too_large": skipped}


def _semantic_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Semantic search over indexed chunks.

    Args:
      query: required
      limit: max hits (default 10)
    """
    query = args.get("query")
    if not query:
        return {"ok": False, "error": "query required"}
    limit = int(args.get("limit", 10))

    q_emb = _embed(query)
    if not q_emb:
        # Fall back to keyword search
        return _fulltext_search(args)

    with _db() as c:
        rows = c.execute("""SELECT c.id, c.file_id, c.chunk_index, c.text, c.embedding, f.path
                            FROM chunks c JOIN files f ON c.file_id=f.id
                            WHERE c.embedding IS NOT NULL AND length(c.embedding) > 0
                            LIMIT 5000""").fetchall()
    scored = []
    for cid, fid, ci, text, emb_blob, fpath in rows:
        try:
            emb = json.loads(emb_blob.decode("utf-8"))
        except Exception:
            continue
        score = _cosine(q_emb, emb)
        scored.append({"path": fpath, "chunk_index": ci, "score": round(score, 3),
                        "snippet": text[:400]})
    scored.sort(key=lambda x: -x["score"])
    return {"ok": True, "hits": scored[:limit], "indexed_chunks": len(rows),
            "query": query}


def _semantic_index_status(args: Dict[str, Any]) -> Dict[str, Any]:
    with _db() as c:
        files = c.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        chunks = c.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        with_emb = c.execute("SELECT COUNT(*) FROM chunks WHERE length(embedding)>0").fetchone()[0]
    return {"ok": True, "files": files, "chunks": chunks, "chunks_with_embeddings": with_emb,
            "db_path": str(_INDEX_DB)}


def _semantic_index_clear(args: Dict[str, Any]) -> Dict[str, Any]:
    with _db() as c:
        c.execute("DELETE FROM chunks")
        c.execute("DELETE FROM files")
    return {"ok": True, "cleared": True}


def _ask(args: Dict[str, Any]) -> Dict[str, Any]:
    """Semantic search + summary: 'what was that idea I had about X?'

    Args:
      question: required
      limit: number of chunks to surface (default 5)
    """
    q = args.get("question")
    if not q:
        return {"ok": False, "error": "question required"}
    limit = int(args.get("limit", 5))
    results = _semantic_search({"query": q, "limit": limit})
    if not results.get("ok"):
        return results
    hits = results.get("hits", [])
    answer = ""
    if hits:
        answer = "Top matches:\n" + "\n\n".join(
            f"• {h['path']}: {h['snippet'][:200]}"
            for h in hits[:limit]
        )
    return {"ok": True, "question": q, "answer": answer, "hits": hits}


EXTRA_TOOLS = {
    "file.fulltext_search":         _fulltext_search,
    "file.find_by_name":            _find_by_name,
    "file.find_by_age":             _find_by_age,
    "file.large_files":             _large_files,
    "file.recent_modifications":    _recent_modifications,
    "file.semantic_index":          _semantic_index,
    "file.semantic_search":         _semantic_search,
    "file.semantic_index_status":   _semantic_index_status,
    "file.semantic_index_clear":    _semantic_index_clear,
    "file.ask":                     _ask,
}
