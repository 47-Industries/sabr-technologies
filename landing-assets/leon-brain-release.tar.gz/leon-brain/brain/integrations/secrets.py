"""
secrets.py — Password / secrets / crypto tool surface for Leon.

Tools cover:
  - Bitwarden CLI (`bw`)
  - 1Password CLI (`op`)
  - GPG encryption / signing
  - SSH key inventory + agent
  - Local Fernet-encrypted vault (brain_state/local_vault.bin)
  - TOTP / 2FA code generation (pyotp)
  - Random password / passphrase generation

Contract:
  - Every tool returns a dict, never raises.
  - `{"ok": bool, ...}` shape.
  - External CLIs that aren't installed return `{"ok": False, "error": "<tool> not installed"}`.
  - Cred redaction: passwords / API keys are NEVER echoed in audit logs or error
    messages. When a value MUST appear (e.g. bw_get_password), it is returned in
    the `password` field but the `audit` field is masked (first 4 chars + ****).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets as _pysecrets
import shutil
import string
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Paths / constants
# ---------------------------------------------------------------------------

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_BRAIN_STATE_DIR = _PROJECT_ROOT / "brain_state"
_VAULT_PATH = _BRAIN_STATE_DIR / "local_vault.bin"
_VAULT_SALT_PATH = _BRAIN_STATE_DIR / "local_vault.salt"

_DICEWARE_WORDS = [
    # Small built-in word list (~256 words) — good enough for offline passphrases.
    "anchor", "arrow", "atlas", "amber", "apple", "amber", "angle", "aspen",
    "badger", "basin", "baker", "blaze", "bloom", "bluff", "brave", "brick",
    "brook", "brush", "bugle", "buzzy", "cabin", "cable", "candle", "canyon",
    "carbon", "cargo", "carve", "cedar", "chant", "charm", "cinder", "civic",
    "clamp", "clasp", "clover", "cobra", "comet", "coral", "cosmic", "cotton",
    "cougar", "crane", "crater", "crisp", "cycle", "daisy", "dancer", "dapple",
    "dazzle", "delta", "denim", "diamond", "diesel", "dingo", "dolphin", "donut",
    "drift", "dune", "eagle", "ember", "engine", "ether", "evade", "fable",
    "falcon", "fang", "felix", "fern", "fiber", "finch", "flame", "fleet",
    "flint", "flora", "fluent", "foggy", "forge", "fossil", "frost", "fudge",
    "garnet", "gecko", "ginger", "glade", "gleam", "glider", "globe", "gnome",
    "golden", "granite", "grape", "graphite", "grouse", "grove", "guild", "harbor",
    "hawk", "haze", "hearth", "helix", "heron", "hickory", "hollow", "honey",
    "horizon", "humble", "husk", "icicle", "indigo", "iris", "iron", "ivory",
    "jagged", "jasper", "jelly", "jester", "jovial", "juniper", "kelp", "kestrel",
    "kettle", "knack", "lagoon", "lantern", "ledger", "lichen", "linen", "lobby",
    "loom", "lotus", "lunar", "lyric", "magpie", "mango", "maple", "marble",
    "marlin", "marsh", "meadow", "meteor", "mica", "midnight", "mint", "mirror",
    "mocha", "moss", "moth", "muffin", "myth", "nebula", "needle", "nimbus",
    "noble", "nova", "oasis", "oat", "ocean", "olive", "onyx", "opal",
    "orbit", "orca", "orchid", "otter", "owl", "oxide", "pacific", "panda",
    "papyrus", "parka", "parlor", "pearl", "pebble", "pelican", "pepper", "petal",
    "pewter", "phoenix", "pilot", "pine", "plasma", "platinum", "plum", "polar",
    "poppy", "prairie", "prism", "puffin", "pumice", "quail", "quartz", "quill",
    "quokka", "raccoon", "raven", "reef", "relic", "ridge", "rocket", "rouge",
    "rover", "ruby", "saffron", "sage", "salmon", "sand", "sapphire", "savor",
    "scarlet", "seaglass", "shadow", "shale", "shrimp", "signal", "silver", "skiff",
    "slate", "smoke", "snowy", "solar", "sonar", "sparrow", "spire", "sprout",
    "spruce", "stag", "starlight", "stone", "summit", "sundial", "swift", "tango",
    "tapir", "thicket", "thistle", "thorn", "thunder", "tidal", "timber", "topaz",
    "torch", "totem", "trail", "trellis", "truffle", "tulip", "tundra", "turret",
    "tusk", "twilight", "umber", "unicorn", "vector", "velvet", "verdant", "vesper",
    "violet", "vortex", "walnut", "warbler", "willow", "wisp", "wolverine", "yarrow",
    "yodel", "yonder", "zenith", "zephyr",
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _which(cmd: str) -> Optional[str]:
    return shutil.which(cmd)


def _not_installed(cmd: str) -> Dict[str, Any]:
    return {"ok": False, "error": f"{cmd} not installed"}


def _mask(s: Optional[str]) -> str:
    """Cred-redaction: first 4 chars + ****.  Never returns the full secret."""
    if not s:
        return ""
    s = str(s)
    if len(s) <= 4:
        return "*" * len(s)
    return s[:4] + "*" * 4


def _run(
    argv: List[str],
    *,
    stdin: Optional[str] = None,
    env: Optional[Dict[str, str]] = None,
    timeout: int = 30,
) -> Dict[str, Any]:
    """Subprocess wrapper that never raises and never echoes stdin."""
    try:
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        proc = subprocess.run(
            argv,
            input=stdin,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=merged_env,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr.strip(),
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout", "argv0": argv[0]}
    except FileNotFoundError:
        return {"ok": False, "error": f"{argv[0]} not installed"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"subprocess error: {type(e).__name__}"}


def _bw_env() -> Dict[str, str]:
    sess = os.environ.get("BW_SESSION")
    return {"BW_SESSION": sess} if sess else {}


def _ensure_state_dir() -> None:
    _BRAIN_STATE_DIR.mkdir(parents=True, exist_ok=True)


def _derive_fernet_key(password: str, salt: bytes) -> bytes:
    """PBKDF2-HMAC-SHA256 → 32 bytes → urlsafe-b64 → Fernet key."""
    raw = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000, dklen=32)
    return base64.urlsafe_b64encode(raw)


def _load_vault(password: str) -> Dict[str, Any]:
    """Returns {'ok': True, 'data': {...}} or {'ok': False, 'error': ...}."""
    try:
        from cryptography.fernet import Fernet, InvalidToken  # type: ignore
    except ImportError:
        return {"ok": False, "error": "cryptography not installed"}

    _ensure_state_dir()
    if not _VAULT_PATH.exists():
        return {"ok": True, "data": {}, "new": True}
    if not _VAULT_SALT_PATH.exists():
        return {"ok": False, "error": "vault salt missing — vault corrupt"}

    try:
        salt = _VAULT_SALT_PATH.read_bytes()
        key = _derive_fernet_key(password, salt)
        f = Fernet(key)
        blob = _VAULT_PATH.read_bytes()
        decrypted = f.decrypt(blob)
        return {"ok": True, "data": json.loads(decrypted.decode("utf-8")), "new": False}
    except InvalidToken:
        return {"ok": False, "error": "wrong vault password or corrupt vault"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"vault load failed: {type(e).__name__}"}


def _save_vault(data: Dict[str, Any], password: str) -> Dict[str, Any]:
    try:
        from cryptography.fernet import Fernet  # type: ignore
    except ImportError:
        return {"ok": False, "error": "cryptography not installed"}

    _ensure_state_dir()
    if _VAULT_SALT_PATH.exists():
        salt = _VAULT_SALT_PATH.read_bytes()
    else:
        salt = _pysecrets.token_bytes(16)
        _VAULT_SALT_PATH.write_bytes(salt)
        try:
            os.chmod(_VAULT_SALT_PATH, 0o600)
        except OSError:
            pass

    try:
        key = _derive_fernet_key(password, salt)
        f = Fernet(key)
        blob = f.encrypt(json.dumps(data).encode("utf-8"))
        _VAULT_PATH.write_bytes(blob)
        try:
            os.chmod(_VAULT_PATH, 0o600)
        except OSError:
            pass
        return {"ok": True}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"vault save failed: {type(e).__name__}"}


# ---------------------------------------------------------------------------
# Bitwarden CLI
# ---------------------------------------------------------------------------


def bw_status() -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    r = _run(["bw", "status"], env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "bw status failed", "stderr": r.get("stderr", "")}
    try:
        status = json.loads(r["stdout"])
        return {"ok": True, "status": status.get("status"), "user": status.get("userEmail")}
    except json.JSONDecodeError:
        return {"ok": False, "error": "bw status returned non-JSON"}


def bw_unlock(password: str) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    if not password:
        return {"ok": False, "error": "password required"}
    r = _run(["bw", "unlock", "--raw", "--passwordenv", "_BW_PW_TMP"], env={"_BW_PW_TMP": password})
    if not r["ok"]:
        return {"ok": False, "error": "unlock failed (wrong password or not logged in)"}
    session = r["stdout"].strip()
    if not session:
        return {"ok": False, "error": "no session token returned"}
    os.environ["BW_SESSION"] = session
    return {"ok": True, "session_masked": _mask(session), "note": "BW_SESSION set in env"}


def bw_lock() -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    r = _run(["bw", "lock"], env=_bw_env())
    os.environ.pop("BW_SESSION", None)
    return {"ok": r["ok"], "stderr": r.get("stderr", "")}


def bw_list(search: Optional[str] = None, limit: int = 50) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    argv = ["bw", "list", "items"]
    if search:
        argv += ["--search", search]
    r = _run(argv, env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "bw list failed (vault locked?)"}
    try:
        items = json.loads(r["stdout"])
    except json.JSONDecodeError:
        return {"ok": False, "error": "bw list returned non-JSON"}
    redacted = []
    for it in items[: max(1, int(limit))]:
        login = it.get("login") or {}
        redacted.append(
            {
                "id": it.get("id"),
                "name": it.get("name"),
                "username": login.get("username"),
            }
        )
    return {"ok": True, "count": len(redacted), "items": redacted}


def bw_get_password(item_name_or_id: str) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    if not item_name_or_id:
        return {"ok": False, "error": "item name or id required"}
    r = _run(["bw", "get", "password", item_name_or_id], env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "item not found or vault locked"}
    pw = r["stdout"].strip()
    return {
        "ok": True,
        "password": pw,
        "audit": _mask(pw),
        "item": item_name_or_id,
    }


def bw_get_username(item_name_or_id: str) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    if not item_name_or_id:
        return {"ok": False, "error": "item name or id required"}
    r = _run(["bw", "get", "username", item_name_or_id], env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "item not found or vault locked"}
    return {"ok": True, "username": r["stdout"].strip(), "item": item_name_or_id}


def bw_generate_password(
    length: int = 20,
    uppercase: bool = True,
    lowercase: bool = True,
    numbers: bool = True,
    special: bool = True,
) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    argv = ["bw", "generate", f"--length={int(length)}"]
    if uppercase:
        argv.append("--uppercase")
    if lowercase:
        argv.append("--lowercase")
    if numbers:
        argv.append("--number")
    if special:
        argv.append("--special")
    r = _run(argv, env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "bw generate failed"}
    pw = r["stdout"].strip()
    return {"ok": True, "password": pw, "audit": _mask(pw), "length": len(pw)}


def bw_create_item(
    name: str,
    username: str,
    password: str,
    url: Optional[str] = None,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    if not _which("bw"):
        return _not_installed("bw")
    if not name or password is None:
        return {"ok": False, "error": "name and password required"}
    item = {
        "type": 1,  # login
        "name": name,
        "notes": notes or "",
        "login": {
            "username": username or "",
            "password": password,
            "uris": [{"match": None, "uri": url}] if url else [],
        },
    }
    encoded = base64.b64encode(json.dumps(item).encode("utf-8")).decode("ascii")
    r = _run(["bw", "create", "item", encoded], env=_bw_env())
    if not r["ok"]:
        return {"ok": False, "error": "bw create failed (vault locked?)"}
    try:
        created = json.loads(r["stdout"])
        return {
            "ok": True,
            "id": created.get("id"),
            "name": created.get("name"),
            "audit": f"created login '{name}' user={username} pw={_mask(password)}",
            "risk": "MEDIUM",
        }
    except json.JSONDecodeError:
        return {"ok": True, "audit": f"created login '{name}'", "risk": "MEDIUM"}


# ---------------------------------------------------------------------------
# 1Password CLI
# ---------------------------------------------------------------------------


def op_signin_status() -> Dict[str, Any]:
    if not _which("op"):
        return _not_installed("op")
    r = _run(["op", "account", "list", "--format=json"])
    if not r["ok"]:
        return {"ok": False, "error": "op account list failed", "stderr": r.get("stderr", "")}
    try:
        accounts = json.loads(r["stdout"] or "[]")
        whoami = _run(["op", "whoami", "--format=json"])
        signed_in = whoami["ok"]
        return {
            "ok": True,
            "signed_in": signed_in,
            "accounts": [a.get("email") for a in accounts],
        }
    except json.JSONDecodeError:
        return {"ok": False, "error": "op returned non-JSON"}


def op_list_items(vault: Optional[str] = None, limit: int = 50) -> Dict[str, Any]:
    if not _which("op"):
        return _not_installed("op")
    argv = ["op", "item", "list", "--format=json"]
    if vault:
        argv += ["--vault", vault]
    r = _run(argv)
    if not r["ok"]:
        return {"ok": False, "error": "op item list failed (not signed in?)"}
    try:
        items = json.loads(r["stdout"] or "[]")
    except json.JSONDecodeError:
        return {"ok": False, "error": "op returned non-JSON"}
    redacted = []
    for it in items[: max(1, int(limit))]:
        redacted.append(
            {
                "id": it.get("id"),
                "title": it.get("title"),
                "category": it.get("category"),
                "vault": (it.get("vault") or {}).get("name"),
            }
        )
    return {"ok": True, "count": len(redacted), "items": redacted}


def op_get_field(item: str, field: str, vault: Optional[str] = None) -> Dict[str, Any]:
    if not _which("op"):
        return _not_installed("op")
    if not item or not field:
        return {"ok": False, "error": "item and field required"}
    argv = ["op", "item", "get", item, "--fields", field]
    if vault:
        argv += ["--vault", vault]
    r = _run(argv)
    if not r["ok"]:
        return {"ok": False, "error": "op item get failed"}
    value = r["stdout"].strip()
    sensitive = field.lower() in {"password", "credential", "secret", "api_key", "apikey", "token"}
    return {
        "ok": True,
        "field": field,
        "value": value,
        "audit": _mask(value) if sensitive else value,
    }


def op_get_password(item: str, vault: Optional[str] = None) -> Dict[str, Any]:
    return op_get_field(item, "password", vault=vault)


def op_create_login(
    title: str,
    username: str,
    password: str,
    url: Optional[str] = None,
    vault: Optional[str] = None,
) -> Dict[str, Any]:
    if not _which("op"):
        return _not_installed("op")
    if not title or password is None:
        return {"ok": False, "error": "title and password required"}
    argv = [
        "op",
        "item",
        "create",
        "--category=login",
        f"--title={title}",
        f"username={username or ''}",
        f"password={password}",
    ]
    if url:
        argv.append(f"url={url}")
    if vault:
        argv += ["--vault", vault]
    r = _run(argv)
    if not r["ok"]:
        return {"ok": False, "error": "op item create failed"}
    return {
        "ok": True,
        "title": title,
        "audit": f"created 1P login '{title}' user={username} pw={_mask(password)}",
        "risk": "MEDIUM",
    }


# ---------------------------------------------------------------------------
# GPG
# ---------------------------------------------------------------------------


def gpg_encrypt(
    text: str,
    recipient_email_or_key_id: str,
    output_path: Optional[str] = None,
) -> Dict[str, Any]:
    if not _which("gpg"):
        return _not_installed("gpg")
    if text is None:
        return {"ok": False, "error": "text required"}
    if not recipient_email_or_key_id:
        # Symmetric: GPG will prompt for passphrase — disallow in non-interactive context.
        return {"ok": False, "error": "recipient required (symmetric mode not supported in non-interactive)"}
    argv = ["gpg", "--batch", "--yes", "--armor", "--encrypt", "--recipient", recipient_email_or_key_id]
    if output_path:
        argv += ["--output", output_path]
    r = _run(argv, stdin=text)
    if not r["ok"]:
        return {"ok": False, "error": "gpg encrypt failed", "stderr": r.get("stderr", "")}
    return {
        "ok": True,
        "output_path": output_path,
        "ciphertext": None if output_path else r["stdout"],
        "recipient": recipient_email_or_key_id,
    }


def gpg_decrypt(input_path: str) -> Dict[str, Any]:
    if not _which("gpg"):
        return _not_installed("gpg")
    if not input_path or not Path(input_path).exists():
        return {"ok": False, "error": "input file not found"}
    r = _run(["gpg", "--batch", "--yes", "--decrypt", input_path])
    if not r["ok"]:
        return {"ok": False, "error": "gpg decrypt failed (key loaded?)"}
    return {"ok": True, "plaintext": r["stdout"]}


def gpg_list_keys() -> Dict[str, Any]:
    if not _which("gpg"):
        return _not_installed("gpg")
    pub = _run(["gpg", "--list-keys", "--with-colons"])
    sec = _run(["gpg", "--list-secret-keys", "--with-colons"])
    if not pub["ok"] and not sec["ok"]:
        return {"ok": False, "error": "gpg listing failed"}

    def _parse(out: str) -> List[Dict[str, str]]:
        keys: List[Dict[str, str]] = []
        current: Optional[Dict[str, str]] = None
        for line in out.splitlines():
            parts = line.split(":")
            if not parts:
                continue
            rec = parts[0]
            if rec in ("pub", "sec"):
                if current:
                    keys.append(current)
                current = {"type": rec, "keyid": parts[4] if len(parts) > 4 else ""}
            elif rec == "uid" and current is not None and len(parts) > 9:
                current.setdefault("uid", parts[9])
        if current:
            keys.append(current)
        return keys

    return {
        "ok": True,
        "public": _parse(pub.get("stdout", "")),
        "secret": _parse(sec.get("stdout", "")),
    }


def gpg_sign(text: str, key_id: Optional[str] = None) -> Dict[str, Any]:
    if not _which("gpg"):
        return _not_installed("gpg")
    if text is None:
        return {"ok": False, "error": "text required"}
    argv = ["gpg", "--batch", "--yes", "--armor", "--clearsign"]
    if key_id:
        argv += ["--local-user", key_id]
    r = _run(argv, stdin=text)
    if not r["ok"]:
        return {"ok": False, "error": "gpg sign failed", "stderr": r.get("stderr", "")}
    return {"ok": True, "signed": r["stdout"], "key_id": key_id}


def gpg_verify(signed_text: str) -> Dict[str, Any]:
    if not _which("gpg"):
        return _not_installed("gpg")
    if not signed_text:
        return {"ok": False, "error": "signed text required"}
    r = _run(["gpg", "--batch", "--yes", "--verify"], stdin=signed_text)
    stderr = r.get("stderr", "")
    valid = "Good signature" in stderr
    return {
        "ok": r["ok"],
        "valid": valid,
        "info": stderr,
    }


# ---------------------------------------------------------------------------
# SSH
# ---------------------------------------------------------------------------


def ssh_list_keys() -> Dict[str, Any]:
    ssh_dir = Path.home() / ".ssh"
    if not ssh_dir.exists():
        return {"ok": True, "keys": [], "note": "~/.ssh missing"}
    keys = []
    for f in sorted(ssh_dir.iterdir()):
        if not f.is_file():
            continue
        name = f.name
        if name.endswith(".pub"):
            kind = "public"
        elif name in {"authorized_keys", "known_hosts", "config"}:
            continue
        elif name.startswith("id_") or name.startswith("identity"):
            kind = "private"
        else:
            kind = "other"
        try:
            size = f.stat().st_size
        except OSError:
            size = 0
        keys.append({"name": name, "kind": kind, "size": size, "path": str(f)})
    return {"ok": True, "count": len(keys), "keys": keys}


def ssh_add_to_agent(key_path: str) -> Dict[str, Any]:
    if not _which("ssh-add"):
        return _not_installed("ssh-add")
    if not key_path:
        return {"ok": False, "error": "key_path required"}
    p = Path(key_path).expanduser()
    if not p.exists():
        return {"ok": False, "error": "key file not found"}
    r = _run(["ssh-add", str(p)])
    return {
        "ok": r["ok"],
        "audit": f"ssh-add {p.name}",
        "stderr": r.get("stderr", ""),
        "risk": "MEDIUM",
    }


def ssh_authorized_keys() -> Dict[str, Any]:
    p = Path.home() / ".ssh" / "authorized_keys"
    if not p.exists():
        return {"ok": True, "keys": [], "note": "no authorized_keys file"}
    try:
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as e:
        return {"ok": False, "error": f"read failed: {e}"}
    keys = []
    for ln in lines:
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        parts = ln.split()
        if len(parts) >= 2:
            keys.append(
                {
                    "type": parts[0],
                    "fingerprint_prefix": _mask(parts[1]),
                    "comment": " ".join(parts[2:]) if len(parts) > 2 else "",
                }
            )
    return {"ok": True, "count": len(keys), "keys": keys}


# ---------------------------------------------------------------------------
# Local Fernet vault
# ---------------------------------------------------------------------------


def vault_set(key: str, value: str, vault_password: str) -> Dict[str, Any]:
    if not key or value is None or not vault_password:
        return {"ok": False, "error": "key, value, vault_password required"}
    loaded = _load_vault(vault_password)
    if not loaded["ok"] and not loaded.get("new"):
        return loaded
    data = loaded.get("data", {})
    data[key] = value
    saved = _save_vault(data, vault_password)
    if not saved["ok"]:
        return saved
    return {"ok": True, "key": key, "audit": f"vault_set {key}={_mask(value)}"}


def vault_get(key: str, vault_password: str) -> Dict[str, Any]:
    if not key or not vault_password:
        return {"ok": False, "error": "key and vault_password required"}
    loaded = _load_vault(vault_password)
    if not loaded["ok"]:
        return loaded
    data = loaded.get("data", {})
    if key not in data:
        return {"ok": False, "error": "key not found"}
    val = data[key]
    return {"ok": True, "key": key, "value": val, "audit": _mask(val)}


def vault_list(vault_password: str) -> Dict[str, Any]:
    if not vault_password:
        return {"ok": False, "error": "vault_password required"}
    loaded = _load_vault(vault_password)
    if not loaded["ok"]:
        return loaded
    data = loaded.get("data", {})
    # Hide internal TOTP namespace details from caller-visible key list by stripping prefix.
    keys = sorted(data.keys())
    return {"ok": True, "count": len(keys), "keys": keys}


def vault_delete(key: str, vault_password: str) -> Dict[str, Any]:
    if not key or not vault_password:
        return {"ok": False, "error": "key and vault_password required"}
    loaded = _load_vault(vault_password)
    if not loaded["ok"]:
        return loaded
    data = loaded.get("data", {})
    if key not in data:
        return {"ok": False, "error": "key not found"}
    del data[key]
    saved = _save_vault(data, vault_password)
    if not saved["ok"]:
        return saved
    return {"ok": True, "key": key, "audit": f"vault_delete {key}", "risk": "HIGH"}


# ---------------------------------------------------------------------------
# TOTP / 2FA
# ---------------------------------------------------------------------------

_TOTP_PREFIX = "__totp__:"


def totp_generate(secret: str) -> Dict[str, Any]:
    if not secret:
        return {"ok": False, "error": "secret required"}
    try:
        import pyotp  # type: ignore
    except ImportError:
        return {"ok": False, "error": "pyotp not installed"}
    try:
        totp = pyotp.TOTP(secret.replace(" ", "").upper())
        code = totp.now()
        return {"ok": True, "code": code, "remaining_seconds": totp.interval - (int(__import__("time").time()) % totp.interval)}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"totp failed: {type(e).__name__}"}


def totp_save(name: str, secret: str, vault_password: Optional[str] = None) -> Dict[str, Any]:
    if not name or not secret:
        return {"ok": False, "error": "name and secret required"}
    if not vault_password:
        return {"ok": False, "error": "vault_password required to store TOTP secret"}
    return vault_set(_TOTP_PREFIX + name, secret.replace(" ", "").upper(), vault_password)


def totp_get_code(name: str, vault_password: str) -> Dict[str, Any]:
    if not name or not vault_password:
        return {"ok": False, "error": "name and vault_password required"}
    loaded = vault_get(_TOTP_PREFIX + name, vault_password)
    if not loaded["ok"]:
        return {"ok": False, "error": "TOTP secret not found"}
    gen = totp_generate(loaded["value"])
    if not gen["ok"]:
        return gen
    return {"ok": True, "name": name, "code": gen["code"], "remaining_seconds": gen.get("remaining_seconds")}


def totp_list(vault_password: str) -> Dict[str, Any]:
    if not vault_password:
        return {"ok": False, "error": "vault_password required"}
    listed = vault_list(vault_password)
    if not listed["ok"]:
        return listed
    names = [k[len(_TOTP_PREFIX):] for k in listed["keys"] if k.startswith(_TOTP_PREFIX)]
    return {"ok": True, "count": len(names), "names": sorted(names)}


# ---------------------------------------------------------------------------
# Random password / passphrase
# ---------------------------------------------------------------------------


def generate_random_password(length: int = 20, charset: str = "alphanumeric_symbols") -> Dict[str, Any]:
    try:
        length = max(4, int(length))
    except (TypeError, ValueError):
        return {"ok": False, "error": "length must be int"}
    if charset == "alphanumeric":
        alphabet = string.ascii_letters + string.digits
    elif charset == "alphanumeric_symbols":
        alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+[]{};:,.<>?"
    elif charset == "letters":
        alphabet = string.ascii_letters
    elif charset == "digits":
        alphabet = string.digits
    elif charset == "hex":
        alphabet = string.hexdigits.lower()[:16]
    else:
        return {"ok": False, "error": f"unknown charset '{charset}'"}
    pw = "".join(_pysecrets.choice(alphabet) for _ in range(length))
    return {"ok": True, "password": pw, "audit": _mask(pw), "length": length, "charset": charset}


def generate_passphrase(words: int = 5) -> Dict[str, Any]:
    try:
        words = max(2, int(words))
    except (TypeError, ValueError):
        return {"ok": False, "error": "words must be int"}
    chosen = [_pysecrets.choice(_DICEWARE_WORDS) for _ in range(words)]
    phrase = "-".join(chosen)
    return {"ok": True, "passphrase": phrase, "audit": _mask(phrase), "words": words}


# ---------------------------------------------------------------------------
# EXTRA_TOOLS registry
# ---------------------------------------------------------------------------

EXTRA_TOOLS: Dict[str, Any] = {
    # Bitwarden
    "secrets.bw_status": bw_status,
    "secrets.bw_unlock": bw_unlock,
    "secrets.bw_lock": bw_lock,
    "secrets.bw_list": bw_list,
    "secrets.bw_get_password": bw_get_password,
    "secrets.bw_get_username": bw_get_username,
    "secrets.bw_generate_password": bw_generate_password,
    "secrets.bw_create_item": bw_create_item,
    # 1Password
    "secrets.op_signin_status": op_signin_status,
    "secrets.op_list_items": op_list_items,
    "secrets.op_get_field": op_get_field,
    "secrets.op_get_password": op_get_password,
    "secrets.op_create_login": op_create_login,
    # GPG
    "secrets.gpg_encrypt": gpg_encrypt,
    "secrets.gpg_decrypt": gpg_decrypt,
    "secrets.gpg_list_keys": gpg_list_keys,
    "secrets.gpg_sign": gpg_sign,
    "secrets.gpg_verify": gpg_verify,
    # SSH
    "secrets.ssh_list_keys": ssh_list_keys,
    "secrets.ssh_add_to_agent": ssh_add_to_agent,
    "secrets.ssh_authorized_keys": ssh_authorized_keys,
    # Local vault
    "secrets.vault_set": vault_set,
    "secrets.vault_get": vault_get,
    "secrets.vault_list": vault_list,
    "secrets.vault_delete": vault_delete,
    # TOTP
    "secrets.totp_generate": totp_generate,
    "secrets.totp_save": totp_save,
    "secrets.totp_get_code": totp_get_code,
    "secrets.totp_list": totp_list,
    # Random
    "secrets.generate_random_password": generate_random_password,
    "secrets.generate_passphrase": generate_passphrase,
}


# ── Adapter ─────────────────────────────────────────────────────────────
# brain.integrations tools are dispatched as `fn(args_dict) -> dict`. Some
# tools in this module were authored with kwarg signatures
# (`def tool(name, value)`) instead of `def tool(args: dict)`. This wrapper
# makes both styles work: it calls the dict form first, and on a signature
# mismatch retries with kwargs. Every tool returns a dict and never raises.
def _adapt(fn):
    _fname = getattr(fn, "__name__", "tool")

    def _wrapped(args=None):
        a = args if isinstance(args, dict) else {}
        try:
            r = fn(a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            if f"{_fname}()" not in str(e):
                return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        try:
            r = fn(**a)
            return r if isinstance(r, dict) else {"ok": True, "result": r}
        except TypeError as e:
            return {"ok": False, "error": f"bad args for {_fname}: {e}"}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    _wrapped.__name__ = _fname
    _wrapped.__doc__ = getattr(fn, "__doc__", None)
    return _wrapped


EXTRA_TOOLS = {k: _adapt(v) for k, v in EXTRA_TOOLS.items()}
