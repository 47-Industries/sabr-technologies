#!/usr/bin/env python3
"""Leon's hands on Dean's Tesla ("Phantom", 2020 Model 3).

Everything goes through the local tesla-http-proxy (systemd: tesla-http-proxy.service,
https://127.0.0.1:4443) which signs commands with Leon's Fleet API private key.
Commands the Vehicle Command Protocol doesn't cover are passed through as REST.

Usage:
  tesla_ctl.py status
  tesla_ctl.py where
  tesla_ctl.py navigate "<address or place>"      # sends destination to the car's nav
  tesla_ctl.py navigate-gps <lat> <lon>
  tesla_ctl.py wake | flash | honk | lock | unlock
  tesla_ctl.py climate on|off
  tesla_ctl.py temp <celsius>
  tesla_ctl.py charge-limit <percent>
  tesla_ctl.py raw <command_name> '<json body>'   # any Fleet API command
"""
from __future__ import annotations
import json, os, sys, time, urllib.request, ssl

SECURE = "/opt/leon-brain/secure"
TOKENS = os.path.join(SECURE, "tesla_user_tokens.json")
PROXY = "https://127.0.0.1:4443"
PROXY_CA = os.path.join(SECURE, "tesla_proxy.crt")
FLEET = "https://fleet-api.prd.na.vn.cloud.tesla.com"


def _secure_vin() -> str:
    """The owner's VIN lives in secure/ (never shipped), not in source.
    2026-09-02: the default used to be hard-coded here, which put the owner's
    car in every customer tarball. Resolution order: TESLA_VIN env, then
    secure/tesla_vehicle.json {"vin": ...}, else empty (no car configured)."""
    v = os.environ.get("TESLA_VIN", "").strip()
    if v:
        return v
    try:
        with open(os.path.join(SECURE, "tesla_vehicle.json")) as f:
            return str(json.load(f).get("vin", "")).strip()
    except Exception:
        return ""


VIN = _secure_vin()

_ctx = ssl.create_default_context(cafile=PROXY_CA)


def _token() -> str:
    with open(TOKENS) as fh:
        return json.load(fh)["access_token"]


def _call(base: str, path: str, method: str = "GET", body: dict | None = None, timeout: int = 45) -> dict:
    data = json.dumps(body or {}).encode() if method == "POST" else None
    req = urllib.request.Request(base + path, data=data, method=method, headers={
        "Authorization": f"Bearer {_token()}",
        "Content-Type": "application/json",
    })
    ctx = _ctx if base == PROXY else None
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read())
        except Exception:
            return {"error": f"HTTP {e.code}"}


def command(name: str, body: dict | None = None) -> dict:
    return _call(PROXY, f"/api/1/vehicles/{VIN}/command/{name}", "POST", body or {})


def wake() -> dict:
    r = _call(FLEET, f"/api/1/vehicles/{VIN}/wake_up", "POST", {})
    for _ in range(12):
        if (r.get("response") or {}).get("state") == "online":
            return r
        time.sleep(3)
        r = _call(FLEET, f"/api/1/vehicles/{VIN}", "GET")
    return r


def data(endpoints: str = "drive_state;vehicle_state;charge_state;climate_state") -> dict:
    return _call(FLEET, f"/api/1/vehicles/{VIN}/vehicle_data?endpoints=" + urllib.parse.quote(endpoints), "GET")


def rest_command(name: str, body: dict | None = None) -> dict:
    """Commands the signing proxy REFUSES. Measured 2026-08-30 23:28 with
    two people sitting in the car: navigation_request through the proxy
    -> HTTP 400 {"error":"command requires using the REST API"}; the same
    body straight at Fleet API -> 200 {"result":true}. Navigation is not a
    signed vehicle command, it is a plain REST call. Route it there."""
    return _call(FLEET, f"/api/1/vehicles/{VIN}/command/{name}", "POST", body or {})


def navigate(text: str, locale: str = "en-US") -> dict:
    # Tesla's "share to vehicle" — the car geocodes the text itself.
    return rest_command("navigation_request", {
        "type": "share_ext_content_raw",
        "locale": locale,
        "timestamp_ms": str(int(time.time() * 1000)),
        "value": {"android.intent.extra.TEXT": text},
    })


def navigate_gps(lat: float, lon: float, order: int = 0) -> dict:
    return rest_command("navigation_gps_request", {"lat": lat, "lon": lon, "order": order})


def status_text() -> str:
    d = data()
    r = d.get("response") or {}
    if not r:
        return "vehicle data unavailable: " + json.dumps(d)[:300]
    ds, vs, cs, cl = (r.get(k) or {} for k in ("drive_state", "vehicle_state", "charge_state", "climate_state"))
    shift = ds.get("shift_state") or "P"
    speed = ds.get("speed")
    parts = [
        f"{r.get('display_name','Phantom')}: {r.get('state')}",
        f"gear {shift}" + (f", {speed} mph" if speed else ""),
        f"battery {cs.get('battery_level')}% ({cs.get('battery_range')} mi)",
        f"charging {cs.get('charging_state')}",
        "locked" if vs.get("locked") else "UNLOCKED",
        "someone inside" if vs.get("is_user_present") else "empty",
        f"cabin {cl.get('inside_temp')}C" if cl.get("inside_temp") is not None else "",
        f"climate {'on' if cl.get('is_climate_on') else 'off'}",
    ]
    if ds.get("latitude") is not None:
        parts.append(f"at {ds['latitude']:.5f},{ds['longitude']:.5f} heading {ds.get('heading')}")
    if ds.get("active_route_destination"):
        parts.append(f"navigating to {ds['active_route_destination']} ({ds.get('active_route_miles_to_arrival')} mi, {ds.get('active_route_minutes_to_arrival')} min)")
    return " | ".join(p for p in parts if p)


def main(argv: list[str]) -> int:
    import urllib.parse  # noqa
    if not argv:
        print(__doc__); return 2
    cmd, args = argv[0], argv[1:]
    out: dict | str
    if cmd == "status":
        out = status_text()
    elif cmd == "where":
        r = (data("drive_state").get("response") or {}).get("drive_state") or {}
        out = r
    elif cmd == "wake":
        out = wake()
    elif cmd == "navigate":
        out = navigate(" ".join(args))
    elif cmd == "navigate-gps":
        out = navigate_gps(float(args[0]), float(args[1]))
    elif cmd == "flash":
        out = command("flash_lights")
    elif cmd == "honk":
        out = command("honk_horn")
    elif cmd == "lock":
        out = command("door_lock")
    elif cmd == "unlock":
        out = command("door_unlock")
    elif cmd == "climate":
        out = command("auto_conditioning_start" if args and args[0] == "on" else "auto_conditioning_stop")
    elif cmd == "temp":
        c = float(args[0]); out = command("set_temps", {"driver_temp": c, "passenger_temp": c})
    elif cmd == "charge-limit":
        out = command("set_charge_limit", {"percent": int(args[0])})
    elif cmd == "raw":
        out = command(args[0], json.loads(args[1]) if len(args) > 1 else {})
    else:
        print(__doc__); return 2
    print(out if isinstance(out, str) else json.dumps(out, indent=1))
    return 0


if __name__ == "__main__":
    import urllib.parse
    sys.exit(main(sys.argv[1:]))
