"""
life.py — Leon's daily-life utility tool surface.

This module gives Leon the ability to answer the small, practical, "what's
the weather of life right now?" questions: flight status, gas prices, EV
chargers, air quality, UV index, pollen, sunrise/sunset, currency
conversion, restaurants & places, transit & traffic, sports scores,
lottery results, calorie/nutrition lookups, plus a handful of local
random-string helpers (passwords, UUIDs, usernames).

The design philosophy mirrors `brain/memory_extras.py`:

  - One function per tool, taking a single `args` dict.
  - Every function returns `{"ok": True, "result": ...}` or
    `{"ok": False, "error": "..."}` — never raises out.
  - Credentials are read lazily from env on each call, so Leon can pick up
    a new key the moment Dean sets it without a restart.
  - Network calls go through `_get` / `_post` helpers with a 10s timeout
    so a slow third-party doesn't wedge the responder thread.
  - We prefer FREE, no-key public APIs (Open-Meteo, OpenAQ, Frankfurter,
    Nominatim, Open Charge Map, ESPN, Open Food Facts, OpenSky,
    sunrise-sunset.org) and only require API keys for the ones that
    truly need them (AviationStack, OpenRouteService, Edamam).

EXTRA_TOOLS at the bottom maps dotted names like `life.air_quality` to
the implementing function — import that dict from the responder / MCP
server to register everything in one shot.
"""

from __future__ import annotations

import os
import secrets
import string
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 10
_USER_AGENT = os.environ.get(
    "LEON_HTTP_CONTACT",
    "Leon/1.0 (Leon; Sabr; contact: support@sabrtechnologies.com)")


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
    if extra:
        h.update(extra)
    return h


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None,
         timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """GET with uniform error envelope. Returns {ok, status, json|text} or {ok:False, error}."""
    try:
        r = requests.get(url, params=params, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _post(url: str, json_body: Optional[dict] = None, headers: Optional[dict] = None,
          timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    try:
        r = requests.post(url, json=json_body, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    try:
        out["json"] = r.json()
    except ValueError:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _env(name: str) -> Optional[str]:
    v = os.environ.get(name)
    return v.strip() if v and v.strip() else None


def _require_arg(args: dict, key: str) -> Any:
    """Return args[key] or raise KeyError — caller wraps in try/except."""
    if key not in args or args[key] in (None, ""):
        raise KeyError(key)
    return args[key]


# ──────────────────────────────────────────────────────────────────────────
# FLIGHTS
# ──────────────────────────────────────────────────────────────────────────


def flight_status(args: dict) -> dict:
    """Status of a single flight by IATA code. AviationStack if key set, else OpenSky."""
    try:
        code = str(_require_arg(args, "flight_iata")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "flight_iata is required"}

    key = _env("AVIATIONSTACK_API_KEY")
    if key:
        resp = _get(
            "http://api.aviationstack.com/v1/flights",
            params={"access_key": key, "flight_iata": code, "limit": 1},
        )
        if not resp.get("ok"):
            return {"ok": False, "error": resp.get("error", "aviationstack failed")}
        data = (resp.get("json") or {}).get("data") or []
        if not data:
            return {"ok": False, "error": f"no flight found for {code}"}
        f = data[0]
        return {
            "ok": True,
            "result": {
                "flight": code,
                "status": f.get("flight_status"),
                "departure": f.get("departure", {}),
                "arrival": f.get("arrival", {}),
                "airline": f.get("airline", {}),
                "source": "aviationstack",
            },
        }

    # OpenSky fallback — we can only match by callsign substring.
    resp = _get("https://opensky-network.org/api/states/all")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "opensky failed")}
    states = (resp.get("json") or {}).get("states") or []
    matches = [s for s in states if s and s[1] and code in s[1].strip().upper()]
    if not matches:
        return {"ok": False, "error": f"no live OpenSky state for {code} (set AVIATIONSTACK_API_KEY for richer data)"}
    s = matches[0]
    return {
        "ok": True,
        "result": {
            "flight": code,
            "callsign": (s[1] or "").strip(),
            "origin_country": s[2],
            "longitude": s[5],
            "latitude": s[6],
            "altitude_m": s[7],
            "velocity_ms": s[9],
            "on_ground": s[8],
            "source": "opensky",
        },
    }


def flights_near(args: dict) -> dict:
    """Live flights within `radius_km` of (lat, lon) via OpenSky free API."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}
    radius_km = float(args.get("radius_km", 50))

    # Rough bounding box: 1deg lat ≈ 111km.
    dlat = radius_km / 111.0
    dlon = radius_km / max(1.0, 111.0 * abs((1.0 - (lat / 90.0) ** 2) ** 0.5))
    params = {
        "lamin": lat - dlat, "lamax": lat + dlat,
        "lomin": lon - dlon, "lomax": lon + dlon,
    }
    resp = _get("https://opensky-network.org/api/states/all", params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "opensky failed")}
    states = (resp.get("json") or {}).get("states") or []
    flights = []
    for s in states:
        if not s:
            continue
        flights.append({
            "icao24": s[0],
            "callsign": (s[1] or "").strip(),
            "origin_country": s[2],
            "longitude": s[5],
            "latitude": s[6],
            "altitude_m": s[7],
            "on_ground": s[8],
            "velocity_ms": s[9],
        })
    return {"ok": True, "result": {"count": len(flights), "flights": flights[:50]}}


def flights_arrivals(args: dict) -> dict:
    """Recent arrivals at an airport in the last `hours` hours via OpenSky."""
    try:
        airport = str(_require_arg(args, "airport_iata")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "airport_iata is required"}
    hours = int(args.get("hours", 2))

    # AviationStack first if key present (handles IATA directly).
    key = _env("AVIATIONSTACK_API_KEY")
    if key:
        resp = _get(
            "http://api.aviationstack.com/v1/flights",
            params={"access_key": key, "arr_iata": airport, "limit": 25},
        )
        if resp.get("ok"):
            data = (resp.get("json") or {}).get("data") or []
            return {"ok": True, "result": {"airport": airport, "count": len(data),
                                           "flights": data, "source": "aviationstack"}}

    # OpenSky requires ICAO (4-letter) for arrivals; we attempt best-effort
    # by treating IATA "KAUS" style or letting the caller pass ICAO.
    now = int(time.time())
    begin = now - hours * 3600
    resp = _get(
        "https://opensky-network.org/api/flights/arrival",
        params={"airport": airport, "begin": begin, "end": now},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error",
                "opensky failed — OpenSky needs ICAO (e.g. KAUS); set AVIATIONSTACK_API_KEY for IATA")}
    arrivals = resp.get("json") or []
    return {"ok": True, "result": {"airport": airport, "count": len(arrivals),
                                   "flights": arrivals[:25], "source": "opensky"}}


# ──────────────────────────────────────────────────────────────────────────
# GAS & EV CHARGING
# ──────────────────────────────────────────────────────────────────────────


def gas_prices(args: dict) -> dict:
    """Best-effort gas-price lookup. No clean free API exists; returns helpful error."""
    zip_code = args.get("zip_code")
    lat = args.get("lat")
    lon = args.get("lon")
    if not (zip_code or (lat is not None and lon is not None)):
        return {"ok": False, "error": "provide zip_code or (lat, lon)"}

    # GasBuddy has no public free API. The U.S. EIA gives national averages
    # but not per-zip. We surface the EIA weekly retail price as a fallback
    # so Leon has *something* useful to say instead of nothing.
    resp = _get(
        "https://api.eia.gov/v2/petroleum/pri/gnd/data/",
        params={
            "api_key": _env("EIA_API_KEY") or "DEMO_KEY",
            "frequency": "weekly",
            "data[0]": "value",
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "length": 1,
        },
    )
    if resp.get("ok"):
        data = ((resp.get("json") or {}).get("response") or {}).get("data") or []
        if data:
            row = data[0]
            return {"ok": True, "result": {
                "scope": "US national average (no per-zip free source)",
                "period": row.get("period"),
                "price_usd_per_gallon": row.get("value"),
                "series": row.get("series-description"),
                "source": "EIA",
                "note": "set EIA_API_KEY for higher rate limit; per-zip pricing requires a paid GasBuddy/MyGasFeed key",
            }}
    return {"ok": False, "error": "no free per-zip gas-price API available; try OPIS or GasBuddy (paid)"}


def ev_charging_stations(args: dict) -> dict:
    """EV chargers near (lat, lon) via Open Charge Map free API."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}
    radius_miles = float(args.get("radius_miles", 10))

    params = {
        "output": "json",
        "latitude": lat,
        "longitude": lon,
        "distance": radius_miles,
        "distanceunit": "Miles",
        "maxresults": 25,
        "compact": "true",
        "verbose": "false",
    }
    ocm_key = _env("OPENCHARGEMAP_API_KEY")
    if ocm_key:
        params["key"] = ocm_key
    resp = _get("https://api.openchargemap.io/v3/poi", params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "openchargemap failed")}
    pois = resp.get("json") or []
    stations = []
    for p in pois:
        ai = p.get("AddressInfo") or {}
        stations.append({
            "id": p.get("ID"),
            "title": ai.get("Title"),
            "address": ai.get("AddressLine1"),
            "town": ai.get("Town"),
            "state": ai.get("StateOrProvince"),
            "distance_miles": ai.get("Distance"),
            "latitude": ai.get("Latitude"),
            "longitude": ai.get("Longitude"),
            "num_connections": len(p.get("Connections") or []),
        })
    return {"ok": True, "result": {"count": len(stations), "stations": stations}}


# ──────────────────────────────────────────────────────────────────────────
# AIR QUALITY & ENVIRONMENT
# ──────────────────────────────────────────────────────────────────────────


def air_quality(args: dict) -> dict:
    """Latest air-quality readings via OpenAQ free API (by city or lat/lon)."""
    city = args.get("city")
    lat = args.get("lat")
    lon = args.get("lon")
    if not city and (lat is None or lon is None):
        return {"ok": False, "error": "provide city or (lat, lon)"}

    params: Dict[str, Any] = {"limit": 10, "order_by": "datetime", "sort": "desc"}
    if city:
        params["city"] = city
    else:
        params["coordinates"] = f"{lat},{lon}"
        params["radius"] = 25000  # 25km
    headers = {}
    oaq_key = _env("OPENAQ_API_KEY")
    if oaq_key:
        headers["X-API-Key"] = oaq_key

    resp = _get("https://api.openaq.org/v2/latest", params=params, headers=headers)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "openaq failed")}
    data = (resp.get("json") or {}).get("results") or []
    readings = []
    for r in data:
        for m in r.get("measurements", []):
            readings.append({
                "location": r.get("location"),
                "city": r.get("city"),
                "country": r.get("country"),
                "parameter": m.get("parameter"),
                "value": m.get("value"),
                "unit": m.get("unit"),
                "last_updated": m.get("lastUpdated"),
            })
    return {"ok": True, "result": {"count": len(readings), "readings": readings[:25]}}


def uv_index(args: dict) -> dict:
    """Current UV index at (lat, lon) via Open-Meteo (free, no key)."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}

    resp = _get(
        "https://api.open-meteo.com/v1/forecast",
        params={"latitude": lat, "longitude": lon,
                "current": "uv_index,uv_index_clear_sky",
                "daily": "uv_index_max", "timezone": "auto"},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "open-meteo failed")}
    j = resp.get("json") or {}
    cur = j.get("current") or {}
    daily = j.get("daily") or {}
    return {"ok": True, "result": {
        "uv_index": cur.get("uv_index"),
        "uv_clear_sky": cur.get("uv_index_clear_sky"),
        "uv_max_today": (daily.get("uv_index_max") or [None])[0],
        "time": cur.get("time"),
    }}


def pollen_count(args: dict) -> dict:
    """Pollen levels at (lat, lon) via Open-Meteo air-quality endpoint."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}

    resp = _get(
        "https://air-quality-api.open-meteo.com/v1/air-quality",
        params={"latitude": lat, "longitude": lon,
                "current": "alder_pollen,birch_pollen,grass_pollen,mugwort_pollen,olive_pollen,ragweed_pollen",
                "timezone": "auto"},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "open-meteo air-quality failed")}
    cur = (resp.get("json") or {}).get("current") or {}
    return {"ok": True, "result": {
        "alder": cur.get("alder_pollen"),
        "birch": cur.get("birch_pollen"),
        "grass": cur.get("grass_pollen"),
        "mugwort": cur.get("mugwort_pollen"),
        "olive": cur.get("olive_pollen"),
        "ragweed": cur.get("ragweed_pollen"),
        "time": cur.get("time"),
        "unit": "grains/m³",
    }}


def sunset_sunrise(args: dict) -> dict:
    """Sunrise / sunset times at (lat, lon) for `date` (YYYY-MM-DD or 'today')."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}
    date = args.get("date") or "today"

    resp = _get(
        "https://api.sunrise-sunset.org/json",
        params={"lat": lat, "lng": lon, "date": date, "formatted": 0},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "sunrise-sunset failed")}
    j = resp.get("json") or {}
    if j.get("status") != "OK":
        return {"ok": False, "error": f"sunrise-sunset status: {j.get('status')}"}
    return {"ok": True, "result": j.get("results", {})}


# ──────────────────────────────────────────────────────────────────────────
# CURRENCY
# ──────────────────────────────────────────────────────────────────────────


def currency_convert(args: dict) -> dict:
    """Convert `amount` from one currency to another via Frankfurter (free, no key)."""
    try:
        amount = float(_require_arg(args, "amount"))
        frm = str(_require_arg(args, "from_currency")).upper()
        to = str(_require_arg(args, "to_currency")).upper()
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "amount, from_currency, to_currency are required"}

    resp = _get("https://api.frankfurter.app/latest",
                params={"amount": amount, "from": frm, "to": to})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "frankfurter failed")}
    j = resp.get("json") or {}
    rates = j.get("rates") or {}
    if to not in rates:
        return {"ok": False, "error": f"no rate returned for {to}"}
    return {"ok": True, "result": {
        "amount": amount, "from": frm, "to": to,
        "converted": rates[to], "rate": rates[to] / amount if amount else None,
        "date": j.get("date"),
    }}


def currency_historical(args: dict) -> dict:
    """Historical exchange rate on `date` (YYYY-MM-DD) via Frankfurter."""
    try:
        date = str(_require_arg(args, "date"))
        frm = str(_require_arg(args, "from_currency")).upper()
        to = str(_require_arg(args, "to_currency")).upper()
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "date, from_currency, to_currency are required"}

    resp = _get(f"https://api.frankfurter.app/{date}",
                params={"from": frm, "to": to})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "frankfurter failed")}
    j = resp.get("json") or {}
    return {"ok": True, "result": {
        "date": j.get("date"), "from": frm, "to": to,
        "rate": (j.get("rates") or {}).get(to),
    }}


def currency_list_rates(args: dict) -> dict:
    """All exchange rates relative to `base` (default USD) via Frankfurter."""
    base = str(args.get("base", "USD")).upper()
    resp = _get("https://api.frankfurter.app/latest", params={"from": base})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "frankfurter failed")}
    j = resp.get("json") or {}
    return {"ok": True, "result": {
        "base": j.get("base", base),
        "date": j.get("date"),
        "rates": j.get("rates", {}),
    }}


# ──────────────────────────────────────────────────────────────────────────
# RESTAURANTS / PLACES (Nominatim + Overpass)
# ──────────────────────────────────────────────────────────────────────────


def _nominatim_get(path: str, params: dict) -> Dict[str, Any]:
    return _get(f"https://nominatim.openstreetmap.org/{path}",
                params=params, headers={"Accept-Language": "en"})


def places_search(args: dict) -> dict:
    """Search OSM places matching `query` near (lat, lon)."""
    try:
        query = str(_require_arg(args, "query"))
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "query, lat, lon are required"}
    radius_m = int(args.get("radius_m", 2000))

    # Nominatim viewbox = a bounding box around the point.
    dlat = radius_m / 111000.0
    dlon = radius_m / 85000.0  # rough mid-latitude
    viewbox = f"{lon - dlon},{lat + dlat},{lon + dlon},{lat - dlat}"
    resp = _nominatim_get("search", {
        "q": query, "format": "json", "limit": 15,
        "viewbox": viewbox, "bounded": 1, "addressdetails": 1,
    })
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "nominatim failed")}
    j = resp.get("json") or []
    places = [{
        "name": p.get("display_name"),
        "type": p.get("type"),
        "category": p.get("class"),
        "lat": float(p["lat"]) if p.get("lat") else None,
        "lon": float(p["lon"]) if p.get("lon") else None,
        "address": p.get("address", {}),
    } for p in j]
    return {"ok": True, "result": {"count": len(places), "places": places}}


def geocode(args: dict) -> dict:
    """Convert an address string → (lat, lon) via Nominatim."""
    try:
        address = str(_require_arg(args, "address"))
    except KeyError:
        return {"ok": False, "error": "address is required"}
    resp = _nominatim_get("search",
                          {"q": address, "format": "json", "limit": 1, "addressdetails": 1})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "nominatim failed")}
    j = resp.get("json") or []
    if not j:
        return {"ok": False, "error": f"no match for: {address}"}
    p = j[0]
    return {"ok": True, "result": {
        "display_name": p.get("display_name"),
        "lat": float(p["lat"]), "lon": float(p["lon"]),
        "address": p.get("address", {}),
        "osm_type": p.get("osm_type"), "osm_id": p.get("osm_id"),
    }}


def reverse_geocode(args: dict) -> dict:
    """Convert (lat, lon) → address via Nominatim."""
    try:
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "lat and lon are required (floats)"}
    resp = _nominatim_get("reverse",
                          {"lat": lat, "lon": lon, "format": "json", "addressdetails": 1})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "nominatim failed")}
    j = resp.get("json") or {}
    return {"ok": True, "result": {
        "display_name": j.get("display_name"),
        "address": j.get("address", {}),
    }}


def business_hours(args: dict) -> dict:
    """Best-effort opening hours via Overpass (OSM `opening_hours` tag)."""
    try:
        name = str(_require_arg(args, "name"))
        lat = float(_require_arg(args, "lat"))
        lon = float(_require_arg(args, "lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "name, lat, lon are required"}

    # 1km radius around the point, matching name case-insensitively.
    q = (
        f'[out:json][timeout:10];'
        f'(node["name"~"{name}",i](around:1000,{lat},{lon});'
        f' way["name"~"{name}",i](around:1000,{lat},{lon}););'
        f'out tags 5;'
    )
    try:
        r = requests.post("https://overpass-api.de/api/interpreter",
                          data={"data": q},
                          headers={"User-Agent": _USER_AGENT},
                          timeout=_DEFAULT_TIMEOUT)
    except requests.RequestException as e:
        return {"ok": False, "error": f"overpass network error: {e}"}
    if not r.ok:
        return {"ok": False, "error": f"overpass HTTP {r.status_code}"}
    try:
        elements = r.json().get("elements", [])
    except ValueError:
        return {"ok": False, "error": "overpass returned non-JSON"}
    if not elements:
        return {"ok": False, "error": f"no OSM match for {name} near point"}
    hits = []
    for el in elements:
        tags = el.get("tags") or {}
        hits.append({
            "name": tags.get("name"),
            "opening_hours": tags.get("opening_hours"),
            "phone": tags.get("phone"),
            "website": tags.get("website"),
            "amenity": tags.get("amenity"),
            "cuisine": tags.get("cuisine"),
        })
    return {"ok": True, "result": {"count": len(hits), "matches": hits}}


# ──────────────────────────────────────────────────────────────────────────
# TRANSIT & TRAFFIC (OpenRouteService)
# ──────────────────────────────────────────────────────────────────────────


_ORS_PROFILES = {
    "transit": "foot-walking",  # ORS free tier has no transit; fall back to walking
    "driving": "driving-car",
    "walking": "foot-walking",
    "cycling": "cycling-regular",
}


def _ors_directions(from_lat: float, from_lon: float,
                    to_lat: float, to_lon: float, profile: str) -> Dict[str, Any]:
    key = _env("OPENROUTESERVICE_API_KEY")
    if not key:
        return {"ok": False, "error": "OPENROUTESERVICE_API_KEY not set"}
    body = {"coordinates": [[from_lon, from_lat], [to_lon, to_lat]]}
    headers = {"Authorization": key, "Content-Type": "application/json"}
    return _post(f"https://api.openrouteservice.org/v2/directions/{profile}",
                 json_body=body, headers=headers)


def transit_routes(args: dict) -> dict:
    """Route from A→B via OpenRouteService. `mode` ∈ {transit,driving,walking,cycling}."""
    try:
        fl = float(_require_arg(args, "from_lat"))
        fo = float(_require_arg(args, "from_lon"))
        tl = float(_require_arg(args, "to_lat"))
        to = float(_require_arg(args, "to_lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "from_lat, from_lon, to_lat, to_lon are required"}
    mode = str(args.get("mode", "transit")).lower()
    profile = _ORS_PROFILES.get(mode, "foot-walking")
    resp = _ors_directions(fl, fo, tl, to, profile)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "ORS failed")}
    routes = ((resp.get("json") or {}).get("routes") or [])
    if not routes:
        return {"ok": False, "error": "no route returned"}
    r0 = routes[0]
    summ = r0.get("summary") or {}
    return {"ok": True, "result": {
        "mode": mode, "profile": profile,
        "distance_m": summ.get("distance"),
        "duration_s": summ.get("duration"),
        "duration_min": round(summ.get("duration", 0) / 60.0, 1),
        "segments": r0.get("segments", []),
    }}


def traffic_estimate(args: dict) -> dict:
    """Driving-time estimate A→B via OpenRouteService (driving-car profile)."""
    try:
        fl = float(_require_arg(args, "from_lat"))
        fo = float(_require_arg(args, "from_lon"))
        tl = float(_require_arg(args, "to_lat"))
        to = float(_require_arg(args, "to_lon"))
    except (KeyError, ValueError, TypeError):
        return {"ok": False, "error": "from_lat, from_lon, to_lat, to_lon are required"}
    resp = _ors_directions(fl, fo, tl, to, "driving-car")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "ORS failed")}
    routes = ((resp.get("json") or {}).get("routes") or [])
    if not routes:
        return {"ok": False, "error": "no driving route returned"}
    summ = routes[0].get("summary") or {}
    return {"ok": True, "result": {
        "distance_km": round(summ.get("distance", 0) / 1000.0, 2),
        "duration_min": round(summ.get("duration", 0) / 60.0, 1),
        "note": "ORS free tier has no live traffic; this is base driving time",
    }}


# ──────────────────────────────────────────────────────────────────────────
# SPORTS (ESPN public)
# ──────────────────────────────────────────────────────────────────────────


_ESPN_SPORTS = {
    "nba": ("basketball", "nba"),
    "wnba": ("basketball", "wnba"),
    "ncaab": ("basketball", "mens-college-basketball"),
    "nfl": ("football", "nfl"),
    "ncaaf": ("football", "college-football"),
    "mlb": ("baseball", "mlb"),
    "nhl": ("hockey", "nhl"),
    "mls": ("soccer", "usa.1"),
    "epl": ("soccer", "eng.1"),
}


def _espn_path(sport: str) -> Optional[str]:
    sport = sport.lower()
    if sport in _ESPN_SPORTS:
        cat, league = _ESPN_SPORTS[sport]
        return f"{cat}/{league}"
    return None


def sports_scores(args: dict) -> dict:
    """Scoreboard for `sport` (nba/nfl/mlb/etc) on `date` (YYYYMMDD optional)."""
    sport = str(args.get("sport", "nba")).lower()
    path = _espn_path(sport)
    if not path:
        return {"ok": False, "error": f"unknown sport: {sport} (try {list(_ESPN_SPORTS)})"}
    params = {}
    date = args.get("date")
    if date:
        params["dates"] = str(date).replace("-", "")
    url = f"https://site.api.espn.com/apis/site/v2/sports/{path}/scoreboard"
    resp = _get(url, params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "espn failed")}
    j = resp.get("json") or {}
    events = j.get("events") or []
    games = []
    for ev in events:
        comp = (ev.get("competitions") or [{}])[0]
        competitors = comp.get("competitors") or []
        teams = []
        for c in competitors:
            teams.append({
                "name": (c.get("team") or {}).get("displayName"),
                "abbreviation": (c.get("team") or {}).get("abbreviation"),
                "score": c.get("score"),
                "home_away": c.get("homeAway"),
                "record": ((c.get("records") or [{}])[0]).get("summary"),
            })
        games.append({
            "name": ev.get("name"),
            "short": ev.get("shortName"),
            "date": ev.get("date"),
            "status": (ev.get("status") or {}).get("type", {}).get("description"),
            "teams": teams,
        })
    return {"ok": True, "result": {"sport": sport, "count": len(games), "games": games}}


def sports_team_record(args: dict) -> dict:
    """Find a team by name and return its record."""
    try:
        team_name = str(_require_arg(args, "team_name"))
    except KeyError:
        return {"ok": False, "error": "team_name is required"}
    sport = str(args.get("sport", "nba")).lower()
    path = _espn_path(sport)
    if not path:
        return {"ok": False, "error": f"unknown sport: {sport}"}

    url = f"https://site.api.espn.com/apis/site/v2/sports/{path}/teams"
    resp = _get(url)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "espn failed")}
    sports = (resp.get("json") or {}).get("sports") or []
    teams_list = []
    for s in sports:
        for l in s.get("leagues", []):
            teams_list.extend(l.get("teams", []))
    q = team_name.lower()
    for t in teams_list:
        team = t.get("team") or {}
        names = [
            (team.get("displayName") or "").lower(),
            (team.get("name") or "").lower(),
            (team.get("nickname") or "").lower(),
            (team.get("location") or "").lower(),
            (team.get("abbreviation") or "").lower(),
        ]
        if any(q in n for n in names if n):
            return {"ok": True, "result": {
                "team": team.get("displayName"),
                "abbreviation": team.get("abbreviation"),
                "record": (team.get("record") or {}),
                "standing": team.get("standingSummary"),
                "id": team.get("id"),
            }}
    return {"ok": False, "error": f"no {sport} team matches {team_name}"}


# ──────────────────────────────────────────────────────────────────────────
# LOTTERY / RANDOM
# ──────────────────────────────────────────────────────────────────────────


def lottery_results(args: dict) -> dict:
    """Best-effort latest results for a US lottery game (powerball / megamillions)."""
    game = str(args.get("game", "powerball")).lower()
    # NY Open Data hosts historical Powerball + Mega Millions feeds for free.
    feeds = {
        "powerball": "https://data.ny.gov/resource/d6yy-54nr.json",
        "megamillions": "https://data.ny.gov/resource/5xaw-6ayf.json",
        "mega-millions": "https://data.ny.gov/resource/5xaw-6ayf.json",
    }
    url = feeds.get(game)
    if not url:
        return {"ok": False, "error": f"game not supported: {game} (try powerball, megamillions)"}
    resp = _get(url, params={"$order": "draw_date DESC", "$limit": 1})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "ny.gov failed")}
    rows = resp.get("json") or []
    if not rows:
        return {"ok": False, "error": "no rows returned"}
    return {"ok": True, "result": rows[0]}


def random_password(args: dict) -> dict:
    """Generate a cryptographically random password."""
    length = int(args.get("length", 20))
    include_symbols = bool(args.get("include_symbols", True))
    if length < 4 or length > 256:
        return {"ok": False, "error": "length must be 4..256"}
    alphabet = string.ascii_letters + string.digits
    if include_symbols:
        alphabet += "!@#$%^&*()-_=+[]{};:,.<>?/"
    pw = "".join(secrets.choice(alphabet) for _ in range(length))
    return {"ok": True, "result": {"password": pw, "length": length,
                                   "include_symbols": include_symbols}}


def random_uuid(args: dict) -> dict:
    """Generate a UUID4."""
    return {"ok": True, "result": {"uuid": str(uuid.uuid4())}}


_ADJECTIVES = [
    "swift", "silent", "cosmic", "neon", "lucid", "feral", "atomic", "crimson",
    "obsidian", "electric", "lunar", "solar", "quantum", "phantom", "iron",
    "velvet", "wild", "ember", "frosted", "hidden", "rogue", "ancient",
    "midnight", "stellar", "molten", "drifting", "rising", "humble", "fierce",
]
_NOUNS = [
    "fox", "raven", "wolf", "ember", "comet", "tide", "drift", "spark",
    "anvil", "pilot", "monk", "warden", "blade", "cipher", "echo", "harbor",
    "lighthouse", "circuit", "atlas", "nomad", "scribe", "hunter", "weaver",
    "voyager", "phoenix", "vector", "signal", "halo", "forge", "river",
]


def random_username(args: dict) -> dict:
    """Generate a fun random username. `adjective_noun=True` → e.g. swift-fox-482."""
    adjective_noun = bool(args.get("adjective_noun", True))
    if adjective_noun:
        adj = secrets.choice(_ADJECTIVES)
        noun = secrets.choice(_NOUNS)
        suffix = secrets.randbelow(900) + 100
        username = f"{adj}-{noun}-{suffix}"
    else:
        alphabet = string.ascii_lowercase + string.digits
        username = "user_" + "".join(secrets.choice(alphabet) for _ in range(8))
    return {"ok": True, "result": {"username": username}}


# ──────────────────────────────────────────────────────────────────────────
# NUTRITION / CALORIES
# ──────────────────────────────────────────────────────────────────────────


def nutrition_lookup(args: dict) -> dict:
    """Look up a food product via Open Food Facts (free, no key)."""
    try:
        food_name = str(_require_arg(args, "food_name"))
    except KeyError:
        return {"ok": False, "error": "food_name is required"}

    resp = _get(
        "https://world.openfoodfacts.org/cgi/search.pl",
        params={"search_terms": food_name, "search_simple": 1,
                "action": "process", "json": 1, "page_size": 5},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "openfoodfacts failed")}
    products = (resp.get("json") or {}).get("products") or []
    if not products:
        return {"ok": False, "error": f"no products found for: {food_name}"}
    out = []
    for p in products[:5]:
        nut = p.get("nutriments") or {}
        out.append({
            "name": p.get("product_name") or p.get("generic_name"),
            "brand": p.get("brands"),
            "serving_size": p.get("serving_size"),
            "energy_kcal_100g": nut.get("energy-kcal_100g"),
            "carbs_100g": nut.get("carbohydrates_100g"),
            "protein_100g": nut.get("proteins_100g"),
            "fat_100g": nut.get("fat_100g"),
            "sugars_100g": nut.get("sugars_100g"),
            "fiber_100g": nut.get("fiber_100g"),
            "salt_100g": nut.get("salt_100g"),
            "nutriscore": p.get("nutriscore_grade"),
            "code": p.get("code"),
        })
    return {"ok": True, "result": {"query": food_name, "count": len(out), "products": out}}


def calorie_estimate(args: dict) -> dict:
    """Calorie estimate for a free-text meal via Edamam (needs APP_ID + APP_KEY)."""
    try:
        meal = str(_require_arg(args, "meal_description"))
    except KeyError:
        return {"ok": False, "error": "meal_description is required"}
    app_id = _env("EDAMAM_APP_ID")
    app_key = _env("EDAMAM_APP_KEY")
    if not (app_id and app_key):
        return {"ok": False,
                "error": "EDAMAM_APP_ID and EDAMAM_APP_KEY required; "
                         "sign up at developer.edamam.com (Nutrition Analysis API)"}

    resp = _post(
        f"https://api.edamam.com/api/nutrition-details?app_id={app_id}&app_key={app_key}",
        json_body={"title": "meal", "ingr": [meal]},
    )
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "edamam failed")}
    j = resp.get("json") or {}
    nutrients = j.get("totalNutrients") or {}
    def _n(key):
        v = nutrients.get(key) or {}
        return {"value": v.get("quantity"), "unit": v.get("unit")}
    return {"ok": True, "result": {
        "meal": meal,
        "calories": j.get("calories"),
        "weight_g": j.get("totalWeight"),
        "diet_labels": j.get("dietLabels"),
        "health_labels": j.get("healthLabels"),
        "protein": _n("PROCNT"),
        "fat": _n("FAT"),
        "carbs": _n("CHOCDF"),
        "fiber": _n("FIBTG"),
        "sugar": _n("SUGAR"),
        "sodium": _n("NA"),
    }}


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted-name registry
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # flights
    "life.flight_status": flight_status,
    "life.flights_near": flights_near,
    "life.flights_arrivals": flights_arrivals,
    # gas & EV
    "life.gas_prices": gas_prices,
    "life.ev_charging_stations": ev_charging_stations,
    # air & environment
    "life.air_quality": air_quality,
    "life.uv_index": uv_index,
    "life.pollen_count": pollen_count,
    "life.sunset_sunrise": sunset_sunrise,
    # currency
    "life.currency_convert": currency_convert,
    "life.currency_historical": currency_historical,
    "life.currency_list_rates": currency_list_rates,
    # places
    "life.places_search": places_search,
    "life.geocode": geocode,
    "life.reverse_geocode": reverse_geocode,
    "life.business_hours": business_hours,
    # transit
    "life.transit_routes": transit_routes,
    "life.traffic_estimate": traffic_estimate,
    # sports
    "life.sports_scores": sports_scores,
    "life.sports_team_record": sports_team_record,
    # lottery & random
    "life.lottery_results": lottery_results,
    "life.random_password": random_password,
    "life.random_uuid": random_uuid,
    "life.random_username": random_username,
    # nutrition
    "life.nutrition_lookup": nutrition_lookup,
    "life.calorie_estimate": calorie_estimate,
}
