"""
security.py — Leon's home / network security tool surface.

This module gives Leon eyes and ears on the *physical and network*
perimeter: RTSP / ONVIF IP-camera feeds, single-frame snapshots, naive
frame-difference motion detection, LAN device discovery + new-device
alerting, pure-socket TCP port scanning, a local SQLite security event
log, account / password breach checks (HaveIBeenPwned + k-anonymity
Pwned Passwords), SSL / DNSSEC checks, and a few local hardening probes
(ufw, failed SSH logins, listening sockets).

Everything shells out via `subprocess` with hard timeouts and degrades
gracefully when a binary is missing — there is no hard dependency on
ffmpeg, nmap or arp; the pure-Python paths still work. Port scanning is
a non-privileged TCP connect scan over `socket`. Camera credentials are
loaded lazily from the environment or `~/.openclaw/secrets.json` so no
secret ever lives in this file. Snapshots and clips land in
`~/Documents/leon-security/`, created on import.

Each tool is a function taking a single `args` dict and returning either
`{"ok": True, ...}` or `{"ok": False, "error": "..."}` — tools never
raise. The EXTRA_TOOLS dict at the bottom maps dotted tool names (e.g.
`security.camera_snapshot`, `security.network_scan`) to the implementing
function — import this dict from the responder / MCP server to register
them in one shot.

Reolink / Wyze quick reference (RTSP URL patterns):
  Reolink main : rtsp://USER:PASS@HOST:554/h264Preview_01_main
  Reolink sub  : rtsp://USER:PASS@HOST:554/h264Preview_01_sub
  Wyze (RTSP fw): rtsp://USER:PASS@HOST/live
"""

from __future__ import annotations

import json
import os
import re
import socket
import sqlite3
import shutil
import ssl
import struct
import subprocess
import time
import hashlib
import urllib.request
import urllib.error
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# PATHS / CONSTANTS
# ──────────────────────────────────────────────────────────────────────────

_HOME = os.path.expanduser("~")
_SNAP_DIR = os.path.join(_HOME, "Documents", "leon-security")
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_STATE_DIR = os.path.join(_PROJECT_ROOT, "brain_state")
_CAMERAS_FILE = os.path.join(_STATE_DIR, "cameras.json")
_BASELINE_FILE = os.path.join(_STATE_DIR, "network_baseline.json")
_EVENTS_DB = os.path.join(_STATE_DIR, "security_events.db")
_SECRETS_FILE = os.path.join(_HOME, ".openclaw", "secrets.json")

# Create the snapshot directory on import (best-effort, never raises).
try:
    os.makedirs(_SNAP_DIR, exist_ok=True)
    os.makedirs(_STATE_DIR, exist_ok=True)
except OSError:
    pass

# Common ports for the connect-scan when ports="common".
_COMMON_PORTS: List[int] = [
    21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 465, 514,
    554, 587, 631, 993, 995, 1433, 1723, 1883, 2049, 3306, 3389, 5060,
    5432, 5555, 5900, 6379, 8000, 8008, 8080, 8081, 8443, 8554, 8888,
    9000, 9090, 9100, 27017, 32400,
]


# ──────────────────────────────────────────────────────────────────────────
# SHELL / IO HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _have(binary: str) -> bool:
    """Return True if `binary` is on PATH."""
    return shutil.which(binary) is not None


def _run(
    cmd: List[str],
    timeout: float = 15.0,
    input_text: Optional[str] = None,
) -> Tuple[int, str, str]:
    """Run `cmd`, return (returncode, stdout, stderr). Never raises on
    non-zero exit; returns rc 127 if the binary is missing, 124 on timeout."""
    try:
        proc = subprocess.run(
            cmd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except FileNotFoundError:
        return 127, "", f"{cmd[0]}: not installed"
    except Exception as e:  # pragma: no cover - defensive
        return 1, "", str(e)


def _missing(binary: str) -> Dict[str, Any]:
    return {"ok": False, "error": f"{binary} not installed"}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _stamp() -> str:
    """Filesystem-safe timestamp for snapshot filenames."""
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def _http_get(
    url: str,
    timeout: float = 8.0,
    headers: Optional[Dict[str, str]] = None,
) -> Tuple[Optional[int], Optional[str]]:
    """GET `url`, return (status_code, body_text). On failure returns
    (None, error_string) so callers can branch cleanly."""
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "Leon-Security/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        return e.code, body
    except (urllib.error.URLError, socket.timeout, ConnectionError) as e:
        return None, str(e)
    except Exception as e:  # pragma: no cover - defensive
        return None, str(e)


def _load_json(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return default


def _save_json(path: str, data: Any) -> bool:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, path)
        return True
    except OSError:
        return False


# ──────────────────────────────────────────────────────────────────────────
# SECRETS / CREDENTIALS (lazy)
# ──────────────────────────────────────────────────────────────────────────


def _secret(key: str) -> Optional[str]:
    """Lazy secret lookup: environment first, then ~/.openclaw/secrets.json.
    Supports nested lookups like 'security.HIBP_API_KEY' via dotted keys
    being flattened, plus a flat top-level match."""
    env = os.environ.get(key)
    if env:
        return env
    blob = _load_json(_SECRETS_FILE, {})
    if not isinstance(blob, dict):
        return None
    if key in blob and isinstance(blob[key], str):
        return blob[key]
    # check a nested "security" section
    sec = blob.get("security")
    if isinstance(sec, dict) and isinstance(sec.get(key), str):
        return sec[key]
    return None


def _inject_creds(rtsp_url: str) -> str:
    """If an rtsp:// URL has no user:pass and CAMERA_USER/CAMERA_PASS are
    available, splice them in. Returns the URL unchanged otherwise."""
    if not rtsp_url.lower().startswith("rtsp://"):
        return rtsp_url
    rest = rtsp_url[len("rtsp://"):]
    if "@" in rest.split("/", 1)[0]:
        return rtsp_url  # already has credentials
    user = _secret("CAMERA_USER") or _secret("RTSP_USER")
    pw = _secret("CAMERA_PASS") or _secret("RTSP_PASS")
    if user and pw:
        return f"rtsp://{user}:{pw}@{rest}"
    return rtsp_url


def _redact(url: str) -> str:
    """Strip credentials out of an rtsp URL for safe logging/returning."""
    return re.sub(r"://[^/@]+@", "://***:***@", url)


# ──────────────────────────────────────────────────────────────────────────
# CAMERA REGISTRY
# ──────────────────────────────────────────────────────────────────────────


def _load_cameras() -> List[Dict[str, Any]]:
    data = _load_json(_CAMERAS_FILE, [])
    return data if isinstance(data, list) else []


def _find_camera(name: str) -> Optional[Dict[str, Any]]:
    for cam in _load_cameras():
        if str(cam.get("name", "")).lower() == name.lower():
            return cam
    return None


# ──────────────────────────────────────────────────────────────────────────
# RTSP / IP CAMERAS
# ──────────────────────────────────────────────────────────────────────────


def _ffmpeg_snapshot(rtsp_url: str, dest: str, timeout: float = 25.0) -> Dict[str, Any]:
    """Grab a single frame from `rtsp_url` to `dest` via ffmpeg."""
    if not _have("ffmpeg"):
        return _missing("ffmpeg")
    real = _inject_creds(rtsp_url)
    cmd = [
        "ffmpeg", "-y", "-rtsp_transport", "tcp",
        "-i", real,
        "-frames:v", "1", "-q:v", "2",
        "-an", dest,
    ]
    rc, out, err = _run(cmd, timeout=timeout)
    if rc == 0 and os.path.exists(dest) and os.path.getsize(dest) > 0:
        return {
            "ok": True,
            "saved_to": dest,
            "bytes": os.path.getsize(dest),
            "url": _redact(rtsp_url),
        }
    return _err(f"ffmpeg snapshot failed (rc={rc}): {(err or out).strip()[-300:]}")


def camera_snapshot(args: dict) -> dict:
    """Grab a single still frame from an arbitrary RTSP URL."""
    rtsp_url = args.get("rtsp_url")
    if not rtsp_url:
        return _err("rtsp_url required")
    save_to = args.get("save_to") or os.path.join(_SNAP_DIR, f"snap-{_stamp()}.jpg")
    save_to = os.path.expanduser(save_to)
    return _ffmpeg_snapshot(rtsp_url, save_to)


def camera_record_clip(args: dict) -> dict:
    """Record a short clip from an RTSP URL via ffmpeg (copy codec, mp4)."""
    rtsp_url = args.get("rtsp_url")
    if not rtsp_url:
        return _err("rtsp_url required")
    if not _have("ffmpeg"):
        return _missing("ffmpeg")
    try:
        duration = int(args.get("duration_sec", 30))
    except (TypeError, ValueError):
        duration = 30
    duration = max(1, min(duration, 600))
    save_to = args.get("save_to") or os.path.join(_SNAP_DIR, f"clip-{_stamp()}.mp4")
    save_to = os.path.expanduser(save_to)
    real = _inject_creds(rtsp_url)
    cmd = [
        "ffmpeg", "-y", "-rtsp_transport", "tcp",
        "-i", real,
        "-t", str(duration),
        "-c", "copy", save_to,
    ]
    rc, out, err = _run(cmd, timeout=duration + 30)
    if rc == 0 and os.path.exists(save_to) and os.path.getsize(save_to) > 0:
        return {
            "ok": True,
            "saved_to": save_to,
            "bytes": os.path.getsize(save_to),
            "duration_sec": duration,
            "url": _redact(rtsp_url),
        }
    return _err(f"ffmpeg record failed (rc={rc}): {(err or out).strip()[-300:]}")


def camera_list_configured(args: dict) -> dict:
    """List cameras registered in brain_state/cameras.json (creds redacted)."""
    cams = _load_cameras()
    safe = []
    for c in cams:
        safe.append({
            "name": c.get("name"),
            "location": c.get("location"),
            "rtsp_url": _redact(str(c.get("rtsp_url", ""))),
            "added": c.get("added"),
        })
    return {"ok": True, "count": len(safe), "cameras": safe, "file": _CAMERAS_FILE}


def camera_add(args: dict) -> dict:
    """Register a camera in brain_state/cameras.json."""
    name = args.get("name")
    rtsp_url = args.get("rtsp_url")
    if not name or not rtsp_url:
        return _err("name and rtsp_url required")
    cams = _load_cameras()
    if any(str(c.get("name", "")).lower() == str(name).lower() for c in cams):
        return _err(f"camera '{name}' already registered")
    cams.append({
        "name": name,
        "rtsp_url": rtsp_url,
        "location": args.get("location"),
        "added": _now_iso(),
    })
    if not _save_json(_CAMERAS_FILE, cams):
        return _err("could not write cameras.json")
    return {"ok": True, "name": name, "total_cameras": len(cams)}


def camera_snapshot_by_name(args: dict) -> dict:
    """Snapshot a registered camera by its name."""
    name = args.get("name")
    if not name:
        return _err("name required")
    cam = _find_camera(name)
    if not cam:
        return _err(f"no camera named '{name}' — register one with camera_add")
    save_to = args.get("save_to") or os.path.join(
        _SNAP_DIR, f"{re.sub(r'[^A-Za-z0-9_-]', '_', str(name))}-{_stamp()}.jpg"
    )
    save_to = os.path.expanduser(save_to)
    res = _ffmpeg_snapshot(str(cam.get("rtsp_url", "")), save_to)
    if res.get("ok"):
        res["camera"] = name
        res["location"] = cam.get("location")
    return res


def camera_snapshot_all(args: dict) -> dict:
    """Snapshot every registered camera; returns per-camera results."""
    cams = _load_cameras()
    if not cams:
        return {"ok": True, "count": 0, "results": [], "note": "no cameras registered"}
    if not _have("ffmpeg"):
        return _missing("ffmpeg")
    results = []
    ok_count = 0
    for cam in cams:
        nm = str(cam.get("name", "?"))
        dest = os.path.join(
            _SNAP_DIR, f"{re.sub(r'[^A-Za-z0-9_-]', '_', nm)}-{_stamp()}.jpg"
        )
        res = _ffmpeg_snapshot(str(cam.get("rtsp_url", "")), dest)
        results.append({"camera": nm, **res})
        if res.get("ok"):
            ok_count += 1
    return {"ok": True, "count": len(cams), "succeeded": ok_count, "results": results}


def _frame_diff_ratio(path_a: str, path_b: str) -> Optional[float]:
    """Return a 0..1 motion ratio between two image files. Uses Pillow if
    available, otherwise a crude byte-size heuristic. None if unreadable."""
    try:
        from PIL import Image, ImageChops  # type: ignore
    except Exception:
        # Fallback: compare file sizes — extremely rough, but never raises.
        try:
            sa, sb = os.path.getsize(path_a), os.path.getsize(path_b)
            if sa == 0 and sb == 0:
                return None
            return min(1.0, abs(sa - sb) / max(sa, sb, 1))
        except OSError:
            return None
    try:
        a = Image.open(path_a).convert("L").resize((160, 120))
        b = Image.open(path_b).convert("L").resize((160, 120))
        diff = ImageChops.difference(a, b)
        hist = diff.histogram()
        # weight each grey-level bucket by its intensity; >25 counts as "changed"
        changed = sum(c for i, c in enumerate(hist) if i > 25)
        total = sum(hist)
        return (changed / total) if total else 0.0
    except Exception:
        return None


def camera_motion_check(args: dict) -> dict:
    """Snapshot a registered camera twice (a few seconds apart) and report
    the frame-difference ratio. motion=True if ratio >= sensitivity."""
    name = args.get("name")
    if not name:
        return _err("name required")
    cam = _find_camera(name)
    if not cam:
        return _err(f"no camera named '{name}'")
    if not _have("ffmpeg"):
        return _missing("ffmpeg")
    try:
        sensitivity = float(args.get("sensitivity", 0.1))
    except (TypeError, ValueError):
        sensitivity = 0.1
    url = str(cam.get("rtsp_url", ""))
    frame_a = os.path.join(_SNAP_DIR, f"motion-a-{_stamp()}.jpg")
    r1 = _ffmpeg_snapshot(url, frame_a)
    if not r1.get("ok"):
        return _err(f"first frame failed: {r1.get('error')}")
    time.sleep(3)
    frame_b = os.path.join(_SNAP_DIR, f"motion-b-{_stamp()}.jpg")
    r2 = _ffmpeg_snapshot(url, frame_b)
    if not r2.get("ok"):
        return _err(f"second frame failed: {r2.get('error')}")
    ratio = _frame_diff_ratio(frame_a, frame_b)
    if ratio is None:
        return _err("could not compare frames")
    motion = ratio >= sensitivity
    result = {
        "ok": True,
        "camera": name,
        "motion": motion,
        "motion_pct": round(ratio * 100, 2),
        "sensitivity_pct": round(sensitivity * 100, 2),
        "frame_a": frame_a,
        "frame_b": frame_b,
    }
    if motion:
        _record_event("motion", f"Motion detected on camera '{name}' ({result['motion_pct']}%)",
                       severity="warning", source=str(name))
    return result


# ──────────────────────────────────────────────────────────────────────────
# ONVIF DISCOVERY (WS-Discovery multicast probe)
# ──────────────────────────────────────────────────────────────────────────


def onvif_discover(args: dict) -> dict:
    """Discover ONVIF cameras on the LAN via a WS-Discovery multicast probe.
    Pure-socket; no external dependency."""
    probe = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" '
        'xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" '
        'xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" '
        'xmlns:dn="http://www.onvif.org/ver10/network/wsdl">'
        '<e:Header>'
        '<w:MessageID>uuid:leon-onvif-probe-0001</w:MessageID>'
        '<w:To e:mustUnderstand="true">'
        'urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>'
        '<w:Action e:mustUnderstand="true">'
        'http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>'
        '</e:Header>'
        '<e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe>'
        '</e:Body></e:Envelope>'
    )
    multicast_group = ("239.255.255.250", 3702)
    found: Dict[str, Dict[str, Any]] = {}
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        sock.settimeout(4.0)
        sock.sendto(probe.encode("utf-8"), multicast_group)
        deadline = time.time() + 5.0
        while time.time() < deadline:
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                break
            text = data.decode("utf-8", errors="replace")
            xaddrs = re.findall(r"<[^>]*XAddrs[^>]*>(.*?)</[^>]*XAddrs[^>]*>", text)
            urls: List[str] = []
            for x in xaddrs:
                urls.extend(u for u in x.split() if u.startswith("http"))
            found[addr[0]] = {"ip": addr[0], "service_urls": urls}
        sock.close()
    except OSError as e:
        return _err(f"WS-Discovery socket error: {e}")
    cams = list(found.values())
    if cams:
        _record_event("onvif_discover", f"ONVIF discovery found {len(cams)} camera(s)",
                       severity="info", source="onvif")
    return {"ok": True, "count": len(cams), "cameras": cams}


# ──────────────────────────────────────────────────────────────────────────
# NETWORK DEVICE DISCOVERY
# ──────────────────────────────────────────────────────────────────────────


_MAC_RE = re.compile(r"([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5})")


def _normalize_mac(mac: str) -> str:
    return mac.lower().replace("-", ":")


def _discover_devices() -> List[Dict[str, Any]]:
    """Return a list of {ip, mac, hostname?} for LAN neighbours, trying
    `ip neigh` then `arp -a`. Empty list if neither yields anything."""
    devices: Dict[str, Dict[str, Any]] = {}

    if _have("ip"):
        rc, out, _ = _run(["ip", "neigh"], timeout=8.0)
        if rc == 0:
            for line in out.splitlines():
                parts = line.split()
                if not parts:
                    continue
                ip = parts[0]
                m = _MAC_RE.search(line)
                state = parts[-1] if parts else ""
                if m and state not in ("FAILED", "INCOMPLETE"):
                    devices[ip] = {"ip": ip, "mac": _normalize_mac(m.group(1))}

    if not devices and _have("arp"):
        rc, out, _ = _run(["arp", "-a"], timeout=8.0)
        if rc == 0:
            for line in out.splitlines():
                ipm = re.search(r"\(([0-9.]+)\)", line)
                m = _MAC_RE.search(line)
                if ipm and m:
                    ip = ipm.group(1)
                    devices[ip] = {"ip": ip, "mac": _normalize_mac(m.group(1))}
                    hm = re.match(r"(\S+)\s+\(", line)
                    if hm and hm.group(1) not in ("?",):
                        devices[ip]["hostname"] = hm.group(1)

    return list(devices.values())


def network_scan(args: dict) -> dict:
    """List devices currently visible on the LAN (ip neigh / arp -a)."""
    devices = _discover_devices()
    if not devices and not (_have("ip") or _have("arp")):
        return _err("neither 'ip' nor 'arp' is installed")
    return {"ok": True, "count": len(devices), "devices": devices}


def _resolve_hostname(ip: str) -> Optional[str]:
    try:
        return socket.gethostbyaddr(ip)[0]
    except (socket.herror, socket.gaierror, OSError):
        return None


def _mac_vendor(mac: str) -> Optional[str]:
    """Best-effort MAC OUI vendor lookup via the free macvendors.com API."""
    oui = mac.upper().replace(":", "")[:6]
    if not re.fullmatch(r"[0-9A-F]{6}", oui):
        return None
    status, body = _http_get(f"https://api.macvendors.com/{mac}", timeout=4.0)
    if status == 200 and body:
        return body.strip()[:80]
    return None


def network_devices_named(args: dict) -> dict:
    """Scan the LAN, then enrich each device with a resolved hostname and a
    MAC-vendor lookup. Vendor lookups are rate-limited so this is slower."""
    devices = _discover_devices()
    if not devices:
        return {"ok": True, "count": 0, "devices": [], "note": "no devices found"}
    enriched = []
    for d in devices:
        ip = d.get("ip", "")
        mac = d.get("mac", "")
        host = d.get("hostname") or _resolve_hostname(ip)
        vendor = _mac_vendor(mac) if mac else None
        enriched.append({
            "ip": ip,
            "mac": mac,
            "hostname": host,
            "vendor": vendor,
        })
        time.sleep(1.1)  # be polite to the free vendor API
    return {"ok": True, "count": len(enriched), "devices": enriched}


def network_baseline_save(args: dict) -> dict:
    """Snapshot current LAN devices as the trusted baseline."""
    devices = _discover_devices()
    if not devices:
        return _err("no devices discovered — refusing to save an empty baseline")
    baseline = {
        "saved": _now_iso(),
        "macs": sorted({d["mac"] for d in devices if d.get("mac")}),
        "devices": devices,
    }
    if not _save_json(_BASELINE_FILE, baseline):
        return _err("could not write network_baseline.json")
    _record_event("baseline_save", f"Network baseline saved ({len(baseline['macs'])} devices)",
                   severity="info", source="network")
    return {"ok": True, "device_count": len(baseline["macs"]), "file": _BASELINE_FILE}


def new_device_check(args: dict) -> dict:
    """Compare current LAN devices against the saved baseline, flag new MACs."""
    baseline = _load_json(_BASELINE_FILE, None)
    if not baseline or not isinstance(baseline, dict):
        return _err("no baseline saved — run network_baseline_save first")
    known = set(baseline.get("macs", []))
    devices = _discover_devices()
    if not devices:
        return _err("no devices discovered (is 'ip'/'arp' available?)")
    current = {d["mac"]: d for d in devices if d.get("mac")}
    new_macs = sorted(set(current) - known)
    missing_macs = sorted(known - set(current))
    new_devices = [current[m] for m in new_macs]
    if new_devices:
        _record_event(
            "new_device",
            f"{len(new_devices)} new device(s) on LAN: "
            + ", ".join(d["ip"] for d in new_devices),
            severity="warning", source="network",
        )
    return {
        "ok": True,
        "new_count": len(new_devices),
        "new_devices": new_devices,
        "missing_macs": missing_macs,
        "baseline_saved": baseline.get("saved"),
    }


# ──────────────────────────────────────────────────────────────────────────
# PORT SCANNING (pure socket — no nmap needed)
# ──────────────────────────────────────────────────────────────────────────


def _parse_ports(spec: Any) -> List[int]:
    """Turn a port spec into a list of ints. 'common' -> the curated list;
    a string like '22,80,443' or '8000-8010'; or an actual list."""
    if spec in (None, "", "common"):
        return list(_COMMON_PORTS)
    if isinstance(spec, list):
        out = []
        for p in spec:
            try:
                out.append(int(p))
            except (TypeError, ValueError):
                continue
        return out
    if isinstance(spec, int):
        return [spec]
    ports: List[int] = []
    for chunk in str(spec).split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            try:
                lo, hi = chunk.split("-", 1)
                lo, hi = int(lo), int(hi)
                ports.extend(range(min(lo, hi), max(lo, hi) + 1))
            except ValueError:
                continue
        else:
            try:
                ports.append(int(chunk))
            except ValueError:
                continue
    return ports


def _service_name(port: int) -> str:
    try:
        return socket.getservbyport(port, "tcp")
    except (OSError, OverflowError):
        return ""


def port_scan_host(args: dict) -> dict:
    """TCP connect-scan a host. ports='common' (default) or a spec like
    '22,80,443' / '8000-8010' / a list. Pure socket — no nmap required."""
    host = args.get("host")
    if not host:
        return _err("host required")
    ports = _parse_ports(args.get("ports", "common"))
    if not ports:
        return _err("no valid ports parsed")
    ports = [p for p in ports if 0 < p < 65536][:1024]
    try:
        ip = socket.gethostbyname(host)
    except socket.gaierror as e:
        return _err(f"cannot resolve host '{host}': {e}")
    open_ports = []
    for p in ports:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.6)
        try:
            if s.connect_ex((ip, p)) == 0:
                open_ports.append({"port": p, "service": _service_name(p)})
        except OSError:
            pass
        finally:
            s.close()
    return {
        "ok": True,
        "host": host,
        "ip": ip,
        "scanned": len(ports),
        "open_count": len(open_ports),
        "open_ports": open_ports,
    }


def _parse_ss_listen(output: str) -> List[Dict[str, Any]]:
    """Parse `ss -tulnp` output into listening-socket records."""
    rows = []
    for line in output.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 5:
            continue
        proto = parts[0]
        local = parts[4]
        m = re.search(r":(\d+)$", local)
        if not m:
            continue
        port = int(m.group(1))
        proc = ""
        pm = re.search(r'users:\(\("([^"]+)"', line)
        if pm:
            proc = pm.group(1)
        rows.append({
            "proto": proto,
            "local": local,
            "port": port,
            "process": proc,
            "service": _service_name(port),
        })
    return rows


def open_ports_local(args: dict) -> dict:
    """List sockets currently LISTENING on this machine (ss, then netstat)."""
    if _have("ss"):
        rc, out, err = _run(["ss", "-tulnp"], timeout=8.0)
        if rc == 0:
            rows = _parse_ss_listen(out)
            return {"ok": True, "tool": "ss", "count": len(rows), "listening": rows}
    if _have("netstat"):
        rc, out, err = _run(["netstat", "-tulnp"], timeout=8.0)
        if rc == 0:
            rows = _parse_ss_listen(out)
            return {"ok": True, "tool": "netstat", "count": len(rows), "listening": rows}
    return _err("neither 'ss' nor 'netstat' is installed")


# ──────────────────────────────────────────────────────────────────────────
# SECURITY EVENT LOG (SQLite)
# ──────────────────────────────────────────────────────────────────────────


def _events_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(_EVENTS_DB, timeout=5.0)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS events (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            ts          TEXT NOT NULL,
            event_type  TEXT NOT NULL,
            description TEXT NOT NULL,
            severity    TEXT NOT NULL DEFAULT 'info',
            source      TEXT
        )
        """
    )
    return conn


def _record_event(
    event_type: str,
    description: str,
    severity: str = "info",
    source: Optional[str] = None,
) -> None:
    """Internal: write an event without raising. Used by camera/network tools."""
    try:
        conn = _events_conn()
        conn.execute(
            "INSERT INTO events (ts, event_type, description, severity, source) "
            "VALUES (?, ?, ?, ?, ?)",
            (_now_iso(), event_type, description, severity, source),
        )
        conn.commit()
        conn.close()
    except sqlite3.Error:
        pass


def event_log(args: dict) -> dict:
    """Append an entry to the local security event log."""
    event_type = args.get("event_type")
    description = args.get("description")
    if not event_type or not description:
        return _err("event_type and description required")
    severity = str(args.get("severity", "info")).lower()
    if severity not in ("info", "warning", "critical"):
        severity = "info"
    source = args.get("source")
    try:
        conn = _events_conn()
        cur = conn.execute(
            "INSERT INTO events (ts, event_type, description, severity, source) "
            "VALUES (?, ?, ?, ?, ?)",
            (_now_iso(), event_type, description, severity, source),
        )
        conn.commit()
        row_id = cur.lastrowid
        conn.close()
    except sqlite3.Error as e:
        return _err(f"sqlite error: {e}")
    return {"ok": True, "id": row_id, "event_type": event_type, "severity": severity}


def events_list(args: dict) -> dict:
    """List recent security events, newest first; optional severity filter."""
    try:
        limit = int(args.get("limit", 30))
    except (TypeError, ValueError):
        limit = 30
    limit = max(1, min(limit, 500))
    severity = args.get("severity")
    try:
        conn = _events_conn()
        if severity:
            cur = conn.execute(
                "SELECT id, ts, event_type, description, severity, source "
                "FROM events WHERE severity = ? ORDER BY id DESC LIMIT ?",
                (str(severity).lower(), limit),
            )
        else:
            cur = conn.execute(
                "SELECT id, ts, event_type, description, severity, source "
                "FROM events ORDER BY id DESC LIMIT ?",
                (limit,),
            )
        rows = cur.fetchall()
        conn.close()
    except sqlite3.Error as e:
        return _err(f"sqlite error: {e}")
    events = [
        {"id": r[0], "ts": r[1], "event_type": r[2],
         "description": r[3], "severity": r[4], "source": r[5]}
        for r in rows
    ]
    return {"ok": True, "count": len(events), "events": events}


def events_today(args: dict) -> dict:
    """List security events logged since local midnight today."""
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        conn = _events_conn()
        cur = conn.execute(
            "SELECT id, ts, event_type, description, severity, source "
            "FROM events WHERE ts LIKE ? ORDER BY id DESC",
            (today + "%",),
        )
        rows = cur.fetchall()
        conn.close()
    except sqlite3.Error as e:
        return _err(f"sqlite error: {e}")
    events = [
        {"id": r[0], "ts": r[1], "event_type": r[2],
         "description": r[3], "severity": r[4], "source": r[5]}
        for r in rows
    ]
    by_sev: Dict[str, int] = {}
    for e in events:
        by_sev[e["severity"]] = by_sev.get(e["severity"], 0) + 1
    return {"ok": True, "date": today, "count": len(events),
            "by_severity": by_sev, "events": events}


# ──────────────────────────────────────────────────────────────────────────
# ACCOUNT / BREACH CHECKS
# ──────────────────────────────────────────────────────────────────────────


def haveibeenpwned_check(args: dict) -> dict:
    """Check an email against HaveIBeenPwned breaches (needs HIBP_API_KEY)."""
    email = args.get("email")
    if not email:
        return _err("email required")
    key = _secret("HIBP_API_KEY")
    if not key:
        return _err("HIBP_API_KEY not set (env or ~/.openclaw/secrets.json)")
    url = (
        "https://haveibeenpwned.com/api/v3/breachedaccount/"
        + urllib.parse.quote(email)
        + "?truncateResponse=false"
    )
    status, body = _http_get(
        url, timeout=10.0,
        headers={"hibp-api-key": key, "User-Agent": "Leon-Security/1.0"},
    )
    if status == 404:
        return {"ok": True, "email": email, "pwned": False, "breach_count": 0,
                "breaches": []}
    if status == 200 and body:
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            return _err("HIBP returned unparseable JSON")
        breaches = [
            {"name": b.get("Name"), "domain": b.get("Domain"),
             "breach_date": b.get("BreachDate"),
             "data_classes": b.get("DataClasses", [])}
            for b in data
        ]
        return {"ok": True, "email": email, "pwned": True,
                "breach_count": len(breaches), "breaches": breaches}
    if status == 401:
        return _err("HIBP rejected the API key (401)")
    if status == 429:
        return _err("HIBP rate-limited (429) — try again shortly")
    return _err(f"HIBP request failed (status={status}): {str(body)[:200]}")


def password_breach_check(args: dict) -> dict:
    """k-anonymity check of a password against HIBP Pwned Passwords. Only the
    first 5 SHA-1 hex chars leave the machine — FREE, no API key needed."""
    password = args.get("password")
    if not password:
        return _err("password required")
    sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]
    status, body = _http_get(
        f"https://api.pwnedpasswords.com/range/{prefix}",
        timeout=8.0,
        headers={"User-Agent": "Leon-Security/1.0", "Add-Padding": "true"},
    )
    if status != 200 or not body:
        return _err(f"Pwned Passwords request failed (status={status})")
    count = 0
    for line in body.splitlines():
        if ":" not in line:
            continue
        h, c = line.split(":", 1)
        if h.strip().upper() == suffix:
            try:
                count = int(c.strip())
            except ValueError:
                count = 0
            break
    return {
        "ok": True,
        "pwned": count > 0,
        "times_seen": count,
        "advice": ("change this password — it appears in known breaches"
                   if count > 0 else "not found in known breaches"),
    }


def ssl_cert_check(args: dict) -> dict:
    """Fetch a domain's TLS certificate and report issuer + expiry."""
    domain = args.get("domain")
    if not domain:
        return _err("domain required")
    domain = domain.replace("https://", "").replace("http://", "").split("/")[0]
    try:
        port = int(args.get("port", 443))
    except (TypeError, ValueError):
        port = 443
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((domain, port), timeout=8.0) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
    except ssl.SSLCertVerificationError as e:
        return {"ok": True, "domain": domain, "valid": False,
                "error": f"certificate verification failed: {e}"}
    except (socket.gaierror, socket.timeout, ConnectionError, OSError) as e:
        return _err(f"could not connect to {domain}:{port}: {e}")
    if not cert:
        return _err("no certificate returned (peer cert unverified?)")

    def _name(seq):
        out = {}
        for rdn in seq or ():
            for k, v in rdn:
                out[k] = v
        return out

    issuer = _name(cert.get("issuer"))
    subject = _name(cert.get("subject"))
    not_after = cert.get("notAfter")
    days_left = None
    if not_after:
        try:
            exp = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_left = (exp - datetime.utcnow()).days
        except ValueError:
            pass
    return {
        "ok": True,
        "domain": domain,
        "valid": True,
        "issuer": issuer.get("organizationName") or issuer.get("commonName"),
        "subject_cn": subject.get("commonName"),
        "expires": not_after,
        "days_until_expiry": days_left,
        "expiring_soon": (days_left is not None and days_left < 21),
    }


def domain_dnssec_check(args: dict) -> dict:
    """Report whether DNSSEC (DNSKEY records) is published for a domain."""
    domain = args.get("domain")
    if not domain:
        return _err("domain required")
    domain = domain.replace("https://", "").replace("http://", "").split("/")[0]
    if _have("dig"):
        rc, out, err = _run(["dig", "+short", "DNSKEY", domain], timeout=8.0)
        if rc in (0, 124):
            keys = [l for l in out.splitlines() if l.strip()]
            rc2, out2, _ = _run(["dig", "+dnssec", "+short", domain], timeout=8.0)
            has_rrsig = "RRSIG" in out2 or bool(keys)
            return {"ok": True, "domain": domain,
                    "dnssec_enabled": bool(keys) or has_rrsig,
                    "dnskey_records": len(keys), "tool": "dig"}
    # Fallback: Cloudflare DoH JSON API for DNSKEY (type 48)
    status, body = _http_get(
        f"https://cloudflare-dns.com/dns-query?name={domain}&type=DNSKEY",
        timeout=8.0,
        headers={"accept": "application/dns-json", "User-Agent": "Leon-Security/1.0"},
    )
    if status == 200 and body:
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            return _err("DoH returned unparseable JSON")
        answers = data.get("Answer", []) or []
        dnskeys = [a for a in answers if a.get("type") == 48]
        return {"ok": True, "domain": domain,
                "dnssec_enabled": bool(dnskeys),
                "dnskey_records": len(dnskeys),
                "ad_flag": bool(data.get("AD")), "tool": "cloudflare-doh"}
    return _err("could not determine DNSSEC status (no dig, DoH failed)")


# ──────────────────────────────────────────────────────────────────────────
# LOCAL SYSTEM HARDENING CHECKS
# ──────────────────────────────────────────────────────────────────────────


def firewall_status(args: dict) -> dict:
    """Summarize the local firewall posture (ufw, then iptables)."""
    if _have("ufw"):
        rc, out, err = _run(["ufw", "status", "verbose"], timeout=8.0)
        if rc == 0:
            active = "Status: active" in out
            return {"ok": True, "tool": "ufw", "active": active,
                    "raw": out.strip()[:1200]}
        if rc != 0 and ("permission" in (err or "").lower() or rc == 1):
            # ufw status usually needs root; report what we can
            return {"ok": True, "tool": "ufw", "active": None,
                    "note": "ufw present but status needs root",
                    "stderr": (err or "").strip()[:200]}
    if _have("iptables"):
        rc, out, err = _run(["iptables", "-L", "-n"], timeout=8.0)
        if rc == 0:
            chains = len(re.findall(r"^Chain ", out, re.MULTILINE))
            rules = len([l for l in out.splitlines()
                         if l and not l.startswith(("Chain", "target", " "))])
            return {"ok": True, "tool": "iptables", "active": rules > 0,
                    "chains": chains, "approx_rules": rules,
                    "raw": out.strip()[:1200]}
        return {"ok": True, "tool": "iptables", "active": None,
                "note": "iptables present but listing needs root"}
    return _err("neither 'ufw' nor 'iptables' is installed")


def failed_logins(args: dict) -> dict:
    """Parse recent failed SSH login attempts from journalctl / auth.log."""
    try:
        limit = int(args.get("limit", 20))
    except (TypeError, ValueError):
        limit = 20
    limit = max(1, min(limit, 200))
    lines: List[str] = []

    if _have("journalctl"):
        rc, out, _ = _run(
            ["journalctl", "-u", "ssh", "-u", "sshd", "--no-pager",
             "-n", "800", "--since", "-7days"],
            timeout=12.0,
        )
        if rc == 0 and out.strip():
            lines = out.splitlines()

    if not lines:
        for p in ("/var/log/auth.log", "/var/log/secure"):
            try:
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()[-2000:]
                break
            except OSError:
                continue

    if not lines:
        return {"ok": True, "count": 0, "attempts": [],
                "note": "no journalctl ssh logs and no readable auth.log "
                        "(may need root)"}

    attempts = []
    pat = re.compile(
        r"Failed password for (?:invalid user )?(\S+) from ([0-9a-fA-F:.]+)"
    )
    for line in lines:
        m = pat.search(line)
        if m:
            attempts.append({
                "user": m.group(1),
                "source_ip": m.group(2),
                "line": line.strip()[:240],
            })
    attempts = attempts[-limit:][::-1]
    by_ip: Dict[str, int] = {}
    for a in attempts:
        by_ip[a["source_ip"]] = by_ip.get(a["source_ip"], 0) + 1
    return {"ok": True, "count": len(attempts), "attempts": attempts,
            "by_source_ip": by_ip}


def audit_summary(args: dict) -> dict:
    """Quick security posture: firewall on? SSH exposed? open ports? recent
    failed logins? Returns a concise scorecard with findings."""
    findings: List[str] = []
    score_ok = 0
    score_total = 0

    # Firewall
    fw = firewall_status({})
    score_total += 1
    fw_active = fw.get("active")
    if fw.get("ok") and fw_active is True:
        score_ok += 1
    elif fw.get("ok") and fw_active is False:
        findings.append("firewall is INACTIVE — enable ufw")
    elif fw_active is None:
        findings.append("firewall status unknown (needs root)")
    else:
        findings.append("no firewall tool detected")

    # Listening ports
    lp = open_ports_local({})
    score_total += 1
    listening = lp.get("listening", []) if lp.get("ok") else []
    external = [
        r for r in listening
        if not str(r.get("local", "")).startswith(("127.", "[::1]", "::1"))
    ]
    ssh_exposed = any(r.get("port") == 22 for r in external)
    if ssh_exposed:
        findings.append("SSH (port 22) is listening on a non-loopback address")
    else:
        score_ok += 1
    risky = [22, 23, 3389, 5900, 445, 3306, 5432, 6379, 27017]
    risky_open = sorted({r.get("port") for r in external
                         if r.get("port") in risky})
    if risky_open:
        findings.append(f"sensitive ports exposed: {risky_open}")

    # Failed logins
    fl = failed_logins({"limit": 100})
    score_total += 1
    fail_count = fl.get("count", 0) if fl.get("ok") else 0
    if fail_count > 25:
        findings.append(f"{fail_count} recent failed SSH logins — possible brute force")
    else:
        score_ok += 1

    # Recent critical security events
    ev = events_list({"limit": 50, "severity": "critical"})
    crit = ev.get("count", 0) if ev.get("ok") else 0
    if crit:
        findings.append(f"{crit} unresolved critical event(s) in the log")

    posture = "good" if not findings else ("attention" if score_ok else "poor")
    return {
        "ok": True,
        "posture": posture,
        "score": f"{score_ok}/{score_total}",
        "firewall_active": fw_active,
        "ssh_exposed": ssh_exposed,
        "external_listening_ports": sorted({r.get("port") for r in external}),
        "recent_failed_logins": fail_count,
        "critical_events": crit,
        "findings": findings or ["no obvious issues found"],
    }


# urllib.parse imported lazily here so the top of the file stays tidy.
import urllib.parse  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # RTSP / IP cameras
    "security.camera_snapshot": camera_snapshot,
    "security.camera_record_clip": camera_record_clip,
    "security.camera_list_configured": camera_list_configured,
    "security.camera_add": camera_add,
    "security.camera_snapshot_by_name": camera_snapshot_by_name,
    "security.camera_snapshot_all": camera_snapshot_all,
    "security.camera_motion_check": camera_motion_check,
    # ONVIF
    "security.onvif_discover": onvif_discover,
    # Network security
    "security.network_scan": network_scan,
    "security.network_devices_named": network_devices_named,
    "security.new_device_check": new_device_check,
    "security.network_baseline_save": network_baseline_save,
    "security.port_scan_host": port_scan_host,
    "security.open_ports_local": open_ports_local,
    # Security event log
    "security.event_log": event_log,
    "security.events_list": events_list,
    "security.events_today": events_today,
    # Account / breach checks
    "security.haveibeenpwned_check": haveibeenpwned_check,
    "security.password_breach_check": password_breach_check,
    "security.ssl_cert_check": ssl_cert_check,
    "security.domain_dnssec_check": domain_dnssec_check,
    # Local hardening checks
    "security.firewall_status": firewall_status,
    "security.failed_logins": failed_logins,
    "security.audit_summary": audit_summary,
}
