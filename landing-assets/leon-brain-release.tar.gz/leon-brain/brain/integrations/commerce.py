"""commerce.py — Leon's commerce hub (Stripe, PayPal, Shopify, Etsy, invoicing).

Each tool reads credentials lazily (env first, then `~/.openclaw/secrets.json`),
makes a single `requests` call with a 15s timeout, and returns the standard
`{ok, ...}` contract used elsewhere in the brain. Nothing in this module
raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `commerce.stripe_balance`)
to callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - STRIPE_SECRET_KEY              (sk_test_… or sk_live_…)
  - PAYPAL_CLIENT_ID + PAYPAL_CLIENT_SECRET
  - PAYPAL_MODE                    (optional — "live" or "sandbox", default sandbox)
  - SHOPIFY_STORE_DOMAIN           (e.g. "shop.myshopify.com")
  - SHOPIFY_ACCESS_TOKEN
  - ETSY_API_KEY + ETSY_ACCESS_TOKEN

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object.
"""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS / HELPERS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 15.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0

# project-local state dir (for invoice PDFs / markdown)
_BRAIN_ROOT = Path(__file__).resolve().parent.parent.parent
_INVOICE_DIR = _BRAIN_ROOT / "brain_state" / "invoices"


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    """Decode a Response into JSON when possible, else return raw text."""
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": resp.text[:2000]}


def _is_http_err(r: requests.Response) -> bool:
    return r.status_code >= 400


# ──────────────────────────────────────────────────────────────────────────
# STRIPE
# ──────────────────────────────────────────────────────────────────────────

_STRIPE_API = "https://api.stripe.com"


def _stripe_auth() -> Optional[tuple]:
    """Return (key, "") basic-auth tuple, or None if missing."""
    key = _get_secret("STRIPE_SECRET_KEY")
    if not key:
        return None
    return (key, "")


def _stripe_get(path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    auth = _stripe_auth()
    if not auth:
        return _missing("STRIPE_SECRET_KEY", "Stripe")
    try:
        r = requests.get(
            f"{_STRIPE_API}{path}",
            auth=auth,
            params=params or {},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "data": r.json()}
    except Exception as e:
        return _err(e)


def _stripe_post(path: str, data: Dict[str, Any]) -> Dict[str, Any]:
    auth = _stripe_auth()
    if not auth:
        return _missing("STRIPE_SECRET_KEY", "Stripe")
    try:
        r = requests.post(
            f"{_STRIPE_API}{path}",
            auth=auth,
            data=data,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "data": r.json()}
    except Exception as e:
        return _err(e)


def _stripe_balance(args: dict) -> dict:
    """GET /v1/balance — available + pending."""
    res = _stripe_get("/v1/balance")
    if not res.get("ok"):
        return res
    d = res["data"]
    return {
        "ok": True,
        "available": d.get("available", []),
        "pending": d.get("pending", []),
        "livemode": d.get("livemode"),
    }


def _stripe_charges_list(args: dict) -> dict:
    """GET /v1/charges — recent charges (default limit 20, max 100)."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    res = _stripe_get("/v1/charges", {"limit": limit})
    if not res.get("ok"):
        return res
    d = res["data"]
    items = d.get("data", []) or []
    return {
        "ok": True,
        "count": len(items),
        "charges": [
            {
                "id": c.get("id"),
                "amount": c.get("amount"),
                "currency": c.get("currency"),
                "status": c.get("status"),
                "paid": c.get("paid"),
                "captured": c.get("captured"),
                "created": c.get("created"),
                "customer": c.get("customer"),
                "description": c.get("description"),
                "receipt_email": c.get("receipt_email"),
            }
            for c in items
        ],
    }


def _stripe_payment_intents_list(args: dict) -> dict:
    """GET /v1/payment_intents."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    res = _stripe_get("/v1/payment_intents", {"limit": limit})
    if not res.get("ok"):
        return res
    items = (res["data"] or {}).get("data", []) or []
    return {
        "ok": True,
        "count": len(items),
        "payment_intents": [
            {
                "id": p.get("id"),
                "amount": p.get("amount"),
                "currency": p.get("currency"),
                "status": p.get("status"),
                "customer": p.get("customer"),
                "created": p.get("created"),
                "description": p.get("description"),
            }
            for p in items
        ],
    }


def _stripe_create_payment_link(args: dict) -> dict:
    """POST /v1/payment_links — creates a hosted Stripe checkout URL.

    Requires a price; we create one on the fly via inline `price_data` on a
    new product, then attach to a payment link.
    """
    try:
        amount_cents = int(args.get("amount_cents", 0))
    except Exception:
        return {"ok": False, "error": "amount_cents must be int"}
    if amount_cents <= 0:
        return {"ok": False, "error": "amount_cents must be positive"}
    currency = str(args.get("currency", "usd")).lower()
    product_name = str(args.get("product_name", "Custom"))[:250] or "Custom"
    # 1) create product
    p = _stripe_post("/v1/products", {"name": product_name})
    if not p.get("ok"):
        return {"ok": False, "error": "product create failed", "detail": p}
    product_id = ((p.get("data") or {}).get("id"))
    if not product_id:
        return {"ok": False, "error": "no product id returned", "detail": p}
    # 2) create price
    pr = _stripe_post(
        "/v1/prices",
        {
            "unit_amount": amount_cents,
            "currency": currency,
            "product": product_id,
        },
    )
    if not pr.get("ok"):
        return {"ok": False, "error": "price create failed", "detail": pr}
    price_id = ((pr.get("data") or {}).get("id"))
    if not price_id:
        return {"ok": False, "error": "no price id returned", "detail": pr}
    # 3) create payment link
    link = _stripe_post(
        "/v1/payment_links",
        {
            "line_items[0][price]": price_id,
            "line_items[0][quantity]": 1,
        },
    )
    if not link.get("ok"):
        return {"ok": False, "error": "payment link create failed", "detail": link}
    ld = link.get("data") or {}
    return {
        "ok": True,
        "url": ld.get("url"),
        "id": ld.get("id"),
        "amount_cents": amount_cents,
        "currency": currency,
        "product_name": product_name,
    }


def _stripe_customers_list(args: dict) -> dict:
    """GET /v1/customers."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    res = _stripe_get("/v1/customers", {"limit": limit})
    if not res.get("ok"):
        return res
    items = (res["data"] or {}).get("data", []) or []
    return {
        "ok": True,
        "count": len(items),
        "customers": [
            {
                "id": c.get("id"),
                "email": c.get("email"),
                "name": c.get("name"),
                "description": c.get("description"),
                "created": c.get("created"),
                "balance": c.get("balance"),
            }
            for c in items
        ],
    }


def _stripe_customer_create(args: dict) -> dict:
    """POST /v1/customers — MEDIUM (creates a customer record)."""
    email = str(args.get("email", "")).strip()
    if not email:
        return {"ok": False, "error": "email required"}
    payload: Dict[str, Any] = {"email": email}
    if args.get("name"):
        payload["name"] = str(args.get("name"))
    if args.get("description"):
        payload["description"] = str(args.get("description"))
    res = _stripe_post("/v1/customers", payload)
    if not res.get("ok"):
        return res
    d = res["data"] or {}
    return {
        "ok": True,
        "id": d.get("id"),
        "email": d.get("email"),
        "name": d.get("name"),
    }


def _stripe_subscription_list(args: dict) -> dict:
    """GET /v1/subscriptions — optionally filtered by customer_id."""
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    params: Dict[str, Any] = {"limit": limit}
    cust = args.get("customer_id")
    if cust:
        params["customer"] = str(cust)
    res = _stripe_get("/v1/subscriptions", params)
    if not res.get("ok"):
        return res
    items = (res["data"] or {}).get("data", []) or []
    return {
        "ok": True,
        "count": len(items),
        "subscriptions": [
            {
                "id": s.get("id"),
                "customer": s.get("customer"),
                "status": s.get("status"),
                "current_period_end": s.get("current_period_end"),
                "cancel_at_period_end": s.get("cancel_at_period_end"),
            }
            for s in items
        ],
    }


def _stripe_invoice_create(args: dict) -> dict:
    """Create a one-off invoice (item + invoice). MEDIUM.

    Flow: POST /v1/invoiceitems (pending) → POST /v1/invoices to bundle them.
    """
    customer_id = str(args.get("customer_id", "")).strip()
    description = str(args.get("description", "")).strip()
    try:
        amount_cents = int(args.get("amount_cents", 0))
    except Exception:
        return {"ok": False, "error": "amount_cents must be int"}
    if not customer_id or amount_cents <= 0 or not description:
        return {"ok": False, "error": "customer_id, amount_cents>0, description required"}
    currency = str(args.get("currency", "usd")).lower()
    # 1) invoice item
    item = _stripe_post(
        "/v1/invoiceitems",
        {
            "customer": customer_id,
            "amount": amount_cents,
            "currency": currency,
            "description": description,
        },
    )
    if not item.get("ok"):
        return {"ok": False, "error": "invoiceitem failed", "detail": item}
    # 2) invoice
    inv = _stripe_post(
        "/v1/invoices",
        {"customer": customer_id, "auto_advance": "false"},
    )
    if not inv.get("ok"):
        return {"ok": False, "error": "invoice create failed", "detail": inv}
    d = inv["data"] or {}
    return {
        "ok": True,
        "id": d.get("id"),
        "customer": d.get("customer"),
        "amount_due": d.get("amount_due"),
        "status": d.get("status"),
        "hosted_invoice_url": d.get("hosted_invoice_url"),
    }


def _stripe_invoice_send(args: dict) -> dict:
    """POST /v1/invoices/{id}/send — HIGH (emails the customer)."""
    invoice_id = str(args.get("invoice_id", "")).strip()
    if not invoice_id:
        return {"ok": False, "error": "invoice_id required"}
    res = _stripe_post(f"/v1/invoices/{invoice_id}/send", {})
    if not res.get("ok"):
        return res
    d = res["data"] or {}
    return {
        "ok": True,
        "id": d.get("id"),
        "status": d.get("status"),
        "sent": True,
    }


def _stripe_refund(args: dict) -> dict:
    """POST /v1/refunds — HIGH. amount_cents=None refunds full charge."""
    charge_id = str(args.get("charge_id", "")).strip()
    if not charge_id:
        return {"ok": False, "error": "charge_id required"}
    payload: Dict[str, Any] = {"charge": charge_id}
    amt = args.get("amount_cents")
    if amt is not None:
        try:
            payload["amount"] = int(amt)
        except Exception:
            return {"ok": False, "error": "amount_cents must be int"}
    res = _stripe_post("/v1/refunds", payload)
    if not res.get("ok"):
        return res
    d = res["data"] or {}
    return {
        "ok": True,
        "id": d.get("id"),
        "charge": d.get("charge"),
        "amount": d.get("amount"),
        "status": d.get("status"),
    }


def _stripe_dispute_list(args: dict) -> dict:
    """GET /v1/disputes."""
    try:
        limit = max(1, min(100, int(args.get("limit", 10))))
    except Exception:
        limit = 10
    res = _stripe_get("/v1/disputes", {"limit": limit})
    if not res.get("ok"):
        return res
    items = (res["data"] or {}).get("data", []) or []
    return {
        "ok": True,
        "count": len(items),
        "disputes": [
            {
                "id": d.get("id"),
                "amount": d.get("amount"),
                "currency": d.get("currency"),
                "status": d.get("status"),
                "reason": d.get("reason"),
                "charge": d.get("charge"),
                "created": d.get("created"),
            }
            for d in items
        ],
    }


def _stripe_revenue_window(start_ts: int, end_ts: int) -> Dict[str, Any]:
    """Sum successful charges in [start_ts, end_ts) by paginating /v1/charges."""
    auth = _stripe_auth()
    if not auth:
        return _missing("STRIPE_SECRET_KEY", "Stripe")
    try:
        total_by_currency: Dict[str, int] = {}
        count = 0
        starting_after: Optional[str] = None
        # cap pages to keep call bounded
        for _ in range(20):
            params: Dict[str, Any] = {
                "limit": 100,
                "created[gte]": start_ts,
                "created[lt]": end_ts,
            }
            if starting_after:
                params["starting_after"] = starting_after
            r = requests.get(
                f"{_STRIPE_API}/v1/charges",
                auth=auth,
                params=params,
                timeout=_DEFAULT_TIMEOUT,
            )
            if _is_http_err(r):
                return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
            j = r.json() or {}
            items = j.get("data", []) or []
            for c in items:
                if c.get("paid") and c.get("status") == "succeeded" and not c.get("refunded"):
                    cur = (c.get("currency") or "usd").lower()
                    total_by_currency[cur] = total_by_currency.get(cur, 0) + int(c.get("amount", 0))
                    count += 1
            if not j.get("has_more") or not items:
                break
            starting_after = items[-1].get("id")
            if not starting_after:
                break
        return {
            "ok": True,
            "count": count,
            "total_cents_by_currency": total_by_currency,
        }
    except Exception as e:
        return _err(e)


def _stripe_revenue_today(args: dict) -> dict:
    """Sum today's (UTC) successful charges."""
    now = datetime.now(timezone.utc)
    start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    end = start + timedelta(days=1)
    res = _stripe_revenue_window(int(start.timestamp()), int(end.timestamp()))
    if not res.get("ok"):
        return res
    res["window"] = "today_utc"
    res["start"] = start.isoformat()
    res["end"] = end.isoformat()
    return res


def _stripe_revenue_this_month(args: dict) -> dict:
    """Sum this month's (UTC) successful charges."""
    now = datetime.now(timezone.utc)
    start = datetime(now.year, now.month, 1, tzinfo=timezone.utc)
    # first of next month
    if now.month == 12:
        end = datetime(now.year + 1, 1, 1, tzinfo=timezone.utc)
    else:
        end = datetime(now.year, now.month + 1, 1, tzinfo=timezone.utc)
    res = _stripe_revenue_window(int(start.timestamp()), int(end.timestamp()))
    if not res.get("ok"):
        return res
    res["window"] = "month_to_date_utc"
    res["start"] = start.isoformat()
    res["end"] = end.isoformat()
    return res


# ──────────────────────────────────────────────────────────────────────────
# PAYPAL
# ──────────────────────────────────────────────────────────────────────────

_PAYPAL_TOKEN_CACHE: Dict[str, Any] = {"token": None, "expires": 0.0, "base": None}


def _paypal_base() -> str:
    mode = (_get_secret("PAYPAL_MODE") or "sandbox").lower()
    if mode == "live":
        return "https://api-m.paypal.com"
    return "https://api-m.sandbox.paypal.com"


def _paypal_token() -> Dict[str, Any]:
    """Fetch (and cache) an OAuth2 access token."""
    cid = _get_secret("PAYPAL_CLIENT_ID")
    sec = _get_secret("PAYPAL_CLIENT_SECRET")
    if not cid or not sec:
        return _missing("PAYPAL_CLIENT_ID/PAYPAL_CLIENT_SECRET", "PayPal")
    base = _paypal_base()
    now = time.time()
    if (
        _PAYPAL_TOKEN_CACHE.get("token")
        and _PAYPAL_TOKEN_CACHE.get("base") == base
        and _PAYPAL_TOKEN_CACHE.get("expires", 0) > now + 60
    ):
        return {"ok": True, "token": _PAYPAL_TOKEN_CACHE["token"], "base": base}
    try:
        r = requests.post(
            f"{base}/v1/oauth2/token",
            auth=(cid, sec),
            data={"grant_type": "client_credentials"},
            headers={"Accept": "application/json"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"paypal auth HTTP {r.status_code}",
                    **_wrap_http(r)}
        j = r.json() or {}
        tok = j.get("access_token")
        if not tok:
            return {"ok": False, "error": "paypal: no access_token"}
        _PAYPAL_TOKEN_CACHE["token"] = tok
        _PAYPAL_TOKEN_CACHE["expires"] = now + float(j.get("expires_in", 3000))
        _PAYPAL_TOKEN_CACHE["base"] = base
        return {"ok": True, "token": tok, "base": base}
    except Exception as e:
        return _err(e)


def _paypal_headers() -> Optional[Dict[str, str]]:
    t = _paypal_token()
    if not t.get("ok"):
        return None
    return {
        "Authorization": f"Bearer {t['token']}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _paypal_balance(args: dict) -> dict:
    """GET /v1/reporting/balances."""
    t = _paypal_token()
    if not t.get("ok"):
        return t
    base = t["base"]
    headers = {"Authorization": f"Bearer {t['token']}",
               "Accept": "application/json"}
    try:
        r = requests.get(
            f"{base}/v1/reporting/balances",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        return {
            "ok": True,
            "balances": j.get("balances", []),
            "account_id": j.get("account_id"),
            "as_of_time": j.get("as_of_time"),
        }
    except Exception as e:
        return _err(e)


def _paypal_transactions_list(args: dict) -> dict:
    """GET /v1/reporting/transactions — default last 24h, max 31-day window."""
    t = _paypal_token()
    if not t.get("ok"):
        return t
    base = t["base"]
    try:
        limit = max(1, min(500, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    end_iso = args.get("end_date") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S-0000")
    start_iso = args.get("start_date") or (
        (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S-0000")
    )
    headers = {"Authorization": f"Bearer {t['token']}",
               "Accept": "application/json"}
    try:
        r = requests.get(
            f"{base}/v1/reporting/transactions",
            headers=headers,
            params={
                "start_date": start_iso,
                "end_date": end_iso,
                "page_size": limit,
                "fields": "transaction_info,payer_info",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        details = j.get("transaction_details", []) or []
        return {
            "ok": True,
            "count": len(details),
            "transactions": details,
            "start_date": start_iso,
            "end_date": end_iso,
        }
    except Exception as e:
        return _err(e)


def _paypal_create_invoice(args: dict) -> dict:
    """POST /v2/invoicing/invoices — MEDIUM (draft created; not auto-sent)."""
    recipient = str(args.get("recipient_email", "")).strip()
    if not recipient:
        return {"ok": False, "error": "recipient_email required"}
    try:
        amount = float(args.get("amount", 0))
    except Exception:
        return {"ok": False, "error": "amount must be number"}
    if amount <= 0:
        return {"ok": False, "error": "amount must be > 0"}
    currency = str(args.get("currency", "USD")).upper()
    note = str(args.get("note", "")) or "Invoice from Sabr"
    headers = _paypal_headers()
    if not headers:
        return _missing("PAYPAL_CLIENT_ID/PAYPAL_CLIENT_SECRET", "PayPal")
    base = _paypal_base()
    body = {
        "detail": {
            "currency_code": currency,
            "note": note,
            "invoice_date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        },
        "primary_recipients": [
            {"billing_info": {"email_address": recipient}}
        ],
        "items": [
            {
                "name": "Services",
                "quantity": "1",
                "unit_amount": {
                    "currency_code": currency,
                    "value": f"{amount:.2f}",
                },
            }
        ],
    }
    try:
        r = requests.post(
            f"{base}/v2/invoicing/invoices",
            headers=headers,
            json=body,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        href = None
        for link in j.get("links", []) or []:
            if link.get("rel") == "self":
                href = link.get("href")
                break
        return {
            "ok": True,
            "id": (href.rsplit("/", 1)[-1] if href else j.get("id")),
            "href": href,
            "currency": currency,
            "amount": amount,
            "recipient": recipient,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# SHOPIFY
# ──────────────────────────────────────────────────────────────────────────

_SHOPIFY_API_VERSION = "2024-10"


def _shopify_base() -> Optional[str]:
    domain = _get_secret("SHOPIFY_STORE_DOMAIN")
    if not domain:
        return None
    domain = domain.strip().replace("https://", "").replace("http://", "").rstrip("/")
    return f"https://{domain}/admin/api/{_SHOPIFY_API_VERSION}"


def _shopify_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("SHOPIFY_ACCESS_TOKEN")
    if not tok:
        return None
    return {
        "X-Shopify-Access-Token": tok,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _shopify_check() -> Optional[Dict[str, Any]]:
    base = _shopify_base()
    if not base:
        return _missing("SHOPIFY_STORE_DOMAIN", "Shopify")
    headers = _shopify_headers()
    if not headers:
        return _missing("SHOPIFY_ACCESS_TOKEN", "Shopify")
    return None


def _shopify_products_list(args: dict) -> dict:
    """GET /products.json."""
    miss = _shopify_check()
    if miss:
        return miss
    try:
        limit = max(1, min(250, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    try:
        r = requests.get(
            f"{_shopify_base()}/products.json",
            headers=_shopify_headers(),
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        items = j.get("products", []) or []
        return {
            "ok": True,
            "count": len(items),
            "products": [
                {
                    "id": p.get("id"),
                    "title": p.get("title"),
                    "vendor": p.get("vendor"),
                    "product_type": p.get("product_type"),
                    "status": p.get("status"),
                    "variants": [
                        {
                            "id": v.get("id"),
                            "price": v.get("price"),
                            "sku": v.get("sku"),
                            "inventory_quantity": v.get("inventory_quantity"),
                            "inventory_item_id": v.get("inventory_item_id"),
                        }
                        for v in (p.get("variants") or [])
                    ],
                }
                for p in items
            ],
        }
    except Exception as e:
        return _err(e)


def _shopify_product_get(args: dict) -> dict:
    """GET /products/{id}.json."""
    miss = _shopify_check()
    if miss:
        return miss
    pid = str(args.get("product_id", "")).strip()
    if not pid:
        return {"ok": False, "error": "product_id required"}
    try:
        r = requests.get(
            f"{_shopify_base()}/products/{pid}.json",
            headers=_shopify_headers(),
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        return {"ok": True, "product": j.get("product")}
    except Exception as e:
        return _err(e)


def _shopify_product_create(args: dict) -> dict:
    """POST /products.json — MEDIUM (creates a product)."""
    miss = _shopify_check()
    if miss:
        return miss
    title = str(args.get("title", "")).strip()
    if not title:
        return {"ok": False, "error": "title required"}
    body: Dict[str, Any] = {"title": title}
    if args.get("body_html"):
        body["body_html"] = str(args.get("body_html"))
    if args.get("vendor"):
        body["vendor"] = str(args.get("vendor"))
    if args.get("product_type"):
        body["product_type"] = str(args.get("product_type"))
    try:
        r = requests.post(
            f"{_shopify_base()}/products.json",
            headers=_shopify_headers(),
            json={"product": body},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        p = j.get("product") or {}
        return {
            "ok": True,
            "id": p.get("id"),
            "title": p.get("title"),
            "handle": p.get("handle"),
        }
    except Exception as e:
        return _err(e)


def _shopify_product_update_inventory(args: dict) -> dict:
    """Set on-hand inventory for a variant. MEDIUM.

    Flow: variant → inventory_item_id → locations[0] → POST inventory_levels/set.
    """
    miss = _shopify_check()
    if miss:
        return miss
    variant_id = str(args.get("variant_id", "")).strip()
    if not variant_id:
        return {"ok": False, "error": "variant_id required"}
    try:
        available = int(args.get("available", 0))
    except Exception:
        return {"ok": False, "error": "available must be int"}
    headers = _shopify_headers()
    base = _shopify_base()
    try:
        # 1) get variant for inventory_item_id
        rv = requests.get(
            f"{base}/variants/{variant_id}.json",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(rv):
            return {"ok": False, "error": f"variant HTTP {rv.status_code}", **_wrap_http(rv)}
        inv_item_id = (((rv.json() or {}).get("variant") or {}).get("inventory_item_id"))
        if not inv_item_id:
            return {"ok": False, "error": "no inventory_item_id on variant"}
        # 2) pick first location
        rl = requests.get(
            f"{base}/locations.json",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(rl):
            return {"ok": False, "error": f"locations HTTP {rl.status_code}", **_wrap_http(rl)}
        locs = (rl.json() or {}).get("locations", []) or []
        if not locs:
            return {"ok": False, "error": "no Shopify locations found"}
        location_id = locs[0].get("id")
        # 3) set
        rs = requests.post(
            f"{base}/inventory_levels/set.json",
            headers=headers,
            json={
                "location_id": location_id,
                "inventory_item_id": inv_item_id,
                "available": available,
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(rs):
            return {"ok": False, "error": f"set HTTP {rs.status_code}", **_wrap_http(rs)}
        return {
            "ok": True,
            "variant_id": variant_id,
            "inventory_item_id": inv_item_id,
            "location_id": location_id,
            "available": available,
        }
    except Exception as e:
        return _err(e)


def _shopify_orders_unfulfilled(args: dict) -> dict:
    """GET /orders.json?fulfillment_status=unfulfilled&status=open."""
    miss = _shopify_check()
    if miss:
        return miss
    try:
        limit = max(1, min(250, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    try:
        r = requests.get(
            f"{_shopify_base()}/orders.json",
            headers=_shopify_headers(),
            params={
                "limit": limit,
                "fulfillment_status": "unfulfilled",
                "status": "open",
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = (r.json() or {}).get("orders", []) or []
        return {
            "ok": True,
            "count": len(items),
            "orders": [
                {
                    "id": o.get("id"),
                    "name": o.get("name"),
                    "total_price": o.get("total_price"),
                    "currency": o.get("currency"),
                    "created_at": o.get("created_at"),
                    "customer_email": (o.get("email") or
                                       (o.get("customer") or {}).get("email")),
                    "fulfillment_status": o.get("fulfillment_status"),
                    "line_items": [
                        {"title": li.get("title"), "qty": li.get("quantity"), "sku": li.get("sku")}
                        for li in (o.get("line_items") or [])
                    ],
                }
                for o in items
            ],
        }
    except Exception as e:
        return _err(e)


def _shopify_order_fulfill(args: dict) -> dict:
    """Create a fulfillment for an order. MEDIUM.

    Uses 2024-10 fulfillment_orders + /fulfillments.json endpoint.
    """
    miss = _shopify_check()
    if miss:
        return miss
    order_id = str(args.get("order_id", "")).strip()
    if not order_id:
        return {"ok": False, "error": "order_id required"}
    headers = _shopify_headers()
    base = _shopify_base()
    try:
        # 1) list fulfillment orders for this order
        rfo = requests.get(
            f"{base}/orders/{order_id}/fulfillment_orders.json",
            headers=headers,
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(rfo):
            return {"ok": False, "error": f"fulfillment_orders HTTP {rfo.status_code}",
                    **_wrap_http(rfo)}
        fos = (rfo.json() or {}).get("fulfillment_orders", []) or []
        if not fos:
            return {"ok": False, "error": "no fulfillment orders found"}
        line_items_by_fo: List[Dict[str, Any]] = []
        for fo in fos:
            if fo.get("status") in ("closed", "cancelled"):
                continue
            line_items_by_fo.append({"fulfillment_order_id": fo.get("id")})
        if not line_items_by_fo:
            return {"ok": False, "error": "all fulfillment orders are closed/cancelled"}
        # 2) create fulfillment (no tracking)
        rfu = requests.post(
            f"{base}/fulfillments.json",
            headers=headers,
            json={
                "fulfillment": {
                    "message": "Fulfilled by Leon",
                    "notify_customer": False,
                    "line_items_by_fulfillment_order": line_items_by_fo,
                }
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(rfu):
            return {"ok": False, "error": f"fulfillment HTTP {rfu.status_code}",
                    **_wrap_http(rfu)}
        fj = (rfu.json() or {}).get("fulfillment") or {}
        return {
            "ok": True,
            "fulfillment_id": fj.get("id"),
            "order_id": order_id,
            "status": fj.get("status"),
        }
    except Exception as e:
        return _err(e)


def _shopify_customers_list(args: dict) -> dict:
    """GET /customers.json."""
    miss = _shopify_check()
    if miss:
        return miss
    try:
        limit = max(1, min(250, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    try:
        r = requests.get(
            f"{_shopify_base()}/customers.json",
            headers=_shopify_headers(),
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = (r.json() or {}).get("customers", []) or []
        return {
            "ok": True,
            "count": len(items),
            "customers": [
                {
                    "id": c.get("id"),
                    "email": c.get("email"),
                    "first_name": c.get("first_name"),
                    "last_name": c.get("last_name"),
                    "orders_count": c.get("orders_count"),
                    "total_spent": c.get("total_spent"),
                }
                for c in items
            ],
        }
    except Exception as e:
        return _err(e)


def _shopify_revenue_today(args: dict) -> dict:
    """Sum today's orders (Shopify-side `created_at` >= start of UTC day)."""
    miss = _shopify_check()
    if miss:
        return miss
    now = datetime.now(timezone.utc)
    start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    start_iso = start.strftime("%Y-%m-%dT%H:%M:%S%z")
    # default tz offset gives +0000 — fine
    try:
        r = requests.get(
            f"{_shopify_base()}/orders.json",
            headers=_shopify_headers(),
            params={
                "status": "any",
                "created_at_min": start_iso,
                "limit": 250,
            },
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        items = (r.json() or {}).get("orders", []) or []
        total_by_currency: Dict[str, float] = {}
        for o in items:
            cur = (o.get("currency") or "USD").upper()
            try:
                total_by_currency[cur] = total_by_currency.get(cur, 0.0) + float(o.get("total_price") or 0)
            except Exception:
                pass
        return {
            "ok": True,
            "count": len(items),
            "total_by_currency": {k: round(v, 2) for k, v in total_by_currency.items()},
            "start": start.isoformat(),
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# ETSY (v3 Open API)
# ──────────────────────────────────────────────────────────────────────────

_ETSY_API = "https://openapi.etsy.com/v3/application"


def _etsy_headers() -> Optional[Dict[str, str]]:
    api_key = _get_secret("ETSY_API_KEY")
    tok = _get_secret("ETSY_ACCESS_TOKEN")
    if not api_key or not tok:
        return None
    return {
        "x-api-key": api_key,
        "Authorization": f"Bearer {tok}",
        "Accept": "application/json",
    }


def _etsy_shop_listings(args: dict) -> dict:
    """GET /shops/{shop_id}/listings/active."""
    shop_id = str(args.get("shop_id", "")).strip()
    if not shop_id:
        return {"ok": False, "error": "shop_id required"}
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    headers = _etsy_headers()
    if not headers:
        return _missing("ETSY_API_KEY/ETSY_ACCESS_TOKEN", "Etsy")
    try:
        r = requests.get(
            f"{_ETSY_API}/shops/{shop_id}/listings/active",
            headers=headers,
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        items = j.get("results", []) or []
        return {
            "ok": True,
            "count": len(items),
            "listings": [
                {
                    "listing_id": li.get("listing_id"),
                    "title": li.get("title"),
                    "state": li.get("state"),
                    "price": li.get("price"),
                    "quantity": li.get("quantity"),
                    "url": li.get("url"),
                }
                for li in items
            ],
        }
    except Exception as e:
        return _err(e)


def _etsy_shop_orders(args: dict) -> dict:
    """GET /shops/{shop_id}/receipts — recent shop orders ('receipts' in Etsy parlance)."""
    shop_id = str(args.get("shop_id", "")).strip()
    if not shop_id:
        return {"ok": False, "error": "shop_id required"}
    try:
        limit = max(1, min(100, int(args.get("limit", 20))))
    except Exception:
        limit = 20
    headers = _etsy_headers()
    if not headers:
        return _missing("ETSY_API_KEY/ETSY_ACCESS_TOKEN", "Etsy")
    try:
        r = requests.get(
            f"{_ETSY_API}/shops/{shop_id}/receipts",
            headers=headers,
            params={"limit": limit},
            timeout=_DEFAULT_TIMEOUT,
        )
        if _is_http_err(r):
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json() or {}
        items = j.get("results", []) or []
        return {
            "ok": True,
            "count": len(items),
            "orders": [
                {
                    "receipt_id": o.get("receipt_id"),
                    "status": o.get("status"),
                    "buyer_email": o.get("buyer_email"),
                    "grandtotal": o.get("grandtotal"),
                    "is_paid": o.get("is_paid"),
                    "is_shipped": o.get("is_shipped"),
                    "created_timestamp": o.get("created_timestamp"),
                }
                for o in items
            ],
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# LOCAL INVOICING  (no external API)
# ──────────────────────────────────────────────────────────────────────────


def _invoice_dir() -> Path:
    _INVOICE_DIR.mkdir(parents=True, exist_ok=True)
    return _INVOICE_DIR


def _invoice_compute_totals(line_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    subtotal = 0.0
    for raw in line_items or []:
        if not isinstance(raw, dict):
            continue
        desc = str(raw.get("description", "") or "Item")
        try:
            qty = float(raw.get("quantity", 1))
        except Exception:
            qty = 1.0
        try:
            unit_price = float(raw.get("unit_price", 0))
        except Exception:
            unit_price = 0.0
        line_total = round(qty * unit_price, 2)
        subtotal += line_total
        rows.append({
            "description": desc,
            "quantity": qty,
            "unit_price": unit_price,
            "line_total": line_total,
        })
    return {"rows": rows, "subtotal": round(subtotal, 2)}


def _invoice_render_pdf(path: Path, ctx: Dict[str, Any]) -> Optional[str]:
    """Try reportlab. Return None on success, error string on failure."""
    try:
        from reportlab.lib.pagesizes import LETTER
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        )
        from reportlab.lib import colors
        from reportlab.lib.units import inch
    except Exception as e:
        return f"reportlab not available: {type(e).__name__}: {e}"
    try:
        doc = SimpleDocTemplate(
            str(path), pagesize=LETTER,
            leftMargin=0.75 * inch, rightMargin=0.75 * inch,
            topMargin=0.75 * inch, bottomMargin=0.75 * inch,
        )
        styles = getSampleStyleSheet()
        story: List[Any] = []
        story.append(Paragraph(f"<b>INVOICE</b> #{ctx['invoice_id']}", styles["Title"]))
        story.append(Spacer(1, 12))
        story.append(Paragraph(f"<b>Bill To:</b> {ctx['client_name']}", styles["Normal"]))
        story.append(Paragraph(f"<b>Date:</b> {ctx['date']}", styles["Normal"]))
        if ctx.get("due_date"):
            story.append(Paragraph(f"<b>Due:</b> {ctx['due_date']}", styles["Normal"]))
        story.append(Spacer(1, 12))
        table_data = [["Description", "Qty", "Unit", "Total"]]
        for row in ctx["rows"]:
            table_data.append([
                row["description"],
                f"{row['quantity']:g}",
                f"${row['unit_price']:,.2f}",
                f"${row['line_total']:,.2f}",
            ])
        table_data.append(["", "", "Subtotal", f"${ctx['subtotal']:,.2f}"])
        tbl = Table(table_data, colWidths=[3.5 * inch, 0.7 * inch, 1.1 * inch, 1.2 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#00ffc8")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("GRID", (0, 0), (-1, -2), 0.25, colors.grey),
            ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
            ("FONTNAME", (2, -1), (-1, -1), "Helvetica-Bold"),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 18))
        story.append(Paragraph("Thank you for your business.", styles["Italic"]))
        doc.build(story)
        return None
    except Exception as e:
        return f"{type(e).__name__}: {e}"


def _invoice_render_md(path: Path, ctx: Dict[str, Any]) -> None:
    lines = [
        f"# INVOICE #{ctx['invoice_id']}",
        "",
        f"**Bill To:** {ctx['client_name']}",
        f"**Date:** {ctx['date']}",
    ]
    if ctx.get("due_date"):
        lines.append(f"**Due:** {ctx['due_date']}")
    lines += [
        "",
        "| Description | Qty | Unit | Total |",
        "|---|---:|---:|---:|",
    ]
    for row in ctx["rows"]:
        lines.append(
            f"| {row['description']} | {row['quantity']:g} | "
            f"${row['unit_price']:,.2f} | ${row['line_total']:,.2f} |"
        )
    lines += [
        f"| | | **Subtotal** | **${ctx['subtotal']:,.2f}** |",
        "",
        "_Thank you for your business._",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def _invoice_create(args: dict) -> dict:
    """Generate an invoice file (PDF if reportlab, else markdown).

    Args:
      client_name (str, required)
      line_items (list of {description, quantity, unit_price})
      due_date (str, optional ISO date)
      save_to (str, optional — full path to write to)
    """
    try:
        client = str(args.get("client_name", "")).strip()
        if not client:
            return {"ok": False, "error": "client_name required"}
        line_items = args.get("line_items") or []
        if not isinstance(line_items, list) or not line_items:
            return {"ok": False, "error": "line_items (non-empty list) required"}
        totals = _invoice_compute_totals(line_items)
        if not totals["rows"]:
            return {"ok": False, "error": "no valid line_items"}
        now = datetime.now(timezone.utc)
        invoice_id = now.strftime("%Y%m%d-%H%M%S")
        ctx = {
            "invoice_id": invoice_id,
            "client_name": client,
            "date": now.strftime("%Y-%m-%d"),
            "due_date": (str(args.get("due_date")) if args.get("due_date") else None),
            "rows": totals["rows"],
            "subtotal": totals["subtotal"],
        }
        save_to = args.get("save_to")
        try_pdf = True
        if save_to:
            target = Path(str(save_to)).expanduser()
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.suffix.lower() == ".md":
                try_pdf = False
        else:
            target = _invoice_dir() / f"invoice-{invoice_id}.pdf"

        pdf_err: Optional[str] = None
        if try_pdf:
            pdf_err = _invoice_render_pdf(target, ctx)
            if pdf_err is None:
                fmt = "pdf"
            else:
                # fall back to markdown alongside the requested name
                target = target.with_suffix(".md")
                _invoice_render_md(target, ctx)
                fmt = "markdown"
        else:
            _invoice_render_md(target, ctx)
            fmt = "markdown"

        # Sidecar JSON describing this invoice. NOTE: this used to say it was
        # "for invoice_total_outstanding()" — a function that does not exist
        # anywhere in the codebase. The sidecar is still worth writing (it is
        # the only machine-readable record of an invoice), but nothing reads
        # it yet. Do not assume a consumer exists because a comment named one.
        meta = {
            "invoice_id": invoice_id,
            "client_name": client,
            "date": ctx["date"],
            "due_date": ctx["due_date"],
            "subtotal": totals["subtotal"],
            "paid": False,
            "file": str(target),
            "format": fmt,
        }
        meta_path = target.with_suffix(".json")
        try:
            meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        except Exception:
            pass

        return {
            "ok": True,
            "invoice_id": invoice_id,
            "path": str(target),
            "format": fmt,
            "subtotal": totals["subtotal"],
            "pdf_fallback_reason": pdf_err,
        }
    except Exception as e:
        return _err(e)


def _invoice_list_local(args: dict) -> dict:
    """List invoices saved under brain_state/invoices/."""
    try:
        try:
            limit = max(1, min(500, int(args.get("limit", 30))))
        except Exception:
            limit = 30
        d = _invoice_dir()
        files = sorted(
            [p for p in d.glob("invoice-*.*") if p.suffix.lower() != ".json"],
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:limit]
        out: List[Dict[str, Any]] = []
        for f in files:
            meta_path = f.with_suffix(".json")
            meta: Dict[str, Any] = {}
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                except Exception:
                    meta = {}
            out.append({
                "file": str(f),
                "name": f.name,
                "modified": datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc).isoformat(),
                "size_bytes": f.stat().st_size,
                "invoice_id": meta.get("invoice_id"),
                "client_name": meta.get("client_name"),
                "subtotal": meta.get("subtotal"),
                "paid": meta.get("paid", False),
                "due_date": meta.get("due_date"),
            })
        return {"ok": True, "count": len(out), "invoices": out, "dir": str(d)}
    except Exception as e:
        return _err(e)


def _invoice_total_outstanding(args: dict) -> dict:
    """Sum subtotals for invoices whose sidecar JSON has paid=false."""
    try:
        d = _invoice_dir()
        total = 0.0
        unpaid: List[Dict[str, Any]] = []
        for meta_path in d.glob("invoice-*.json"):
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if meta.get("paid"):
                continue
            try:
                sub = float(meta.get("subtotal") or 0)
            except Exception:
                sub = 0.0
            total += sub
            unpaid.append({
                "invoice_id": meta.get("invoice_id"),
                "client_name": meta.get("client_name"),
                "subtotal": sub,
                "due_date": meta.get("due_date"),
                "file": meta.get("file"),
            })
        return {
            "ok": True,
            "outstanding_total": round(total, 2),
            "count": len(unpaid),
            "invoices": unpaid,
        }
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CONVERSION UTILITIES
# ──────────────────────────────────────────────────────────────────────────


def _dollars_to_cents(args: dict) -> dict:
    try:
        amount = float(args.get("amount", 0))
    except Exception:
        return {"ok": False, "error": "amount must be number"}
    return {"ok": True, "cents": int(round(amount * 100)), "dollars": amount}


def _cents_to_dollars(args: dict) -> dict:
    try:
        amount = int(args.get("amount", 0))
    except Exception:
        return {"ok": False, "error": "amount must be int"}
    return {"ok": True, "dollars": round(amount / 100.0, 2), "cents": amount}


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Stripe
    "commerce.stripe_balance": _stripe_balance,
    "commerce.stripe_charges_list": _stripe_charges_list,
    "commerce.stripe_payment_intents_list": _stripe_payment_intents_list,
    "commerce.stripe_create_payment_link": _stripe_create_payment_link,
    "commerce.stripe_customers_list": _stripe_customers_list,
    "commerce.stripe_customer_create": _stripe_customer_create,
    "commerce.stripe_subscription_list": _stripe_subscription_list,
    "commerce.stripe_invoice_create": _stripe_invoice_create,
    "commerce.stripe_invoice_send": _stripe_invoice_send,
    "commerce.stripe_refund": _stripe_refund,
    "commerce.stripe_dispute_list": _stripe_dispute_list,
    "commerce.stripe_revenue_today": _stripe_revenue_today,
    "commerce.stripe_revenue_this_month": _stripe_revenue_this_month,
    # PayPal
    "commerce.paypal_balance": _paypal_balance,
    "commerce.paypal_transactions_list": _paypal_transactions_list,
    "commerce.paypal_create_invoice": _paypal_create_invoice,
    # Shopify
    "commerce.shopify_products_list": _shopify_products_list,
    "commerce.shopify_product_get": _shopify_product_get,
    "commerce.shopify_product_create": _shopify_product_create,
    "commerce.shopify_product_update_inventory": _shopify_product_update_inventory,
    "commerce.shopify_orders_unfulfilled": _shopify_orders_unfulfilled,
    "commerce.shopify_order_fulfill": _shopify_order_fulfill,
    "commerce.shopify_customers_list": _shopify_customers_list,
    "commerce.shopify_revenue_today": _shopify_revenue_today,
    # Etsy
    "commerce.etsy_shop_listings": _etsy_shop_listings,
    "commerce.etsy_shop_orders": _etsy_shop_orders,
    # Local invoicing
    "commerce.invoice_create": _invoice_create,
    "commerce.invoice_list_local": _invoice_list_local,
    "commerce.invoice_total_outstanding": _invoice_total_outstanding,
    # Conversion utilities
    "commerce.dollars_to_cents": _dollars_to_cents,
    "commerce.cents_to_dollars": _cents_to_dollars,
}
