"""Keeps the Tesla Fleet API token set alive.

Access tokens live 8h. This refreshes proactively at a fraction of that
window so a slow refresh or a transient Tesla outage never leaves the
token fully expired. Refresh tokens rotate on every use (Tesla issues a
new one each call) — the old file is preserved as a timestamped backup
before being overwritten, never deleted outright, so a bad refresh can
be diagnosed instead of silently losing access.
"""
from __future__ import annotations
import json, os, time, urllib.request, urllib.parse, shutil, sys

SECURE = "/opt/leon-brain/secure"
TOKENS = os.path.join(SECURE, "tesla_user_tokens.json")
FLEET_TXT = os.path.join(SECURE, "tesla_fleet.txt")
TOKEN_URL = "https://fleet-auth.prd.vn.cloud.tesla.com/oauth2/v3/token"


def _client_id() -> str:
    with open(FLEET_TXT) as fh:
        for line in fh:
            if line.startswith("CLIENT_ID="):
                return line.split("=", 1)[1].strip()
    raise RuntimeError("CLIENT_ID not found in tesla_fleet.txt")


def refresh() -> bool:
    with open(TOKENS) as fh:
        current = json.load(fh)
    data = urllib.parse.urlencode({
        "grant_type": "refresh_token",
        "client_id": _client_id(),
        "refresh_token": current["refresh_token"],
    }).encode()
    req = urllib.request.Request(TOKEN_URL, data=data, method="POST",
                                  headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = json.loads(resp.read())
    except Exception as e:
        print(f"tesla refresh FAILED: {e}", file=sys.stderr)
        return False
    if "access_token" not in body:
        print(f"tesla refresh FAILED: no access_token in response: {body}", file=sys.stderr)
        return False
    body["obtained_at"] = time.time()
    body["obtained_at_human"] = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    backup = f"{TOKENS}.prev-{int(time.time())}"
    shutil.copy2(TOKENS, backup)
    tmp = f"{TOKENS}.tmp"
    with open(tmp, "w") as fh:
        json.dump(body, fh, indent=2)
    os.chmod(tmp, 0o600)
    os.replace(tmp, TOKENS)
    # keep only the 5 most recent backups
    backups = sorted(f for f in os.listdir(SECURE) if f.startswith("tesla_user_tokens.json.prev-"))
    for stale in backups[:-5]:
        os.remove(os.path.join(SECURE, stale))
    print(f"tesla refresh OK, expires_in={body.get('expires_in')}")
    return True


if __name__ == "__main__":
    ok = refresh()
    raise SystemExit(0 if ok else 1)
