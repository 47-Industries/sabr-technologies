"""Document generation — create PDFs, resumes, contracts, reports from
templates. Useful for invoices that aren't tied to Stripe, resumes Dean
wants on demand, meeting minutes from a transcript, etc.

Tries reportlab (full PDF) first, falls back to Markdown if not installed.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_DOCS_DIR = Path.home() / "Documents" / "leon-docs"
_DOCS_DIR.mkdir(parents=True, exist_ok=True)


def _safe_name(name: str) -> str:
    """Strip nasties so filenames are safe + portable."""
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in name)[:80]


def _have_reportlab() -> bool:
    try:
        import reportlab  # type: ignore
        return True
    except Exception:
        return False


def _write_md_fallback(path: Path, title: str, body: str) -> None:
    path.write_text(f"# {title}\n\n{body}\n")


def _resolve_save(save_to: Optional[str], default_name: str) -> Path:
    if save_to:
        p = Path(save_to).expanduser()
    else:
        p = _DOCS_DIR / default_name
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


# ── Resume ────────────────────────────────────────────────────────────
def _resume_pdf(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a resume PDF.

    Args:
      name, title, email, phone, summary, experience (list of dicts),
      education (list), skills (list of strings), save_to (optional)

    Experience dict: {"company","role","start","end","bullets":[...]}.
    Education dict: {"school","degree","year"}.
    """
    name = args.get("name", "Unknown")
    title = args.get("title", "")
    save_to = args.get("save_to")
    default = f"resume_{_safe_name(name)}_{int(time.time())}.pdf"
    path = _resolve_save(save_to, default)

    if not _have_reportlab():
        # Markdown fallback
        md_path = path.with_suffix(".md")
        lines = [f"## {title}" if title else "", "",
                 f"**Email:** {args.get('email','')}",
                 f"**Phone:** {args.get('phone','')}", ""]
        if args.get("summary"):
            lines += ["### Summary", args["summary"], ""]
        if args.get("experience"):
            lines += ["### Experience"]
            for e in args["experience"]:
                lines.append(f"- **{e.get('role','?')}** at {e.get('company','?')} ({e.get('start','?')} – {e.get('end','present')})")
                for b in e.get("bullets", []):
                    lines.append(f"  - {b}")
            lines += [""]
        if args.get("education"):
            lines += ["### Education"]
            for ed in args["education"]:
                lines.append(f"- {ed.get('degree','?')}, {ed.get('school','?')} ({ed.get('year','')})")
            lines += [""]
        if args.get("skills"):
            lines += ["### Skills", ", ".join(args["skills"])]
        _write_md_fallback(md_path, name, "\n".join(lines))
        return {"ok": True, "path": str(md_path), "format": "markdown",
                "note": "reportlab not installed — wrote markdown instead"}

    # reportlab path
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     ListFlowable, ListItem)
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                             rightMargin=0.6*inch, leftMargin=0.6*inch,
                             topMargin=0.6*inch, bottomMargin=0.6*inch)
    styles = getSampleStyleSheet()
    accent = HexColor("#00ffc8")
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], textColor=accent,
                         fontSize=22, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=accent,
                         fontSize=13, spaceBefore=10, spaceAfter=4)
    body = styles["BodyText"]
    parts: List = [Paragraph(name, h1)]
    if title:
        parts.append(Paragraph(title, styles["Italic"]))
    contact = f"{args.get('email','')} · {args.get('phone','')}".strip(" ·")
    if contact:
        parts.append(Paragraph(contact, body))
    if args.get("summary"):
        parts += [Paragraph("Summary", h2), Paragraph(args["summary"], body)]
    if args.get("experience"):
        parts.append(Paragraph("Experience", h2))
        for e in args["experience"]:
            parts.append(Paragraph(
                f"<b>{e.get('role','?')}</b> &mdash; {e.get('company','?')} "
                f"<font color='#888'>({e.get('start','?')} – {e.get('end','present')})</font>",
                body))
            bullets = e.get("bullets") or []
            if bullets:
                parts.append(ListFlowable(
                    [ListItem(Paragraph(b, body)) for b in bullets],
                    bulletType="bullet", leftIndent=12))
    if args.get("education"):
        parts.append(Paragraph("Education", h2))
        for ed in args["education"]:
            parts.append(Paragraph(
                f"{ed.get('degree','?')}, {ed.get('school','?')} "
                f"<font color='#888'>({ed.get('year','')})</font>", body))
    if args.get("skills"):
        parts += [Paragraph("Skills", h2),
                  Paragraph(", ".join(args["skills"]), body)]
    doc.build(parts)
    return {"ok": True, "path": str(path), "format": "pdf"}


# ── Contract / agreement ───────────────────────────────────────────────
def _contract_pdf(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a simple contract / agreement PDF.

    Args: title, parties (list), terms (list of paragraphs),
    effective_date (iso), save_to.
    """
    title = args.get("title", "Agreement")
    save_to = args.get("save_to")
    default = f"contract_{_safe_name(title)}_{int(time.time())}.pdf"
    path = _resolve_save(save_to, default)

    if not _have_reportlab():
        md_path = path.with_suffix(".md")
        lines = [f"## {title}", "",
                 f"**Effective:** {args.get('effective_date','')}",
                 f"**Parties:** {', '.join(args.get('parties',[]))}", ""]
        lines += [f"\n{i+1}. {t}" for i, t in enumerate(args.get("terms", []))]
        _write_md_fallback(md_path, title, "\n".join(lines))
        return {"ok": True, "path": str(md_path), "format": "markdown",
                "note": "reportlab not installed"}

    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                             rightMargin=0.75*inch, leftMargin=0.75*inch,
                             topMargin=0.75*inch, bottomMargin=0.75*inch)
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Heading1"],
                         textColor=HexColor("#00ffc8"), fontSize=18, spaceAfter=12)
    body = styles["BodyText"]
    parts = [Paragraph(title, h1)]
    parts.append(Paragraph(f"<b>Effective Date:</b> {args.get('effective_date','')}", body))
    parts.append(Paragraph(f"<b>Parties:</b> {', '.join(args.get('parties',[]))}", body))
    parts.append(Spacer(1, 0.2*inch))
    for i, term in enumerate(args.get("terms", []), 1):
        parts.append(Paragraph(f"<b>{i}.</b> {term}", body))
        parts.append(Spacer(1, 0.1*inch))
    parts.append(Spacer(1, 0.6*inch))
    parts.append(Paragraph("___________________________ ___________________________", body))
    parts.append(Paragraph("Signature 1 (Party 1)" + " " * 18 + "Signature 2 (Party 2)", body))
    doc.build(parts)
    return {"ok": True, "path": str(path), "format": "pdf"}


# ── Report ─────────────────────────────────────────────────────────────
def _report_pdf(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a generic report PDF from sections.

    Args: title, subtitle (optional), sections (list of {heading, body, bullets}),
    save_to.
    """
    title = args.get("title", "Report")
    save_to = args.get("save_to")
    default = f"report_{_safe_name(title)}_{int(time.time())}.pdf"
    path = _resolve_save(save_to, default)
    sections = args.get("sections", [])

    if not _have_reportlab():
        md_path = path.with_suffix(".md")
        lines = [f"## {title}", ""]
        if args.get("subtitle"):
            lines.append(f"*{args['subtitle']}*\n")
        for s in sections:
            lines.append(f"### {s.get('heading','')}")
            if s.get("body"):
                lines.append(s["body"])
            for b in s.get("bullets", []):
                lines.append(f"- {b}")
            lines.append("")
        _write_md_fallback(md_path, title, "\n".join(lines))
        return {"ok": True, "path": str(md_path), "format": "markdown"}

    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, ListFlowable, ListItem
    doc = SimpleDocTemplate(str(path), pagesize=letter,
                             rightMargin=0.7*inch, leftMargin=0.7*inch,
                             topMargin=0.7*inch, bottomMargin=0.7*inch)
    styles = getSampleStyleSheet()
    accent = HexColor("#00ffc8")
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], textColor=accent, fontSize=20, spaceAfter=6)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=accent, fontSize=14, spaceBefore=10, spaceAfter=6)
    body = styles["BodyText"]
    parts = [Paragraph(title, h1)]
    if args.get("subtitle"):
        parts.append(Paragraph(args["subtitle"], styles["Italic"]))
        parts.append(Spacer(1, 0.15*inch))
    for s in sections:
        parts.append(Paragraph(s.get("heading", ""), h2))
        if s.get("body"):
            parts.append(Paragraph(s["body"], body))
        bullets = s.get("bullets") or []
        if bullets:
            parts.append(ListFlowable(
                [ListItem(Paragraph(b, body)) for b in bullets],
                bulletType="bullet", leftIndent=12))
    doc.build(parts)
    return {"ok": True, "path": str(path), "format": "pdf"}


# ── Meeting minutes ────────────────────────────────────────────────────
def _meeting_minutes_pdf(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate meeting minutes PDF from a transcript.

    Args: title, attendees (list), date_iso, transcript_or_summary,
    action_items (list), decisions (list), save_to.
    """
    return _report_pdf({
        "title": args.get("title", "Meeting Minutes"),
        "subtitle": f"{args.get('date_iso','')} · {', '.join(args.get('attendees',[]))}",
        "sections": [
            {"heading": "Discussion", "body": args.get("transcript_or_summary", "")},
            {"heading": "Decisions", "bullets": args.get("decisions", [])},
            {"heading": "Action items", "bullets": args.get("action_items", [])},
        ],
        "save_to": args.get("save_to"),
    })


# ── Quick Markdown → PDF ───────────────────────────────────────────────
def _markdown_to_pdf(args: Dict[str, Any]) -> Dict[str, Any]:
    """Convert markdown text directly to PDF (simple — bullets + headings).

    Args: markdown (required), title (optional), save_to.
    """
    md = args.get("markdown")
    if not md:
        return {"ok": False, "error": "markdown required"}
    title = args.get("title", "Document")
    sections = []
    current_heading = None
    current_body: List[str] = []
    current_bullets: List[str] = []
    for line in md.split("\n"):
        if line.startswith("# "):
            if current_heading is not None:
                sections.append({"heading": current_heading,
                                 "body": "\n".join(current_body).strip(),
                                 "bullets": current_bullets})
            current_heading = line[2:].strip()
            current_body, current_bullets = [], []
        elif line.startswith("## ") or line.startswith("### "):
            if current_heading is not None:
                sections.append({"heading": current_heading,
                                 "body": "\n".join(current_body).strip(),
                                 "bullets": current_bullets})
            current_heading = line.lstrip("# ").strip()
            current_body, current_bullets = [], []
        elif line.startswith("- ") or line.startswith("* "):
            current_bullets.append(line[2:].strip())
        else:
            current_body.append(line)
    if current_heading is not None or current_body or current_bullets:
        sections.append({"heading": current_heading or "",
                         "body": "\n".join(current_body).strip(),
                         "bullets": current_bullets})
    return _report_pdf({"title": title, "sections": sections,
                         "save_to": args.get("save_to")})


# ── List + cleanup ────────────────────────────────────────────────────
def _list_docs(args: Dict[str, Any]) -> Dict[str, Any]:
    """List documents previously generated by Leon."""
    limit = int(args.get("limit", 30))
    files = sorted(_DOCS_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]
    return {"ok": True, "docs": [
        {"name": p.name, "path": str(p), "size": p.stat().st_size,
         "modified": p.stat().st_mtime}
        for p in files
    ], "count": min(len(files), limit), "dir": str(_DOCS_DIR)}


def _delete_doc(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a generated doc by name (within Leon's doc dir only)."""
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    p = _DOCS_DIR / _safe_name(name)
    if not p.exists():
        return {"ok": False, "error": f"not found: {p}"}
    p.unlink()
    return {"ok": True, "deleted": str(p)}


EXTRA_TOOLS = {
    "docgen.resume_pdf":          _resume_pdf,
    "docgen.contract_pdf":        _contract_pdf,
    "docgen.report_pdf":          _report_pdf,
    "docgen.meeting_minutes_pdf": _meeting_minutes_pdf,
    "docgen.markdown_to_pdf":     _markdown_to_pdf,
    "docgen.list_docs":           _list_docs,
    "docgen.delete_doc":          _delete_doc,
}
