"""
smart_home.py — Leon's smart-home control hub.

A single tool surface that fans out to whichever home-automation backend
the user actually has wired up: Home Assistant (preferred, covers ~all
devices), Philips Hue Bridge (local LAN), Govee cloud, TP-Link Kasa
(local discovery), IFTTT webhooks (fallback), and generic MQTT.

All tools take a single `args` dict and return `{"ok": bool, ...}` —
never raise. Credentials are read lazily from env vars OR
`~/.openclaw/secrets.json`, so this module imports cleanly even on a
machine with nothing configured. Missing creds produce a helpful error
string, not a crash.

EXTRA_TOOLS at the bottom maps dotted tool names (e.g. `home.lights_on`)
to the implementing function — import that dict to register the tools
in one shot, same pattern as `brain/memory_extras.py`.
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# PATHS, SECRETS, HTTP
# ──────────────────────────────────────────────────────────────────────────


_HTTP_TIMEOUT = 8
_SECRETS_LOCK = threading.Lock()
_SECRETS_CACHE: Optional[Dict[str, Any]] = None
_SECRETS_CACHE_TS: float = 0.0
_SECRETS_TTL = 30.0  # re-read at most every 30s


def _project_root() -> str:
    """Project directory (parent of brain/). Used to locate brain_state/."""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _scenes_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "home_scenes.json")


def _secrets_path() -> str:
    return os.path.expanduser("~/.openclaw/secrets.json")


def _load_secrets() -> Dict[str, Any]:
    """Read ~/.openclaw/secrets.json with short TTL cache. Never raises."""
    global _SECRETS_CACHE, _SECRETS_CACHE_TS
    with _SECRETS_LOCK:
        now = time.time()
        if _SECRETS_CACHE is not None and (now - _SECRETS_CACHE_TS) < _SECRETS_TTL:
            return _SECRETS_CACHE
        data: Dict[str, Any] = {}
        try:
            with open(_secrets_path(), "r") as f:
                data = json.load(f) or {}
        except FileNotFoundError:
            data = {}
        except Exception:
            data = {}
        _SECRETS_CACHE = data
        _SECRETS_CACHE_TS = now
        return data


def _secret(dotted_key: str, env_var: Optional[str] = None) -> Optional[str]:
    """Resolve a credential by env-var first, then dotted path in secrets.json."""
    if env_var:
        v = os.environ.get(env_var)
        if v:
            return v
    parts = dotted_key.split(".")
    node: Any = _load_secrets()
    for p in parts:
        if isinstance(node, dict) and p in node:
            node = node[p]
        else:
            return None
    return node if isinstance(node, str) else None


def _missing_creds(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": f"credentials missing — {msg}"}


def _http(method: str, url: str, **kw) -> Dict[str, Any]:
    """Wrap requests with a uniform error envelope. Returns {"ok", "status", "data"}."""
    kw.setdefault("timeout", _HTTP_TIMEOUT)
    try:
        r = requests.request(method, url, **kw)
    except requests.exceptions.Timeout:
        return {"ok": False, "error": f"timeout after {_HTTP_TIMEOUT}s: {url}"}
    except requests.exceptions.ConnectionError as e:
        return {"ok": False, "error": f"connection error: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"http error: {e}"}
    if r.status_code >= 400:
        return {"ok": False, "status": r.status_code, "error": r.text[:500]}
    try:
        data = r.json()
    except Exception:
        data = r.text
    return {"ok": True, "status": r.status_code, "data": data}


# ──────────────────────────────────────────────────────────────────────────
# HOME ASSISTANT
# ──────────────────────────────────────────────────────────────────────────


def _ha_base() -> str:
    url = (
        os.environ.get("HASS_URL")
        or _secret("home_assistant.url")
        or "http://homeassistant.local:8123"
    )
    return url.rstrip("/")


def _ha_token() -> Optional[str]:
    return _secret("home_assistant.token", env_var="HASS_TOKEN")


def _ha_headers() -> Optional[Dict[str, str]]:
    tok = _ha_token()
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


def _ha_require() -> Optional[Dict[str, Any]]:
    """Return an error envelope if HA creds are missing, else None."""
    if not _ha_token():
        return _missing_creds(
            "needs HASS_TOKEN env var or set in ~/.openclaw/secrets.json under key 'home_assistant.token'"
        )
    return None


def ha_get_state(args: dict) -> dict:
    """GET /api/states/{entity_id} — current state + attributes of one entity."""
    err = _ha_require()
    if err:
        return err
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    return _http("GET", f"{_ha_base()}/api/states/{entity_id}", headers=_ha_headers())


def ha_list_entities(args: dict) -> dict:
    """GET /api/states — list all entities, optionally filtered by domain prefix."""
    err = _ha_require()
    if err:
        return err
    domain = (args or {}).get("domain")
    res = _http("GET", f"{_ha_base()}/api/states", headers=_ha_headers())
    if not res.get("ok"):
        return res
    entities = res["data"] or []
    if domain:
        prefix = f"{domain}."
        entities = [e for e in entities if str(e.get("entity_id", "")).startswith(prefix)]
    return {"ok": True, "count": len(entities), "entities": entities}


def ha_call_service(args: dict) -> dict:
    """POST /api/services/{domain}/{service} — generic HA service call."""
    err = _ha_require()
    if err:
        return err
    a = args or {}
    domain = a.get("domain")
    service = a.get("service")
    service_data = a.get("service_data") or {}
    if not domain or not service:
        return {"ok": False, "error": "domain and service required"}
    url = f"{_ha_base()}/api/services/{domain}/{service}"
    return _http("POST", url, headers=_ha_headers(), json=service_data)


def ha_turn_on(args: dict) -> dict:
    """Convenience: call homeassistant.turn_on on any entity."""
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    domain = entity_id.split(".", 1)[0] if "." in entity_id else "homeassistant"
    return ha_call_service({
        "domain": domain,
        "service": "turn_on",
        "service_data": {"entity_id": entity_id},
    })


def ha_turn_off(args: dict) -> dict:
    """Convenience: call <domain>.turn_off on any entity."""
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    domain = entity_id.split(".", 1)[0] if "." in entity_id else "homeassistant"
    return ha_call_service({
        "domain": domain,
        "service": "turn_off",
        "service_data": {"entity_id": entity_id},
    })


def ha_toggle(args: dict) -> dict:
    """Convenience: toggle any entity."""
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    domain = entity_id.split(".", 1)[0] if "." in entity_id else "homeassistant"
    return ha_call_service({
        "domain": domain,
        "service": "toggle",
        "service_data": {"entity_id": entity_id},
    })


def ha_get_history(args: dict) -> dict:
    """GET /api/history/period — recent state history for an entity."""
    err = _ha_require()
    if err:
        return err
    a = args or {}
    entity_id = a.get("entity_id")
    hours = float(a.get("hours") or 24)
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    start_ts = time.time() - hours * 3600
    start_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(start_ts))
    url = f"{_ha_base()}/api/history/period/{start_iso}"
    return _http(
        "GET",
        url,
        headers=_ha_headers(),
        params={"filter_entity_id": entity_id},
    )


def ha_get_logbook(args: dict) -> dict:
    """GET /api/logbook — recent human-readable events."""
    err = _ha_require()
    if err:
        return err
    hours = float((args or {}).get("hours") or 24)
    start_ts = time.time() - hours * 3600
    start_iso = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(start_ts))
    url = f"{_ha_base()}/api/logbook/{start_iso}"
    return _http("GET", url, headers=_ha_headers())


def ha_render_template(args: dict) -> dict:
    """POST /api/template — render a Jinja template against HA state."""
    err = _ha_require()
    if err:
        return err
    template = (args or {}).get("template")
    if not template:
        return {"ok": False, "error": "template required"}
    return _http(
        "POST",
        f"{_ha_base()}/api/template",
        headers=_ha_headers(),
        json={"template": template},
    )


# ──────────────────────────────────────────────────────────────────────────
# HIGH-LEVEL LIGHTS (via Home Assistant entity conventions)
# ──────────────────────────────────────────────────────────────────────────


# A tiny color name → hex/xy table. Anything not here, we try to parse as hex.
_COLOR_NAMES = {
    "red": "#ff0000",
    "green": "#00ff00",
    "blue": "#0000ff",
    "white": "#ffffff",
    "warm": "#ffd2a1",
    "warm_white": "#ffd2a1",
    "cool": "#c4e2ff",
    "cool_white": "#c4e2ff",
    "yellow": "#ffff00",
    "orange": "#ff8800",
    "purple": "#a020f0",
    "pink": "#ff69b4",
    "cyan": "#00ffc8",
    "magenta": "#ff00ff",
    "amber": "#ffbf00",
    "violet": "#7f00ff",
    "indigo": "#4b0082",
    "teal": "#008080",
}


def _parse_color(s: str) -> Optional[List[int]]:
    """Color name or #hex / hex → [r,g,b] 0-255. Returns None if unparseable."""
    if not s:
        return None
    s2 = s.strip().lower()
    if s2 in _COLOR_NAMES:
        s2 = _COLOR_NAMES[s2]
    if s2.startswith("#"):
        s2 = s2[1:]
    if len(s2) == 6 and all(c in "0123456789abcdef" for c in s2):
        try:
            return [int(s2[0:2], 16), int(s2[2:4], 16), int(s2[4:6], 16)]
        except Exception:
            return None
    return None


def _lights_target(area: Optional[str]) -> Dict[str, Any]:
    """Build the service_data dict for an area target.

    If area is None → all lights (no entity_id, HA hits group.all_lights).
    If area looks like a full entity_id (contains .) → use it directly.
    Else assume light.{area}_lights convention.
    """
    if not area:
        return {"entity_id": "all"}
    if "." in area:
        return {"entity_id": area}
    return {"entity_id": f"light.{area}_lights"}


def lights_on(args: dict) -> dict:
    """Turn lights on. Optional `area` (room name or full entity_id), `brightness` 0-255."""
    a = args or {}
    data = _lights_target(a.get("area"))
    b = a.get("brightness")
    if b is not None:
        try:
            data["brightness"] = max(0, min(255, int(b)))
        except Exception:
            pass
    return ha_call_service({"domain": "light", "service": "turn_on", "service_data": data})


def lights_off(args: dict) -> dict:
    """Turn lights off. Optional `area` (room name or full entity_id)."""
    a = args or {}
    data = _lights_target(a.get("area"))
    return ha_call_service({"domain": "light", "service": "turn_off", "service_data": data})


def lights_dim(args: dict) -> dict:
    """Dim lights in area to `percent` (0-100). Converts to HA brightness 0-255."""
    a = args or {}
    area = a.get("area")
    percent = a.get("percent")
    if percent is None:
        return {"ok": False, "error": "percent required"}
    try:
        pct = max(0, min(100, float(percent)))
    except Exception:
        return {"ok": False, "error": "percent must be a number 0-100"}
    data = _lights_target(area)
    data["brightness"] = int(round(pct * 2.55))
    return ha_call_service({"domain": "light", "service": "turn_on", "service_data": data})


def lights_set_color(args: dict) -> dict:
    """Set light color by name (red/cyan/warm/…) or hex (#ff00aa)."""
    a = args or {}
    area = a.get("area")
    color = a.get("color_name_or_hex") or a.get("color")
    rgb = _parse_color(color)
    if not rgb:
        return {"ok": False, "error": f"could not parse color: {color!r}"}
    data = _lights_target(area)
    data["rgb_color"] = rgb
    return ha_call_service({"domain": "light", "service": "turn_on", "service_data": data})


def lights_scene(args: dict) -> dict:
    """Activate scene.{name} via HA scene.turn_on."""
    name = (args or {}).get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    entity = name if "." in name else f"scene.{name}"
    return ha_call_service({
        "domain": "scene",
        "service": "turn_on",
        "service_data": {"entity_id": entity},
    })


# ──────────────────────────────────────────────────────────────────────────
# PHILIPS HUE (direct bridge API)
# ──────────────────────────────────────────────────────────────────────────


def _hue_creds() -> Optional[Dict[str, str]]:
    ip = _secret("hue.bridge_ip", env_var="HUE_BRIDGE_IP")
    user = _secret("hue.username", env_var="HUE_USERNAME")
    if not ip or not user:
        return None
    return {"ip": ip, "user": user}


def _hue_require():
    c = _hue_creds()
    if not c:
        return _missing_creds(
            "needs HUE_BRIDGE_IP + HUE_USERNAME env vars or ~/.openclaw/secrets.json keys 'hue.bridge_ip' and 'hue.username'"
        )
    return None


def hue_list_lights(args: dict) -> dict:
    """GET /api/{user}/lights — all Hue lights on the bridge."""
    err = _hue_require()
    if err:
        return err
    c = _hue_creds()
    return _http("GET", f"http://{c['ip']}/api/{c['user']}/lights")


def hue_set_light(args: dict) -> dict:
    """PUT /api/{user}/lights/{id}/state — set on/brightness/hue/sat on one Hue light."""
    err = _hue_require()
    if err:
        return err
    a = args or {}
    light_id = a.get("light_id")
    if light_id is None:
        return {"ok": False, "error": "light_id required"}
    body: Dict[str, Any] = {}
    if a.get("on") is not None:
        body["on"] = bool(a["on"])
    if a.get("brightness") is not None:
        try:
            body["bri"] = max(0, min(254, int(a["brightness"])))
        except Exception:
            pass
    if a.get("hue") is not None:
        try:
            body["hue"] = max(0, min(65535, int(a["hue"])))
        except Exception:
            pass
    if a.get("sat") is not None:
        try:
            body["sat"] = max(0, min(254, int(a["sat"])))
        except Exception:
            pass
    if not body:
        return {"ok": False, "error": "nothing to set (pass on, brightness, hue, or sat)"}
    c = _hue_creds()
    return _http("PUT", f"http://{c['ip']}/api/{c['user']}/lights/{light_id}/state", json=body)


def hue_list_groups(args: dict) -> dict:
    """GET /api/{user}/groups — Hue rooms / zones."""
    err = _hue_require()
    if err:
        return err
    c = _hue_creds()
    return _http("GET", f"http://{c['ip']}/api/{c['user']}/groups")


# ──────────────────────────────────────────────────────────────────────────
# GOVEE (cloud API)
# ──────────────────────────────────────────────────────────────────────────


def _govee_key() -> Optional[str]:
    return _secret("govee.api_key", env_var="GOVEE_API_KEY")


def _govee_require():
    if not _govee_key():
        return _missing_creds(
            "needs GOVEE_API_KEY env var or ~/.openclaw/secrets.json key 'govee.api_key'"
        )
    return None


def _govee_headers() -> Dict[str, str]:
    return {"Govee-API-Key": _govee_key() or "", "Content-Type": "application/json"}


def govee_list_devices(args: dict) -> dict:
    """GET https://developer-api.govee.com/v1/devices — list Govee devices."""
    err = _govee_require()
    if err:
        return err
    return _http(
        "GET",
        "https://developer-api.govee.com/v1/devices",
        headers=_govee_headers(),
    )


def govee_set_power(args: dict) -> dict:
    """PUT /v1/devices/control — turn Govee device on/off."""
    err = _govee_require()
    if err:
        return err
    a = args or {}
    mac = a.get("device_mac") or a.get("device")
    model = a.get("model")
    if not mac or not model:
        return {"ok": False, "error": "device_mac and model required"}
    body = {
        "device": mac,
        "model": model,
        "cmd": {"name": "turn", "value": "on" if a.get("on", True) else "off"},
    }
    return _http(
        "PUT",
        "https://developer-api.govee.com/v1/devices/control",
        headers=_govee_headers(),
        json=body,
    )


def govee_set_brightness(args: dict) -> dict:
    """PUT /v1/devices/control — set Govee brightness 0-100."""
    err = _govee_require()
    if err:
        return err
    a = args or {}
    mac = a.get("device_mac") or a.get("device")
    model = a.get("model")
    value = a.get("value")
    if not mac or not model or value is None:
        return {"ok": False, "error": "device_mac, model, value required"}
    try:
        v = max(0, min(100, int(value)))
    except Exception:
        return {"ok": False, "error": "value must be int 0-100"}
    body = {
        "device": mac,
        "model": model,
        "cmd": {"name": "brightness", "value": v},
    }
    return _http(
        "PUT",
        "https://developer-api.govee.com/v1/devices/control",
        headers=_govee_headers(),
        json=body,
    )


# ──────────────────────────────────────────────────────────────────────────
# TP-LINK KASA (local, optional dep)
# ──────────────────────────────────────────────────────────────────────────


def _kasa_available() -> bool:
    try:
        import kasa  # noqa: F401
        return True
    except Exception:
        return False


def _kasa_run(coro):
    """Run a coroutine to completion regardless of whether we're already in a loop."""
    import asyncio
    try:
        return asyncio.run(coro)
    except RuntimeError:
        # Already inside a running loop — spin a temp one in a thread.
        result: Dict[str, Any] = {}

        def _worker():
            new_loop = asyncio.new_event_loop()
            try:
                result["v"] = new_loop.run_until_complete(coro)
            except Exception as e:
                result["e"] = e
            finally:
                new_loop.close()

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        t.join(timeout=_HTTP_TIMEOUT + 2)
        if "e" in result:
            raise result["e"]
        return result.get("v")


def kasa_list_devices(args: dict) -> dict:
    """Discover Kasa devices on the local network (requires python-kasa)."""
    if not _kasa_available():
        return {"ok": False, "error": "python-kasa not installed — `pip install python-kasa`"}
    try:
        from kasa import Discover  # type: ignore
        devices = _kasa_run(Discover.discover())
        out = []
        for ip, dev in (devices or {}).items():
            try:
                _kasa_run(dev.update())
            except Exception:
                pass
            out.append({
                "ip": ip,
                "alias": getattr(dev, "alias", None),
                "model": getattr(dev, "model", None),
                "is_on": getattr(dev, "is_on", None),
            })
        return {"ok": True, "count": len(out), "devices": out}
    except Exception as e:
        return {"ok": False, "error": f"kasa discovery failed: {e}"}


def _kasa_find(alias_or_ip: str):
    """Resolve a Kasa device by alias OR by IP. Returns SmartDevice or None."""
    from kasa import Discover, SmartDevice  # type: ignore
    # If it looks like an IP, connect directly.
    if alias_or_ip and (alias_or_ip[0].isdigit() and "." in alias_or_ip):
        try:
            dev = _kasa_run(Discover.discover_single(alias_or_ip))
            return dev
        except Exception:
            return None
    devices = _kasa_run(Discover.discover()) or {}
    for _ip, dev in devices.items():
        try:
            _kasa_run(dev.update())
        except Exception:
            continue
        if getattr(dev, "alias", None) == alias_or_ip:
            return dev
    return None


def kasa_turn_on(args: dict) -> dict:
    """Turn a Kasa device on by alias or IP."""
    if not _kasa_available():
        return {"ok": False, "error": "python-kasa not installed — `pip install python-kasa`"}
    target = (args or {}).get("alias_or_ip")
    if not target:
        return {"ok": False, "error": "alias_or_ip required"}
    try:
        dev = _kasa_find(target)
        if not dev:
            return {"ok": False, "error": f"device not found: {target}"}
        _kasa_run(dev.turn_on())
        return {"ok": True, "alias": getattr(dev, "alias", None), "state": "on"}
    except Exception as e:
        return {"ok": False, "error": f"kasa turn_on failed: {e}"}


def kasa_turn_off(args: dict) -> dict:
    """Turn a Kasa device off by alias or IP."""
    if not _kasa_available():
        return {"ok": False, "error": "python-kasa not installed — `pip install python-kasa`"}
    target = (args or {}).get("alias_or_ip")
    if not target:
        return {"ok": False, "error": "alias_or_ip required"}
    try:
        dev = _kasa_find(target)
        if not dev:
            return {"ok": False, "error": f"device not found: {target}"}
        _kasa_run(dev.turn_off())
        return {"ok": True, "alias": getattr(dev, "alias", None), "state": "off"}
    except Exception as e:
        return {"ok": False, "error": f"kasa turn_off failed: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# CLIMATE / THERMOSTAT
# ──────────────────────────────────────────────────────────────────────────


def thermostat_set_target(args: dict) -> dict:
    """Call climate.set_temperature on a thermostat entity (temperature in F)."""
    a = args or {}
    entity_id = a.get("entity_id")
    temp = a.get("temperature_f")
    if not entity_id or temp is None:
        return {"ok": False, "error": "entity_id and temperature_f required"}
    try:
        t = float(temp)
    except Exception:
        return {"ok": False, "error": "temperature_f must be a number"}
    return ha_call_service({
        "domain": "climate",
        "service": "set_temperature",
        "service_data": {"entity_id": entity_id, "temperature": t},
    })


def thermostat_get_state(args: dict) -> dict:
    """Read current state + attributes of a climate entity."""
    return ha_get_state(args)


def thermostat_set_mode(args: dict) -> dict:
    """Set HVAC mode (heat/cool/auto/off/heat_cool/fan_only/dry) on a climate entity."""
    a = args or {}
    entity_id = a.get("entity_id")
    mode = a.get("mode")
    if not entity_id or not mode:
        return {"ok": False, "error": "entity_id and mode required"}
    return ha_call_service({
        "domain": "climate",
        "service": "set_hvac_mode",
        "service_data": {"entity_id": entity_id, "hvac_mode": mode},
    })


# ──────────────────────────────────────────────────────────────────────────
# SENSORS
# ──────────────────────────────────────────────────────────────────────────


def sensor_read(args: dict) -> dict:
    """Read any HA sensor entity — returns state + unit if available."""
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    res = ha_get_state({"entity_id": entity_id})
    if not res.get("ok"):
        return res
    d = res.get("data") or {}
    attrs = d.get("attributes") or {}
    return {
        "ok": True,
        "entity_id": entity_id,
        "state": d.get("state"),
        "unit": attrs.get("unit_of_measurement"),
        "friendly_name": attrs.get("friendly_name"),
        "last_changed": d.get("last_changed"),
    }


def _sensor_filter_by_suffix(suffix: str) -> Dict[str, Any]:
    res = ha_list_entities({"domain": "sensor"})
    if not res.get("ok"):
        return res
    out = []
    for e in res.get("entities") or []:
        eid = str(e.get("entity_id", ""))
        attrs = e.get("attributes") or {}
        device_class = attrs.get("device_class")
        if eid.endswith(suffix) or device_class == suffix.strip("_"):
            out.append({
                "entity_id": eid,
                "state": e.get("state"),
                "unit": attrs.get("unit_of_measurement"),
                "friendly_name": attrs.get("friendly_name"),
            })
    return {"ok": True, "count": len(out), "sensors": out}


def sensor_list_temperature(args: dict) -> dict:
    """Find all temperature sensors in HA (entity ends in _temperature or device_class=temperature)."""
    return _sensor_filter_by_suffix("_temperature")


def sensor_list_humidity(args: dict) -> dict:
    """Find all humidity sensors in HA."""
    return _sensor_filter_by_suffix("_humidity")


def sensor_door_state(args: dict) -> dict:
    """Read a binary_sensor and translate to open/closed."""
    entity_id = (args or {}).get("entity_id")
    if not entity_id:
        return {"ok": False, "error": "entity_id required"}
    res = ha_get_state({"entity_id": entity_id})
    if not res.get("ok"):
        return res
    d = res.get("data") or {}
    raw = str(d.get("state", "")).lower()
    # binary_sensor convention: "on" == open/detected, "off" == closed/clear
    if raw == "on":
        state = "open"
    elif raw == "off":
        state = "closed"
    else:
        state = raw or "unknown"
    return {
        "ok": True,
        "entity_id": entity_id,
        "state": state,
        "raw": raw,
        "friendly_name": (d.get("attributes") or {}).get("friendly_name"),
    }


# ──────────────────────────────────────────────────────────────────────────
# SCENES / MACROS (local JSON, executes a list of tool calls)
# ──────────────────────────────────────────────────────────────────────────


_SCENES_LOCK = threading.Lock()


def _load_scenes() -> Dict[str, List[Dict[str, Any]]]:
    try:
        with open(_scenes_path(), "r") as f:
            return json.load(f) or {}
    except FileNotFoundError:
        return {}
    except Exception:
        return {}


def _save_scenes(scenes: Dict[str, List[Dict[str, Any]]]) -> None:
    with open(_scenes_path(), "w") as f:
        json.dump(scenes, f, indent=2)


def scene_define(args: dict) -> dict:
    """Save a scene definition: list of {tool, args} actions to run in order."""
    a = args or {}
    name = a.get("name")
    actions = a.get("actions_list") or a.get("actions")
    if not name:
        return {"ok": False, "error": "name required"}
    if not isinstance(actions, list):
        return {"ok": False, "error": "actions_list must be a list of {tool, args}"}
    for i, act in enumerate(actions):
        if not isinstance(act, dict) or "tool" not in act:
            return {"ok": False, "error": f"action {i} missing 'tool' key"}
    with _SCENES_LOCK:
        scenes = _load_scenes()
        scenes[name] = actions
        _save_scenes(scenes)
    return {"ok": True, "name": name, "actions": len(actions)}


def scene_run(args: dict) -> dict:
    """Run a saved scene — each action's tool is looked up in EXTRA_TOOLS."""
    name = (args or {}).get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    with _SCENES_LOCK:
        scenes = _load_scenes()
    if name not in scenes:
        return {"ok": False, "error": f"scene not found: {name}"}
    results = []
    ok_all = True
    for act in scenes[name]:
        tool_name = act.get("tool")
        tool_args = act.get("args") or {}
        fn = EXTRA_TOOLS.get(tool_name)
        if not fn:
            results.append({"tool": tool_name, "ok": False, "error": "tool not registered"})
            ok_all = False
            continue
        try:
            r = fn(tool_args)
        except Exception as e:
            r = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        if not r.get("ok"):
            ok_all = False
        results.append({"tool": tool_name, "result": r})
    return {"ok": ok_all, "name": name, "results": results}


def scene_list(args: dict) -> dict:
    """List all defined scene names + action counts."""
    with _SCENES_LOCK:
        scenes = _load_scenes()
    return {
        "ok": True,
        "count": len(scenes),
        "scenes": [{"name": k, "actions": len(v)} for k, v in scenes.items()],
    }


def scene_delete(args: dict) -> dict:
    """Delete a saved scene by name."""
    name = (args or {}).get("name")
    if not name:
        return {"ok": False, "error": "name required"}
    with _SCENES_LOCK:
        scenes = _load_scenes()
        if name not in scenes:
            return {"ok": False, "error": f"scene not found: {name}"}
        del scenes[name]
        _save_scenes(scenes)
    return {"ok": True, "deleted": name}


# ──────────────────────────────────────────────────────────────────────────
# IFTTT WEBHOOKS
# ──────────────────────────────────────────────────────────────────────────


def ifttt_trigger(args: dict) -> dict:
    """POST to https://maker.ifttt.com/trigger/{event}/with/key/{IFTTT_KEY}."""
    key = _secret("ifttt.key", env_var="IFTTT_KEY")
    if not key:
        return _missing_creds(
            "needs IFTTT_KEY env var or ~/.openclaw/secrets.json key 'ifttt.key'"
        )
    a = args or {}
    event = a.get("event")
    if not event:
        return {"ok": False, "error": "event required"}
    body = {}
    for k in ("value1", "value2", "value3"):
        if a.get(k) is not None:
            body[k] = a[k]
    url = f"https://maker.ifttt.com/trigger/{event}/with/key/{key}"
    return _http("POST", url, json=body)


# ──────────────────────────────────────────────────────────────────────────
# MQTT GENERIC
# ──────────────────────────────────────────────────────────────────────────


def mqtt_publish(args: dict) -> dict:
    """Publish one message to an MQTT topic (requires paho-mqtt)."""
    try:
        import paho.mqtt.publish as mqtt_publish_mod  # type: ignore
    except Exception:
        return {"ok": False, "error": "paho-mqtt not installed — `pip install paho-mqtt`"}
    a = args or {}
    topic = a.get("topic")
    payload = a.get("payload")
    if not topic:
        return {"ok": False, "error": "topic required"}
    host = a.get("host") or _secret("mqtt.host", env_var="MQTT_HOST") or "localhost"
    try:
        port = int(a.get("port") or _secret("mqtt.port", env_var="MQTT_PORT") or 1883)
    except Exception:
        port = 1883
    user = _secret("mqtt.username", env_var="MQTT_USERNAME")
    pw = _secret("mqtt.password", env_var="MQTT_PASSWORD")
    auth = {"username": user, "password": pw} if user else None
    try:
        mqtt_publish_mod.single(
            topic,
            payload=str(payload) if payload is not None else None,
            hostname=host,
            port=port,
            auth=auth,
            keepalive=_HTTP_TIMEOUT,
        )
        return {"ok": True, "topic": topic, "host": host, "port": port}
    except Exception as e:
        return {"ok": False, "error": f"mqtt publish failed: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Home Assistant raw
    "home.ha_get_state": ha_get_state,
    "home.ha_list_entities": ha_list_entities,
    "home.ha_call_service": ha_call_service,
    "home.ha_turn_on": ha_turn_on,
    "home.ha_turn_off": ha_turn_off,
    "home.ha_toggle": ha_toggle,
    "home.ha_get_history": ha_get_history,
    "home.ha_get_logbook": ha_get_logbook,
    "home.ha_render_template": ha_render_template,
    # Lights (high-level via HA)
    "home.lights_on": lights_on,
    "home.lights_off": lights_off,
    "home.lights_dim": lights_dim,
    "home.lights_set_color": lights_set_color,
    "home.lights_scene": lights_scene,
    # Hue (direct bridge)
    "home.hue_list_lights": hue_list_lights,
    "home.hue_set_light": hue_set_light,
    "home.hue_list_groups": hue_list_groups,
    # Govee (cloud)
    "home.govee_list_devices": govee_list_devices,
    "home.govee_set_power": govee_set_power,
    "home.govee_set_brightness": govee_set_brightness,
    # TP-Link Kasa (local)
    "home.kasa_list_devices": kasa_list_devices,
    "home.kasa_turn_on": kasa_turn_on,
    "home.kasa_turn_off": kasa_turn_off,
    # Climate
    "home.thermostat_set_target": thermostat_set_target,
    "home.thermostat_get_state": thermostat_get_state,
    "home.thermostat_set_mode": thermostat_set_mode,
    # Sensors
    "home.sensor_read": sensor_read,
    "home.sensor_list_temperature": sensor_list_temperature,
    "home.sensor_list_humidity": sensor_list_humidity,
    "home.sensor_door_state": sensor_door_state,
    # Scenes (local macros)
    "home.scene_define": scene_define,
    "home.scene_run": scene_run,
    "home.scene_list": scene_list,
    "home.scene_delete": scene_delete,
    # IFTTT
    "home.ifttt_trigger": ifttt_trigger,
    # MQTT
    "home.mqtt_publish": mqtt_publish,
}
