"""
crypto.py — Leon's crypto / Web3 tool surface.

Read-only crypto utilities: Ethereum + Bitcoin balances and transactions,
ENS name resolution, NFT lookups, exchange spot prices (Binance / Coinbase
/ Kraken), and a tiny local portfolio tracker priced via CoinGecko.

Design mirrors `brain/integrations/life.py`:

  - One function per tool, taking a single `args` dict.
  - Every function returns `{"ok": True, "result": ...}` or
    `{"ok": False, "error": "..."}` — never raises out.
  - Credentials read lazily from env per call (ETHERSCAN_API_KEY,
    ALCHEMY_API_KEY, OPENSEA_API_KEY) so Leon picks up new keys without
    a restart. None are required — public endpoints are always tried.
  - All network calls go through `_get` with a 10s timeout.
  - FREE public APIs preferred: Etherscan public tier, Blockstream,
    CoinGecko free, Binance/Coinbase/Kraken public market data.
  - NO trade execution. NO private keys. Read-only by design.

EXTRA_TOOLS at the bottom maps dotted names like `crypto.eth_balance` to
the implementing function.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 10
_USER_AGENT = os.environ.get(
    "LEON_HTTP_CONTACT",
    "Leon/1.0 (Leon; Sabr; contact: support@sabrtechnologies.com)")


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
    if extra:
        h.update(extra)
    return h


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None,
         timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """GET with uniform error envelope."""
    try:
        r = requests.get(url, params=params, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


def _env(name: str) -> Optional[str]:
    v = os.environ.get(name)
    return v.strip() if v and v.strip() else None


def _require_arg(args: dict, key: str) -> Any:
    if key not in args or args[key] in (None, ""):
        raise KeyError(key)
    return args[key]


# ──────────────────────────────────────────────────────────────────────────
# PATHS
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> Path:
    # crypto.py lives in brain/integrations/, project root is two parents up.
    return Path(__file__).resolve().parent.parent.parent


def _portfolio_path() -> Path:
    p = _project_root() / "brain_state" / "crypto_portfolio.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _load_portfolios() -> Dict[str, Any]:
    p = _portfolio_path()
    if not p.exists():
        return {}
    try:
        with p.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_portfolios(data: Dict[str, Any]) -> Optional[str]:
    try:
        with _portfolio_path().open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return None
    except OSError as e:
        return f"could not save portfolio: {e}"


# ──────────────────────────────────────────────────────────────────────────
# ETHERSCAN HELPER
# ──────────────────────────────────────────────────────────────────────────


_ETHERSCAN_URL = "https://api.etherscan.io/api"


def _etherscan(params: Dict[str, Any]) -> Dict[str, Any]:
    key = _env("ETHERSCAN_API_KEY")
    if key:
        params = {**params, "apikey": key}
    resp = _get(_ETHERSCAN_URL, params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "etherscan request failed")}
    data = resp.get("json") or {}
    # Etherscan returns status="1" for success, "0" for "no records" or error.
    status = str(data.get("status", ""))
    message = str(data.get("message", ""))
    if status == "1":
        return {"ok": True, "result": data.get("result")}
    # status=0 with message "No transactions found" is not really an error
    if message and "No transactions" in message:
        return {"ok": True, "result": []}
    return {"ok": False, "error": data.get("result") or message or "etherscan error"}


def _wei_to_eth(wei_str: Any) -> float:
    try:
        return int(wei_str) / 1e18
    except (TypeError, ValueError):
        return 0.0


# ──────────────────────────────────────────────────────────────────────────
# ETHEREUM
# ──────────────────────────────────────────────────────────────────────────


def eth_balance(args: dict) -> dict:
    """ETH balance for an address (in ETH and wei)."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    resp = _etherscan({"module": "account", "action": "balance", "address": addr, "tag": "latest"})
    if not resp.get("ok"):
        return resp
    wei = resp.get("result")
    return {
        "ok": True,
        "result": {
            "address": addr,
            "wei": str(wei),
            "eth": _wei_to_eth(wei),
        },
    }


def eth_token_balance(args: dict) -> dict:
    """ERC-20 token balance for an address."""
    try:
        addr = str(_require_arg(args, "address")).strip()
        token = str(_require_arg(args, "token_contract")).strip()
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    resp = _etherscan({
        "module": "account",
        "action": "tokenbalance",
        "contractaddress": token,
        "address": addr,
        "tag": "latest",
    })
    if not resp.get("ok"):
        return resp
    raw = resp.get("result")
    try:
        raw_int = int(raw)
    except (TypeError, ValueError):
        raw_int = 0
    return {
        "ok": True,
        "result": {
            "address": addr,
            "token_contract": token,
            "raw_balance": str(raw),
            "balance_int": raw_int,
            "note": "raw balance — divide by 10**decimals for human value",
        },
    }


def eth_transactions(args: dict) -> dict:
    """Recent normal transactions for an address."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    limit = int(args.get("limit", 20) or 20)
    resp = _etherscan({
        "module": "account",
        "action": "txlist",
        "address": addr,
        "startblock": 0,
        "endblock": 99999999,
        "page": 1,
        "offset": max(1, min(limit, 100)),
        "sort": "desc",
    })
    if not resp.get("ok"):
        return resp
    txs = resp.get("result") or []
    if not isinstance(txs, list):
        return {"ok": False, "error": "unexpected etherscan response"}
    out = []
    for tx in txs[:limit]:
        out.append({
            "hash": tx.get("hash"),
            "from": tx.get("from"),
            "to": tx.get("to"),
            "value_eth": _wei_to_eth(tx.get("value", "0")),
            "block": tx.get("blockNumber"),
            "timestamp": tx.get("timeStamp"),
            "is_error": tx.get("isError"),
            "gas_used": tx.get("gasUsed"),
        })
    return {"ok": True, "result": {"address": addr, "count": len(out), "transactions": out}}


def eth_gas_price(args: dict) -> dict:
    """Current gas prices (safe/propose/fast) via Etherscan gas tracker."""
    resp = _etherscan({"module": "gastracker", "action": "gasoracle"})
    if not resp.get("ok"):
        return resp
    r = resp.get("result") or {}
    if not isinstance(r, dict):
        return {"ok": False, "error": "unexpected gasoracle response"}
    return {
        "ok": True,
        "result": {
            "safe_gwei": r.get("SafeGasPrice"),
            "propose_gwei": r.get("ProposeGasPrice"),
            "fast_gwei": r.get("FastGasPrice"),
            "base_fee_gwei": r.get("suggestBaseFee"),
            "last_block": r.get("LastBlock"),
        },
    }


def eth_block_number(args: dict) -> dict:
    """Current Ethereum block height."""
    key = _env("ETHERSCAN_API_KEY")
    params = {"module": "proxy", "action": "eth_blockNumber"}
    if key:
        params["apikey"] = key
    resp = _get(_ETHERSCAN_URL, params=params)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "etherscan request failed")}
    data = resp.get("json") or {}
    hex_block = data.get("result")
    try:
        block = int(hex_block, 16)
    except (TypeError, ValueError):
        return {"ok": False, "error": "could not parse block number"}
    return {"ok": True, "result": {"block": block, "hex": hex_block}}


def eth_tx_status(args: dict) -> dict:
    """Status of a transaction: confirmed/pending/failed."""
    try:
        tx_hash = str(_require_arg(args, "tx_hash")).strip()
    except KeyError:
        return {"ok": False, "error": "tx_hash is required"}

    key = _env("ETHERSCAN_API_KEY")
    receipt_params = {"module": "proxy", "action": "eth_getTransactionReceipt", "txhash": tx_hash}
    if key:
        receipt_params["apikey"] = key
    receipt_resp = _get(_ETHERSCAN_URL, params=receipt_params)
    if not receipt_resp.get("ok"):
        return {"ok": False, "error": receipt_resp.get("error", "etherscan request failed")}
    receipt = (receipt_resp.get("json") or {}).get("result")
    if receipt is None:
        # Not yet mined.
        return {"ok": True, "result": {"tx_hash": tx_hash, "status": "pending"}}
    status_hex = receipt.get("status")
    confirmed = status_hex == "0x1"
    try:
        block = int(receipt.get("blockNumber", "0x0"), 16)
    except (TypeError, ValueError):
        block = None
    return {
        "ok": True,
        "result": {
            "tx_hash": tx_hash,
            "status": "confirmed" if confirmed else "failed",
            "block": block,
            "from": receipt.get("from"),
            "to": receipt.get("to"),
            "gas_used_hex": receipt.get("gasUsed"),
        },
    }


# ──────────────────────────────────────────────────────────────────────────
# BITCOIN (Blockstream)
# ──────────────────────────────────────────────────────────────────────────


_BLOCKSTREAM = "https://blockstream.info/api"


def _sats_to_btc(sats: Any) -> float:
    try:
        return int(sats) / 1e8
    except (TypeError, ValueError):
        return 0.0


def btc_balance(args: dict) -> dict:
    """BTC balance for an address (confirmed + mempool)."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    resp = _get(f"{_BLOCKSTREAM}/address/{addr}")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "blockstream request failed")}
    data = resp.get("json") or {}
    chain = data.get("chain_stats") or {}
    mempool = data.get("mempool_stats") or {}
    conf_sats = int(chain.get("funded_txo_sum", 0)) - int(chain.get("spent_txo_sum", 0))
    mem_sats = int(mempool.get("funded_txo_sum", 0)) - int(mempool.get("spent_txo_sum", 0))
    total_sats = conf_sats + mem_sats
    return {
        "ok": True,
        "result": {
            "address": addr,
            "confirmed_sats": conf_sats,
            "mempool_sats": mem_sats,
            "total_sats": total_sats,
            "btc": _sats_to_btc(total_sats),
            "tx_count": chain.get("tx_count"),
        },
    }


def btc_transactions(args: dict) -> dict:
    """Recent BTC transactions for an address."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    limit = int(args.get("limit", 20) or 20)
    resp = _get(f"{_BLOCKSTREAM}/address/{addr}/txs")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "blockstream request failed")}
    txs = resp.get("json") or []
    if not isinstance(txs, list):
        return {"ok": False, "error": "unexpected blockstream response"}
    out = []
    for tx in txs[:limit]:
        status = tx.get("status") or {}
        out.append({
            "txid": tx.get("txid"),
            "confirmed": status.get("confirmed"),
            "block_height": status.get("block_height"),
            "block_time": status.get("block_time"),
            "fee_sats": tx.get("fee"),
            "size": tx.get("size"),
            "vin_count": len(tx.get("vin") or []),
            "vout_count": len(tx.get("vout") or []),
        })
    return {"ok": True, "result": {"address": addr, "count": len(out), "transactions": out}}


def btc_tx_status(args: dict) -> dict:
    """Status of a BTC transaction."""
    try:
        tx_hash = str(_require_arg(args, "tx_hash")).strip()
    except KeyError:
        return {"ok": False, "error": "tx_hash is required"}
    resp = _get(f"{_BLOCKSTREAM}/tx/{tx_hash}")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "blockstream request failed")}
    data = resp.get("json") or {}
    status = data.get("status") or {}
    return {
        "ok": True,
        "result": {
            "txid": data.get("txid"),
            "confirmed": status.get("confirmed"),
            "block_height": status.get("block_height"),
            "block_time": status.get("block_time"),
            "fee_sats": data.get("fee"),
            "size": data.get("size"),
            "weight": data.get("weight"),
        },
    }


def btc_fees(args: dict) -> dict:
    """Current BTC mempool fee estimates (sat/vB)."""
    resp = _get(f"{_BLOCKSTREAM}/fee-estimates")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "blockstream request failed")}
    data = resp.get("json") or {}
    # Blockstream returns {"1": 87.882, "2": 87.882, "3": ..., "6": ..., ...}
    pick = lambda k: data.get(k) if isinstance(data, dict) else None
    return {
        "ok": True,
        "result": {
            "next_block": pick("1"),
            "thirty_min": pick("3"),
            "hour": pick("6"),
            "day": pick("144"),
            "all": data,
        },
    }


# ──────────────────────────────────────────────────────────────────────────
# ENS
# ──────────────────────────────────────────────────────────────────────────


def ens_resolve(args: dict) -> dict:
    """ENS name (foo.eth) → address."""
    try:
        name = str(_require_arg(args, "name")).strip().lower()
    except KeyError:
        return {"ok": False, "error": "name is required"}
    resp = _etherscan({"module": "ens", "action": "lookup", "name": name})
    if resp.get("ok"):
        addr = resp.get("result")
        if addr and isinstance(addr, str) and addr.startswith("0x"):
            return {"ok": True, "result": {"name": name, "address": addr}}
        return {"ok": False, "error": f"could not resolve {name}"}
    return resp


def ens_reverse(args: dict) -> dict:
    """Address → ENS name (reverse resolution)."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    resp = _etherscan({"module": "ens", "action": "reverse", "address": addr})
    if resp.get("ok"):
        name = resp.get("result")
        if name and isinstance(name, str):
            return {"ok": True, "result": {"address": addr, "name": name}}
        return {"ok": False, "error": f"no reverse ENS for {addr}"}
    return resp


# ──────────────────────────────────────────────────────────────────────────
# NFTs
# ──────────────────────────────────────────────────────────────────────────


def nft_owned_by(args: dict) -> dict:
    """NFTs owned by an address. Requires ALCHEMY_API_KEY."""
    try:
        addr = str(_require_arg(args, "address")).strip()
    except KeyError:
        return {"ok": False, "error": "address is required"}
    chain = str(args.get("chain", "ethereum")).lower().strip()
    limit = int(args.get("limit", 20) or 20)

    key = _env("ALCHEMY_API_KEY")
    if not key:
        return {"ok": False, "error": "ALCHEMY_API_KEY not set"}

    base_by_chain = {
        "ethereum": f"https://eth-mainnet.g.alchemy.com/nft/v3/{key}",
        "polygon": f"https://polygon-mainnet.g.alchemy.com/nft/v3/{key}",
        "arbitrum": f"https://arb-mainnet.g.alchemy.com/nft/v3/{key}",
        "optimism": f"https://opt-mainnet.g.alchemy.com/nft/v3/{key}",
        "base": f"https://base-mainnet.g.alchemy.com/nft/v3/{key}",
    }
    base = base_by_chain.get(chain)
    if not base:
        return {"ok": False, "error": f"unsupported chain: {chain}"}

    resp = _get(f"{base}/getNFTsForOwner",
                params={"owner": addr, "pageSize": max(1, min(limit, 100)), "withMetadata": "true"})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "alchemy request failed")}
    data = resp.get("json") or {}
    owned = data.get("ownedNfts") or []
    out = []
    for n in owned[:limit]:
        contract = n.get("contract") or {}
        out.append({
            "contract": contract.get("address"),
            "name": contract.get("name") or (n.get("contract") or {}).get("name"),
            "token_id": n.get("tokenId"),
            "title": n.get("name") or n.get("title"),
            "token_type": n.get("tokenType"),
            "image": (n.get("image") or {}).get("cachedUrl") or (n.get("image") or {}).get("originalUrl"),
        })
    return {
        "ok": True,
        "result": {
            "address": addr,
            "chain": chain,
            "count": len(out),
            "total_count": data.get("totalCount"),
            "nfts": out,
        },
    }


def nft_collection_floor(args: dict) -> dict:
    """Floor price for an OpenSea collection slug."""
    try:
        slug = str(_require_arg(args, "slug")).strip().lower()
    except KeyError:
        return {"ok": False, "error": "slug is required"}
    headers = {}
    key = _env("OPENSEA_API_KEY")
    if key:
        headers["X-API-KEY"] = key
    resp = _get(f"https://api.opensea.io/api/v2/collections/{slug}/stats", headers=headers)
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "opensea request failed")}
    data = resp.get("json") or {}
    total = data.get("total") or {}
    return {
        "ok": True,
        "result": {
            "slug": slug,
            "floor_price": total.get("floor_price"),
            "floor_price_symbol": total.get("floor_price_symbol"),
            "volume": total.get("volume"),
            "num_owners": total.get("num_owners"),
            "market_cap": total.get("market_cap"),
            "average_price": total.get("average_price"),
            "raw": data,
        },
    }


def nft_metadata(args: dict) -> dict:
    """Metadata for a single NFT (Ethereum mainnet)."""
    try:
        contract = str(_require_arg(args, "contract")).strip()
        token_id = str(_require_arg(args, "token_id")).strip()
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}

    key = _env("ALCHEMY_API_KEY")
    if not key:
        # Fall back to OpenSea v2.
        headers = {}
        os_key = _env("OPENSEA_API_KEY")
        if os_key:
            headers["X-API-KEY"] = os_key
        resp = _get(f"https://api.opensea.io/api/v2/chain/ethereum/contract/{contract}/nfts/{token_id}",
                    headers=headers)
        if not resp.get("ok"):
            return {"ok": False, "error": resp.get("error", "opensea metadata failed")}
        data = (resp.get("json") or {}).get("nft") or {}
        return {
            "ok": True,
            "result": {
                "contract": contract,
                "token_id": token_id,
                "name": data.get("name"),
                "description": data.get("description"),
                "image_url": data.get("image_url"),
                "collection": data.get("collection"),
                "raw": data,
            },
        }

    base = f"https://eth-mainnet.g.alchemy.com/nft/v3/{key}"
    resp = _get(f"{base}/getNFTMetadata",
                params={"contractAddress": contract, "tokenId": token_id})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "alchemy metadata failed")}
    data = resp.get("json") or {}
    return {
        "ok": True,
        "result": {
            "contract": contract,
            "token_id": token_id,
            "name": data.get("name"),
            "description": data.get("description"),
            "token_type": data.get("tokenType"),
            "image": (data.get("image") or {}).get("cachedUrl"),
            "collection": (data.get("contract") or {}).get("name"),
            "raw": data,
        },
    }


# ──────────────────────────────────────────────────────────────────────────
# EXCHANGES (READ-ONLY)
# ──────────────────────────────────────────────────────────────────────────


def binance_price(args: dict) -> dict:
    """Spot price for a Binance symbol like 'BTCUSDT'."""
    try:
        symbol = str(_require_arg(args, "symbol")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "symbol is required"}
    resp = _get("https://api.binance.com/api/v3/ticker/price", params={"symbol": symbol})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "binance request failed")}
    data = resp.get("json") or {}
    price = data.get("price")
    try:
        price_f = float(price) if price is not None else None
    except (TypeError, ValueError):
        price_f = None
    return {"ok": True, "result": {"symbol": symbol, "price": price_f, "raw": data}}


def binance_klines(args: dict) -> dict:
    """Candles for a Binance symbol. interval default 1d, limit default 20."""
    try:
        symbol = str(_require_arg(args, "symbol")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "symbol is required"}
    interval = str(args.get("interval", "1d")).strip()
    limit = int(args.get("limit", 20) or 20)
    resp = _get("https://api.binance.com/api/v3/klines",
                params={"symbol": symbol, "interval": interval, "limit": max(1, min(limit, 1000))})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "binance klines failed")}
    raw = resp.get("json") or []
    candles = []
    for k in raw:
        try:
            candles.append({
                "open_time": k[0],
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": k[6],
            })
        except (TypeError, ValueError, IndexError):
            continue
    return {"ok": True, "result": {"symbol": symbol, "interval": interval, "count": len(candles), "candles": candles}}


def coinbase_price(args: dict) -> dict:
    """Coinbase spot price. symbol like 'BTC-USD'."""
    try:
        symbol = str(_require_arg(args, "symbol")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "symbol is required"}
    resp = _get(f"https://api.coinbase.com/v2/prices/{symbol}/spot")
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "coinbase request failed")}
    data = (resp.get("json") or {}).get("data") or {}
    amt = data.get("amount")
    try:
        amt_f = float(amt) if amt is not None else None
    except (TypeError, ValueError):
        amt_f = None
    return {"ok": True, "result": {"symbol": symbol, "price": amt_f, "currency": data.get("currency"), "base": data.get("base")}}


def kraken_price(args: dict) -> dict:
    """Kraken ticker for a pair like 'XBTUSD' or 'ETHUSD'."""
    try:
        pair = str(_require_arg(args, "pair")).upper().strip()
    except KeyError:
        return {"ok": False, "error": "pair is required"}
    resp = _get("https://api.kraken.com/0/public/Ticker", params={"pair": pair})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "kraken request failed")}
    data = resp.get("json") or {}
    if data.get("error"):
        err = data.get("error")
        if isinstance(err, list) and err:
            return {"ok": False, "error": "; ".join(str(x) for x in err)}
    result = data.get("result") or {}
    if not result:
        return {"ok": False, "error": "no result from kraken"}
    # Kraken returns one key inside result.
    key0 = next(iter(result.keys()))
    info = result[key0] or {}
    last = None
    if isinstance(info.get("c"), list) and info["c"]:
        try:
            last = float(info["c"][0])
        except (TypeError, ValueError):
            last = None
    return {
        "ok": True,
        "result": {
            "pair": pair,
            "kraken_pair": key0,
            "last": last,
            "ask": info.get("a", [None])[0] if isinstance(info.get("a"), list) else None,
            "bid": info.get("b", [None])[0] if isinstance(info.get("b"), list) else None,
            "high_24h": info.get("h", [None])[0] if isinstance(info.get("h"), list) else None,
            "low_24h": info.get("l", [None])[0] if isinstance(info.get("l"), list) else None,
            "volume_24h": info.get("v", [None])[0] if isinstance(info.get("v"), list) else None,
        },
    }


# ──────────────────────────────────────────────────────────────────────────
# COINGECKO HELPERS
# ──────────────────────────────────────────────────────────────────────────


_COINGECKO = "https://api.coingecko.com/api/v3"

# Common symbol → CoinGecko id mapping. Anything outside this list is
# resolved with /search.
_CG_SYMBOL_MAP = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "ADA": "cardano",
    "DOGE": "dogecoin",
    "MATIC": "matic-network",
    "DOT": "polkadot",
    "AVAX": "avalanche-2",
    "LINK": "chainlink",
    "LTC": "litecoin",
    "XRP": "ripple",
    "ATOM": "cosmos",
    "ARB": "arbitrum",
    "OP": "optimism",
    "USDT": "tether",
    "USDC": "usd-coin",
    "DAI": "dai",
    "BNB": "binancecoin",
    "TRX": "tron",
    "TON": "the-open-network",
    "SHIB": "shiba-inu",
    "PEPE": "pepe",
    "UNI": "uniswap",
    "AAVE": "aave",
    "NEAR": "near",
    "APT": "aptos",
}


def _cg_id_for(symbol: str) -> Optional[str]:
    s = symbol.upper().strip()
    if s in _CG_SYMBOL_MAP:
        return _CG_SYMBOL_MAP[s]
    resp = _get(f"{_COINGECKO}/search", params={"query": s.lower()})
    if not resp.get("ok"):
        return None
    coins = (resp.get("json") or {}).get("coins") or []
    for c in coins:
        if str(c.get("symbol", "")).upper() == s:
            return c.get("id")
    if coins:
        return coins[0].get("id")
    return None


def _cg_prices(ids: List[str], vs: str = "usd") -> Dict[str, Any]:
    if not ids:
        return {"ok": True, "result": {}}
    resp = _get(f"{_COINGECKO}/simple/price",
                params={"ids": ",".join(ids), "vs_currencies": vs})
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "coingecko request failed")}
    return {"ok": True, "result": resp.get("json") or {}}


# ──────────────────────────────────────────────────────────────────────────
# PORTFOLIO
# ──────────────────────────────────────────────────────────────────────────


def portfolio_define(args: dict) -> dict:
    """Define or replace a named portfolio. holdings=[{"symbol":"BTC","amount":0.5}, ...]"""
    try:
        name = str(_require_arg(args, "name")).strip()
        holdings = _require_arg(args, "holdings")
    except KeyError as e:
        return {"ok": False, "error": f"{e.args[0]} is required"}
    if not isinstance(holdings, list):
        return {"ok": False, "error": "holdings must be a list of {symbol, amount}"}

    clean: List[Dict[str, Any]] = []
    for h in holdings:
        if not isinstance(h, dict):
            continue
        sym = str(h.get("symbol", "")).upper().strip()
        try:
            amt = float(h.get("amount", 0))
        except (TypeError, ValueError):
            continue
        if not sym or amt <= 0:
            continue
        clean.append({"symbol": sym, "amount": amt})

    if not clean:
        return {"ok": False, "error": "no valid holdings provided"}

    data = _load_portfolios()
    data[name] = {
        "name": name,
        "holdings": clean,
        "created": data.get(name, {}).get("created") or int(time.time()),
        "updated": int(time.time()),
    }
    err = _save_portfolios(data)
    if err:
        return {"ok": False, "error": err}
    return {"ok": True, "result": data[name]}


def portfolio_value(args: dict) -> dict:
    """Current USD value of a named portfolio."""
    try:
        name = str(_require_arg(args, "name")).strip()
    except KeyError:
        return {"ok": False, "error": "name is required"}
    data = _load_portfolios()
    pf = data.get(name)
    if not pf:
        return {"ok": False, "error": f"portfolio '{name}' not found"}
    holdings = pf.get("holdings") or []
    if not holdings:
        return {"ok": True, "result": {"name": name, "total_usd": 0.0, "lines": []}}

    # Resolve symbol → coingecko id.
    sym_to_id: Dict[str, str] = {}
    for h in holdings:
        sym = str(h.get("symbol", "")).upper()
        cid = _cg_id_for(sym)
        if cid:
            sym_to_id[sym] = cid

    if not sym_to_id:
        return {"ok": False, "error": "could not resolve any symbols to CoinGecko ids"}

    prices_resp = _cg_prices(list(set(sym_to_id.values())), vs="usd")
    if not prices_resp.get("ok"):
        return prices_resp
    prices = prices_resp.get("result") or {}

    total = 0.0
    lines = []
    for h in holdings:
        sym = str(h.get("symbol", "")).upper()
        amt = float(h.get("amount", 0))
        cid = sym_to_id.get(sym)
        price = None
        if cid:
            price = ((prices.get(cid) or {}).get("usd"))
        value = float(price) * amt if price is not None else None
        if value is not None:
            total += value
        lines.append({
            "symbol": sym,
            "amount": amt,
            "price_usd": price,
            "value_usd": value,
        })
    return {"ok": True, "result": {"name": name, "total_usd": round(total, 2), "lines": lines, "as_of": int(time.time())}}


def portfolio_list(args: dict) -> dict:
    """List all defined portfolios."""
    data = _load_portfolios()
    summaries = []
    for name, pf in data.items():
        summaries.append({
            "name": name,
            "holdings_count": len(pf.get("holdings") or []),
            "updated": pf.get("updated"),
            "created": pf.get("created"),
        })
    return {"ok": True, "result": {"count": len(summaries), "portfolios": summaries}}


def portfolio_delete(args: dict) -> dict:
    """Delete a named portfolio."""
    try:
        name = str(_require_arg(args, "name")).strip()
    except KeyError:
        return {"ok": False, "error": "name is required"}
    data = _load_portfolios()
    if name not in data:
        return {"ok": False, "error": f"portfolio '{name}' not found"}
    del data[name]
    err = _save_portfolios(data)
    if err:
        return {"ok": False, "error": err}
    return {"ok": True, "result": {"deleted": name}}


# ──────────────────────────────────────────────────────────────────────────
# MISC
# ──────────────────────────────────────────────────────────────────────────


def _btc_usd_price() -> Optional[float]:
    resp = _get(f"{_COINGECKO}/simple/price", params={"ids": "bitcoin", "vs_currencies": "usd"})
    if not resp.get("ok"):
        return None
    data = (resp.get("json") or {}).get("bitcoin") or {}
    try:
        return float(data.get("usd"))
    except (TypeError, ValueError):
        return None


def usd_to_btc(args: dict) -> dict:
    """Convert a USD amount to BTC using current CoinGecko price."""
    try:
        amount = float(_require_arg(args, "amount"))
    except (KeyError, TypeError, ValueError):
        return {"ok": False, "error": "amount (number) is required"}
    price = _btc_usd_price()
    if price is None or price <= 0:
        return {"ok": False, "error": "could not fetch BTC/USD price"}
    btc = amount / price
    return {"ok": True, "result": {"usd": amount, "btc": btc, "price_usd": price}}


def btc_to_usd(args: dict) -> dict:
    """Convert a BTC amount to USD using current CoinGecko price."""
    try:
        amount = float(_require_arg(args, "amount"))
    except (KeyError, TypeError, ValueError):
        return {"ok": False, "error": "amount (number) is required"}
    price = _btc_usd_price()
    if price is None or price <= 0:
        return {"ok": False, "error": "could not fetch BTC/USD price"}
    usd = amount * price
    return {"ok": True, "result": {"btc": amount, "usd": usd, "price_usd": price}}


def market_cap_top(args: dict) -> dict:
    """Top coins by market cap (CoinGecko)."""
    limit = int(args.get("limit", 20) or 20)
    resp = _get(f"{_COINGECKO}/coins/markets",
                params={
                    "vs_currency": "usd",
                    "order": "market_cap_desc",
                    "per_page": max(1, min(limit, 250)),
                    "page": 1,
                    "sparkline": "false",
                })
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "coingecko markets failed")}
    rows = resp.get("json") or []
    out = []
    for c in rows[:limit]:
        out.append({
            "rank": c.get("market_cap_rank"),
            "id": c.get("id"),
            "symbol": str(c.get("symbol", "")).upper(),
            "name": c.get("name"),
            "price_usd": c.get("current_price"),
            "market_cap_usd": c.get("market_cap"),
            "volume_24h_usd": c.get("total_volume"),
            "change_24h_pct": c.get("price_change_percentage_24h"),
        })
    return {"ok": True, "result": {"count": len(out), "coins": out}}


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Ethereum
    "crypto.eth_balance": eth_balance,
    "crypto.eth_token_balance": eth_token_balance,
    "crypto.eth_transactions": eth_transactions,
    "crypto.eth_gas_price": eth_gas_price,
    "crypto.eth_block_number": eth_block_number,
    "crypto.eth_tx_status": eth_tx_status,
    # Bitcoin
    "crypto.btc_balance": btc_balance,
    "crypto.btc_transactions": btc_transactions,
    "crypto.btc_tx_status": btc_tx_status,
    "crypto.btc_fees": btc_fees,
    # ENS
    "crypto.ens_resolve": ens_resolve,
    "crypto.ens_reverse": ens_reverse,
    # NFTs
    "crypto.nft_owned_by": nft_owned_by,
    "crypto.nft_collection_floor": nft_collection_floor,
    "crypto.nft_metadata": nft_metadata,
    # Exchanges
    "crypto.binance_price": binance_price,
    "crypto.binance_klines": binance_klines,
    "crypto.coinbase_price": coinbase_price,
    "crypto.kraken_price": kraken_price,
    # Portfolio
    "crypto.portfolio_define": portfolio_define,
    "crypto.portfolio_value": portfolio_value,
    "crypto.portfolio_list": portfolio_list,
    "crypto.portfolio_delete": portfolio_delete,
    # Misc
    "crypto.usd_to_btc": usd_to_btc,
    "crypto.btc_to_usd": btc_to_usd,
    "crypto.market_cap_top": market_cap_top,
}
