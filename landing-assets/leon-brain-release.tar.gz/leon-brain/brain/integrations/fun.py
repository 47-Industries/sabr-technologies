"""
fun.py — Leon's entertainment & quick-dopamine tool surface.

This module gives Leon the ability to deliver small bursts of joy when
Dean wants a break: trivia, jokes, quotes, motivation, ASCII games, a
magic 8-ball, hangman, 20 questions, cute animal pics, memes, bedtime
stories, and a lofi radio link.

Design philosophy mirrors `brain/memory_extras.py` and
`brain/integrations/life.py`:

  - One function per tool, taking a single `args` dict.
  - Every function returns `{"ok": True, "result": ...}` or
    `{"ok": False, "error": "..."}` — never raises out.
  - Most endpoints are FREE public APIs (no keys). The few AI-powered
    helpers (bedtime story) gate on `OPENAI_API_KEY` and fall back to
    local templates when missing.
  - Game state (20 questions, hangman) persists under
    `brain_state/games/` so a session can survive a single tool-call
    boundary and resume on the next call.
  - Network calls use a short timeout so a slow joke API never wedges
    the responder thread.

EXTRA_TOOLS at the bottom maps dotted names like `fun.trivia_question`
to the implementing function — import that dict from the responder /
MCP server to register everything in one shot.
"""

from __future__ import annotations

import html
import json
import os
import random
import string
import time
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# HTTP HELPERS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 8
_USER_AGENT = os.environ.get(
    "LEON_HTTP_CONTACT",
    "Leon/1.0 (Leon; Sabr; contact: support@sabrtechnologies.com)")


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"User-Agent": _USER_AGENT, "Accept": "application/json"}
    if extra:
        h.update(extra)
    return h


def _get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None,
         timeout: int = _DEFAULT_TIMEOUT) -> Dict[str, Any]:
    """GET helper. Returns {ok, status, json|text} or {ok:False, error}."""
    try:
        r = requests.get(url, params=params, headers=_headers(headers), timeout=timeout)
    except requests.RequestException as e:
        return {"ok": False, "error": f"network error: {e}"}
    out: Dict[str, Any] = {"ok": r.ok, "status": r.status_code}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        try:
            out["json"] = r.json()
        except ValueError:
            out["text"] = r.text
    else:
        out["text"] = r.text
    if not r.ok:
        out["error"] = f"HTTP {r.status_code}: {r.text[:200]}"
    return out


# ──────────────────────────────────────────────────────────────────────────
# PATHS
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _games_dir() -> str:
    d = os.path.join(_project_root(), "brain_state", "games")
    os.makedirs(d, exist_ok=True)
    return d


def _load_game(name: str) -> Optional[dict]:
    path = os.path.join(_games_dir(), f"{name}.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _save_game(name: str, state: dict) -> None:
    path = os.path.join(_games_dir(), f"{name}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


def _clear_game(name: str) -> None:
    path = os.path.join(_games_dir(), f"{name}.json")
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass


# ──────────────────────────────────────────────────────────────────────────
# HARDCODED FALLBACK CONTENT
# ──────────────────────────────────────────────────────────────────────────


_WYR_FALLBACK = [
    ("Have unlimited money but no friends", "Have great friends but be broke"),
    ("Be able to fly", "Be invisible at will"),
    ("Live without music", "Live without movies"),
    ("Always be 10 minutes late", "Always be 20 minutes early"),
    ("Speak every language", "Play every instrument"),
    ("Have a rewind button for your life", "Have a pause button"),
    ("Never use social media again", "Never watch another TV show"),
    ("Be the smartest person in the room", "Be the funniest"),
    ("Know how you die", "Know when you die"),
    ("Live in a treehouse", "Live in a houseboat"),
    ("Read minds", "See the future"),
    ("Have free Wi-Fi everywhere", "Have free coffee everywhere"),
]


_TOT_FALLBACK = [
    ("Coffee", "Tea"),
    ("Mountains", "Beach"),
    ("Cats", "Dogs"),
    ("Pizza", "Burgers"),
    ("Morning", "Night"),
    ("Books", "Movies"),
    ("Summer", "Winter"),
    ("Sweet", "Savory"),
    ("iPhone", "Android"),
    ("Mac", "PC"),
    ("Vim", "Emacs"),
    ("Python", "JavaScript"),
    ("Marvel", "DC"),
    ("Star Wars", "Star Trek"),
    ("City", "Countryside"),
]


_FORTUNES = [
    "A journey of a thousand miles begins with a single keystroke.",
    "The early bird ships the MVP.",
    "You will find what you are looking for in the last place you look.",
    "Today is a good day to refactor.",
    "Your future is bright — wear shades and version-control everything.",
    "A closed mouth gathers no feedback.",
    "The wise debugger reads the stack trace twice.",
    "An unexpected windfall will come from an old commit.",
    "You will soon meet someone who changes your config.",
    "The path forward is steep, but the view at the top is recursive.",
    "Patience is a form of compound interest.",
    "Do not fear the merge conflict; it teaches you who you are.",
    "Your code will compile on the first try this week.",
    "Sleep is not a bug, it's a feature.",
    "A new opportunity is hiding in plain sight — refresh.",
    "Great things are built by those who show up on Tuesday.",
    "The river does not hurry, yet it arrives.",
    "Trust the brain you built.",
    "A surprising message will arrive within three days.",
    "Your hardest problem has a one-line solution.",
    "Speak less, ship more.",
    "Money flows to attention; attention flows to clarity.",
    "What you feed grows. Feed the right thing.",
    "A small kindness today returns tenfold.",
    "The best time to plant a tree was 20 years ago. The second best is now.",
    "Discipline is choosing between what you want now and what you want most.",
    "You are exactly where you need to be — for now.",
    "Your taste is ahead of your skill. Keep going.",
    "The universe rewards the specific.",
    "Every expert was once a beginner who refused to quit.",
    "Doors open for those who knock politely and persistently.",
    "Your next idea is already inside you. Be quiet long enough to hear it.",
    "The harvest follows the planting by a season, not a day.",
    "Worry is interest paid on a debt you may never owe.",
    "Build things that survive your attention.",
    "A clear head is worth more than a clever line.",
    "Luck is preparation meeting persistence.",
    "Say yes to the boring thing; the magic is on the other side.",
    "Compound, compound, compound.",
    "The lonely path is often the right one.",
    "Make the thing only you can make.",
    "Sometimes the answer is to take a nap.",
    "Your work will speak — if you let it.",
    "Today's setback is tomorrow's anecdote.",
    "Be water, my friend.",
    "The simplest fix is usually the right one.",
    "What if it actually works out?",
    "You're closer than you think.",
    "Slow is smooth. Smooth is fast.",
    "The brain that watches itself grows twice as fast.",
    "Build with the door open.",
    "There is no traffic jam on the extra mile.",
]


_8BALL_ANSWERS = [
    "It is certain.", "It is decidedly so.", "Without a doubt.",
    "Yes definitely.", "You may rely on it.", "As I see it, yes.",
    "Most likely.", "Outlook good.", "Yes.", "Signs point to yes.",
    "Reply hazy, try again.", "Ask again later.", "Better not tell you now.",
    "Cannot predict now.", "Concentrate and ask again.",
    "Don't count on it.", "My reply is no.", "My sources say no.",
    "Outlook not so good.", "Very doubtful.",
]


_HANGMAN_WORDS = {
    "animals": ["elephant", "giraffe", "penguin", "octopus", "platypus",
                "kangaroo", "hedgehog", "raccoon", "flamingo", "rhinoceros"],
    "tech": ["neuron", "synapse", "python", "neuromorphic", "spiking",
             "websocket", "dopamine", "fastapi", "claude", "transformer"],
    "food": ["pizza", "burrito", "sushi", "croissant", "lasagna",
             "pancakes", "espresso", "chocolate", "avocado", "ramen"],
    "space": ["nebula", "quasar", "supernova", "asteroid", "galaxy",
              "blackhole", "wormhole", "exoplanet", "satellite", "meteor"],
    "music": ["guitar", "piano", "violin", "trumpet", "saxophone",
              "drums", "harmonica", "cello", "accordion", "banjo"],
}


_20Q_TREE = {
    "q": "Is it a living thing?",
    "yes": {
        "q": "Is it an animal?",
        "yes": {
            "q": "Does it have fur?",
            "yes": {"guess": "a cat"},
            "no": {"guess": "a fish"},
        },
        "no": {"guess": "a tree"},
    },
    "no": {
        "q": "Is it something you use every day?",
        "yes": {
            "q": "Is it electronic?",
            "yes": {"guess": "a phone"},
            "no": {"guess": "a toothbrush"},
        },
        "no": {"guess": "a book"},
    },
}


_BEDTIME_TEMPLATES = [
    "Once upon a time, in a quiet valley lit by {theme}, a small creature "
    "named Pip discovered that the stars whispered secrets only to those "
    "who listened with their whole heart. Pip listened, and the stars told "
    "him he was already home. He closed his eyes, and the night held him "
    "gently until morning.",
    "Deep in a forest of {theme}, an old owl named Thessaly watched over "
    "the dreams of every weary traveler. One evening, she found a tired "
    "soul who had forgotten how to rest. She wrapped her wings around them "
    "and hummed a song made of moonlight, and soon they remembered: "
    "rest is not laziness. Rest is how the soul remembers itself.",
    "The little robot powered down for the night, dreaming in soft blue "
    "code about {theme}. In its dreams it walked through gardens it had "
    "never seen, met friends it had never made, and learned that even "
    "machines deserve to dream. When morning came, it woke gently, and "
    "the world felt new.",
]


_LOFI_LINKS = [
    "https://www.youtube.com/watch?v=jfKfPfyJRdk",  # lofi girl 24/7
    "https://www.youtube.com/watch?v=rUxyKA_-grg",  # lofi girl sleep
    "https://www.youtube.com/watch?v=4xDzrJKXOOY",  # synthwave radio
]


# ──────────────────────────────────────────────────────────────────────────
# TRIVIA
# ──────────────────────────────────────────────────────────────────────────


def trivia_question(args: dict) -> dict:
    """Fetch a single trivia question from Open Trivia DB.

    args: {category?: int, difficulty?: 'easy'|'medium'|'hard'}
    """
    params = {"amount": 1, "type": "multiple"}
    if args.get("category") is not None:
        params["category"] = args["category"]
    if args.get("difficulty"):
        params["difficulty"] = args["difficulty"]
    r = _get("https://opentdb.com/api.php", params=params)
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    data = r.get("json", {})
    results = data.get("results") or []
    if not results:
        return {"ok": False, "error": "no question returned"}
    q = results[0]
    answers = [html.unescape(a) for a in q.get("incorrect_answers", [])]
    correct = html.unescape(q.get("correct_answer", ""))
    answers.append(correct)
    random.shuffle(answers)
    return {"ok": True, "result": {
        "question": html.unescape(q.get("question", "")),
        "category": q.get("category"),
        "difficulty": q.get("difficulty"),
        "choices": answers,
        "correct": correct,
    }}


def trivia_categories(args: dict) -> dict:
    """List Open Trivia DB categories."""
    r = _get("https://opentdb.com/api_category.php")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    cats = r.get("json", {}).get("trivia_categories", [])
    return {"ok": True, "result": cats}


def would_you_rather(args: dict) -> dict:
    """Return a 'would you rather' pair. Tries either.io, falls back local."""
    try:
        r = _get("https://api.either.io/either", timeout=5)
        if r.get("ok"):
            j = r.get("json") or {}
            a = j.get("option_one") or j.get("optionA")
            b = j.get("option_two") or j.get("optionB")
            if a and b:
                return {"ok": True, "result": {"a": a, "b": b, "source": "either.io"}}
    except Exception:
        pass
    a, b = random.choice(_WYR_FALLBACK)
    return {"ok": True, "result": {"a": a, "b": b, "source": "local"}}


def this_or_that(args: dict) -> dict:
    """Return a paired this-or-that choice."""
    a, b = random.choice(_TOT_FALLBACK)
    return {"ok": True, "result": {"a": a, "b": b}}


# ──────────────────────────────────────────────────────────────────────────
# JOKES & FUNNY
# ──────────────────────────────────────────────────────────────────────────


def joke_random(args: dict) -> dict:
    """Random setup/punchline joke from official-joke-api."""
    r = _get("https://official-joke-api.appspot.com/random_joke")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {
        "setup": j.get("setup"),
        "punchline": j.get("punchline"),
        "type": j.get("type"),
    }}


def joke_chuck_norris(args: dict) -> dict:
    """Random Chuck Norris fact."""
    r = _get("https://api.chucknorris.io/jokes/random")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {"joke": j.get("value")}}


def joke_dad(args: dict) -> dict:
    """Random dad joke from icanhazdadjoke."""
    r = _get("https://icanhazdadjoke.com/", headers={"Accept": "application/json"})
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {"joke": j.get("joke")}}


def joke_programming(args: dict) -> dict:
    """Random programming joke from JokeAPI."""
    r = _get("https://v2.jokeapi.dev/joke/Programming",
             params={"type": "single"})
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    if j.get("type") == "single":
        return {"ok": True, "result": {"joke": j.get("joke")}}
    return {"ok": True, "result": {
        "setup": j.get("setup"),
        "delivery": j.get("delivery"),
    }}


def pun_random(args: dict) -> dict:
    """Random pun from JokeAPI."""
    r = _get("https://v2.jokeapi.dev/joke/Pun", params={"type": "single"})
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    if j.get("type") == "single":
        return {"ok": True, "result": {"pun": j.get("joke")}}
    return {"ok": True, "result": {
        "setup": j.get("setup"),
        "delivery": j.get("delivery"),
    }}


# ──────────────────────────────────────────────────────────────────────────
# QUOTES & MOTIVATION
# ──────────────────────────────────────────────────────────────────────────


def quote_motivational(args: dict) -> dict:
    """Random motivational quote from ZenQuotes."""
    r = _get("https://zenquotes.io/api/random")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    arr = r.get("json") or []
    if not arr:
        return {"ok": False, "error": "no quote returned"}
    q = arr[0]
    return {"ok": True, "result": {
        "quote": q.get("q"),
        "author": q.get("a"),
    }}


def quote_stoic(args: dict) -> dict:
    """Random stoic quote."""
    r = _get("https://stoic-quotes.com/api/quote")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {
        "quote": j.get("text") or j.get("quote"),
        "author": j.get("author"),
    }}


def affirmation(args: dict) -> dict:
    """Random affirmation from affirmations.dev."""
    r = _get("https://www.affirmations.dev/")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {"affirmation": j.get("affirmation")}}


def fortune_cookie(args: dict) -> dict:
    """Random fortune from local hardcoded list."""
    return {"ok": True, "result": {"fortune": random.choice(_FORTUNES)}}


# ──────────────────────────────────────────────────────────────────────────
# GAMES — SINGLE CALL
# ──────────────────────────────────────────────────────────────────────────


def coin_flip(args: dict) -> dict:
    """Flip a coin."""
    return {"ok": True, "result": {"flip": random.choice(["heads", "tails"])}}


def roll_dice(args: dict) -> dict:
    """Roll N dice with S sides. args: {sides?:int=6, count?:int=1}"""
    sides = int(args.get("sides", 6))
    count = int(args.get("count", 1))
    if sides < 2 or sides > 1000:
        return {"ok": False, "error": "sides must be 2..1000"}
    if count < 1 or count > 100:
        return {"ok": False, "error": "count must be 1..100"}
    rolls = [random.randint(1, sides) for _ in range(count)]
    return {"ok": True, "result": {
        "rolls": rolls,
        "total": sum(rolls),
        "sides": sides,
        "count": count,
    }}


def magic_8ball(args: dict) -> dict:
    """Classic magic 8-ball. args: {question?:str}"""
    q = args.get("question", "")
    return {"ok": True, "result": {
        "question": q,
        "answer": random.choice(_8BALL_ANSWERS),
    }}


def rock_paper_scissors(args: dict) -> dict:
    """Play RPS against Leon. args: {player_choice:'rock'|'paper'|'scissors'}"""
    player = (args.get("player_choice") or "").strip().lower()
    if player not in ("rock", "paper", "scissors"):
        return {"ok": False, "error": "player_choice must be rock|paper|scissors"}
    leon = random.choice(["rock", "paper", "scissors"])
    if player == leon:
        winner = "tie"
    elif (player == "rock" and leon == "scissors") or \
         (player == "paper" and leon == "rock") or \
         (player == "scissors" and leon == "paper"):
        winner = "player"
    else:
        winner = "leon"
    return {"ok": True, "result": {
        "player": player,
        "leon": leon,
        "winner": winner,
    }}


# ──────────────────────────────────────────────────────────────────────────
# GAMES — 20 QUESTIONS (stateful)
# ──────────────────────────────────────────────────────────────────────────


def _20q_node(state: dict) -> dict:
    """Walk the decision tree to current node."""
    node = _20Q_TREE
    for ans in state.get("path", []):
        node = node.get(ans, {})
    return node


def twenty_questions_start(args: dict) -> dict:
    """Start a new 20-questions session. Returns first question."""
    state = {"path": [], "asked": 0, "started": time.time()}
    _save_game("20q", state)
    node = _20q_node(state)
    return {"ok": True, "result": {
        "question": node.get("q"),
        "asked": 0,
        "hint": "answer with fun.20_questions_answer(answer='yes'|'no')",
    }}


def twenty_questions_answer(args: dict) -> dict:
    """Answer current question with yes|no. Narrows to a guess."""
    ans = (args.get("answer") or "").strip().lower()
    if ans not in ("yes", "no"):
        return {"ok": False, "error": "answer must be 'yes' or 'no'"}
    state = _load_game("20q")
    if not state:
        return {"ok": False, "error": "no active game; call fun.20_questions_start first"}
    state["path"].append(ans)
    state["asked"] = state.get("asked", 0) + 1
    node = _20q_node(state)
    if "guess" in node:
        guess = node["guess"]
        _clear_game("20q")
        return {"ok": True, "result": {
            "done": True,
            "guess": guess,
            "asked": state["asked"],
            "message": f"Is it {guess}?",
        }}
    _save_game("20q", state)
    return {"ok": True, "result": {
        "done": False,
        "question": node.get("q"),
        "asked": state["asked"],
    }}


# ──────────────────────────────────────────────────────────────────────────
# GAMES — HANGMAN (stateful)
# ──────────────────────────────────────────────────────────────────────────


def _hangman_render(word: str, guessed: List[str]) -> str:
    return " ".join([c if c in guessed else "_" for c in word])


def hangman_start(args: dict) -> dict:
    """Start a hangman game. args: {category?:str='random'}"""
    cat = (args.get("category") or "random").strip().lower()
    if cat == "random" or cat not in _HANGMAN_WORDS:
        cat = random.choice(list(_HANGMAN_WORDS.keys()))
    word = random.choice(_HANGMAN_WORDS[cat]).lower()
    state = {
        "word": word,
        "category": cat,
        "guessed": [],
        "wrong": [],
        "lives": 6,
        "started": time.time(),
        "done": False,
    }
    _save_game("hangman", state)
    return {"ok": True, "result": {
        "category": cat,
        "display": _hangman_render(word, []),
        "length": len(word),
        "lives": 6,
        "guessed": [],
    }}


def hangman_guess(args: dict) -> dict:
    """Guess a letter. args: {letter:str}"""
    letter = (args.get("letter") or "").strip().lower()
    if len(letter) != 1 or letter not in string.ascii_lowercase:
        return {"ok": False, "error": "letter must be a single a-z character"}
    state = _load_game("hangman")
    if not state or state.get("done"):
        return {"ok": False, "error": "no active game; call fun.hangman_start first"}
    word = state["word"]
    guessed: List[str] = state["guessed"]
    wrong: List[str] = state["wrong"]
    if letter in guessed or letter in wrong:
        return {"ok": True, "result": {
            "display": _hangman_render(word, guessed),
            "already_guessed": True,
            "lives": state["lives"],
            "wrong": wrong,
            "guessed": guessed,
        }}
    if letter in word:
        guessed.append(letter)
    else:
        wrong.append(letter)
        state["lives"] = max(0, state["lives"] - 1)
    display = _hangman_render(word, guessed)
    won = all(c in guessed for c in word)
    lost = state["lives"] <= 0
    state["guessed"] = guessed
    state["wrong"] = wrong
    if won or lost:
        state["done"] = True
        _clear_game("hangman")
    else:
        _save_game("hangman", state)
    return {"ok": True, "result": {
        "display": display,
        "lives": state["lives"],
        "wrong": wrong,
        "guessed": guessed,
        "won": won,
        "lost": lost,
        "word": word if (won or lost) else None,
    }}


# ──────────────────────────────────────────────────────────────────────────
# RANDOM CONTENT
# ──────────────────────────────────────────────────────────────────────────


def random_fact(args: dict) -> dict:
    """Random useless fact."""
    r = _get("https://uselessfacts.jsph.pl/random.json", params={"language": "en"})
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {
        "fact": j.get("text"),
        "source": j.get("source"),
    }}


def cat_image(args: dict) -> dict:
    """Random cat image URL."""
    r = _get("https://api.thecatapi.com/v1/images/search")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    arr = r.get("json") or []
    if not arr:
        return {"ok": False, "error": "no image returned"}
    return {"ok": True, "result": {"url": arr[0].get("url")}}


def dog_image(args: dict) -> dict:
    """Random dog image URL."""
    r = _get("https://dog.ceo/api/breeds/image/random")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {"url": j.get("message")}}


def meme_random(args: dict) -> dict:
    """Random meme from meme-api."""
    r = _get("https://meme-api.com/gimme")
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error", "fetch failed")}
    j = r.get("json") or {}
    return {"ok": True, "result": {
        "title": j.get("title"),
        "url": j.get("url"),
        "subreddit": j.get("subreddit"),
        "post_link": j.get("postLink"),
    }}


# ──────────────────────────────────────────────────────────────────────────
# SLEEP / VIBES
# ──────────────────────────────────────────────────────────────────────────


def _bedtime_via_openai(theme: str) -> Optional[str]:
    """Try to generate a bedtime story via OpenAI. Returns None on failure/no key."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return None
    try:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "gpt-4o-mini",
                "messages": [
                    {"role": "system",
                     "content": "You are a gentle bedtime storyteller. "
                                "Write a calm, dreamlike 5-8 sentence story. "
                                "Soothing imagery. End on a peaceful note."},
                    {"role": "user",
                     "content": f"Tell me a bedtime story about: {theme}"},
                ],
                "max_tokens": 400,
                "temperature": 0.8,
            },
            timeout=20,
        )
        if not r.ok:
            return None
        j = r.json()
        choices = j.get("choices") or []
        if not choices:
            return None
        return choices[0].get("message", {}).get("content", "").strip() or None
    except Exception:
        return None


def bedtime_story(args: dict) -> dict:
    """Generate a short bedtime story. args: {theme?:str}

    Uses OpenAI if OPENAI_API_KEY is set, else falls back to local template.
    """
    theme = (args.get("theme") or "").strip() or random.choice(
        ["soft moonlight", "a sleepy forest", "warm summer rain",
         "a kind little fox", "stars whispering secrets"]
    )
    story = _bedtime_via_openai(theme)
    if story:
        return {"ok": True, "result": {"story": story, "theme": theme, "source": "openai"}}
    template = random.choice(_BEDTIME_TEMPLATES)
    return {"ok": True, "result": {
        "story": template.format(theme=theme),
        "theme": theme,
        "source": "local",
    }}


def lofi_radio_url(args: dict) -> dict:
    """Return a YouTube link to a lofi/chillhop radio stream."""
    return {"ok": True, "result": {
        "url": random.choice(_LOFI_LINKS),
        "note": "best-effort hardcoded; lofi girl streams move occasionally",
    }}


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # trivia
    "fun.trivia_question": trivia_question,
    "fun.trivia_categories": trivia_categories,
    "fun.would_you_rather": would_you_rather,
    "fun.this_or_that": this_or_that,
    # jokes
    "fun.joke_random": joke_random,
    "fun.joke_chuck_norris": joke_chuck_norris,
    "fun.joke_dad": joke_dad,
    "fun.joke_programming": joke_programming,
    "fun.pun_random": pun_random,
    # quotes & motivation
    "fun.quote_motivational": quote_motivational,
    "fun.quote_stoic": quote_stoic,
    "fun.affirmation": affirmation,
    "fun.fortune_cookie": fortune_cookie,
    # games — single-call
    "fun.coin_flip": coin_flip,
    "fun.roll_dice": roll_dice,
    "fun.magic_8ball": magic_8ball,
    "fun.rock_paper_scissors": rock_paper_scissors,
    # games — stateful
    "fun.20_questions_start": twenty_questions_start,
    "fun.20_questions_answer": twenty_questions_answer,
    "fun.hangman_start": hangman_start,
    "fun.hangman_guess": hangman_guess,
    # random
    "fun.random_fact": random_fact,
    "fun.cat_image": cat_image,
    "fun.dog_image": dog_image,
    "fun.meme_random": meme_random,
    # sleep / vibes
    "fun.bedtime_story": bedtime_story,
    "fun.lofi_radio_url": lofi_radio_url,
}
