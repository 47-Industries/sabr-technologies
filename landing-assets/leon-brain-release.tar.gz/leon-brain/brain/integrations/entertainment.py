"""entertainment.py — Leon's entertainment data hub.

Spotify Web API (deep), TMDB (movies/TV), RAWG (games), Open Library (books),
Last.fm (music data), and lyrics.ovh (lyrics).

Each tool reads credentials lazily (env first, then `~/.openclaw/secrets.json`),
makes `requests` calls with a 10s default timeout, and returns the standard
`{ok, ...}` contract. Nothing here raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `ent.spotify_search`) to
callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET  (search, catalogue — free)
  - SPOTIFY_ACCESS_TOKEN                        (user data / playback — OAuth)
  - TMDB_API_KEY        (movies/TV — free key)
  - RAWG_API_KEY        (games — free key)
  - LASTFM_API_KEY      (music metadata — free key)

No key needed for Open Library or lyrics.ovh — both are open public APIs.

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 10.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file.

    Returns `{}` on any error — caller falls through to a missing-credential
    message. Never raises, never logs values.
    """
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, service: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {service}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _http_fail(resp: requests.Response, prefix: str = "HTTP") -> Dict[str, Any]:
    """Build a clean error envelope from a failed Response."""
    out: Dict[str, Any] = {"ok": False, "error": f"{prefix} {resp.status_code}"}
    try:
        out["detail"] = resp.json()
    except Exception:
        out["detail"] = resp.text[:500]
    return out


# ──────────────────────────────────────────────────────────────────────────
# SPOTIFY
# ──────────────────────────────────────────────────────────────────────────

_SPOTIFY_API = "https://api.spotify.com/v1"
_SPOTIFY_TOKEN_URL = "https://accounts.spotify.com/api/token"

# In-process cache for the client-credentials token.
_SPOTIFY_CC_TOKEN: Optional[str] = None
_SPOTIFY_CC_EXPIRES: float = 0.0


def _spotify_client_token() -> Dict[str, Any]:
    """Fetch (and cache) a client-credentials token for catalogue/search calls.

    Returns `{"ok": True, "token": "..."}` or a `{"ok": False, "error": ...}`
    envelope. Token is cached in-process until ~60s before expiry.
    """
    global _SPOTIFY_CC_TOKEN, _SPOTIFY_CC_EXPIRES
    if _SPOTIFY_CC_TOKEN and time.time() < _SPOTIFY_CC_EXPIRES:
        return {"ok": True, "token": _SPOTIFY_CC_TOKEN}
    cid = _get_secret("SPOTIFY_CLIENT_ID")
    secret = _get_secret("SPOTIFY_CLIENT_SECRET")
    if not cid or not secret:
        return _missing("SPOTIFY_CLIENT_ID + SPOTIFY_CLIENT_SECRET", "Spotify")
    try:
        r = requests.post(
            _SPOTIFY_TOKEN_URL,
            data={"grant_type": "client_credentials"},
            auth=(cid, secret),
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return _http_fail(r, "spotify token HTTP")
        payload = r.json()
        token = payload.get("access_token")
        if not token:
            return {"ok": False, "error": "spotify: no access_token returned"}
        _SPOTIFY_CC_TOKEN = token
        _SPOTIFY_CC_EXPIRES = time.time() + max(0, int(payload.get("expires_in", 3600)) - 60)
        return {"ok": True, "token": token}
    except Exception as e:
        return _err(e)


def _spotify_user_token() -> Dict[str, Any]:
    """Return the OAuth user token needed for personal data / playback."""
    tok = _get_secret("SPOTIFY_ACCESS_TOKEN")
    if not tok:
        return _missing("SPOTIFY_ACCESS_TOKEN", "Spotify user data/playback")
    return {"ok": True, "token": tok}


def _spotify_get(path: str, params: Optional[dict] = None,
                 user: bool = False) -> Dict[str, Any]:
    """GET a Spotify endpoint. `user=True` uses the OAuth user token, else the
    client-credentials token. Returns `{"ok": True, "json": ...}` or an error.
    """
    auth = _spotify_user_token() if user else _spotify_client_token()
    if not auth.get("ok"):
        return auth
    try:
        r = requests.get(
            f"{_SPOTIFY_API}/{path.lstrip('/')}",
            headers={"Authorization": f"Bearer {auth['token']}"},
            params=params or {},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code == 204:
            return {"ok": True, "json": None, "status": 204}
        if r.status_code >= 400:
            return _http_fail(r, "spotify HTTP")
        return {"ok": True, "json": r.json()}
    except Exception as e:
        return _err(e)


def _spotify_post(path: str, body: Optional[dict] = None) -> Dict[str, Any]:
    """POST to a Spotify endpoint with the OAuth user token."""
    auth = _spotify_user_token()
    if not auth.get("ok"):
        return auth
    try:
        r = requests.post(
            f"{_SPOTIFY_API}/{path.lstrip('/')}",
            headers={"Authorization": f"Bearer {auth['token']}",
                     "Content-Type": "application/json"},
            json=body or {},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code >= 400:
            return _http_fail(r, "spotify HTTP")
        try:
            return {"ok": True, "json": r.json()}
        except Exception:
            return {"ok": True, "json": None, "status": r.status_code}
    except Exception as e:
        return _err(e)


def _track_compact(t: dict) -> Dict[str, Any]:
    """Reduce a Spotify track object to the fields Leon cares about."""
    if not isinstance(t, dict):
        return {}
    return {
        "id": t.get("id"),
        "name": t.get("name"),
        "uri": t.get("uri"),
        "artists": [a.get("name") for a in t.get("artists", []) if isinstance(a, dict)],
        "album": (t.get("album") or {}).get("name"),
        "duration_ms": t.get("duration_ms"),
        "popularity": t.get("popularity"),
        "explicit": t.get("explicit"),
        "preview_url": t.get("preview_url"),
        "external_url": (t.get("external_urls") or {}).get("spotify"),
    }


def _spotify_search(args: dict) -> dict:
    """Search the Spotify catalogue. type: track/album/artist/playlist."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        stype = str(args.get("type", "track")).strip().lower()
        if stype not in ("track", "album", "artist", "playlist"):
            return {"ok": False, "error": "type must be track/album/artist/playlist"}
        limit = max(1, min(50, int(args.get("limit", 10))))
        res = _spotify_get("search", {"q": query, "type": stype, "limit": limit})
        if not res.get("ok"):
            return res
        bucket = (res["json"] or {}).get(f"{stype}s", {}) or {}
        items = bucket.get("items", []) or []
        if stype == "track":
            items = [_track_compact(i) for i in items if i]
        elif stype == "artist":
            items = [{"id": i.get("id"), "name": i.get("name"),
                      "genres": i.get("genres", []),
                      "popularity": i.get("popularity"),
                      "followers": (i.get("followers") or {}).get("total"),
                      "uri": i.get("uri")} for i in items if i]
        elif stype == "album":
            items = [{"id": i.get("id"), "name": i.get("name"),
                      "artists": [a.get("name") for a in i.get("artists", [])],
                      "release_date": i.get("release_date"),
                      "total_tracks": i.get("total_tracks"),
                      "uri": i.get("uri")} for i in items if i]
        else:  # playlist
            items = [{"id": i.get("id"), "name": i.get("name"),
                      "owner": (i.get("owner") or {}).get("display_name"),
                      "tracks": (i.get("tracks") or {}).get("total"),
                      "uri": i.get("uri")} for i in items if i]
        return {"ok": True, "type": stype, "results": items, "count": len(items)}
    except Exception as e:
        return _err(e)


def _spotify_track_info(args: dict) -> dict:
    """Full details for a single track."""
    try:
        track_id = str(args.get("track_id", "")).strip()
        if not track_id:
            return {"ok": False, "error": "track_id required"}
        res = _spotify_get(f"tracks/{track_id}")
        if not res.get("ok"):
            return res
        return {"ok": True, "track": _track_compact(res["json"] or {})}
    except Exception as e:
        return _err(e)


def _spotify_artist_top_tracks(args: dict) -> dict:
    """Top tracks for an artist (market defaults to US)."""
    try:
        artist_id = str(args.get("artist_id", "")).strip()
        if not artist_id:
            return {"ok": False, "error": "artist_id required"}
        market = str(args.get("market", "US")).strip() or "US"
        res = _spotify_get(f"artists/{artist_id}/top-tracks", {"market": market})
        if not res.get("ok"):
            return res
        tracks = (res["json"] or {}).get("tracks", []) or []
        compact = [_track_compact(t) for t in tracks]
        return {"ok": True, "tracks": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _spotify_recommendations(args: dict) -> dict:
    """Recommendation engine — seed with track ids and/or genres."""
    try:
        seed_tracks = args.get("seed_tracks")
        seed_genres = args.get("seed_genres")
        limit = max(1, min(100, int(args.get("limit", 20))))
        params: Dict[str, Any] = {"limit": limit}
        if seed_tracks:
            if isinstance(seed_tracks, str):
                seed_tracks = [s.strip() for s in seed_tracks.split(",") if s.strip()]
            params["seed_tracks"] = ",".join(seed_tracks[:5])
        if seed_genres:
            if isinstance(seed_genres, str):
                seed_genres = [s.strip() for s in seed_genres.split(",") if s.strip()]
            params["seed_genres"] = ",".join(seed_genres[:5])
        if "seed_tracks" not in params and "seed_genres" not in params:
            return {"ok": False, "error": "seed_tracks or seed_genres required"}
        res = _spotify_get("recommendations", params)
        if not res.get("ok"):
            return res
        tracks = (res["json"] or {}).get("tracks", []) or []
        compact = [_track_compact(t) for t in tracks]
        return {"ok": True, "tracks": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _spotify_my_playlists(args: dict) -> dict:
    """List the authenticated user's playlists (needs user token)."""
    try:
        limit = max(1, min(50, int(args.get("limit", 50))))
        res = _spotify_get("me/playlists", {"limit": limit}, user=True)
        if not res.get("ok"):
            return res
        items = (res["json"] or {}).get("items", []) or []
        compact = [{"id": p.get("id"), "name": p.get("name"),
                    "tracks": (p.get("tracks") or {}).get("total"),
                    "public": p.get("public"),
                    "owner": (p.get("owner") or {}).get("display_name"),
                    "uri": p.get("uri")} for p in items if p]
        return {"ok": True, "playlists": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _spotify_playlist_tracks(args: dict) -> dict:
    """List tracks inside a playlist."""
    try:
        playlist_id = str(args.get("playlist_id", "")).strip()
        if not playlist_id:
            return {"ok": False, "error": "playlist_id required"}
        limit = max(1, min(100, int(args.get("limit", 100))))
        res = _spotify_get(f"playlists/{playlist_id}/tracks", {"limit": limit})
        if not res.get("ok"):
            return res
        items = (res["json"] or {}).get("items", []) or []
        compact = [_track_compact((i or {}).get("track") or {}) for i in items]
        compact = [t for t in compact if t.get("id")]
        return {"ok": True, "tracks": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


def _spotify_create_playlist(args: dict) -> dict:
    """Create a new playlist on the authenticated user's account. MEDIUM action."""
    try:
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        description = args.get("description")
        public = bool(args.get("public", False))
        # need the user's id first
        me = _spotify_get("me", user=True)
        if not me.get("ok"):
            return me
        uid = (me["json"] or {}).get("id")
        if not uid:
            return {"ok": False, "error": "could not resolve current user id"}
        body: Dict[str, Any] = {"name": name, "public": public}
        if description:
            body["description"] = str(description)
        res = _spotify_post(f"users/{uid}/playlists", body)
        if not res.get("ok"):
            return res
        pl = res["json"] or {}
        return {"ok": True, "playlist_id": pl.get("id"),
                "name": pl.get("name"), "uri": pl.get("uri"),
                "external_url": (pl.get("external_urls") or {}).get("spotify")}
    except Exception as e:
        return _err(e)


def _spotify_add_to_playlist(args: dict) -> dict:
    """Add tracks (by spotify:track:… URIs) to a playlist. MEDIUM action."""
    try:
        playlist_id = str(args.get("playlist_id", "")).strip()
        track_uris = args.get("track_uris")
        if not playlist_id:
            return {"ok": False, "error": "playlist_id required"}
        if not track_uris:
            return {"ok": False, "error": "track_uris required"}
        if isinstance(track_uris, str):
            track_uris = [u.strip() for u in track_uris.split(",") if u.strip()]
        # normalise bare ids to full URIs
        uris = [u if u.startswith("spotify:") else f"spotify:track:{u}"
                for u in track_uris]
        res = _spotify_post(f"playlists/{playlist_id}/tracks", {"uris": uris[:100]})
        if not res.get("ok"):
            return res
        return {"ok": True, "playlist_id": playlist_id, "added": len(uris[:100]),
                "snapshot_id": (res["json"] or {}).get("snapshot_id")}
    except Exception as e:
        return _err(e)


def _spotify_currently_playing(args: dict) -> dict:
    """What the user is playing right now (needs user token)."""
    try:
        res = _spotify_get("me/player/currently-playing", user=True)
        if not res.get("ok"):
            return res
        data = res["json"]
        if not data:
            return {"ok": True, "playing": False}
        item = data.get("item") or {}
        return {"ok": True, "playing": data.get("is_playing", False),
                "progress_ms": data.get("progress_ms"),
                "track": _track_compact(item)}
    except Exception as e:
        return _err(e)


def _spotify_audio_features(args: dict) -> dict:
    """Audio analysis for a track — tempo, energy, danceability, valence, etc."""
    try:
        track_id = str(args.get("track_id", "")).strip()
        if not track_id:
            return {"ok": False, "error": "track_id required"}
        res = _spotify_get(f"audio-features/{track_id}")
        if not res.get("ok"):
            return res
        f = res["json"] or {}
        return {"ok": True, "features": {
            "tempo": f.get("tempo"),
            "energy": f.get("energy"),
            "danceability": f.get("danceability"),
            "valence": f.get("valence"),
            "acousticness": f.get("acousticness"),
            "instrumentalness": f.get("instrumentalness"),
            "liveness": f.get("liveness"),
            "speechiness": f.get("speechiness"),
            "loudness": f.get("loudness"),
            "key": f.get("key"),
            "mode": f.get("mode"),
            "time_signature": f.get("time_signature"),
        }}
    except Exception as e:
        return _err(e)


def _spotify_new_releases(args: dict) -> dict:
    """Newly released albums on Spotify."""
    try:
        limit = max(1, min(50, int(args.get("limit", 20))))
        res = _spotify_get("browse/new-releases", {"limit": limit})
        if not res.get("ok"):
            return res
        items = ((res["json"] or {}).get("albums") or {}).get("items", []) or []
        compact = [{"id": a.get("id"), "name": a.get("name"),
                    "artists": [ar.get("name") for ar in a.get("artists", [])],
                    "release_date": a.get("release_date"),
                    "total_tracks": a.get("total_tracks"),
                    "uri": a.get("uri")} for a in items if a]
        return {"ok": True, "albums": compact, "count": len(compact)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TMDB — MOVIES & TV
# ──────────────────────────────────────────────────────────────────────────

_TMDB_API = "https://api.themoviedb.org/3"


def _tmdb_get(path: str, params: Optional[dict] = None) -> Dict[str, Any]:
    """GET a TMDB endpoint with the API key appended."""
    key = _get_secret("TMDB_API_KEY")
    if not key:
        return _missing("TMDB_API_KEY", "TMDB")
    try:
        p = dict(params or {})
        p["api_key"] = key
        r = requests.get(f"{_TMDB_API}/{path.lstrip('/')}", params=p,
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "tmdb HTTP")
        return {"ok": True, "json": r.json()}
    except Exception as e:
        return _err(e)


def _movie_compact(m: dict) -> Dict[str, Any]:
    if not isinstance(m, dict):
        return {}
    return {
        "id": m.get("id"),
        "title": m.get("title") or m.get("name"),
        "release_date": m.get("release_date") or m.get("first_air_date"),
        "overview": m.get("overview"),
        "rating": m.get("vote_average"),
        "votes": m.get("vote_count"),
        "popularity": m.get("popularity"),
    }


def _movie_search(args: dict) -> dict:
    """Search movies by title."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        res = _tmdb_get("search/movie", {"query": query})
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _movie_details(args: dict) -> dict:
    """Full details for a movie, including genres, runtime and cast."""
    try:
        movie_id = str(args.get("movie_id", "")).strip()
        if not movie_id:
            return {"ok": False, "error": "movie_id required"}
        res = _tmdb_get(f"movie/{movie_id}", {"append_to_response": "credits"})
        if not res.get("ok"):
            return res
        m = res["json"] or {}
        cast = [c.get("name") for c in (m.get("credits") or {}).get("cast", [])[:10]]
        return {"ok": True, "movie": {
            **_movie_compact(m),
            "genres": [g.get("name") for g in m.get("genres", [])],
            "runtime": m.get("runtime"),
            "tagline": m.get("tagline"),
            "status": m.get("status"),
            "budget": m.get("budget"),
            "revenue": m.get("revenue"),
            "homepage": m.get("homepage"),
            "imdb_id": m.get("imdb_id"),
            "cast": cast,
        }}
    except Exception as e:
        return _err(e)


def _movie_trending(args: dict) -> dict:
    """Trending movies. window: day or week."""
    try:
        window = str(args.get("window", "week")).strip().lower()
        if window not in ("day", "week"):
            window = "week"
        res = _tmdb_get(f"trending/movie/{window}")
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "window": window, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _movie_now_playing(args: dict) -> dict:
    """Movies currently in theatres."""
    try:
        region = str(args.get("region", "US")).strip() or "US"
        res = _tmdb_get("movie/now_playing", {"region": region})
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "region": region, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _tv_search(args: dict) -> dict:
    """Search TV shows by name."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        res = _tmdb_get("search/tv", {"query": query})
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _tv_details(args: dict) -> dict:
    """Full details for a TV show."""
    try:
        tv_id = str(args.get("tv_id", "")).strip()
        if not tv_id:
            return {"ok": False, "error": "tv_id required"}
        res = _tmdb_get(f"tv/{tv_id}", {"append_to_response": "credits"})
        if not res.get("ok"):
            return res
        m = res["json"] or {}
        cast = [c.get("name") for c in (m.get("credits") or {}).get("cast", [])[:10]]
        return {"ok": True, "show": {
            **_movie_compact(m),
            "genres": [g.get("name") for g in m.get("genres", [])],
            "number_of_seasons": m.get("number_of_seasons"),
            "number_of_episodes": m.get("number_of_episodes"),
            "status": m.get("status"),
            "tagline": m.get("tagline"),
            "networks": [n.get("name") for n in m.get("networks", [])],
            "homepage": m.get("homepage"),
            "cast": cast,
        }}
    except Exception as e:
        return _err(e)


def _tv_trending(args: dict) -> dict:
    """Trending TV shows. window: day or week."""
    try:
        window = str(args.get("window", "week")).strip().lower()
        if window not in ("day", "week"):
            window = "week"
        res = _tmdb_get(f"trending/tv/{window}")
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "window": window, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _movie_recommendations(args: dict) -> dict:
    """Movies recommended based on a given movie."""
    try:
        movie_id = str(args.get("movie_id", "")).strip()
        if not movie_id:
            return {"ok": False, "error": "movie_id required"}
        res = _tmdb_get(f"movie/{movie_id}/recommendations")
        if not res.get("ok"):
            return res
        results = [_movie_compact(m) for m in (res["json"] or {}).get("results", [])]
        return {"ok": True, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _person_search(args: dict) -> dict:
    """Search people — actors, directors, crew."""
    try:
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        res = _tmdb_get("search/person", {"query": name})
        if not res.get("ok"):
            return res
        people = []
        for p in (res["json"] or {}).get("results", []):
            known = [(k.get("title") or k.get("name"))
                     for k in p.get("known_for", []) if isinstance(k, dict)]
            people.append({
                "id": p.get("id"),
                "name": p.get("name"),
                "known_for_department": p.get("known_for_department"),
                "popularity": p.get("popularity"),
                "known_for": [k for k in known if k],
            })
        return {"ok": True, "results": people, "count": len(people)}
    except Exception as e:
        return _err(e)


def _where_to_watch(args: dict) -> dict:
    """Streaming / rental / purchase availability for a movie in a region."""
    try:
        movie_id = str(args.get("movie_id", "")).strip()
        if not movie_id:
            return {"ok": False, "error": "movie_id required"}
        region = str(args.get("region", "US")).strip().upper() or "US"
        res = _tmdb_get(f"movie/{movie_id}/watch/providers")
        if not res.get("ok"):
            return res
        regions = (res["json"] or {}).get("results", {}) or {}
        block = regions.get(region)
        if not block:
            return {"ok": True, "region": region, "available": False,
                    "regions_with_data": list(regions.keys())}
        def names(key):
            return [p.get("provider_name") for p in block.get(key, []) or []]
        return {"ok": True, "region": region, "available": True,
                "link": block.get("link"),
                "stream": names("flatrate"),
                "rent": names("rent"),
                "buy": names("buy")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# RAWG — GAMES
# ──────────────────────────────────────────────────────────────────────────

_RAWG_API = "https://api.rawg.io/api"


def _rawg_get(path: str, params: Optional[dict] = None) -> Dict[str, Any]:
    """GET a RAWG endpoint with the API key appended."""
    key = _get_secret("RAWG_API_KEY")
    if not key:
        return _missing("RAWG_API_KEY", "RAWG")
    try:
        p = dict(params or {})
        p["key"] = key
        r = requests.get(f"{_RAWG_API}/{path.lstrip('/')}", params=p,
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "rawg HTTP")
        return {"ok": True, "json": r.json()}
    except Exception as e:
        return _err(e)


def _game_compact(g: dict) -> Dict[str, Any]:
    if not isinstance(g, dict):
        return {}
    return {
        "id": g.get("id"),
        "name": g.get("name"),
        "slug": g.get("slug"),
        "released": g.get("released"),
        "rating": g.get("rating"),
        "metacritic": g.get("metacritic"),
        "platforms": [(p.get("platform") or {}).get("name")
                      for p in g.get("platforms", []) or [] if isinstance(p, dict)],
        "genres": [gn.get("name") for gn in g.get("genres", []) or []
                   if isinstance(gn, dict)],
    }


def _game_search(args: dict) -> dict:
    """Search games by title."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(40, int(args.get("limit", 10))))
        res = _rawg_get("games", {"search": query, "page_size": limit})
        if not res.get("ok"):
            return res
        results = [_game_compact(g) for g in (res["json"] or {}).get("results", [])]
        return {"ok": True, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _game_details(args: dict) -> dict:
    """Full details for a game."""
    try:
        game_id = str(args.get("game_id", "")).strip()
        if not game_id:
            return {"ok": False, "error": "game_id required"}
        res = _rawg_get(f"games/{game_id}")
        if not res.get("ok"):
            return res
        g = res["json"] or {}
        return {"ok": True, "game": {
            **_game_compact(g),
            "description": (g.get("description_raw") or "")[:1500],
            "website": g.get("website"),
            "playtime": g.get("playtime"),
            "esrb_rating": (g.get("esrb_rating") or {}).get("name"),
            "developers": [d.get("name") for d in g.get("developers", []) or []],
            "publishers": [p.get("name") for p in g.get("publishers", []) or []],
        }}
    except Exception as e:
        return _err(e)


def _games_trending(args: dict) -> dict:
    """Currently popular games — last 12 months, ordered by rating."""
    try:
        limit = max(1, min(40, int(args.get("limit", 20))))
        end = time.strftime("%Y-%m-%d")
        start = time.strftime("%Y-%m-%d", time.gmtime(time.time() - 365 * 86400))
        res = _rawg_get("games", {"dates": f"{start},{end}",
                                  "ordering": "-rating", "page_size": limit})
        if not res.get("ok"):
            return res
        results = [_game_compact(g) for g in (res["json"] or {}).get("results", [])]
        return {"ok": True, "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


def _games_by_platform(args: dict) -> dict:
    """Games on a given platform. `platform` may be a RAWG platform id or a
    common name (pc, ps5, ps4, xbox-one, xbox-series-x, switch, etc.)."""
    try:
        platform = args.get("platform")
        if platform in (None, ""):
            return {"ok": False, "error": "platform required"}
        limit = max(1, min(40, int(args.get("limit", 20))))
        # common name → RAWG platform id
        name_map = {
            "pc": 4, "ps5": 187, "playstation5": 187, "ps4": 18,
            "playstation4": 18, "xbox-one": 1, "xboxone": 1,
            "xbox-series-x": 186, "xbox-series-s": 186, "xbox": 186,
            "switch": 7, "nintendo-switch": 7, "ios": 3, "android": 21,
            "macos": 5, "mac": 5, "linux": 6,
        }
        pkey = str(platform).strip().lower()
        pid = name_map.get(pkey)
        if pid is None and pkey.isdigit():
            pid = int(pkey)
        if pid is None:
            return {"ok": False,
                    "error": f"unknown platform '{platform}' — pass a RAWG "
                             f"platform id or one of: {', '.join(sorted(name_map))}"}
        res = _rawg_get("games", {"platforms": pid, "ordering": "-rating",
                                  "page_size": limit})
        if not res.get("ok"):
            return res
        results = [_game_compact(g) for g in (res["json"] or {}).get("results", [])]
        return {"ok": True, "platform": platform, "platform_id": pid,
                "results": results, "count": len(results)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# OPEN LIBRARY — BOOKS  (no key, free)
# ──────────────────────────────────────────────────────────────────────────

_OPENLIB_API = "https://openlibrary.org"


def _book_search(args: dict) -> dict:
    """Search books by title / author / keyword (Open Library — no key)."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(50, int(args.get("limit", 10))))
        r = requests.get(f"{_OPENLIB_API}/search.json",
                         params={"q": query, "limit": limit},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "openlibrary HTTP")
        docs = (r.json() or {}).get("docs", []) or []
        books = [{
            "title": d.get("title"),
            "authors": d.get("author_name", []),
            "first_publish_year": d.get("first_publish_year"),
            "olid": (d.get("key") or "").replace("/works/", ""),
            "edition_count": d.get("edition_count"),
            "isbn": (d.get("isbn") or [None])[0],
            "subjects": (d.get("subject") or [])[:6],
        } for d in docs]
        return {"ok": True, "results": books, "count": len(books)}
    except Exception as e:
        return _err(e)


def _book_details(args: dict) -> dict:
    """Details for a book by Open Library work id (OL…W) or ISBN."""
    try:
        ident = str(args.get("olid_or_isbn", "")).strip()
        if not ident:
            return {"ok": False, "error": "olid_or_isbn required"}
        digits = ident.replace("-", "")
        is_isbn = digits.isdigit() and len(digits) in (10, 13)
        if is_isbn:
            r = requests.get(f"{_OPENLIB_API}/isbn/{digits}.json",
                             timeout=_DEFAULT_TIMEOUT)
        else:
            olid = ident if ident.startswith("OL") else ident
            r = requests.get(f"{_OPENLIB_API}/works/{olid}.json",
                             timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "openlibrary HTTP")
        d = r.json() or {}
        desc = d.get("description")
        if isinstance(desc, dict):
            desc = desc.get("value")
        return {"ok": True, "book": {
            "title": d.get("title"),
            "description": (desc or "")[:1500] if desc else None,
            "subjects": (d.get("subjects") or [])[:10],
            "publish_date": d.get("publish_date"),
            "number_of_pages": d.get("number_of_pages"),
            "publishers": d.get("publishers"),
            "isbn_13": (d.get("isbn_13") or [None])[0],
            "isbn_10": (d.get("isbn_10") or [None])[0],
            "key": d.get("key"),
        }}
    except Exception as e:
        return _err(e)


def _book_by_author(args: dict) -> dict:
    """Find books written by a given author (Open Library — no key)."""
    try:
        author = str(args.get("author", "")).strip()
        if not author:
            return {"ok": False, "error": "author required"}
        limit = max(1, min(50, int(args.get("limit", 20))))
        r = requests.get(f"{_OPENLIB_API}/search.json",
                         params={"author": author, "limit": limit},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "openlibrary HTTP")
        docs = (r.json() or {}).get("docs", []) or []
        books = [{
            "title": d.get("title"),
            "first_publish_year": d.get("first_publish_year"),
            "olid": (d.get("key") or "").replace("/works/", ""),
            "edition_count": d.get("edition_count"),
        } for d in docs]
        return {"ok": True, "author": author, "results": books, "count": len(books)}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# LAST.FM + LYRICS — MUSIC DATA
# ──────────────────────────────────────────────────────────────────────────

_LASTFM_API = "https://ws.audioscrobbler.com/2.0/"
_LYRICS_API = "https://api.lyrics.ovh/v1"


def _lastfm_get(method: str, params: dict) -> Dict[str, Any]:
    """GET a Last.fm method with the API key appended (JSON format)."""
    key = _get_secret("LASTFM_API_KEY")
    if not key:
        return _missing("LASTFM_API_KEY", "Last.fm")
    try:
        p = dict(params)
        p.update({"method": method, "api_key": key, "format": "json"})
        r = requests.get(_LASTFM_API, params=p, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return _http_fail(r, "lastfm HTTP")
        data = r.json()
        if isinstance(data, dict) and data.get("error"):
            return {"ok": False,
                    "error": f"lastfm: {data.get('message', data.get('error'))}"}
        return {"ok": True, "json": data}
    except Exception as e:
        return _err(e)


def _lastfm_artist_info(args: dict) -> dict:
    """Bio, stats, tags and top tracks for an artist."""
    try:
        artist = str(args.get("artist", "")).strip()
        if not artist:
            return {"ok": False, "error": "artist required"}
        res = _lastfm_get("artist.getinfo", {"artist": artist, "autocorrect": 1})
        if not res.get("ok"):
            return res
        a = (res["json"] or {}).get("artist", {}) or {}
        bio = (a.get("bio") or {}).get("summary", "")
        # strip the trailing "<a>Read more…</a>" Last.fm appends
        if "<a href" in bio:
            bio = bio.split("<a href")[0].strip()
        return {"ok": True, "artist": {
            "name": a.get("name"),
            "listeners": (a.get("stats") or {}).get("listeners"),
            "playcount": (a.get("stats") or {}).get("playcount"),
            "tags": [t.get("name") for t in (a.get("tags") or {}).get("tag", [])],
            "bio": bio,
            "url": a.get("url"),
            "on_tour": a.get("ontour"),
        }}
    except Exception as e:
        return _err(e)


def _lastfm_similar_artists(args: dict) -> dict:
    """Artists similar to a given artist."""
    try:
        artist = str(args.get("artist", "")).strip()
        if not artist:
            return {"ok": False, "error": "artist required"}
        limit = max(1, min(100, int(args.get("limit", 20))))
        res = _lastfm_get("artist.getsimilar",
                          {"artist": artist, "autocorrect": 1, "limit": limit})
        if not res.get("ok"):
            return res
        sim = (res["json"] or {}).get("similarartists", {}) or {}
        artists = [{"name": s.get("name"),
                    "match": s.get("match"),
                    "url": s.get("url")}
                   for s in sim.get("artist", []) or []]
        return {"ok": True, "artist": artist, "similar": artists,
                "count": len(artists)}
    except Exception as e:
        return _err(e)


def _lyrics(args: dict) -> dict:
    """Fetch song lyrics via the free lyrics.ovh API (no key needed)."""
    try:
        artist = str(args.get("artist", "")).strip()
        title = str(args.get("title", "")).strip()
        if not artist or not title:
            return {"ok": False, "error": "artist and title required"}
        from urllib.parse import quote
        r = requests.get(f"{_LYRICS_API}/{quote(artist)}/{quote(title)}",
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code == 404:
            return {"ok": False, "error": f"lyrics not found for {artist} — {title}"}
        if r.status_code >= 400:
            return _http_fail(r, "lyrics.ovh HTTP")
        data = r.json() or {}
        text = (data.get("lyrics") or "").strip()
        if not text:
            return {"ok": False, "error": f"lyrics not found for {artist} — {title}"}
        return {"ok": True, "artist": artist, "title": title, "lyrics": text}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Spotify
    "ent.spotify_search": _spotify_search,
    "ent.spotify_track_info": _spotify_track_info,
    "ent.spotify_artist_top_tracks": _spotify_artist_top_tracks,
    "ent.spotify_recommendations": _spotify_recommendations,
    "ent.spotify_my_playlists": _spotify_my_playlists,
    "ent.spotify_playlist_tracks": _spotify_playlist_tracks,
    "ent.spotify_create_playlist": _spotify_create_playlist,
    "ent.spotify_add_to_playlist": _spotify_add_to_playlist,
    "ent.spotify_currently_playing": _spotify_currently_playing,
    "ent.spotify_audio_features": _spotify_audio_features,
    "ent.spotify_new_releases": _spotify_new_releases,
    # TMDB — movies & TV
    "ent.movie_search": _movie_search,
    "ent.movie_details": _movie_details,
    "ent.movie_trending": _movie_trending,
    "ent.movie_now_playing": _movie_now_playing,
    "ent.tv_search": _tv_search,
    "ent.tv_details": _tv_details,
    "ent.tv_trending": _tv_trending,
    "ent.movie_recommendations": _movie_recommendations,
    "ent.person_search": _person_search,
    "ent.where_to_watch": _where_to_watch,
    # Games — RAWG
    "ent.game_search": _game_search,
    "ent.game_details": _game_details,
    "ent.games_trending": _games_trending,
    "ent.games_by_platform": _games_by_platform,
    # Books — Open Library
    "ent.book_search": _book_search,
    "ent.book_details": _book_details,
    "ent.book_by_author": _book_by_author,
    # Music data
    "ent.lastfm_artist_info": _lastfm_artist_info,
    "ent.lastfm_similar_artists": _lastfm_similar_artists,
    "ent.lyrics": _lyrics,
}
