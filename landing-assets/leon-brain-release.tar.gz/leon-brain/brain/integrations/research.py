"""
research.py — Leon's research & knowledge tool surface.

This module gives Leon the ability to LOOK THINGS UP across the public
web: Wikipedia, arXiv academic papers, Reddit, RSS feeds, dictionary /
thesaurus / translation, Wolfram Alpha, podcasts, and assorted "fun
facts" endpoints (dad jokes, cat facts, NASA APOD, etc.).

All tools share the {ok, result|error} contract used elsewhere in the
brain. None of them raise — every exception is caught and wrapped as
`{"ok": False, "error": "<msg>"}`. Default HTTP timeout is 8 seconds.

Most endpoints are credential-free. Two exceptions:

  - Wolfram Alpha tools require `WOLFRAM_APP_ID` env var.
  - NASA APOD honors `NASA_API_KEY` if set, falls back to `DEMO_KEY`.

RSS subscription state is persisted under:

  - brain_state/rss_subscriptions.json  — {name: url} map
  - brain_state/rss_state.json          — {url: last_seen_iso} map

The EXTRA_TOOLS dict at the bottom maps dotted tool names (e.g.
`research.wikipedia_summary`) to the implementing function — import this
dict from the responder / MCP server to register them in one shot.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

try:
    import requests
except Exception:  # pragma: no cover - requests is expected to be installed
    requests = None  # type: ignore


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONSTANTS
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_TIMEOUT = 8
_USER_AGENT = "LeonBrain/1.0 (https://github.com/47industries; research module)"


def _project_root() -> str:
    """Project dir (parent of brain/). Mirrors memory_extras._project_root."""
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _brain_state_dir() -> str:
    d = os.path.join(_project_root(), "brain_state")
    os.makedirs(d, exist_ok=True)
    return d


def _rss_subs_path() -> str:
    return os.path.join(_brain_state_dir(), "rss_subscriptions.json")


def _rss_state_path() -> str:
    return os.path.join(_brain_state_dir(), "rss_state.json")


# ──────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": str(msg)}


def _ok(**kwargs: Any) -> Dict[str, Any]:
    out = {"ok": True}
    out.update(kwargs)
    return out


def _require_requests() -> Optional[Dict[str, Any]]:
    if requests is None:
        return _err("requests library not available")
    return None


def _http_get(
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = _DEFAULT_TIMEOUT,
) -> Any:
    """GET with default UA + timeout. Returns the response object. Raises on
    transport errors — callers wrap in try/except."""
    hdrs = {"User-Agent": _USER_AGENT, "Accept": "*/*"}
    if headers:
        hdrs.update(headers)
    return requests.get(url, params=params, headers=hdrs, timeout=timeout)


def _load_json_file(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception:
        return default


def _save_json_file(path: str, data: Any) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _strip_html(text: str) -> str:
    """Quick & dirty HTML tag stripper for RSS descriptions."""
    text = re.sub(r"<[^>]+>", "", text or "")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


# ──────────────────────────────────────────────────────────────────────────
# WIKIPEDIA
# ──────────────────────────────────────────────────────────────────────────


def wikipedia_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """REST summary for a Wikipedia article."""
    if (e := _require_requests()):
        return e
    title = (args.get("title") or "").strip()
    if not title:
        return _err("title required")
    lang = (args.get("lang") or "en").strip()
    try:
        slug = urllib.parse.quote(title.replace(" ", "_"), safe="")
        url = f"https://{lang}.wikipedia.org/api/rest_v1/page/summary/{slug}"
        r = _http_get(url)
        if r.status_code == 404:
            return _err(f"no article titled '{title}'")
        r.raise_for_status()
        d = r.json()
        return _ok(
            title=d.get("title"),
            description=d.get("description"),
            extract=d.get("extract"),
            url=(d.get("content_urls", {}).get("desktop", {}) or {}).get("page"),
            thumbnail=(d.get("thumbnail") or {}).get("source"),
            lang=lang,
        )
    except Exception as e:
        return _err(e)


def wikipedia_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """OpenSearch on Wikipedia — returns list of {title, description, url}."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    lang = (args.get("lang") or "en").strip()
    limit = int(args.get("limit") or 5)
    try:
        url = f"https://{lang}.wikipedia.org/w/api.php"
        params = {
            "action": "opensearch",
            "search": query,
            "limit": limit,
            "namespace": 0,
            "format": "json",
        }
        r = _http_get(url, params=params)
        r.raise_for_status()
        data = r.json()
        titles = data[1] if len(data) > 1 else []
        descs = data[2] if len(data) > 2 else []
        urls = data[3] if len(data) > 3 else []
        results = []
        for i, t in enumerate(titles):
            results.append({
                "title": t,
                "description": descs[i] if i < len(descs) else "",
                "url": urls[i] if i < len(urls) else "",
            })
        return _ok(results=results, count=len(results))
    except Exception as e:
        return _err(e)


def wikipedia_full_content(args: Dict[str, Any]) -> Dict[str, Any]:
    """Full plaintext extract of a Wikipedia article (optionally limited to
    a list of section indexes — currently sections is informational; the
    full extract is returned)."""
    if (e := _require_requests()):
        return e
    title = (args.get("title") or "").strip()
    if not title:
        return _err("title required")
    lang = (args.get("lang") or "en").strip()
    sections = args.get("sections")
    try:
        url = f"https://{lang}.wikipedia.org/w/api.php"
        params = {
            "action": "query",
            "prop": "extracts",
            "explaintext": 1,
            "titles": title,
            "format": "json",
            "redirects": 1,
        }
        r = _http_get(url, params=params, timeout=12)
        r.raise_for_status()
        pages = (r.json().get("query") or {}).get("pages") or {}
        if not pages:
            return _err("no pages returned")
        page = next(iter(pages.values()))
        if "missing" in page:
            return _err(f"no article titled '{title}'")
        extract = page.get("extract") or ""
        paragraphs = [p.strip() for p in extract.split("\n") if p.strip()]
        if sections and isinstance(sections, list):
            wanted = [paragraphs[i] for i in sections if 0 <= int(i) < len(paragraphs)]
            paragraphs = wanted
        return _ok(
            title=page.get("title"),
            paragraphs=paragraphs,
            chars=len(extract),
            paragraph_count=len(paragraphs),
        )
    except Exception as e:
        return _err(e)


def wikipedia_random(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return a random Wikipedia article summary."""
    if (e := _require_requests()):
        return e
    lang = (args.get("lang") or "en").strip()
    try:
        url = f"https://{lang}.wikipedia.org/api/rest_v1/page/random/summary"
        r = _http_get(url)
        r.raise_for_status()
        d = r.json()
        return _ok(
            title=d.get("title"),
            description=d.get("description"),
            extract=d.get("extract"),
            url=(d.get("content_urls", {}).get("desktop", {}) or {}).get("page"),
        )
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# ARXIV
# ──────────────────────────────────────────────────────────────────────────


_ARXIV_NS = {
    "a": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
}


def _parse_arxiv_feed(xml_text: str) -> List[Dict[str, Any]]:
    root = ET.fromstring(xml_text)
    entries = []
    for entry in root.findall("a:entry", _ARXIV_NS):
        def _t(tag: str) -> str:
            el = entry.find(f"a:{tag}", _ARXIV_NS)
            return (el.text or "").strip() if el is not None else ""

        authors = [
            (a.find("a:name", _ARXIV_NS).text or "").strip()
            for a in entry.findall("a:author", _ARXIV_NS)
            if a.find("a:name", _ARXIV_NS) is not None
        ]
        cats = [
            c.get("term", "")
            for c in entry.findall("a:category", _ARXIV_NS)
        ]
        pdf_url = ""
        abs_url = ""
        for link in entry.findall("a:link", _ARXIV_NS):
            if link.get("title") == "pdf":
                pdf_url = link.get("href", "")
            elif link.get("rel") == "alternate":
                abs_url = link.get("href", "")
        raw_id = _t("id")
        paper_id = raw_id.rsplit("/", 1)[-1] if raw_id else ""
        entries.append({
            "id": paper_id,
            "title": re.sub(r"\s+", " ", _t("title")),
            "summary": re.sub(r"\s+", " ", _t("summary")),
            "authors": authors,
            "categories": cats,
            "published": _t("published"),
            "updated": _t("updated"),
            "abs_url": abs_url or raw_id,
            "pdf_url": pdf_url,
        })
    return entries


def arxiv_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search arXiv via the public Atom API."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    max_results = int(args.get("max_results") or 10)
    sort_by = (args.get("sort_by") or "relevance").strip()
    if sort_by not in ("relevance", "lastUpdatedDate", "submittedDate"):
        sort_by = "relevance"
    try:
        url = "http://export.arxiv.org/api/query"
        params = {
            "search_query": f"all:{query}",
            "start": 0,
            "max_results": max_results,
            "sortBy": sort_by,
            "sortOrder": "descending",
        }
        r = _http_get(url, params=params, timeout=12)
        r.raise_for_status()
        results = _parse_arxiv_feed(r.text)
        return _ok(results=results, count=len(results))
    except Exception as e:
        return _err(e)


def arxiv_recent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent arXiv papers in a given category (e.g. cs.AI, cs.CL)."""
    if (e := _require_requests()):
        return e
    category = (args.get("category") or "").strip()
    if not category:
        return _err("category required (e.g. cs.AI)")
    max_results = int(args.get("max_results") or 10)
    try:
        url = "http://export.arxiv.org/api/query"
        params = {
            "search_query": f"cat:{category}",
            "start": 0,
            "max_results": max_results,
            "sortBy": "submittedDate",
            "sortOrder": "descending",
        }
        r = _http_get(url, params=params, timeout=12)
        r.raise_for_status()
        results = _parse_arxiv_feed(r.text)
        return _ok(results=results, count=len(results), category=category)
    except Exception as e:
        return _err(e)


def arxiv_get_paper(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fetch a single arXiv paper by ID (e.g. '2401.12345')."""
    if (e := _require_requests()):
        return e
    paper_id = (args.get("paper_id") or "").strip()
    if not paper_id:
        return _err("paper_id required")
    try:
        url = "http://export.arxiv.org/api/query"
        params = {"id_list": paper_id}
        r = _http_get(url, params=params, timeout=12)
        r.raise_for_status()
        results = _parse_arxiv_feed(r.text)
        if not results:
            return _err(f"no paper found for id '{paper_id}'")
        return _ok(paper=results[0])
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# REDDIT (unauth public JSON)
# ──────────────────────────────────────────────────────────────────────────


def _reddit_extract_posts(payload: Any, limit: int) -> List[Dict[str, Any]]:
    out = []
    children = (((payload or {}).get("data") or {}).get("children")) or []
    for c in children[:limit]:
        d = c.get("data") or {}
        out.append({
            "id": d.get("id"),
            "title": d.get("title"),
            "author": d.get("author"),
            "subreddit": d.get("subreddit"),
            "score": d.get("score"),
            "num_comments": d.get("num_comments"),
            "url": d.get("url"),
            "permalink": f"https://www.reddit.com{d.get('permalink', '')}",
            "selftext": (d.get("selftext") or "")[:600],
            "created_utc": d.get("created_utc"),
            "over_18": d.get("over_18", False),
        })
    return out


def reddit_top(args: Dict[str, Any]) -> Dict[str, Any]:
    """Top posts of a subreddit. time in {hour, day, week, month, year, all}."""
    if (e := _require_requests()):
        return e
    subreddit = (args.get("subreddit") or "").strip().lstrip("/").removeprefix("r/")
    if not subreddit:
        return _err("subreddit required")
    time_window = (args.get("time") or "day").strip()
    limit = int(args.get("limit") or 10)
    try:
        url = f"https://www.reddit.com/r/{subreddit}/top.json"
        r = _http_get(url, params={"t": time_window, "limit": limit})
        r.raise_for_status()
        posts = _reddit_extract_posts(r.json(), limit)
        return _ok(posts=posts, count=len(posts), subreddit=subreddit, time=time_window)
    except Exception as e:
        return _err(e)


def reddit_hot(args: Dict[str, Any]) -> Dict[str, Any]:
    """Hot posts of a subreddit."""
    if (e := _require_requests()):
        return e
    subreddit = (args.get("subreddit") or "").strip().lstrip("/").removeprefix("r/")
    if not subreddit:
        return _err("subreddit required")
    limit = int(args.get("limit") or 10)
    try:
        url = f"https://www.reddit.com/r/{subreddit}/hot.json"
        r = _http_get(url, params={"limit": limit})
        r.raise_for_status()
        posts = _reddit_extract_posts(r.json(), limit)
        return _ok(posts=posts, count=len(posts), subreddit=subreddit)
    except Exception as e:
        return _err(e)


def reddit_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Reddit (optionally scoped to a subreddit)."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    subreddit = (args.get("subreddit") or "").strip().lstrip("/").removeprefix("r/")
    limit = int(args.get("limit") or 10)
    try:
        if subreddit:
            url = f"https://www.reddit.com/r/{subreddit}/search.json"
            params = {"q": query, "restrict_sr": 1, "limit": limit}
        else:
            url = "https://www.reddit.com/search.json"
            params = {"q": query, "limit": limit}
        r = _http_get(url, params=params)
        r.raise_for_status()
        posts = _reddit_extract_posts(r.json(), limit)
        return _ok(posts=posts, count=len(posts), query=query)
    except Exception as e:
        return _err(e)


def reddit_comments(args: Dict[str, Any]) -> Dict[str, Any]:
    """First-level comments on a post by ID."""
    if (e := _require_requests()):
        return e
    post_id = (args.get("post_id") or "").strip()
    if not post_id:
        return _err("post_id required")
    limit = int(args.get("limit") or 20)
    try:
        url = f"https://www.reddit.com/comments/{post_id}.json"
        r = _http_get(url, params={"limit": limit, "depth": 1})
        r.raise_for_status()
        data = r.json()
        comments = []
        if isinstance(data, list) and len(data) >= 2:
            children = (((data[1] or {}).get("data") or {}).get("children")) or []
            for c in children[:limit]:
                if c.get("kind") != "t1":
                    continue
                d = c.get("data") or {}
                comments.append({
                    "id": d.get("id"),
                    "author": d.get("author"),
                    "body": d.get("body"),
                    "score": d.get("score"),
                    "created_utc": d.get("created_utc"),
                })
        return _ok(comments=comments, count=len(comments), post_id=post_id)
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# RSS / ATOM
# ──────────────────────────────────────────────────────────────────────────


def _parse_rss_xml(xml_text: str, limit: int) -> List[Dict[str, Any]]:
    """Manual fallback RSS/Atom parser. Returns list of normalized items."""
    items: List[Dict[str, Any]] = []
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return items
    # RSS 2.0: rss/channel/item
    channel = root.find("channel")
    if channel is not None:
        for it in channel.findall("item")[:limit]:
            title = (it.findtext("title") or "").strip()
            link = (it.findtext("link") or "").strip()
            desc = _strip_html(it.findtext("description") or "")
            pub = (it.findtext("pubDate") or "").strip()
            items.append({
                "title": title,
                "link": link,
                "summary": desc[:800],
                "published": pub,
            })
        return items
    # Atom: feed/entry  (handle ns)
    ns = {"a": "http://www.w3.org/2005/Atom"}
    if root.tag.endswith("feed"):
        for entry in root.findall("a:entry", ns)[:limit]:
            title = (entry.findtext("a:title", default="", namespaces=ns) or "").strip()
            link_el = entry.find("a:link", ns)
            link = link_el.get("href", "") if link_el is not None else ""
            summary = _strip_html(
                entry.findtext("a:summary", default="", namespaces=ns)
                or entry.findtext("a:content", default="", namespaces=ns)
                or ""
            )
            pub = (entry.findtext("a:published", default="", namespaces=ns) or "").strip()
            items.append({
                "title": title,
                "link": link,
                "summary": summary[:800],
                "published": pub,
            })
    return items


def rss_fetch(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fetch & parse an RSS/Atom feed. Uses feedparser if available."""
    if (e := _require_requests()):
        return e
    url = (args.get("url") or "").strip()
    if not url:
        return _err("url required")
    limit = int(args.get("limit") or 10)
    try:
        try:
            import feedparser  # type: ignore
            r = _http_get(url, timeout=12)
            r.raise_for_status()
            parsed = feedparser.parse(r.content)
            items = []
            for entry in (parsed.entries or [])[:limit]:
                items.append({
                    "title": (entry.get("title") or "").strip(),
                    "link": (entry.get("link") or "").strip(),
                    "summary": _strip_html(entry.get("summary") or entry.get("description") or "")[:800],
                    "published": entry.get("published") or entry.get("updated") or "",
                })
            feed_title = (parsed.feed or {}).get("title", "")
            return _ok(items=items, count=len(items), feed_title=feed_title)
        except ImportError:
            r = _http_get(url, timeout=12)
            r.raise_for_status()
            items = _parse_rss_xml(r.text, limit)
            return _ok(items=items, count=len(items), feed_title="", parser="builtin")
    except Exception as e:
        return _err(e)


def rss_subscribe(args: Dict[str, Any]) -> Dict[str, Any]:
    """Persist a named RSS subscription."""
    name = (args.get("name") or "").strip()
    url = (args.get("url") or "").strip()
    if not name or not url:
        return _err("name and url required")
    try:
        subs = _load_json_file(_rss_subs_path(), {})
        if not isinstance(subs, dict):
            subs = {}
        subs[name] = url
        _save_json_file(_rss_subs_path(), subs)
        return _ok(name=name, url=url, total=len(subs))
    except Exception as e:
        return _err(e)


def rss_list_subscriptions(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all RSS subscriptions."""
    try:
        subs = _load_json_file(_rss_subs_path(), {})
        if not isinstance(subs, dict):
            subs = {}
        return _ok(subscriptions=subs, count=len(subs))
    except Exception as e:
        return _err(e)


def rss_check_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fetch all subscriptions, return items newer than last-check timestamp.
    Updates brain_state/rss_state.json with new last-seen timestamps."""
    if (e := _require_requests()):
        return e
    limit = int(args.get("limit") or 10)
    try:
        subs = _load_json_file(_rss_subs_path(), {})
        state = _load_json_file(_rss_state_path(), {})
        if not isinstance(subs, dict):
            subs = {}
        if not isinstance(state, dict):
            state = {}
        now_iso = datetime.now(timezone.utc).isoformat()
        digest: Dict[str, List[Dict[str, Any]]] = {}
        for name, url in subs.items():
            res = rss_fetch({"url": url, "limit": limit})
            if not res.get("ok"):
                digest[name] = []
                continue
            items = res.get("items") or []
            last_seen = state.get(url)
            new_items = []
            for it in items:
                pub = it.get("published") or ""
                if not last_seen or (pub and pub > last_seen):
                    new_items.append(it)
            digest[name] = new_items
            state[url] = now_iso
        _save_json_file(_rss_state_path(), state)
        total_new = sum(len(v) for v in digest.values())
        return _ok(digest=digest, feeds=len(subs), new_items=total_new)
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# DICTIONARY / LANGUAGE
# ──────────────────────────────────────────────────────────────────────────


def dictionary_lookup(args: Dict[str, Any]) -> Dict[str, Any]:
    """Dictionary definition via dictionaryapi.dev."""
    if (e := _require_requests()):
        return e
    word = (args.get("word") or "").strip()
    if not word:
        return _err("word required")
    lang = (args.get("lang") or "en").strip()
    try:
        url = f"https://api.dictionaryapi.dev/api/v2/entries/{lang}/{urllib.parse.quote(word)}"
        r = _http_get(url)
        if r.status_code == 404:
            return _err(f"no definition for '{word}'")
        r.raise_for_status()
        data = r.json()
        if not isinstance(data, list) or not data:
            return _err("no entry found")
        entry = data[0]
        meanings = []
        for m in entry.get("meanings", []):
            defs = [
                {"definition": d.get("definition"), "example": d.get("example")}
                for d in m.get("definitions", [])[:3]
            ]
            meanings.append({
                "part_of_speech": m.get("partOfSpeech"),
                "definitions": defs,
                "synonyms": m.get("synonyms", [])[:8],
                "antonyms": m.get("antonyms", [])[:8],
            })
        phonetic = entry.get("phonetic") or ""
        if not phonetic:
            for p in entry.get("phonetics", []):
                if p.get("text"):
                    phonetic = p["text"]
                    break
        return _ok(word=entry.get("word", word), phonetic=phonetic, meanings=meanings)
    except Exception as e:
        return _err(e)


def thesaurus_synonyms(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pull synonyms (and antonyms) out of the dictionary API."""
    word = (args.get("word") or "").strip()
    if not word:
        return _err("word required")
    try:
        res = dictionary_lookup({"word": word})
        if not res.get("ok"):
            return res
        syns: List[str] = []
        ants: List[str] = []
        for m in res.get("meanings", []):
            syns.extend(m.get("synonyms") or [])
            ants.extend(m.get("antonyms") or [])
            for d in m.get("definitions", []):
                # dictionaryapi sometimes nests per-definition syns/ants — not
                # in our extracted shape, so we rely on the meaning-level lists.
                pass
        # dedupe preserving order
        seen = set()
        syns_dedup = [s for s in syns if not (s in seen or seen.add(s))]
        seen = set()
        ants_dedup = [a for a in ants if not (a in seen or seen.add(a))]
        return _ok(word=word, synonyms=syns_dedup, antonyms=ants_dedup)
    except Exception as e:
        return _err(e)


def translate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Translate text via MyMemory free translation API."""
    if (e := _require_requests()):
        return e
    text = (args.get("text") or "").strip()
    target = (args.get("target_lang") or "").strip()
    source = (args.get("source_lang") or "auto").strip()
    if not text or not target:
        return _err("text and target_lang required")
    try:
        if source == "auto":
            source = "en"
        url = "https://api.mymemory.translated.net/get"
        params = {"q": text, "langpair": f"{source}|{target}"}
        r = _http_get(url, params=params, timeout=12)
        r.raise_for_status()
        data = r.json()
        translated = ((data.get("responseData") or {}).get("translatedText")) or ""
        match_q = (data.get("responseData") or {}).get("match")
        return _ok(
            translated=translated,
            source_lang=source,
            target_lang=target,
            match_quality=match_q,
        )
    except Exception as e:
        return _err(e)


def urban_dictionary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Look up a term on Urban Dictionary."""
    if (e := _require_requests()):
        return e
    term = (args.get("term") or "").strip()
    if not term:
        return _err("term required")
    try:
        url = "https://api.urbandictionary.com/v0/define"
        r = _http_get(url, params={"term": term})
        r.raise_for_status()
        items = r.json().get("list") or []
        results = []
        for it in items[:5]:
            results.append({
                "definition": (it.get("definition") or "").strip(),
                "example": (it.get("example") or "").strip(),
                "author": it.get("author"),
                "thumbs_up": it.get("thumbs_up"),
                "thumbs_down": it.get("thumbs_down"),
                "permalink": it.get("permalink"),
            })
        return _ok(term=term, results=results, count=len(results))
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# WOLFRAM ALPHA
# ──────────────────────────────────────────────────────────────────────────


def _wolfram_app_id() -> Optional[str]:
    return os.environ.get("WOLFRAM_APP_ID")


def wolfram_short_answer(args: Dict[str, Any]) -> Dict[str, Any]:
    """Wolfram Alpha short-answer endpoint. Requires WOLFRAM_APP_ID env var."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    app_id = _wolfram_app_id()
    if not app_id:
        return _err("WOLFRAM_APP_ID env var not set")
    try:
        url = "https://api.wolframalpha.com/v1/result"
        r = _http_get(url, params={"appid": app_id, "i": query})
        if r.status_code == 501:
            return _err("Wolfram could not interpret query")
        r.raise_for_status()
        return _ok(answer=r.text.strip(), query=query)
    except Exception as e:
        return _err(e)


def wolfram_full(args: Dict[str, Any]) -> Dict[str, Any]:
    """Wolfram Alpha full v2/query API. Returns parsed pods."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    app_id = _wolfram_app_id()
    if not app_id:
        return _err("WOLFRAM_APP_ID env var not set")
    try:
        url = "https://api.wolframalpha.com/v2/query"
        params = {"appid": app_id, "input": query, "format": "plaintext", "output": "xml"}
        r = _http_get(url, params=params, timeout=15)
        r.raise_for_status()
        root = ET.fromstring(r.text)
        success = root.get("success", "false") == "true"
        pods = []
        for pod in root.findall("pod"):
            subpods = []
            for sp in pod.findall("subpod"):
                pt = sp.findtext("plaintext") or ""
                if pt.strip():
                    subpods.append(pt.strip())
            pods.append({
                "title": pod.get("title", ""),
                "id": pod.get("id", ""),
                "subpods": subpods,
            })
        return _ok(success=success, query=query, pods=pods, pod_count=len(pods))
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# MISC KNOWLEDGE / FUN
# ──────────────────────────────────────────────────────────────────────────


def dad_joke(args: Dict[str, Any]) -> Dict[str, Any]:
    """Random dad joke via icanhazdadjoke.com."""
    if (e := _require_requests()):
        return e
    try:
        r = _http_get(
            "https://icanhazdadjoke.com/",
            headers={"Accept": "application/json"},
        )
        r.raise_for_status()
        d = r.json()
        return _ok(id=d.get("id"), joke=d.get("joke"))
    except Exception as e:
        return _err(e)


def cat_fact(args: Dict[str, Any]) -> Dict[str, Any]:
    """Random cat fact via catfact.ninja."""
    if (e := _require_requests()):
        return e
    try:
        r = _http_get("https://catfact.ninja/fact")
        r.raise_for_status()
        d = r.json()
        return _ok(fact=d.get("fact"), length=d.get("length"))
    except Exception as e:
        return _err(e)


def bored_activity(args: Dict[str, Any]) -> Dict[str, Any]:
    """Random activity suggestion via boredapi.com."""
    if (e := _require_requests()):
        return e
    try:
        r = _http_get("https://www.boredapi.com/api/activity")
        r.raise_for_status()
        d = r.json()
        return _ok(
            activity=d.get("activity"),
            type=d.get("type"),
            participants=d.get("participants"),
            price=d.get("price"),
            accessibility=d.get("accessibility"),
        )
    except Exception as e:
        return _err(e)


def nasa_apod(args: Dict[str, Any]) -> Dict[str, Any]:
    """NASA Astronomy Picture of the Day. Uses NASA_API_KEY if set, else DEMO_KEY."""
    if (e := _require_requests()):
        return e
    key = os.environ.get("NASA_API_KEY", "DEMO_KEY")
    date = (args.get("date") or "").strip()
    try:
        params: Dict[str, Any] = {"api_key": key}
        if date:
            params["date"] = date
        r = _http_get("https://api.nasa.gov/planetary/apod", params=params)
        r.raise_for_status()
        d = r.json()
        return _ok(
            title=d.get("title"),
            date=d.get("date"),
            explanation=d.get("explanation"),
            url=d.get("url"),
            hdurl=d.get("hdurl"),
            media_type=d.get("media_type"),
            copyright=d.get("copyright"),
        )
    except Exception as e:
        return _err(e)


def podcast_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search podcasts via the iTunes Search API."""
    if (e := _require_requests()):
        return e
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query required")
    limit = int(args.get("limit") or 10)
    try:
        url = "https://itunes.apple.com/search"
        params = {"media": "podcast", "term": query, "limit": limit}
        r = _http_get(url, params=params)
        r.raise_for_status()
        items = r.json().get("results") or []
        results = []
        for it in items:
            results.append({
                "name": it.get("collectionName") or it.get("trackName"),
                "artist": it.get("artistName"),
                "feed_url": it.get("feedUrl"),
                "genre": it.get("primaryGenreName"),
                "track_count": it.get("trackCount"),
                "artwork": it.get("artworkUrl600") or it.get("artworkUrl100"),
                "itunes_url": it.get("collectionViewUrl"),
            })
        return _ok(results=results, count=len(results), query=query)
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# EXPORTS
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # Wikipedia
    "research.wikipedia_summary": wikipedia_summary,
    "research.wikipedia_search": wikipedia_search,
    "research.wikipedia_full_content": wikipedia_full_content,
    "research.wikipedia_random": wikipedia_random,
    # arXiv
    "research.arxiv_search": arxiv_search,
    "research.arxiv_recent": arxiv_recent,
    "research.arxiv_get_paper": arxiv_get_paper,
    # Reddit
    "research.reddit_top": reddit_top,
    "research.reddit_hot": reddit_hot,
    "research.reddit_search": reddit_search,
    "research.reddit_comments": reddit_comments,
    # RSS
    "research.rss_fetch": rss_fetch,
    "research.rss_subscribe": rss_subscribe,
    "research.rss_list_subscriptions": rss_list_subscriptions,
    "research.rss_check_all": rss_check_all,
    # Dictionary / language
    "research.dictionary_lookup": dictionary_lookup,
    "research.thesaurus_synonyms": thesaurus_synonyms,
    "research.translate": translate,
    "research.urban_dictionary": urban_dictionary,
    # Wolfram
    "research.wolfram_short_answer": wolfram_short_answer,
    "research.wolfram_full": wolfram_full,
    # Misc knowledge / fun
    "research.dad_joke": dad_joke,
    "research.cat_fact": cat_fact,
    "research.bored_activity": bored_activity,
    "research.nasa_apod": nasa_apod,
    "research.podcast_search": podcast_search,
}
