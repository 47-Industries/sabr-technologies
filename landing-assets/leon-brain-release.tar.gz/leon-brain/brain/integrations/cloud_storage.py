"""cloud_storage.py — Leon's unified cloud file hub.

Single front door for Google Drive, Dropbox, Microsoft OneDrive, and AWS S3.
Same envelope as `comms.py`: every tool takes one `dict`, never raises, and
returns `{"ok": bool, ...}`. Credentials are lazy — env vars first, then
`~/.openclaw/secrets.json`, then (for Drive only) the OpenClaw MCP google
token store, then (for S3) standard boto3 resolution.

Local filesystem writes are sandboxed to `~/Desktop`, `~/Documents`, and
`~/Downloads`. Anything outside is rejected before any HTTP call.

Credentials read:
  - GDRIVE_ACCESS_TOKEN          (OAuth bearer; or OpenClaw token store)
  - DROPBOX_ACCESS_TOKEN
  - ONEDRIVE_ACCESS_TOKEN        (Microsoft Graph bearer)
  - AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY / AWS_REGION  (or ~/.aws/credentials)

Secrets file fallback: `~/.openclaw/secrets.json` — flat JSON dict.

EXTRA_TOOLS at the bottom maps `cloud.<name>` to callables.
"""

from __future__ import annotations

import json
import mimetypes
import os
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import quote

import requests


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 15.0
_UPLOAD_TIMEOUT = 60.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0

_GDRIVE_MCP_TOKEN_CANDIDATES = [
    Path.home() / ".openclaw" / "mcp" / "openclaw-mcp" / "google-token.json",
    Path.home() / ".openclaw" / "mcp" / "openclaw-mcp" / ".google-token.json",
    Path.home() / ".openclaw" / "google-token.json",
]


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file."""
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _gdrive_token_from_mcp() -> Optional[str]:
    """Try to pull a Google Drive access token out of the OpenClaw MCP store."""
    for p in _GDRIVE_MCP_TOKEN_CANDIDATES:
        try:
            if not p.exists():
                continue
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                tok = data.get("access_token") or data.get("token")
                if tok:
                    return str(tok)
        except Exception:
            continue
    return None


def _gdrive_token() -> Optional[str]:
    return _get_secret("GDRIVE_ACCESS_TOKEN") or _gdrive_token_from_mcp()


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _wrap_http(resp: requests.Response) -> Dict[str, Any]:
    try:
        return {"status": resp.status_code, "json": resp.json()}
    except Exception:
        return {"status": resp.status_code, "text": resp.text[:2000]}


# ──────────────────────────────────────────────────────────────────────────
# LOCAL PATH SANDBOX
# ──────────────────────────────────────────────────────────────────────────

_ALLOWED_ROOTS = [
    (Path.home() / "Desktop").resolve(),
    (Path.home() / "Documents").resolve(),
    (Path.home() / "Downloads").resolve(),
]


def _safe_local_path(p: str, *, must_exist: bool = False) -> Optional[Path]:
    """Resolve `p` and ensure it lives under one of the sandboxed roots.

    Returns the resolved Path on success, None on rejection.
    """
    try:
        if not p:
            return None
        path = Path(p).expanduser().resolve()
        if must_exist and not path.exists():
            return None
        for root in _ALLOWED_ROOTS:
            try:
                path.relative_to(root)
                return path
            except ValueError:
                continue
        return None
    except Exception:
        return None


def _sandbox_error(p: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"local path {p!r} outside sandbox "
                 f"(allowed: ~/Desktop, ~/Documents, ~/Downloads)",
    }


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE DRIVE
# ──────────────────────────────────────────────────────────────────────────

_GDRIVE_API = "https://www.googleapis.com/drive/v3"
_GDRIVE_UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"


def _gdrive_headers() -> Optional[Dict[str, str]]:
    tok = _gdrive_token()
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}"}


def _gdrive_list(args: dict) -> dict:
    """List files in Drive (optionally scoped to a folder or query)."""
    try:
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        folder_id = args.get("folder_id")
        query = args.get("query")
        limit = max(1, min(1000, int(args.get("limit", 50))))
        q_parts: List[str] = ["trashed = false"]
        if folder_id:
            q_parts.append(f"'{folder_id}' in parents")
        if query:
            safe = str(query).replace("'", "\\'")
            q_parts.append(f"name contains '{safe}'")
        params = {
            "q": " and ".join(q_parts),
            "pageSize": limit,
            "fields": "files(id,name,mimeType,modifiedTime,size,parents,webViewLink)",
        }
        r = requests.get(f"{_GDRIVE_API}/files", headers=headers,
                         params=params, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "files": data.get("files", []),
                "count": len(data.get("files", []))}
    except Exception as e:
        return _err(e)


def _gdrive_search(args: dict) -> dict:
    """Search Drive by filename substring (files.list with q)."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(100, int(args.get("limit", 20))))
        return _gdrive_list({"query": query, "limit": limit})
    except Exception as e:
        return _err(e)


def _gdrive_download(args: dict) -> dict:
    """Download a Drive file to a sandboxed local path."""
    try:
        file_id = str(args.get("file_id", "")).strip()
        save_to = str(args.get("save_to", "")).strip()
        if not file_id or not save_to:
            return {"ok": False, "error": "file_id and save_to required"}
        path = _safe_local_path(save_to)
        if not path:
            return _sandbox_error(save_to)
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        r = requests.get(f"{_GDRIVE_API}/files/{quote(file_id)}",
                         headers=headers, params={"alt": "media"},
                         timeout=_UPLOAD_TIMEOUT, stream=True)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        path.parent.mkdir(parents=True, exist_ok=True)
        bytes_written = 0
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    bytes_written += len(chunk)
        return {"ok": True, "saved_to": str(path), "bytes": bytes_written}
    except Exception as e:
        return _err(e)


def _gdrive_upload(args: dict) -> dict:
    """Upload a local sandboxed file to Drive (multipart)."""
    try:
        local_path = str(args.get("local_path", "")).strip()
        parent = args.get("parent_folder_id")
        mime_type = args.get("mime_type")
        path = _safe_local_path(local_path, must_exist=True)
        if not path:
            return _sandbox_error(local_path)
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        if not mime_type:
            mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        meta: Dict[str, Any] = {"name": path.name}
        if parent:
            meta["parents"] = [str(parent)]
        # multipart/related upload
        boundary = "leon_boundary_47ind"
        body = (
            f"--{boundary}\r\n"
            f"Content-Type: application/json; charset=UTF-8\r\n\r\n"
            f"{json.dumps(meta)}\r\n"
            f"--{boundary}\r\n"
            f"Content-Type: {mime_type}\r\n\r\n"
        ).encode("utf-8")
        with open(path, "rb") as f:
            body += f.read()
        body += f"\r\n--{boundary}--".encode("utf-8")
        up_headers = {**headers,
                      "Content-Type": f"multipart/related; boundary={boundary}"}
        r = requests.post(_GDRIVE_UPLOAD, headers=up_headers,
                          params={"uploadType": "multipart"}, data=body,
                          timeout=_UPLOAD_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "file_id": data.get("id"), "name": data.get("name")}
    except Exception as e:
        return _err(e)


def _gdrive_create_folder(args: dict) -> dict:
    """Create a Drive folder, optionally inside a parent."""
    try:
        name = str(args.get("name", "")).strip()
        if not name:
            return {"ok": False, "error": "name required"}
        parent = args.get("parent_id")
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        body: Dict[str, Any] = {
            "name": name,
            "mimeType": "application/vnd.google-apps.folder",
        }
        if parent:
            body["parents"] = [str(parent)]
        r = requests.post(f"{_GDRIVE_API}/files",
                          headers={**headers, "Content-Type": "application/json"},
                          json=body, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "folder_id": data.get("id"), "name": data.get("name")}
    except Exception as e:
        return _err(e)


def _gdrive_delete(args: dict) -> dict:
    """Delete a Drive file by id. HIGH risk — permanent."""
    try:
        file_id = str(args.get("file_id", "")).strip()
        if not file_id:
            return {"ok": False, "error": "file_id required"}
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        r = requests.delete(f"{_GDRIVE_API}/files/{quote(file_id)}",
                            headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "deleted": file_id}
    except Exception as e:
        return _err(e)


def _gdrive_share(args: dict) -> dict:
    """Grant a Drive permission to an email (default role=reader)."""
    try:
        file_id = str(args.get("file_id", "")).strip()
        email = str(args.get("email", "")).strip()
        role = str(args.get("role", "reader")).strip() or "reader"
        if not file_id or not email:
            return {"ok": False, "error": "file_id and email required"}
        if role not in ("reader", "writer", "commenter", "owner"):
            return {"ok": False, "error": f"invalid role {role!r}"}
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        body = {"type": "user", "role": role, "emailAddress": email}
        r = requests.post(f"{_GDRIVE_API}/files/{quote(file_id)}/permissions",
                          headers={**headers, "Content-Type": "application/json"},
                          json=body, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "permission_id": data.get("id"),
                "email": email, "role": role}
    except Exception as e:
        return _err(e)


def _gdrive_recent(args: dict) -> dict:
    """Most-recently-modified Drive files."""
    try:
        headers = _gdrive_headers()
        if not headers:
            return _missing("GDRIVE_ACCESS_TOKEN", "Google Drive")
        limit = max(1, min(100, int(args.get("limit", 20))))
        params = {
            "pageSize": limit,
            "orderBy": "modifiedTime desc",
            "q": "trashed = false",
            "fields": "files(id,name,mimeType,modifiedTime,size,webViewLink)",
        }
        r = requests.get(f"{_GDRIVE_API}/files", headers=headers,
                         params=params, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        return {"ok": True, "files": data.get("files", []),
                "count": len(data.get("files", []))}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# DROPBOX
# ──────────────────────────────────────────────────────────────────────────

_DBX_RPC = "https://api.dropboxapi.com/2"
_DBX_CONTENT = "https://content.dropboxapi.com/2"


def _dbx_headers(json_body: bool = True) -> Optional[Dict[str, str]]:
    tok = _get_secret("DROPBOX_ACCESS_TOKEN")
    if not tok:
        return None
    h = {"Authorization": f"Bearer {tok}"}
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def _dropbox_list(args: dict) -> dict:
    """List a Dropbox folder (root = `""`)."""
    try:
        headers = _dbx_headers()
        if not headers:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        path = str(args.get("path", ""))
        r = requests.post(f"{_DBX_RPC}/files/list_folder",
                          headers=headers, json={"path": path, "recursive": False},
                          timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        entries = [
            {"name": e.get("name"), "path": e.get("path_display"),
             "type": e.get(".tag"), "size": e.get("size"),
             "modified": e.get("server_modified")}
            for e in data.get("entries", [])
        ]
        return {"ok": True, "entries": entries, "count": len(entries),
                "cursor": data.get("cursor"), "has_more": data.get("has_more")}
    except Exception as e:
        return _err(e)


def _dropbox_search(args: dict) -> dict:
    """Search Dropbox by query."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        limit = max(1, min(100, int(args.get("limit", 20))))
        headers = _dbx_headers()
        if not headers:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        body = {"query": query, "options": {"max_results": limit}}
        r = requests.post(f"{_DBX_RPC}/files/search_v2",
                          headers=headers, json=body, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        matches = []
        for m in data.get("matches", []):
            md = m.get("metadata", {}).get("metadata", {})
            matches.append({"name": md.get("name"),
                            "path": md.get("path_display"),
                            "type": md.get(".tag")})
        return {"ok": True, "matches": matches, "count": len(matches)}
    except Exception as e:
        return _err(e)


def _dropbox_download(args: dict) -> dict:
    """Download a Dropbox path to a sandboxed local file."""
    try:
        remote_path = str(args.get("remote_path", "")).strip()
        save_to = str(args.get("save_to", "")).strip()
        if not remote_path or not save_to:
            return {"ok": False, "error": "remote_path and save_to required"}
        path = _safe_local_path(save_to)
        if not path:
            return _sandbox_error(save_to)
        tok = _get_secret("DROPBOX_ACCESS_TOKEN")
        if not tok:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        headers = {
            "Authorization": f"Bearer {tok}",
            "Dropbox-API-Arg": json.dumps({"path": remote_path}),
        }
        r = requests.post(f"{_DBX_CONTENT}/files/download",
                          headers=headers, timeout=_UPLOAD_TIMEOUT, stream=True)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        path.parent.mkdir(parents=True, exist_ok=True)
        bytes_written = 0
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    bytes_written += len(chunk)
        return {"ok": True, "saved_to": str(path), "bytes": bytes_written}
    except Exception as e:
        return _err(e)


def _dropbox_upload(args: dict) -> dict:
    """Upload a sandboxed local file to a Dropbox path (overwrite mode)."""
    try:
        local_path = str(args.get("local_path", "")).strip()
        remote_path = str(args.get("remote_path", "")).strip()
        if not local_path or not remote_path:
            return {"ok": False, "error": "local_path and remote_path required"}
        path = _safe_local_path(local_path, must_exist=True)
        if not path:
            return _sandbox_error(local_path)
        tok = _get_secret("DROPBOX_ACCESS_TOKEN")
        if not tok:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        headers = {
            "Authorization": f"Bearer {tok}",
            "Content-Type": "application/octet-stream",
            "Dropbox-API-Arg": json.dumps({
                "path": remote_path, "mode": "overwrite",
                "autorename": False, "mute": True,
            }),
        }
        with open(path, "rb") as f:
            data = f.read()
        r = requests.post(f"{_DBX_CONTENT}/files/upload",
                          headers=headers, data=data, timeout=_UPLOAD_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json()
        return {"ok": True, "path": j.get("path_display"),
                "size": j.get("size"), "id": j.get("id")}
    except Exception as e:
        return _err(e)


def _dropbox_delete(args: dict) -> dict:
    """Delete a Dropbox path. HIGH risk — permanent."""
    try:
        path = str(args.get("path", "")).strip()
        if not path:
            return {"ok": False, "error": "path required"}
        headers = _dbx_headers()
        if not headers:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        r = requests.post(f"{_DBX_RPC}/files/delete_v2",
                          headers=headers, json={"path": path},
                          timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        return {"ok": True, "deleted": path}
    except Exception as e:
        return _err(e)


def _dropbox_share_link(args: dict) -> dict:
    """Create (or return existing) shareable link for a Dropbox path."""
    try:
        path = str(args.get("path", "")).strip()
        if not path:
            return {"ok": False, "error": "path required"}
        headers = _dbx_headers()
        if not headers:
            return _missing("DROPBOX_ACCESS_TOKEN", "Dropbox")
        body = {"path": path, "settings": {"requested_visibility": "public"}}
        r = requests.post(f"{_DBX_RPC}/sharing/create_shared_link_with_settings",
                          headers=headers, json=body, timeout=_DEFAULT_TIMEOUT)
        # 409 => link already exists; fall back to list_shared_links
        if r.status_code == 409:
            r2 = requests.post(f"{_DBX_RPC}/sharing/list_shared_links",
                               headers=headers,
                               json={"path": path, "direct_only": True},
                               timeout=_DEFAULT_TIMEOUT)
            if r2.status_code >= 400:
                return {"ok": False, "error": f"HTTP {r2.status_code}", **_wrap_http(r2)}
            links = r2.json().get("links", [])
            if not links:
                return {"ok": False, "error": "link exists but list returned empty"}
            return {"ok": True, "url": links[0].get("url"),
                    "path": links[0].get("path_lower"), "existing": True}
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json()
        return {"ok": True, "url": j.get("url"), "path": j.get("path_lower")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# AWS S3 (boto3, lazy-imported)
# ──────────────────────────────────────────────────────────────────────────

def _boto3():
    """Lazy import boto3. Returns module or None."""
    try:
        import boto3  # type: ignore
        return boto3
    except Exception:
        return None


def _s3_client():
    """Return (client, None) on success, (None, error_dict) on failure."""
    b = _boto3()
    if b is None:
        return None, {"ok": False,
                      "error": "boto3 not installed — run `pip install boto3`"}
    try:
        region = (_get_secret("AWS_REGION") or _get_secret("AWS_DEFAULT_REGION")
                  or "us-east-1")
        ak = _get_secret("AWS_ACCESS_KEY_ID")
        sk = _get_secret("AWS_SECRET_ACCESS_KEY")
        token = _get_secret("AWS_SESSION_TOKEN")
        kwargs: Dict[str, Any] = {"region_name": region}
        if ak and sk:
            kwargs["aws_access_key_id"] = ak
            kwargs["aws_secret_access_key"] = sk
            if token:
                kwargs["aws_session_token"] = token
        # If no explicit creds, boto3 will resolve from ~/.aws/credentials etc.
        client = b.client("s3", **kwargs)
        return client, None
    except Exception as e:
        return None, _err(e)


def _s3_list_buckets(args: dict) -> dict:
    """List all S3 buckets owned by the account."""
    try:
        client, err = _s3_client()
        if err:
            return err
        resp = client.list_buckets()
        buckets = [
            {"name": b.get("Name"),
             "created": b.get("CreationDate").isoformat() if b.get("CreationDate") else None}
            for b in resp.get("Buckets", [])
        ]
        return {"ok": True, "buckets": buckets, "count": len(buckets)}
    except Exception as e:
        return _err(e)


def _s3_list_objects(args: dict) -> dict:
    """List objects in an S3 bucket (optionally by prefix)."""
    try:
        bucket = str(args.get("bucket", "")).strip()
        if not bucket:
            return {"ok": False, "error": "bucket required"}
        prefix = args.get("prefix")
        limit = max(1, min(1000, int(args.get("limit", 100))))
        client, err = _s3_client()
        if err:
            return err
        kwargs: Dict[str, Any] = {"Bucket": bucket, "MaxKeys": limit}
        if prefix:
            kwargs["Prefix"] = str(prefix)
        resp = client.list_objects_v2(**kwargs)
        objs = [
            {"key": o.get("Key"), "size": o.get("Size"),
             "modified": o.get("LastModified").isoformat() if o.get("LastModified") else None,
             "etag": o.get("ETag")}
            for o in resp.get("Contents", [])
        ]
        return {"ok": True, "bucket": bucket, "objects": objs,
                "count": len(objs), "truncated": resp.get("IsTruncated", False)}
    except Exception as e:
        return _err(e)


def _s3_download(args: dict) -> dict:
    """Download an S3 object to a sandboxed local path."""
    try:
        bucket = str(args.get("bucket", "")).strip()
        key = str(args.get("key", "")).strip()
        save_to = str(args.get("save_to", "")).strip()
        if not bucket or not key or not save_to:
            return {"ok": False, "error": "bucket, key, save_to required"}
        path = _safe_local_path(save_to)
        if not path:
            return _sandbox_error(save_to)
        client, err = _s3_client()
        if err:
            return err
        path.parent.mkdir(parents=True, exist_ok=True)
        client.download_file(bucket, key, str(path))
        return {"ok": True, "saved_to": str(path),
                "bucket": bucket, "key": key,
                "bytes": path.stat().st_size}
    except Exception as e:
        return _err(e)


def _s3_upload(args: dict) -> dict:
    """Upload a sandboxed local file to S3."""
    try:
        bucket = str(args.get("bucket", "")).strip()
        key = str(args.get("key", "")).strip()
        local_path = str(args.get("local_path", "")).strip()
        content_type = args.get("content_type")
        if not bucket or not key or not local_path:
            return {"ok": False, "error": "bucket, key, local_path required"}
        path = _safe_local_path(local_path, must_exist=True)
        if not path:
            return _sandbox_error(local_path)
        client, err = _s3_client()
        if err:
            return err
        if not content_type:
            content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        extra = {"ContentType": content_type}
        client.upload_file(str(path), bucket, key, ExtraArgs=extra)
        return {"ok": True, "bucket": bucket, "key": key,
                "bytes": path.stat().st_size, "content_type": content_type}
    except Exception as e:
        return _err(e)


def _s3_delete(args: dict) -> dict:
    """Delete an S3 object. HIGH risk — permanent."""
    try:
        bucket = str(args.get("bucket", "")).strip()
        key = str(args.get("key", "")).strip()
        if not bucket or not key:
            return {"ok": False, "error": "bucket and key required"}
        client, err = _s3_client()
        if err:
            return err
        client.delete_object(Bucket=bucket, Key=key)
        return {"ok": True, "deleted": {"bucket": bucket, "key": key}}
    except Exception as e:
        return _err(e)


def _s3_presigned_url(args: dict) -> dict:
    """Generate a time-limited presigned GET URL for an S3 object."""
    try:
        bucket = str(args.get("bucket", "")).strip()
        key = str(args.get("key", "")).strip()
        expires = max(1, min(7 * 24 * 3600, int(args.get("expires_seconds", 3600))))
        if not bucket or not key:
            return {"ok": False, "error": "bucket and key required"}
        client, err = _s3_client()
        if err:
            return err
        url = client.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": key},
            ExpiresIn=expires,
        )
        return {"ok": True, "url": url, "expires_in": expires,
                "bucket": bucket, "key": key}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# ONEDRIVE (Microsoft Graph)
# ──────────────────────────────────────────────────────────────────────────

_GRAPH = "https://graph.microsoft.com/v1.0"


def _onedrive_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("ONEDRIVE_ACCESS_TOKEN")
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}"}


def _onedrive_path_segment(path: str) -> str:
    """Convert a user path like '/Docs/Foo' into a Graph URL segment."""
    p = (path or "/").strip()
    if p in ("", "/"):
        return "root"
    p = p.lstrip("/")
    return f"root:/{quote(p)}:"


def _onedrive_list(args: dict) -> dict:
    """List children of a OneDrive folder (default = root)."""
    try:
        headers = _onedrive_headers()
        if not headers:
            return _missing("ONEDRIVE_ACCESS_TOKEN", "OneDrive")
        path = str(args.get("path", "/"))
        seg = _onedrive_path_segment(path)
        url = f"{_GRAPH}/me/drive/{seg}/children"
        r = requests.get(url, headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        items = [
            {"id": it.get("id"), "name": it.get("name"),
             "size": it.get("size"),
             "is_folder": "folder" in it,
             "modified": it.get("lastModifiedDateTime"),
             "web_url": it.get("webUrl")}
            for it in data.get("value", [])
        ]
        return {"ok": True, "items": items, "count": len(items), "path": path}
    except Exception as e:
        return _err(e)


def _onedrive_search(args: dict) -> dict:
    """Search OneDrive by query string."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        headers = _onedrive_headers()
        if not headers:
            return _missing("ONEDRIVE_ACCESS_TOKEN", "OneDrive")
        url = f"{_GRAPH}/me/drive/root/search(q='{quote(query)}')"
        r = requests.get(url, headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        data = r.json()
        items = [
            {"id": it.get("id"), "name": it.get("name"),
             "size": it.get("size"),
             "is_folder": "folder" in it,
             "modified": it.get("lastModifiedDateTime"),
             "web_url": it.get("webUrl")}
            for it in data.get("value", [])
        ]
        return {"ok": True, "items": items, "count": len(items)}
    except Exception as e:
        return _err(e)


def _onedrive_download(args: dict) -> dict:
    """Download a OneDrive item by id to a sandboxed local path."""
    try:
        item_id = str(args.get("item_id", "")).strip()
        save_to = str(args.get("save_to", "")).strip()
        if not item_id or not save_to:
            return {"ok": False, "error": "item_id and save_to required"}
        path = _safe_local_path(save_to)
        if not path:
            return _sandbox_error(save_to)
        headers = _onedrive_headers()
        if not headers:
            return _missing("ONEDRIVE_ACCESS_TOKEN", "OneDrive")
        url = f"{_GRAPH}/me/drive/items/{quote(item_id)}/content"
        r = requests.get(url, headers=headers,
                         timeout=_UPLOAD_TIMEOUT, stream=True,
                         allow_redirects=True)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        path.parent.mkdir(parents=True, exist_ok=True)
        bytes_written = 0
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    bytes_written += len(chunk)
        return {"ok": True, "saved_to": str(path), "bytes": bytes_written}
    except Exception as e:
        return _err(e)


def _onedrive_upload(args: dict) -> dict:
    """Upload a sandboxed local file into a OneDrive folder (simple <4MB upload)."""
    try:
        local_path = str(args.get("local_path", "")).strip()
        remote_folder = str(args.get("remote_folder_path", "/")).strip() or "/"
        if not local_path:
            return {"ok": False, "error": "local_path required"}
        path = _safe_local_path(local_path, must_exist=True)
        if not path:
            return _sandbox_error(local_path)
        headers = _onedrive_headers()
        if not headers:
            return _missing("ONEDRIVE_ACCESS_TOKEN", "OneDrive")
        size = path.stat().st_size
        if size > 4 * 1024 * 1024:
            return {"ok": False,
                    "error": f"file {size} bytes > 4MB simple upload limit "
                             f"(resumable upload not yet implemented)"}
        # Build target path: remote_folder + filename
        rf = remote_folder.strip().lstrip("/").rstrip("/")
        target = f"{rf}/{path.name}" if rf else path.name
        url = f"{_GRAPH}/me/drive/root:/{quote(target)}:/content"
        mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        with open(path, "rb") as f:
            data = f.read()
        r = requests.put(url, headers={**headers, "Content-Type": mime_type},
                         data=data, timeout=_UPLOAD_TIMEOUT)
        if r.status_code >= 400:
            return {"ok": False, "error": f"HTTP {r.status_code}", **_wrap_http(r)}
        j = r.json()
        return {"ok": True, "item_id": j.get("id"), "name": j.get("name"),
                "size": j.get("size"), "web_url": j.get("webUrl")}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# CROSS-CLOUD
# ──────────────────────────────────────────────────────────────────────────

def _list_configured(args: dict) -> dict:
    """Report which cloud backends have usable credentials right now."""
    try:
        configured = {
            "gdrive": bool(_gdrive_token()),
            "dropbox": bool(_get_secret("DROPBOX_ACCESS_TOKEN")),
            "onedrive": bool(_get_secret("ONEDRIVE_ACCESS_TOKEN")),
            "s3": False,
        }
        # S3: configured if boto3 importable AND (env creds OR ~/.aws/credentials)
        if _boto3() is not None:
            has_env = bool(_get_secret("AWS_ACCESS_KEY_ID")
                           and _get_secret("AWS_SECRET_ACCESS_KEY"))
            has_file = (Path.home() / ".aws" / "credentials").exists()
            configured["s3"] = has_env or has_file
        return {"ok": True, "configured": configured,
                "available": [k for k, v in configured.items() if v]}
    except Exception as e:
        return _err(e)


def _unified_search(args: dict) -> dict:
    """Fan out a search across every configured cloud backend."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        services = args.get("services")
        if services is None:
            services = ["gdrive", "dropbox", "onedrive"]
        elif isinstance(services, str):
            services = [s.strip() for s in services.split(",") if s.strip()]
        results: Dict[str, Any] = {}
        errors: Dict[str, str] = {}
        total = 0

        if "gdrive" in services and _gdrive_token():
            res = _gdrive_search({"query": query, "limit": 20})
            if res.get("ok"):
                results["gdrive"] = res.get("files", [])
                total += len(res.get("files", []))
            else:
                errors["gdrive"] = res.get("error", "unknown")

        if "dropbox" in services and _get_secret("DROPBOX_ACCESS_TOKEN"):
            res = _dropbox_search({"query": query, "limit": 20})
            if res.get("ok"):
                results["dropbox"] = res.get("matches", [])
                total += len(res.get("matches", []))
            else:
                errors["dropbox"] = res.get("error", "unknown")

        if "onedrive" in services and _get_secret("ONEDRIVE_ACCESS_TOKEN"):
            res = _onedrive_search({"query": query})
            if res.get("ok"):
                results["onedrive"] = res.get("items", [])
                total += len(res.get("items", []))
            else:
                errors["onedrive"] = res.get("error", "unknown")

        return {"ok": True, "query": query, "results": results,
                "total": total, "errors": errors or None,
                "searched": list(results.keys())}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Google Drive
    "cloud.gdrive_list": _gdrive_list,
    "cloud.gdrive_search": _gdrive_search,
    "cloud.gdrive_download": _gdrive_download,
    "cloud.gdrive_upload": _gdrive_upload,
    "cloud.gdrive_create_folder": _gdrive_create_folder,
    "cloud.gdrive_delete": _gdrive_delete,
    "cloud.gdrive_share": _gdrive_share,
    "cloud.gdrive_recent": _gdrive_recent,
    # Dropbox
    "cloud.dropbox_list": _dropbox_list,
    "cloud.dropbox_search": _dropbox_search,
    "cloud.dropbox_download": _dropbox_download,
    "cloud.dropbox_upload": _dropbox_upload,
    "cloud.dropbox_delete": _dropbox_delete,
    "cloud.dropbox_share_link": _dropbox_share_link,
    # AWS S3
    "cloud.s3_list_buckets": _s3_list_buckets,
    "cloud.s3_list_objects": _s3_list_objects,
    "cloud.s3_download": _s3_download,
    "cloud.s3_upload": _s3_upload,
    "cloud.s3_delete": _s3_delete,
    "cloud.s3_presigned_url": _s3_presigned_url,
    # OneDrive
    "cloud.onedrive_list": _onedrive_list,
    "cloud.onedrive_search": _onedrive_search,
    "cloud.onedrive_download": _onedrive_download,
    "cloud.onedrive_upload": _onedrive_upload,
    # Cross-cloud
    "cloud.unified_search": _unified_search,
    "cloud.list_configured": _list_configured,
}
