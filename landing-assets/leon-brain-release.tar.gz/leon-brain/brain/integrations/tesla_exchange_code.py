#!/usr/bin/env python3
"""Exchange a Tesla OAuth authorization code for a token set and install it.
Usage: tesla_exchange_code.py <code> [expected_state] [got_state]
Backs up the previous token file (timestamped, never deleted) before replacing."""
import json, os, sys, time, shutil, urllib.request, urllib.parse
SECURE = "/opt/leon-brain/secure"
TOKENS = os.path.join(SECURE, "tesla_user_tokens.json")
FLEET_TXT = os.path.join(SECURE, "tesla_fleet.txt")
TOKEN_URL = "https://fleet-auth.prd.vn.cloud.tesla.com/oauth2/v3/token"
REDIRECT = "https://sabr-technologies-production.up.railway.app/tesla/callback"

def creds():
    cid = sec = None
    for line in open(FLEET_TXT):
        if line.startswith("CLIENT_ID="): cid = line.split("=",1)[1].strip()
        if line.startswith("CLIENT_SECRET="): sec = line.split("=",1)[1].strip()
    if not (cid and sec): raise SystemExit("missing client creds")
    return cid, sec

def main():
    code = sys.argv[1]
    if len(sys.argv) >= 4 and sys.argv[2] != sys.argv[3]:
        raise SystemExit(f"state mismatch: expected {sys.argv[2]} got {sys.argv[3]}")
    cid, sec = creds()
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code", "client_id": cid, "client_secret": sec,
        "code": code, "redirect_uri": REDIRECT,
        "audience": "https://fleet-api.prd.na.vn.cloud.tesla.com",
    }).encode()
    req = urllib.request.Request(TOKEN_URL, data=data, method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r: body = json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise SystemExit(f"exchange failed HTTP {e.code}: {e.read()[:400]}")
    if "access_token" not in body: raise SystemExit(f"no access_token: {body}")
    body["obtained_at"] = time.time()
    body["obtained_at_human"] = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    body["obtained_via"] = "authorization_code re-auth 2026-08-30"
    if os.path.exists(TOKENS): shutil.copy2(TOKENS, f"{TOKENS}.prev-{int(time.time())}")
    tmp = TOKENS + ".tmp"
    with open(tmp, "w") as fh: json.dump(body, fh, indent=2)
    os.chmod(tmp, 0o600); os.replace(tmp, TOKENS)
    print("installed new token set; expires_in", body.get("expires_in"), "scopes via jwt below")
    import base64
    p = body["access_token"].split(".")[1]; p += "=" * (-len(p) % 4)
    j = json.loads(base64.urlsafe_b64decode(p)); print("scp:", j.get("scp"), "| sub:", j.get("sub","")[:12])

if __name__ == "__main__": main()
