#!/usr/bin/env python3
"""Phantom battery-health watcher — runs from tesla-watch.timer every 15 min.

Dean, 2026-08-30: "if I'm ever below 20% you should advise me not to leave it
parked all night at 20% — go charge it to keep my battery healthy... always let
me know when you think I should be charging."

Read-only: uses vehicle_data on the Fleet API, which does NOT wake a sleeping
car (a 408 just means asleep — we reuse the last reading). Never sends a
command. Alerts go through POST /api/tesla/alert (loopback) so they come out
in Leon's voice on every connected screen, and are logged either way.
"""
from __future__ import annotations
import json, os, sys, time, urllib.request
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, "/opt/leon-brain")
from brain.integrations import tesla_ctl as T  # noqa: E402

STATE = "/opt/leon-brain/brain_state/tesla_watch.json"
TZ = ZoneInfo("America/New_York")
LOW, URGENT = 20, 10
REPEAT_LOW_S, REPEAT_URGENT_S = 6 * 3600, 2 * 3600


def _load():
    try:
        return json.load(open(STATE))
    except Exception:
        return {}


def _save(s):
    tmp = STATE + ".tmp"; json.dump(s, open(tmp, "w"), indent=2); os.replace(tmp, STATE)


def _api_key() -> str:
    # The dashboard auth gate (server/__init__.py _AuthASGIMiddleware) sits in
    # front of /api/tesla/alert and Caddy proxies the PUBLIC domain to this same
    # loopback port, so the route's loopback check alone is not a trust boundary.
    # We present the brain key like any other client. Without this header every
    # alert died as a silent 401 (found 2026-08-30 after restart).
    k = os.environ.get("LEON_API_KEY", "").strip()
    if not k:
        try:
            for line in open("/opt/leon-brain/.env"):
                if line.startswith("LEON_API_KEY="):
                    k = line.split("=", 1)[1].strip().strip('"').strip("'"); break
        except Exception:
            pass
    return k


def _alert(text: str, kind: str) -> bool:
    body = json.dumps({"text": text, "kind": kind, "force": True}).encode()
    req = urllib.request.Request("http://127.0.0.1:8000/api/tesla/alert", data=body, method="POST",
                                 headers={"Content-Type": "application/json",
                                          "Authorization": f"Bearer {_api_key()}"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return bool(json.loads(r.read()).get("ok"))
    except Exception as e:
        print("alert delivery failed:", e); return False


def main():
    s = _load(); now = time.time(); local = datetime.now(TZ)
    d = T.data("charge_state;drive_state;vehicle_state")
    r = d.get("response") or {}
    if r:
        cs, ds = r.get("charge_state") or {}, r.get("drive_state") or {}
        s.update(soc=cs.get("battery_level"), charging=cs.get("charging_state"), limit=cs.get("charge_limit_soc"),
                 range_mi=cs.get("battery_range"), shift=ds.get("shift_state") or "P", odo=(r.get("vehicle_state") or {}).get("odometer"),
                 read_ts=now, asleep=False)
    else:
        s["asleep"] = True   # 408 = asleep; keep last reading, do not wake
        if now - s.get("read_ts", 0) > 3 * 3600:
            print("asleep and last reading is stale; nothing to judge"); _save(s); return
    soc, charging = s.get("soc"), (s.get("charging") or "")
    plugged = charging in ("Charging", "Complete", "Starting")
    hour = local.hour
    kind, text = None, None
    if soc is not None and not plugged:
        if soc <= URGENT:
            kind = "urgent"
            text = (f"Heads up — Phantom's at {soc} percent and not plugged in. That's low enough to matter for the pack, "
                    f"not just for range. Get it on a charger when you can, even a regular outlet overnight helps.")
        elif soc < LOW:
            if hour >= 19 or hour < 6:
                kind = "overnight"
                text = (f"Phantom's sitting at {soc} percent unplugged and it's evening — I'd rather you didn't leave it parked "
                        f"all night that low. One night won't kill it, but it's the habit that ages the pack. Plug it in tonight if you can, "
                        f"or first thing tomorrow.")
            else:
                kind = "low"
                text = (f"Phantom's at {soc} percent and unplugged. You're fine for today, just plan to charge before tonight — "
                        f"I'll nudge you again this evening if it's still low.")
    if kind:
        last_kind, last_ts = s.get("last_alert_kind"), s.get("last_alert_ts", 0)
        repeat = REPEAT_URGENT_S if kind == "urgent" else REPEAT_LOW_S
        escalated = (kind == "urgent" and last_kind != "urgent") or (kind == "overnight" and last_kind == "low")
        if escalated or now - last_ts > repeat:
            delivered = _alert(text, kind)
            s.update(last_alert_kind=kind, last_alert_ts=now, last_alert_delivered=delivered, last_alert_text=text)
            print(f"ALERT[{kind}] delivered={delivered}: {text}")
        else:
            print(f"{kind} condition persists; last alert {int((now-last_ts)/60)} min ago, holding")
    else:
        if plugged and s.get("last_alert_kind"):
            s["last_alert_kind"] = None   # charging now — reset so the next low episode alerts fresh
        print(f"ok: soc={soc} charging={charging or 'n/a'} asleep={s.get('asleep')} hour={hour}")
    s["last_run"] = now
    _save(s)


if __name__ == "__main__":
    main()
