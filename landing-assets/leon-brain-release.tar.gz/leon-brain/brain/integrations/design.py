"""design.py — Leon's design tooling hub (Figma, Canva, stock photos, color/font/icon, generators).

Each tool reads credentials lazily (env first, then `~/.openclaw/secrets.json`),
makes a single `requests` call with a 12s default timeout where the network is
involved, and returns the standard `{ok, ...}` contract used by the rest of the
brain. Nothing in this module raises — every exception is wrapped into
`{"ok": False, "error": "<type>: <msg>"}`.

EXTRA_TOOLS at the bottom maps dotted names (e.g. `design.figma_file`) to
callables that take a single `dict` argument. Import that dict from the
responder / MCP server to register everything in one shot.

Credentials read:
  - FIGMA_ACCESS_TOKEN     — Figma personal access token
  - CANVA_ACCESS_TOKEN     — Canva Connect OAuth token
  - UNSPLASH_ACCESS_KEY    — Unsplash API access key
  - PEXELS_API_KEY         — Pexels API key
  - PIXABAY_API_KEY        — Pixabay API key

Secrets file fallback: `~/.openclaw/secrets.json` — a flat JSON object.

Image outputs land in `~/Documents/leon-design/` (auto-created on import).
Color / font-pairing / icon / generator tools are local where possible and
need no credentials.
"""

from __future__ import annotations

import colorsys
import json
import math
import os
import re
import time
from io import BytesIO
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests

try:
    from PIL import Image, ImageDraw, ImageFont
    _HAVE_PIL = True
except Exception:  # pragma: no cover - PIL should be present alongside media.py
    _HAVE_PIL = False

try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_H
    _HAVE_QR = True
except Exception:
    _HAVE_QR = False


# ──────────────────────────────────────────────────────────────────────────
# CREDENTIALS
# ──────────────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 12.0
_SECRETS_PATH = Path.home() / ".openclaw" / "secrets.json"
_SECRETS_CACHE: Optional[Dict[str, str]] = None
_SECRETS_MTIME: float = 0.0

_OUT_DIR = Path.home() / "Documents" / "leon-design"
try:
    _OUT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass


def _load_secrets_file() -> Dict[str, str]:
    """Lazily load (and cache, with mtime check) the secrets JSON file.

    Returns `{}` on any error — caller falls through to a missing-credential
    message. Never raises, never logs values.
    """
    global _SECRETS_CACHE, _SECRETS_MTIME
    try:
        if not _SECRETS_PATH.exists():
            return {}
        mtime = _SECRETS_PATH.stat().st_mtime
        if _SECRETS_CACHE is not None and mtime == _SECRETS_MTIME:
            return _SECRETS_CACHE
        with open(_SECRETS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {}
        _SECRETS_CACHE = {str(k): str(v) for k, v in data.items()}
        _SECRETS_MTIME = mtime
        return _SECRETS_CACHE
    except Exception:
        return {}


def _get_secret(key: str) -> Optional[str]:
    """Return secret from env first, then secrets.json. None if missing."""
    v = os.environ.get(key)
    if v:
        return v
    secrets = _load_secrets_file()
    v = secrets.get(key)
    return v if v else None


def _missing(key: str, platform: str) -> Dict[str, Any]:
    return {
        "ok": False,
        "error": f"credentials missing — needs {key} env var "
                 f"(or entry in ~/.openclaw/secrets.json) for {platform}",
    }


def _err(e: BaseException) -> Dict[str, Any]:
    """Wrap an exception into the standard error envelope."""
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _need_pil() -> Optional[Dict[str, Any]]:
    if not _HAVE_PIL:
        return {"ok": False, "error": "Pillow (PIL) not installed — run `pip install Pillow`"}
    return None


# ──────────────────────────────────────────────────────────────────────────
# PATH / IMAGE HELPERS
# ──────────────────────────────────────────────────────────────────────────

def _out_path(save_to: Optional[str], default_name: str) -> Path:
    """Resolve an output path. None → `~/Documents/leon-design/<default_name>`."""
    if save_to:
        p = Path(str(save_to)).expanduser()
        if p.is_dir():
            return p / default_name
        p.parent.mkdir(parents=True, exist_ok=True)
        return p
    _OUT_DIR.mkdir(parents=True, exist_ok=True)
    return _OUT_DIR / default_name


def _timestamp_name(prefix: str, ext: str) -> str:
    return f"{prefix}_{int(time.time())}.{ext}"


def _download_to(url: str, save_to: Optional[str], default_name: str,
                 headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Stream a URL to disk. Returns {ok, path, bytes} or an error envelope."""
    try:
        r = requests.get(url, headers=headers or {}, timeout=_DEFAULT_TIMEOUT, stream=True)
        if r.status_code != 200:
            return {"ok": False, "error": f"download failed — HTTP {r.status_code}",
                    "status": r.status_code}
        path = _out_path(save_to, default_name)
        total = 0
        with open(path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    total += len(chunk)
        return {"ok": True, "path": str(path), "bytes": total}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# COLOR HELPERS
# ──────────────────────────────────────────────────────────────────────────

def _clean_hex(value: str) -> Optional[str]:
    """Normalise a hex string to 6-digit lowercase, no leading '#'. None if bad."""
    if not value:
        return None
    s = str(value).strip().lstrip("#").lower()
    if len(s) == 3:
        s = "".join(c * 2 for c in s)
    if len(s) != 6 or any(c not in "0123456789abcdef" for c in s):
        return None
    return s


def _hex_to_rgb(value: str) -> Optional[Tuple[int, int, int]]:
    s = _clean_hex(value)
    if not s:
        return None
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def _rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
    return "{:02x}{:02x}{:02x}".format(
        max(0, min(255, int(rgb[0]))),
        max(0, min(255, int(rgb[1]))),
        max(0, min(255, int(rgb[2]))),
    )


def _rel_luminance(rgb: Tuple[int, int, int]) -> float:
    """WCAG relative luminance of an RGB triple."""
    def chan(c: float) -> float:
        c = c / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (chan(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


# A compact named-colour table for the nearest-name lookup.
_NAMED_COLORS: Dict[str, Tuple[int, int, int]] = {
    "black": (0, 0, 0), "white": (255, 255, 255), "red": (255, 0, 0),
    "green": (0, 128, 0), "lime": (0, 255, 0), "blue": (0, 0, 255),
    "navy": (0, 0, 128), "yellow": (255, 255, 0), "cyan": (0, 255, 255),
    "magenta": (255, 0, 255), "silver": (192, 192, 192), "gray": (128, 128, 128),
    "maroon": (128, 0, 0), "olive": (128, 128, 0), "purple": (128, 0, 128),
    "teal": (0, 128, 128), "orange": (255, 165, 0), "pink": (255, 192, 203),
    "brown": (165, 42, 42), "gold": (255, 215, 0), "indigo": (75, 0, 130),
    "violet": (238, 130, 238), "coral": (255, 127, 80), "salmon": (250, 128, 114),
    "khaki": (240, 230, 140), "crimson": (220, 20, 60), "turquoise": (64, 224, 208),
    "lavender": (230, 230, 250), "beige": (245, 245, 220), "ivory": (255, 255, 240),
    "mint": (189, 252, 201), "charcoal": (54, 69, 79), "slate": (112, 128, 144),
    "aqua marine": (127, 255, 212), "sky blue": (135, 206, 235),
    "forest green": (34, 139, 34), "hot pink": (255, 105, 180),
    "leon cyan": (0, 255, 200), "off white": (250, 250, 250),
}

# Curated font-pairing table. Keys are lowercased font names.
_FONT_PAIRINGS: Dict[str, List[str]] = {
    "inter": ["Lora", "Source Serif Pro", "IBM Plex Mono"],
    "roboto": ["Roboto Slab", "Playfair Display", "Lora"],
    "montserrat": ["Merriweather", "Lora", "Source Sans Pro"],
    "poppins": ["PT Serif", "Lora", "Inter"],
    "playfair display": ["Source Sans Pro", "Montserrat", "Lato"],
    "lora": ["Montserrat", "Open Sans", "Inter"],
    "open sans": ["Playfair Display", "Merriweather", "Bitter"],
    "lato": ["Merriweather", "Playfair Display", "Bitter"],
    "raleway": ["Merriweather", "Lora", "Crimson Text"],
    "oswald": ["Open Sans", "Lato", "Source Sans Pro"],
    "merriweather": ["Montserrat", "Open Sans", "Lato"],
    "nunito": ["Bitter", "Lora", "PT Serif"],
    "work sans": ["Lora", "Source Serif Pro", "Bitter"],
    "ibm plex sans": ["IBM Plex Serif", "IBM Plex Mono", "Lora"],
    "space grotesk": ["IBM Plex Mono", "Inter", "JetBrains Mono"],
    "dm sans": ["DM Serif Display", "Lora", "Bitter"],
    "manrope": ["Lora", "Fraunces", "Source Serif Pro"],
}


# ══════════════════════════════════════════════════════════════════════════
# FIGMA
# ══════════════════════════════════════════════════════════════════════════

_FIGMA_API = "https://api.figma.com/v1"


def _figma_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("FIGMA_ACCESS_TOKEN")
    if not tok:
        return None
    return {"X-Figma-Token": tok}


def _figma_get(path: str, params: Optional[dict] = None) -> Dict[str, Any]:
    """Authenticated GET against the Figma API. Returns {ok, json|error}."""
    headers = _figma_headers()
    if not headers:
        return _missing("FIGMA_ACCESS_TOKEN", "Figma")
    r = requests.get(f"{_FIGMA_API}/{path}", headers=headers,
                     params=params or {}, timeout=_DEFAULT_TIMEOUT)
    if r.status_code != 200:
        try:
            detail = r.json()
        except Exception:
            detail = r.text[:500]
        return {"ok": False, "error": f"Figma HTTP {r.status_code}",
                "status": r.status_code, "detail": detail}
    return {"ok": True, "json": r.json()}


def _figma_file(args: dict) -> dict:
    """Fetch a Figma file's metadata + page list."""
    try:
        file_key = str(args.get("file_key", "")).strip()
        if not file_key:
            return {"ok": False, "error": "file_key required"}
        res = _figma_get(file_key, {"depth": 1})
        if not res.get("ok"):
            return res
        data = res["json"]
        doc = data.get("document", {})
        pages = [
            {"id": c.get("id"), "name": c.get("name"), "type": c.get("type")}
            for c in doc.get("children", [])
        ]
        return {
            "ok": True,
            "file_key": file_key,
            "name": data.get("name"),
            "last_modified": data.get("lastModified"),
            "version": data.get("version"),
            "thumbnail_url": data.get("thumbnailUrl"),
            "page_count": len(pages),
            "pages": pages,
        }
    except Exception as e:
        return _err(e)


def _figma_file_nodes(args: dict) -> dict:
    """Fetch specific nodes from a Figma file by id."""
    try:
        file_key = str(args.get("file_key", "")).strip()
        node_ids = args.get("node_ids")
        if not file_key or not node_ids:
            return {"ok": False, "error": "file_key and node_ids required"}
        if isinstance(node_ids, (list, tuple)):
            ids = ",".join(str(n) for n in node_ids)
        else:
            ids = str(node_ids)
        res = _figma_get(f"files/{file_key}/nodes", {"ids": ids})
        if not res.get("ok"):
            return res
        nodes = res["json"].get("nodes", {})
        out = []
        for nid, payload in nodes.items():
            doc = (payload or {}).get("document", {}) if isinstance(payload, dict) else {}
            out.append({
                "id": nid,
                "name": doc.get("name"),
                "type": doc.get("type"),
                "visible": doc.get("visible", True),
            })
        return {"ok": True, "file_key": file_key, "count": len(out), "nodes": out,
                "raw": res["json"].get("nodes", {})}
    except Exception as e:
        return _err(e)


def _figma_comments(args: dict) -> dict:
    """List comments on a Figma file."""
    try:
        file_key = str(args.get("file_key", "")).strip()
        if not file_key:
            return {"ok": False, "error": "file_key required"}
        res = _figma_get(f"files/{file_key}/comments")
        if not res.get("ok"):
            return res
        comments = res["json"].get("comments", [])
        out = [
            {
                "id": c.get("id"),
                "message": c.get("message"),
                "user": (c.get("user") or {}).get("handle"),
                "created_at": c.get("created_at"),
                "resolved_at": c.get("resolved_at"),
            }
            for c in comments
        ]
        return {"ok": True, "file_key": file_key, "count": len(out), "comments": out}
    except Exception as e:
        return _err(e)


def _figma_export_image(args: dict) -> dict:
    """Render a Figma node to an image and download it to disk."""
    try:
        file_key = str(args.get("file_key", "")).strip()
        node_id = str(args.get("node_id", "")).strip()
        if not file_key or not node_id:
            return {"ok": False, "error": "file_key and node_id required"}
        fmt = str(args.get("format", "png")).lower()
        if fmt not in ("png", "jpg", "svg", "pdf"):
            fmt = "png"
        try:
            scale = float(args.get("scale", 2))
        except Exception:
            scale = 2.0
        scale = max(0.01, min(4.0, scale))
        res = _figma_get("images/" + file_key,
                         {"ids": node_id, "format": fmt, "scale": scale})
        if not res.get("ok"):
            return res
        data = res["json"]
        if data.get("err"):
            return {"ok": False, "error": f"Figma render error: {data['err']}"}
        url = (data.get("images") or {}).get(node_id)
        if not url:
            return {"ok": False, "error": f"no rendered image returned for node {node_id}"}
        safe_node = re.sub(r"[^a-zA-Z0-9]+", "_", node_id)
        name = _timestamp_name(f"figma_{safe_node}", fmt)
        dl = _download_to(url, args.get("save_to"), name)
        if not dl.get("ok"):
            return dl
        return {"ok": True, "file_key": file_key, "node_id": node_id,
                "format": fmt, "scale": scale, "image_url": url,
                "path": dl["path"], "bytes": dl["bytes"]}
    except Exception as e:
        return _err(e)


def _figma_team_projects(args: dict) -> dict:
    """List projects within a Figma team."""
    try:
        team_id = str(args.get("team_id", "")).strip()
        if not team_id:
            return {"ok": False, "error": "team_id required"}
        res = _figma_get(f"teams/{team_id}/projects")
        if not res.get("ok"):
            return res
        projects = res["json"].get("projects", [])
        return {"ok": True, "team_id": team_id, "name": res["json"].get("name"),
                "count": len(projects), "projects": projects}
    except Exception as e:
        return _err(e)


def _figma_project_files(args: dict) -> dict:
    """List files within a Figma project."""
    try:
        project_id = str(args.get("project_id", "")).strip()
        if not project_id:
            return {"ok": False, "error": "project_id required"}
        res = _figma_get(f"projects/{project_id}/files")
        if not res.get("ok"):
            return res
        files = res["json"].get("files", [])
        out = [
            {"key": f.get("key"), "name": f.get("name"),
             "last_modified": f.get("last_modified"),
             "thumbnail_url": f.get("thumbnail_url")}
            for f in files
        ]
        return {"ok": True, "project_id": project_id, "name": res["json"].get("name"),
                "count": len(out), "files": out}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# STOCK PHOTOS — UNSPLASH
# ══════════════════════════════════════════════════════════════════════════

_UNSPLASH_API = "https://api.unsplash.com"


def _unsplash_search(args: dict) -> dict:
    """Search Unsplash for photos matching a query."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        key = _get_secret("UNSPLASH_ACCESS_KEY")
        if not key:
            return _missing("UNSPLASH_ACCESS_KEY", "Unsplash")
        try:
            count = int(args.get("count", 10))
        except Exception:
            count = 10
        count = max(1, min(30, count))
        r = requests.get(
            f"{_UNSPLASH_API}/search/photos",
            params={"query": query, "per_page": count},
            headers={"Authorization": f"Client-ID {key}",
                     "Accept-Version": "v1"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code != 200:
            return {"ok": False, "error": f"Unsplash HTTP {r.status_code}",
                    "status": r.status_code}
        results = r.json().get("results", [])
        out = []
        for p in results:
            out.append({
                "id": p.get("id"),
                "description": p.get("description") or p.get("alt_description"),
                "width": p.get("width"), "height": p.get("height"),
                "color": p.get("color"),
                "author": (p.get("user") or {}).get("name"),
                "thumb": (p.get("urls") or {}).get("thumb"),
                "regular": (p.get("urls") or {}).get("regular"),
            })
        return {"ok": True, "source": "unsplash", "query": query,
                "count": len(out), "photos": out}
    except Exception as e:
        return _err(e)


def _unsplash_download(args: dict) -> dict:
    """Download a specific Unsplash photo (regular size) by id."""
    try:
        photo_id = str(args.get("photo_id", "")).strip()
        if not photo_id:
            return {"ok": False, "error": "photo_id required"}
        key = _get_secret("UNSPLASH_ACCESS_KEY")
        if not key:
            return _missing("UNSPLASH_ACCESS_KEY", "Unsplash")
        headers = {"Authorization": f"Client-ID {key}", "Accept-Version": "v1"}
        r = requests.get(f"{_UNSPLASH_API}/photos/{photo_id}",
                         headers=headers, timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            return {"ok": False, "error": f"Unsplash HTTP {r.status_code}",
                    "status": r.status_code}
        data = r.json()
        url = (data.get("urls") or {}).get("regular")
        if not url:
            return {"ok": False, "error": "no downloadable URL for that photo"}
        # Trigger Unsplash download tracking (best effort, ignore failure).
        dl_loc = (data.get("links") or {}).get("download_location")
        if dl_loc:
            try:
                requests.get(dl_loc, headers=headers, timeout=_DEFAULT_TIMEOUT)
            except Exception:
                pass
        name = _timestamp_name(f"unsplash_{photo_id}", "jpg")
        out = _download_to(url, args.get("save_to"), name)
        if not out.get("ok"):
            return out
        return {"ok": True, "source": "unsplash", "photo_id": photo_id,
                "author": (data.get("user") or {}).get("name"),
                "path": out["path"], "bytes": out["bytes"]}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# STOCK PHOTOS — PEXELS
# ══════════════════════════════════════════════════════════════════════════

_PEXELS_API = "https://api.pexels.com/v1"


def _pexels_search(args: dict) -> dict:
    """Search Pexels for photos matching a query."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        key = _get_secret("PEXELS_API_KEY")
        if not key:
            return _missing("PEXELS_API_KEY", "Pexels")
        try:
            count = int(args.get("count", 10))
        except Exception:
            count = 10
        count = max(1, min(80, count))
        r = requests.get(
            f"{_PEXELS_API}/search",
            params={"query": query, "per_page": count},
            headers={"Authorization": key},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code != 200:
            return {"ok": False, "error": f"Pexels HTTP {r.status_code}",
                    "status": r.status_code}
        photos = r.json().get("photos", [])
        out = []
        for p in photos:
            out.append({
                "id": p.get("id"),
                "description": p.get("alt"),
                "width": p.get("width"), "height": p.get("height"),
                "color": p.get("avg_color"),
                "author": p.get("photographer"),
                "thumb": (p.get("src") or {}).get("medium"),
                "large": (p.get("src") or {}).get("large"),
            })
        return {"ok": True, "source": "pexels", "query": query,
                "count": len(out), "photos": out}
    except Exception as e:
        return _err(e)


def _pexels_download(args: dict) -> dict:
    """Download a specific Pexels photo (large size) by id."""
    try:
        photo_id = str(args.get("photo_id", "")).strip()
        if not photo_id:
            return {"ok": False, "error": "photo_id required"}
        key = _get_secret("PEXELS_API_KEY")
        if not key:
            return _missing("PEXELS_API_KEY", "Pexels")
        r = requests.get(f"{_PEXELS_API}/photos/{photo_id}",
                         headers={"Authorization": key},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            return {"ok": False, "error": f"Pexels HTTP {r.status_code}",
                    "status": r.status_code}
        data = r.json()
        src = data.get("src") or {}
        url = src.get("large2x") or src.get("large") or src.get("original")
        if not url:
            return {"ok": False, "error": "no downloadable URL for that photo"}
        name = _timestamp_name(f"pexels_{photo_id}", "jpg")
        out = _download_to(url, args.get("save_to"), name)
        if not out.get("ok"):
            return out
        return {"ok": True, "source": "pexels", "photo_id": photo_id,
                "author": data.get("photographer"),
                "path": out["path"], "bytes": out["bytes"]}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# STOCK PHOTOS — PIXABAY
# ══════════════════════════════════════════════════════════════════════════

_PIXABAY_API = "https://pixabay.com/api/"


def _pixabay_search(args: dict) -> dict:
    """Search Pixabay for photos matching a query."""
    try:
        query = str(args.get("query", "")).strip()
        if not query:
            return {"ok": False, "error": "query required"}
        key = _get_secret("PIXABAY_API_KEY")
        if not key:
            return _missing("PIXABAY_API_KEY", "Pixabay")
        try:
            count = int(args.get("count", 10))
        except Exception:
            count = 10
        count = max(3, min(50, count))
        r = requests.get(
            _PIXABAY_API,
            params={"key": key, "q": query, "per_page": count,
                    "image_type": "photo", "safesearch": "true"},
            timeout=_DEFAULT_TIMEOUT,
        )
        if r.status_code != 200:
            return {"ok": False, "error": f"Pixabay HTTP {r.status_code}",
                    "status": r.status_code}
        hits = r.json().get("hits", [])
        out = []
        for p in hits:
            out.append({
                "id": p.get("id"),
                "description": p.get("tags"),
                "width": p.get("imageWidth"), "height": p.get("imageHeight"),
                "author": p.get("user"),
                "thumb": p.get("previewURL"),
                "large": p.get("largeImageURL") or p.get("webformatURL"),
                "page": p.get("pageURL"),
            })
        return {"ok": True, "source": "pixabay", "query": query,
                "count": len(out), "photos": out}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# CANVA
# ══════════════════════════════════════════════════════════════════════════

_CANVA_API = "https://api.canva.com/rest/v1"


def _canva_headers() -> Optional[Dict[str, str]]:
    tok = _get_secret("CANVA_ACCESS_TOKEN")
    if not tok:
        return None
    return {"Authorization": f"Bearer {tok}", "Content-Type": "application/json"}


def _canva_designs(args: dict) -> dict:
    """List the authenticated Canva user's recent designs."""
    try:
        headers = _canva_headers()
        if not headers:
            return _missing("CANVA_ACCESS_TOKEN", "Canva")
        try:
            limit = int(args.get("limit", 20))
        except Exception:
            limit = 20
        limit = max(1, min(100, limit))
        r = requests.get(f"{_CANVA_API}/designs",
                         headers=headers, params={"limit": limit},
                         timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            try:
                detail = r.json()
            except Exception:
                detail = r.text[:500]
            return {"ok": False, "error": f"Canva HTTP {r.status_code}",
                    "status": r.status_code, "detail": detail}
        items = r.json().get("items", [])
        out = []
        for d in items:
            out.append({
                "id": d.get("id"),
                "title": d.get("title"),
                "url": (d.get("urls") or {}).get("view_url"),
                "edit_url": (d.get("urls") or {}).get("edit_url"),
                "updated_at": d.get("updated_at"),
            })
        return {"ok": True, "count": len(out), "designs": out}
    except Exception as e:
        return _err(e)


def _canva_create_design(args: dict) -> dict:
    """Create a new Canva design of a given preset type."""
    try:
        design_type = str(args.get("design_type", "")).strip()
        if not design_type:
            return {"ok": False, "error": "design_type required (e.g. 'presentation', 'doc', 'whiteboard')"}
        headers = _canva_headers()
        if not headers:
            return _missing("CANVA_ACCESS_TOKEN", "Canva")
        body: Dict[str, Any] = {
            "design_type": {"type": "preset", "name": design_type}
        }
        title = args.get("title")
        if title:
            body["title"] = str(title)
        r = requests.post(f"{_CANVA_API}/designs", headers=headers,
                          json=body, timeout=_DEFAULT_TIMEOUT)
        if r.status_code not in (200, 201):
            try:
                detail = r.json()
            except Exception:
                detail = r.text[:500]
            return {"ok": False, "error": f"Canva HTTP {r.status_code}",
                    "status": r.status_code, "detail": detail}
        d = r.json().get("design", {})
        return {"ok": True, "id": d.get("id"), "title": d.get("title"),
                "edit_url": (d.get("urls") or {}).get("edit_url"),
                "view_url": (d.get("urls") or {}).get("view_url")}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# COLOR TOOLS  (local, no key)
# ══════════════════════════════════════════════════════════════════════════

def _color_palette_extract(args: dict) -> dict:
    """Extract the dominant colors from an image via PIL quantize."""
    try:
        gate = _need_pil()
        if gate:
            return gate
        image_path = str(args.get("image_path", "")).strip()
        if not image_path:
            return {"ok": False, "error": "image_path required"}
        p = Path(image_path).expanduser()
        if not p.exists():
            return {"ok": False, "error": f"image not found: {p}"}
        try:
            count = int(args.get("count", 6))
        except Exception:
            count = 6
        count = max(2, min(16, count))
        img = Image.open(p).convert("RGB")
        # Shrink for speed, then quantize to `count` colours.
        img.thumbnail((200, 200))
        quant = img.quantize(colors=count, method=Image.Quantize.MEDIANCUT)
        palette = quant.getpalette() or []
        color_counts = quant.getcolors() or []
        color_counts.sort(reverse=True)
        total = sum(c for c, _ in color_counts) or 1
        out = []
        for cnt, idx in color_counts:
            rgb = (palette[idx * 3], palette[idx * 3 + 1], palette[idx * 3 + 2])
            out.append({
                "hex": "#" + _rgb_to_hex(rgb),
                "rgb": list(rgb),
                "weight": round(cnt / total, 4),
            })
        return {"ok": True, "image": str(p), "count": len(out), "palette": out}
    except Exception as e:
        return _err(e)


def _color_scheme(args: dict) -> dict:
    """Generate a color scheme from a base hex (complementary/triadic/etc.)."""
    try:
        base = _clean_hex(str(args.get("base_hex", "")))
        if not base:
            return {"ok": False, "error": "base_hex must be a valid hex color"}
        scheme = str(args.get("scheme", "complementary")).lower().strip()
        rgb = _hex_to_rgb(base)
        h, l, s = colorsys.rgb_to_hls(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255)

        def mk(hh: float, ll: float, ss: float) -> str:
            rr, gg, bb = colorsys.hls_to_rgb(hh % 1.0, max(0, min(1, ll)),
                                             max(0, min(1, ss)))
            return "#" + _rgb_to_hex((rr * 255, gg * 255, bb * 255))

        if scheme == "complementary":
            colors = [mk(h, l, s), mk(h + 0.5, l, s)]
        elif scheme == "triadic":
            colors = [mk(h, l, s), mk(h + 1 / 3, l, s), mk(h + 2 / 3, l, s)]
        elif scheme == "analogous":
            colors = [mk(h - 1 / 12, l, s), mk(h, l, s), mk(h + 1 / 12, l, s)]
        elif scheme == "monochromatic":
            colors = [mk(h, ll, s) for ll in (0.2, 0.35, 0.5, 0.65, 0.8)]
        elif scheme == "split-complementary":
            colors = [mk(h, l, s), mk(h + 0.5 - 1 / 12, l, s), mk(h + 0.5 + 1 / 12, l, s)]
        else:
            return {"ok": False, "error": "scheme must be one of: complementary, "
                    "triadic, analogous, monochromatic, split-complementary"}
        return {"ok": True, "base": "#" + base, "scheme": scheme, "colors": colors}
    except Exception as e:
        return _err(e)


def _contrast_check(args: dict) -> dict:
    """Compute the WCAG contrast ratio between two colors and grade it."""
    try:
        fg = _hex_to_rgb(str(args.get("fg_hex", "")))
        bg = _hex_to_rgb(str(args.get("bg_hex", "")))
        if not fg or not bg:
            return {"ok": False, "error": "fg_hex and bg_hex must be valid hex colors"}
        l1, l2 = _rel_luminance(fg), _rel_luminance(bg)
        lighter, darker = max(l1, l2), min(l1, l2)
        ratio = (lighter + 0.05) / (darker + 0.05)
        ratio_r = round(ratio, 2)
        return {
            "ok": True,
            "fg": "#" + _clean_hex(str(args.get("fg_hex"))),
            "bg": "#" + _clean_hex(str(args.get("bg_hex"))),
            "ratio": ratio_r,
            "aa_normal": ratio >= 4.5,
            "aa_large": ratio >= 3.0,
            "aaa_normal": ratio >= 7.0,
            "aaa_large": ratio >= 4.5,
            "grade": "AAA" if ratio >= 7.0 else "AA" if ratio >= 4.5
                     else "AA Large" if ratio >= 3.0 else "Fail",
        }
    except Exception as e:
        return _err(e)


def _color_name(args: dict) -> dict:
    """Find the nearest named color to a given hex value."""
    try:
        rgb = _hex_to_rgb(str(args.get("hex", "")))
        if not rgb:
            return {"ok": False, "error": "hex must be a valid hex color"}
        best_name, best_dist = None, float("inf")
        for name, ref in _NAMED_COLORS.items():
            d = sum((a - b) ** 2 for a, b in zip(rgb, ref))
            if d < best_dist:
                best_dist, best_name = d, name
        return {"ok": True, "hex": "#" + _clean_hex(str(args.get("hex"))),
                "name": best_name, "exact": best_dist == 0,
                "distance": round(math.sqrt(best_dist), 1)}
    except Exception as e:
        return _err(e)


def _gradient_css(args: dict) -> dict:
    """Generate a CSS linear-gradient string from two colors."""
    try:
        a = _clean_hex(str(args.get("color_a", "")))
        b = _clean_hex(str(args.get("color_b", "")))
        if not a or not b:
            return {"ok": False, "error": "color_a and color_b must be valid hex colors"}
        direction = str(args.get("direction", "to right")).strip() or "to right"
        css = f"linear-gradient({direction}, #{a}, #{b})"
        return {
            "ok": True,
            "css": f"background: {css};",
            "value": css,
            "color_a": "#" + a,
            "color_b": "#" + b,
            "direction": direction,
        }
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# FONTS
# ══════════════════════════════════════════════════════════════════════════

# Public Google Fonts metadata endpoint — no API key required.
_GOOGLE_FONTS_META = "https://fonts.google.com/metadata/fonts"


def _google_fonts_search(args: dict) -> dict:
    """Search the Google Fonts catalog by name (no API key needed)."""
    try:
        query = str(args.get("query", "")).strip().lower()
        if not query:
            return {"ok": False, "error": "query required"}
        r = requests.get(_GOOGLE_FONTS_META, timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            return {"ok": False, "error": f"Google Fonts HTTP {r.status_code}",
                    "status": r.status_code}
        # The metadata endpoint prefixes the JSON with a `)]}'` guard line.
        text = r.text
        if text.startswith(")]}'"):
            text = text.split("\n", 1)[1] if "\n" in text else text[4:]
        data = json.loads(text)
        families = data.get("familyMetadataList", [])
        out = []
        for f in families:
            fam = f.get("family", "")
            if query in fam.lower():
                out.append({
                    "family": fam,
                    "category": f.get("category"),
                    "variants": list((f.get("fonts") or {}).keys()),
                    "popularity": f.get("popularity"),
                })
        out.sort(key=lambda x: x.get("popularity") or 99999)
        return {"ok": True, "query": query, "count": len(out), "fonts": out[:25]}
    except Exception as e:
        return _err(e)


def _font_pairing(args: dict) -> dict:
    """Suggest font pairings for a given font from a curated table."""
    try:
        font_name = str(args.get("font_name", "")).strip()
        if not font_name:
            return {"ok": False, "error": "font_name required"}
        key = font_name.lower()
        pairs = _FONT_PAIRINGS.get(key)
        if pairs:
            return {"ok": True, "font": font_name, "source": "curated",
                    "pairings": pairs}
        # Fallback: case-insensitive partial match against the table.
        for k, v in _FONT_PAIRINGS.items():
            if key in k or k in key:
                return {"ok": True, "font": font_name, "matched": k,
                        "source": "curated-partial", "pairings": v}
        # Generic default — a safe serif + mono combination.
        return {
            "ok": True,
            "font": font_name,
            "source": "default",
            "pairings": ["Lora", "Source Serif Pro", "IBM Plex Mono"],
            "note": "no curated entry — these are safe general-purpose pairings",
        }
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# ICONS  (Lucide / Feather)
# ══════════════════════════════════════════════════════════════════════════

# Raw icon-set sources. Both Lucide and Feather expose individual SVG files.
_ICON_SOURCES = {
    "lucide": {
        "tags": "https://raw.githubusercontent.com/lucide-icons/lucide/main/icons/{name}.json",
        "svg": "https://raw.githubusercontent.com/lucide-icons/lucide/main/icons/{name}.svg",
        "index": "https://api.github.com/repos/lucide-icons/lucide/contents/icons",
    },
    "feather": {
        "svg": "https://raw.githubusercontent.com/feathericons/feather/main/icons/{name}.svg",
        "index": "https://api.github.com/repos/feathericons/feather/contents/icons",
    },
}

_ICON_INDEX_CACHE: Dict[str, List[str]] = {}


def _fetch_icon_index(source: str) -> Tuple[bool, Any]:
    """Fetch (and cache) the list of icon names for an icon set."""
    if source in _ICON_INDEX_CACHE:
        return True, _ICON_INDEX_CACHE[source]
    cfg = _ICON_SOURCES.get(source)
    if not cfg:
        return False, f"unknown icon source '{source}' — use 'lucide' or 'feather'"
    r = requests.get(cfg["index"], timeout=_DEFAULT_TIMEOUT,
                     headers={"Accept": "application/vnd.github+json"})
    if r.status_code != 200:
        return False, f"icon index HTTP {r.status_code}"
    names = []
    for entry in r.json():
        nm = entry.get("name", "")
        if nm.endswith(".svg"):
            names.append(nm[:-4])
    _ICON_INDEX_CACHE[source] = sorted(set(names))
    return True, _ICON_INDEX_CACHE[source]


def _icon_search(args: dict) -> dict:
    """Search an icon set (Lucide / Feather) for matching icon names."""
    try:
        query = str(args.get("query", "")).strip().lower()
        if not query:
            return {"ok": False, "error": "query required"}
        source = str(args.get("source", "lucide")).lower().strip()
        ok, payload = _fetch_icon_index(source)
        if not ok:
            return {"ok": False, "error": payload}
        matches = [n for n in payload if query in n]
        # Prefer prefix matches first.
        matches.sort(key=lambda n: (not n.startswith(query), n))
        return {"ok": True, "source": source, "query": query,
                "count": len(matches), "icons": matches[:40]}
    except Exception as e:
        return _err(e)


def _icon_svg(args: dict) -> dict:
    """Fetch the raw SVG markup for a named icon."""
    try:
        icon_name = str(args.get("icon_name", "")).strip().lower()
        if not icon_name:
            return {"ok": False, "error": "icon_name required"}
        source = str(args.get("source", "lucide")).lower().strip()
        cfg = _ICON_SOURCES.get(source)
        if not cfg:
            return {"ok": False, "error": f"unknown icon source '{source}'"}
        url = cfg["svg"].format(name=icon_name)
        r = requests.get(url, timeout=_DEFAULT_TIMEOUT)
        if r.status_code != 200:
            return {"ok": False, "error": f"icon '{icon_name}' not found in {source} "
                    f"(HTTP {r.status_code})", "status": r.status_code}
        return {"ok": True, "source": source, "icon_name": icon_name,
                "svg": r.text, "url": url}
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# GENERATORS  (local, PIL / qrcode)
# ══════════════════════════════════════════════════════════════════════════

def _load_font(size: int) -> Any:
    """Best-effort load of a TrueType font, falling back to PIL's default."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for c in candidates:
        try:
            if Path(c).exists():
                return ImageFont.truetype(c, size)
        except Exception:
            continue
    try:
        return ImageFont.load_default()
    except Exception:
        return None


def _text_size(draw: Any, text: str, font: Any) -> Tuple[int, int]:
    """Measure text dimensions, robust across Pillow versions."""
    try:
        box = draw.textbbox((0, 0), text, font=font)
        return box[2] - box[0], box[3] - box[1]
    except Exception:
        try:
            return draw.textsize(text, font=font)
        except Exception:
            return (len(text) * 8, 16)


def _readable_text_color(bg_rgb: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """Pick black or white text for legibility over a background."""
    return (0, 0, 0) if _rel_luminance(bg_rgb) > 0.4 else (255, 255, 255)


def _placeholder_image(args: dict) -> dict:
    """Generate a flat-color placeholder PNG with optional centered text."""
    try:
        gate = _need_pil()
        if gate:
            return gate
        try:
            width = int(args.get("width", 600))
            height = int(args.get("height", 400))
        except Exception:
            return {"ok": False, "error": "width and height must be integers"}
        width = max(1, min(5000, width))
        height = max(1, min(5000, height))
        bg = _hex_to_rgb(str(args.get("bg_hex", "00ffc8"))) or (0, 255, 200)
        text = args.get("text")
        if text is None:
            text = f"{width}x{height}"
        text = str(text)
        img = Image.new("RGB", (width, height), bg)
        draw = ImageDraw.Draw(img)
        if text:
            fg = _readable_text_color(bg)
            size = max(12, min(width, height) // 6)
            font = _load_font(size)
            tw, th = _text_size(draw, text, font)
            draw.text(((width - tw) / 2, (height - th) / 2), text,
                      fill=fg, font=font)
        path = _out_path(args.get("save_to"),
                         _timestamp_name("placeholder", "png"))
        img.save(path, "PNG")
        return {"ok": True, "path": str(path), "width": width,
                "height": height, "bg": "#" + _rgb_to_hex(bg)}
    except Exception as e:
        return _err(e)


def _favicon_generate(args: dict) -> dict:
    """Generate a 64x64 favicon PNG from a short text string or emoji."""
    try:
        gate = _need_pil()
        if gate:
            return gate
        label = str(args.get("text_or_emoji", "")).strip()
        if not label:
            return {"ok": False, "error": "text_or_emoji required"}
        size = 64
        bg = _hex_to_rgb(str(args.get("bg_hex", "0a0a0a"))) or (10, 10, 10)
        fg_hint = args.get("fg_hex")
        fg = _hex_to_rgb(str(fg_hint)) if fg_hint else (0, 255, 200)
        if not fg:
            fg = (0, 255, 200)
        img = Image.new("RGBA", (size, size), bg + (255,))
        draw = ImageDraw.Draw(img)
        # Use up to the first 2 characters for legibility.
        glyph = label[:2] if len(label) <= 2 else label[0]
        for fsize in range(52, 18, -4):
            font = _load_font(fsize)
            tw, th = _text_size(draw, glyph, font)
            if tw <= size - 8 and th <= size - 8:
                break
        draw.text(((size - tw) / 2, (size - th) / 2 - 2), glyph,
                  fill=fg + (255,), font=font)
        path = _out_path(args.get("save_to"),
                         _timestamp_name("favicon", "png"))
        img.save(path, "PNG")
        return {"ok": True, "path": str(path), "size": size, "glyph": glyph}
    except Exception as e:
        return _err(e)


def _qr_branded(args: dict) -> dict:
    """Generate a branded QR code with optional custom color and center logo."""
    try:
        if not _HAVE_QR:
            return {"ok": False, "error": "qrcode lib not installed — run `pip install qrcode[pil]`"}
        gate = _need_pil()
        if gate:
            return gate
        data = str(args.get("data", "")).strip()
        if not data:
            return {"ok": False, "error": "data required"}
        fg = _hex_to_rgb(str(args.get("fg_hex", "000000"))) or (0, 0, 0)
        bg = _hex_to_rgb(str(args.get("bg_hex", "ffffff"))) or (255, 255, 255)
        qr = qrcode.QRCode(error_correction=ERROR_CORRECT_H, box_size=10, border=2)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color=fg, back_color=bg).convert("RGBA")
        logo_path = args.get("logo_path")
        embedded = False
        if logo_path:
            lp = Path(str(logo_path)).expanduser()
            if lp.exists():
                try:
                    logo = Image.open(lp).convert("RGBA")
                    qw, qh = img.size
                    lsize = qw // 4
                    logo.thumbnail((lsize, lsize))
                    lw, lh = logo.size
                    # White pad behind the logo so the QR stays scannable.
                    pad = 8
                    plate = Image.new("RGBA", (lw + pad * 2, lh + pad * 2),
                                      (255, 255, 255, 255))
                    img.paste(plate, ((qw - plate.width) // 2,
                                      (qh - plate.height) // 2))
                    img.paste(logo, ((qw - lw) // 2, (qh - lh) // 2), logo)
                    embedded = True
                except Exception:
                    embedded = False
        path = _out_path(args.get("save_to"), _timestamp_name("qr", "png"))
        img.save(path, "PNG")
        return {"ok": True, "path": str(path), "data": data,
                "logo_embedded": embedded, "fg": "#" + _rgb_to_hex(fg)}
    except Exception as e:
        return _err(e)


def _mockup_frame(args: dict) -> dict:
    """Wrap a screenshot in a simple browser or phone frame via PIL."""
    try:
        gate = _need_pil()
        if gate:
            return gate
        screenshot_path = str(args.get("screenshot_path", "")).strip()
        if not screenshot_path:
            return {"ok": False, "error": "screenshot_path required"}
        sp = Path(screenshot_path).expanduser()
        if not sp.exists():
            return {"ok": False, "error": f"screenshot not found: {sp}"}
        frame = str(args.get("frame", "browser")).lower().strip()
        shot = Image.open(sp).convert("RGB")
        sw, sh = shot.size

        if frame == "phone":
            pad, top, bottom, radius = 16, 60, 60, 48
            bg_color = (20, 20, 22)
            canvas = Image.new("RGB", (sw + pad * 2, sh + top + bottom), bg_color)
            canvas.paste(shot, (pad, top))
            draw = ImageDraw.Draw(canvas)
            # Speaker notch + home indicator.
            cx = canvas.width // 2
            draw.rounded_rectangle([cx - 40, 24, cx + 40, 38], radius=7,
                                   fill=(45, 45, 48))
            draw.rounded_rectangle([cx - 60, canvas.height - 34,
                                    cx + 60, canvas.height - 24], radius=5,
                                   fill=(70, 70, 74))
        elif frame == "phone-light":
            pad, top, bottom = 16, 60, 60
            canvas = Image.new("RGB", (sw + pad * 2, sh + top + bottom),
                               (235, 235, 238))
            canvas.paste(shot, (pad, top))
        else:  # browser
            frame = "browser"
            pad, top = 2, 44
            bar_color = (40, 40, 44)
            canvas = Image.new("RGB", (sw + pad * 2, sh + top + pad), bar_color)
            canvas.paste(shot, (pad, top))
            draw = ImageDraw.Draw(canvas)
            # Three traffic-light dots.
            for i, col in enumerate([(255, 95, 86), (255, 189, 46), (39, 201, 63)]):
                cx = 22 + i * 26
                draw.ellipse([cx - 7, 15, cx + 7, 29], fill=col)
            # A faux address-bar pill.
            draw.rounded_rectangle([110, 12, canvas.width - 24, 32],
                                   radius=10, fill=(64, 64, 70))

        path = _out_path(args.get("save_to"),
                         _timestamp_name(f"mockup_{frame}", "png"))
        canvas.save(path, "PNG")
        return {"ok": True, "path": str(path), "frame": frame,
                "width": canvas.width, "height": canvas.height}
    except Exception as e:
        return _err(e)


def _image_to_ascii(args: dict) -> dict:
    """Convert an image to ASCII art at a given character width."""
    try:
        gate = _need_pil()
        if gate:
            return gate
        image_path = str(args.get("image_path", "")).strip()
        if not image_path:
            return {"ok": False, "error": "image_path required"}
        p = Path(image_path).expanduser()
        if not p.exists():
            return {"ok": False, "error": f"image not found: {p}"}
        try:
            width = int(args.get("width", 80))
        except Exception:
            width = 80
        width = max(10, min(300, width))
        img = Image.open(p).convert("L")
        w, h = img.size
        # Characters are ~2x taller than wide — squash vertically.
        new_h = max(1, int((h / w) * width * 0.5))
        img = img.resize((width, new_h))
        ramp = "@%#*+=-:. "
        pixels = list(img.getdata())
        chars = [ramp[min(len(ramp) - 1, p_ * len(ramp) // 256)] for p_ in pixels]
        lines = ["".join(chars[i:i + width]) for i in range(0, len(chars), width)]
        ascii_art = "\n".join(lines)
        return {"ok": True, "image": str(p), "width": width,
                "height": new_h, "ascii": ascii_art}
    except Exception as e:
        return _err(e)


def _aspect_ratio_calc(args: dict) -> dict:
    """Simplify a width:height pair and name a common aspect ratio."""
    try:
        try:
            width = int(args.get("width", 0))
            height = int(args.get("height", 0))
        except Exception:
            return {"ok": False, "error": "width and height must be integers"}
        if width <= 0 or height <= 0:
            return {"ok": False, "error": "width and height must be positive"}
        g = math.gcd(width, height)
        rw, rh = width // g, height // g
        ratio = width / height
        common = {
            (16, 9): "16:9 widescreen", (4, 3): "4:3 standard",
            (21, 9): "21:9 ultrawide", (1, 1): "1:1 square",
            (3, 2): "3:2 classic photo", (9, 16): "9:16 vertical / story",
            (2, 3): "2:3 portrait", (5, 4): "5:4", (3, 4): "3:4 portrait",
            (1, 2): "1:2 tall", (2, 1): "2:1 panorama",
        }
        name = common.get((rw, rh))
        if not name:
            # Match against a known ratio within a small tolerance.
            for (cw, ch), label in common.items():
                if abs((cw / ch) - ratio) < 0.02:
                    name = label + " (approx)"
                    break
        return {
            "ok": True,
            "width": width, "height": height,
            "simplified": f"{rw}:{rh}",
            "decimal": round(ratio, 4),
            "common_name": name or "uncommon ratio",
        }
    except Exception as e:
        return _err(e)


# ══════════════════════════════════════════════════════════════════════════
# REGISTRY
# ══════════════════════════════════════════════════════════════════════════

EXTRA_TOOLS: Dict[str, Callable[[dict], dict]] = {
    # Figma
    "design.figma_file": _figma_file,
    "design.figma_file_nodes": _figma_file_nodes,
    "design.figma_comments": _figma_comments,
    "design.figma_export_image": _figma_export_image,
    "design.figma_team_projects": _figma_team_projects,
    "design.figma_project_files": _figma_project_files,
    # Stock photos
    "design.unsplash_search": _unsplash_search,
    "design.unsplash_download": _unsplash_download,
    "design.pexels_search": _pexels_search,
    "design.pexels_download": _pexels_download,
    "design.pixabay_search": _pixabay_search,
    # Canva
    "design.canva_designs": _canva_designs,
    "design.canva_create_design": _canva_create_design,
    # Color tools
    "design.color_palette_extract": _color_palette_extract,
    "design.color_scheme": _color_scheme,
    "design.contrast_check": _contrast_check,
    "design.color_name": _color_name,
    "design.gradient_css": _gradient_css,
    # Fonts
    "design.google_fonts_search": _google_fonts_search,
    "design.font_pairing": _font_pairing,
    # Icons
    "design.icon_search": _icon_search,
    "design.icon_svg": _icon_svg,
    # Generators
    "design.placeholder_image": _placeholder_image,
    "design.favicon_generate": _favicon_generate,
    "design.qr_branded": _qr_branded,
    "design.mockup_frame": _mockup_frame,
    "design.image_to_ascii": _image_to_ascii,
    "design.aspect_ratio_calc": _aspect_ratio_calc,
}
