#!/usr/bin/env python3
"""Tesla fast path — fire the car command BEFORE Leon's full reasoning turn.

Dean, 2026-08-30: "I don't want to wait a whole minute of loading when I could
just tap it on the screen myself." Measured: the signed round-trip to Phantom
is ~0.3-0.6s. The lag was never the car — it was Leon's full LLM turn sitting
in front of it. So the WebSocket text ingress (server/routers/websocket.py)
calls match() on every incoming line; if it is an unambiguous car intent the
command is executed right there (sub-second), a one-line confirmation is
broadcast to every screen (phone in the car included, with voice), and the
real result is appended as a note to the text Leon reasons over — so the full
reply is consistent with what already happened instead of promising it.

Deliberately narrow: only intents that are safe to fire without deliberation.
Nothing here flashes lights or honks (Dean has neighbors).
"""
from __future__ import annotations
import importlib.util, os, re, time, json

_HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("tesla_ctl", os.path.join(_HERE, "tesla_ctl.py"))
T = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(T)

_LEAD = r"^(?:(?:hey|yo|ok|okay)\s+)?(?:leon[,.!]?\s+)?(?:can you|could you|please|would you|go ahead and)?\s*"
_INTENTS = [
    ("nav", re.compile(_LEAD + r"(?:take me|navigate(?: me)?|(?:get|send|give)(?: me)? directions|drive me|route me|get me|bring me|set (?:the )?nav(?:igation)?|nav)\s+to\s+(?:the\s+)?(?P<dest>.+?)[.!?\s]*$", re.I)),
    ("nav", re.compile(_LEAD + r"(?:take me|drive me|bring me|get me|go|let's go|head)\s+(?P<dest>home)[.!?\s]*$", re.I)),
    ("lock", re.compile(_LEAD + r"lock (?:the |my )?(?:car|tesla|phantom)\b", re.I)),
    ("unlock", re.compile(_LEAD + r"unlock (?:the |my )?(?:car|tesla|phantom)\b", re.I)),
    ("climate_on", re.compile(_LEAD + r"(?:(?:turn|switch) on (?:the )?(?:ac|a\.?c\.?|air|climate|air conditioning)|start (?:the )?(?:ac|climate)|(?:pre-?cool|cool (?:down|off)?|precondition|warm up) (?:the |my )?(?:car|tesla|phantom|cabin))\b", re.I)),
    ("climate_off", re.compile(_LEAD + r"(?:(?:turn|switch|shut) off (?:the )?(?:ac|a\.?c\.?|air|climate|air conditioning)|stop (?:the )?(?:ac|climate))\b", re.I)),
    ("leaving", re.compile(_LEAD + r"(?:i'?m|im|i am) (?:about to|gonna|going to|finna) (?:leave|head out|come out|walk out|be out)\b", re.I)),
    ("charge_limit", re.compile(_LEAD + r"(?:set )?(?:the |my )?charge limit (?:to )?(?P<pct>\d{2,3})\s*(?:%|percent)?\b", re.I)),
]
_CMD = {"lock": ("door_lock", {}), "unlock": ("door_unlock", {}),
        "climate_on": ("auto_conditioning_start", {}), "climate_off": ("auto_conditioning_stop", {}),
        "leaving": ("auto_conditioning_start", {})}


def match(text: str):
    t = (text or "").strip()
    if not t or len(t) > 220:          # a paragraph is a conversation, not a command
        return None
    for name, rx in _INTENTS:
        m = rx.match(t)
        if m:
            d = m.groupdict()
            if name == "nav":
                dest = re.sub(r"\s+", " ", d["dest"]).strip(" ,.")
                if not dest or dest.lower() in ("the", "a", "there", "it"):
                    return None
                return {"intent": "nav", "dest": dest, "text": t}
            if name == "charge_limit":
                pct = int(d["pct"])
                if not 50 <= pct <= 100:
                    return None
                return {"intent": "charge_limit", "pct": pct, "text": t}
            return {"intent": name, "text": t}
    return None


_PLACES = "/opt/leon-brain/brain_state/tesla_places.json"


def resolve_place(dest: str) -> str:
    """'gym' / 'my mom's house' / 'home' -> the real address Dean gave us.

    The car geocodes free text, which is fine for 'Publix Largo' and useless for
    'my mom's house'. Aliases live in brain_state/tesla_places.json as
    {"alias": "address"}; unknown names pass straight through to the car.
    """
    try:
        places = json.load(open(_PLACES))
    except Exception:
        return dest
    key = re.sub(r"^(?:my|the)\s+", "", dest.strip().lower())
    key = re.sub(r"'s(?:\s+(?:house|place|home|spot))?$", "", key).strip()   # mom's / mom's house / mom's place
    for alias, addr in places.items():
        a = alias.strip().lower()
        if (key == a or key == re.sub(r"^(?:my|the)\s+", "", a)) and str(addr).strip():
            return addr          # blank alias = not filled in yet; let the car try the raw words
    return dest


def _ensure_online() -> bool:
    try:
        r = T._call(T.FLEET, f"/api/1/vehicles/{T.VIN}", "GET")
        st = (r.get("response") or {}).get("state")
        if st == "online":
            return True
        r = T.wake()
        return (r.get("response") or {}).get("state") == "online"
    except Exception:
        return False


def execute(fp: dict) -> dict:
    t0 = time.time()
    res = dict(fp); res["ok"] = False; res["reason"] = ""
    try:
        if not _ensure_online():
            res["reason"] = "car did not wake"
        else:
            if fp["intent"] == "nav":
                r = T.navigate(resolve_place(fp["dest"]))
            elif fp["intent"] == "charge_limit":
                r = T.command("set_charge_limit", {"percent": fp["pct"]})
            else:
                name, body = _CMD[fp["intent"]]
                r = T.command(name, body)
            resp = r.get("response") or {}
            res["ok"] = bool(resp.get("result"))
            res["reason"] = resp.get("reason") or r.get("error") or ""
            if not res["ok"] and "already" in res["reason"]:
                res["ok"] = True   # already_set / already_locked = the state Dean wanted
    except Exception as e:
        res["reason"] = f"{type(e).__name__}: {e}"
    res["latency_s"] = round(time.time() - t0, 2)
    _log(res)
    try:
        from server.helpers import broadcast_response
        broadcast_response(_confirm(res), source="tesla-fastpath", user_label="(Phantom)", force=True)
    except Exception:
        pass
    return res


def _confirm(res: dict) -> str:
    i = res["intent"]
    if res["ok"]:
        return {"nav": f"{res.get('dest')} is on your screen.",
                "lock": "Locked.", "unlock": "Unlocked.",
                "climate_on": "Cooling the cabin now.", "leaving": "Got it — cooling the cabin so it's ready when you get out.",
                "climate_off": "Climate's off.",
                "charge_limit": f"Charge limit set to {res.get('pct')} percent."}[i]
    what = {"nav": f"push {res.get('dest')} to the nav", "lock": "lock it", "unlock": "unlock it",
            "climate_on": "start the climate", "leaving": "start the climate", "climate_off": "stop the climate",
            "charge_limit": "set the charge limit"}[i]
    return f"Couldn't {what} — {res.get('reason') or 'no answer from the car'}."


def note(res: dict) -> str:
    """Appended to the text Leon reasons over so his reply matches reality."""
    return ("\n\n[TESLA FAST-PATH — this command was ALREADY executed on Phantom before you saw this message "
            f"and Dean already heard the one-line confirmation: {json.dumps({k: v for k, v in res.items() if k != 'text'})}. "
            "Do NOT say you are about to do it or ask whether to do it. Reply briefly and naturally; add value or say nothing more.]")


def _log(res: dict) -> None:
    try:
        os.makedirs("/opt/leon-brain/brain_state", exist_ok=True)
        with open("/opt/leon-brain/brain_state/tesla_fastpath.log", "a") as fh:
            fh.write(json.dumps({"ts": time.time(), **res}) + "\n")
    except Exception:
        pass


if __name__ == "__main__":
    import sys
    fp = match(" ".join(sys.argv[1:]))
    print("match:", fp)
    if fp and "--run" in sys.argv:
        print(execute(fp))
