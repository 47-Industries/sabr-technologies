#!/usr/bin/env python3
"""Tesla fast path — fire the car command BEFORE Leon's full reasoning turn.

Dean, 2026-08-30: "I don't want to wait a whole minute of loading when I could
just tap it on the screen myself." Measured: the signed round-trip to Phantom
is ~0.3-0.6s. The lag was never the car — it was Leon's full LLM turn sitting
in front of it. So the WebSocket text ingress (server/routers/websocket.py)
calls match() on every incoming line; if it is an unambiguous car intent the
command is executed right there (sub-second), a one-line confirmation is
broadcast to every screen (phone in the car included, with voice), and the
real result is appended as a note to the text Leon reasons over — so the full
reply is consistent with what already happened instead of promising it.

Deliberately narrow: only intents that are safe to fire without deliberation.
Nothing here flashes lights or honks (Dean has neighbors).
"""
from __future__ import annotations
import importlib.util, os, re, time, json

_HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("tesla_ctl", os.path.join(_HERE, "tesla_ctl.py"))
T = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(T)

_LEAD = r"^(?:(?:hey|yo|ok|okay)\s+)?(?:leon[,.!]?\s+)?(?:can you|could you|please|would you|go ahead and)?\s*"
_INTENTS = [
    ("nav", re.compile(_LEAD + r"(?:take me|navigate(?: me)?|(?:get|send|give)(?: me)? directions|drive me|route me|get me|bring me|set (?:the )?nav(?:igation)?|nav)\s+to\s+(?:the\s+)?(?P<dest>.+?)[.!?\s]*$", re.I)),
    ("nav", re.compile(_LEAD + r"(?:take me|drive me|bring me|get me|go|let's go|head)\s+(?P<dest>home)[.!?\s]*$", re.I)),
    ("lock", re.compile(_LEAD + r"lock (?:the |my )?(?:car|tesla|phantom)\b", re.I)),
    ("unlock", re.compile(_LEAD + r"unlock (?:the |my )?(?:car|tesla|phantom)\b", re.I)),
    ("climate_on", re.compile(_LEAD + r"(?:(?:turn|switch) on (?:the )?(?:ac|a\.?c\.?|air|climate|air conditioning)|start (?:the )?(?:ac|climate)|(?:pre-?cool|cool (?:down|off)?|precondition|warm up) (?:the |my )?(?:car|tesla|phantom|cabin))\b", re.I)),
    ("climate_off", re.compile(_LEAD + r"(?:(?:turn|switch|shut) off (?:the )?(?:ac|a\.?c\.?|air|climate|air conditioning)|stop (?:the )?(?:ac|climate))\b", re.I)),
    ("leaving", re.compile(_LEAD + r"(?:i'?m|im|i am) (?:about to|gonna|going to|finna) (?:leave|head out|come out|walk out|be out)\b", re.I)),
    ("charge_limit", re.compile(_LEAD + r"(?:set )?(?:the |my )?charge limit (?:to )?(?P<pct>\d{2,3})\s*(?:%|percent)?\b", re.I)),
]
# Read-only instant answers (Dean, plan D.17). These never wake the car: a
# sleeping Phantom answers from the last reading the battery watcher saved.
_Q = r"^(?:(?:hey|yo|ok|okay)\s+)?(?:leon[,.!]?\s+)?"
_QUERIES = [
    ("where", re.compile(_Q + r"(?:where(?:'s| is| are)\s+(?:the |my )?(?:car|tesla|phantom|we|you)|where am i|where(?:'s| is) she)\b", re.I)),
    ("battery", re.compile(_Q + r"(?:(?:what(?:'s| is)|how(?:'s| is)) (?:the |my |phantom'?s )?(?:battery|charge|range)|how much (?:battery|charge|range)|battery(?: level| status)?\??$|(?:is|is it|is she|is the car) charging)\b", re.I)),
    ("eta", re.compile(_Q + r"(?:what(?:'s| is) (?:the |my )?(?:eta|e\.t\.a\.)|how (?:far|long)(?: (?:away|out|left|to go|till|until))?|(?:eta|e\.t\.a\.)\??$|how many (?:miles|minutes) (?:left|out|to go))\b", re.I)),
    ("locked", re.compile(_Q + r"(?:is (?:the |my )?(?:car|tesla|phantom|she|it) locked|did (?:you|i) lock (?:the |my )?(?:car|tesla|phantom|it)|lock status)\b", re.I)),
    ("cabin", re.compile(_Q + r"(?:how (?:hot|cold|warm) is it in (?:the |my )?(?:car|tesla|phantom)|(?:what(?:'s| is) (?:the )?)?cabin temp(?:erature)?|is (?:the )?(?:ac|climate|a\.?c\.?) (?:on|running))\b", re.I)),
]

_CMD = {"lock": ("door_lock", {}), "unlock": ("door_unlock", {}),
        "climate_on": ("auto_conditioning_start", {}), "climate_off": ("auto_conditioning_stop", {}),
        "leaving": ("auto_conditioning_start", {})}


def match(text: str):
    t = (text or "").strip()
    if not t or len(t) > 220:          # a paragraph is a conversation, not a command
        return None
    for qname, rx in _QUERIES:
        if rx.match(t):
            return {"intent": "query", "q": qname, "text": t}
    for name, rx in _INTENTS:
        m = rx.match(t)
        if m:
            d = m.groupdict()
            if name == "nav":
                dest = re.sub(r"\s+", " ", d["dest"]).strip(" ,.")
                if not dest or dest.lower() in ("the", "a", "there", "it"):
                    return None
                return {"intent": "nav", "dest": dest, "text": t}
            if name == "charge_limit":
                pct = int(d["pct"])
                if not 50 <= pct <= 100:
                    return None
                return {"intent": "charge_limit", "pct": pct, "text": t}
            return {"intent": name, "text": t}
    return None


_PLACES = "/opt/leon-brain/brain_state/tesla_places.json"


def resolve_place(dest: str) -> str:
    """'gym' / 'my mom's house' / 'home' -> the real address Dean gave us.

    The car geocodes free text, which is fine for 'Publix Largo' and useless for
    'my mom's house'. Aliases live in brain_state/tesla_places.json as
    {"alias": "address"}; unknown names pass straight through to the car.
    """
    try:
        places = json.load(open(_PLACES))
    except Exception:
        return dest
    key = re.sub(r"^(?:my|the)\s+", "", dest.strip().lower())
    key = re.sub(r"'s(?:\s+(?:house|place|home|spot))?$", "", key).strip()   # mom's / mom's house / mom's place
    for alias, addr in places.items():
        a = alias.strip().lower()
        if (key == a or key == re.sub(r"^(?:my|the)\s+", "", a)) and str(addr).strip():
            return addr          # blank alias = not filled in yet; let the car try the raw words
    return dest


def _ensure_online() -> bool:
    try:
        r = T._call(T.FLEET, f"/api/1/vehicles/{T.VIN}", "GET")
        st = (r.get("response") or {}).get("state")
        if st == "online":
            return True
        r = T.wake()
        return (r.get("response") or {}).get("state") == "online"
    except Exception:
        return False


def execute(fp: dict) -> dict:
    t0 = time.time()
    res = dict(fp); res["ok"] = False; res["reason"] = ""
    try:
        if fp["intent"] == "query":
            res["answer"] = _answer(fp["q"])
            res["ok"] = bool(res["answer"])
            res["reason"] = "" if res["ok"] else "no reading"
        elif not _ensure_online():
            res["reason"] = "car did not wake"
        else:
            if fp["intent"] == "nav":
                r = T.navigate(resolve_place(fp["dest"]))
            elif fp["intent"] == "charge_limit":
                r = T.command("set_charge_limit", {"percent": fp["pct"]})
            else:
                name, body = _CMD[fp["intent"]]
                r = T.command(name, body)
            resp = r.get("response") or {}
            res["ok"] = bool(resp.get("result"))
            res["reason"] = resp.get("reason") or r.get("error") or ""
            if not res["ok"] and "already" in res["reason"]:
                res["ok"] = True   # already_set / already_locked = the state Dean wanted
    except Exception as e:
        res["reason"] = f"{type(e).__name__}: {e}"
    res["latency_s"] = round(time.time() - t0, 2)
    _log(res)
    try:
        from server.helpers import broadcast_response
        broadcast_response(_confirm(res), source="tesla-fastpath", user_label="(Phantom)", force=True)
    except Exception:
        pass
    return res


_WATCH = "/opt/leon-brain/brain_state/tesla_watch.json"


def _reading() -> tuple:
    """(live vehicle_data response or None, last saved watcher reading or {})."""
    live = None
    try:
        r = T.data("drive_state;vehicle_state;charge_state;climate_state")
        resp = r.get("response") or {}
        if resp and not r.get("error"):
            live = resp
    except Exception:
        live = None
    try:
        with open(_WATCH, encoding="utf-8") as fh:
            saved = json.load(fh)
    except Exception:
        saved = {}
    return live, saved


def _ago(ts) -> str:
    try:
        m = int((time.time() - float(ts)) / 60)
    except Exception:
        return ""
    return "just now" if m < 2 else (f"{m} minutes ago" if m < 120 else f"{m // 60} hours ago")


def _answer(q: str) -> str:
    live, saved = _reading()
    ds = (live or {}).get("drive_state") or {}
    cs = (live or {}).get("charge_state") or {}
    cl = (live or {}).get("climate_state") or {}
    vs = (live or {}).get("vehicle_state") or {}
    asleep = live is None
    stale = f" (she's asleep — last reading {_ago(saved.get('read_ts'))})" if asleep and saved else ""
    if q == "battery":
        soc = cs.get("battery_level") if not asleep else saved.get("soc")
        rng = cs.get("battery_range") if not asleep else saved.get("range_mi")
        chg = (cs.get("charging_state") if not asleep else saved.get("charging")) or "unknown"
        if soc is None:
            return ""
        state = "charging" if chg == "Charging" else ("plugged in, not charging" if chg in ("Complete", "Stopped") else "not plugged in")
        return f"Phantom's at {int(soc)} percent, about {int(rng or 0)} miles, {state}{stale}."
    if q == "eta":
        dest = ds.get("active_route_destination"); mi = ds.get("active_route_miles_to_arrival"); mn = ds.get("active_route_minutes_to_arrival")
        if asleep:
            return f"No route — she's asleep{stale}."
        if not dest:
            return "No route on the screen right now."
        return f"{dest}: {mi:.1f} miles, about {int(round(mn or 0))} minutes."
    if q == "where":
        if asleep:
            return f"She's parked and asleep{stale}."
        spd = ds.get("speed") or 0; shift = ds.get("shift_state") or "P"; dest = ds.get("active_route_destination")
        moving = f"doing {int(spd)} on the way to {dest}" if spd and dest else (f"moving at {int(spd)}" if spd else ("parked" if shift in ("P", None) else "stopped, in " + str(shift)))
        return f"Phantom's {moving}."
    if q == "locked":
        if asleep:
            return f"Last I saw she was locked{stale}." if saved else ""
        return "Locked." if vs.get("locked") else "UNLOCKED right now."
    if q == "cabin":
        if asleep:
            return f"Climate's off, she's asleep{stale}."
        t_in = cl.get("inside_temp"); on = cl.get("is_climate_on"); tgt = cl.get("driver_temp_setting")
        if t_in is None:
            return ""
        f_in = t_in * 9 / 5 + 32
        return f"Cabin's {int(round(f_in))} degrees" + (f", climate on, set to {int(round(tgt * 9 / 5 + 32))}." if on and tgt else ", climate off.")
    return ""


def _confirm(res: dict) -> str:
    i = res["intent"]
    if i == "query":
        return res.get("answer") or "I can't get a reading from Phantom right now."
    if res["ok"]:
        return {"nav": f"Sent {res.get('dest')} to Phantom — if the browser is open, close it and tap the navigate card on the map.",
                "lock": "Locked.", "unlock": "Unlocked.",
                "climate_on": "Cooling the cabin now.", "leaving": "Got it — cooling the cabin so it's ready when you get out.",
                "climate_off": "Climate's off.",
                "charge_limit": f"Charge limit set to {res.get('pct')} percent."}[i]
    what = {"nav": f"push {res.get('dest')} to the nav", "lock": "lock it", "unlock": "unlock it",
            "climate_on": "start the climate", "leaving": "start the climate", "climate_off": "stop the climate",
            "charge_limit": "set the charge limit"}[i]
    return f"Couldn't {what} — {res.get('reason') or 'no answer from the car'}."


def note(res: dict) -> str:
    """Appended to the text Leon reasons over so his reply matches reality."""
    return ("\n\n[TESLA FAST-PATH — this command was ALREADY executed on Phantom before you saw this message "
            f"and Dean already heard the one-line confirmation: {json.dumps({k: v for k, v in res.items() if k != 'text'})}. "
            "Do NOT say you are about to do it or ask whether to do it. Reply briefly and naturally; add value or say nothing more.]")


def _log(res: dict) -> None:
    try:
        os.makedirs("/opt/leon-brain/brain_state", exist_ok=True)
        with open("/opt/leon-brain/brain_state/tesla_fastpath.log", "a") as fh:
            fh.write(json.dumps({"ts": time.time(), **res}) + "\n")
    except Exception:
        pass


if __name__ == "__main__":
    import sys
    fp = match(" ".join(sys.argv[1:]))
    print("match:", fp)
    if fp and "--run" in sys.argv:
        print(execute(fp))
