"""Local LLM agent pool for Leon — Ollama-backed sub-agents.

Spawns multiple cheap reasoning agents on Dean's RTX 3070 via Ollama:
single completions, parallel multi-model fan-out, debate, voting, prompt
chains, RAG, summarization, classification — all FREE, no API keys.

All tools take a single `args` dict, return {"ok": bool, ...}, and never
raise. Ollama is expected at http://localhost:11434; if it is down the
tools return a clean, helpful error.
"""

from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional

import requests


# ---------------------------------------------------------------------------
# config / helpers
# ---------------------------------------------------------------------------

_OLLAMA = "http://localhost:11434"
_GEN_TIMEOUT = 30
_PULL_TIMEOUT = 600
_FAST_MODEL = "llama3.2:1b"
_REASON_MODEL = "llama3.2:3b"


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _ollama_down(detail: str = "") -> Dict[str, Any]:
    tip = ("Ollama not reachable at %s — start it with `ollama serve` "
           "(or `systemctl --user start ollama`)." % _OLLAMA)
    if detail:
        tip += " [%s]" % detail
    return {"ok": False, "error": tip}


def _post(path: str, payload: Dict[str, Any],
          timeout: int = _GEN_TIMEOUT) -> Dict[str, Any]:
    """POST JSON to Ollama, return {"ok": True, "data": ...} or error dict."""
    url = _OLLAMA + path
    try:
        r = requests.post(url, json=payload, timeout=timeout)
        if r.status_code >= 400:
            return _err("HTTP %d: %s" % (r.status_code, r.text[:300]))
        return {"ok": True, "data": r.json()}
    except requests.ConnectionError as e:
        return _ollama_down(str(e)[:120])
    except requests.Timeout:
        return _err("timeout after %ds" % timeout)
    except Exception as e:
        return _err("%s: %s" % (type(e).__name__, e))


def _get(path: str, timeout: int = _GEN_TIMEOUT) -> Dict[str, Any]:
    url = _OLLAMA + path
    try:
        r = requests.get(url, timeout=timeout)
        if r.status_code >= 400:
            return _err("HTTP %d: %s" % (r.status_code, r.text[:300]))
        return {"ok": True, "data": r.json()}
    except requests.ConnectionError as e:
        return _ollama_down(str(e)[:120])
    except requests.Timeout:
        return _err("timeout after %ds" % timeout)
    except Exception as e:
        return _err("%s: %s" % (type(e).__name__, e))


def _chat(model: str, messages: List[Dict[str, str]],
          temperature: float = 0.7, timeout: int = _GEN_TIMEOUT,
          fmt: Optional[str] = None) -> Dict[str, Any]:
    """Single non-streaming /api/chat call. Returns {"ok", "text", "model",
    "elapsed", ...} or an error dict."""
    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": float(temperature)},
    }
    if fmt:
        payload["format"] = fmt
    t0 = time.time()
    res = _post("/api/chat", payload, timeout=timeout)
    if not res.get("ok"):
        return res
    data = res["data"]
    text = ((data.get("message") or {}).get("content") or "").strip()
    if not text and data.get("error"):
        return _err("ollama: %s" % data["error"])
    return {
        "ok": True,
        "text": text,
        "model": model,
        "elapsed": round(time.time() - t0, 2),
        "eval_count": data.get("eval_count"),
        "eval_duration": data.get("eval_duration"),
    }


def _simple(model: str, prompt: str, system: Optional[str] = None,
            temperature: float = 0.7, timeout: int = _GEN_TIMEOUT,
            fmt: Optional[str] = None) -> Dict[str, Any]:
    """Convenience: build messages from optional system + user prompt."""
    msgs: List[Dict[str, str]] = []
    if system:
        msgs.append({"role": "system", "content": str(system)})
    msgs.append({"role": "user", "content": str(prompt)})
    return _chat(model, msgs, temperature=temperature, timeout=timeout, fmt=fmt)


def _extract_json(text: str) -> Optional[Any]:
    """Best-effort JSON parse from a model response (handles code fences)."""
    if not text:
        return None
    s = text.strip()
    if s.startswith("```"):
        s = s.split("```", 2)[1]
        if s.lower().startswith("json"):
            s = s[4:]
        s = s.strip()
    try:
        return json.loads(s)
    except Exception:
        pass
    # grab the first balanced {...} or [...] span
    for open_ch, close_ch in (("{", "}"), ("[", "]")):
        start = s.find(open_ch)
        end = s.rfind(close_ch)
        if 0 <= start < end:
            try:
                return json.loads(s[start:end + 1])
            except Exception:
                continue
    return None


# ---------------------------------------------------------------------------
# single-agent tools
# ---------------------------------------------------------------------------

def _ask(args: Dict[str, Any]) -> Dict[str, Any]:
    """One Ollama completion.

    Args: prompt (required), model, system, temperature.
    """
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    res = _simple(
        args.get("model", _REASON_MODEL),
        prompt,
        system=args.get("system"),
        temperature=float(args.get("temperature", 0.7)),
    )
    if not res.get("ok"):
        return res
    return {"ok": True, "answer": res["text"], "model": res["model"],
            "elapsed": res["elapsed"]}


def _classify(args: Dict[str, Any]) -> Dict[str, Any]:
    """Classify text into one of `categories`.

    Args: text (required), categories (required list), model.
    """
    text = args.get("text")
    cats = args.get("categories")
    if not text:
        return _err("text required")
    if not isinstance(cats, list) or not cats:
        return _err("categories (non-empty list) required")
    cats = [str(c) for c in cats]
    system = ("You are a precise text classifier. Reply with EXACTLY one of "
              "the allowed category labels and nothing else.")
    prompt = ("Categories: %s\n\nText:\n%s\n\nCategory:"
              % (", ".join(cats), text))
    res = _simple(args.get("model", _FAST_MODEL), prompt, system=system,
                  temperature=0.0)
    if not res.get("ok"):
        return res
    raw = res["text"].strip()
    pick = None
    low = raw.lower()
    for c in cats:
        if c.lower() == low:
            pick = c
            break
    if pick is None:
        for c in cats:
            if c.lower() in low:
                pick = c
                break
    return {"ok": True, "category": pick or raw, "matched": pick is not None,
            "raw": raw, "model": res["model"]}


def _extract(args: Dict[str, Any]) -> Dict[str, Any]:
    """Extract structured fields per a schema dict, return JSON.

    Args: text (required), schema (required dict of field->description), model.
    """
    text = args.get("text")
    schema = args.get("schema")
    if not text:
        return _err("text required")
    if not isinstance(schema, dict) or not schema:
        return _err("schema (non-empty dict) required")
    fields = "\n".join("- %s: %s" % (k, v) for k, v in schema.items())
    system = ("You extract structured data. Return ONLY a single JSON object "
              "with exactly the requested keys. Use null for missing values.")
    prompt = ("Fields to extract:\n%s\n\nText:\n%s\n\nJSON:"
              % (fields, text))
    res = _simple(args.get("model", _FAST_MODEL), prompt, system=system,
                  temperature=0.0, fmt="json")
    if not res.get("ok"):
        return res
    parsed = _extract_json(res["text"])
    if parsed is None:
        return {"ok": False, "error": "model did not return valid JSON",
                "raw": res["text"]}
    return {"ok": True, "data": parsed, "model": res["model"]}


def _summarize(args: Dict[str, Any]) -> Dict[str, Any]:
    """Summarize text.

    Args: text (required), max_words (default 100), model.
    """
    text = args.get("text")
    if not text:
        return _err("text required")
    max_words = int(args.get("max_words", 100))
    system = "You are a concise summarizer. No preamble, just the summary."
    prompt = ("Summarize the following in at most %d words:\n\n%s"
              % (max_words, text))
    res = _simple(args.get("model", _REASON_MODEL), prompt, system=system,
                  temperature=0.3)
    if not res.get("ok"):
        return res
    return {"ok": True, "summary": res["text"], "model": res["model"]}


def _sentiment(args: Dict[str, Any]) -> Dict[str, Any]:
    """Sentiment of text: positive/negative/neutral + score in [-1, 1].

    Args: text (required), model.
    """
    text = args.get("text")
    if not text:
        return _err("text required")
    system = ("You are a sentiment analyzer. Return ONLY JSON: "
              '{"label": "positive|negative|neutral", "score": <float -1..1>}.')
    res = _simple(args.get("model", _FAST_MODEL),
                  "Text:\n%s\n\nJSON:" % text, system=system,
                  temperature=0.0, fmt="json")
    if not res.get("ok"):
        return res
    parsed = _extract_json(res["text"])
    if not isinstance(parsed, dict):
        return {"ok": False, "error": "no valid sentiment JSON",
                "raw": res["text"]}
    label = str(parsed.get("label", "")).lower().strip()
    if label not in ("positive", "negative", "neutral"):
        label = "neutral"
    try:
        score = max(-1.0, min(1.0, float(parsed.get("score", 0.0))))
    except Exception:
        score = 0.0
    return {"ok": True, "label": label, "score": round(score, 3),
            "model": res["model"]}


def _translate_local(args: Dict[str, Any]) -> Dict[str, Any]:
    """Translate text via a local model.

    Args: text (required), target_lang (required), model.
    """
    text = args.get("text")
    target = args.get("target_lang")
    if not text:
        return _err("text required")
    if not target:
        return _err("target_lang required")
    system = ("You are a translator. Output ONLY the translation, no notes, "
              "no original text.")
    prompt = "Translate the following into %s:\n\n%s" % (target, text)
    res = _simple(args.get("model", _REASON_MODEL), prompt, system=system,
                  temperature=0.2)
    if not res.get("ok"):
        return res
    return {"ok": True, "translation": res["text"], "target_lang": target,
            "model": res["model"]}


def _rewrite(args: Dict[str, Any]) -> Dict[str, Any]:
    """Rewrite text in a given style.

    Args: text (required), style (required, e.g. formal/casual/concise), model.
    """
    text = args.get("text")
    style = args.get("style")
    if not text:
        return _err("text required")
    if not style:
        return _err("style required")
    system = ("You rewrite text. Output ONLY the rewritten text, preserving "
              "meaning. No commentary.")
    prompt = "Rewrite the following in a %s style:\n\n%s" % (style, text)
    res = _simple(args.get("model", _REASON_MODEL), prompt, system=system,
                  temperature=0.6)
    if not res.get("ok"):
        return res
    return {"ok": True, "rewritten": res["text"], "style": style,
            "model": res["model"]}


# ---------------------------------------------------------------------------
# parallel / multi-agent tools
# ---------------------------------------------------------------------------

def _parallel_ask(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send the same prompt to N models concurrently, return all answers.

    Args: prompt (required), models (list, default [1b, 3b]), system,
          temperature.
    """
    prompt = args.get("prompt")
    if not prompt:
        return _err("prompt required")
    models = args.get("models") or [_FAST_MODEL, _REASON_MODEL]
    if not isinstance(models, list) or not models:
        return _err("models must be a non-empty list")
    system = args.get("system")
    temperature = float(args.get("temperature", 0.7))

    def _one(m: str) -> Dict[str, Any]:
        r = _simple(m, prompt, system=system, temperature=temperature)
        if r.get("ok"):
            return {"model": m, "ok": True, "answer": r["text"],
                    "elapsed": r["elapsed"]}
        return {"model": m, "ok": False, "error": r.get("error")}

    with ThreadPoolExecutor(max_workers=min(len(models), 4)) as pool:
        results = list(pool.map(_one, [str(m) for m in models]))
    any_ok = any(r["ok"] for r in results)
    out = {"ok": any_ok, "results": results}
    if not any_ok:
        out["error"] = "all models failed — " + (
            results[0].get("error") or "unknown")
    return out


def _map_over(args: Dict[str, Any]) -> Dict[str, Any]:
    """Apply an instruction to each item in a list (sequential).

    Args: items (required list), instruction (required), model.
    """
    items = args.get("items")
    instruction = args.get("instruction")
    if not isinstance(items, list) or not items:
        return _err("items (non-empty list) required")
    if not instruction:
        return _err("instruction required")
    model = args.get("model", _FAST_MODEL)
    system = ("Apply the user's instruction to the given item. Output ONLY "
              "the result, no preamble.")
    results: List[Dict[str, Any]] = []
    for idx, item in enumerate(items):
        prompt = "Instruction: %s\n\nItem:\n%s" % (instruction, item)
        r = _simple(model, prompt, system=system, temperature=0.3)
        if r.get("ok"):
            results.append({"index": idx, "ok": True, "input": item,
                            "result": r["text"]})
        else:
            results.append({"index": idx, "ok": False, "input": item,
                            "error": r.get("error")})
            # Ollama down → bail early, no point hammering
            if "not reachable" in (r.get("error") or ""):
                return {"ok": False, "error": r["error"],
                        "results": results}
    return {"ok": True, "results": results, "count": len(results),
            "model": model}


def _debate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Two personas argue pro/con for N rounds, then synthesize.

    Args: question (required), rounds (default 2), model.
    """
    question = args.get("question")
    if not question:
        return _err("question required")
    rounds = max(1, int(args.get("rounds", 2)))
    model = args.get("model", _REASON_MODEL)

    transcript: List[Dict[str, str]] = []
    pro_sys = ("You are PRO, arguing IN FAVOR. Be persuasive and concise "
               "(<=120 words). Rebut the opponent's last point if any.")
    con_sys = ("You are CON, arguing AGAINST. Be persuasive and concise "
               "(<=120 words). Rebut the opponent's last point if any.")
    last = ""
    for rnd in range(1, rounds + 1):
        for side, sysmsg in (("PRO", pro_sys), ("CON", con_sys)):
            ctx = ("Question: %s\n\nOpponent's last argument:\n%s\n\n"
                   "Your argument:" % (question, last or "(none yet)"))
            r = _simple(model, ctx, system=sysmsg, temperature=0.8)
            if not r.get("ok"):
                return {"ok": False, "error": r.get("error"),
                        "transcript": transcript}
            last = r["text"]
            transcript.append({"round": rnd, "side": side,
                               "argument": last})

    convo = "\n\n".join("[%s r%d] %s" % (t["side"], t["round"], t["argument"])
                        for t in transcript)
    syn = _simple(
        model,
        ("Question: %s\n\nDebate transcript:\n%s\n\nGive a balanced "
         "synthesis and a final verdict in <=120 words." % (question, convo)),
        system="You are a neutral judge synthesizing a debate.",
        temperature=0.4,
    )
    return {"ok": True, "question": question, "rounds": rounds,
            "transcript": transcript,
            "synthesis": syn.get("text") if syn.get("ok") else None,
            "model": model}


def _vote(args: Dict[str, Any]) -> Dict[str, Any]:
    """N independent model calls vote on options, return a tally.

    Args: question (required), options (required list), voters (default 3),
          model.
    """
    question = args.get("question")
    options = args.get("options")
    if not question:
        return _err("question required")
    if not isinstance(options, list) or not options:
        return _err("options (non-empty list) required")
    options = [str(o) for o in options]
    voters = max(1, int(args.get("voters", 3)))
    model = args.get("model", _FAST_MODEL)
    system = ("You are a voter. Reply with EXACTLY one of the allowed "
              "options and nothing else.")
    prompt = ("Question: %s\n\nOptions: %s\n\nYour pick:"
              % (question, ", ".join(options)))

    def _one(_i: int) -> Dict[str, Any]:
        r = _simple(model, prompt, system=system, temperature=0.9)
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error")}
        raw = r["text"].strip()
        low = raw.lower()
        pick = None
        for o in options:
            if o.lower() == low or o.lower() in low:
                pick = o
                break
        return {"ok": True, "pick": pick or raw, "raw": raw}

    with ThreadPoolExecutor(max_workers=min(voters, 4)) as pool:
        ballots = list(pool.map(_one, range(voters)))
    if not any(b["ok"] for b in ballots):
        return {"ok": False, "error": "all voters failed — "
                + (ballots[0].get("error") or "unknown")}
    tally: Dict[str, int] = {o: 0 for o in options}
    for b in ballots:
        if b.get("ok") and b.get("pick") in tally:
            tally[b["pick"]] += 1
    winner = max(tally, key=tally.get) if any(tally.values()) else None
    return {"ok": True, "question": question, "tally": tally,
            "winner": winner, "ballots": ballots, "model": model}


def _chain(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a chain of prompts; each step gets the prior output appended.

    Args: steps (required list of prompt strings), model.
    """
    steps = args.get("steps")
    if not isinstance(steps, list) or not steps:
        return _err("steps (non-empty list) required")
    model = args.get("model", _REASON_MODEL)
    intermediate: List[Dict[str, Any]] = []
    prev = ""
    for idx, step in enumerate(steps):
        prompt = str(step)
        if prev:
            prompt += "\n\n--- Previous step output ---\n" + prev
        r = _simple(model, prompt, temperature=0.5)
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error"),
                    "intermediate": intermediate, "failed_step": idx}
        prev = r["text"]
        intermediate.append({"step": idx, "prompt": str(step),
                             "output": prev})
    return {"ok": True, "final": prev, "intermediate": intermediate,
            "steps": len(steps), "model": model}


def _critique(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a critique + concrete improvement suggestions.

    Args: text (required), model.
    """
    text = args.get("text")
    if not text:
        return _err("text required")
    system = ("You are a sharp, constructive critic. Identify weaknesses and "
              "give specific, actionable improvement suggestions.")
    prompt = ("Critique the following. List 1) strengths, 2) weaknesses, "
              "3) concrete suggestions:\n\n%s" % text)
    res = _simple(args.get("model", _REASON_MODEL), prompt, system=system,
                  temperature=0.5)
    if not res.get("ok"):
        return res
    return {"ok": True, "critique": res["text"], "model": res["model"]}


def _refine(args: Dict[str, Any]) -> Dict[str, Any]:
    """Iteratively self-improve a piece of text.

    Args: text (required), iterations (default 2), model.
    """
    text = args.get("text")
    if not text:
        return _err("text required")
    iterations = max(1, int(args.get("iterations", 2)))
    model = args.get("model", _REASON_MODEL)
    system = ("You improve text: fix clarity, flow, and correctness. Output "
              "ONLY the improved version, no commentary.")
    history: List[str] = [str(text)]
    current = str(text)
    for _ in range(iterations):
        r = _simple(model,
                    "Improve this text:\n\n%s" % current,
                    system=system, temperature=0.4)
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error"),
                    "history": history}
        current = r["text"]
        history.append(current)
    return {"ok": True, "refined": current, "iterations": iterations,
            "history": history, "model": model}


# ---------------------------------------------------------------------------
# RAG tools
# ---------------------------------------------------------------------------

def _retrieve(question: str, limit: int) -> Dict[str, Any]:
    """Pull hits from the file_search semantic index, if available."""
    try:
        from brain.integrations import file_search  # type: ignore
    except Exception:
        try:
            import file_search  # type: ignore
        except Exception as e:
            return {"ok": False,
                    "error": "file_search index unavailable (%s)" % e}
    fn = getattr(file_search, "_semantic_search", None)
    if fn is None:
        tools = getattr(file_search, "EXTRA_TOOLS", {})
        fn = tools.get("file.semantic_search")
    if fn is None:
        return {"ok": False, "error": "file_search.semantic_search missing"}
    try:
        return fn({"query": question, "limit": limit})
    except Exception as e:
        return {"ok": False,
                "error": "semantic_search failed: %s" % e}


def _rag_answer(args: Dict[str, Any]) -> Dict[str, Any]:
    """Retrieve from the file_search semantic index, stuff context, answer.

    Args: question (required), model, limit (chunks, default 5).
    """
    question = args.get("question")
    if not question:
        return _err("question required")
    limit = int(args.get("limit", 5))
    retr = _retrieve(question, limit)
    if not retr.get("ok"):
        return {"ok": False,
                "error": "retrieval failed — %s" % retr.get("error")}
    hits = retr.get("hits", [])
    if not hits:
        return {"ok": True, "answer": "No relevant context found in the "
                "semantic index.", "hits": [], "grounded": False}
    context = "\n\n".join(
        "[%s]\n%s" % (h.get("path", "?"), h.get("snippet", ""))
        for h in hits)
    return _answer_with_context(args.get("model", _REASON_MODEL),
                                question, context, hits)


def _rag_over_text(args: Dict[str, Any]) -> Dict[str, Any]:
    """Answer a question given explicit context text.

    Args: question (required), context_text (required), model.
    """
    question = args.get("question")
    context = args.get("context_text")
    if not question:
        return _err("question required")
    if not context:
        return _err("context_text required")
    return _answer_with_context(args.get("model", _REASON_MODEL),
                                question, str(context), None)


def _answer_with_context(model: str, question: str, context: str,
                          hits: Optional[List[Dict[str, Any]]]) -> Dict[str, Any]:
    system = ("You answer using ONLY the provided context. If the context "
              "does not contain the answer, say so plainly.")
    prompt = ("Context:\n%s\n\nQuestion: %s\n\nAnswer:"
              % (context[:8000], question))
    res = _simple(model, prompt, system=system, temperature=0.3)
    if not res.get("ok"):
        return res
    out = {"ok": True, "question": question, "answer": res["text"],
           "grounded": True, "model": res["model"]}
    if hits is not None:
        out["hits"] = hits
        out["sources"] = sorted({h.get("path") for h in hits if h.get("path")})
    return out


# ---------------------------------------------------------------------------
# model management
# ---------------------------------------------------------------------------

def _list_models(args: Dict[str, Any]) -> Dict[str, Any]:
    """List locally available Ollama models (/api/tags)."""
    res = _get("/api/tags")
    if not res.get("ok"):
        return res
    models = res["data"].get("models", [])
    return {"ok": True, "count": len(models),
            "models": [m.get("name") for m in models],
            "details": models}


def _model_info(args: Dict[str, Any]) -> Dict[str, Any]:
    """Show details for a model (/api/show).

    Args: model (required).
    """
    model = args.get("model")
    if not model:
        return _err("model required")
    res = _post("/api/show", {"name": str(model)})
    if not res.get("ok"):
        return res
    d = res["data"]
    return {"ok": True, "model": model,
            "details": d.get("details"),
            "parameters": d.get("parameters"),
            "template": d.get("template"),
            "model_info": d.get("model_info")}


def _pull_model(args: Dict[str, Any]) -> Dict[str, Any]:
    """Download a model from the Ollama registry (/api/pull). Slow.

    Args: model (required).
    """
    model = args.get("model")
    if not model:
        return _err("model required")
    payload = {"name": str(model), "stream": False}
    res = _post("/api/pull", payload, timeout=_PULL_TIMEOUT)
    if not res.get("ok"):
        return res
    status = res["data"].get("status", "")
    ok = "success" in str(status).lower()
    return {"ok": ok, "model": model, "status": status or "done",
            "error": None if ok else "pull did not report success"}


def _benchmark(args: Dict[str, Any]) -> Dict[str, Any]:
    """Time a standard prompt and report tokens/sec.

    Args: model (default llama3.2:1b).
    """
    model = args.get("model", _FAST_MODEL)
    prompt = ("Count from 1 to 20 and then briefly explain what a spiking "
              "neuron is in two sentences.")
    res = _simple(model, prompt, temperature=0.0)
    if not res.get("ok"):
        return res
    eval_count = res.get("eval_count") or 0
    eval_dur = res.get("eval_duration") or 0  # nanoseconds
    tok_per_sec = None
    if eval_count and eval_dur:
        tok_per_sec = round(eval_count / (eval_dur / 1e9), 1)
    return {"ok": True, "model": model, "wall_seconds": res["elapsed"],
            "eval_tokens": eval_count, "tokens_per_sec": tok_per_sec,
            "sample": res["text"][:200]}


def _recommend_model(args: Dict[str, Any]) -> Dict[str, Any]:
    """Heuristic model pick for a task type.

    Args: task_type (required, e.g. classify/extract/reasoning/writing).
    """
    task = str(args.get("task_type", "")).lower().strip()
    if not task:
        return _err("task_type required")
    fast_tasks = {"classify", "classification", "extract", "extraction",
                  "sentiment", "vote", "voting", "tag", "tagging", "label",
                  "label", "map", "route", "routing"}
    reason_tasks = {"reasoning", "reason", "writing", "write", "summarize",
                    "summary", "debate", "critique", "refine", "translate",
                    "translation", "rag", "qa", "chain", "analysis",
                    "rewrite"}
    if task in fast_tasks:
        model, why = _FAST_MODEL, "fast, cheap — fine for short structured tasks"
    elif task in reason_tasks:
        model, why = _REASON_MODEL, "more capable — better for reasoning/writing"
    else:
        model, why = _REASON_MODEL, "unknown task — defaulting to the stronger model"
    return {"ok": True, "task_type": task, "recommended_model": model,
            "reason": why}


# ---------------------------------------------------------------------------
# tool registry
# ---------------------------------------------------------------------------

EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # single-agent
    "agentpool.ask":             _ask,
    "agentpool.classify":        _classify,
    "agentpool.extract":         _extract,
    "agentpool.summarize":       _summarize,
    "agentpool.sentiment":       _sentiment,
    "agentpool.translate_local": _translate_local,
    "agentpool.rewrite":         _rewrite,
    # parallel / multi-agent
    "agentpool.parallel_ask":    _parallel_ask,
    "agentpool.map_over":        _map_over,
    "agentpool.debate":          _debate,
    "agentpool.vote":            _vote,
    "agentpool.chain":           _chain,
    "agentpool.critique":        _critique,
    "agentpool.refine":          _refine,
    # RAG
    "agentpool.rag_answer":      _rag_answer,
    "agentpool.rag_over_text":   _rag_over_text,
    # model management
    "agentpool.list_models":     _list_models,
    "agentpool.model_info":      _model_info,
    "agentpool.pull_model":      _pull_model,
    "agentpool.benchmark":       _benchmark,
    "agentpool.recommend_model": _recommend_model,
}
