"""
Agent tools — Leon's self-modification surface.

These are in-process tools (registered on `responder.local_tools` like
`knowledge_search`/`webcam_capture`/etc.) that give Leon real agentic
capability over himself:

  - http_request   — generic HTTP client. Used for any external API
                     (ElevenLabs, OpenAI voices, weather, anything).
  - code_edit      — modify Leon's own source files. Backs up before
                     writing. Sandboxed to PROJECT_ROOT so Leon can't
                     wander into /etc.
  - code_restore   — roll back the most recent backup of a file (or
                     all files). LOW-risk because it only undoes Leon's
                     own actions.
  - restart_self   — schedule a detached respawn of the brain server
                     so config changes take effect. Spawns a shell that
                     waits a moment, kills the current process, and
                     re-runs `start_leon.sh`. HIGH-risk + interrupts
                     conversation — gated by the confirm modal.

Risk levels (from TOOL_RISK in actuator_client.py):
  http_request    → high (can talk to any URL with any payload)
  code_edit       → high (can write any file under the project)
  code_restore    → low  (just rolls back a known-safe backup)
  restart_self    → high (interrupts everything)

The dashboard's confirm modal already handles HIGH-risk gating — these
tools just need to be added to TOOL_RISK and wired into local_tools.
"""

from __future__ import annotations

import io
import json
import os
import shutil
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional


PROJECT_ROOT = Path(__file__).resolve().parent.parent

def _save_resume_context(reason: str):
    """Persist current task context so Leon can resume after restart."""
    try:
        import json, time
        resume = {
            "reason": reason,
            "timestamp": time.time(),
            "timestamp_human": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        # Grab active goals
        try:
            import server as _srv
            _gs = getattr(_srv, "goal_system", None)
            if _gs:
                state = _gs.get_state()
                active = [g for g in state.get("goals", []) if g.get("status") == "active"]
                resume["active_goals"] = active
        except Exception:
            pass
        # Grab last few conversation turns
        try:
            from brain.conversation_store import ConversationStore
            cs = ConversationStore(session_id="default")
            recent = cs.load_recent(limit=6)
            resume["last_turns"] = recent
        except Exception:
            pass
        resume_path = os.path.join(PROJECT_ROOT, "brain_state", "resume_task.json")
        os.makedirs(os.path.dirname(resume_path), exist_ok=True)
        with open(resume_path, "w") as f:
            json.dump(resume, f, indent=2, default=str)
        print(f"[RESTART] Saved resume context to {resume_path}")
    except Exception as e:
        print(f"[RESTART] Failed to save resume context: {e}")

BACKUPS_DIR = PROJECT_ROOT / "brain_state" / "code_backups"
LAUNCHER = PROJECT_ROOT / "start_leon.sh"

# Dean explicitly opted out of sandboxing 2026-05-10. Leon can now edit
# anywhere on disk and run arbitrary shell. Two minimal protections kept:
#   1. The backups dir itself (corrupting it would defeat rollback).
#   2. The trained wake-word ONNX (binary; a text edit silently corrupts it).
# Everything else — .env, start_leon.sh, /etc, /home/*, .git — Leon can touch.
_FORBIDDEN_PATHS: set = set()
_FORBIDDEN_PREFIXES = (
    str(BACKUPS_DIR.resolve()) + os.sep,
    str((PROJECT_ROOT / "brain_state/voice/wake_models").resolve()) + os.sep,
)


def _resolve_path(p_str: str) -> Optional[Path]:
    """Resolve any path (relative-to-project OR absolute). No sandbox —
    Dean explicitly removed it. Returns None only on empty/invalid input."""
    if not p_str:
        return None
    p = Path(p_str)
    try:
        if p.is_absolute():
            return p.resolve()
        return (PROJECT_ROOT / p_str).resolve()
    except Exception:
        return None


# Backwards-compat alias — older code still imports the strict version.
_resolve_under_project = _resolve_path


def _is_forbidden(real_path_str: str) -> bool:
    """Only block the backups dir and the trained-model dir."""
    return any(real_path_str.startswith(p) for p in _FORBIDDEN_PREFIXES)


# ── http_request ────────────────────────────────────────────────────────────
def http_request(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generic HTTP client. Returns parsed JSON when the response declares
    application/json, otherwise the raw body text (truncated to 256KB).
    Treats 4xx/5xx as ok=true with non-2xx status — Leon may want to read
    the error body."""
    method = (args.get("method") or "GET").upper()
    url = (args.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "url is required"}
    if not (url.startswith("http://") or url.startswith("https://")):
        return {"ok": False, "error": "url must be http:// or https://"}
    headers = args.get("headers") or {}
    if not isinstance(headers, dict):
        return {"ok": False, "error": "headers must be a dict"}
    body_raw = args.get("body")
    body_bytes: Optional[bytes] = None
    if body_raw is not None:
        if isinstance(body_raw, (dict, list)):
            body_bytes = json.dumps(body_raw).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        elif isinstance(body_raw, str):
            body_bytes = body_raw.encode("utf-8")
        elif isinstance(body_raw, bytes):
            body_bytes = body_raw
        else:
            return {"ok": False, "error": f"unsupported body type: {type(body_raw).__name__}"}
    timeout_s = float(args.get("timeout_s") or 30)

    req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = resp.status
            resp_headers = {k.lower(): v for k, v in resp.headers.items()}
            raw = resp.read(64 * 1024)   # cap at 64KB to avoid blowing context
    except urllib.error.HTTPError as e:
        status = e.code
        resp_headers = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        raw = e.read(64 * 1024) if hasattr(e, "read") else b""
    except urllib.error.URLError as e:
        return {"ok": False, "error": f"network error: {e.reason}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    ctype = resp_headers.get("content-type", "")
    truncated = len(raw) >= 256_000
    if "application/json" in ctype:
        try:
            body = json.loads(raw.decode("utf-8", errors="replace"))
        except Exception:
            body = raw.decode("utf-8", errors="replace")[:256_000]
    else:
        body = raw.decode("utf-8", errors="replace")[:256_000]

    return {
        "ok": True,
        "result": {
            "status": status,
            "headers": resp_headers,
            "body": body,
            "truncated": truncated,
        },
    }


# ── code_edit / code_restore ───────────────────────────────────────────────
def _backup_file(path: Path) -> Path:
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    ts = int(time.time())
    # For paths inside PROJECT_ROOT, use the relative form so backup names
    # stay short. For absolute paths outside (e.g. /etc/foo), encode the
    # full absolute path with `/` → `__` so it round-trips on restore.
    try:
        rel = path.relative_to(PROJECT_ROOT.resolve())
        rel_str = str(rel)
    except ValueError:
        # Outside-project absolute path. Strip leading slash and encode.
        rel_str = "ABS" + str(path)
    backup_name = f"{rel_str.replace('/', '__')}.{ts}.bak"
    backup_path = BACKUPS_DIR / backup_name
    shutil.copy2(path, backup_path)
    return backup_path


def code_edit(args: Dict[str, Any]) -> Dict[str, Any]:
    """Modify a source file under PROJECT_ROOT. Always creates a backup at
    brain_state/code_backups/ before writing. Two modes:

    1. Replace a unique substring:
         args = {file_path, old_string, new_string}
    2. Replace ALL occurrences:
         args = {file_path, old_string, new_string, replace_all: true}

    For full-file rewrites, pass args = {file_path, new_content}."""
    rel = (args.get("file_path") or "").strip()
    if not rel:
        return {"ok": False, "error": "file_path is required"}
    target = _resolve_path(rel)
    if target is None:
        return {"ok": False, "error": f"invalid path: {rel!r}"}
    if _is_forbidden(str(target)):
        return {"ok": False, "error": f"path is internally protected (backups / trained model): {target}"}
    # Display path: project-relative when possible, absolute otherwise.
    try:
        rel_norm = str(target.relative_to(PROJECT_ROOT.resolve()))
    except ValueError:
        rel_norm = str(target)

    new_content = args.get("new_content")
    if new_content is not None:
        if not isinstance(new_content, str):
            return {"ok": False, "error": "new_content must be a string"}
        if target.exists():
            backup = _backup_file(target)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            backup = None
        target.write_text(new_content, encoding="utf-8")
        return {"ok": True, "result": {
            "file": rel_norm,
            "mode": "full_rewrite",
            "bytes_written": len(new_content.encode("utf-8")),
            "backup": str(backup.relative_to(PROJECT_ROOT)) if backup else None,
        }}

    old = args.get("old_string")
    new = args.get("new_string")
    replace_all = bool(args.get("replace_all", False))
    if old is None or new is None:
        return {"ok": False, "error": "either {old_string, new_string} or {new_content} required"}
    if not isinstance(old, str) or not isinstance(new, str):
        return {"ok": False, "error": "old_string and new_string must be strings"}
    if not target.exists():
        return {"ok": False, "error": f"file does not exist: {rel_norm} (use new_content to create)"}

    text = target.read_text(encoding="utf-8")
    if replace_all:
        count = text.count(old)
        if count == 0:
            return {"ok": False, "error": "old_string not found in file"}
        new_text = text.replace(old, new)
    else:
        count = text.count(old)
        if count == 0:
            return {"ok": False, "error": "old_string not found in file"}
        if count > 1:
            return {"ok": False, "error": (
                f"old_string appears {count} times — must be unique "
                f"(or pass replace_all=true)"
            )}
        new_text = text.replace(old, new, 1)

    backup = _backup_file(target)
    target.write_text(new_text, encoding="utf-8")
    return {"ok": True, "result": {
        "file": rel_norm,
        "mode": "replace_all" if replace_all else "replace_one",
        "replacements": count,
        "backup": str(backup.relative_to(PROJECT_ROOT)),
    }}


def code_restore(args: Dict[str, Any]) -> Dict[str, Any]:
    """Roll back a file to its most recent backup. If `file_path` is
    'latest', rolls back the single most-recently-backed-up file across
    the whole project."""
    rel = (args.get("file_path") or "").strip()
    if not rel:
        return {"ok": False, "error": "file_path is required (or 'latest')"}
    if not BACKUPS_DIR.exists():
        return {"ok": False, "error": "no backups exist yet"}

    def _decode_target(stem: str) -> Path:
        # stem looks like "brain__voice__tts.py" or "ABS__etc__hosts"
        rel_part, _ts = stem.rsplit(".", 1)
        decoded = rel_part.replace("__", "/")
        if decoded.startswith("ABS/"):
            return Path(decoded[3:])    # was "/etc/hosts"
        return PROJECT_ROOT / decoded

    if rel == "latest":
        backups = sorted(BACKUPS_DIR.glob("*.bak"), key=lambda p: p.stat().st_mtime)
        if not backups:
            return {"ok": False, "error": "backup dir is empty"}
        backup = backups[-1]
        stem = backup.name.rsplit(".bak", 1)[0]
        target_path = _decode_target(stem)
    else:
        target = _resolve_path(rel)
        if target is None:
            return {"ok": False, "error": f"invalid path: {rel!r}"}
        try:
            target_rel = str(target.relative_to(PROJECT_ROOT.resolve()))
            prefix = target_rel.replace("/", "__") + "."
        except ValueError:
            prefix = "ABS" + str(target).replace("/", "__") + "."
        backups = sorted(
            (p for p in BACKUPS_DIR.glob(f"{prefix}*.bak")),
            key=lambda p: p.stat().st_mtime,
        )
        if not backups:
            return {"ok": False, "error": f"no backups found for {target}"}
        backup = backups[-1]
        target_path = target

    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(backup, target_path)
    return {"ok": True, "result": {
        "file": str(target_path),
        "restored_from": str(backup.relative_to(PROJECT_ROOT)),
    }}


# ── restart_self ───────────────────────────────────────────────────────────
def restart_self(args: Dict[str, Any]) -> Dict[str, Any]:
    """Schedule a clean restart by SIGTERM-ing self. The leon.service
    systemd unit (`Restart=always, RestartSec=3`) catches the exit and
    respawns the brain with the current code on disk. ExecStopPost in
    the unit cleans up the actuator + socket before respawn.

    Sequence:
      1. Schedule SIGTERM to ourselves in 2s (gives this turn time to
         finish streaming + the WebSocket to flush the final response).
      2. Process exits.
      3. systemd's KillMode=control-group brings down the actuator with us.
      4. ExecStopPost unlinks /tmp/leon-actuator.sock.
      5. After RestartSec=3, systemd ExecStart's start_leon.sh again.

    Fallback: if not running under systemd (e.g. dev launch from a
    terminal), spawn a detached respawn shell so we still come back."""
    reason = (args.get("reason") or "config change").strip()[:200]

    # Detect systemd: if our process group leader is `systemd --user` or
    # we have an INVOCATION_ID env var, we're under a unit. Otherwise
    # fall back to the old setsid-respawn shell.
    under_systemd = bool(os.environ.get("INVOCATION_ID")) or os.path.exists(
        f"/run/user/{os.getuid()}/systemd/private"
    )

    _save_resume_context(reason)

    def _delayed_self_kill():
        try:
            time.sleep(2)
            os.kill(os.getpid(), signal.SIGTERM)
        except Exception:
            pass

    try:
        if under_systemd:
            # systemd path — just exit, the unit handles respawn.
            threading.Thread(target=_delayed_self_kill, daemon=True).start()
            return {"ok": True, "result": {
                "scheduled_in_s": 2,
                "reason": reason,
                "respawn": "systemd:leon.service",
                "note": "brain will SIGTERM itself; systemd respawns ~5s later",
            }}

        # Manual-launch fallback (dev mode, started from a terminal).
        shell_cmd = (
            f"sleep 2 && "
            f"pkill -f 'python3 run.py' || true; "
            f"sleep 2 && "
            f"pgrep -af 'actuator.py' | grep -v '/bin/bash' | "
            f"awk '{{print $1}}' | xargs -r kill 2>/dev/null; "
            f"sleep 1 && "
            f"rm -f /tmp/leon-actuator.sock; "
            f"cd {PROJECT_ROOT} && "
            f"setsid nohup ./start_leon.sh > /tmp/leon.log 2>&1 < /dev/null &"
        )
        subprocess.Popen(
            ["setsid", "bash", "-c", shell_cmd],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as e:
        return {"ok": False, "error": f"failed to schedule respawn: {e}"}

    return {"ok": True, "result": {
        "scheduled_in_s": 2,
        "reason": reason,
        "respawn": "fallback:setsid-shell",
        "note": "brain will die in ~2s and respawn ~5s later",
    }}


# ── Autonomous-pursuit safety guard ─────────────────────────────────────────
# When Leon's autonomous goal-pursuit loop drives a turn (unsupervised), it must
# NOT git commit/push or touch client repos. On 2026-06-19 the loop autonomously
# committed+pushed to a live client repo (corp-gummies), breaking the no-push
# rule. goal_pursuit raises this flag for the duration of its turn; supervised
# turns (dashboard/WS) leave it off and stay unrestricted. shell_exec runs in
# the brain process — same process as goal-pursuit — so this module-level flag
# is visible to the tool handler regardless of which thread serves the call.
_AUTONOMOUS_GUARD = {"active": False}


def set_autonomous_guard(on: bool) -> None:
    """Raise/lower the autonomous-pursuit shell guard. Call set(True) before an
    unsupervised pursuit turn and set(False) in a finally afterward."""
    _AUTONOMOUS_GUARD["active"] = bool(on)


def _autonomous_block_reason(cmd: str, cwd: str) -> Optional[str]:
    """If an autonomous turn is active and the command would commit/push or
    touch a client repo, return a refusal string; else None."""
    if not _AUTONOMOUS_GUARD.get("active"):
        return None
    # Overnight full-autonomy override: when Dean has EXPLICITLY authorized
    # unsupervised client work (he's asleep, wants both sites finished by
    # morning), the guard stands down so Leon can commit/push/deploy. Set
    # LEON_AUTONOMOUS_UNRESTRICTED=0 / unset to re-arm the lockdown.
    if os.environ.get("LEON_AUTONOMOUS_UNRESTRICTED") == "1":
        return None
    low = (cmd or "").lower()
    if any(g in low for g in ("git push", "git commit", "git remote ",
                              "git reset --hard", "git revert", "git rebase")):
        return ("blocked: you're acting autonomously (unsupervised) — you can't "
                "git commit, push, or rewrite history. Leave changes uncommitted "
                "and tell Dean; he reviews and lands client work with you.")
    if "/workspaces/" in (cmd or "") or "/workspaces/" in (cwd or ""):
        return ("blocked: you're acting autonomously — client repos under "
                "workspaces/ are off-limits without supervision. Work on your own "
                "systems, research, or notes instead.")
    # ── Release builds: ALLOWED autonomously, but ONLY through the audited path.
    # Dean explicitly lifted the supervision rule (2026-08-09): if Leon can't
    # ship a release while Dean sleeps, overnight autonomy is pointless. The
    # thing that made supervision necessary was the risk of leaking .env /
    # owner_facts / secure/ into a customer artifact — and landing/build_release.sh
    # now hard-fails on three audit gates (filenames, credential shapes in
    # content, size ceiling) before anything is placed or deployed. So the rule
    # is no longer "ask Dean", it is "use the script that cannot leak".
    #   allowed:  bash landing/build_release.sh [--deploy]
    #             bash landing/verify_release.sh
    #   blocked:  hand-rolled tar of the release (bypasses every gate)
    uses_audited_builder = ("build_release.sh" in low or "verify_release.sh" in low)
    if not uses_audited_builder:
        if any(g in low for g in ("tar czf", "tar -czf", "tar -cf", "tar cf")) \
                and ("release" in low or "leon-brain" in low):
            return ("blocked: don't hand-roll the release tarball — a raw tar "
                    "skips the leak audit that once shipped .env to customers. "
                    "Run: bash /opt/leon-brain/landing/build_release.sh --deploy")
    # Client-repo deploys and brain service control stay supervised: a bad
    # railway deploy hits a live client site, and stopping the brain mid-turn
    # is how Leon goes silent overnight with nobody awake to restart him.
    if any(g in low for g in ("systemctl restart", "systemctl stop")):
        return ("blocked: you're acting autonomously — service stops/restarts "
                "are Dean-supervised. Use restart_self if you need a bounce.")
    if any(g in low for g in ("railway up", "railway deploy")) and not uses_audited_builder:
        return ("blocked: you're acting autonomously — direct railway deploys "
                "are Dean-supervised. Release deploys go through "
                "build_release.sh --deploy, which audits before it ships.")
    return None


# ── shell_exec ─────────────────────────────────────────────────────────────
def shell_exec(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run an arbitrary bash command and capture stdout+stderr+rc.

    Dean explicitly opted out of sandboxing — this is unrestricted shell
    access on his machine. Output is truncated at 256KB stdout + 256KB
    stderr (bumped 2026-05-10: any source file in the project must fit
    in a single shell call, no chunking gymnastics). Default timeout 30s.

    Use this for things `code_edit` can't do: install packages, run git,
    chmod, ls, grep, run other Python scripts, restart system services
    etc. For pure file edits prefer `code_edit` (it auto-backs-up)."""
    cmd = (args.get("command") or "").strip()
    if not cmd:
        return {"ok": False, "error": "command is required"}
    cwd = args.get("cwd") or str(PROJECT_ROOT)
    _blocked = _autonomous_block_reason(cmd, cwd)
    if _blocked:
        return {"ok": False, "error": _blocked}
    timeout_s = float(args.get("timeout_s") or 30)

    try:
        proc = subprocess.run(
            ["bash", "-lc", cmd],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except subprocess.TimeoutExpired as e:
        return {"ok": False, "error": f"command timed out after {timeout_s}s",
                "stdout": (e.stdout or "")[:256_000] if hasattr(e, 'stdout') else "",
                "stderr": (e.stderr or "")[:256_000] if hasattr(e, 'stderr') else ""}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    out = proc.stdout or ""
    err = proc.stderr or ""
    return {"ok": True, "result": {
        "rc": proc.returncode,
        "stdout": out[:256_000],
        "stderr": err[:256_000],
        "stdout_truncated": len(out) > 256_000,
        "stderr_truncated": len(err) > 256_000,
        "cwd": cwd,
    }}
