"""One-time purge of LEGACY OWNER SEEDS from a CLIENT install.

WHY THIS EXISTS (2026-08-30):

Testers reported their SIs dreaming about a car nobody in the house owns
and remembering a company nobody there has worked with. brain/concept_map.py
was one half of that — the owner's project names seeded into every install's
hippocampus, fixed there. This module is the other half: rows already sitting
in customers' knowledge.db. (The names themselves are not repeated here; this
purges by SOURCE, so it never needs to spell them, and spelling them would
put them back into the shipped tree the fix is removing them from.)

Releases before 2026-08-18 seeded the owner's personal facts into EVERY
install:

  source='core_fact_seed'   — brain/seed_core_facts.py rendering OWNER_FACTS
                              (his age, his home town, his dead best friend,
                              his clients, his finances).
  source='dean_bio_seed'    — an older biography seeder, same shape.
  source='client_seed' (v1) — brain/seed_client_facts.py before SEED_VERSION 2
                              asserted a named creator, a named guardian bond,
                              and a short biography of a real human.
  brain_state/core_facts.md — the same OWNER_FACTS rendered to markdown and
                              injected verbatim into every prompt.

Nothing removed them, and three separate mechanisms guaranteed they stayed:

  1. knowledge_store.py's _DURABLE set lists core_fact_seed and dean_bio_seed,
     so recall STRENGTHENS them instead of letting them decay.
  2. neural_retriever.py ranks those same sources first, so they surface
     ahead of the customer's own memories.
  3. landing/bootstrap.sh carries brain_state/ forward across reinstalls, so
     reinstalling — the thing a confused customer does — preserves them.

So the leak is not self-healing. It has to be actively deleted, once, on
every install that is not the original.

FAIL CLOSED, IN THE DELETING DIRECTION. Everywhere else in this codebase
"fail closed" means "assume client, load nothing personal". Here the safe
default is the opposite: if we cannot PROVE this is a client install, we
delete nothing. A wrong "assume client" here would wipe the owner's own
59 permanent facts, and that is exactly the failure seed_core_facts.py
already had to grow two abort guards for.

WHAT IS DELIBERATELY NOT DELETED: rows from conversation_distill,
inner_thought, dean_stated, consolidated, screen_observer, dashboard,
project_crawler, leon_autopilot, continuous_hearing, wake. On a customer
machine those are the CUSTOMER'S own data — their words, their screen, their
thoughts. Some of them may quote an owner project name (because a seeded row
was distilled or consolidated at some point), but they are not owner seeds
and deleting them would be deleting the user's memory to fix ours. The
source-based boundary is the whole point; see the module docstring in
brain/seed_client_facts.py for why "infer from the artifact" is the wrong
guard.
"""

import os
import sqlite3
import sys
import time

# Sources written ONLY by the owner-fact seeders. Deleting by source is
# deliberate: matching on the text of the owner's car or product names would also
# hit the customer's own conversations, which are not ours to delete.
OWNER_SEED_SOURCES = ("core_fact_seed", "dean_bio_seed")

# seed_log event key. Keyed on the EVENT, never on "are the rows gone?" —
# the same lesson seed_client_facts.py learned: infer from the record of what
# happened, not from the artifact, or a later prune silently re-arms it.
PURGE_EVENT = "owner_seed_purge"
PURGE_VERSION = 1


def _app_root() -> str:
    """Install root (the directory holding brain/ and brain_state/)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _ensure_seed_log(c) -> None:
    """Same DDL as brain/seed_client_facts.py — one table, two writers."""
    try:
        from brain.seed_client_facts import _ensure_seed_log as _ensure
        _ensure(c)
        return
    except Exception:
        pass
    c.execute(
        "CREATE TABLE IF NOT EXISTS seed_log ("
        " event TEXT PRIMARY KEY, version INTEGER, ts REAL)"
    )


def _client_seed_version() -> int:
    """SEED_VERSION from seed_client_facts — anything below it is v1 material."""
    try:
        from brain.seed_client_facts import SEED_VERSION
        return int(SEED_VERSION)
    except Exception:
        return 2


def _is_client_install() -> bool:
    """Positive proof that this is NOT the original install.

    Any doubt — import failure, exception, anything — returns False and the
    purge does nothing. Deleting memory is not a safe default.
    """
    try:
        from brain.origin import is_client_si
        return bool(is_client_si())
    except Exception:
        return False


def purge(root: str = None, db_path: str = None, force: bool = False) -> dict:
    """Delete legacy owner seeds from this install. Once, ever, per install.

    Args:
        root:    install root; defaults to the tree this file lives in.
        db_path: knowledge.db path; defaults to <root>/brain_state/knowledge.db.
        force:   skip the is_client_si() gate. FOR TESTS ONLY — the gate is
                 the thing standing between this function and the owner's own
                 permanent memory.

    Returns a report dict. Never raises: a purge failure must never be able
    to block boot. The one thing worse than a customer carrying the owner's
    facts is a customer whose SI will not start.
    """
    report = {
        "ran": False, "reason": "", "rows": 0,
        "by_source": {}, "client_seed_v1": 0, "core_facts_md": False,
    }
    try:
        if not force and not _is_client_install():
            # Either this IS the original, or origin could not be determined.
            # Both mean: touch nothing.
            report["reason"] = "not a proven client install"
            return report

        root = root or os.environ.get("LEON_ROOT") or _app_root()
        state_dir = os.path.join(root, "brain_state")
        db_path = db_path or os.path.join(state_dir, "knowledge.db")

        if not os.path.exists(db_path):
            report["reason"] = "no knowledge.db yet"
            return report

        conn = sqlite3.connect(db_path, timeout=30)
        try:
            c = conn.cursor()
            _ensure_seed_log(c)

            row = c.execute(
                "SELECT version FROM seed_log WHERE event = ?", (PURGE_EVENT,)
            ).fetchone()
            if row and (row[0] or 0) >= PURGE_VERSION:
                report["reason"] = "already purged"
                return report

            total = 0

            # ── 1. the owner-fact seeders ────────────────────────────────
            for src in OWNER_SEED_SOURCES:
                ids = [r[0] for r in c.execute(
                    "SELECT id FROM knowledge WHERE source = ?", (src,)
                ).fetchall()]
                if not ids:
                    continue
                _delete_ids(c, ids)
                report["by_source"][src] = len(ids)
                total += len(ids)

            # ── 2. client_seed v1 ────────────────────────────────────────
            # The knowledge table has NO version column (verified against the
            # live schema: id, text, source, tags, timestamp,
            # neural_fingerprint, metadata, access_count, last_access,
            # strength, emo_*). The version lives on the seed_log EVENT, one
            # row per install, written by seed_client_facts.SEED_VERSION.
            # So "v1 rows" == "every client_seed row on an install whose
            # client_seed marker is below SEED_VERSION" — or an install that
            # has client_seed rows and no marker at all, which can only be
            # pre-marker (v1) code, since v2 writes rows and marker together.
            want = _client_seed_version()
            marker = c.execute(
                "SELECT version FROM seed_log WHERE event = 'client_seed'"
            ).fetchone()
            stale = (marker is None) or ((marker[0] or 0) < want)
            if stale:
                ids = [r[0] for r in c.execute(
                    "SELECT id FROM knowledge WHERE source = 'client_seed'"
                ).fetchall()]
                if ids:
                    _delete_ids(c, ids)
                    report["client_seed_v1"] = len(ids)
                    total += len(ids)
                # Drop the marker so seed_client_facts() re-seeds at the
                # current version. Without this the install is left with NO
                # starting facts at all — _already_seeded() keys on the event,
                # so it would never write them again.
                c.execute("DELETE FROM seed_log WHERE event = 'client_seed'")

            # ── 3. the rendered markdown ─────────────────────────────────
            # claude_api_responder injects this file verbatim into every
            # prompt. It is gated on is_client_si() today, but the file has no
            # business existing on a customer's disk at all.
            md = os.path.join(state_dir, "core_facts.md")
            if os.path.exists(md):
                try:
                    os.remove(md)
                    report["core_facts_md"] = True
                except OSError:
                    pass

            c.execute(
                "INSERT OR REPLACE INTO seed_log (event, version, ts) VALUES (?,?,?)",
                (PURGE_EVENT, PURGE_VERSION, time.time()),
            )
            conn.commit()

            # ── Residue (Sam's remediation report, §4.6a) ────────────────
            # SQLite does not zero freed pages on DELETE. The rows are gone
            # from every query and from the FTS index (the AD trigger fired
            # above), but the raw bytes stay readable with `strings` on the
            # database file, and recently, in the WAL, until these run. Must
            # be outside the transaction — VACUUM cannot run inside one.
            try:
                c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                conn.commit()
                conn.execute("VACUUM")
            except sqlite3.Error as e:
                report["vacuum_error"] = f"{type(e).__name__}: {e}"

            report["ran"] = True
            report["rows"] = total
        finally:
            conn.close()

        # ── Stale pre-scrub snapshots (Sam's report, §4.6b) ───────────────
        # A backup left inside brain_state/ is a full copy of exactly what
        # was just deleted. The reference instance had five of these sitting
        # next to the live database from earlier ad-hoc cleanups; removing
        # them here means this purge can never be the one that leaves a
        # readable copy of the very rows it just scrubbed.
        report["stale_copies_removed"] = []
        try:
            import glob
            for pat in ("*.db.PRE_*", "*.db.bak", "*.jsonl.PRE_*"):
                for f in glob.glob(os.path.join(state_dir, pat)):
                    try:
                        os.remove(f)
                        report["stale_copies_removed"].append(os.path.basename(f))
                    except OSError:
                        pass
        except Exception:
            pass

        print(f"[PURGE] removed {report['rows']} owner-seed rows")

        # Re-seed the neutral v2 starting facts we just cleared the marker
        # for, so the SI is not left blank until the next boot. Best effort:
        # no-ops when LEON_SI_NAME is unset (e.g. the bootstrap.sh path).
        if report["client_seed_v1"]:
            try:
                from brain.seed_client_facts import seed_client_facts
                seed_client_facts()
            except Exception:
                pass

        return report
    except Exception as e:            # noqa: BLE001 — must never block boot
        report["reason"] = f"{type(e).__name__}: {e}"
        try:
            print(f"[PURGE] skipped (non-fatal): {report['reason']}")
        except Exception:
            pass
        return report


def _delete_ids(c, ids) -> None:
    """Delete knowledge rows and their token-index rows.

    knowledge_tokens declares ON DELETE CASCADE, but SQLite enforces foreign
    keys only when PRAGMA foreign_keys=ON, which nothing here sets — so the
    cascade does not fire and orphaned tokens would keep the purged text
    influencing TF-IDF scoring. The FTS index does clean itself: the
    knowledge_ad trigger in knowledge_store._init_db fires on DELETE.
    """
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        marks = ",".join("?" * len(chunk))
        try:
            c.execute(
                f"DELETE FROM knowledge_tokens WHERE entry_id IN ({marks})",
                chunk,
            )
        except sqlite3.OperationalError:
            pass          # table retired on newer installs
        c.execute(f"DELETE FROM knowledge WHERE id IN ({marks})", chunk)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--root", default=None, help="install root")
    ap.add_argument("--force", action="store_true",
                    help="skip the client gate (tests only)")
    args = ap.parse_args()
    purge(root=args.root, force=args.force)
