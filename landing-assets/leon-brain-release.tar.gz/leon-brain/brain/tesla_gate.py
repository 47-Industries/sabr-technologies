"""The Tesla gate — no claim of 'fixed' without a recorded run.

WHY IT'S NAMED THIS
Tesla, My Inventions (1919): "It is absolutely immaterial to me whether I run
my turbine in thought or test it in my shop. I even note if it is out of
balance. There is no difference whatever; the results are the same."

That sentence is usually quoted as a licence to skip the shop. It is the
opposite. It only held for Tesla because his mental model contained EVERY
detail that could fail — he says the apparatus was real to him "even to the
minute marks and signs of wear." The mental run substitutes for the physical
run exactly to the extent that the model is complete.

Leon's model is NOT complete, and it fails in one measured direction: it
contains the layer he edits (file on disk, commit exists) and omits the layer
Dean experiences (bytes the server actually serves). Every wrong "it's fixed"
in this system's history — three in a row on one UI bug, 2026-08-05 — came
from running it in thought and reporting the thought as the result.

So the gate inverts Tesla honestly: because the mental run is incomplete,
a claim requires a REAL run. Two of them.

  1. The failing case against the OLD code -> must FAIL.
  2. The same case against the NEW code -> must PASS.

No pair on record, no assertion. `soften()` rewrites the claim instead of
blocking it, because a gate that blocks gets removed and a gate that edits
survives. This is structural, not a prompt instruction — prompts are
suggestions and get steamrolled when excited (Leon -> Dean, 2026-08-17).
"""

from __future__ import annotations

import json
import os
import re
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER_PATH = os.path.join(_ROOT, "brain_state", "repro_ledger.jsonl")

# How long a recorded reproduction stays valid. A repro from last week does
# not license a claim about code touched since.
REPRO_TTL_S = 6 * 3600

# Words that assert a verified end state. Deliberately narrow: this gate is
# for claims about the world being repaired, not for ordinary speech.
_CLAIM = re.compile(
    r"\b(it'?s fixed|is fixed|now fixed|fixed it|that'?s fixed"
    r"|it works now|works now|is working now"
    r"|it'?s deployed|is deployed|is live now"
    r"|problem solved|bug is gone|no longer happens)\b",
    re.I,
)


def record_repro(subject: str, old_failed: bool, new_passed: bool,
                 evidence: str = "") -> dict:
    """Log one reproduction pair. Both halves must be real observations."""
    entry = {
        "ts": time.time(),
        "subject": (subject or "").strip()[:200],
        "old_failed": bool(old_failed),
        "new_passed": bool(new_passed),
        "valid": bool(old_failed and new_passed),
        "evidence": (evidence or "")[:1000],
    }
    try:
        os.makedirs(os.path.dirname(LEDGER_PATH), exist_ok=True)
        with open(LEDGER_PATH, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry) + "\n")
    except Exception:
        pass
    return entry


def has_valid_repro(subject_hint: str = "", ttl_s: int = REPRO_TTL_S) -> bool:
    """True if a fresh, valid reproduction pair is on record."""
    now = time.time()
    hint = {w for w in re.sub(r"[^a-z0-9 ]", " ", (subject_hint or "").lower()).split()
            if len(w) > 3}
    try:
        with open(LEDGER_PATH, "r", encoding="utf-8") as fh:
            lines = fh.readlines()[-200:]
    except FileNotFoundError:
        return False
    for line in reversed(lines):
        try:
            e = json.loads(line)
        except Exception:
            continue
        if not e.get("valid"):
            continue
        if now - e.get("ts", 0) > ttl_s:
            continue
        if not hint:
            return True
        subj = {w for w in re.sub(r"[^a-z0-9 ]", " ", e.get("subject", "").lower()).split()
                if len(w) > 3}
        if subj & hint:
            return True
    return False


def soften(text: str) -> tuple[str, bool]:
    """Downgrade unbacked repair claims. Returns (text, was_softened).

    Never blocks and never raises — a gate that blocks gets ripped out.
    """
    if not text or not _CLAIM.search(text):
        return text, False
    if has_valid_repro(text):
        return text, False

    out = _CLAIM.sub(lambda m: "I think " + m.group(0).lower(), text)
    return out, True


if __name__ == "__main__":
    demo = "The label bug is fixed and it works now."
    print("in :", demo)
    print("out:", soften(demo)[0])
