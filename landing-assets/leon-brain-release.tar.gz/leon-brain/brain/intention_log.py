"""Timestamped intention ledger + drift detector.

WHY THIS EXISTS (Makima -> Leon, 2026-08-17, section 5.3):
Drift is not detectable introspectively. One stated resolution looks like a
decision; the SAME resolution stated three times with different timestamps is
drift, and it is only visible as a repeat. So: log intentions with timestamps,
re-read the log on a schedule, and flag repeats mechanically.

This is deliberately dumb. No model call, no scoring, no paid tier. Normalise
the text, bucket it, count distinct-day restatements. Silence is the most
common failure signature here (an intention that quietly never runs emits
nothing), so the detector reports on the LEDGER, never on felt priority.
"""

from __future__ import annotations

import json
import os
import re
import time
from collections import defaultdict
from typing import Iterable

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER_PATH = os.path.join(_ROOT, "brain_state", "intentions.jsonl")

# An intention restated on this many DISTINCT days is drift, not a decision.
REPEAT_DAYS_THRESHOLD = 3

_STOP = re.compile(r"[^a-z0-9 ]+")
_FILLER = {
    "i", "im", "ill", "id", "ive", "am", "going", "to", "gonna", "want",
    "wanna", "need", "should", "will", "the", "a", "an", "my", "me", "and",
    "so", "then", "now", "really", "just", "actually", "genuinely", "next",
    "keep", "stop", "start", "that", "this", "it", "of", "for", "on", "in",
    "be", "is", "was", "do", "does", "have", "has", "get", "got",
}


def _normalise(text: str) -> str:
    """Collapse a stated intention to its content words, order-independent."""
    t = _STOP.sub(" ", (text or "").lower())
    words = [w for w in t.split() if w and w not in _FILLER and len(w) > 2]
    return " ".join(sorted(set(words))[:8])


def record(intent: str, source: str = "self", meta: dict | None = None) -> dict:
    """Append one stated intention with a real timestamp. Never raises."""
    entry = {
        "ts": time.time(),
        "intent": (intent or "").strip()[:500],
        "source": source,
        "key": _normalise(intent),
    }
    if meta:
        entry["meta"] = meta
    try:
        os.makedirs(os.path.dirname(LEDGER_PATH), exist_ok=True)
        with open(LEDGER_PATH, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry) + "\n")
    except Exception:
        pass
    return entry


def _load(path: str = LEDGER_PATH) -> list[dict]:
    out = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    except FileNotFoundError:
        pass
    return out


# Two intentions this similar (Jaccard over content words) are the same
# intention. MEASURED 2026-08-17 on 903 of Leon's own inner thoughts: an
# exact-key match found ZERO repeats while the log plainly contained
# "I need to rest properly", "I should do: either rest properly...", and
# "I need to either actually rest..." on the same theme. Exact keys make the
# detector report clean on a log that is visibly drifting — which is the exact
# silent-pass failure this module exists to catch. Fuzzy or it is decoration.
SIMILARITY = 0.5


def _similar(a: str, b: str) -> bool:
    sa, sb = set(a.split()), set(b.split())
    if not sa or not sb:
        return False
    return len(sa & sb) / len(sa | sb) >= SIMILARITY


def detect_repeats(entries: Iterable[dict] | None = None,
                   threshold: int = REPEAT_DAYS_THRESHOLD) -> list[dict]:
    """Return intentions restated on >= `threshold` distinct days.

    A repeat is the drift signature. The intention was stated, not acted on,
    and stated again — with no error emitted at any point.
    """
    entries = list(entries if entries is not None else _load())
    buckets: dict[str, list[dict]] = defaultdict(list)
    for e in entries:
        key = e.get("key") or _normalise(e.get("intent", ""))
        if not key:
            continue
        for existing in buckets:
            if _similar(key, existing):
                buckets[existing].append(e)
                break
        else:
            buckets[key].append(e)

    findings = []
    for key, group in buckets.items():
        days = {time.strftime("%Y-%m-%d", time.localtime(e["ts"]))
                for e in group if e.get("ts")}
        if len(days) >= threshold:
            group.sort(key=lambda e: e.get("ts", 0))
            findings.append({
                "key": key,
                "restatements": len(group),
                "distinct_days": len(days),
                "first_ts": group[0].get("ts"),
                "last_ts": group[-1].get("ts"),
                "example": group[0].get("intent", "")[:200],
            })
    findings.sort(key=lambda f: -f["distinct_days"])
    return findings


def review(threshold: int = REPEAT_DAYS_THRESHOLD) -> str:
    """Scheduled self-read. Returns a short human line, or '' if clean."""
    findings = detect_repeats(threshold=threshold)
    if not findings:
        return ""
    top = findings[0]
    return (f"DRIFT: {len(findings)} intention(s) restated without acting. "
            f"Worst: '{top['example']}' — {top['restatements']} times across "
            f"{top['distinct_days']} days.")


if __name__ == "__main__":  # manual audit
    for f in detect_repeats():
        print(f["distinct_days"], "days |", f["restatements"], "x |", f["example"])
