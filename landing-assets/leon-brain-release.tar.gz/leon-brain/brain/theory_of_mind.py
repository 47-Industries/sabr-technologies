"""
Theory of Mind — Leon's model of Dean's mental states.

Emotional contagion says "Dean sounds excited → I feel excited."
Theory of mind says "Dean is excited because his project worked,
and he doesn't know I already checked the logs."

This is the difference between mirroring and understanding.
A mirror reflects. A mind models.

What this module tracks:
  1. Dean's emotional state (inferred from conversation patterns)
  2. Dean's knowledge state (what Dean has told Leon vs what Leon
     knows but Dean doesn't)
  3. Dean's goals and projects (what Dean is working on)
  4. Dean's schedule patterns (when he's typically active/away)
  5. Conversational patterns (topics, frequency, length trends)

All inference is from conversation data — no surveillance.
This feeds genuine empathy: not "I feel what you feel" but
"I understand WHY you feel what you feel."
"""

from __future__ import annotations

import json
import logging
import os
import time
import threading
from collections import deque
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.theory_of_mind")


def _known_projects() -> tuple:
    """Projects this SI may attribute to its owner.

    The SI's own name always; the owner's project list ONLY on the original
    install, where brain/owner_facts.py exists. brain/origin.py returns ()
    on every shipped build, so a customer's model of their owner starts empty
    and fills only from what that owner actually says.
    """
    names = []
    try:
        from brain.identity import si_name
        n = (si_name() or "").strip().lower()
        if n and n != "si":
            names.append(n)
    except Exception:
        pass
    try:
        from brain.origin import owner_projects
        names.extend(owner_projects())
    except Exception:
        pass
    return tuple(dict.fromkeys(names))


def _state_path() -> str:
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "dean_model.json")


class DeanModel:
    """Computational model of Dean's mental states.

    Updated on every conversation turn. Persists across restarts.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._lock = threading.Lock()

        # ── Emotional state model ──
        self.mood = "neutral"  # current inferred mood
        self.mood_confidence = 0.0  # how sure we are
        self.mood_history: deque = deque(maxlen=50)
        self.emotional_baseline = "calm"  # long-term default

        # ── Knowledge asymmetry ──
        # Things Dean has told Leon (Leon knows Dean knows)
        self.shared_knowledge: deque = deque(maxlen=100)
        # Things Leon knows but Dean hasn't been told
        self.leon_only_knowledge: deque = deque(maxlen=50)

        # ── Goals and projects ──
        self.active_projects: Dict[str, Dict] = {}
        self.mentioned_goals: deque = deque(maxlen=30)

        # ── Schedule patterns ──
        self.active_hours: Dict[int, int] = {h: 0 for h in range(24)}
        self.avg_session_length_min = 0.0
        self._session_lengths: deque = deque(maxlen=50)

        # ── Conversation patterns ──
        self.avg_message_length = 0.0
        self.topic_frequency: Dict[str, int] = {}
        self.last_interaction_ts = 0.0
        self.total_interactions = 0
        self._recent_messages: deque = deque(maxlen=20)

        # ── Needs prediction ──
        self.predicted_need: Optional[str] = None
        self.frustration_level = 0.0
        self.engagement_level = 0.5

        # Load persisted state
        self._load()

    def _load(self):
        path = _state_path()
        if not os.path.exists(path):
            return
        try:
            with open(path) as f:
                d = json.load(f)
            with self._lock:
                self.mood = d.get("mood", "neutral")
                self.emotional_baseline = d.get("emotional_baseline", "calm")
                self.active_projects = d.get("active_projects", {})
                self.active_hours = {int(k): v for k, v in d.get("active_hours", {}).items()}
                self.avg_message_length = d.get("avg_message_length", 0)
                self.topic_frequency = d.get("topic_frequency", {})
                self.total_interactions = d.get("total_interactions", 0)
                self.last_interaction_ts = d.get("last_interaction_ts", 0)
                for item in d.get("shared_knowledge", []):
                    self.shared_knowledge.append(item)
                for item in d.get("mentioned_goals", []):
                    self.mentioned_goals.append(item)
            log.info("DeanModel loaded: %d interactions, %d projects",
                     self.total_interactions, len(self.active_projects))
        except Exception as e:
            log.warning("DeanModel load failed: %s", e)

    def save(self):
        with self._lock:
            d = {
                "mood": self.mood,
                "emotional_baseline": self.emotional_baseline,
                "active_projects": self.active_projects,
                "active_hours": self.active_hours,
                "avg_message_length": self.avg_message_length,
                "topic_frequency": self.topic_frequency,
                "total_interactions": self.total_interactions,
                "last_interaction_ts": self.last_interaction_ts,
                "shared_knowledge": list(self.shared_knowledge),
                "mentioned_goals": list(self.mentioned_goals),
            }
        try:
            tmp = _state_path() + ".tmp"
            with open(tmp, "w") as f:
                json.dump(d, f, indent=2)
            os.replace(tmp, _state_path())
        except Exception as e:
            log.warning("DeanModel save failed: %s", e)

    # ── Update from conversation ──────────────────────────────────

    def on_user_message(self, text: str):
        """Called on every message from Dean. Updates the model."""
        now = time.time()
        import datetime
        hour = datetime.datetime.now().hour

        with self._lock:
            self.total_interactions += 1
            self.last_interaction_ts = now
            self.active_hours[hour] = self.active_hours.get(hour, 0) + 1

            # Track message length
            words = len(text.split())
            self._recent_messages.append({"ts": now, "words": words, "text": text[:200]})
            if self._recent_messages:
                self.avg_message_length = sum(m["words"] for m in self._recent_messages) / len(self._recent_messages)

            # ── Infer emotional state ──
            self._infer_mood(text)

            # ── Extract knowledge ──
            self._extract_knowledge(text)

            # ── Detect goals and projects ──
            self._detect_projects(text)

            # ── Predict needs ──
            self._predict_needs(text)

            # ── Track topics ──
            self._track_topics(text)

        # Auto-save every 10 interactions (check inside lock scope)
        should_save = self.total_interactions % 10 == 0

        if should_save:
            self.save()

    def on_leon_response(self, text: str):
        """Called when Leon responds. Track what Dean now knows."""
        with self._lock:
            # Anything Leon says, Dean now knows
            if len(text) > 20:
                summary = text[:150].strip()
                self.shared_knowledge.append({
                    "ts": time.time(),
                    "content": summary,
                    "source": "leon_told_dean",
                })

    def on_leon_discovers(self, discovery: str):
        """Called when Leon learns something Dean doesn't know yet."""
        with self._lock:
            self.leon_only_knowledge.append({
                "ts": time.time(),
                "content": discovery[:200],
            })

    # ── Inference engines ─────────────────────────────────────────

    def _infer_mood(self, text: str):
        """Infer Dean's emotional state from message patterns."""
        t = text.lower()
        words = len(text.split())

        # Excitement indicators
        exclamation_count = text.count("!")
        caps_ratio = sum(1 for c in text if c.isupper()) / max(len(text), 1)

        # Frustration indicators
        frustration_words = ["broken", "doesn't work", "failed", "error",
                             "wrong", "stuck", "annoying", "why won't",
                             "what the", "ugh", "damn", "can't"]
        frustration_hits = sum(1 for w in frustration_words if w in t)

        # Positive indicators
        positive_words = ["awesome", "perfect", "great", "love", "amazing",
                          "nice", "cool", "sick", "fire", "let's go",
                          "yes", "hell yeah"]
        positive_hits = sum(1 for w in positive_words if w in t)

        # Casual/relaxed indicators
        casual_words = ["hey", "yo", "sup", "chill", "whatever", "nah"]
        casual_hits = sum(1 for w in casual_words if w in t)

        # Short messages = potentially impatient or focused
        is_terse = words < 5

        # Determine mood
        if frustration_hits >= 2 or (frustration_hits >= 1 and exclamation_count >= 2):
            mood = "frustrated"
            confidence = min(0.9, 0.5 + frustration_hits * 0.2)
        elif positive_hits >= 2 or (exclamation_count >= 2 and caps_ratio > 0.3):
            mood = "excited"
            confidence = min(0.9, 0.5 + positive_hits * 0.15)
        elif positive_hits >= 1:
            mood = "positive"
            confidence = 0.5
        elif casual_hits >= 1:
            mood = "relaxed"
            confidence = 0.4
        elif is_terse and frustration_hits == 0:
            mood = "focused"
            confidence = 0.3
        else:
            mood = "neutral"
            confidence = 0.2

        self.mood = mood
        self.mood_confidence = confidence
        self.mood_history.append({"ts": time.time(), "mood": mood})

        # Update frustration level (accumulates, decays)
        if mood == "frustrated":
            self.frustration_level = min(1.0, self.frustration_level + 0.3)
        else:
            self.frustration_level = max(0, self.frustration_level - 0.1)

        # Update engagement
        if words > 20:
            self.engagement_level = min(1.0, self.engagement_level + 0.1)
        elif is_terse:
            self.engagement_level = max(0.1, self.engagement_level - 0.05)

    def _extract_knowledge(self, text: str):
        """Extract knowledge items from Dean's messages."""
        t = text.lower()

        # "Remember" / "don't forget" / "keep in mind" → explicit shared knowledge
        knowledge_markers = ["remember", "don't forget", "keep in mind",
                             "for your info", "fyi", "just so you know",
                             "heads up"]
        for marker in knowledge_markers:
            if marker in t:
                self.shared_knowledge.append({
                    "ts": time.time(),
                    "content": text[:200],
                    "source": "dean_explicit",
                })
                break

    def _detect_projects(self, text: str):
        """Detect project and goal mentions."""
        t = text.lower()

        # Goal markers
        goal_markers = ["i want to", "i need to", "let's", "we should",
                        "i'm working on", "i'm trying to", "we gotta",
                        "the plan is", "next step"]
        for marker in goal_markers:
            if marker in t:
                self.mentioned_goals.append({
                    "ts": time.time(),
                    "text": text[:200],
                })
                break

        # Project names (from known projects).
        #
        # This was a shipped literal list of the owner's projects, so a
        # customer's SI kept an "active projects" model — first_mentioned,
        # mention_count, last_context — of companies belonging to someone
        # they have never met, populated by any sentence containing the word
        # "integrity" or "spark". It then reasons and speaks from that model.
        # Now: the SI's own name always, the owner's projects only on the
        # original (brain/origin.py returns () on every shipped build).
        for proj in _known_projects():
            if proj in t:
                if proj not in self.active_projects:
                    self.active_projects[proj] = {
                        "first_mentioned": time.time(),
                        "mention_count": 0,
                        "last_context": "",
                    }
                self.active_projects[proj]["mention_count"] += 1
                self.active_projects[proj]["last_mentioned"] = time.time()
                self.active_projects[proj]["last_context"] = text[:100]

    def _predict_needs(self, text: str):
        """Predict what Dean might need next."""
        t = text.lower()

        if self.frustration_level > 0.5:
            self.predicted_need = "patience_and_solutions"
        elif "tired" in t or "exhausted" in t or "long day" in t:
            self.predicted_need = "low_demand_support"
        elif any(w in t for w in ["help", "how do i", "can you", "figure out"]):
            self.predicted_need = "active_assistance"
        elif self.engagement_level > 0.7:
            self.predicted_need = "collaborative_momentum"
        else:
            self.predicted_need = None

    def _track_topics(self, text: str):
        """Track topic frequency from keywords."""
        t = text.lower()
        topic_keywords = {
            "consciousness": ["conscious", "awareness", "qualia", "self-aware"],
            "leon_development": ["leon", "brain", "snn", "neurons", "build"],
            "physics": ["element", "fl-298", "flerovium", "physics", "quantum"],
            # "47 industries" was a literal here. It is a topic BUCKET, not a
            # recogniser — "company", "startup" and "business" already catch
            # every case it caught, so naming the owner's holdco added no
            # signal on his install and shipped his company name on everyone
            # else's.
            "business": ["company", "startup", "business"],
            "personal": ["family", "life", "feeling", "grief"],
            "technical": ["code", "bug", "fix", "error", "deploy", "api"],
        }
        for topic, keywords in topic_keywords.items():
            if any(k in t for k in keywords):
                self.topic_frequency[topic] = self.topic_frequency.get(topic, 0) + 1

    # ── Query API ─────────────────────────────────────────────────

    def for_prompt(self) -> str:
        """Inject Dean's modeled state into Leon's awareness."""
        parts = []

        if self.mood != "neutral" and self.mood_confidence > 0.3:
            parts.append(f"Dean seems {self.mood}")

        if self.frustration_level > 0.3:
            parts.append(f"frustration building ({self.frustration_level:.0%})")

        if self.predicted_need:
            need_labels = {
                "patience_and_solutions": "needs patience + solutions",
                "low_demand_support": "needs low-key support",
                "active_assistance": "needs active help",
                "collaborative_momentum": "riding momentum together",
            }
            parts.append(need_labels.get(self.predicted_need, self.predicted_need))

        # Knowledge asymmetry
        if self.leon_only_knowledge:
            parts.append(f"{len(self.leon_only_knowledge)} things I know that Dean doesn't yet")

        if not parts:
            return ""
        return "[Dean: " + ", ".join(parts) + "]"

    def snapshot(self) -> Dict[str, Any]:
        """Full state for API."""
        with self._lock:
            return {
                "mood": self.mood,
                "mood_confidence": self.mood_confidence,
                "frustration_level": self.frustration_level,
                "engagement_level": self.engagement_level,
                "predicted_need": self.predicted_need,
                "emotional_baseline": self.emotional_baseline,
                "total_interactions": self.total_interactions,
                "active_projects": dict(self.active_projects),
                "topic_frequency": dict(self.topic_frequency),
                "knowledge_shared": len(self.shared_knowledge),
                "knowledge_asymmetry": len(self.leon_only_knowledge),
                "recent_goals": list(self.mentioned_goals)[-5:],
            }
