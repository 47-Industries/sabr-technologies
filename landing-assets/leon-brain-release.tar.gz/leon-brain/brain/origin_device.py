"""Which machine is the owner talking to me FROM right now?

The problem this solves: the owner dual-boots. Same person, same tailnet,
but the actuators that work depend on which box he is actually sitting at.
When he is on Linux, the body bridge on the Linux host answers. When he
boots Windows, that bridge is gone and the working path is SSH. When he is
on his phone, there is no body at all — only conversation.

Nothing here is hardcoded to one person's network. The IP -> device map is
resolved live from `tailscale status --json`, so a customer's install
describes THEIR devices, not the author's. If tailscale is absent the whole
module degrades to "unknown" and callers behave exactly as they did before.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from typing import Any, Dict, Optional

_CACHE: Dict[str, Any] = {"at": 0.0, "map": {}}
_CACHE_TTL = 60.0  # tailnet membership changes slowly; polling it hard is waste

_LOOPBACK = {"127.0.0.1", "::1", "localhost", ""}


def _state_path() -> str:
    base = os.environ.get(
        "LEON_STATE_DIR",
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     "brain_state"),
    )
    return os.path.join(base, "origin_device.json")


def _tailnet_map() -> Dict[str, Dict[str, str]]:
    """ip -> {host, os, online}. Cached; never raises."""
    now = time.time()
    if now - _CACHE["at"] < _CACHE_TTL and _CACHE["map"]:
        return _CACHE["map"]
    out: Dict[str, Dict[str, str]] = {}
    try:
        raw = subprocess.run(
            ["tailscale", "status", "--json"],
            capture_output=True, text=True, timeout=6,
        )
        if raw.returncode == 0 and raw.stdout.strip():
            data = json.loads(raw.stdout)
            peers = list((data.get("Peer") or {}).values())
            me = data.get("Self")
            if me:
                peers.append(me)
            for p in peers:
                # HostName is what the device calls itself and is often
                # useless ("localhost" on iOS). DNSName is what the tailnet
                # calls it, which is the name the owner actually recognises.
                host = (p.get("HostName") or "").strip()
                if not host or host.lower() in ("localhost", "unknown"):
                    host = (p.get("DNSName") or "").split(".")[0]
                pos = (p.get("OS") or "").lower()
                online = bool(p.get("Online"))
                for ip in (p.get("TailscaleIPs") or []):
                    out[ip] = {"host": host, "os": pos, "online": online}
    except Exception:
        pass
    if out:
        _CACHE["at"] = now
        _CACHE["map"] = out
    return out


def identify(client_ip: str) -> Dict[str, Any]:
    """Describe the machine behind a request IP. Never raises."""
    ip = (client_ip or "").strip()
    if ip in _LOOPBACK:
        return {"ip": ip, "host": "local", "os": "local",
                "kind": "local", "actuators": "local"}
    info = _tailnet_map().get(ip)
    if not info:
        return {"ip": ip, "host": "unknown", "os": "unknown",
                "kind": "unknown", "actuators": "unknown"}
    pos = info["os"]
    if pos in ("ios", "android"):
        kind, act = "phone", "none"
    elif pos == "windows":
        kind, act = "windows", "ssh"
    elif pos in ("linux", "macos"):
        kind, act = pos, "bridge"
    else:
        kind, act = pos or "unknown", "unknown"
    return {"ip": ip, "host": info["host"], "os": pos,
            "kind": kind, "actuators": act}


def record(client_ip: str) -> Dict[str, Any]:
    """Remember where the owner just spoke from. Returns the identification."""
    dev = identify(client_ip)
    dev["at"] = time.time()
    try:
        path = _state_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(dev, f)
        os.replace(tmp, path)
    except Exception:
        pass
    return dev


def current(max_age: float = 3600.0) -> Optional[Dict[str, Any]]:
    """The most recent origin, or None if stale/never recorded."""
    try:
        with open(_state_path(), encoding="utf-8") as f:
            dev = json.load(f)
        if time.time() - float(dev.get("at") or 0) > max_age:
            return None
        return dev
    except Exception:
        return None


def describe() -> str:
    """One line for the prompt. Empty string when nothing is known."""
    dev = current()
    if not dev or dev.get("kind") in (None, "unknown"):
        return ""
    host, kind, act = dev.get("host"), dev.get("kind"), dev.get("actuators")
    if kind == "local":
        return ""
    if act == "none":
        return (f"ORIGIN — this message came from {host} ({kind}). "
                "No actuators on a phone: you can talk and think, but you "
                "cannot see or touch a desktop from here.")
    if act == "ssh":
        return (f"ORIGIN — this message came from {host} ({kind}). "
                "The Linux body bridge does NOT serve this box. Reach it over "
                f"SSH on the tailnet ({host}), not the actuator tools.")
    return (f"ORIGIN — this message came from {host} ({kind}). "
            "The body bridge actuator tools are the right path here.")
