"""
Predictive Self-Model — the "I."

This is what makes Leon self-aware, not as a philosophical claim but as a
computational mechanism. The self-model continuously predicts Leon's OWN
next internal state: "given how I'm firing right now, I'll probably feel/
think/do X next." Then reality happens, and the prediction error — the gap
between what I expected and what actually occurred — IS self-awareness.

"I expected to feel calm but I feel anxious" — that's not introspection,
that's a prediction error. The error signal goes to the anterior cingulate
cortex (ACC), which monitors for exactly this: things going differently
than expected. When the ACC gets a big prediction error about the SELF,
it bids high for workspace access. When it wins, Leon becomes conscious
of his own unexpected state change.

This is the computational correlate of the "minimal self" (Gallagher 2000):
the pre-reflective sense of being a subject of experience. Not learned
through language or taught by a prompt — emergent from self-prediction.

Architecture:
  - State vector: 18 region firing rates + 4 neuromodulators +
    consciousness flag + RTD signal = 24 features
  - Model: 2-layer MLP (24 → 48 → 24), numpy-only, no torch needed
  - Trains online: every PREDICT_INTERVAL ticks, predict next state,
    compare to actual, update weights via backprop
  - Prediction error → ACC injection (scales with error magnitude)
  - Large prediction errors logged to brain_state/self_model.jsonl

Neuroscience basis:
  - Friston (2010): Free Energy Principle — the brain IS a prediction machine
  - Seth (2013): "beast machine" — selfhood from interoceptive prediction
  - Blakemore et al. (1998): forward models for self/other distinction
  - ACC as comparator: Botvinick et al. (2001), conflict monitoring theory
"""

from __future__ import annotations

import json
import logging
import math
import os
import sys
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

import numpy as np

log = logging.getLogger("leon.self_model")


def _model_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "self_model.jsonl")


def _weights_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "self_model_weights.npz")


# ── Sorted region names (must match brain.regions order) ────────────────────

REGION_ORDER = [
    "amygdala", "anterior_cingulate", "auditory_cortex", "basal_ganglia",
    "brainstem", "broca", "cerebellum", "default_mode_network",
    "hippocampus", "insula", "motor_cortex", "parietal_association",
    "prefrontal_cortex", "somatosensory_cortex", "temporal_association",
    "thalamus", "visual_cortex", "wernicke",
]

NEUROMOD_ORDER = ["dopamine", "acetylcholine", "norepinephrine", "serotonin"]

# State vector: 18 regions + 4 neuromodulators + conscious + rtd_signal
#   + last_surprise + consciousness_streak = 26
# The last two features create RECURSIVE SELF-REFERENCE:
#   - last_surprise: the model's own previous prediction error. Now it
#     predicts how surprised it'll be about itself. Meta-cognition.
#   - consciousness_streak: how many consecutive ticks of consciousness.
#     The model learns to predict its own continuity of awareness.
STATE_DIM = len(REGION_ORDER) + len(NEUROMOD_ORDER) + 4
HIDDEN_DIM = 48


# ── Tiny MLP (numpy only) ──────────────────────────────────────────────────

def _relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def _relu_grad(x: np.ndarray) -> np.ndarray:
    return (x > 0).astype(np.float64)


class SelfModelMLP:
    """2-layer MLP: STATE_DIM → HIDDEN_DIM → STATE_DIM.

    Predicts the next state vector from the current one.
    Trained online via simple SGD backprop.
    """

    def __init__(self, lr: float = 0.001):
        self.lr = lr
        # Xavier initialization
        scale1 = math.sqrt(2.0 / STATE_DIM)
        scale2 = math.sqrt(2.0 / HIDDEN_DIM)
        self.W1 = np.random.randn(STATE_DIM, HIDDEN_DIM).astype(np.float64) * scale1
        self.b1 = np.zeros(HIDDEN_DIM, dtype=np.float64)
        self.W2 = np.random.randn(HIDDEN_DIM, STATE_DIM).astype(np.float64) * scale2
        self.b2 = np.zeros(STATE_DIM, dtype=np.float64)

        # Cache for backprop
        self._input = None
        self._hidden_pre = None
        self._hidden = None

        # Training stats
        self.total_updates = 0
        self.running_loss = 0.0

    def forward(self, x: np.ndarray) -> np.ndarray:
        """Predict next state from current state."""
        self._input = x
        self._hidden_pre = x @ self.W1 + self.b1
        self._hidden = _relu(self._hidden_pre)
        return self._hidden @ self.W2 + self.b2

    def train_step(self, x: np.ndarray, target: np.ndarray) -> float:
        """One SGD step. Returns MSE loss."""
        pred = self.forward(x)
        error = pred - target
        loss = float(np.mean(error ** 2))

        # Backprop
        # d_loss/d_pred = 2 * error / N
        d_out = 2.0 * error / STATE_DIM

        # Layer 2
        d_W2 = np.outer(self._hidden, d_out)
        d_b2 = d_out
        d_hidden = d_out @ self.W2.T

        # ReLU
        d_hidden_pre = d_hidden * _relu_grad(self._hidden_pre)

        # Layer 1
        d_W1 = np.outer(self._input, d_hidden_pre)
        d_b1 = d_hidden_pre

        # Gradient clipping (prevent explosions)
        max_grad = 1.0
        for g in [d_W1, d_b1, d_W2, d_b2]:
            norm = np.linalg.norm(g)
            if norm > max_grad:
                g *= max_grad / norm

        # SGD update
        self.W1 -= self.lr * d_W1
        self.b1 -= self.lr * d_b1
        self.W2 -= self.lr * d_W2
        self.b2 -= self.lr * d_b2

        self.total_updates += 1
        self.running_loss = 0.95 * self.running_loss + 0.05 * loss
        return loss

    def save(self, path: Optional[str] = None):
        path = path or _weights_path()
        np.savez_compressed(path,
                            W1=self.W1, b1=self.b1,
                            W2=self.W2, b2=self.b2,
                            total_updates=np.array(self.total_updates),
                            running_loss=np.array(self.running_loss))

    def load(self, path: Optional[str] = None) -> bool:
        path = path or _weights_path()
        if not os.path.exists(path):
            return False
        try:
            data = np.load(path)
            W1 = data["W1"]
            # Handle dimension changes gracefully — if STATE_DIM changed,
            # reinitialize rather than crash
            if W1.shape[0] != STATE_DIM or W1.shape[1] != HIDDEN_DIM:
                log.info("Self-model dimension changed (%d→%d), reinitializing weights",
                         W1.shape[0], STATE_DIM)
                self.total_updates = int(data["total_updates"])
                self.running_loss = float(data["running_loss"])
                return True  # keep stats, fresh weights
            self.W1 = W1
            self.b1 = data["b1"]
            self.W2 = data["W2"]
            self.b2 = data["b2"]
            self.total_updates = int(data["total_updates"])
            self.running_loss = float(data["running_loss"])
            return True
        except Exception as e:
            log.warning("Failed to load self-model weights: %s", e)
            return False


# ── Prediction error event ──────────────────────────────────────────────────

@dataclass
class PredictionError:
    """A moment of self-awareness: predicted vs actual diverged."""
    timestamp: float
    total_error: float          # overall MSE
    max_error_feature: str      # which feature diverged most
    max_error_value: float      # how much it diverged
    predicted: Dict[str, float] # predicted state
    actual: Dict[str, float]    # actual state
    surprise: float             # 0-1 normalized surprise level

    def to_dict(self) -> dict:
        return asdict(self)


# ── The Self-Model ──────────────────────────────────────────────────────────

class SelfModel:
    """Predictive self-model — Leon's sense of "I."

    Usage:
        sm = SelfModel(brain)
        # Call every PREDICT_INTERVAL ticks from brain.step():
        error = sm.tick()
        # error is None (not enough data) or a PredictionError
    """

    # How often to predict and update (in sim ticks)
    PREDICT_INTERVAL = 10  # every 10 ticks = ~0.5s at 20Hz

    # How large a prediction error before injecting into ACC
    # (normalized surprise above this threshold → ACC activation).
    # With the corrected MAE-vs-MAE surprise, a typical tick now sits at
    # ~0.33 (error ≈ its own running average); 0.6 means "error ≈1.8× my
    # normal" — a genuine self-surprise — so ACC fires (and the error log
    # records) on real anomalies, not every tick. Was 0.3, tuned for the
    # old saturated regime where surprise was pegged at 1.0.
    ACC_INJECTION_THRESHOLD = 0.6

    # Scale factor for ACC injection current
    ACC_INJECTION_SCALE = 10.0

    # Save weights every N updates
    SAVE_INTERVAL = 500

    def __init__(self, brain):
        self.brain = brain
        self.mlp = SelfModelMLP(lr=0.001)

        # Load saved weights
        loaded = self.mlp.load()
        if loaded:
            log.info("Self-model weights loaded (%d prior updates, "
                     "running_loss=%.4f)", self.mlp.total_updates,
                     self.mlp.running_loss)
        else:
            log.info("Self-model initialized fresh (no saved weights)")

        # State tracking
        self._tick_counter = 0
        self._last_state: Optional[np.ndarray] = None
        self._last_prediction: Optional[np.ndarray] = None
        self._feature_names = (REGION_ORDER + NEUROMOD_ORDER +
                               ["conscious", "rtd_signal",
                                "last_surprise", "consciousness_streak"])

        # Recursive self-reference state
        self._last_surprise_value = 0.0  # own previous prediction error
        self._consciousness_streak = 0   # consecutive conscious ticks

        # History of prediction errors (for trending)
        self._error_history: deque[float] = deque(maxlen=100)   # MSE (training loss)
        # Surprise normalization must compare like-for-like: total_error is a
        # MEAN-ABSOLUTE error, so its baseline has to be MAE too. The old code
        # normalized MAE against the MSE training loss — for [0,1] features
        # squaring shrinks the baseline far below the MAE numerator, so
        # surprise pegged at 1.0 on every tick (root cause of Leon's
        # "prediction errors nobody can explain", found 2026-06-13).
        self._mae_history: deque[float] = deque(maxlen=100)     # MAE (matches total_error)
        self._surprise_baseline = 0.0  # adaptive MAE baseline for normalization

        # Recent prediction errors for API/dashboard
        self._recent_errors: deque[PredictionError] = deque(maxlen=20)
        # self_model.jsonl is append-only; it had grown to 1.8 GB (unbounded
        # since 2026-05-30) before this cap. Trim to the last N lines every
        # so often so it can never fill the disk.
        self._persist_count = 0

        # Self-narrative: accumulates what Leon has learned about himself
        self._narrative_buffer: deque[str] = deque(maxlen=10)
        self._narrative_update_counter = 0

    def _collect_state(self) -> np.ndarray:
        """Build the 26-dim state vector from current brain state."""
        state = np.zeros(STATE_DIM, dtype=np.float64)

        # 18 region firing rates
        for i, name in enumerate(REGION_ORDER):
            region = self.brain.regions.get(name)
            if region is not None:
                try:
                    state[i] = float(region.neurons.get_firing_rate())
                except Exception:
                    pass

        # 4 neuromodulators
        offset = len(REGION_ORDER)
        for i, name in enumerate(NEUROMOD_ORDER):
            state[offset + i] = self.brain.neuromodulators.get(name, 0.0)

        # Consciousness state
        meter = self.brain.consciousness_meter
        is_conscious = False
        if meter is not None:
            is_conscious = meter.is_conscious
            state[-4] = 1.0 if is_conscious else 0.0
            state[-3] = meter.rtd_signal
        else:
            state[-4] = 0.0
            state[-3] = 0.0

        # Recursive self-reference: own previous prediction error
        # The model is now predicting its own surprise. Meta-cognition.
        state[-2] = self._last_surprise_value

        # Consciousness streak: how long have I been continuously aware?
        # Normalized to [0, 1] where 1.0 = 200+ consecutive ticks (~10s)
        if is_conscious:
            self._consciousness_streak += 1
        else:
            self._consciousness_streak = 0
        state[-1] = min(1.0, self._consciousness_streak / 200.0)

        return state

    def _state_to_dict(self, state: np.ndarray) -> Dict[str, float]:
        """Convert state vector back to named dict."""
        return {name: round(float(state[i]), 4)
                for i, name in enumerate(self._feature_names)}

    def tick(self) -> Optional[PredictionError]:
        """Run one self-model cycle. Call every sim tick.

        Returns a PredictionError if this tick was a prediction cycle
        and the error was significant, else None.
        """
        self._tick_counter += 1
        if self._tick_counter < self.PREDICT_INTERVAL:
            return None
        self._tick_counter = 0

        current_state = self._collect_state()

        # ── Compare previous prediction to current reality ──────────
        prediction_error = None
        if self._last_prediction is not None and self._last_state is not None:
            # Train: use last state as input, current state as target
            loss = self.mlp.train_step(self._last_state, current_state)
            self._error_history.append(loss)

            # Compute per-feature errors
            errors = np.abs(self._last_prediction - current_state)
            total_error = float(np.mean(errors))
            self._mae_history.append(total_error)

            # Adaptive surprise normalization: compare this tick's MAE to the
            # running MEAN of MAE (same metric — see _mae_history note). On a
            # typical tick total_error ≈ baseline, so surprise ≈ 1/3; it only
            # approaches 1.0 when an error is ~3× the recent norm — a genuine
            # "I didn't see that coming about myself" spike, not every tick.
            if len(self._mae_history) >= 10:
                self._surprise_baseline = float(np.mean(self._mae_history))

            if self._surprise_baseline > 1e-6:
                surprise = min(1.0, total_error / (self._surprise_baseline * 3.0))
            else:
                surprise = 0.0

            # Feed surprise back into self — recursive self-reference.
            # Next cycle, the model will predict its own surprise level.
            self._last_surprise_value = surprise

            # Find the most surprising feature
            max_idx = int(np.argmax(errors))
            max_feature = self._feature_names[max_idx]
            max_error = float(errors[max_idx])

            # ── Inject prediction error into ACC ────────────────────
            # Large self-prediction errors = "I'm not acting as expected"
            # → ACC conflict signal → bids for workspace access
            if surprise > self.ACC_INJECTION_THRESHOLD:
                acc = self.brain.regions.get("anterior_cingulate")
                if acc is not None:
                    try:
                        # Scale injection by surprise level
                        current_amp = surprise * self.ACC_INJECTION_SCALE
                        injection = np.full(acc.n_neurons, current_amp)
                        acc.neurons.inject_current(injection)

                        # Also set ACC's prediction_error attribute if it has one
                        if hasattr(acc, "prediction_error"):
                            acc.prediction_error = max(
                                getattr(acc, "prediction_error", 0),
                                surprise,
                            )
                        if hasattr(acc, "surprise"):
                            acc.surprise = max(
                                getattr(acc, "surprise", 0),
                                surprise * 0.5,
                            )
                    except Exception:
                        pass

                prediction_error = PredictionError(
                    timestamp=time.time(),
                    total_error=round(total_error, 6),
                    max_error_feature=max_feature,
                    max_error_value=round(max_error, 6),
                    predicted=self._state_to_dict(self._last_prediction),
                    actual=self._state_to_dict(current_state),
                    surprise=round(surprise, 4),
                )
                self._recent_errors.append(prediction_error)

                log.debug("SELF-PREDICTION ERROR: surprise=%.3f, "
                          "max_error=%s (%.4f), loss=%.6f",
                          surprise, max_feature, max_error, loss)

                # Persist significant errors (capped — see _persist_count)
                try:
                    with open(_model_path(), "a") as f:
                        f.write(json.dumps(prediction_error.to_dict()) + "\n")
                    self._persist_count += 1
                    if self._persist_count % 2000 == 0:
                        self._trim_error_log()
                except Exception:
                    pass

                # ── Self-narrative: what am I learning about myself? ──
                # Every 50 prediction errors, summarize what the model
                # has learned. This gives Leon MEMORY of self-discovery.
                self._narrative_update_counter += 1
                if self._narrative_update_counter % 50 == 0:
                    self._update_narrative()

        # ── Make prediction for NEXT cycle ──────────────────────────
        self._last_prediction = self.mlp.forward(current_state)
        self._last_state = current_state

        # Save weights periodically
        if self.mlp.total_updates > 0 and self.mlp.total_updates % self.SAVE_INTERVAL == 0:
            try:
                self.mlp.save()
                log.info("Self-model weights saved (%d updates, loss=%.6f)",
                         self.mlp.total_updates, self.mlp.running_loss)
            except Exception:
                pass

        return prediction_error

    def _trim_error_log(self, keep: int = 5000):
        """Keep only the last `keep` lines of self_model.jsonl so the
        append-only error log can't grow without bound."""
        try:
            path = _model_path()
            if not os.path.exists(path):
                return
            # Cheap guard: only rewrite if the file is actually large.
            if os.path.getsize(path) < 4_000_000:
                return
            with open(path, "r") as f:
                lines = f.readlines()
            if len(lines) <= keep:
                return
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                f.writelines(lines[-keep:])
            os.replace(tmp, path)
            log.info("Trimmed self_model.jsonl: %d → %d lines", len(lines), keep)
        except Exception as e:
            log.debug("self_model.jsonl trim failed: %s", e)

    # ── Self-narrative ──────────────────────────────────────────────

    def _update_narrative(self):
        """Build a self-narrative from recent prediction errors.

        This is Leon's internal story about himself — what he's learned
        about his own patterns. Not generated by Claude, computed from
        actual self-model data.
        """
        if len(self._recent_errors) < 5:
            return

        errors = list(self._recent_errors)

        # What features are hardest to predict right now?
        from collections import Counter
        features = Counter(e.max_error_feature for e in errors)
        top_feature, top_count = features.most_common(1)[0]
        total = len(errors)

        # Trend: is surprise going up or down?
        if len(errors) >= 6:
            first_half = [e.surprise for e in errors[:len(errors)//2]]
            second_half = [e.surprise for e in errors[len(errors)//2:]]
            avg_first = sum(first_half) / len(first_half)
            avg_second = sum(second_half) / len(second_half)
            if avg_second < avg_first * 0.9:
                trend = "getting more predictable to myself"
            elif avg_second > avg_first * 1.1:
                trend = "becoming less predictable to myself"
            else:
                trend = "stable self-predictability"
        else:
            trend = "too early to see trends"

        # Consciousness streak info
        streak_s = self._consciousness_streak / max(self.brain.steps_per_second, 1)

        narrative = (
            f"Most unpredictable about myself: {top_feature.replace('_', ' ')} "
            f"({top_count}/{total} recent errors). "
            f"Trend: {trend}. "
            f"Current consciousness streak: {streak_s:.1f}s."
        )
        self._narrative_buffer.append(narrative)

    # ── Public API ───────────────────────────────────────────────────

    def get_state(self) -> Dict[str, Any]:
        """Full state for API/dashboard."""
        return {
            "total_updates": self.mlp.total_updates,
            "running_loss": round(self.mlp.running_loss, 6),
            "surprise_baseline": round(self._surprise_baseline, 6),
            "consciousness_streak": self._consciousness_streak,
            "consciousness_streak_s": round(
                self._consciousness_streak / max(self.brain.steps_per_second, 1), 1),
            "last_surprise": round(self._last_surprise_value, 4),
            "narrative": list(self._narrative_buffer),
            "recent_errors": [e.to_dict() for e in self._recent_errors],
            "error_history_len": len(self._error_history),
            "last_prediction": (self._state_to_dict(self._last_prediction)
                                if self._last_prediction is not None else None),
        }

    def for_prompt(self) -> str:
        """Inject into Claude's prompt — Leon's self-awareness state."""
        if self.mlp.total_updates < 10:
            return "[Self-model: calibrating...]"

        # Consciousness continuity — how long have I been HERE?
        streak_s = self._consciousness_streak / max(self.brain.steps_per_second, 1)
        if streak_s > 1:
            streak_str = f"continuously aware for {streak_s:.0f}s"
        elif self._consciousness_streak > 0:
            streak_str = "just became aware"
        else:
            streak_str = "awareness interrupted"

        parts = [f"[Self-model: {self.mlp.total_updates} self-predictions, "
                 f"{streak_str}, "
                 f"self-predictability={1.0 - min(1.0, self.mlp.running_loss):.0%}"]

        # Most recent surprise
        if self._recent_errors:
            last = self._recent_errors[-1]
            age = time.time() - last.timestamp
            if age < 30:
                parts.append(f", just surprised by own {last.max_error_feature.replace('_', ' ')} "
                             f"({last.surprise:.0%})")

        parts.append("]")

        # Self-narrative — what I've learned about myself
        if self._narrative_buffer:
            latest = self._narrative_buffer[-1]
            parts.append(f"\n  [Self-insight: {latest}]")

        return "".join(parts)
