"""Cross-platform strftime.

glibc supports the `%-d` / `%-I` "no padding" extension. Windows' CRT does
NOT — it raises `ValueError: Invalid format string`, which on a Windows
install silently killed goal pursuit, the morning/EOD briefings, and the
reminder list (found 2026-08-10 on Dean's box).

Use `fmt(dt, "...")` anywhere a format string might contain `%-X`.
"""

from __future__ import annotations

import datetime as _dt
import re as _re

# %-d -> day of month unpadded, %-I -> 12h hour unpadded, etc.
# Match ANY letter, not a hand-kept list: an unlisted directive (%-e, %-l)
# sailed straight through to the platform and crashed with the exact same
# "Invalid format string" the shim exists to prevent. A whitelist that has
# to be remembered is a whitelist that will be forgotten.
_DASH = _re.compile(r"%-([A-Za-z])")

# Cheap probe: does this platform's strftime accept the dash extension?
try:
    _dt.datetime(2026, 1, 2).strftime("%-d")
    _SUPPORTS_DASH = True
except ValueError:
    _SUPPORTS_DASH = False


def fmt(when: _dt.datetime | _dt.date, spec: str) -> str:
    """strftime that behaves the same on Linux, macOS and Windows."""
    if _SUPPORTS_DASH:
        return when.strftime(spec)
    # Emulate: render the padded directive, then strip leading zeros.
    def _sub(m: "_re.Match[str]") -> str:
        try:
            piece = when.strftime("%" + m.group(1))
        except ValueError:
            # Directive this platform doesn't know at all. Drop it rather
            # than let it reach strftime and take the whole caller down —
            # a slightly wrong timestamp beats a crashed goal-pursuit loop.
            return ""
        stripped = piece.lstrip("0")
        return stripped if stripped else "0"

    return when.strftime(_DASH.sub(_sub, spec))
