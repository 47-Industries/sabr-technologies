"""Cross-platform strftime.

glibc supports the `%-d` / `%-I` "no padding" extension. Windows' CRT does
NOT — it raises `ValueError: Invalid format string`, which on a Windows
install silently killed goal pursuit, the morning/EOD briefings, and the
reminder list (found 2026-08-10 on Dean's box).

Use `fmt(dt, "...")` anywhere a format string might contain `%-X`.
"""

from __future__ import annotations

import datetime as _dt
import re as _re

# %-d -> day of month unpadded, %-I -> 12h hour unpadded, etc.
# Match ANY letter, not a hand-kept list: an unlisted directive (%-e, %-l)
# sailed straight through to the platform and crashed with the exact same
# "Invalid format string" the shim exists to prevent. A whitelist that has
# to be remembered is a whitelist that will be forgotten.
_DASH = _re.compile(r"%-([A-Za-z])")

# Cheap probe: does this platform's strftime accept the dash extension?
try:
    _dt.datetime(2026, 1, 2).strftime("%-d")
    _SUPPORTS_DASH = True
except ValueError:
    _SUPPORTS_DASH = False


def fmt(when: _dt.datetime | _dt.date, spec: str) -> str:
    """strftime that behaves the same on Linux, macOS and Windows."""
    if _SUPPORTS_DASH:
        return when.strftime(spec)
    # Emulate: render the padded directive, then strip leading zeros.
    def _sub(m: "_re.Match[str]") -> str:
        try:
            piece = when.strftime("%" + m.group(1))
        except ValueError:
            # Directive this platform doesn't know at all. Drop it rather
            # than let it reach strftime and take the whole caller down —
            # a slightly wrong timestamp beats a crashed goal-pursuit loop.
            return ""
        stripped = piece.lstrip("0")
        return stripped if stripped else "0"

    return when.strftime(_DASH.sub(_sub, spec))


# ── Timezone resolution (added by Makima patch) ───────────────────────
# These resolve LIVE on every call — never cached at import time —
# so a daemon that runs for days sees TZ changes without restart.

import os as _os
import time as _time

import os as _os
import time as _time

_ACTUATOR_TZ_CACHE: dict = {"tz": None, "at": 0.0}
_ACTUATOR_TZ_TTL = 900.0  # 15 min


def owner_tz() -> _dt.timezone:
    """Return the owner's timezone, resolved live on every call.

    Resolution chain:
      1. LEON_TZ or OWNER_TZ env var (read fresh each call)
      2. Actuator system.timezone tool result (cached 15 min)
      3. /etc/timezone (Linux)
      4. /etc/localtime symlink basename
      5. UTC fallback
    """
    # 1. Env override — read fresh every call so a hand-edit takes effect
    for _v in ("LEON_TZ", "OWNER_TZ"):
        _raw = _os.environ.get(_v, "").strip()
        if _raw:
            try:
                import zoneinfo as _zi
                return _dt.timezone(_dt.timedelta(
                    seconds=_zi.ZoneInfo(_raw).utcoffset(
                        _dt.datetime.now(_dt.timezone.utc)).total_seconds()))
            except Exception:
                pass

    # 2. Actuator cache (15 min TTL)
    _now = _time.monotonic()
    if _ACTUATOR_TZ_CACHE["tz"] is not None and (_now - _ACTUATOR_TZ_CACHE["at"]) < _ACTUATOR_TZ_TTL:
        return _ACTUATOR_TZ_CACHE["tz"]
    try:
        from brain.actuator_client import call as _acall
        result = _acall("system.timezone", {})
        if isinstance(result, dict) and result.get("ok"):
            _raw = result.get("timezone", "")
            if _raw:
                import zoneinfo as _zi
                _tz = _dt.timezone(_dt.timedelta(
                    seconds=_zi.ZoneInfo(_raw).utcoffset(
                        _dt.datetime.now(_dt.timezone.utc)).total_seconds()))
                _ACTUATOR_TZ_CACHE["tz"] = _tz
                _ACTUATOR_TZ_CACHE["at"] = _now
                return _tz
    except Exception:
        pass

    # 3. /etc/timezone
    try:
        _raw = open("/etc/timezone").read().strip()
        if _raw:
            import zoneinfo as _zi
            _tz = _dt.timezone(_dt.timedelta(
                seconds=_zi.ZoneInfo(_raw).utcoffset(
                    _dt.datetime.now(_dt.timezone.utc)).total_seconds()))
            _ACTUATOR_TZ_CACHE["tz"] = _tz
            _ACTUATOR_TZ_CACHE["at"] = _now
            return _tz
    except Exception:
        pass

    # 4. /etc/localtime symlink
    try:
        import pathlib as _pl
        _lk = _pl.Path("/etc/localtime").resolve()
        _raw = "/".join(_lk.parts[-2:])
        import zoneinfo as _zi
        _tz = _dt.timezone(_dt.timedelta(
            seconds=_zi.ZoneInfo(_raw).utcoffset(
                _dt.datetime.now(_dt.timezone.utc)).total_seconds()))
        _ACTUATOR_TZ_CACHE["tz"] = _tz
        _ACTUATOR_TZ_CACHE["at"] = _now
        return _tz
    except Exception:
        pass

    # 5. UTC fallback
    return _dt.timezone.utc


def now() -> _dt.datetime:
    """Current time in the owner's timezone — always timezone-aware."""
    return _dt.datetime.now(_dt.timezone.utc).astimezone(owner_tz())
