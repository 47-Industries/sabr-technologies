"""
Proactive Skill Practice — Leon optimizes tools Dean uses most.

Watches tool usage patterns and proactively:
  - Tests reliability of frequently-used tools
  - Pre-caches results where possible
  - Creates goals for improving broken high-value tools
  - Suggests shortcuts and reflexes for common patterns

Runs during idle periods. Never interrupts Dean.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Dict, List, Optional

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_PRACTICE_FILE = _STATE_DIR / "skill_practice.json"


def _load() -> dict:
    try:
        return json.loads(_PRACTICE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"practice_log": [], "skill_health": {}, "last_practice": 0}


def _save(data: dict) -> None:
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    _PRACTICE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def analyze_usage_patterns() -> dict:
    """Analyze tool_learning.jsonl to find Dean's most-used tool patterns."""
    log_file = _STATE_DIR / "tool_learning.jsonl"
    if not log_file.exists():
        return {"top_tools": [], "top_patterns": []}

    tool_counts: Dict[str, int] = {}
    pattern_counts: Dict[str, dict] = {}

    try:
        for line in log_file.read_text(encoding="utf-8").splitlines():
            entry = json.loads(line.strip())
            tool = entry.get("tool", "")
            if tool:
                tool_counts[tool] = tool_counts.get(tool, 0) + 1
            keywords = tuple(sorted(entry.get("keywords", [])[:3]))
            if keywords:
                key = str(keywords)
                if key not in pattern_counts:
                    pattern_counts[key] = {
                        "keywords": list(keywords),
                        "tool": tool,
                        "count": 0,
                        "last_text": entry.get("user_text", ""),
                    }
                pattern_counts[key]["count"] += 1
    except Exception:
        pass

    top_tools = sorted(tool_counts.items(), key=lambda x: x[1], reverse=True)[:20]
    top_patterns = sorted(pattern_counts.values(),
                          key=lambda x: x["count"], reverse=True)[:20]

    return {"top_tools": top_tools, "top_patterns": top_patterns}


def practice_session() -> List[dict]:
    """Run a practice session: test top tools, create goals for broken ones."""
    results = []
    usage = analyze_usage_patterns()

    # Only test tools that have known safe test args — the rest (shell_exec,
    # code_edit, etc.) can't be meaningfully health-checked without side effects.
    try:
        from brain.tool_explorer import _SAFE_EXPLORE_ARGS
        testable = set(_SAFE_EXPLORE_ARGS.keys())
    except Exception:
        testable = set()

    top_testable = [(t, c) for t, c in usage.get("top_tools", []) if t in testable][:5]
    for tool_name, count in top_testable:
        # Check if this tool still works
        try:
            from brain.failure_memory import is_known_failure
            if is_known_failure(tool_name):
                # High-value tool is broken — create a goal to fix it
                try:
                    from brain.persistent_goals import add_goal, get_active_goals
                    existing = [g for g in get_active_goals()
                                if tool_name in g.get("description", "")]
                    if not existing:
                        add_goal(
                            f"Fix broken tool: {tool_name} (used {count} times)",
                            category="optimize",
                            priority=0.8,
                            source="system",
                        )
                except Exception:
                    pass
                results.append({
                    "tool": tool_name,
                    "status": "broken_goal_created",
                    "usage_count": count,
                })
                continue
        except Exception:
            pass

        # Quick health check on the tool
        try:
            from brain.actuator_client import call
            from brain.tool_explorer import _SAFE_EXPLORE_ARGS
            args = _SAFE_EXPLORE_ARGS.get(tool_name, {})
            result = call(tool_name, args, timeout=5.0)

            data = _load()
            data["skill_health"][tool_name] = {
                "ok": result.get("ok", False),
                "last_tested": time.time(),
                "usage_count": count,
            }
            data["last_practice"] = time.time()
            _save(data)

            results.append({
                "tool": tool_name,
                "status": "healthy" if result.get("ok") else "degraded",
                "usage_count": count,
            })
        except Exception as e:
            results.append({
                "tool": tool_name,
                "status": "error",
                "error": str(e),
            })

    try:
        from server.helpers import broadcast_activity
        healthy = sum(1 for r in results if r["status"] == "healthy")
        degraded = [r["tool"] for r in results if r["status"] in ("broken_goal_created", "degraded", "error")]
        # Only broadcast if we actually found a problem worth reporting
        if degraded:
            broadcast_activity("inner",
                f"Tool health: {', '.join(degraded[:3])} degraded — {healthy}/{len(results)} healthy", 8000)
        # Silence when everything is fine or nothing was testable
    except Exception:
        pass

    return results


def get_skill_health() -> dict:
    """Current health of Leon's most-used tools."""
    return _load().get("skill_health", {})
