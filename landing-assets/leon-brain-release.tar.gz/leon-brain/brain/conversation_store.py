"""
Persistent conversation history for `BrainAPIResponder`.

Without this, every server restart wipes Leon's memory of prior turns.
Stored in the existing `brain_state/knowledge.db` SQLite as its own
`conversation_history` table — same DB so backups already cover it,
but a separate table so it doesn't pollute knowledge_search results.

Cheap on every turn: one INSERT per role-message. Reads happen exactly
once (on responder boot) — last N turns to seed `self.history`.
"""

from __future__ import annotations

import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional


#: Anthropic API ACCEPTS these fields on input messages — anything else
#: (citations, parsed_output, caller, etc.) is output-only and will trigger
#: a 400 invalid_request_error like:
#:   messages.6.content.0.text.parsed_output: Extra inputs are not permitted
#: This caused intermittent chat failures after the block-persistence shipped.
_INPUT_VALID_KEYS = {
    "text":        {"type", "text"},
    "tool_use":    {"type", "id", "name", "input"},
    "tool_result": {"type", "tool_use_id", "content", "is_error"},
    "thinking":    {"type", "thinking", "signature"},
    "image":       {"type", "source"},
}


def _strip_to_input_valid(block: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of `block` containing ONLY the fields Anthropic's
    messages API accepts as input. Drops output-only fields the SDK
    helpfully attaches to its response objects (citations, parsed_output,
    caller, etc.)."""
    if not isinstance(block, dict):
        return block
    t = block.get("type")
    allowed = _INPUT_VALID_KEYS.get(t)
    if not allowed:
        # unknown block type — keep type + drop None-valued extras as a
        # best-effort safety net
        return {k: v for k, v in block.items() if v is not None}
    return {k: block[k] for k in allowed if k in block}


def _block_to_json(obj: Any) -> Any:
    """Default-encoder for `json.dumps` — handles Anthropic SDK content
    blocks (TextBlock, ToolUseBlock) which are pydantic-ish objects.
    Falls through to str() for anything else.

    Critical: strips output-only fields (citations / parsed_output /
    caller / ...) before persisting. Persisted blocks must be valid as
    INPUT for the next API call, not just whatever the SDK echoed back."""
    # Anthropic SDK blocks expose model_dump() (pydantic v2) or dict().
    for attr in ("model_dump", "dict"):
        fn = getattr(obj, attr, None)
        if callable(fn):
            try:
                return _strip_to_input_valid(fn())
            except Exception:
                pass
    if isinstance(obj, dict):
        return _strip_to_input_valid(obj)
    # Last resort: stringify so json.dumps doesn't crash. Loses fidelity
    # but at least the row is persisted.
    return str(obj)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversation_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL,
    session_id  TEXT    NOT NULL DEFAULT 'default',
    role        TEXT    NOT NULL,    -- 'user' | 'assistant'
    content     TEXT    NOT NULL,
    model       TEXT    DEFAULT '',  -- haiku/sonnet/opus tier on assistant rows
    metadata    TEXT    DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_conv_session_ts
    ON conversation_history (session_id, ts);
"""


class ConversationStore:
    """Thread-safe SQLite wrapper for storing/replaying conversation turns."""

    def __init__(
        self,
        db_path: Optional[str] = None,
        session_id: str = "default",
    ):
        if db_path is None:
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(project_root, "brain_state", "knowledge.db")
        self.db_path = db_path
        self.session_id = session_id
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self) -> None:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            # busy_timeout prevents boot hang if another process holds the DB
            conn.execute("PRAGMA busy_timeout = 5000")
            conn.execute("PRAGMA journal_mode = WAL")
            for stmt in _SCHEMA.strip().split(";"):
                s = stmt.strip()
                if s:
                    conn.execute(s)
            # HEALING MIGRATION (2026-08-25): upgrade_awareness used to persist
            # its synthetic wake prompt as a role='user' turn, so customer
            # installs (Kyle's Mac) painted "You just woke up and something is
            # profoundly different... here's what you're feeling" as if the
            # CUSTOMER typed it. The call site is fixed to persist_history=False;
            # this purge heals databases already poisoned by older builds every
            # time the store opens. Signature is exact-prefix on the synthetic
            # prompt so no real human words can ever match.
            conn.execute(
                "DELETE FROM conversation_history WHERE role='user' AND "
                "content LIKE 'You just woke up and something is profoundly different%'"
            )
            conn.commit()

    def append(
        self,
        role: str,
        content: Any,                       # str OR list-of-blocks (Anthropic format)
        model: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Persist one turn. `content` can be a plain string (chat-only
        turns) OR a list of Anthropic content blocks (text + tool_use +
        tool_result). Lists are JSON-encoded with a sentinel prefix so
        load_recent can tell them apart from legacy text rows.
        Returns the row id, or -1 if content is empty."""
        import json as _json
        # Normalize: lists go in as JSON with a sentinel; everything else
        # as a stripped string. Empty content is skipped.
        # CREDENTIAL GUARD (2026-09-04). A user said her Gmail password out
        # loud to her SI; it landed here verbatim and was then copied into the
        # knowledge table and the FTS index — plaintext, permanent, searchable.
        # The store must refuse to hold a spoken secret, because "please don't
        # say passwords out loud" is advice, not a control. Only the VALUE is
        # replaced, so the turn still reads as "the password is
        # [REDACTED-CREDENTIAL]" and the SI can still react to what happened.
        try:
            from brain.security import redact_credentials_deep as _rcd
            content = _rcd(content)
        except Exception:
            pass  # never let the guard break persistence

        # THE BRAIN'S OWN AUTH FAILING IS NOT SOMETHING THE SI SAID
        # (2026-09-05). When Claude Code's OAuth expires it prints
        # "Failed to authenticate: OAuth session expired and could not be
        # refreshed" and EXITS ZERO, so that line rides all the way through
        # as the assistant's reply -- spoken out loud, and written here as
        # an utterance. Leon's own history carries eight of them from this
        # morning, sitting in his memory as things he said. They are an
        # infrastructure fault, not speech, and a mind's record of itself
        # should not fill up with them.
        if role == "assistant":
            try:
                from brain.security import looks_like_brain_auth_failure as _laf
                if isinstance(content, str) and _laf(content):
                    return -1
            except Exception:
                pass

        if isinstance(content, list):
            if not content:
                return -1
            stored = "__BLOCKS__" + _json.dumps(content, default=_block_to_json)
        else:
            stored = (content or "").strip() if isinstance(content, str) else str(content)
            if not stored:
                return -1
        meta_str = _json.dumps(metadata or {}, default=str)
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            # Skip an immediate duplicate. The user turn is persisted once
            # "pre-response" (so it survives a restart) and AGAIN when the turn
            # completes — the two writes are consecutive with nothing between,
            # so the transcript AND Leon's own context showed every message
            # twice. If the most recent row is an identical (role, content),
            # don't write it again. Genuine repeats (with an assistant turn in
            # between) aren't consecutive, so they're unaffected.
            last = cur.execute(
                "SELECT id, role, content FROM conversation_history "
                "WHERE session_id = ? ORDER BY id DESC LIMIT 1",
                (self.session_id,),
            ).fetchone()
            if last and last[1] == role and last[2] == stored:
                return last[0]
            cur.execute(
                "INSERT INTO conversation_history (ts, session_id, role, content, model, metadata) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (time.time(), self.session_id, role, stored, model, meta_str),
            )
            conn.commit()
            return cur.lastrowid

    def load_recent(self, limit: int = 24) -> List[Dict[str, Any]]:
        """Return the most recent up-to-N turns in chronological order.
        Each entry is shaped like the Anthropic messages list expects:
        `{"role": "user"|"assistant", "content": str_or_block_list}`.
        Rows starting with the `__BLOCKS__` sentinel are decoded back
        into a content-block list (preserves tool_use / tool_result
        structure across restarts — fixes the 'priming' bug where Sonnet
        sees prior turns as text-only and stops calling tools)."""
        if limit <= 0:
            return []
        import json as _json
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            rows = conn.execute(
                "SELECT role, content FROM conversation_history "
                "WHERE session_id = ? ORDER BY id DESC LIMIT ?",
                (self.session_id, limit),
            ).fetchall()
        out: List[Dict[str, Any]] = []
        for (role, content) in reversed(rows):
            if isinstance(content, str) and content.startswith("__BLOCKS__"):
                try:
                    blocks = _json.loads(content[len("__BLOCKS__"):])
                    # Defensive: strip output-only fields from any row
                    # that was written before the _strip_to_input_valid
                    # fix landed. Without this, replaying ~36 historical
                    # blocks throws 400 invalid_request_error.
                    clean = [_strip_to_input_valid(b) for b in blocks
                             if isinstance(b, dict)]
                    out.append({"role": role, "content": clean})
                    continue
                except Exception:
                    pass  # fall through to plain-text
            out.append({"role": role, "content": content})
        return out

    def load_recent_prioritized(self, limit: int = 400, real_floor: int = 300) -> List[Dict[str, Any]]:
        """Load recent turns, prioritizing real conversations over proactive noise.

        Loads up to `limit` total turns, but guarantees at least `real_floor`
        slots for non-proactive turns (model != 'proactive'). Proactive turns
        only fill the remaining slots, keeping Leon's context window focused
        on actual conversations with Dean.

        Returns turns in chronological order, each shaped for the Anthropic API.
        """
        if limit <= 0:
            return []
        import json as _json
        # Load the most recent real (non-proactive) turns with their IDs, then
        # backfill remaining slots with RECENT proactive turns (Leon's own
        # thoughts inside the same window) so context stays focused on the
        # actual conversation. IDs let us interleave them chronologically.
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            # Get IDs of the real rows
            real_ids = conn.execute(
                "SELECT id, role, content FROM conversation_history "
                "WHERE session_id = ? AND model != 'proactive' "
                "ORDER BY id DESC LIMIT ?",
                (self.session_id, real_floor),
            ).fetchall()

            oldest_real_id = min(r[0] for r in real_ids) if real_ids else 0
            proactive_limit = limit - len(real_ids)

            if proactive_limit > 0:
                proactive_ids = conn.execute(
                    "SELECT id, role, content FROM conversation_history "
                    "WHERE session_id = ? AND model = 'proactive' AND id >= ? "
                    "ORDER BY id DESC LIMIT ?",
                    (self.session_id, oldest_real_id, proactive_limit),
                ).fetchall()
            else:
                proactive_ids = []

        # Combine, sort by id (chronological), decode
        combined = list(real_ids) + list(proactive_ids)
        combined.sort(key=lambda r: r[0])

        out: List[Dict[str, Any]] = []
        for (_id, role, content) in combined:
            if isinstance(content, str) and content.startswith("__BLOCKS__"):
                try:
                    blocks = _json.loads(content[len("__BLOCKS__"):])
                    clean = [_strip_to_input_valid(b) for b in blocks
                             if isinstance(b, dict)]
                    out.append({"role": role, "content": clean})
                    continue
                except Exception:
                    pass
            out.append({"role": role, "content": content})
        return out

    def count(self) -> int:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            (n,) = conn.execute(
                "SELECT COUNT(*) FROM conversation_history WHERE session_id = ?",
                (self.session_id,),
            ).fetchone()
        return int(n)

    def clear(self) -> int:
        """Wipe history for this session. Returns rows deleted."""
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM conversation_history WHERE session_id = ?",
                (self.session_id,),
            )
            conn.commit()
            return cur.rowcount or 0

    def trim(self, keep_last: int = 200) -> int:
        """Delete all but the most recent `keep_last` turns. Returns
        rows deleted. Run periodically so the table doesn't grow forever."""
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM conversation_history "
                "WHERE session_id = ? AND id NOT IN ("
                "    SELECT id FROM conversation_history "
                "    WHERE session_id = ? ORDER BY id DESC LIMIT ?"
                ")",
                (self.session_id, self.session_id, keep_last),
            )
            conn.commit()
            return cur.rowcount or 0
