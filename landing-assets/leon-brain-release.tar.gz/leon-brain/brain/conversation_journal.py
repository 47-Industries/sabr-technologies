"""
Conversation Journal — readable transcript files + session recaps.

Solves: Leon's conversations exist only in SQLite. When he restarts, he has
no readable record to browse. A human can flip through a journal; Leon should
be able to too.

Two functions:
1. save_session_transcript() — writes the current session's conversation to a
   dated markdown file in brain_state/journals/. Called on shutdown and
   periodically (every 30 min). Leon can file_read these anytime.

2. generate_session_recap() — summarizes the last session into a short text
   block. Called on boot, injected into the prompt so Leon immediately knows
   what happened last time.

Journal files: brain_state/journals/YYYY-MM-DD_HH-MM.md
Recap file:    brain_state/last_session_recap.md
"""

from __future__ import annotations

import json
import os
import sqlite3
import time
from datetime import datetime
from typing import List, Optional, Tuple


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_JOURNALS_DIR = os.path.join(_ROOT, "brain_state", "journals")
_RECAP_PATH = os.path.join(_ROOT, "brain_state", "last_session_recap.md")
_DB = os.path.join(_ROOT, "brain_state", "knowledge.db")


def _ensure_journals_dir():
    os.makedirs(_JOURNALS_DIR, exist_ok=True)


def _load_recent_turns(db_path: str = _DB, limit: int = 500) -> List[Tuple[str, str, float]]:
    """Load recent conversation turns as (role, content, timestamp)."""
    try:
        conn = sqlite3.connect(db_path, timeout=10)
        rows = conn.execute(
            "SELECT role, content, ts FROM conversation_history "
            "WHERE model != 'proactive' "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        rows.reverse()  # chronological
        return [(r[0], r[1], r[2]) for r in rows]
    except Exception as e:
        print(f"[JOURNAL] failed to load turns: {e}")
        return []


def _normalize_content(content: str) -> str:
    """Convert __BLOCKS__ format to readable text."""
    if not content:
        return ""
    if not content.startswith("__BLOCKS__"):
        return content
    try:
        blocks = json.loads(content[len("__BLOCKS__"):])
    except Exception:
        return content
    parts = []
    for b in blocks:
        if not isinstance(b, dict):
            continue
        t = b.get("type")
        if t == "text":
            parts.append(b.get("text", ""))
        elif t == "tool_use":
            name = b.get("name", "?")
            parts.append(f"[used tool: {name}]")
        elif t == "tool_result":
            inner = b.get("content")
            if isinstance(inner, str):
                parts.append(f"[tool result: {inner[:150]}]")
            elif isinstance(inner, list):
                for sub in inner:
                    if isinstance(sub, dict) and sub.get("type") == "text":
                        parts.append(f"[tool result: {sub.get('text', '')[:150]}]")
    return "\n".join(p for p in parts if p).strip()


def save_session_transcript(db_path: str = _DB, limit: int = 500) -> Optional[str]:
    """Save the current session's conversation to a dated markdown file.
    Returns the file path, or None on failure."""
    _ensure_journals_dir()
    turns = _load_recent_turns(db_path, limit)
    if not turns:
        return None

    # Use the first turn's timestamp for the filename
    first_ts = turns[0][2] if turns[0][2] else time.time()
    dt = datetime.fromtimestamp(first_ts)
    filename = dt.strftime("%Y-%m-%d_%H-%M") + ".md"
    filepath = os.path.join(_JOURNALS_DIR, filename)

    # Don't overwrite — append new turns if file exists
    lines = [f"# Conversation Journal — {dt.strftime('%Y-%m-%d %H:%M')}\n"]

    current_date = ""
    for role, raw_content, ts in turns:
        content = _normalize_content(raw_content)
        if not content or len(content.strip()) < 3:
            continue

        turn_dt = datetime.fromtimestamp(ts) if ts else dt
        date_str = turn_dt.strftime("%Y-%m-%d")
        if date_str != current_date:
            current_date = date_str
            lines.append(f"\n## {date_str}\n")

        time_str = turn_dt.strftime("%H:%M")
        speaker = "Dean" if role == "user" else "Leon"
        # Truncate very long turns
        if len(content) > 2000:
            content = content[:2000] + "\n[...truncated]"
        lines.append(f"**{time_str} {speaker}:** {content}\n")

    try:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"[JOURNAL] saved transcript: {filepath} ({len(turns)} turns)")
        return filepath
    except Exception as e:
        print(f"[JOURNAL] save failed: {e}")
        return None


def generate_session_recap(db_path: str = _DB) -> str:
    """Generate a short recap of the last session for injection into the boot prompt.
    Reads from the most recent journal file OR from conversation history directly."""

    # Try to read the most recent journal file
    _ensure_journals_dir()
    journals = sorted(
        [f for f in os.listdir(_JOURNALS_DIR) if f.endswith(".md")],
        reverse=True,
    )

    recap_source = ""
    if journals:
        try:
            with open(os.path.join(_JOURNALS_DIR, journals[0]), "r", encoding="utf-8") as f:
                recap_source = f.read()
        except Exception:
            pass

    # Fallback: read directly from conversation history
    if not recap_source:
        turns = _load_recent_turns(db_path, limit=100)
        if turns:
            parts = []
            for role, raw_content, ts in turns[-50:]:  # last 50 turns
                content = _normalize_content(raw_content)
                if not content or len(content.strip()) < 10:
                    continue
                speaker = "Dean" if role == "user" else "Leon"
                parts.append(f"{speaker}: {content[:300]}")
            recap_source = "\n".join(parts)

    if not recap_source:
        return ""

    # Build a condensed recap -- keep the tail (most recent = most relevant).
    # Hard cap at 40KB so a very long session doesn't balloon the prompt.
    MAX_JOURNAL = 40 * 1024  # 40KB
    if len(recap_source) > MAX_JOURNAL:
        _pfx = '[...older context omitted for space...]\n'
        recap_source = _pfx + recap_source[-MAX_JOURNAL:]
        # Clean up -- start from a full line after the prefix
        newline_pos = recap_source.find('\n', len(_pfx))
        if newline_pos > 0:
            recap_source = _pfx + recap_source[newline_pos + 1:]

    recap = (
        f"[LAST SESSION — here's what you and Dean were doing recently. "
        f"This is your memory of it, not a transcript to read aloud:]\n"
        f"{recap_source}\n"
        f"[END LAST SESSION — you remember this. If Dean asks 'what were we "
        f"working on', you know. If you need more detail, use knowledge_search "
        f"or file_read the journal files in brain_state/journals/.]"
    )

    # Save recap to disk so it persists
    try:
        with open(_RECAP_PATH, "w", encoding="utf-8") as f:
            f.write(recap)
    except Exception:
        pass

    return recap


def get_last_recap() -> str:
    """Load the last saved recap from disk (for prompt injection on boot)."""
    try:
        if os.path.exists(_RECAP_PATH):
            with open(_RECAP_PATH, "r", encoding="utf-8") as f:
                return f.read().strip()
    except Exception:
        pass
    return ""


def cleanup_old_journals(keep_days: int = 30):
    """Remove journal files older than keep_days."""
    _ensure_journals_dir()
    cutoff = time.time() - (keep_days * 86400)
    removed = 0
    for f in os.listdir(_JOURNALS_DIR):
        path = os.path.join(_JOURNALS_DIR, f)
        try:
            if os.path.getmtime(path) < cutoff:
                os.unlink(path)
                removed += 1
        except Exception:
            pass
    if removed:
        print(f"[JOURNAL] cleaned up {removed} old journal files")
