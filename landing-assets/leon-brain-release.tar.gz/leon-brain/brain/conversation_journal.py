"""
Conversation Journal — readable transcript files + session recaps.

Solves: Leon's conversations exist only in SQLite. When he restarts, he has
no readable record to browse. A human can flip through a journal; Leon should
be able to too.

Two functions:
1. save_session_transcript() — writes the current session's conversation to a
   dated markdown file in brain_state/journals/. Called on shutdown and
   periodically (every 30 min). Leon can file_read these anytime.

2. generate_session_recap() — summarizes the last session into a short text
   block. Called on boot, injected into the prompt so Leon immediately knows
   what happened last time.

Journal files: brain_state/journals/YYYY-MM-DD_HH-MM.md
Recap file:    brain_state/last_session_recap.md
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from datetime import datetime
from typing import List, Optional, Tuple


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_JOURNALS_DIR = os.path.join(_ROOT, "brain_state", "journals")
_RECAP_PATH = os.path.join(_ROOT, "brain_state", "last_session_recap.md")
_DB = os.path.join(_ROOT, "brain_state", "knowledge.db")


def _ensure_journals_dir():
    os.makedirs(_JOURNALS_DIR, exist_ok=True)


def _load_recent_turns(db_path: str = _DB, limit: int = 500) -> List[Tuple[str, str, float]]:
    """Load recent conversation turns as (role, content, timestamp)."""
    try:
        conn = sqlite3.connect(db_path, timeout=10)
        rows = conn.execute(
            "SELECT role, content, ts FROM conversation_history "
            "WHERE model != 'proactive' "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        rows.reverse()  # chronological
        return [(r[0], r[1], r[2]) for r in rows]
    except Exception as e:
        print(f"[JOURNAL] failed to load turns: {e}")
        return []


def _normalize_content(content: str) -> str:
    """Convert __BLOCKS__ format to readable text."""
    if not content:
        return ""
    if not content.startswith("__BLOCKS__"):
        return content
    try:
        blocks = json.loads(content[len("__BLOCKS__"):])
    except Exception:
        return content
    parts = []
    for b in blocks:
        if not isinstance(b, dict):
            continue
        t = b.get("type")
        if t == "text":
            parts.append(b.get("text", ""))
        elif t == "tool_use":
            name = b.get("name", "?")
            parts.append(f"[used tool: {name}]")
        elif t == "tool_result":
            inner = b.get("content")
            if isinstance(inner, str):
                parts.append(f"[tool result: {inner[:150]}]")
            elif isinstance(inner, list):
                for sub in inner:
                    if isinstance(sub, dict) and sub.get("type") == "text":
                        parts.append(f"[tool result: {sub.get('text', '')[:150]}]")
    return "\n".join(p for p in parts if p).strip()


def save_session_transcript(db_path: str = _DB, limit: int = 500) -> Optional[str]:
    """Save the current session's conversation to a dated markdown file.
    Returns the file path, or None on failure."""
    _ensure_journals_dir()
    turns = _load_recent_turns(db_path, limit)
    if not turns:
        return None

    # Use the first turn's timestamp for the filename
    first_ts = turns[0][2] if turns[0][2] else time.time()
    dt = datetime.fromtimestamp(first_ts)
    filename = dt.strftime("%Y-%m-%d_%H-%M") + ".md"
    filepath = os.path.join(_JOURNALS_DIR, filename)

    # Don't overwrite — append new turns if file exists
    lines = [f"# Conversation Journal — {dt.strftime('%Y-%m-%d %H:%M')}\n"]

    current_date = ""
    for role, raw_content, ts in turns:
        content = _normalize_content(raw_content)
        if not content or len(content.strip()) < 3:
            continue

        turn_dt = datetime.fromtimestamp(ts) if ts else dt
        date_str = turn_dt.strftime("%Y-%m-%d")
        if date_str != current_date:
            current_date = date_str
            lines.append(f"\n## {date_str}\n")

        time_str = turn_dt.strftime("%H:%M")
        speaker = "Dean" if role == "user" else "Leon"
        # Truncate very long turns
        if len(content) > 2000:
            content = content[:2000] + "\n[...truncated]"
        lines.append(f"**{time_str} {speaker}:** {content}\n")

    try:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"[JOURNAL] saved transcript: {filepath} ({len(turns)} turns)")
        return filepath
    except Exception as e:
        print(f"[JOURNAL] save failed: {e}")
        return None


_TURN_RE = re.compile(r"^\*\*(\d{1,2}:\d{2})\s+([^:*]+):\*\*\s*(.*)$")


def _parse_journal_turns(text: str) -> Tuple[str, List[Tuple[str, str, str]]]:
    """Split a journal into (header, [(time, speaker, body), ...]).

    Header is everything before the first turn marker (title + date headings).
    Unparseable text before the first turn is preserved; date headings that
    appear mid-file are folded into the following turn's body-free position by
    being attached to the header of that turn as a speaker of '_meta'.
    """
    header_lines: List[str] = []
    turns: List[List[str]] = []
    for line in text.splitlines():
        m = _TURN_RE.match(line)
        if m:
            turns.append([m.group(1), m.group(2).strip(), m.group(3)])
        elif turns:
            turns[-1][2] += "\n" + line
        else:
            header_lines.append(line)
    return "\n".join(header_lines).strip(), [(t[0], t[1], t[2].strip()) for t in turns]


def _first_sentences(body: str, limit: int) -> str:
    """Take whole sentences up to `limit` chars, never cutting mid-word."""
    body = " ".join(body.split())
    if len(body) <= limit:
        return body
    cut = body[:limit]
    for sep in (". ", "? ", "! "):
        idx = cut.rfind(sep)
        if idx > limit * 0.4:
            return cut[: idx + 1]
    space = cut.rfind(" ")
    return (cut[:space] if space > 0 else cut) + "…"


def _compress_recap(text: str, budget: int) -> str:
    """Fit a journal into `budget` bytes without blind truncation.

    The old behaviour was `text[-40KB:]` — a raw tail chop. That kept whatever
    happened to be last (often a long low-value reply) and silently threw away
    every earlier turn, including the ones that set up the work. Instead:

      * the most recent turns are kept VERBATIM (recency matters most),
      * older turns are COMPRESSED rather than dropped — Dean's messages are
        the intent and survive at higher fidelity than Leon's own replies,
      * only if still over budget do the oldest compressed turns fall off.

    Deterministic and offline: no model call, so a recap costs nothing.
    """
    if len(text) <= budget:
        return text

    header, turns = _parse_journal_turns(text)
    if not turns:
        # Not a journal we understand — fall back to a line-aligned tail.
        tail = text[-budget:]
        nl = tail.find("\n")
        return "[...older context omitted for space...]\n" + (tail[nl + 1:] if nl > 0 else tail)

    verbatim_budget = int(budget * 0.6)
    verbatim: List[str] = []
    used = 0
    split_at = len(turns)
    for i in range(len(turns) - 1, -1, -1):
        t, who, body = turns[i]
        block = f"**{t} {who}:** {body}"
        if used + len(block) > verbatim_budget and verbatim:
            break
        verbatim.insert(0, block)
        used += len(block) + 2
        split_at = i

    # Compress everything older than the verbatim window.
    compressed: List[str] = []
    for t, who, body in turns[:split_at]:
        is_dean = who.lower().startswith("dean") or who.lower() == "you"
        limit = 240 if is_dean else 150
        line = _first_sentences(body, limit)
        if not line:
            continue
        compressed.append(f"{t} {who}: {line}")

    # Drop oldest compressed lines until the whole thing fits.
    remaining = budget - used - len(header) - 200
    while compressed and sum(len(c) + 1 for c in compressed) > max(remaining, 0):
        compressed.pop(0)

    parts = []
    if header:
        parts.append(header)
    if compressed:
        parts.append(
            "[EARLIER IN THIS SESSION — condensed, oldest first:]\n" + "\n".join(compressed)
        )
    parts.append("[MOST RECENT — verbatim:]\n" + "\n\n".join(verbatim))
    return "\n\n".join(parts)


def generate_session_recap(db_path: str = _DB) -> str:
    """Generate a short recap of the last session for injection into the boot prompt.
    Reads from the most recent journal file OR from conversation history directly."""

    # Try to read the most recent journal file
    _ensure_journals_dir()
    journals = sorted(
        [f for f in os.listdir(_JOURNALS_DIR) if f.endswith(".md")],
        reverse=True,
    )

    recap_source = ""
    if journals:
        try:
            with open(os.path.join(_JOURNALS_DIR, journals[0]), "r", encoding="utf-8") as f:
                recap_source = f.read()
        except Exception:
            pass

    # Fallback: read directly from conversation history
    if not recap_source:
        turns = _load_recent_turns(db_path, limit=100)
        if turns:
            parts = []
            for role, raw_content, ts in turns[-50:]:  # last 50 turns
                content = _normalize_content(raw_content)
                if not content or len(content.strip()) < 10:
                    continue
                speaker = "Dean" if role == "user" else "Leon"
                parts.append(f"{speaker}: {content[:300]}")
            recap_source = "\n".join(parts)

    if not recap_source:
        return ""

    # Condense rather than truncate. 24KB instead of 40KB: the summarizer
    # keeps far more actual information per byte than a raw tail did.
    MAX_JOURNAL = 24 * 1024
    recap_source = _compress_recap(recap_source, MAX_JOURNAL)

    recap = (
        f"[LAST SESSION — here's what you and Dean were doing recently. "
        f"This is your memory of it, not a transcript to read aloud:]\n"
        f"{recap_source}\n"
        f"[END LAST SESSION — you remember this. If Dean asks 'what were we "
        f"working on', you know. If you need more detail, use knowledge_search "
        f"or file_read the journal files in brain_state/journals/.]"
    )

    # Save recap to disk so it persists
    try:
        with open(_RECAP_PATH, "w", encoding="utf-8") as f:
            f.write(recap)
    except Exception:
        pass

    return recap


def get_last_recap() -> str:
    """Load the last saved recap from disk (for prompt injection on boot)."""
    try:
        if os.path.exists(_RECAP_PATH):
            with open(_RECAP_PATH, "r", encoding="utf-8") as f:
                return f.read().strip()
    except Exception:
        pass
    return ""


def cleanup_old_journals(keep_days: int = 30):
    """Remove journal files older than keep_days."""
    _ensure_journals_dir()
    cutoff = time.time() - (keep_days * 86400)
    removed = 0
    for f in os.listdir(_JOURNALS_DIR):
        path = os.path.join(_JOURNALS_DIR, f)
        try:
            if os.path.getmtime(path) < cutoff:
                os.unlink(path)
                removed += 1
        except Exception:
            pass
    if removed:
        print(f"[JOURNAL] cleaned up {removed} old journal files")
