"""
memory_extras.py — Leon's memory & relationship tool surface.

This module gives Leon the ability to REMEMBER Dean across sessions:
people he knows, decisions he's made, preferences he holds, jargon he
uses, beliefs he's corrected, episodic events, mood snapshots, and a
free-form USER.md profile.

All tools share the same {ok, result|error} contract used by the
Leon actuator (`leon-actuator/tools_extra.py`), but unlike that module
these tools DO NOT cross the actuator socket. They operate on the
brain's local SQLite stores directly:

  - brain_state/memory.db      — relationships, decisions, preferences,
                                 glossary, corrections, episodes, mood log
                                 (auto-created on first call)
  - brain_state/knowledge.db   — existing TF-IDF KnowledgeStore, wrapped
                                 by `knowledge_*` tools
  - USER.md (project root)     — Dean's free-form profile in Markdown

Each tool is a function taking a single `args` dict and returning either
`{"ok": True, "result": ...}` or `{"ok": False, "error": "..."}`. The
EXTRA_TOOLS dict at the bottom maps dotted tool names (e.g.
`memory.relationship_add`) to the implementing function — import this
dict from the responder / MCP server to register them in one shot.
"""

from __future__ import annotations

import os
import re
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# PATHS & CONNECTIONS
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/). Used to locate brain_state/
    and USER.md regardless of where the file is imported from."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _memory_db_path() -> str:
    brain_state_dir = os.path.join(_project_root(), "brain_state")
    os.makedirs(brain_state_dir, exist_ok=True)
    return os.path.join(brain_state_dir, "memory.db")


def _user_md_path() -> str:
    return os.path.join(_project_root(), "USER.md")


# Lazy shared connection + lock. We use check_same_thread=False so the
# same connection can be used from responder threads. All writes are
# guarded by `_MEM_LOCK` so we don't race on commits.
_MEM_CONN: Optional[sqlite3.Connection] = None
_MEM_LOCK = threading.Lock()
_KNOWLEDGE_STORE = None  # cached KnowledgeStore instance


_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS people (
    name TEXT PRIMARY KEY,
    role TEXT,
    context TEXT,
    last_interaction_ts REAL,
    interaction_count INTEGER DEFAULT 0,
    notes TEXT,
    created_ts REAL DEFAULT (strftime('%s','now')),
    updated_ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT,
    decision TEXT,
    reason TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT,
    preference TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS glossary (
    term TEXT PRIMARY KEY,
    definition TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS corrections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wrong_belief TEXT,
    correct_belief TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS episodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event TEXT,
    location TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
CREATE TABLE IF NOT EXISTS mood_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dopamine REAL,
    serotonin REAL,
    norepinephrine REAL,
    acetylcholine REAL,
    note TEXT,
    ts REAL DEFAULT (strftime('%s','now'))
);
"""


def _mem_conn() -> sqlite3.Connection:
    """Get the lazy SQLite connection to memory.db. Creates the file
    and schema on first call."""
    global _MEM_CONN
    if _MEM_CONN is not None:
        return _MEM_CONN
    with _MEM_LOCK:
        if _MEM_CONN is not None:
            return _MEM_CONN
        conn = sqlite3.connect(
            _memory_db_path(),
            timeout=30,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        # Apply schema
        conn.executescript(_SCHEMA_SQL)
        conn.commit()
        _MEM_CONN = conn
    return _MEM_CONN


def _knowledge_store():
    """Lazy-import + cache the existing KnowledgeStore. Defaults to
    the canonical brain_state/knowledge.db location."""
    global _KNOWLEDGE_STORE
    if _KNOWLEDGE_STORE is not None:
        return _KNOWLEDGE_STORE
    from brain.knowledge_store import KnowledgeStore  # noqa: WPS433
    _KNOWLEDGE_STORE = KnowledgeStore()
    return _KNOWLEDGE_STORE


def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Convert a sqlite3.Row to a plain dict (sqlite3.Row isn't
    JSON-serializable on its own)."""
    if row is None:
        return None
    return {k: row[k] for k in row.keys()}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


# ──────────────────────────────────────────────────────────────────────────
# PEOPLE / RELATIONSHIPS
# ──────────────────────────────────────────────────────────────────────────


def relationship_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """INSERT OR REPLACE a person into the people table. Returns the
    full row that was stored."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    role = args.get("role")
    context = args.get("context")
    notes = args.get("notes")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            now = time.time()
            conn.execute(
                """
                INSERT INTO people (name, role, context, notes, created_ts, updated_ts)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET
                    role = excluded.role,
                    context = excluded.context,
                    notes = excluded.notes,
                    updated_ts = excluded.updated_ts
                """,
                (name, role, context, notes, now, now),
            )
            conn.commit()
            cur = conn.execute("SELECT * FROM people WHERE name = ?", (name,))
            row = cur.fetchone()
        return _ok(_row_to_dict(row))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def relationship_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update only the fields provided on an existing person. Bumps
    `updated_ts`. Returns the resulting row, or an error if the person
    doesn't exist yet."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    fields: List[Tuple[str, Any]] = []
    for key in ("role", "context", "notes"):
        if key in args and args[key] is not None:
            fields.append((key, args[key]))
    if not fields:
        return _err("at least one of role / context / notes is required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute("SELECT 1 FROM people WHERE name = ?", (name,))
            if cur.fetchone() is None:
                return _err(f"no person named {name!r}; use relationship_add first")
            sets = ", ".join(f"{k} = ?" for k, _ in fields)
            params = [v for _, v in fields] + [time.time(), name]
            conn.execute(
                f"UPDATE people SET {sets}, updated_ts = ? WHERE name = ?",
                params,
            )
            conn.commit()
            cur = conn.execute("SELECT * FROM people WHERE name = ?", (name,))
            row = cur.fetchone()
        return _ok(_row_to_dict(row))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def relationship_recall(args: Dict[str, Any]) -> Dict[str, Any]:
    """Look up a person by exact name. Also returns the last 5 knowledge
    entries that mention them (case-insensitive LIKE on text+tags)."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute("SELECT * FROM people WHERE name = ?", (name,))
            person = _row_to_dict(cur.fetchone())
        if person is None:
            # Try a case-insensitive fallback so "dean" finds "Dean"
            with _MEM_LOCK:
                cur = conn.execute(
                    "SELECT * FROM people WHERE LOWER(name) = LOWER(?)",
                    (name,),
                )
                person = _row_to_dict(cur.fetchone())
        # Pull the last 5 knowledge entries that mention this name
        related: List[Dict[str, Any]] = []
        try:
            ks = _knowledge_store()
            related = ks.search(name, limit=5) or []
        except Exception as e:
            related = [{"_error": f"knowledge search failed: {e}"}]
        return _ok({"person": person, "related_knowledge": related})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def relationship_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List people, optionally filtered by role. Sorted by last
    interaction (most recent first), tie-broken by name."""
    try:
        limit = int(args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    role = args.get("role")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            if role:
                cur = conn.execute(
                    """
                    SELECT * FROM people
                    WHERE LOWER(role) = LOWER(?)
                    ORDER BY COALESCE(last_interaction_ts, 0) DESC, name ASC
                    LIMIT ?
                    """,
                    (role, limit),
                )
            else:
                cur = conn.execute(
                    """
                    SELECT * FROM people
                    ORDER BY COALESCE(last_interaction_ts, 0) DESC, name ASC
                    LIMIT ?
                    """,
                    (limit,),
                )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"count": len(rows), "people": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def relationship_log_interaction(args: Dict[str, Any]) -> Dict[str, Any]:
    """Record that Dean just interacted with a person. Increments
    interaction_count, bumps last_interaction_ts, and appends an
    optional note onto the notes column (line-separated)."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    note = args.get("note")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute("SELECT notes FROM people WHERE name = ?", (name,))
            row = cur.fetchone()
            if row is None:
                # Auto-create a minimal person row so logging never fails silently
                now = time.time()
                conn.execute(
                    """
                    INSERT INTO people
                        (name, last_interaction_ts, interaction_count, notes, created_ts, updated_ts)
                    VALUES (?, ?, 1, ?, ?, ?)
                    """,
                    (name, now, note or "", now, now),
                )
                conn.commit()
                cur = conn.execute("SELECT * FROM people WHERE name = ?", (name,))
                new_row = _row_to_dict(cur.fetchone())
                return _ok({"created": True, "person": new_row})

            existing_notes = row["notes"] or ""
            if note:
                stamp = time.strftime("%Y-%m-%d %H:%M")
                combined = f"{existing_notes}\n[{stamp}] {note}".strip()
            else:
                combined = existing_notes
            now = time.time()
            conn.execute(
                """
                UPDATE people SET
                    interaction_count = COALESCE(interaction_count, 0) + 1,
                    last_interaction_ts = ?,
                    notes = ?,
                    updated_ts = ?
                WHERE name = ?
                """,
                (now, combined, now, name),
            )
            conn.commit()
            cur = conn.execute("SELECT * FROM people WHERE name = ?", (name,))
            updated = _row_to_dict(cur.fetchone())
        return _ok({"created": False, "person": updated})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def relationship_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """LIKE search across name / role / context / notes."""
    query = (args.get("query") or "").strip()
    if not query:
        return _err("query is required")
    try:
        limit = int(args.get("limit") or 10)
    except (TypeError, ValueError):
        limit = 10
    pattern = f"%{query}%"
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                SELECT * FROM people
                WHERE name LIKE ?
                   OR role LIKE ?
                   OR context LIKE ?
                   OR notes LIKE ?
                ORDER BY COALESCE(last_interaction_ts, 0) DESC, name ASC
                LIMIT ?
                """,
                (pattern, pattern, pattern, pattern, limit),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"query": query, "count": len(rows), "people": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# DECISIONS
# ──────────────────────────────────────────────────────────────────────────


def decision_log(args: Dict[str, Any]) -> Dict[str, Any]:
    """Record a decision Dean made (topic + decision + optional reason)."""
    topic = (args.get("topic") or "").strip()
    decision = (args.get("decision") or "").strip()
    if not topic or not decision:
        return _err("topic and decision are required")
    reason = args.get("reason")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "INSERT INTO decisions (topic, decision, reason) VALUES (?, ?, ?)",
                (topic, decision, reason),
            )
            conn.commit()
            new_id = cur.lastrowid
            cur = conn.execute("SELECT * FROM decisions WHERE id = ?", (new_id,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def decision_recall(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find decisions whose topic contains a substring (case-insensitive)."""
    needle = (args.get("topic_substring") or args.get("query") or "").strip()
    if not needle:
        return _err("topic_substring is required")
    try:
        limit = int(args.get("limit") or 10)
    except (TypeError, ValueError):
        limit = 10
    pattern = f"%{needle}%"
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                SELECT * FROM decisions
                WHERE topic LIKE ? OR decision LIKE ? OR reason LIKE ?
                ORDER BY ts DESC
                LIMIT ?
                """,
                (pattern, pattern, pattern, limit),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"query": needle, "count": len(rows), "decisions": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def decision_list_recent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return the most recent N decisions."""
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "SELECT * FROM decisions ORDER BY ts DESC LIMIT ?",
                (limit,),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"count": len(rows), "decisions": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# PREFERENCES
# ──────────────────────────────────────────────────────────────────────────


def preference_log(args: Dict[str, Any]) -> Dict[str, Any]:
    """Record a preference under a category (e.g. category='ui',
    preference='cyan #00ffc8 is the brand color')."""
    category = (args.get("category") or "").strip()
    pref = (args.get("preference") or "").strip()
    if not category or not pref:
        return _err("category and preference are required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "INSERT INTO preferences (category, preference) VALUES (?, ?)",
                (category, pref),
            )
            conn.commit()
            new_id = cur.lastrowid
            cur = conn.execute("SELECT * FROM preferences WHERE id = ?", (new_id,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def preference_recall(args: Dict[str, Any]) -> Dict[str, Any]:
    """List preferences within a category (case-insensitive match)."""
    category = (args.get("category") or "").strip()
    if not category:
        return _err("category is required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                SELECT * FROM preferences
                WHERE LOWER(category) = LOWER(?)
                ORDER BY ts DESC
                """,
                (category,),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"category": category, "count": len(rows), "preferences": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def preference_list_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """List every preference, grouped by category."""
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "SELECT * FROM preferences ORDER BY category ASC, ts DESC"
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            grouped.setdefault(r["category"] or "(uncategorized)", []).append(r)
        return _ok({
            "total": len(rows),
            "categories": sorted(grouped.keys()),
            "by_category": grouped,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# GLOSSARY
# ──────────────────────────────────────────────────────────────────────────


def glossary_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add/replace a glossary term. Terms are case-sensitive primary keys
    but lookups below are case-insensitive substring matches."""
    term = (args.get("term") or "").strip()
    definition = (args.get("definition") or "").strip()
    if not term or not definition:
        return _err("term and definition are required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            conn.execute(
                """
                INSERT INTO glossary (term, definition) VALUES (?, ?)
                ON CONFLICT(term) DO UPDATE SET
                    definition = excluded.definition,
                    ts = strftime('%s','now')
                """,
                (term, definition),
            )
            conn.commit()
            cur = conn.execute("SELECT * FROM glossary WHERE term = ?", (term,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def glossary_lookup(args: Dict[str, Any]) -> Dict[str, Any]:
    """Look up a term — case-insensitive substring match against the
    term column. Returns up to 25 hits."""
    term = (args.get("term") or "").strip()
    if not term:
        return _err("term is required")
    pattern = f"%{term}%"
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                SELECT * FROM glossary
                WHERE term LIKE ? COLLATE NOCASE
                   OR definition LIKE ? COLLATE NOCASE
                ORDER BY
                    CASE WHEN LOWER(term) = LOWER(?) THEN 0 ELSE 1 END,
                    ts DESC
                LIMIT 25
                """,
                (pattern, pattern, term),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"query": term, "count": len(rows), "entries": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def glossary_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List glossary terms, most recently added first."""
    try:
        limit = int(args.get("limit") or 100)
    except (TypeError, ValueError):
        limit = 100
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "SELECT * FROM glossary ORDER BY ts DESC LIMIT ?",
                (limit,),
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"count": len(rows), "entries": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# CORRECTIONS  ("no, Leon — X is wrong, Y is right")
# ──────────────────────────────────────────────────────────────────────────


def correction_log(args: Dict[str, Any]) -> Dict[str, Any]:
    wrong = (args.get("wrong_belief") or "").strip()
    right = (args.get("correct_belief") or "").strip()
    if not wrong or not right:
        return _err("wrong_belief and correct_belief are required")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "INSERT INTO corrections (wrong_belief, correct_belief) VALUES (?, ?)",
                (wrong, right),
            )
            conn.commit()
            new_id = cur.lastrowid
            cur = conn.execute("SELECT * FROM corrections WHERE id = ?", (new_id,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def correction_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List corrections, optionally filtered by a substring."""
    try:
        limit = int(args.get("limit") or 20)
    except (TypeError, ValueError):
        limit = 20
    search = (args.get("search") or "").strip()
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            if search:
                pattern = f"%{search}%"
                cur = conn.execute(
                    """
                    SELECT * FROM corrections
                    WHERE wrong_belief LIKE ? OR correct_belief LIKE ?
                    ORDER BY ts DESC
                    LIMIT ?
                    """,
                    (pattern, pattern, limit),
                )
            else:
                cur = conn.execute(
                    "SELECT * FROM corrections ORDER BY ts DESC LIMIT ?",
                    (limit,),
                )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({"count": len(rows), "corrections": rows})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# EPISODES  (timestamped events — "Dean met X at Y", "deploy went out")
# ──────────────────────────────────────────────────────────────────────────


def episode_log(args: Dict[str, Any]) -> Dict[str, Any]:
    event = (args.get("event") or "").strip()
    if not event:
        return _err("event is required")
    location = args.get("location")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                "INSERT INTO episodes (event, location) VALUES (?, ?)",
                (event, location),
            )
            conn.commit()
            new_id = cur.lastrowid
            cur = conn.execute("SELECT * FROM episodes WHERE id = ?", (new_id,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _parse_iso(s: Optional[str]) -> Optional[float]:
    """Parse an ISO-8601-ish string into a unix timestamp. Returns
    None on falsy input. Raises ValueError for unparseable strings."""
    if not s:
        return None
    import datetime as _dt
    s = s.strip()
    # Strip trailing 'Z' (fromisoformat doesn't accept it pre-3.11 universally)
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = _dt.datetime.fromisoformat(s)
    except ValueError:
        # Fallback: date-only "YYYY-MM-DD"
        dt = _dt.datetime.strptime(s, "%Y-%m-%d")
    return dt.timestamp()


def episode_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search episodes by free-text query and/or a time range. All
    parameters optional — with none, returns the most recent episodes."""
    query = (args.get("query") or "").strip()
    since_iso = args.get("since_iso")
    until_iso = args.get("until_iso")
    try:
        limit = int(args.get("limit") or 30)
    except (TypeError, ValueError):
        limit = 30
    try:
        since_ts = _parse_iso(since_iso)
        until_ts = _parse_iso(until_iso)
    except Exception as e:
        return _err(f"bad ISO timestamp: {e}")

    where: List[str] = []
    params: List[Any] = []
    if query:
        where.append("(event LIKE ? OR location LIKE ?)")
        params.extend([f"%{query}%", f"%{query}%"])
    if since_ts is not None:
        where.append("ts >= ?")
        params.append(since_ts)
    if until_ts is not None:
        where.append("ts <= ?")
        params.append(until_ts)
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    params.append(limit)
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                f"SELECT * FROM episodes {where_sql} ORDER BY ts DESC LIMIT ?",
                params,
            )
            rows = [_row_to_dict(r) for r in cur.fetchall()]
        return _ok({
            "query": query or None,
            "since_iso": since_iso,
            "until_iso": until_iso,
            "count": len(rows),
            "episodes": rows,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# MOOD LOG
# ──────────────────────────────────────────────────────────────────────────


def mood_log_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Insert a neuromodulator snapshot. All four levels are required
    (any can be float-cast); `note` is optional."""
    required = ("dopamine", "serotonin", "norepinephrine", "acetylcholine")
    vals: Dict[str, float] = {}
    for k in required:
        if k not in args or args[k] is None:
            return _err(f"{k} is required")
        try:
            vals[k] = float(args[k])
        except (TypeError, ValueError):
            return _err(f"{k} must be numeric, got {args[k]!r}")
    note = args.get("note")
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                INSERT INTO mood_log
                    (dopamine, serotonin, norepinephrine, acetylcholine, note)
                VALUES (?, ?, ?, ?, ?)
                """,
                (vals["dopamine"], vals["serotonin"],
                 vals["norepinephrine"], vals["acetylcholine"], note),
            )
            conn.commit()
            new_id = cur.lastrowid
            cur = conn.execute("SELECT * FROM mood_log WHERE id = ?", (new_id,))
            row = _row_to_dict(cur.fetchone())
        return _ok(row)
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _trend_label(first: float, last: float, eps: float = 0.02) -> str:
    """Classify a trend by comparing the earliest day's average to the
    latest day's average. Small deltas count as 'stable'."""
    if last - first > eps:
        return "increasing"
    if first - last > eps:
        return "decreasing"
    return "stable"


def mood_recent_trend(args: Dict[str, Any]) -> Dict[str, Any]:
    """Aggregate mood_log over the last N days. Returns one row per
    day (UTC date string) and an overall trend label per neuromodulator
    based on first-vs-last day averages."""
    try:
        days = int(args.get("days") or 7)
    except (TypeError, ValueError):
        days = 7
    if days <= 0:
        return _err("days must be positive")
    since_ts = time.time() - (days * 86400)
    try:
        conn = _mem_conn()
        with _MEM_LOCK:
            cur = conn.execute(
                """
                SELECT
                    date(ts, 'unixepoch') AS day,
                    AVG(dopamine)         AS dopamine,
                    AVG(serotonin)        AS serotonin,
                    AVG(norepinephrine)   AS norepinephrine,
                    AVG(acetylcholine)    AS acetylcholine,
                    COUNT(*)              AS samples
                FROM mood_log
                WHERE ts >= ?
                GROUP BY day
                ORDER BY day ASC
                """,
                (since_ts,),
            )
            per_day = [_row_to_dict(r) for r in cur.fetchall()]
        if not per_day:
            return _ok({
                "days": days,
                "per_day": [],
                "trend": {},
                "samples": 0,
            })
        first, last = per_day[0], per_day[-1]
        trend = {
            nm: _trend_label(first[nm] or 0.0, last[nm] or 0.0)
            for nm in ("dopamine", "serotonin", "norepinephrine", "acetylcholine")
        }
        total_samples = sum(d["samples"] for d in per_day)
        return _ok({
            "days": days,
            "per_day": per_day,
            "trend": trend,
            "samples": total_samples,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# KNOWLEDGE STORE WRAPPERS  (operate on the existing knowledge.db)
# ──────────────────────────────────────────────────────────────────────────


def knowledge_add(args: Dict[str, Any]) -> Dict[str, Any]:
    """Add an entry to the existing TF-IDF KnowledgeStore.
    Accepts text, optional source, tags (list), and an optional initial
    strength (clamped to KnowledgeStore's normal 0-5 range after write)."""
    text = (args.get("text") or "").strip()
    if not text:
        return _err("text is required")
    source = args.get("source") or "leon-memory"
    tags = args.get("tags")
    if tags is not None and not isinstance(tags, list):
        return _err("tags must be a list of strings")
    strength = args.get("strength")
    try:
        ks = _knowledge_store()
        entry_id = ks.store(text, source=source, tags=tags)
        if entry_id is None or entry_id < 0:
            return _err("store rejected the entry (empty after strip?)")
        # Optional strength override — write directly since `store()` always
        # initializes strength to 1.0.
        if strength is not None:
            try:
                s = float(strength)
            except (TypeError, ValueError):
                return _err(f"strength must be numeric, got {strength!r}")
            s = max(0.0, min(5.0, s))
            with ks._lock:  # reuse the store's own lock
                conn = sqlite3.connect(ks.db_path, timeout=30)
                conn.execute(
                    "UPDATE knowledge SET strength = ? WHERE id = ?",
                    (s, entry_id),
                )
                conn.commit()
                conn.close()
        return _ok({"id": entry_id, "source": source, "tags": tags or []})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def knowledge_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    """Delete a knowledge entry by id. HIGH-RISK — irreversible.
    The caller is expected to confirm before invoking."""
    entry_id = args.get("id")
    if entry_id is None:
        return _err("id is required")
    try:
        entry_id = int(entry_id)
    except (TypeError, ValueError):
        return _err(f"id must be an integer, got {entry_id!r}")
    try:
        ks = _knowledge_store()
        deleted = ks.delete(entry_id)
        return _ok({"id": entry_id, "deleted": bool(deleted)})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def knowledge_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update text and/or tags on an existing knowledge row. Note:
    this does NOT re-tokenize the entry — TF-IDF results for the
    updated row will still reflect its original tokens. For full
    re-tokenization, delete + re-add."""
    entry_id = args.get("id")
    if entry_id is None:
        return _err("id is required")
    try:
        entry_id = int(entry_id)
    except (TypeError, ValueError):
        return _err(f"id must be an integer, got {entry_id!r}")
    text = args.get("text")
    tags = args.get("tags")
    if text is None and tags is None:
        return _err("at least one of text / tags is required")
    if tags is not None and not isinstance(tags, list):
        return _err("tags must be a list of strings")
    sets: List[str] = []
    params: List[Any] = []
    if text is not None:
        sets.append("text = ?")
        params.append(str(text).strip())
    if tags is not None:
        sets.append("tags = ?")
        params.append(",".join(str(t) for t in tags))
    params.append(entry_id)
    try:
        ks = _knowledge_store()
        with ks._lock:
            conn = sqlite3.connect(ks.db_path, timeout=30)
            cur = conn.execute(
                f"UPDATE knowledge SET {', '.join(sets)} WHERE id = ?",
                params,
            )
            updated = cur.rowcount
            conn.commit()
            conn.close()
        if updated == 0:
            return _err(f"no knowledge entry with id={entry_id}")
        return _ok({"id": entry_id, "updated_fields": [s.split(" = ")[0] for s in sets]})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def knowledge_stats(args: Dict[str, Any]) -> Dict[str, Any]:
    """Total knowledge count, count by source, top 20 tags by frequency.
    Wraps KnowledgeStore.get_stats() but reshapes for tool consumption."""
    try:
        ks = _knowledge_store()
        stats = ks.get_stats() or {}
        # `tags` field is already sorted desc, top 20 — keep as-is.
        return _ok({
            "total": stats.get("total_entries", 0),
            "by_source": stats.get("sources", {}),
            "unique_sources": stats.get("unique_sources", 0),
            "top_tags": stats.get("tags", [])[:20],
            "first_entry_ts": stats.get("first_entry"),
            "last_entry_ts": stats.get("last_entry"),
            "db_path": stats.get("db_path"),
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# USER.md  (Dean's personal profile, free-form Markdown)
# ──────────────────────────────────────────────────────────────────────────


_DEFAULT_USER_MD_SECTIONS = [
    "Bio",
    "Goals",
    "Current Focus",
    "Relationships",
    "Preferences",
    "Projects",
    "Off-Limits",
]


def _default_user_md() -> str:
    """Stub USER.md created the first time `user_profile_update` is
    called on a fresh project."""
    lines = ["# USER", "", "Dean's personal profile. Leon reads this on boot.", ""]
    for sec in _DEFAULT_USER_MD_SECTIONS:
        lines.append(f"## {sec}")
        lines.append("")
        lines.append("_(empty)_")
        lines.append("")
    return "\n".join(lines)


def user_profile_get(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read USER.md from the project root. Returns the raw Markdown
    plus the file path. If the file doesn't exist, returns ok=True
    with content=None so callers can branch on absence."""
    path = _user_md_path()
    try:
        if not os.path.exists(path):
            return _ok({"path": path, "exists": False, "content": None})
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        return _ok({"path": path, "exists": True, "content": content})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _split_user_md_sections(md: str) -> List[Tuple[str, str, str]]:
    """Split a USER.md into (heading_line, name, body) tuples in order.
    `heading_line` is the literal `## Whatever` line (preserved for
    round-tripping); `name` is the trimmed heading text; `body` is
    everything until the next `## ` (including the trailing newline).

    Content above the first `## ` heading is returned as a leading
    tuple with heading_line="" and name="" — preserved verbatim."""
    sections: List[Tuple[str, str, str]] = []
    pattern = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
    matches = list(pattern.finditer(md))
    if not matches:
        sections.append(("", "", md))
        return sections
    # Preamble (anything before the first `## `)
    if matches[0].start() > 0:
        sections.append(("", "", md[:matches[0].start()]))
    for i, m in enumerate(matches):
        name = m.group(1).strip()
        heading_line = m.group(0)
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(md)
        body = md[start:end]
        # Strip leading blank line that always follows a `##` heading
        if body.startswith("\n"):
            body = body[1:]
        sections.append((heading_line, name, body))
    return sections


def _join_user_md_sections(sections: List[Tuple[str, str, str]]) -> str:
    parts: List[str] = []
    for heading_line, _name, body in sections:
        if heading_line:
            parts.append(heading_line)
            parts.append("")
            parts.append(body.rstrip("\n"))
            parts.append("")
        else:
            # preamble — preserve verbatim
            parts.append(body.rstrip("\n"))
            if body:
                parts.append("")
    out = "\n".join(parts).rstrip() + "\n"
    return out


def user_profile_update(args: Dict[str, Any]) -> Dict[str, Any]:
    """Update (or create) a section in USER.md identified by its `##`
    heading. If the file doesn't exist, it is created with sensible
    default sections (Bio, Goals, Current Focus, Relationships,
    Preferences, Projects, Off-Limits). If the section doesn't exist,
    it is appended at the end."""
    section = (args.get("section") or "").strip()
    content = args.get("content")
    if not section:
        return _err("section is required")
    if content is None:
        return _err("content is required (use empty string to clear)")
    content = str(content).rstrip() + "\n"
    path = _user_md_path()
    try:
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                f.write(_default_user_md())
        with open(path, "r", encoding="utf-8") as f:
            md = f.read()
        sections = _split_user_md_sections(md)

        # Find the section by case-insensitive name match
        found_idx = -1
        for i, (_hl, name, _body) in enumerate(sections):
            if name and name.lower() == section.lower():
                found_idx = i
                break
        if found_idx >= 0:
            old_hl, old_name, _old_body = sections[found_idx]
            sections[found_idx] = (old_hl, old_name, content)
            action = "updated"
        else:
            sections.append((f"## {section}", section, content))
            action = "created"

        new_md = _join_user_md_sections(sections)
        with open(path, "w", encoding="utf-8") as f:
            f.write(new_md)
        return _ok({
            "path": path,
            "section": section,
            "action": action,
            "bytes": len(new_md),
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS = {
    "memory.relationship_add": relationship_add,
    "memory.relationship_update": relationship_update,
    "memory.relationship_recall": relationship_recall,
    "memory.relationship_list": relationship_list,
    "memory.relationship_log_interaction": relationship_log_interaction,
    "memory.relationship_search": relationship_search,
    "memory.decision_log": decision_log,
    "memory.decision_recall": decision_recall,
    "memory.decision_list_recent": decision_list_recent,
    "memory.preference_log": preference_log,
    "memory.preference_recall": preference_recall,
    "memory.preference_list_all": preference_list_all,
    "memory.glossary_add": glossary_add,
    "memory.glossary_lookup": glossary_lookup,
    "memory.glossary_list": glossary_list,
    "memory.correction_log": correction_log,
    "memory.correction_list": correction_list,
    "memory.episode_log": episode_log,
    "memory.episode_search": episode_search,
    "memory.mood_log_add": mood_log_add,
    "memory.mood_recent_trend": mood_recent_trend,
    "memory.knowledge_add": knowledge_add,
    "memory.knowledge_delete": knowledge_delete,
    "memory.knowledge_update": knowledge_update,
    "memory.knowledge_stats": knowledge_stats,
    "memory.user_profile_get": user_profile_get,
    "memory.user_profile_update": user_profile_update,
}
