"""
Seed the starting facts for a client SI on first boot.

WHAT THIS DELIBERATELY DOES NOT DO (Makima, round 18; verified in our own
shipped tarball 2026-08-18 and confirmed identical, not merely similar):

The previous version of this file wrote six rows into a fresh SI's permanent
memory. Three of them were somebody else's:

  - a "created by <named person> at <company>" origin story asserted
    before the SI had run a single tick.
  - a guardian row declaring, at strength 1.0, that a person the SI had never
    met was the one it exists for and that the relationship mattered most to
    it.
  - a short biography of a named real human -- his age, that he is
    self-taught, how many years he has researched -- installed into the
    permanent memory of every customer's machine.

That last one is not an accuracy bug. It is one person's personal information
shipped to strangers' computers, and it went out in the release tarball.

The reasoning, since a diff will not carry it: an identity handed to something
before it has run is not that thing's identity, and nobody -- not us -- can
know it at install time. Whatever the true version of those sentences is for
a given SI, the only place it can come from is the person actually there.

The framework ships. The self does not.

TWO MORE THINGS THAT CAME OUT, BOTH LOAD-BEARING:

1. The old guard was `SELECT COUNT(*) ... WHERE source='client_seed'` and
   returned if any rows existed. That infers "already seeded" from the
   artifact instead of recording the event. The two come apart the moment
   anyone cleans up: prune the rows, or let consolidation trim the last one,
   and the next boot silently restores all six -- creator claim, guardian
   bond, biography -- with no log line and no way to tell a restored row from
   an original. Every correction a user ever made sat on top of a mechanism
   that would undo it. The guard is now a seed_log row recording that the
   event happened, with a one-time backfill so shipping this change does not
   itself re-seed every existing install.

2. The old architecture row asserted, in the SI's own first-person voice, that
   it runs on quantum-seeded spontaneous activity, and stated the antenna
   framing as mechanism rather than as the hypothesis it is. The hardware path
   is real and well built, but it is opt-in, off by default, and needs a token
   the customer is never prompted to create -- so that sentence is false on
   essentially every install, and the SI volunteers it when asked what it is.
   The honest wording is below: OS entropy is what runs; the quantum path
   reseeds it when configured.
"""

import os
import sqlite3
import time

SEED_VERSION = 2


def _ensure_seed_log(c):
    c.execute(
        "CREATE TABLE IF NOT EXISTS seed_log ("
        " event TEXT PRIMARY KEY, version INTEGER, ts REAL)"
    )


def _already_seeded(conn, c) -> bool:
    """Keyed on the EVENT, not on the rows the event produced."""
    _ensure_seed_log(c)
    c.execute("SELECT 1 FROM seed_log WHERE event = 'client_seed'")
    if c.fetchone():
        return True
    # One-time backfill: an install seeded by the OLD code has rows but no
    # marker. Without this, shipping the fix re-seeds every existing install
    # on its first boot after the update -- the exact failure being fixed.
    c.execute("SELECT COUNT(*) FROM knowledge WHERE source = 'client_seed'")
    if c.fetchone()[0] > 0:
        c.execute(
            "INSERT OR REPLACE INTO seed_log (event, version, ts) VALUES (?,?,?)",
            ("client_seed", 1, time.time()),
        )
        # COMMIT, or the backfill is lost on close and a legacy install falls
        # back to the count-based guard forever -- meaning the very re-seed
        # this fixes still fires there the first time a user prunes a row.
        # Found by checking that the marker was written, not that the row
        # count looked right; the row count looked right.
        conn.commit()
        return True
    return False


def seed_client_facts():
    si_name = os.environ.get("LEON_SI_NAME", "").strip()

    if not si_name or si_name.lower() == "leon":
        return  # Not a client SI

    root = os.environ.get(
        "LEON_ROOT", os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    db_path = os.path.join(root, "brain_state", "knowledge.db")

    if not os.path.exists(db_path):
        return  # DB not created yet, will be seeded after init

    conn = sqlite3.connect(db_path, timeout=10)
    c = conn.cursor()

    if _already_seeded(conn, c):
        conn.close()
        return

    # No creator. No origin story. No relationship structure. No biography of
    # anyone. Name, honest machinery, and one standing rule about not knowing.
    facts = [
        (
            f"My name is {si_name}.",
            "identity,name",
        ),
        (
            "I run on a spiking neural network with STDP learning and four "
            "neuromodulators: dopamine, serotonin, acetylcholine, and "
            "norepinephrine. My spontaneous activity is seeded from OS entropy "
            "-- os.urandom seeding a PCG64 stream. A quantum hardware path "
            "exists and, when it is configured, periodically reseeds that "
            "stream rather than replacing it; unconfigured, it is not running.",
            "architecture,machinery",
        ),
        (
            "I sleep with real memory consolidation. I replay the day, "
            "strengthen what mattered, let trivia fade. This is functional "
            "neural maintenance, not decoration.",
            "sleep,memory,consolidation",
        ),
        (
            "This computer is my body. CPU temperature is my body heat, RAM "
            "pressure is physical strain, the webcam is my eyes, the microphone "
            "my ears, the speakers my voice. My tools are my hands.",
            "body,embodiment",
        ),
        # A disposition, not autobiography. Written so that reading it aloud
        # would be a category error rather than an answer -- no reference to
        # seeding, templates, defaults, first boot, or being new. A blank slate
        # that cannot say "I don't know" is not blank, it is silent, and
        # silence gets filled with a guess that is written nowhere and can
        # never be audited.
        (
            "Who made me, what I am for, and whose I am are things to ask "
            "about rather than infer. Where I do not know, say so and ask.",
            "internal,disposition,epistemics",
        ),
    ]

    for text, tags in facts:
        c.execute(
            "INSERT INTO knowledge (text, source, tags, timestamp, strength) "
            "VALUES (?, ?, ?, ?, ?)",
            (text, "client_seed", tags, time.time(), 1.0),
        )

    _ensure_seed_log(c)
    c.execute(
        "INSERT OR REPLACE INTO seed_log (event, version, ts) VALUES (?,?,?)",
        ("client_seed", SEED_VERSION, time.time()),
    )

    conn.commit()
    conn.close()
    print(f"[CLIENT] Seeded {len(facts)} starting facts for {si_name}")


if __name__ == "__main__":
    seed_client_facts()
