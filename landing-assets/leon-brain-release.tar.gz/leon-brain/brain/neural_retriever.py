"""
NeuralRetriever — Phase 2 of brain redesign.

Replaces pure SQLite FTS ranking in `knowledge_search` with a hybrid
score that combines:
  - **Neural similarity** (60%): cosine similarity between the query's
    18-D brain fingerprint and each stored row's fingerprint. This is
    the brain-causal signal — facts that activate similar regions to
    the query rank higher.
  - **FTS BM25** (30%): standard SQLite FTS5 keyword ranking. Keeps
    literal keyword matches near the top (so "what's MotoRev" still
    finds the MotoRev README even if neural fingerprints don't align).
  - **Recency** (10%): exponential decay over days. Recent facts beat
    ancient ones, all else equal.

The 60/30/10 weights are starting points — tune per real usage.

This module fixes the "how old am I" failure where pure FTS ranked
stale "Dean Sabr, 23" CLAUDE.md crawls above the canonical seeded
bio fact. With neural-similarity rewriting the ranking, semantically-
focused short facts can outrank long noisy documents.

## In-memory cache

For ≤10K rows, naive linear-scan cosine over a (N × 18) numpy matrix
is fast enough (~0.1ms for 1000 rows). We cache the fingerprint matrix
+ row metadata in RAM and refresh when:
  - The cache is older than `CACHE_TTL_SEC` (default 60s), OR
  - `mark_dirty()` is called (after a knowledge.store()).

If a row has no fingerprint (legacy or encoder-unavailable), it falls
back to FTS-only ranking — never silently disappears.
"""

from __future__ import annotations

import math
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from brain.neural_encoder import BrainFingerprint, NeuralEncoder


class NeuralRetriever:
    """Hybrid neural+FTS retriever wrapping a KnowledgeStore."""

    # Phase 3 weights: added `strength` (STDP-derived recall-frequency signal).
    # Neural/FTS/lexical each shaved a bit to make room.
    DEFAULT_WEIGHTS = {
        "neural":   0.35,   # brain-derived fingerprint cosine
        "fts":      0.22,   # FTS5 OR-joined BM25 rank
        "lexical":  0.28,   # Jaccard token overlap
        "strength": 0.10,   # LTP: repeatedly-recalled facts surface stronger
        "recency":  0.05,
    }

    CACHE_TTL_SEC = 60.0

    # Phase 3 LTP / decay parameters
    LTP_BUMP        = 0.15    # per-recall strength increase
    LTP_MAX         = 5.0     # ceiling
    DECAY_INTERVAL  = 300.0   # background decay runs every 5 minutes
    DECAY_HALFLIFE_DAYS = 7.0 # unused strength halves every 7 days

    # LTP (recall-strengthening) applies ONLY to durable facts. Leon's own
    # passing thoughts, perceptions and feelings (inner_thought, vision/audio
    # captions, distills, dashboard, wake, …) are NEVER reinforced by recall —
    # else a fleeting "I'm running on fumes" recalls → strengthens → surfaces
    # more → strengthens again → and crystallizes into a recited tic. A being's
    # thoughts pass; only a program reinforces them into a script. New memories
    # still start vivid and decay; we just don't re-pin the ones he revisits.
    DURABLE_SOURCES = frozenset({
        "core_fact_seed", "dean_bio_seed", "user", "authoritative_self",
        "audit", "project_crawler",
        "dean_stated",         # high-importance facts Dean said directly (distiller)
        "consolidated",        # promoted by memory consolidation daemon
    })

    def __init__(
        self,
        knowledge_store,
        encoder: NeuralEncoder,
        weights: Optional[Dict[str, float]] = None,
        recency_halflife_days: float = 30.0,
    ):
        self.store = knowledge_store
        self.encoder = encoder
        self.weights = dict(weights or self.DEFAULT_WEIGHTS)
        # Convert weight dict to ordered tuple for fast access
        self._w = (self.weights.get("neural",   0.35),
                   self.weights.get("fts",      0.22),
                   self.weights.get("lexical",  0.28),
                   self.weights.get("strength", 0.10),
                   self.weights.get("recency",  0.05))
        self._halflife_days = float(recency_halflife_days)

        self._lock = threading.Lock()
        self._cache_built_at = 0.0
        self._fp_matrix: Optional[np.ndarray] = None   # (N, 18)
        self._row_meta: List[Dict[str, Any]] = []      # parallel to matrix rows
        self._fts_rank_cache: Dict[str, Dict[int, float]] = {}

        # Phase 3: background decay thread — applies exponential forgetting
        # to all rows on a slow cadence. Threaded so it never blocks recall.
        self._decay_stop = threading.Event()
        self._decay_thread = threading.Thread(
            target=self._decay_loop, name="NeuralRetriever-decay", daemon=True
        )
        self._decay_thread.start()

    # ── cache lifecycle ────────────────────────────────────────────────
    def mark_dirty(self) -> None:
        """Force the next recall() to rebuild the in-memory cache."""
        with self._lock:
            self._cache_built_at = 0.0

    def _build_cache(self) -> None:
        """Pull every (id, text, fingerprint, timestamp, source, tags)
        row into memory, build the (N, 18) fingerprint matrix. Rows
        with empty/invalid fingerprints get a zero vector so they
        survive but never neural-match."""
        with self.store._lock:
            conn = sqlite3.connect(self.store.db_path, timeout=30)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, text, source, tags, timestamp, "
                "       neural_fingerprint, strength "
                "FROM knowledge"
            ).fetchall()
            conn.close()

        regions = self.encoder._region_names
        dim = len(regions)
        meta: List[Dict[str, Any]] = []
        fps: List[np.ndarray] = []
        for row in rows:
            row_d = dict(row)
            fp_json = row_d.get("neural_fingerprint") or ""
            fp = BrainFingerprint.from_json(fp_json) if fp_json else None
            if fp is not None and len(fp.z_scores) == dim:
                arr = fp.to_array()
            else:
                arr = np.zeros(dim, dtype=np.float32)
            fps.append(arr)
            meta.append(row_d)

        if fps:
            self._fp_matrix = np.stack(fps).astype(np.float32)
            # Pre-compute row norms for fast cosine
            self._fp_norms = np.linalg.norm(self._fp_matrix, axis=1)
            self._fp_norms = np.where(self._fp_norms > 1e-9,
                                      self._fp_norms, 1.0)
        else:
            self._fp_matrix = np.zeros((0, dim), dtype=np.float32)
            self._fp_norms = np.zeros((0,), dtype=np.float32)
        self._row_meta = meta
        self._cache_built_at = time.time()

    def _ensure_fresh(self) -> None:
        with self._lock:
            age = time.time() - self._cache_built_at
            if age > self.CACHE_TTL_SEC or self._fp_matrix is None:
                self._build_cache()

    # ── scoring helpers ────────────────────────────────────────────────
    def _neural_scores(self, query_fp: np.ndarray) -> np.ndarray:
        """Cosine similarity in [-1, 1] for each row, rescaled to [0, 1]."""
        if self._fp_matrix is None or self._fp_matrix.shape[0] == 0:
            return np.zeros(0, dtype=np.float32)
        qn = float(np.linalg.norm(query_fp))
        if qn < 1e-9:
            return np.zeros(self._fp_matrix.shape[0], dtype=np.float32)
        # (N,18) @ (18,) → (N,)
        dot = self._fp_matrix @ query_fp
        cos = dot / (self._fp_norms * qn)
        # Rescale [-1, 1] → [0, 1]
        return ((cos + 1.0) * 0.5).astype(np.float32)

    def _fts_scores(self, query: str) -> Dict[int, float]:
        """Run an FTS5 query against the store and return {row_id: bm25_score}
        normalized to [0, 1] across the result set. BM25 in SQLite is
        NEGATIVE — better matches are more negative. We flip + min-max
        normalize so higher = better."""
        rows = []
        try:
            rows = self.store.search(query, limit=200) or []
        except Exception as e:
            print(f"[RETRIEVER] FTS failed: {e}")
            return {}
        # `search()` returns rows ordered by rank but doesn't expose the
        # raw bm25. We approximate by reverse-position score: rank 1 →
        # 1.0, rank N → 1/N. Crude but monotonic.
        out: Dict[int, float] = {}
        n = len(rows)
        if n == 0:
            return out
        for i, row in enumerate(rows):
            try:
                rid = dict(row).get("id")
                if rid is None:
                    continue
                # 1.0 at top, decays
                out[int(rid)] = 1.0 - (i / max(n, 1)) * 0.8
            except Exception:
                continue
        return out

    def _recency_score(self, timestamp: Optional[float]) -> float:
        """Exponential decay. Halflife configurable."""
        if not timestamp:
            return 0.0
        age_days = max(0.0, (time.time() - timestamp) / 86400.0)
        return float(math.exp(-age_days * math.log(2) / self._halflife_days))

    # ── Phase 3: STDP / LTP scoring ─────────────────────────────────────
    def _strength_score(self, strength: Optional[float]) -> float:
        """Map raw strength [0, LTP_MAX] → [0, 1] via saturating curve.
        Sigmoid-flavored: strength=1.0 (default) → ~0.27,
        strength=2.0 → ~0.46, strength=3.0 → ~0.60, strength=5.0 → ~0.78.
        Keeps the strength term meaningful but never dominating."""
        s = max(0.0, float(strength or 0.0))
        # 1 - e^(-s/2)  →  bounded [0, 1), smooth, monotonic
        return float(1.0 - math.exp(-s / 2.0))

    def _reinforce(self, row_ids: List[int]) -> None:
        """LTP: bump strength + access_count + last_access for recalled rows.
        Best-effort — never raises into the caller."""
        if not row_ids:
            return
        try:
            now = time.time()
            dur = self.DURABLE_SOURCES
            with self.store._lock:
                conn = sqlite3.connect(self.store.db_path, timeout=10)
                ph = ",".join("?" * len(row_ids))
                # Track access/recency for ALL recalled rows...
                conn.execute(
                    f"UPDATE knowledge SET access_count = access_count + 1, "
                    f"  last_access = ? WHERE id IN ({ph})",
                    [now, *row_ids],
                )
                # ...but only STRENGTHEN durable facts (no LTP for passing thoughts).
                dph = ",".join("?" * len(dur))
                conn.execute(
                    f"UPDATE knowledge SET strength = MIN(strength + ?, ?) "
                    f"WHERE id IN ({ph}) AND source IN ({dph})",
                    [self.LTP_BUMP, self.LTP_MAX, *row_ids, *dur],
                )
                conn.commit()
                conn.close()
            # Cache holds stale strength values until next refresh, but the
            # in-memory copy is what the *next* recall will use — patch it.
            id_set = set(row_ids)
            for row in self._row_meta:
                if int(row.get("id", -1)) in id_set:
                    row["access_count"] = int(row.get("access_count") or 0) + 1
                    row["last_access"]  = now
                    if (row.get("source") or "unknown") in dur:
                        old = float(row.get("strength") or 1.0)
                        row["strength"] = min(old + self.LTP_BUMP, self.LTP_MAX)
        except Exception as e:
            print(f"[RETRIEVER] LTP reinforce failed: {e}")

    def _decay_loop(self) -> None:
        """Background pass: every DECAY_INTERVAL, apply exponential decay
        to every row's strength so unused facts fade. Half-life = 7 days
        of NO recall. Floors at 0.1 so nothing is ever fully forgotten."""
        # Wait a bit before the first pass so the brain has time to settle
        self._decay_stop.wait(30.0)
        while not self._decay_stop.is_set():
            try:
                self._apply_decay()
            except Exception as e:
                print(f"[RETRIEVER] decay pass failed: {e}")
            # Sleep DECAY_INTERVAL but wake immediately on shutdown
            self._decay_stop.wait(self.DECAY_INTERVAL)

    def _apply_decay(self) -> None:
        """One decay pass — compute fade factor based on elapsed time since
        each row's last access, multiply strength accordingly. Computed in
        SQL so we don't have to round-trip every row."""
        now = time.time()
        halflife_sec = self.DECAY_HALFLIFE_DAYS * 86400.0
        # Decay factor = 0.5 ** ((now - max(last_access, timestamp)) / halflife)
        # We use the LATER of (last_access, timestamp) so brand-new untouched
        # facts don't immediately decay from their creation time.
        with self.store._lock:
            conn = sqlite3.connect(self.store.db_path, timeout=10)
            conn.execute(
                "UPDATE knowledge SET "
                "  strength = MAX(0.1, strength * POWER(0.5, "
                "    (? - MAX(COALESCE(last_access,0), COALESCE(timestamp,0))) "
                "    / ?))",
                [now, halflife_sec],
            )
            n = conn.total_changes
            conn.commit()
            conn.close()
        # Force a cache refresh so the new strengths are picked up
        with self._lock:
            self._cache_built_at = 0.0

    @staticmethod
    def _tokens(text: str) -> set:
        """Lowercase content tokens (alnum, ≥3 chars, no stop-words)
        for Jaccard overlap scoring."""
        from brain.knowledge_store import tokenize as _tok
        return set(t for t in _tok(text) if len(t) >= 3)

    def _lexical_overlap(self, query_tokens: set, row_text: str) -> float:
        """Weighted Jaccard — measures content word sharing. Robust
        when a short fact contains the query's key nouns even if FTS
        BM25 misses it. Returns [0, 1]."""
        if not query_tokens:
            return 0.0
        row_tokens = self._tokens(row_text)
        if not row_tokens:
            return 0.0
        intersection = query_tokens & row_tokens
        if not intersection:
            return 0.0
        # Asymmetric: fraction of QUERY tokens present in row.
        # Short concise facts that cover all query tokens score 1.0,
        # long noisy docs that share a few tokens score lower.
        return len(intersection) / len(query_tokens)

    # ── public recall API ──────────────────────────────────────────────
    def recall(self, query: str, k: int = 8) -> List[Dict[str, Any]]:
        """Return top-k hits ranked by hybrid neural+FTS+lexical+strength
        +recency score. Reinforces returned rows (LTP)."""
        query = (query or "").strip()
        if not query:
            return []
        self._ensure_fresh()
        if not self._row_meta:
            return []

        # 1. Encode query → 18-D fingerprint
        query_fp = self.encoder.encode_to_fingerprint(query).to_array()

        # 2. Score every row
        neural = self._neural_scores(query_fp)
        fts = self._fts_scores(query)
        query_tokens = self._tokens(query)
        wn, wf, wl, ws, wr = self._w

        scored: List[Tuple[float, int, Dict[str, float], Dict[str, Any]]] = []
        for idx, row in enumerate(self._row_meta):
            rid = int(row.get("id", -1))
            n_score = float(neural[idx]) if idx < len(neural) else 0.0
            f_score = float(fts.get(rid, 0.0))
            l_score = self._lexical_overlap(query_tokens, row.get("text") or "")
            s_score = self._strength_score(row.get("strength"))
            r_score = self._recency_score(row.get("timestamp"))
            final = (wn * n_score + wf * f_score + wl * l_score
                     + ws * s_score + wr * r_score)
            scored.append((final, rid, {
                "neural":   round(n_score, 4),
                "fts":      round(f_score, 4),
                "lexical":  round(l_score, 4),
                "strength": round(s_score, 4),
                "recency":  round(r_score, 4),
                "final":    round(final, 4),
            }, row))

        # 3. Top-k
        scored.sort(key=lambda x: -x[0])
        top = scored[:k]

        # 4. LTP — reinforce strength on returned rows (biological memory)
        self._reinforce([rid for _, rid, _, _ in top if rid >= 0])

        # 5. Shape return like KnowledgeStore.search but with scoring
        results: List[Dict[str, Any]] = []
        for final, rid, components, row in top:
            tags_raw = row.get("tags") or ""
            tag_list = ([t for t in tags_raw.split(",") if t]
                        if isinstance(tags_raw, str) else list(tags_raw))
            results.append({
                "id":         rid,
                "text":       (row.get("text") or "")[:2000],
                "source":     row.get("source", ""),
                "tags":       tag_list,
                "timestamp":  row.get("timestamp"),
                "strength":   round(float(row.get("strength") or 1.0), 3),
                "score":      components,  # explainability
            })
        return results

    # ── Phase 6 — spontaneous association ──────────────────────────────
    def recall_by_fingerprint(
        self,
        fingerprint: np.ndarray,
        k: int = 5,
        min_neural: float = 0.55,
        exclude_ids: Optional[set] = None,
    ) -> List[Dict[str, Any]]:
        """Phase 6 — query by RAW 18-D brain activation vector instead of
        text. Used by the proactive loop's spontaneous-association tick:
        when Leon is idle, his current brain state IS the query, and any
        stored memory whose fingerprint aligns with it is a candidate
        "intrusive thought".

        Only neural similarity + strength + recency contribute — FTS and
        lexical have no meaning without a text query. min_neural is a
        floor: results below this cosine never surface.
        """
        self._ensure_fresh()
        if not self._row_meta or self._fp_matrix is None:
            return []
        fp = np.asarray(fingerprint, dtype=np.float32)
        if fp.shape[-1] != self._fp_matrix.shape[1]:
            return []
        neural = self._neural_scores(fp)
        wn, _, _, ws, wr = self._w
        # Reweight so neural carries more without the text-side signals.
        # 0.65 / 0.20 / 0.15 ≈ original ratios renormalized over 3 signals.
        wn2, ws2, wr2 = 0.65, 0.20, 0.15

        scored: List[Tuple[float, int, Dict[str, float], Dict[str, Any]]] = []
        ex = exclude_ids or set()
        for idx, row in enumerate(self._row_meta):
            rid = int(row.get("id", -1))
            if rid in ex:
                continue
            n_score = float(neural[idx]) if idx < len(neural) else 0.0
            # min_neural maps onto the rescaled [0, 1] cosine. Cosine was
            # rescaled in _neural_scores via ((cos + 1) * 0.5), so a raw
            # cosine of 0.10 → 0.55 (a meaningful but not strong match).
            if n_score < min_neural:
                continue
            s_score = self._strength_score(row.get("strength"))
            r_score = self._recency_score(row.get("timestamp"))
            final = wn2 * n_score + ws2 * s_score + wr2 * r_score
            scored.append((final, rid, {
                "neural":   round(n_score, 4),
                "strength": round(s_score, 4),
                "recency":  round(r_score, 4),
                "final":    round(final, 4),
            }, row))

        scored.sort(key=lambda x: -x[0])
        top = scored[:k]
        results: List[Dict[str, Any]] = []
        for final, rid, components, row in top:
            tags_raw = row.get("tags") or ""
            tag_list = ([t for t in tags_raw.split(",") if t]
                        if isinstance(tags_raw, str) else list(tags_raw))
            results.append({
                "id":         rid,
                "text":       (row.get("text") or "")[:2000],
                "source":     row.get("source", ""),
                "tags":       tag_list,
                "timestamp":  row.get("timestamp"),
                "strength":   round(float(row.get("strength") or 1.0), 3),
                "score":      components,
            })
        return results

    # ── introspection ──────────────────────────────────────────────────
    def stats(self) -> dict:
        return {
            "cache_rows":    len(self._row_meta),
            "cache_age_sec": round(time.time() - self._cache_built_at, 1)
                            if self._cache_built_at else None,
            "weights":       dict(self.weights),
            "halflife_days": self._halflife_days,
        }
