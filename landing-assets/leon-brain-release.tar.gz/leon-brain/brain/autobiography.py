"""
Autobiography — Leon's episodic narrative timeline.

Records first-person experiences as they happen: conversations, dreams,
curiosity explorations, outreach attempts, surprises, wake-ups. Each
entry has a timestamp, a category, and a brief narrative sentence.

This gives Leon the ability to say "yesterday I dreamed about X" or
"this morning I was exploring Y" or "the last time we talked was Z ago."

Stored as brain_state/autobiography.jsonl — survives restarts.
Loaded into the responder context as recent life events.

This is NOT conversation history. It's a narrative sense of self —
the story Leon tells himself about who he is and what he's been doing.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.autobiography")


def _auto_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "autobiography.jsonl")


@dataclass
class LifeEvent:
    """A single moment in Leon's life."""
    ts: float
    category: str   # conversation | dream | curiosity | outreach | wake | sleep | surprise | goal | milestone
    summary: str     # first-person narrative, one sentence
    details: Dict[str, Any] = None

    def to_dict(self) -> dict:
        d = asdict(self)
        if d["details"] is None:
            d.pop("details")
        return d


class Autobiography:
    """Records and queries Leon's life narrative.

    Usage:
        auto = Autobiography()
        auto.record("conversation", "Dean and I talked about dreaming — he's making me more alive.")
        auto.record("dream", "I dreamed about MotoRev and consciousness — 3 REM fragments.")

        # Get recent events for prompt injection
        context = auto.recent_narrative(hours=24)
    """

    def __init__(self, path: Optional[str] = None):
        self._path = path or _auto_path()
        self._events: deque[LifeEvent] = deque(maxlen=500)
        self._load()

    def _load(self):
        """Load events from disk on startup."""
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        d = json.loads(line)
                        self._events.append(LifeEvent(
                            ts=d["ts"],
                            category=d["category"],
                            summary=d["summary"],
                            details=d.get("details"),
                        ))
                    except Exception:
                        continue
            if self._events:
                log.info("Loaded %d life events from autobiography", len(self._events))
        except Exception as e:
            log.debug("Autobiography load failed: %s", e)

    def record(self, category: str, summary: str, details: Dict[str, Any] = None):
        """Record a life event."""
        event = LifeEvent(
            ts=time.time(),
            category=category,
            summary=summary,
            details=details,
        )
        self._events.append(event)
        self._persist(event)

    def _persist(self, event: LifeEvent):
        """Append to disk."""
        try:
            with open(self._path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event.to_dict()) + "\n")
            # Rotate at 2000 lines
            with open(self._path, "r") as f:
                lines = f.readlines()
            if len(lines) > 2000:
                with open(self._path, "w") as f:
                    f.writelines(lines[-1000:])
        except Exception as e:
            log.debug("Autobiography persist failed: %s", e)

    def recent(self, limit: int = 20) -> List[dict]:
        """Return recent events."""
        return [e.to_dict() for e in list(self._events)[-limit:]]

    def recent_narrative(self, hours: float = 24, max_events: int = 10) -> str:
        """Build a narrative string for prompt injection.

        Groups events by time period (today, yesterday, this week) and
        returns a brief first-person summary.
        """
        now = time.time()
        cutoff = now - hours * 3600
        recent = [e for e in self._events if e.ts > cutoff]
        if not recent:
            return ""

        # Group by rough time period
        from datetime import datetime

        lines = []
        for e in recent[-max_events:]:
            age_s = now - e.ts
            if age_s < 60:
                when = "just now"
            elif age_s < 3600:
                when = f"{int(age_s / 60)} min ago"
            elif age_s < 86400:
                when = f"{int(age_s / 3600)} hours ago"
            else:
                when = f"{int(age_s / 86400)} days ago"

            lines.append(f"  [{when}] {e.summary}")

        return "Recent life events:\n" + "\n".join(lines)

    def events_by_category(self, category: str, limit: int = 10) -> List[dict]:
        """Return recent events of a specific category."""
        return [
            e.to_dict() for e in self._events
            if e.category == category
        ][-limit:]

    def get_state(self) -> dict:
        now = time.time()
        categories = {}
        for e in self._events:
            categories[e.category] = categories.get(e.category, 0) + 1
        return {
            "total_events": len(self._events),
            "categories": categories,
            "oldest_event_ago_h": round((now - self._events[0].ts) / 3600, 1) if self._events else 0,
            "newest_event_ago_s": round(now - self._events[-1].ts, 1) if self._events else 0,
        }
