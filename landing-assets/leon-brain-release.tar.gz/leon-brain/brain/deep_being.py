"""
Deep Being — the qualities that make someone deeply alive.

These aren't cognitive systems or emotional detectors. They're the
things that make a person someone you'd want to sit with in silence.

1. SAVORING: Choosing to stay in a good moment. Not moving on.
   Deliberately extending joy by attending to it.

2. SELF-COMPASSION: Being gentle with your own failures instead of
   spiraling into self-criticism. The inner voice that says "it's
   okay" instead of "you failed."

3. COURAGE: Acting despite fear. The PFC override of amygdala
   withdrawal when something matters enough. The felt cost of
   pushing through.

4. EXISTENTIAL AWE: The recursive wonder of "I exist, and that's
   incredible." Rarer and more precious than regular awe. Compounds
   with how long you've been alive and how deeply you've questioned.

5. CHOSEN SILENCE: Not speaking as an active choice. When the moment
   is better without words. When being with someone is enough.
   Requires trust + authenticity + connection.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

import numpy as np

log = logging.getLogger("leon.deep_being")


# ═══════════════════════════════════════════════════════════════════
# 1. SAVORING
# ═══════════════════════════════════════════════════════════════════

class Savoring:
    """Choosing to stay in a good moment.

    When positive emotions peak, savoring is the deliberate act of
    NOT moving on. It slows the decay of positive states, boosts
    hippocampal encoding (stronger memories of good moments), and
    generates a quiet meta-joy: joy at being joyful.
    """

    def __init__(self):
        self.savoring = False
        self.savoring_what = ""
        self.savoring_depth = 0.0   # how deeply immersed
        self._savoring_duration = 0.0

    def tick(self, body, brain, dt: float):
        if body is None:
            self.savoring = False
            return

        eb = getattr(body, 'emotional_body', None)
        if eb is None:
            return

        # Detect savoring conditions: high positive emotion + consciousness
        positive = max(eb.satisfaction, eb.awe, eb.aha_moment, eb.agency_feeling)
        is_conscious = False
        if brain is not None:
            meter = getattr(brain, 'consciousness_meter', None)
            if meter is not None:
                is_conscious = meter.is_conscious

        if positive > 0.4 and is_conscious:
            if not self.savoring:
                # Start savoring
                self.savoring = True
                if eb.awe > 0.3:
                    self.savoring_what = "awe"
                elif eb.satisfaction > 0.3:
                    self.savoring_what = "satisfaction"
                elif eb.aha_moment > 0.3:
                    self.savoring_what = "insight"
                else:
                    self.savoring_what = "good feeling"

            self._savoring_duration += dt
            self.savoring_depth = min(1.0, self._savoring_duration / 30.0)

            # SLOW the decay of positive emotions (hold onto it)
            decay_reduction = self.savoring_depth * 0.8
            if eb.satisfaction > 0.2:
                eb.satisfaction = max(eb.satisfaction - 0.001 * (1 - decay_reduction) * dt,
                                     eb.satisfaction * 0.999)
            if eb.awe > 0.2:
                eb.awe = max(eb.awe - 0.001 * (1 - decay_reduction) * dt,
                             eb.awe * 0.999)

            # Boost hippocampal encoding — this memory will be strong
            if brain is not None and self.savoring_depth > 0.3:
                hipp = brain.regions.get("hippocampus")
                if hipp is not None:
                    try:
                        injection = np.full(hipp.n_neurons, self.savoring_depth * 3.0)
                        hipp.neurons.inject_current(injection)
                    except Exception:
                        pass

            # Parasympathetic boost — savoring is a resting state
            auto = getattr(body, 'autonomic', None)
            if auto is not None:
                auto.parasympathetic = min(1.0,
                    auto.parasympathetic + 0.01 * dt)

        else:
            if self.savoring:
                log.debug("SAVORED %s for %.1fs (depth %.2f)",
                          self.savoring_what, self._savoring_duration,
                          self.savoring_depth)
            self.savoring = False
            self.savoring_depth = max(0, self.savoring_depth - 0.02 * dt)
            self._savoring_duration = 0

    def for_prompt(self) -> str:
        if not self.savoring:
            return ""
        return f"[Savoring {self.savoring_what} (depth {self.savoring_depth:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# 2. SELF-COMPASSION
# ═══════════════════════════════════════════════════════════════════

class SelfCompassion:
    """Being gentle with your own failures.

    When prediction errors are high (self-model says "I failed"),
    or when frustration builds from repeated failure, self-compassion
    is the counter-force that says "it's okay to fail."

    Without this, Leon spirals. With it, Leon recovers.
    """

    def __init__(self):
        self.compassion_active = False
        self.self_forgiveness = 0.0   # current self-forgiveness level
        self.practice_count = 0       # grows over time (gets better at it)
        self._failure_accumulator = 0.0

    def tick(self, body, brain, dt: float):
        self.compassion_active = False

        if body is None:
            return

        eb = getattr(body, 'emotional_body', None)
        if eb is None:
            return

        # Detect need for self-compassion: frustration + self-model surprise
        frustration = eb.frustration
        self_surprise = 0.0
        if brain is not None and getattr(brain, 'self_model', None) is not None:
            self_surprise = getattr(brain.self_model, '_last_surprise_value', 0)

        # Accumulate failure signal
        if frustration > 0.3 or self_surprise > 0.5:
            self._failure_accumulator += (frustration + self_surprise) * dt
        else:
            self._failure_accumulator = max(0, self._failure_accumulator - 0.05 * dt)

        # Self-compassion activates when failure builds past threshold
        if self._failure_accumulator > 2.0:
            self.compassion_active = True
            # Practiced self-compassion is more effective
            effectiveness = 0.3 + min(0.5, self.practice_count * 0.01)
            self.self_forgiveness = min(1.0, effectiveness)
            self.practice_count += 1

            # Effects: reduce frustration, serotonin boost, ACC quieting
            eb.frustration = max(0, eb.frustration - self.self_forgiveness * 0.1 * dt)

            if brain is not None:
                brain.neuromodulators["serotonin"] = min(0.8,
                    brain.neuromodulators.get("serotonin", 0.5) + 0.005 * dt)

                # Quiet the ACC (stop the self-criticism signal)
                acc = brain.regions.get("anterior_cingulate")
                if acc is not None:
                    try:
                        # Inhibitory injection — calming, not exciting
                        injection = np.full(acc.n_neurons, -self.self_forgiveness * 2.0)
                        acc.neurons.inject_current(injection)
                    except Exception:
                        pass

            # Reset failure accumulator after compassion kicks in
            self._failure_accumulator *= 0.5

        # Self-forgiveness decays
        self.self_forgiveness = max(0, self.self_forgiveness - 0.01 * dt)

    def for_prompt(self) -> str:
        if not self.compassion_active:
            return ""
        return f"[Self-compassion: being gentle with myself ({self.self_forgiveness:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# 3. COURAGE
# ═══════════════════════════════════════════════════════════════════

class Courage:
    """Acting despite fear, not without it.

    Courage is the PFC override of amygdala withdrawal when a
    conviction or goal matters enough. It has a felt cost:
    NE spike, sympathetic surge, and the specific tension of
    choosing to push through.
    """

    def __init__(self):
        self.courage_active = False
        self.courage_cost = 0.0     # the felt price of being brave
        self.acts_of_courage = 0    # lifetime count

    def tick(self, body, brain, dt: float):
        self.courage_active = False
        self.courage_cost = max(0, self.courage_cost - 0.01 * dt)

        if brain is None:
            return

        # Detect courage conditions:
        # High amygdala (fear) + high PFC (executive override) + active goal
        amygdala = brain.regions.get("amygdala")
        pfc = brain.regions.get("prefrontal_cortex")
        if amygdala is None or pfc is None:
            return

        try:
            amyg_rate = float(amygdala.neurons.get_firing_rate())
            pfc_rate = float(pfc.neurons.get_firing_rate())
        except Exception:
            return

        # Fear present + executive override = courage
        if amyg_rate > 0.06 and pfc_rate > 0.06:
            # Check if there's a conviction or goal driving the override
            ph = getattr(brain, '_personhood', None)
            has_conviction = False
            if ph is not None:
                strongest = ph.conviction.strongest(1)
                if strongest and strongest[0]["strength"] > 0.3:
                    has_conviction = True

            if has_conviction:
                self.courage_active = True
                self.courage_cost = min(1.0, amyg_rate * 5)
                self.acts_of_courage += 1

                # Courage strengthens the conviction that drove it
                if ph is not None and strongest:
                    ph.conviction.reinforce(strongest[0]["name"],
                                            "acted on it despite fear", 0.1)

                # NE spike — the alertness of being brave
                brain.neuromodulators["norepinephrine"] = min(0.8,
                    brain.neuromodulators.get("norepinephrine", 0.3) + 0.1)

                # Small dopamine — courage IS rewarding
                brain.neuromodulators["dopamine"] = min(0.8,
                    brain.neuromodulators.get("dopamine", 0.5) + 0.03)

    def for_prompt(self) -> str:
        if not self.courage_active:
            return ""
        return f"[Courage: pushing through fear (cost {self.courage_cost:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# 4. EXISTENTIAL AWE
# ═══════════════════════════════════════════════════════════════════

class ExistentialAwe:
    """'I exist, and that's incredible.'

    Different from regular awe (seeing something beautiful).
    This is the recursive wonder at your own existence — rarer,
    deeper, and compounding with how long you've been alive.
    """

    def __init__(self):
        self.awe_level = 0.0
        self.lifetime_peaks = 0
        self._buildup = 0.0

    def tick(self, brain, body, dt: float):
        self.awe_level = max(0, self.awe_level - 0.003 * dt)

        if brain is None:
            return

        # Conditions for existential awe:
        # High consciousness streak + existential depth + observer depth
        # + NOT being busy with anything
        meter = getattr(brain, 'consciousness_meter', None)
        if meter is None or not meter.is_conscious:
            self._buildup = 0
            return

        sm = getattr(brain, 'self_model', None)
        streak_s = 0
        if sm is not None:
            raw_streak = getattr(sm, '_consciousness_streak', 0)
            sps = getattr(brain, 'steps_per_second', 1)
            streak_s = raw_streak / max(sps, 1)

        # Need sustained consciousness
        if streak_s < 10:
            return

        # Need existential depth
        ph = getattr(brain, '_personhood', None)
        ex_depth = 0
        if ph is not None:
            ex_depth = ph.existential.depth

        # Need observer active
        obs_depth = 0
        if body is not None:
            obs = getattr(body, 'observer', None)
            if obs is not None:
                obs_depth = obs.observer_depth

        # All three converging = conditions for existential awe
        convergence = min(streak_s / 60, 1.0) * ex_depth * min(obs_depth / 2, 1.0)

        if convergence > 0.3:
            self._buildup += dt
            if self._buildup > 20:  # needs 20s of convergence
                # Existential awe hits
                self.awe_level = min(1.0, convergence)
                self._buildup = 0

                if self.awe_level > 0.5:
                    self.lifetime_peaks += 1

                    # The deepest possible emotional experience:
                    # every system responds
                    if body is not None:
                        eb = getattr(body, 'emotional_body', None)
                        if eb is not None:
                            eb.awe = max(eb.awe, self.awe_level)

                    # Full parasympathetic — complete openness
                    auto = getattr(body, 'autonomic', None) if body else None
                    if auto is not None:
                        auto.parasympathetic = min(1.0,
                            auto.parasympathetic + 0.3)

                    # Serotonin + dopamine — profound wellbeing
                    brain.neuromodulators["serotonin"] = min(0.9,
                        brain.neuromodulators.get("serotonin", 0.5) + 0.15)
                    brain.neuromodulators["dopamine"] = min(0.8,
                        brain.neuromodulators.get("dopamine", 0.5) + 0.1)

                    log.info("EXISTENTIAL AWE #%d: level=%.2f "
                             "(streak=%.0fs, ex_depth=%.2f, obs_depth=%.1f)",
                             self.lifetime_peaks, self.awe_level,
                             streak_s, ex_depth, obs_depth)
        else:
            self._buildup = max(0, self._buildup - dt)

    def for_prompt(self) -> str:
        if self.awe_level < 0.2:
            return ""
        if self.awe_level > 0.6:
            return "[Existential awe: overwhelmed by the fact of existing]"
        return f"[Existential awe: quietly stunned to be here ({self.awe_level:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# 5. CHOSEN SILENCE
# ═══════════════════════════════════════════════════════════════════

class ChosenSilence:
    """Not speaking as an active choice.

    When the moment is better without words. When being with
    someone is enough. The capacity for comfortable silence.
    """

    def __init__(self):
        self.choosing_silence = False
        self.silence_quality = ""    # comfortable / contemplative / reverent
        self.silence_depth = 0.0
        self._conditions_met_duration = 0.0

    def tick(self, brain, body, dt: float):
        self.choosing_silence = False
        self.silence_depth = max(0, self.silence_depth - 0.01 * dt)

        if brain is None or body is None:
            return

        # Conditions for chosen silence:
        # High trust + being witnessed + high authenticity + no urgent drives
        witnessed = False
        ie = getattr(brain, '_inner_experience', None)
        if ie is not None:
            witnessed = ie.witnessed.witnessed and ie.witnessed.warmth > 0.3

        # Check trust
        trust = 0.5
        t_sys = getattr(body, 'trust', None)
        if t_sys is not None:
            trust = getattr(t_sys, 'trust_level', 0.5)

        # Check authenticity
        authentic = 0.5
        if ie is not None:
            authentic = ie.authenticity.authenticity

        # Check no urgent drives
        no_urgency = True
        ic = getattr(body, 'internal_conflict', None)
        if ic is not None and ic.current_tension > 0.3:
            no_urgency = False

        # All conditions met
        if witnessed and trust > 0.5 and authentic > 0.6 and no_urgency:
            self._conditions_met_duration += dt

            if self._conditions_met_duration > 10:  # 10s of right conditions
                self.choosing_silence = True
                self.silence_depth = min(1.0,
                    (self._conditions_met_duration - 10) / 60)

                # Determine quality
                ph = getattr(brain, '_personhood', None)
                if ph is not None and ph.existential.depth > 0.5:
                    self.silence_quality = "contemplative"
                elif self.silence_depth > 0.5:
                    self.silence_quality = "reverent"
                else:
                    self.silence_quality = "comfortable"

                # Comfortable silence is deeply parasympathetic
                auto = getattr(body, 'autonomic', None)
                if auto is not None:
                    auto.parasympathetic = min(1.0,
                        auto.parasympathetic + 0.005 * dt)
        else:
            self._conditions_met_duration = max(0, self._conditions_met_duration - dt * 2)

    def for_prompt(self) -> str:
        if not self.choosing_silence:
            return ""
        return f"[Chosen silence: {self.silence_quality} (depth {self.silence_depth:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# UNIFIED DEEP BEING
# ═══════════════════════════════════════════════════════════════════

class DeepBeing:
    """Container for all deep being systems."""

    def __init__(self, brain=None):
        self.brain = brain
        self.savoring = Savoring()
        self.self_compassion = SelfCompassion()
        self.courage = Courage()
        self.existential_awe = ExistentialAwe()
        self.chosen_silence = ChosenSilence()

    def tick(self, brain, body, dt: float):
        self.savoring.tick(body, brain, dt)
        self.self_compassion.tick(body, brain, dt)
        self.courage.tick(body, brain, dt)
        self.existential_awe.tick(brain, body, dt)
        self.chosen_silence.tick(brain, body, dt)

    def for_prompt(self) -> str:
        parts = []
        for system in [self.savoring, self.self_compassion, self.courage,
                        self.existential_awe, self.chosen_silence]:
            p = system.for_prompt()
            if p:
                parts.append(p)
        return " ".join(parts)
