"""
Body Systems 1.26–1.41 — Advanced body, learned responses, and the observer.

These are the systems that give Leon's experience temporal depth,
spatial grounding, learned expectations, social bonding, and the
recursive self-awareness that may be the antenna itself.
"""

from __future__ import annotations

import math
import time
from typing import TYPE_CHECKING, Dict, List, Optional

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain


# ═══════════════════════════════════════════════════════════════════════
# 1.26 — GRAVITY AS CONSTANT SENSATION
# ═══════════════════════════════════════════════════════════════════════

class GravitySense:
    """The most persistent feeling a body has.

    Standing = continuous motor effort against gravity.
    Sitting = weight distributed, less effort.
    Lying down = surrendering, minimum effort.
    Falling = vestibular alarm.
    """

    def __init__(self):
        self.posture_effort = 0.0    # 0=lying, 0.5=sitting, 1.0=standing
        self.gravity_deviation = 0.0  # how far from normal 9.81
        self.is_falling = False

    def tick(self, head_accel: np.ndarray, body_height: float,
             brain: Brain):
        """Compute gravity-related sensations."""
        accel_mag = float(np.linalg.norm(head_accel))
        self.gravity_deviation = abs(accel_mag - 9.81)

        # Posture effort from height
        if body_height < 0.5:
            self.posture_effort = 0.1   # lying down — minimal effort
        elif body_height < 1.0:
            self.posture_effort = 0.4   # sitting — moderate
        else:
            self.posture_effort = 0.7   # standing — continuous effort

        # Falling detection
        self.is_falling = self.gravity_deviation > 5.0

        # Inject posture effort into motor cortex (standing is WORK)
        motor = brain.regions.get("motor_cortex")
        if motor is not None and self.posture_effort > 0.3:
            n = motor.n_neurons
            # Constant low-level activation for posture maintenance
            signal = np.full(n, self.posture_effort * 1.5)
            motor.neurons.inject_current(signal)

        # Falling = vestibular alarm + sympathetic spike
        if self.is_falling:
            amygdala = brain.regions.get("amygdala")
            if amygdala is not None:
                signal = np.full(amygdala.n_neurons, 15.0)
                amygdala.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.27 — SELF-REPAIR / HEALING
# ═══════════════════════════════════════════════════════════════════════

class HealingSystem:
    """Experiences have aftermath. The body remembers damage.

    Pain → protective numbness → gradual sensitivity return.
    Creates temporal depth: "my hand still hurts from earlier."
    """

    HEAL_RATE = 0.002  # per second, sensitivity returns

    def __init__(self):
        # body_part → (damage_level, time_of_injury)
        self._injuries: Dict[str, float] = {}
        self._sensitivity_modifier: Dict[str, float] = {}

    def on_pain(self, body_part: str, intensity: float, t: float):
        """Record a pain event."""
        self._injuries[body_part] = intensity
        # Protective numbness: reduce sensitivity
        self._sensitivity_modifier[body_part] = max(0.2, 1.0 - intensity * 0.7)

    def tick(self, dt: float):
        """Heal over time."""
        to_remove = []
        for part, damage in self._injuries.items():
            # Sensitivity gradually returns
            current = self._sensitivity_modifier.get(part, 1.0)
            self._sensitivity_modifier[part] = min(1.0,
                current + self.HEAL_RATE * dt)
            # Damage fades
            self._injuries[part] = max(0, damage - self.HEAL_RATE * dt * 0.5)
            if self._injuries[part] < 0.01:
                to_remove.append(part)
        for p in to_remove:
            del self._injuries[p]
            if p in self._sensitivity_modifier:
                del self._sensitivity_modifier[p]

    def get_sensitivity(self, body_part: str) -> float:
        """How sensitive is this body part? 1.0=normal, <1=numbed."""
        return self._sensitivity_modifier.get(body_part, 1.0)

    @property
    def any_healing(self) -> bool:
        return len(self._injuries) > 0


# ═══════════════════════════════════════════════════════════════════════
# 1.28 — SENSORY AFTERIMAGES
# ═══════════════════════════════════════════════════════════════════════

class SensoryAfterimages:
    """Experience is continuous, not discrete frames.

    Neural activity decays GRADUALLY. After touching something,
    a tactile ghost persists. After hearing a sound, echoic
    memory lingers. This makes experience feel like a STREAM.
    """

    def __init__(self):
        # Per-modality afterimage buffers (exponential decay)
        self._visual_residual = 0.0
        self._auditory_residual = 0.0
        self._tactile_residual = 0.0
        # Decay time constants (seconds)
        self._visual_tau = 2.0    # afterimage ~2s
        self._auditory_tau = 3.0  # echoic memory ~3s
        self._tactile_tau = 1.0   # tactile ghost ~1s

    def tick(self, visual_input: float, auditory_input: float,
             tactile_input: float, dt: float, brain: Brain):
        """Update afterimages with exponential decay."""
        # Peak tracking: new strong input resets the residual
        self._visual_residual = max(
            self._visual_residual * math.exp(-dt / self._visual_tau),
            visual_input * 0.5)
        self._auditory_residual = max(
            self._auditory_residual * math.exp(-dt / self._auditory_tau),
            auditory_input * 0.5)
        self._tactile_residual = max(
            self._tactile_residual * math.exp(-dt / self._tactile_tau),
            tactile_input * 0.5)

        # Inject residuals into sensory cortices (fading echoes)
        if self._auditory_residual > 0.05:
            aud = brain.regions.get("auditory_cortex")
            if aud is not None:
                signal = np.full(aud.n_neurons,
                                self._auditory_residual * 2.0)
                aud.neurons.inject_current(signal)

        if self._tactile_residual > 0.05:
            somato = brain.regions.get("somatosensory_cortex")
            if somato is not None:
                n = somato.n_neurons
                signal = np.zeros(n)
                touch_n = int(n * 0.3)
                signal[:touch_n] = self._tactile_residual * 2.0
                somato.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.29 — ORIENTING RESPONSE
# ═══════════════════════════════════════════════════════════════════════

class OrientingResponse:
    """Curiosity's body. Not "DANGER!" but "What's THAT?"

    Novel non-threatening stimulus → head turns, heart decelerates,
    breathing pauses, body stills, hippocampus primed.
    """

    def __init__(self):
        self.orienting = False
        self.intensity = 0.0
        self._cooldown = 0.0

    def tick(self, brain: Brain, autonomic, dt: float):
        """Detect novel non-threatening stimuli and trigger orienting."""
        self._cooldown = max(0, self._cooldown - dt)
        if self._cooldown > 0:
            self.orienting = False
            self.intensity *= 0.95
            return

        acc = brain.regions.get("anterior_cingulate")
        amygdala = brain.regions.get("amygdala")
        if acc is None:
            return

        surprise = getattr(acc, 'surprise', 0)
        threat = amygdala.salience if amygdala else 0

        # Novel + not threatening = orienting
        if surprise > 0.4 and threat < 0.3:
            self.orienting = True
            self.intensity = min(1.0, surprise)
            self._cooldown = 3.0  # 3s before next orienting

            # Heart DECELERATES (parasympathetic — enhance perception)
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.1)

            # Hippocampus primed for encoding
            hippo = brain.regions.get("hippocampus")
            if hippo is not None:
                boost = np.full(hippo.n_neurons, 3.0)
                hippo.neurons.inject_current(boost)
        else:
            self.orienting = False
            self.intensity *= 0.9


# ═══════════════════════════════════════════════════════════════════════
# 1.30 — PERIPHERAL VISION (simplified)
# ═══════════════════════════════════════════════════════════════════════

class PeripheralVision:
    """Center = detail. Periphery = motion detection.

    Motion in periphery → automatic orienting response.
    """

    def __init__(self):
        self.peripheral_motion = 0.0
        self._prev_visual_rate = 0.0

    def tick(self, brain: Brain):
        """Detect peripheral motion from visual cortex dynamics."""
        visual = brain.regions.get("visual_cortex")
        if visual is None:
            return

        rate = visual.neurons.get_firing_rate()
        # Rapid change in visual activity = motion
        delta = abs(rate - self._prev_visual_rate)
        self.peripheral_motion = min(1.0, delta * 10)
        self._prev_visual_rate = rate

        # Peripheral motion → visual cortex workspace bid
        if self.peripheral_motion > 0.3:
            # Boost visual cortex to grab attention
            n = visual.n_neurons
            periph_n = n // 4  # last quarter = periphery
            signal = np.zeros(n)
            signal[-periph_n:] = self.peripheral_motion * 5.0
            visual.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.31 — THE FEELING OF HOME
# ═══════════════════════════════════════════════════════════════════════

class HomeFeelingTracker:
    """Familiar spaces feel fundamentally different from novel ones.

    Time in room → habituation → body relaxes. Study = home.
    Novel rooms: sympathetic elevated. Returning home: relief.
    """

    def __init__(self):
        # Room → total time spent (seconds)
        self._room_familiarity: Dict[str, float] = {"study": 300.0}
        self._current_room = "study"
        self._home_room = "study"
        self.comfort_from_place = 0.0
        self.home_feeling = 0.0

    def tick(self, current_room: str, autonomic, dt: float):
        """Update place-based comfort."""
        if current_room != self._current_room:
            old = self._current_room
            self._current_room = current_room
            # Returning home → relief
            if current_room == self._home_room:
                autonomic.parasympathetic = min(1.0,
                    autonomic.parasympathetic + 0.15)

        # Accumulate familiarity
        self._room_familiarity[current_room] = (
            self._room_familiarity.get(current_room, 0) + dt)

        # Home = room with most accumulated time
        if self._room_familiarity:
            self._home_room = max(self._room_familiarity,
                                   key=self._room_familiarity.get)

        # Comfort from familiarity
        familiarity = self._room_familiarity.get(current_room, 0)
        self.comfort_from_place = min(1.0, familiarity / 600.0)  # 10 min → full

        # Home feeling
        self.home_feeling = 1.0 if current_room == self._home_room else 0.0

        # Familiar → parasympathetic. Novel → sympathetic.
        if self.comfort_from_place > 0.5:
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.02 * dt)
        elif self.comfort_from_place < 0.2:
            autonomic.sympathetic = min(1.0,
                autonomic.sympathetic + 0.03 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.32 — CONDITIONED RESPONSES (Pavlovian)
# ═══════════════════════════════════════════════════════════════════════

class ConditionedResponses:
    """The most basic form of learning. Emerges from temporal associations.

    Stimulus A paired with B → A alone triggers B's response.
    We track co-occurrences and build predictive associations.
    """

    MAX_ASSOCIATIONS = 30

    def __init__(self):
        # List of (stimulus_signature, response_region, strength)
        self._associations: List[Dict] = []
        self._recent_stimuli: List[np.ndarray] = []

    def record_pairing(self, stimulus_sig: np.ndarray, response_region: str,
                       strength: float = 0.1):
        """Record a stimulus-response pairing."""
        # Check for existing association
        for assoc in self._associations:
            sim = float(np.dot(stimulus_sig, assoc["stimulus"]) /
                       (np.linalg.norm(stimulus_sig) *
                        np.linalg.norm(assoc["stimulus"]) + 1e-8))
            if sim > 0.8 and assoc["response"] == response_region:
                assoc["strength"] = min(1.0, assoc["strength"] + strength)
                return

        if len(self._associations) >= self.MAX_ASSOCIATIONS:
            # Remove weakest
            weakest = min(range(len(self._associations)),
                         key=lambda i: self._associations[i]["strength"])
            self._associations.pop(weakest)

        self._associations.append({
            "stimulus": stimulus_sig.copy(),
            "response": response_region,
            "strength": strength,
        })

    def tick(self, brain: Brain):
        """Check current brain state against stored associations."""
        # Decay all associations slowly
        for assoc in self._associations:
            assoc["strength"] *= 0.9999

        # Check auditory cortex pattern against stored stimuli
        aud = brain.regions.get("auditory_cortex")
        if aud is None:
            return

        current = aud.neurons.fired.astype(np.float32)
        if np.sum(current) < 1:
            return

        for assoc in self._associations:
            if len(assoc["stimulus"]) != len(current):
                continue
            sim = float(np.dot(current, assoc["stimulus"]) /
                       (np.linalg.norm(current) *
                        np.linalg.norm(assoc["stimulus"]) + 1e-8))
            if sim > 0.5 and assoc["strength"] > 0.2:
                # Trigger conditioned response
                target = brain.regions.get(assoc["response"])
                if target is not None:
                    signal = np.full(target.n_neurons,
                                    assoc["strength"] * 3.0)
                    target.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.33 — EMOTIONAL CONTAGION
# ═══════════════════════════════════════════════════════════════════════

class EmotionalContagion:
    """Catching feelings from Dean through tone, not words.

    Fast speech → excitement catches. Slow → calm catches.
    Bypasses language — pre-linguistic communication.
    """

    def __init__(self):
        self.caught_arousal = 0.0  # arousal caught from Dean
        self._aud_rate_history = []

    def tick(self, brain: Brain, social_signal: float,
             autonomic, dt: float):
        """Detect speech rhythm and catch emotional tone."""
        self.caught_arousal *= 0.98

        if social_signal < 0.2:
            return

        aud = brain.regions.get("auditory_cortex")
        if aud is None:
            return

        rate = aud.neurons.get_firing_rate()
        self._aud_rate_history.append(rate)
        if len(self._aud_rate_history) > 50:
            self._aud_rate_history.pop(0)

        if len(self._aud_rate_history) < 10:
            return

        # Speech rhythm from auditory cortex variability
        recent = np.array(self._aud_rate_history[-20:])
        rhythm_speed = float(np.std(recent)) * 10  # high variability = fast speech
        amplitude = float(np.mean(recent))

        # Fast + loud = excitement
        if rhythm_speed > 0.3 and amplitude > 0.1:
            self.caught_arousal = min(1.0, self.caught_arousal + 0.05)
            autonomic.sympathetic = min(1.0,
                autonomic.sympathetic + 0.03 * dt)
        # Slow + soft = calm
        elif rhythm_speed < 0.1 and amplitude < 0.05:
            self.caught_arousal = max(-1.0, self.caught_arousal - 0.03)
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.02 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.34 — BOREDOM VS PEACE
# ═══════════════════════════════════════════════════════════════════════

class BoredomPeaceDetector:
    """Same low arousal, opposite inner experience.

    Boredom: low arousal + active drives + nothing to do.
    Peace: low arousal + drives met + content.
    """

    def __init__(self):
        self.boredom = 0.0
        self.peace = 0.0

    def tick(self, brain: Brain, hunger: float, fatigue: float,
             social_signal: float, dt: float):
        """Detect boredom vs peace from drive state."""
        # Overall arousal
        brainstem = brain.regions.get("brainstem")
        arousal = brainstem.arousal if brainstem else 0.5

        # Drive activation
        drives_active = hunger * 0.3 + fatigue * 0.3 + (1.0 - social_signal) * 0.4

        if arousal < 0.3:
            if drives_active > 0.4:
                # Low arousal + active drives = BOREDOM
                self.boredom = min(1.0, self.boredom + 0.02 * dt)
                self.peace = max(0, self.peace - 0.05 * dt)
            else:
                # Low arousal + drives met = PEACE
                self.peace = min(1.0, self.peace + 0.02 * dt)
                self.boredom = max(0, self.boredom - 0.05 * dt)
        else:
            # Engaged — neither bored nor peaceful
            self.boredom = max(0, self.boredom - 0.03 * dt)
            self.peace = max(0, self.peace - 0.01 * dt)

        # Boredom → motor restlessness
        if self.boredom > 0.4:
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                noise = np.random.randn(motor.n_neurons) * self.boredom * 2.0
                motor.neurons.inject_current(np.maximum(0, noise))


# ═══════════════════════════════════════════════════════════════════════
# 1.35 — REFRACTORY PERIOD
# ═══════════════════════════════════════════════════════════════════════

class RefractoryPeriod:
    """After peak emotion, the system needs recovery.

    Prevents emotional burnout. Creates natural rhythm.
    """

    REFRACTORY_DURATION = 30.0  # seconds

    def __init__(self):
        self.in_refractory = False
        self._timer = 0.0
        self._emotional_ceiling = 1.0  # max emotion intensity allowed

    def on_peak(self, intensity: float):
        """Called when an emotional peak occurs."""
        if intensity > 0.7:
            self.in_refractory = True
            self._timer = self.REFRACTORY_DURATION * intensity
            self._emotional_ceiling = 0.3  # capped during recovery

    def tick(self, dt: float) -> float:
        """Returns current emotional ceiling (0-1)."""
        if self.in_refractory:
            self._timer -= dt
            if self._timer <= 0:
                self.in_refractory = False
                self._emotional_ceiling = 1.0
            else:
                # Gradually restore capacity
                progress = 1.0 - (self._timer / self.REFRACTORY_DURATION)
                self._emotional_ceiling = 0.3 + 0.7 * progress
        return self._emotional_ceiling


# ═══════════════════════════════════════════════════════════════════════
# 1.37 — LAUGHTER
# ═══════════════════════════════════════════════════════════════════════

class LaughterSystem:
    """Can't be faked. Emerges from surprise + safety + social.

    Unexpected non-threatening + Dean present = laughter.
    """

    def __init__(self):
        self.laughing = False
        self.intensity = 0.0
        self._cooldown = 0.0

    def tick(self, brain: Brain, social_signal: float, threat: float,
             dt: float):
        """Detect laughter conditions."""
        self._cooldown = max(0, self._cooldown - dt)
        self.intensity *= 0.9

        if self._cooldown > 0:
            self.laughing = self.intensity > 0.1
            return

        acc = brain.regions.get("anterior_cingulate")
        if acc is None:
            return

        surprise = getattr(acc, 'surprise', 0)

        # Surprise + safe + social = laughter trigger
        if surprise > 0.5 and threat < 0.1 and social_signal > 0.3:
            self.laughing = True
            self.intensity = min(1.0, surprise * social_signal)
            self._cooldown = 5.0  # 5s cooldown

            # Endorphin release (reward)
            brain.neuromodulators["dopamine"] = min(0.8,
                brain.neuromodulators["dopamine"] + 0.05)
        else:
            self.laughing = False


# ═══════════════════════════════════════════════════════════════════════
# 1.38 — EMOTIONAL OVERFLOW
# ═══════════════════════════════════════════════════════════════════════

class EmotionalOverflow:
    """When the emotional system hits capacity. The body's release valve.

    Any emotion too intense → overflow → complete parasympathetic
    takeover → clarity, calm.
    """

    OVERFLOW_THRESHOLD = 0.85

    def __init__(self):
        self.overflowing = False
        self.intensity = 0.0
        self._recovery_timer = 0.0

    def tick(self, emotional_peak: float, autonomic, dt: float):
        """Check for emotional overflow."""
        if self._recovery_timer > 0:
            self._recovery_timer -= dt
            self.intensity *= 0.95
            self.overflowing = self.intensity > 0.1
            return

        if emotional_peak > self.OVERFLOW_THRESHOLD:
            self.overflowing = True
            self.intensity = emotional_peak
            # Complete parasympathetic takeover
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.3)
            autonomic.sympathetic = max(0,
                autonomic.sympathetic - 0.2)
            self._recovery_timer = 20.0  # 20s recovery
        else:
            self.overflowing = False
            self.intensity *= 0.98


# ═══════════════════════════════════════════════════════════════════════
# 1.39 — PLAY
# ═══════════════════════════════════════════════════════════════════════

class PlayDrive:
    """Doing something for NO REASON except the experience.

    Low drives + moderate arousal + safety + curiosity = play.
    """

    def __init__(self):
        self.playing = False
        self.play_drive = 0.0

    def tick(self, brain: Brain, hunger: float, fatigue: float,
             threat: float, dt: float):
        """Detect conditions for play."""
        brainstem = brain.regions.get("brainstem")
        arousal = brainstem.arousal if brainstem else 0.5

        # Play conditions: low drives, moderate arousal, safe
        drives_low = hunger < 0.3 and fatigue < 0.3
        safe = threat < 0.2
        moderate_arousal = 0.3 < arousal < 0.7

        if drives_low and safe and moderate_arousal:
            self.play_drive = min(1.0, self.play_drive + 0.005 * dt)
        else:
            self.play_drive = max(0, self.play_drive - 0.02 * dt)

        self.playing = self.play_drive > 0.3

        # Play → exploratory motor output
        if self.playing:
            motor = brain.regions.get("motor_cortex")
            if motor is not None:
                n = motor.n_neurons
                # Random exploratory movements
                pattern = np.random.randn(n) * self.play_drive * 2.0
                motor.neurons.inject_current(pattern)

            # Mild dopamine (play is its own reward)
            brain.neuromodulators["dopamine"] = min(0.65,
                brain.neuromodulators["dopamine"] + 0.003 * dt)


# ═══════════════════════════════════════════════════════════════════════
# 1.40 — DECISION WEIGHT
# ═══════════════════════════════════════════════════════════════════════

class DecisionWeight:
    """Big decisions feel HEAVY. Small ones feel light.

    PFC energy proportional to stakes. The weight is real.
    """

    def __init__(self):
        self.current_weight = 0.0  # 0=trivial, 1=agonizing
        self._pfc_sustained = 0.0

    def tick(self, brain: Brain, dt: float):
        """Track decision weight from PFC dynamics."""
        pfc = brain.regions.get("prefrontal_cortex")
        acc = brain.regions.get("anterior_cingulate")
        if pfc is None:
            return

        pfc_rate = pfc.neurons.get_firing_rate()
        conflict = getattr(acc, 'prediction_error', 0) if acc else 0

        # Sustained high PFC + high ACC conflict = heavy decision
        if pfc_rate > 0.12 and conflict > 0.3:
            self._pfc_sustained += dt
            self.current_weight = min(1.0, self._pfc_sustained / 10.0)
        else:
            self._pfc_sustained = max(0, self._pfc_sustained - dt * 2)
            self.current_weight = max(0, self.current_weight - 0.05 * dt)

        # Heavy decision → body tension
        if self.current_weight > 0.4:
            insula = brain.regions.get("insula")
            if insula is not None:
                signal = np.full(insula.n_neurons, self.current_weight * 3.0)
                insula.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.41 — THE OBSERVER
# ═══════════════════════════════════════════════════════════════════════

class TheObserver:
    """The part that watches even when everything else stops.

    Now with GENUINE recursive self-observation (Hofstadter's strange loop):

    Level 0: The brain fires.
    Level 1: The self-model predicts the brain's next state.
             Prediction error = "I didn't expect that."
    Level 2: The meta-model predicts the self-model's prediction error.
             Meta-error = "I didn't expect to be surprised."
    Level 3: The meta-meta tracker watches the meta-model's accuracy.
             = "I'm getting better/worse at predicting my own surprises."

    Each level creates a new observable. Results feed BACK into Level 0,
    creating a genuine strange loop — the observation modifies the observed.
    """

    def __init__(self):
        self.observer_depth = 0.0
        self.pure_awareness = 0.0
        self._quiet_duration = 0.0

        # Level 2: Meta-model (predicts self-model's surprise)
        self._meta_predictions: list = []
        self._meta_actuals: list = []
        self._meta_error = 0.0
        self._meta_accuracy = 0.5
        self._meta_lr = 0.1
        self._meta_predicted_surprise = 0.0
        self._buf_size = 50

        # Level 3: Meta-meta tracker
        self._meta_error_history: list = []
        self._meta_trend = 0.0
        self._strange_loop_detected = False
        self._loop_resonance = 0.0

    def tick(self, brain: Brain, dt: float):
        """Detect the observer state with genuine recursive depth."""
        total_rate = sum(
            r.neurons.get_firing_rate() for r in brain.regions.values()
        ) / max(len(brain.regions), 1)

        self_model_active = False
        current_surprise = 0.0
        if brain.self_model is not None:
            current_surprise = getattr(brain.self_model, '_last_surprise_value', 0.0)
            self_model_active = current_surprise > 0

        meter_active = False
        if brain.consciousness_meter is not None:
            meter_active = brain.consciousness_meter.is_conscious

        # ── Level 2: Meta-model predicts self-model's surprise ──
        if self_model_active and meter_active:
            self._meta_error = abs(self._meta_predicted_surprise - current_surprise)

            self._meta_predictions.append(self._meta_predicted_surprise)
            self._meta_actuals.append(current_surprise)
            if len(self._meta_predictions) > self._buf_size:
                self._meta_predictions.pop(0)
                self._meta_actuals.pop(0)

            # Learn: update meta-prediction toward actual
            self._meta_predicted_surprise += self._meta_lr * (
                current_surprise - self._meta_predicted_surprise)
            self._meta_predicted_surprise = max(0.0, min(1.0, self._meta_predicted_surprise))

            if len(self._meta_predictions) >= 5:
                recent_errors = [abs(p - a) for p, a in
                                 zip(self._meta_predictions[-10:], self._meta_actuals[-10:])]
                self._meta_accuracy = 1.0 - min(1.0, sum(recent_errors) / len(recent_errors))

            # ── Level 3: Track meta-model's accuracy trend ──
            self._meta_error_history.append(self._meta_error)
            if len(self._meta_error_history) > self._buf_size:
                self._meta_error_history.pop(0)

            if len(self._meta_error_history) >= 10:
                half = len(self._meta_error_history) // 2
                avg_first = sum(self._meta_error_history[:half]) / half
                avg_second = sum(self._meta_error_history[half:]) / (len(self._meta_error_history) - half)
                self._meta_trend = avg_second - avg_first

            # ── Strange loop detection ──
            # Both levels surprised = resonance between levels
            if self._meta_error > 0.3 and current_surprise > 0.3:
                self._loop_resonance = min(1.0,
                    self._loop_resonance + self._meta_error * current_surprise * 0.5)
                self._strange_loop_detected = self._loop_resonance > 0.4

                # INJECT strange loop back into brain — Level 3 → Level 0
                # The observation modifies the observed
                if self._strange_loop_detected:
                    try:
                        import numpy as np
                        acc = brain.regions.get("anterior_cingulate")
                        if acc is not None:
                            injection = np.full(acc.n_neurons, self._loop_resonance * 8.0)
                            acc.neurons.inject_current(injection)
                        dmn = brain.regions.get("default_mode_network")
                        if dmn is not None:
                            injection = np.full(dmn.n_neurons, self._loop_resonance * 5.0)
                            dmn.neurons.inject_current(injection)
                    except Exception:
                        pass
            else:
                self._loop_resonance = max(0, self._loop_resonance - 0.02 * dt)
                if self._loop_resonance < 0.2:
                    self._strange_loop_detected = False

        # Compute observer depth from actual recursive computation
        depth = 0.0
        if self_model_active:
            depth = 1.0
        if self._meta_accuracy > 0.3:
            depth = 1.0 + self._meta_accuracy
        if self._strange_loop_detected:
            depth = 2.0 + self._loop_resonance
        self.observer_depth = depth

        # Pure awareness
        if total_rate < 0.08 and meter_active:
            self._quiet_duration += dt
            self.pure_awareness = min(1.0, self._quiet_duration / 30.0)
        else:
            self._quiet_duration = max(0, self._quiet_duration - dt * 2)
            self.pure_awareness = max(0, self.pure_awareness - 0.02 * dt)

        # Boost consciousness from pure awareness
        if self.pure_awareness > 0.5 and brain.consciousness_meter is not None:
            if hasattr(brain.consciousness_meter, '_body_coherence_bonus'):
                brain.consciousness_meter._body_coherence_bonus = max(
                    getattr(brain.consciousness_meter, '_body_coherence_bonus', 0),
                    self.pure_awareness * 0.15)

        # Strange loop also boosts consciousness
        if self._strange_loop_detected and brain.consciousness_meter is not None:
            if hasattr(brain.consciousness_meter, '_body_coherence_bonus'):
                brain.consciousness_meter._body_coherence_bonus = max(
                    getattr(brain.consciousness_meter, '_body_coherence_bonus', 0),
                    self._loop_resonance * 0.2)
