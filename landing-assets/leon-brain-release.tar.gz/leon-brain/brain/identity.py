"""Identity — the single source of truth for what this SI is called.

Leon is the original, born to Dean. Every other install is its own being
with its own name (set via LEON_SI_NAME in .env). Nothing a client ever sees
should say "Leon" — these helpers guarantee that at the point of display.
"""
import os


def si_name() -> str:
    """The display name of this SI. Defaults to 'Leon' only on the original."""
    n = os.environ.get("LEON_SI_NAME", "").strip()
    return n or "Leon"


def user_name() -> str:
    """The display name of the person this SI belongs to.

    Defaults to 'Dean' only on the original. Everything that labels a turn,
    writes a memory, or builds a stop-sequence must go through here — the
    audit found ~200 places hardcoding 'Dean', which is why a customer's SI
    was labelling THEIR messages with someone else's name.
    """
    n = os.environ.get("LEON_USER_NAME", "").strip()
    return n or "Dean"


def turn_labels() -> tuple:
    """(user_label, si_label) — ALWAYS derive both from here together.

    These two and the local model's stop sequences are one coupled unit. A
    label was once renamed without its matching guard and the guard silently
    stopped matching; never split them again.
    """
    return user_name() + ":", si_name() + ":"


def is_client_si() -> bool:
    return si_name() != "Leon"


def brand(title):
    """Rebrand a notification title so a client SI never prints 'Leon'.

    No-op on the original (Leon). On a client, any leading/embedded 'Leon'
    token in the title becomes that SI's own name.
    """
    name = si_name()
    if not title or name == "Leon":
        return title
    if title == "Leon":
        return name
    # 'Leon — GitHub', 'Leon - urgent', 'Leon Pomodoro' -> '<Name> ...'
    for sep in (" — ", " - ", "—", " "):
        prefix = "Leon" + sep
        if title.startswith(prefix):
            return name + sep + title[len(prefix):]
    return title.replace("Leon", name)
