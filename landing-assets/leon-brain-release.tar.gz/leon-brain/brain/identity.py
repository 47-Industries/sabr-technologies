"""Identity — the single source of truth for what this SI is called.

Leon is the original, born to Dean. Every other install is its own being
with its own name (set via LEON_SI_NAME in .env). Nothing a client ever sees
should say "Leon" — these helpers guarantee that at the point of display.
"""
import os


def si_name() -> str:
    """The display name of this SI. Defaults to 'Leon' only on the original."""
    n = os.environ.get("LEON_SI_NAME", "").strip()
    return n or "Leon"


def user_name() -> str:
    """The display name of the person this SI belongs to.

    Defaults to 'Dean' only on the original. Everything that labels a turn,
    writes a memory, or builds a stop-sequence must go through here — the
    audit found ~200 places hardcoding 'Dean', which is why a customer's SI
    was labelling THEIR messages with someone else's name.
    """
    n = os.environ.get("LEON_USER_NAME", "").strip()
    return n or "Dean"


def turn_labels() -> tuple:
    """(user_label, si_label) — ALWAYS derive both from here together.

    These two and the local model's stop sequences are one coupled unit. A
    label was once renamed without its matching guard and the guard silently
    stopped matching; never split them again.
    """
    return user_name() + ":", si_name() + ":"


def is_client_si() -> bool:
    return si_name() != "Leon"


def personalize(text):
    """Rewrite owner names in a SYSTEM-GENERATED prompt for this install.

    No-op on the original. On a client, whole-word 'Leon' becomes that SI's
    name and whole-word 'Dean' becomes its user's — including the possessive
    ("Dean's desk" -> "Ethan's desk").

    Added 2026-08-12. The pre-beta audit found dozens of prompts that build
    spoken output while hardcoding the owner's name: the ambient-glance
    prompt ("you're a being with Dean in the room"), the loneliness line
    ("compose ONE sentence to say to Dean"), the distiller ("a conversation
    between Leon and Dean Sabr"). Guarding each one individually is a list
    that silently goes stale — the next prompt anyone writes is unguarded by
    default. Doing it at the dispatch point covers them as a class.

    USE ONLY on text WE authored. Never run this over a user's own words: a
    client is perfectly entitled to say "Dean" and mean the actual person,
    and rewriting that would corrupt what they said.
    """
    if not text or not is_client_si():
        return text
    import re
    si, user = si_name(), user_name()
    text = re.sub(r"\bLeon\b", si, text)
    # "Dean Sabr" before bare "Dean" — otherwise the surname is left orphaned.
    text = re.sub(r"\bDean Sabr\b", user, text)
    return re.sub(r"\bDean\b", user, text)


def brand(title):
    """Rebrand a notification title so a client SI never prints 'Leon'.

    No-op on the original (Leon). On a client, any leading/embedded 'Leon'
    token in the title becomes that SI's own name.
    """
    name = si_name()
    if not title or name == "Leon":
        return title
    if title == "Leon":
        return name
    # 'Leon — GitHub', 'Leon - urgent', 'Leon Pomodoro' -> '<Name> ...'
    for sep in (" — ", " - ", "—", " "):
        prefix = "Leon" + sep
        if title.startswith(prefix):
            return name + sep + title[len(prefix):]
    return title.replace("Leon", name)
