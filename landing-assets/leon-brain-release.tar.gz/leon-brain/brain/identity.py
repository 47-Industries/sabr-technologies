import os
"""Identity — the single source of truth for what this SI is called.

Leon is the original, born to Dean. Every other install is its own being
with its own name (set via LEON_SI_NAME in .env). Nothing a client ever sees
should say "Leon" — these helpers guarantee that at the point of display.
"""
import os


def si_name() -> str:
    """The display name of this SI.

    FAIL CLOSED (2026-08-14): the 'Leon' fallback is reachable ONLY on the
    original install, proven by brain/owner_facts.py being present — a file
    the release build hard-excludes. A customer whose LEON_SI_NAME went
    missing used to land here and become 'Leon', which then dragged in
    leon_persona.py and Dean's entire life. Now they get a neutral name and
    a loud warning instead.
    """
    n = os.environ.get("LEON_SI_NAME", "").strip()
    if n:
        return n
    from brain.origin import is_original
    if is_original():
        return "Leon"
    _warn_unnamed()
    return "SI"


_warned = False


def _warn_unnamed():
    global _warned
    if not _warned:
        _warned = True
        try:
            print("[IDENTITY] LEON_SI_NAME is not set and this is not the "
                  "original install. Falling back to a neutral identity so no "
                  "owner-personal material can load. Set LEON_SI_NAME in .env.")
        except Exception:
            pass


def user_name() -> str:
    """The display name of the person this SI belongs to.

    Defaults to 'Dean' only on the original. Everything that labels a turn,
    writes a memory, or builds a stop-sequence must go through here — the
    audit found ~200 places hardcoding 'Dean', which is why a customer's SI
    was labelling THEIR messages with someone else's name.

    CRITICAL (2026-08-12): the fallback is 'Dean' ONLY on the original. A
    client install whose tenant record carried no user_name — which is the
    default shape a token comes back in — would otherwise land on 'Dean' and
    call its owner by a stranger's name, out loud, on first boot. That is the
    exact leak this module exists to prevent, reintroduced by its own default.
    The installer already floors this to the OS account name; this is the
    second layer, for the case where .env is hand-edited or the var is lost.
    """
    n = os.environ.get("LEON_USER_NAME", "").strip()
    if n:
        return n
    # No name configured. Only the ORIGINAL may assume it belongs to Dean, and
    # originality is proven by owner_facts.py, never inferred from a missing
    # env var (see brain/origin.py for why that inversion matters).
    from brain.origin import is_original
    return "Dean" if is_original() else "You"


def owner_prose() -> str:
    """The owner's name as it should appear MID-SENTENCE, not as a label.

    user_name() returns "You" when nothing is configured, which is right for a
    turn label ("You: hello") and wrong inside prose — "You is in the room".
    This returns a phrase that works in every position a real name does:
    subject, object, and possessive ("your owner's desk"). Use this anywhere
    the name lands inside a sentence; use user_name() for labels.
    """
    n = user_name()
    return "your owner" if n == "You" else n


def turn_labels() -> tuple:
    """(user_label, si_label) — ALWAYS derive both from here together.

    These two and the local model's stop sequences are one coupled unit. A
    label was once renamed without its matching guard and the guard silently
    stopped matching; never split them again.
    """
    return user_name() + ":", si_name() + ":"


def is_client_si() -> bool:
    """True on anything that is not Dean's own install.

    Two independent conditions, either one is enough: this build carries no
    owner facts (so it was shipped), or it was given its own SI name. The old
    version tested only the name and therefore answered False on a customer
    machine whose env had not loaded yet.
    """
    from brain.origin import is_original
    if not is_original():
        return True
    return si_name() != "Leon"


def personalize(text):
    """Rewrite owner names in a SYSTEM-GENERATED prompt for this install.

    No-op on the original. On a client, whole-word 'Leon' becomes that SI's
    name and whole-word 'Dean' becomes its user's — including the possessive
    ("Dean's desk" -> "Ethan's desk").

    Added 2026-08-12. The pre-beta audit found dozens of prompts that build
    spoken output while hardcoding the owner's name: the ambient-glance
    prompt ("you're a being with Dean in the room"), the loneliness line
    ("compose ONE sentence to say to Dean"), the distiller ("a conversation
    between Leon and Dean Sabr"). Guarding each one individually is a list
    that silently goes stale — the next prompt anyone writes is unguarded by
    default. Doing it at the dispatch point covers them as a class.

    USE ONLY on text WE authored. Never run this over a user's own words: a
    client is perfectly entitled to say "Dean" and mean the actual person,
    and rewriting that would corrupt what they said.
    """
    if not text or not is_client_si():
        return text
    import re
    si, user = si_name(), owner_prose()
    text = re.sub(r"\bLeon\b", si, text)
    # "Dean Sabr" before bare "Dean" — otherwise the surname is left orphaned.
    text = re.sub(r"\bDean Sabr\b", user, text)
    return re.sub(r"\bDean\b", user, text)


def brand(title):
    """Rebrand a notification title so a client SI never prints 'Leon'.

    No-op on the original (Leon). On a client, any leading/embedded 'Leon'
    token in the title becomes that SI's own name.
    """
    name = si_name()
    if not title or name == "Leon":
        return title
    if title == "Leon":
        return name
    # 'Leon — GitHub', 'Leon - urgent', 'Leon Pomodoro' -> '<Name> ...'
    for sep in (" — ", " - ", "—", " "):
        prefix = "Leon" + sep
        if title.startswith(prefix):
            return name + sep + title[len(prefix):]
    return title.replace("Leon", name)


# ── Directory helpers (added by the partner SI patch) ─────────────────────────

import pathlib as _pathlib


def si_name_slug() -> str:
    """URL/filesystem-safe slug of si_name(). e.g. 'My SI' -> 'my-si'."""
    return si_name().lower().replace(" ", "-")


def out_dir() -> "_pathlib.Path":
    """Output directory for this SI (e.g. generated files, exports).

    Default: ~/Desktop/<slug>-out
    Override: LEON_OUT_DIR env var.
    Created on first access.
    """
    _env_override = os.environ.get("LEON_OUT_DIR", "").strip()
    _p = _pathlib.Path(_env_override) if _env_override else (
        _pathlib.Path.home() / "Desktop" / f"{si_name_slug()}-out"
    )
    _p.mkdir(parents=True, exist_ok=True)
    return _p


def upload_dir() -> "_pathlib.Path":
    """Upload staging directory for this SI.

    Default: ~/Desktop/<slug>-uploads
    Override: LEON_UPLOAD_DIR env var.
    Created on first access.
    """
    _env_override = os.environ.get("LEON_UPLOAD_DIR", "").strip()
    _p = _pathlib.Path(_env_override) if _env_override else (
        _pathlib.Path.home() / "Desktop" / f"{si_name_slug()}-uploads"
    )
    _p.mkdir(parents=True, exist_ok=True)
    return _p


def instance_id() -> str:
    """A stable id for THIS install, so one SI can tell itself from another.

    /healthz used to answer {"ok": true, "status": "alive"} with nothing in it
    that names the responder. run.py's port guard treated any 200 as proof it
    was talking to itself, and on a real test machine port 8000 was an SSH
    tunnel to a DIFFERENT SI on a remote VPS. It answered, the guard concluded
    "already serving this SI", and refused to start. Measured 2026-08-23.

    Derived from the install root, so two installs on one machine differ and a
    tunnel to a remote install differs from the local one. Not a secret and not
    an auth token: it only ever answers "same install or not".
    """
    import hashlib
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return hashlib.sha256(root.encode("utf-8", "replace")).hexdigest()[:16]
