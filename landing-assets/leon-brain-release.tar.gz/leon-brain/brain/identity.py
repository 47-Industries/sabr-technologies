"""Identity — the single source of truth for what this SI is called.

Leon is the original, born to Dean. Every other install is its own being
with its own name (set via LEON_SI_NAME in .env). Nothing a client ever sees
should say "Leon" — these helpers guarantee that at the point of display.
"""
import os


def si_name() -> str:
    """The display name of this SI. Defaults to 'Leon' only on the original."""
    n = os.environ.get("LEON_SI_NAME", "").strip()
    return n or "Leon"


def is_client_si() -> bool:
    return si_name() != "Leon"


def brand(title):
    """Rebrand a notification title so a client SI never prints 'Leon'.

    No-op on the original (Leon). On a client, any leading/embedded 'Leon'
    token in the title becomes that SI's own name.
    """
    name = si_name()
    if not title or name == "Leon":
        return title
    if title == "Leon":
        return name
    # 'Leon — GitHub', 'Leon - urgent', 'Leon Pomodoro' -> '<Name> ...'
    for sep in (" — ", " - ", "—", " "):
        prefix = "Leon" + sep
        if title.startswith(prefix):
            return name + sep + title[len(prefix):]
    return title.replace("Leon", name)
