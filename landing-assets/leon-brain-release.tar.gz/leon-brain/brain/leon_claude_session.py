"""
Leon persistent Claude session — one long-lived `claude -p` subprocess that
handles every text/voice turn, eliminating the 3-5s cold-start each turn used
to pay. After the first message, warm turns return in ~1-2s.

Wire:
    session = LeonClaudeSession(
        system_prompt=_LEON_SYSTEM_PROMPT_SHORT,
        mcp_config_json=_LEON_MCP_CONFIG_JSON,
        model="haiku",
    )
    for ev in session.ask(user_text):
        yield ev  # StreamEvent type=model/delta/sentence/tool_use/tool_result/done/error

Auto-restart on process death. Single-threaded turns (a lock serializes them).
Disable with LEON_PERSISTENT_CLAUDE=0 to fall back to the one-shot path.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional

log = logging.getLogger("leon-session")

# Re-use the responder's sentence regex so per-sentence TTS lines up with the
# rest of the pipeline. Imported lazily to avoid circular import.
_SENTENCE_END_RE: Optional[re.Pattern] = None
_StreamEvent = None  # type imported lazily


def _lazy_imports():
    global _SENTENCE_END_RE, _StreamEvent
    if _SENTENCE_END_RE is None:
        from brain.claude_api_responder import _SENTENCE_END_RE as _RE, StreamEvent as _SE
        _SENTENCE_END_RE = _RE
        _StreamEvent = _SE


@dataclass
class _TurnState:
    """Per-turn accumulator. Reader thread fills it; producer drains via queue."""
    response_chunks: List[str] = field(default_factory=list)
    sentence_buf: str = ""
    sentence_idx: int = 0
    active_tool: Optional[Dict] = None
    done: bool = False
    error: Optional[str] = None
    queue: "queue.Queue" = field(default_factory=queue.Queue)


#: How long one turn may hold the session before a waiter gives up. Generous
#: on purpose: a real tool-heavy turn can legitimately run for minutes, and a
#: false timeout would kill good work. This exists to break a WEDGE, not to
#: police slow turns — anything past this is a leak, not a long thought.
_SESSION_LOCK_TIMEOUT_S = float(os.environ.get("LEON_SESSION_LOCK_TIMEOUT_S", "300"))


class _BoundedLock:
    """A Lock whose `with` block refuses to wait forever.

    Drop-in for threading.Lock at the `with` sites, so the fix is one line at
    construction instead of a re-indent of every holder. On timeout it raises
    TimeoutError, which surfaces as a failed turn — recoverable — instead of a
    thread parked for the life of the process, which is not.
    """

    __slots__ = ("_l", "_t")

    def __init__(self, timeout: float):
        self._l = threading.Lock()
        self._t = timeout

    def __enter__(self):
        if not self._l.acquire(timeout=self._t):
            raise TimeoutError(
                f"claude session lock held >{self._t:.0f}s — treating as a "
                f"leaked turn and failing this one rather than blocking forever"
            )
        return self

    def __exit__(self, *_exc):
        try:
            self._l.release()
        except RuntimeError:
            pass  # already released; never mask the real exception
        return False

    # Some callers probe the lock directly.
    def locked(self) -> bool:
        return self._l.locked()


class LeonClaudeSession:
    """One persistent `claude -p` subprocess; serializes turns via a lock."""

    def __init__(
        self,
        system_prompt: str,
        mcp_config_json: Optional[str] = None,
        model: str = "haiku",
        effort: str = "low",
        tool_risk_map: Optional[Dict[str, str]] = None,
    ):
        _lazy_imports()
        self.system_prompt = system_prompt
        self.mcp_config_json = mcp_config_json
        self.model = model
        self.effort = effort
        self.tool_risk_map = tool_risk_map or {}

        self._proc: Optional[subprocess.Popen] = None
        self._system_prompt_path: Optional[str] = None
        self._reader: Optional[threading.Thread] = None
        # BOUNDED, not infinite. ask() yields from inside `with self._lock:`,
        # so any consumer that abandons the generator mid-turn strands this
        # lock held. With a plain Lock that is terminal: every later turn
        # blocks here forever, the server-level responder lock is never
        # released either, and the owner gets "give me a second" on every
        # message for the life of the process (measured on a customer Windows
        # box 2026-08-11 — two threads parked here, zero conversations in two
        # hours). The generator close() calls added the same day remove the
        # known leaks; this is the backstop for the ones not found yet. A
        # leaked lock should cost ONE turn, never the whole mind.
        self._lock = _BoundedLock(_SESSION_LOCK_TIMEOUT_S)
        self._turn: Optional[_TurnState] = None
        self._turn_lock = threading.Lock()  # protects self._turn
        self._dead = False
        self._cold_start_done = threading.Event()

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn the subprocess. Idempotent — no-op if already running."""
        with self._lock:
            if self._proc is not None and self._proc.poll() is None:
                return
            # Absolute path, never the bare name: a frozen launch-time PATH
            # (Aiden's box, 2026-08-29) or an npm claude.cmd on Windows
            # (CreateProcess only appends .exe) makes ["claude", ...] fail
            # while every which()-based health check passes.
            from brain import engine_health as _engine
            # System prompt goes through a FILE, never inline on argv.
            # Found on Aiden's Windows box (CYRUS, 2026-08-29): the npm
            # `claude` install there resolves to claude.CMD, a batch shim,
            # and Windows' cmd.exe caps a whole command line at 8,191 chars.
            # Leon's system prompt alone runs ~8,749 chars, so
            # `--system-prompt <text>` silently overflowed the shim on every
            # launch — the CLI never started, and the only symptom the owner
            # saw was the timeout handler's canned "still processing" reply,
            # for the SI's entire lifetime. A file path is a few dozen chars
            # regardless of prompt size, so this can't recur at any prompt
            # length, on any OS. One file per session start; stop() removes it.
            try:
                _sp_fd, self._system_prompt_path = tempfile.mkstemp(
                    prefix="leon-sysprompt-", suffix=".txt",
                    dir=tempfile.gettempdir())
                with os.fdopen(_sp_fd, "w", encoding="utf-8") as _f:
                    _f.write(self.system_prompt)
            except OSError as e:
                # Can't write a temp file at all -- fall back to inline argv
                # rather than fail to start outright. Rare (disk full / no
                # write perms on tmp), and inline at least works on platforms
                # without the shim cap.
                log.error("could not write system-prompt temp file (%s: %s); "
                          "falling back to inline --system-prompt", type(e).__name__, e)
                self._system_prompt_path = None
            argv = [
                _engine.resolve(), "-p",
                "--input-format", "stream-json",
                "--output-format", "stream-json",
                "--include-partial-messages",
                "--verbose",
                "--model", self.model,
                "--effort", self.effort,
                "--no-session-persistence",
            ]
            if self._system_prompt_path:
                argv += ["--system-prompt-file", self._system_prompt_path]
            else:
                argv += ["--system-prompt", self.system_prompt]
            # --fallback-model only makes sense when distinct from main.
            # Fall back to haiku (always available, separate weekly quota) —
            # NOT sonnet. Sonnet's weekly cap (resets Jun 18) combined with
            # fable access lapsing made the old fable→sonnet fallback 429 on
            # EVERY fable turn (2026-06-14). haiku is the safe floor.
            if self.model != "haiku":
                argv += ["--fallback-model", "haiku"]
            if self.mcp_config_json:
                argv += [
                    "--mcp-config", self.mcp_config_json,
                    # --strict-mcp-config: use ONLY the leon MCP server, ignore
                    # every account-level / claude.ai connector. The VPS CLI is
                    # logged into a shared Anthropic account,
                    # whose claude.ai Gmail connector was leaking KYLE's inbox
                    # into Leon when Dean asked for email (2026-06-13). Leon's
                    # real email path is the browser (browser_gmail_inbox_state
                    # → the owner's signed-in browser account on CDP 9222). allowedTools
                    # alone didn't block the managed connector; this does.
                    "--strict-mcp-config",
                    "--allowedTools", "mcp__leon__*",
                    "--permission-mode", "bypassPermissions",
                ]
            env = os.environ.copy()
            env.pop("ANTHROPIC_API_KEY", None)
            # Force claude's stdout to be LINE-buffered even when piped.
            # Node's claude binary detects TTY vs pipe and switches to block
            # buffering when piped — stdbuf overrides that via libstdbuf.so.
            # Without this, the system/init event sits in claude's stdout
            # buffer until enough output accumulates, and the reader thread
            # never sees it — `cold_start_done` never fires.
            # stdbuf is GNU coreutils — present on Linux, ABSENT on stock macOS.
            # Prepending it unconditionally made macOS clients FileNotFoundError
            # on `stdbuf` and mis-report it as "claude CLI not found in PATH"
            # (the brain never got a reasoning engine). Only wrap when it exists;
            # otherwise spawn claude directly (Mac loses line-buffering, not its
            # mind — the reader still drains, just in larger chunks).
            if shutil.which("stdbuf"):
                wrapped_argv = ["stdbuf", "-oL"] + argv
            else:
                wrapped_argv = argv
            # Windows: find_claude() often resolves to claude.cmd (npm's
            # global-install shim), which CreateProcess can't launch directly
            # under shell=False (WinError 193). No-op on Linux/Mac. See
            # engine_health.spawn_argv docstring — task 22, unverified until
            # exercised on real Windows.
            wrapped_argv = _engine.spawn_argv(wrapped_argv)
            try:
                self._proc = subprocess.Popen(
                    wrapped_argv,
                    # NOT "/tmp" — that is POSIX-only. On Windows it resolves
                    # to C:\tmp which does not exist, and Popen raises
                    # NotADirectoryError (WinError 267). That is a *sibling* of
                    # FileNotFoundError, not a subclass, so the handler below
                    # never caught it: the exception escaped unhandled, the
                    # session never marked itself dead, and every SI on Windows
                    # silently had no reasoning engine — response_start fired
                    # and no text ever came back. (Found on TEST1, 2026-08-10.)
                    cwd=tempfile.gettempdir(),
                    env=env,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                )
                # Drain stderr in a background thread so claude doesn't block on
                # a full pipe — but capture the last lines for diagnostics.
                self._stderr_tail: List[str] = []
                def _drain_stderr(p=self._proc, tail=self._stderr_tail):
                    try:
                        for line in p.stderr:
                            tail.append(line.rstrip())
                            if len(tail) > 50: tail.pop(0)
                    except Exception:
                        pass
                threading.Thread(target=_drain_stderr, daemon=True,
                                  name="leon-claude-stderr").start()
            except FileNotFoundError:
                self._dead = True
                log.error(
                    "claude CLI not found in PATH (looked for %r)",
                    wrapped_argv[0],
                )
                self._cleanup_system_prompt_file()
                return
            except OSError as e:
                # Catch-all for spawn failures that are NOT a missing binary:
                # bad cwd (NotADirectoryError / WinError 267), permission
                # denied, exec format error. These are siblings of
                # FileNotFoundError, so the clause above misses them. Before
                # this existed they escaped unhandled and the SI went mute with
                # no log line at all — the worst possible failure mode.
                self._dead = True
                log.error(
                    "failed to spawn claude CLI (%s: %s) argv=%r cwd=%r",
                    type(e).__name__, e, wrapped_argv, tempfile.gettempdir(),
                )
                self._cleanup_system_prompt_file()
                return
            self._dead = False
            self._reader = threading.Thread(target=self._read_loop, daemon=True,
                                             name="leon-claude-reader")
            self._reader.start()
            log.info("session started — pid=%s model=%s mcp=%s",
                     self._proc.pid, self.model, bool(self.mcp_config_json))

    def stop(self) -> None:
        with self._lock:
            self._dead = True
            if self._proc is not None:
                try:
                    self._proc.stdin.close()
                except Exception:
                    pass
                try:
                    self._proc.terminate()
                    self._proc.wait(timeout=2)
                except Exception:
                    try: self._proc.kill()
                    except Exception: pass
            self._proc = None
            self._cleanup_system_prompt_file()

    def _cleanup_system_prompt_file(self) -> None:
        if self._system_prompt_path:
            try:
                os.remove(self._system_prompt_path)
            except OSError:
                pass
            self._system_prompt_path = None

    def alive(self) -> bool:
        if self._dead or self._proc is None or self._proc.poll() is not None:
            return False
        # Also check reader thread — if it died, session is broken even if proc lives
        if self._reader is not None and not self._reader.is_alive():
            self._dead = True
            return False
        return True

    def interrupt(self) -> None:
        """Halt the in-flight turn NOW by killing the subprocess, so token
        generation (and Max-plan spend) stops the instant Dean hits Stop.
        The next ask() respawns a fresh subprocess.

        Safe to call from the consumer thread mid-turn: unlike stop() it does
        NOT take self._lock — the suspended ask() generator may still hold it,
        and acquiring it here would deadlock (same thread, non-reentrant lock).
        It just kills the process and flags the session dead so alive()→False.
        """
        self._dead = True
        proc = self._proc
        if proc is not None:
            try:
                proc.kill()
            except Exception:
                pass
        # Unblock a queue.get() the ask() generator may be parked on, so the
        # turn drains immediately instead of waiting out its timeout.
        turn = self._turn
        if turn is not None:
            try:
                turn.queue.put(None)
            except Exception:
                pass

    # ── Reader thread (one per subprocess) ───────────────────────────────

    def _read_loop(self) -> None:
        try:
            assert self._proc is not None
            # readline() instead of `for line in stdout` — the iterator does
            # read-ahead which can stall on a pipe that block-buffers, even
            # with bufsize=1. readline() returns as soon as a newline lands.
            while True:
                line = self._proc.stdout.readline()
                if not line:
                    if self._proc.poll() is not None:
                        break
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    evt = json.loads(line)
                except json.JSONDecodeError:
                    continue
                self._handle_event(evt)
        except Exception as e:
            log.warning("reader loop died: %s", e)
        finally:
            with self._turn_lock:
                if self._turn is not None and not self._turn.done:
                    # BUG (found alongside the not-logged-in preflight,
                    # 2026-08-25): this used to set `self._turn.error` and
                    # push only the bare `None` sentinel. `ask()`'s consumer
                    # loop treats `None` as "no more events, stop iterating"
                    # — it never looked at `.error`. So a subprocess that
                    # died mid-turn (not signed in, killed, crashed) ended
                    # the turn with ZERO events after the initial "model"
                    # event: no "error", no "done". The caller's for-loop
                    # ran zero iterations and the failure was invisible all
                    # the way up to the customer's chat window. Push an
                    # actual error event FIRST so every consumer of ask()
                    # gets a terminal event it can act on; the None sentinel
                    # still follows so the loop below still breaks.
                    tail = "; ".join(getattr(self, "_stderr_tail", [])[-3:])
                    reason = "claude subprocess exited mid-turn"
                    if tail:
                        reason += f" ({tail[:200]})"
                    self._turn.error = reason
                    self._turn.done = True
                    try:
                        self._turn.queue.put(
                            _StreamEvent(type="error", error=reason))
                    except Exception:
                        pass
                    self._turn.queue.put(None)
            self._dead = True

    def _emit(self, **kwargs) -> None:
        """Push a StreamEvent into the active turn's queue."""
        with self._turn_lock:
            if self._turn is None:
                return
            self._turn.queue.put(_StreamEvent(**kwargs))

    def _handle_event(self, evt: dict) -> None:
        t = evt.get("type")
        if t == "system" and evt.get("subtype") == "init":
            self._cold_start_done.set()
            return
        with self._turn_lock:
            turn = self._turn
        if turn is None:
            return

        if t == "stream_event":
            inner = evt.get("event", {})
            itype = inner.get("type")
            if itype == "content_block_start":
                cb = inner.get("content_block", {})
                if cb.get("type") == "tool_use":
                    turn.active_tool = {
                        "id": cb.get("id", ""),
                        "name": cb.get("name", "?"),
                        "input_json": "",
                        "emitted": False,
                    }
            elif itype == "content_block_delta":
                delta = inner.get("delta", {})
                dtype = delta.get("type")
                if dtype == "text_delta":
                    chunk = delta.get("text", "")
                    if chunk:
                        turn.response_chunks.append(chunk)
                        turn.sentence_buf += chunk
                        self._emit(type="delta", text=chunk)
                        # Emit any complete sentences in the buffer first.
                        while True:
                            m = _SENTENCE_END_RE.search(turn.sentence_buf)
                            if not m:
                                break
                            end = m.end()
                            sent = turn.sentence_buf[:end].strip()
                            if sent:
                                self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                turn.sentence_idx += 1
                            turn.sentence_buf = turn.sentence_buf[end:]
                        # EARLY-TTS: for the FIRST emission only, also split
                        # on a clause boundary (comma, em-dash, etc.) if the
                        # buffer is getting long. Lets the first 5-10 words
                        # speak while Claude finishes the rest. Subsequent
                        # chunks wait for full sentence boundaries so the
                        # cadence doesn't get choppy.
                        if turn.sentence_idx == 0 and len(turn.sentence_buf.split()) >= 6:
                            try:
                                from brain.claude_api_responder import _CLAUSE_BREAK_RE
                            except Exception:
                                _CLAUSE_BREAK_RE = None
                            if _CLAUSE_BREAK_RE:
                                m = _CLAUSE_BREAK_RE.search(turn.sentence_buf)
                                if m:
                                    end = m.end()
                                    sent = turn.sentence_buf[:end].strip()
                                    if sent and len(sent.split()) >= 4:
                                        self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                        turn.sentence_idx += 1
                                        turn.sentence_buf = turn.sentence_buf[end:]
                elif dtype == "input_json_delta" and turn.active_tool:
                    turn.active_tool["input_json"] += delta.get("partial_json", "")
            elif itype == "content_block_stop":
                at = turn.active_tool
                if at and not at.get("emitted"):
                    display = at["name"]
                    if display.startswith("mcp__leon__"):
                        display = display[len("mcp__leon__"):]
                    risk = self.tool_risk_map.get(display, "medium")
                    self._emit(
                        type="tool_use",
                        text=display,
                        tool_id=at["id"],
                        risk=risk,
                        full_text=at.get("input_json", ""),
                    )
                    at["emitted"] = True
        elif t == "user":
            msg = evt.get("message", {}) or {}
            for c in msg.get("content") or []:
                if isinstance(c, dict) and c.get("type") == "tool_result":
                    tid = c.get("tool_use_id", "")
                    cnt = c.get("content")
                    if isinstance(cnt, list) and cnt:
                        cnt = (cnt[0] or {}).get("text", "")
                    summary = str(cnt or "")[:280]
                    display = (turn.active_tool or {}).get("name", "tool") if turn.active_tool else "tool"
                    if display.startswith("mcp__leon__"):
                        display = display[len("mcp__leon__"):]
                    self._emit(
                        type="tool_result",
                        text=display,
                        tool_id=tid,
                        full_text=summary,
                    )
                    turn.active_tool = None
        elif t == "result":
            # Final tail flush
            tail = turn.sentence_buf.strip()
            if tail:
                self._emit(type="sentence", text=tail, index=turn.sentence_idx)
                turn.sentence_idx += 1
                turn.sentence_buf = ""
            full = "".join(turn.response_chunks).strip()
            if not full:
                full = (evt.get("result") or "").strip()
                if full:
                    self._emit(type="delta", text=full)
            if evt.get("is_error"):
                turn.error = evt.get("api_error_status") or "claude reported error"
                self._emit(type="error", error=turn.error)
            else:
                self._emit(type="done", full_text=full)
            with self._turn_lock:
                turn.done = True
                turn.queue.put(None)  # sentinel

    # ── Public turn API ──────────────────────────────────────────────────

    def ask(self, user_text: str, history_hint: str = "", timeout: float = 90.0) -> Iterator:
        """Yield StreamEvents for one user turn. Caller must consume the
        generator fully (or break early after `done`) — turns are serialized
        by a lock, so a stalled consumer blocks subsequent turns.
        """
        _lazy_imports()
        if not self.alive():
            self.start()
        if not self.alive():
            yield _StreamEvent(type="error", error="claude session unavailable")
            return

        with self._lock:
            # Don't wait for init — claude in --input-format stream-json mode
            # doesn't emit the system/init event until AFTER it reads a user
            # message from stdin. So write the message first; init lands
            # during the normal read loop. Liveness check is enough.
            if self._dead or not self.alive():
                yield _StreamEvent(type="error", error="claude session died before turn")
                return

            yield _StreamEvent(type="model", model=f"claude-{self.model}", tier="cli")
            turn = _TurnState()
            with self._turn_lock:
                self._turn = turn
            try:
                payload = json.dumps({
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": user_text}],
                    },
                })
                assert self._proc and self._proc.stdin
                self._proc.stdin.write(payload + "\n")
                self._proc.stdin.flush()
            except BrokenPipeError:
                # Kill the zombie subprocess — don't just mark dead
                try:
                    self.stop()
                except Exception:
                    self._dead = True
                yield _StreamEvent(type="error", error="claude pipe broken — session died")
                with self._turn_lock:
                    self._turn = None
                return
            except Exception as e:
                yield _StreamEvent(type="error", error=f"send failed: {e}")
                with self._turn_lock:
                    self._turn = None
                return

            t0 = time.time()
            while True:
                try:
                    ev = turn.queue.get(timeout=max(1.0, timeout - (time.time() - t0)))
                except queue.Empty:
                    yield _StreamEvent(type="error", error=f"turn timeout ({int(timeout)}s)")
                    # Subprocess likely hung — terminate so next call respawns.
                    self.stop()
                    break
                if ev is None:
                    break
                yield ev
                if ev.type in ("done", "error"):
                    break
            with self._turn_lock:
                self._turn = None


# ---------------------------------------------------------------------------
# Auth preflight
# ---------------------------------------------------------------------------
#
# WHY THIS EXISTS
# ---------------
# On Dean's Windows box (TEST1, 2026-08-10) the claude CLI was installed,
# on PATH, correct version -- and simply not signed in. Running it printed
# "Not logged in - Please run /login" and exited.
#
# Nothing in the brain checked for that. The SI accepted the user's message,
# emitted brain_response_start, and then produced NOTHING. Forever. No error,
# no log line, no hint. A customer types hello and watches a dead box.
#
# That is the single worst failure mode this product can have, because it is
# indistinguishable from "the AI is broken" when the actual fix is one click.
# Never let unauthenticated read as silence.

_NOT_LOGGED_IN_MARKERS = (
    "not logged in",
    "please run /login",
    "invalid api key",
    "authentication_error",
    "oauth token has expired",
)


def claude_auth_status(timeout: float = 45.0) -> dict:
    """Probe whether the claude CLI can actually answer.

    Returns {"ok": bool, "reason": str, "detail": str}. Never raises --
    a preflight that can throw is a preflight that gets wrapped in a bare
    except and silently ignored, which is how we got here.
    """
    # Same resolver the spawns use, so this probe can't pass on a binary
    # the runtime cannot launch (which() honours PATHEXT; CreateProcess
    # does not) or miss one that lives in a known install dir off PATH.
    try:
        from brain import engine_health as _engine
        exe = _engine.resolve(refresh=True)
        if exe == "claude":
            exe = None
    except Exception:
        exe = shutil.which("claude")
    if not exe:
        return {"ok": False, "reason": "cli_missing",
                "detail": "claude CLI not found on PATH or in any known install dir"}

    env = os.environ.copy()
    env.pop("ANTHROPIC_API_KEY", None)
    try:
        r = subprocess.run(
            [exe, "-p", "ping"],
            cwd=tempfile.gettempdir(),   # never "/tmp" -- see spawn note above
            env=env,
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "reason": "timeout",
                "detail": f"claude CLI did not respond within {int(timeout)}s"}
    except OSError as e:
        return {"ok": False, "reason": "spawn_failed",
                "detail": f"{type(e).__name__}: {e}"}

    blob = ((r.stdout or "") + "\n" + (r.stderr or "")).strip()
    low = blob.lower()
    if any(m in low for m in _NOT_LOGGED_IN_MARKERS):
        return {"ok": False, "reason": "not_logged_in",
                "detail": blob[:400] or "claude CLI reports it is not signed in"}
    if r.returncode != 0:
        return {"ok": False, "reason": "cli_error",
                "detail": f"exit {r.returncode}: {blob[:400]}"}
    if not blob:
        return {"ok": False, "reason": "empty_reply",
                "detail": "claude CLI exited 0 but produced no output"}
    return {"ok": True, "reason": "ok", "detail": blob[:200]}


def auth_status_message(status: dict, si_name: str = "Your SI") -> str:
    """Turn a failed preflight into something a NON-ENGINEER can act on.

    Deliberately plain language. The person reading this bought a product;
    they did not sign up to interpret "spawn_failed".
    """
    reason = (status or {}).get("reason", "")
    if reason == "not_logged_in":
        return (f"{si_name} is awake, but it can't reach Claude yet -- this "
                f"computer isn't signed in. Open a terminal, run: claude  "
                f"then use /login and sign in with your Claude account. "
                f"{si_name} will start thinking the moment that finishes.")
    if reason == "cli_missing":
        return (f"{si_name} is awake, but the Claude command isn't installed "
                f"on this computer, so it has nothing to think with.")
    if reason == "timeout":
        return (f"{si_name} is awake, but Claude isn't responding -- this is "
                f"usually no internet connection, or a firewall blocking it.")
    return (f"{si_name} is awake, but it can't reach Claude right now. "
            f"Details: {(status or {}).get('detail', 'unknown')}")
