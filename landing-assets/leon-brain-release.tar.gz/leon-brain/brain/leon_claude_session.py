"""
Leon persistent Claude session — one long-lived `claude -p` subprocess that
handles every text/voice turn, eliminating the 3-5s cold-start each turn used
to pay. After the first message, warm turns return in ~1-2s.

Wire:
    session = LeonClaudeSession(
        system_prompt=_LEON_SYSTEM_PROMPT_SHORT,
        mcp_config_json=_LEON_MCP_CONFIG_JSON,
        model="haiku",
    )
    for ev in session.ask(user_text):
        yield ev  # StreamEvent type=model/delta/sentence/tool_use/tool_result/done/error

Auto-restart on process death. Single-threaded turns (a lock serializes them).
Disable with LEON_PERSISTENT_CLAUDE=0 to fall back to the one-shot path.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional

log = logging.getLogger("leon-session")

# Re-use the responder's sentence regex so per-sentence TTS lines up with the
# rest of the pipeline. Imported lazily to avoid circular import.
_SENTENCE_END_RE: Optional[re.Pattern] = None
_StreamEvent = None  # type imported lazily


def _lazy_imports():
    global _SENTENCE_END_RE, _StreamEvent
    if _SENTENCE_END_RE is None:
        from brain.claude_api_responder import _SENTENCE_END_RE as _RE, StreamEvent as _SE
        _SENTENCE_END_RE = _RE
        _StreamEvent = _SE


@dataclass
class _TurnState:
    """Per-turn accumulator. Reader thread fills it; producer drains via queue."""
    response_chunks: List[str] = field(default_factory=list)
    sentence_buf: str = ""
    sentence_idx: int = 0
    active_tool: Optional[Dict] = None
    done: bool = False
    error: Optional[str] = None
    queue: "queue.Queue" = field(default_factory=queue.Queue)


class LeonClaudeSession:
    """One persistent `claude -p` subprocess; serializes turns via a lock."""

    def __init__(
        self,
        system_prompt: str,
        mcp_config_json: Optional[str] = None,
        model: str = "haiku",
        effort: str = "low",
        tool_risk_map: Optional[Dict[str, str]] = None,
    ):
        _lazy_imports()
        self.system_prompt = system_prompt
        self.mcp_config_json = mcp_config_json
        self.model = model
        self.effort = effort
        self.tool_risk_map = tool_risk_map or {}

        self._proc: Optional[subprocess.Popen] = None
        self._reader: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._turn: Optional[_TurnState] = None
        self._turn_lock = threading.Lock()  # protects self._turn
        self._dead = False
        self._cold_start_done = threading.Event()

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn the subprocess. Idempotent — no-op if already running."""
        with self._lock:
            if self._proc is not None and self._proc.poll() is None:
                return
            argv = [
                "claude", "-p",
                "--input-format", "stream-json",
                "--output-format", "stream-json",
                "--include-partial-messages",
                "--verbose",
                "--model", self.model,
                "--effort", self.effort,
                "--no-session-persistence",
                "--system-prompt", self.system_prompt,
            ]
            # --fallback-model only makes sense when distinct from main.
            # Fall back to haiku (always available, separate weekly quota) —
            # NOT sonnet. Sonnet's weekly cap (resets Jun 18) combined with
            # fable access lapsing made the old fable→sonnet fallback 429 on
            # EVERY fable turn (2026-06-14). haiku is the safe floor.
            if self.model != "haiku":
                argv += ["--fallback-model", "haiku"]
            if self.mcp_config_json:
                argv += [
                    "--mcp-config", self.mcp_config_json,
                    # --strict-mcp-config: use ONLY the leon MCP server, ignore
                    # every account-level / claude.ai connector. The VPS CLI is
                    # logged into a shared Anthropic account,
                    # whose claude.ai Gmail connector was leaking KYLE's inbox
                    # into Leon when Dean asked for email (2026-06-13). Leon's
                    # real email path is the browser (browser_gmail_inbox_state
                    # → Dean's deansabrwork@gmail.com on CDP 9222). allowedTools
                    # alone didn't block the managed connector; this does.
                    "--strict-mcp-config",
                    "--allowedTools", "mcp__leon__*",
                    "--permission-mode", "bypassPermissions",
                ]
            env = os.environ.copy()
            env.pop("ANTHROPIC_API_KEY", None)
            # Force claude's stdout to be LINE-buffered even when piped.
            # Node's claude binary detects TTY vs pipe and switches to block
            # buffering when piped — stdbuf overrides that via libstdbuf.so.
            # Without this, the system/init event sits in claude's stdout
            # buffer until enough output accumulates, and the reader thread
            # never sees it — `cold_start_done` never fires.
            # stdbuf is GNU coreutils — present on Linux, ABSENT on stock macOS.
            # Prepending it unconditionally made macOS clients FileNotFoundError
            # on `stdbuf` and mis-report it as "claude CLI not found in PATH"
            # (the brain never got a reasoning engine). Only wrap when it exists;
            # otherwise spawn claude directly (Mac loses line-buffering, not its
            # mind — the reader still drains, just in larger chunks).
            if shutil.which("stdbuf"):
                wrapped_argv = ["stdbuf", "-oL"] + argv
            else:
                wrapped_argv = argv
            try:
                self._proc = subprocess.Popen(
                    wrapped_argv,
                    cwd="/tmp",
                    env=env,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,
                )
                # Drain stderr in a background thread so claude doesn't block on
                # a full pipe — but capture the last lines for diagnostics.
                self._stderr_tail: List[str] = []
                def _drain_stderr(p=self._proc, tail=self._stderr_tail):
                    try:
                        for line in p.stderr:
                            tail.append(line.rstrip())
                            if len(tail) > 50: tail.pop(0)
                    except Exception:
                        pass
                threading.Thread(target=_drain_stderr, daemon=True,
                                  name="leon-claude-stderr").start()
            except FileNotFoundError:
                self._dead = True
                log.error("claude CLI not found in PATH")
                return
            self._dead = False
            self._reader = threading.Thread(target=self._read_loop, daemon=True,
                                             name="leon-claude-reader")
            self._reader.start()
            log.info("session started — pid=%s model=%s mcp=%s",
                     self._proc.pid, self.model, bool(self.mcp_config_json))

    def stop(self) -> None:
        with self._lock:
            self._dead = True
            if self._proc is not None:
                try:
                    self._proc.stdin.close()
                except Exception:
                    pass
                try:
                    self._proc.terminate()
                    self._proc.wait(timeout=2)
                except Exception:
                    try: self._proc.kill()
                    except Exception: pass
            self._proc = None

    def alive(self) -> bool:
        if self._dead or self._proc is None or self._proc.poll() is not None:
            return False
        # Also check reader thread — if it died, session is broken even if proc lives
        if self._reader is not None and not self._reader.is_alive():
            self._dead = True
            return False
        return True

    def interrupt(self) -> None:
        """Halt the in-flight turn NOW by killing the subprocess, so token
        generation (and Max-plan spend) stops the instant Dean hits Stop.
        The next ask() respawns a fresh subprocess.

        Safe to call from the consumer thread mid-turn: unlike stop() it does
        NOT take self._lock — the suspended ask() generator may still hold it,
        and acquiring it here would deadlock (same thread, non-reentrant lock).
        It just kills the process and flags the session dead so alive()→False.
        """
        self._dead = True
        proc = self._proc
        if proc is not None:
            try:
                proc.kill()
            except Exception:
                pass
        # Unblock a queue.get() the ask() generator may be parked on, so the
        # turn drains immediately instead of waiting out its timeout.
        turn = self._turn
        if turn is not None:
            try:
                turn.queue.put(None)
            except Exception:
                pass

    # ── Reader thread (one per subprocess) ───────────────────────────────

    def _read_loop(self) -> None:
        try:
            assert self._proc is not None
            # readline() instead of `for line in stdout` — the iterator does
            # read-ahead which can stall on a pipe that block-buffers, even
            # with bufsize=1. readline() returns as soon as a newline lands.
            while True:
                line = self._proc.stdout.readline()
                if not line:
                    if self._proc.poll() is not None:
                        break
                    continue
                line = line.strip()
                if not line:
                    continue
                try:
                    evt = json.loads(line)
                except json.JSONDecodeError:
                    continue
                self._handle_event(evt)
        except Exception as e:
            log.warning("reader loop died: %s", e)
        finally:
            with self._turn_lock:
                if self._turn is not None and not self._turn.done:
                    self._turn.error = "claude subprocess exited mid-turn"
                    self._turn.done = True
                    self._turn.queue.put(None)
            self._dead = True

    def _emit(self, **kwargs) -> None:
        """Push a StreamEvent into the active turn's queue."""
        with self._turn_lock:
            if self._turn is None:
                return
            self._turn.queue.put(_StreamEvent(**kwargs))

    def _handle_event(self, evt: dict) -> None:
        t = evt.get("type")
        if t == "system" and evt.get("subtype") == "init":
            self._cold_start_done.set()
            return
        with self._turn_lock:
            turn = self._turn
        if turn is None:
            return

        if t == "stream_event":
            inner = evt.get("event", {})
            itype = inner.get("type")
            if itype == "content_block_start":
                cb = inner.get("content_block", {})
                if cb.get("type") == "tool_use":
                    turn.active_tool = {
                        "id": cb.get("id", ""),
                        "name": cb.get("name", "?"),
                        "input_json": "",
                        "emitted": False,
                    }
            elif itype == "content_block_delta":
                delta = inner.get("delta", {})
                dtype = delta.get("type")
                if dtype == "text_delta":
                    chunk = delta.get("text", "")
                    if chunk:
                        turn.response_chunks.append(chunk)
                        turn.sentence_buf += chunk
                        self._emit(type="delta", text=chunk)
                        # Emit any complete sentences in the buffer first.
                        while True:
                            m = _SENTENCE_END_RE.search(turn.sentence_buf)
                            if not m:
                                break
                            end = m.end()
                            sent = turn.sentence_buf[:end].strip()
                            if sent:
                                self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                turn.sentence_idx += 1
                            turn.sentence_buf = turn.sentence_buf[end:]
                        # EARLY-TTS: for the FIRST emission only, also split
                        # on a clause boundary (comma, em-dash, etc.) if the
                        # buffer is getting long. Lets the first 5-10 words
                        # speak while Claude finishes the rest. Subsequent
                        # chunks wait for full sentence boundaries so the
                        # cadence doesn't get choppy.
                        if turn.sentence_idx == 0 and len(turn.sentence_buf.split()) >= 6:
                            try:
                                from brain.claude_api_responder import _CLAUSE_BREAK_RE
                            except Exception:
                                _CLAUSE_BREAK_RE = None
                            if _CLAUSE_BREAK_RE:
                                m = _CLAUSE_BREAK_RE.search(turn.sentence_buf)
                                if m:
                                    end = m.end()
                                    sent = turn.sentence_buf[:end].strip()
                                    if sent and len(sent.split()) >= 4:
                                        self._emit(type="sentence", text=sent, index=turn.sentence_idx)
                                        turn.sentence_idx += 1
                                        turn.sentence_buf = turn.sentence_buf[end:]
                elif dtype == "input_json_delta" and turn.active_tool:
                    turn.active_tool["input_json"] += delta.get("partial_json", "")
            elif itype == "content_block_stop":
                at = turn.active_tool
                if at and not at.get("emitted"):
                    display = at["name"]
                    if display.startswith("mcp__leon__"):
                        display = display[len("mcp__leon__"):]
                    risk = self.tool_risk_map.get(display, "medium")
                    self._emit(
                        type="tool_use",
                        text=display,
                        tool_id=at["id"],
                        risk=risk,
                        full_text=at.get("input_json", ""),
                    )
                    at["emitted"] = True
        elif t == "user":
            msg = evt.get("message", {}) or {}
            for c in msg.get("content") or []:
                if isinstance(c, dict) and c.get("type") == "tool_result":
                    tid = c.get("tool_use_id", "")
                    cnt = c.get("content")
                    if isinstance(cnt, list) and cnt:
                        cnt = (cnt[0] or {}).get("text", "")
                    summary = str(cnt or "")[:280]
                    display = (turn.active_tool or {}).get("name", "tool") if turn.active_tool else "tool"
                    if display.startswith("mcp__leon__"):
                        display = display[len("mcp__leon__"):]
                    self._emit(
                        type="tool_result",
                        text=display,
                        tool_id=tid,
                        full_text=summary,
                    )
                    turn.active_tool = None
        elif t == "result":
            # Final tail flush
            tail = turn.sentence_buf.strip()
            if tail:
                self._emit(type="sentence", text=tail, index=turn.sentence_idx)
                turn.sentence_idx += 1
                turn.sentence_buf = ""
            full = "".join(turn.response_chunks).strip()
            if not full:
                full = (evt.get("result") or "").strip()
                if full:
                    self._emit(type="delta", text=full)
            if evt.get("is_error"):
                turn.error = evt.get("api_error_status") or "claude reported error"
                self._emit(type="error", error=turn.error)
            else:
                self._emit(type="done", full_text=full)
            with self._turn_lock:
                turn.done = True
                turn.queue.put(None)  # sentinel

    # ── Public turn API ──────────────────────────────────────────────────

    def ask(self, user_text: str, history_hint: str = "", timeout: float = 90.0) -> Iterator:
        """Yield StreamEvents for one user turn. Caller must consume the
        generator fully (or break early after `done`) — turns are serialized
        by a lock, so a stalled consumer blocks subsequent turns.
        """
        _lazy_imports()
        if not self.alive():
            self.start()
        if not self.alive():
            yield _StreamEvent(type="error", error="claude session unavailable")
            return

        with self._lock:
            # Don't wait for init — claude in --input-format stream-json mode
            # doesn't emit the system/init event until AFTER it reads a user
            # message from stdin. So write the message first; init lands
            # during the normal read loop. Liveness check is enough.
            if self._dead or not self.alive():
                yield _StreamEvent(type="error", error="claude session died before turn")
                return

            yield _StreamEvent(type="model", model=f"claude-{self.model}", tier="cli")
            turn = _TurnState()
            with self._turn_lock:
                self._turn = turn
            try:
                payload = json.dumps({
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": [{"type": "text", "text": user_text}],
                    },
                })
                assert self._proc and self._proc.stdin
                self._proc.stdin.write(payload + "\n")
                self._proc.stdin.flush()
            except BrokenPipeError:
                # Kill the zombie subprocess — don't just mark dead
                try:
                    self.stop()
                except Exception:
                    self._dead = True
                yield _StreamEvent(type="error", error="claude pipe broken — session died")
                with self._turn_lock:
                    self._turn = None
                return
            except Exception as e:
                yield _StreamEvent(type="error", error=f"send failed: {e}")
                with self._turn_lock:
                    self._turn = None
                return

            t0 = time.time()
            while True:
                try:
                    ev = turn.queue.get(timeout=max(1.0, timeout - (time.time() - t0)))
                except queue.Empty:
                    yield _StreamEvent(type="error", error=f"turn timeout ({int(timeout)}s)")
                    # Subprocess likely hung — terminate so next call respawns.
                    self.stop()
                    break
                if ev is None:
                    break
                yield ev
                if ev.type in ("done", "error"):
                    break
            with self._turn_lock:
                self._turn = None
