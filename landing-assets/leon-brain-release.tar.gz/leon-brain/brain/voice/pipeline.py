"""
Full-duplex voice pipeline with barge-in.

Orchestrates VAD → STT → (handler) → TTS. Barge-in means: if the user
starts talking while the brain is speaking, we cut TTS playback instantly
and start listening again — like a phone call, not a walkie-talkie.

Usage:
    pipe = VoicePipeline(on_utterance=handle_user_said)
    pipe.start()  # begins listening
    pipe.feed_audio(pcm16_chunk)  # streaming input
    pipe.stop()

`on_utterance` is called with the finalized user transcript once VAD
detects end-of-speech. Whatever it returns is spoken back via TTS.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional

from brain.voice import audio_gate

from brain.voice.vad import VAD, VADState, VADResult
from brain.voice.stt import STT, STTResult
from brain.voice.tts import TTS, TTSResult


class PipelineState(str, Enum):
    IDLE = "idle"
    LISTENING = "listening"
    THINKING = "thinking"
    SPEAKING = "speaking"
    BARGED_IN = "barged_in"  # user interrupted while we were speaking


@dataclass
class UtteranceEvent:
    text: str
    start_ts: float
    end_ts: float
    duration_sec: float
    vad_state: str
    barge_in: bool = False


@dataclass
class PipelineStats:
    utterances: int = 0
    barge_ins: int = 0
    total_listen_sec: float = 0.0
    total_speak_sec: float = 0.0
    avg_response_ms: float = 0.0
    rejected_frames: int = 0   # frames that hit VAD but got filtered (e.g. desk taps)

    def to_dict(self) -> dict:
        return {
            "utterances": self.utterances,
            "barge_ins": self.barge_ins,
            "total_listen_sec": round(self.total_listen_sec, 2),
            "total_speak_sec": round(self.total_speak_sec, 2),
            "avg_response_ms": round(self.avg_response_ms, 2),
            "rejected_frames": self.rejected_frames,
        }


class VoicePipeline:
    """Full-duplex orchestrator. Thread-safe."""

    def __init__(
        self,
        on_utterance: Optional[Callable[[str], str]] = None,
        vad_prefer: Optional[str] = None,
        stt_prefer: Optional[str] = None,
        tts_prefer: Optional[str] = None,
        sample_rate: int = 16000,
        min_utterance_sec: float = 0.3,      # ignore utterances shorter than this (desk tap protection)
        silence_trailing_sec: float = 0.8,   # after N sec silence, finalize utterance
        tts_piper_model: Optional[str] = None,
        tts_elevenlabs_voice_id: Optional[str] = None,
    ):
        self.vad = VAD(prefer=vad_prefer)
        self.stt = STT(prefer=stt_prefer)
        self.tts = TTS(
            prefer=tts_prefer,
            piper_model=tts_piper_model,
            elevenlabs_voice_id=tts_elevenlabs_voice_id,
        )
        self.sample_rate = sample_rate
        self.min_utterance_sec = min_utterance_sec
        self.silence_trailing_sec = silence_trailing_sec
        self.on_utterance = on_utterance

        self.state = PipelineState.IDLE
        self.stats = PipelineStats()

        # Thread-safe buffer for incoming audio during utterance.
        # We track duration via sample count (audio-time) so that the
        # pipeline works correctly whether fed in real-time from a mic
        # or synchronously from a test harness.
        self._buffer = bytearray()
        self._utterance_samples: int = 0      # samples since utterance started
        self._silence_samples: int = 0        # consecutive silence samples
        # RLock (reentrant) so _finalize_utterance can call self.speak()
        # without deadlocking when the user's handler triggers TTS.
        self._lock = threading.RLock()
        self._on_audio_out: Optional[Callable[[bytes, int], None]] = None
        self._speaking_cancel = threading.Event()
        self._utterances: list = []

    # ---------- Public API ----------

    def start(self):
        """Move pipeline from IDLE -> LISTENING."""
        with self._lock:
            self.state = PipelineState.LISTENING
            self._buffer.clear()
            self._utterance_samples = 0
            self._silence_samples = 0

    def stop(self):
        """Halt everything."""
        with self._lock:
            self._speaking_cancel.set()
            self.state = PipelineState.IDLE

    def feed_audio(self, pcm16: bytes) -> Optional[UtteranceEvent]:
        """
        Feed a chunk of input audio. Returns UtteranceEvent if this chunk
        completes an utterance (i.e. user stopped talking).

        This is the heart of the full-duplex loop. Must be called with
        small chunks (~20ms = 640 bytes at 16kHz) for responsive VAD.

        Uses audio-time (sample count) rather than wall-clock for silence
        measurement, so tests can feed audio synchronously and behavior
        matches real-time mic input exactly.

        Concurrency (post-2026-06-08 audit fix #1): the pipeline lock is
        ONLY held for the fast VAD + buffer-mutation path. The slow
        finalize work (STT, Claude on_utterance, TTS speak) runs WITHOUT
        the lock — STT inline on the caller's thread, on_utterance + speak
        on a worker. This is what makes barge-in actually possible: while
        Leon is thinking or speaking, new mic chunks can still acquire
        the lock cheaply and trip barge-in detection.
        """
        if self.state == PipelineState.IDLE:
            return None

        vad_result = self.vad.feed(pcm16)
        chunk_samples = len(pcm16) // 2  # 16-bit mono
        silence_trailing_samples = int(self.silence_trailing_sec * self.sample_rate)
        min_utterance_samples = int(self.min_utterance_sec * self.sample_rate)

        # Snapshot to extract out of the lock; finalize runs outside.
        finalize_snapshot = None

        with self._lock:
            # Barge-in: if we're speaking and user starts talking, interrupt
            if self.state == PipelineState.SPEAKING and vad_result.state == VADState.SPEECH:
                self._speaking_cancel.set()
                self.state = PipelineState.BARGED_IN
                self.stats.barge_ins += 1

            if vad_result.state == VADState.SPEECH:
                # Reset silence counter; accumulate utterance samples
                if self._utterance_samples == 0:
                    self.state = PipelineState.LISTENING
                self._utterance_samples += chunk_samples
                self._silence_samples = 0
                self._buffer.extend(pcm16)
            else:
                # Silence frame
                if self._utterance_samples > 0:
                    self._buffer.extend(pcm16)
                    self._silence_samples += chunk_samples
                    if self._silence_samples >= silence_trailing_samples:
                        # Finalize utterance
                        speech_samples = self._utterance_samples
                        speech_duration = speech_samples / self.sample_rate
                        if speech_samples < min_utterance_samples:
                            # Too short — probably a desk tap or cough. Reject.
                            self.stats.rejected_frames += 1
                            self._buffer.clear()
                            self._utterance_samples = 0
                            self._silence_samples = 0
                        else:
                            # Snapshot data + reset state under the lock,
                            # then run the slow finalize work OUTSIDE.
                            finalize_snapshot = {
                                "audio": bytes(self._buffer),
                                "duration": speech_duration,
                                "end_ts": time.time(),
                                "barge": self.state == PipelineState.BARGED_IN,
                            }
                            self._buffer.clear()
                            self._utterance_samples = 0
                            self._silence_samples = 0
                            # Set state out-of-band so subsequent chunks
                            # know we are no longer LISTENING.
                            self.state = PipelineState.THINKING

        if finalize_snapshot is None:
            return None

        # Slow path runs without the lock so mic chunks can keep flowing
        # and barge-in detection stays alive.
        return self._finalize_utterance(
            finalize_snapshot["audio"],
            finalize_snapshot["duration"],
            finalize_snapshot["end_ts"],
            finalize_snapshot["barge"],
        )

    def speak(self, text: str) -> TTSResult:
        """Synthesize and return audio. State tracked for barge-in."""
        # Floor lock — never open the mouth while Dean holds the mic.
        try:
            from brain import audio_daemon as _ad
            _ad.await_floor()
        except Exception:
            pass
        with self._lock:
            self.state = PipelineState.SPEAKING
            self._speaking_cancel.clear()
        t0 = time.time()
        result = self.tts.speak(text)
        self.stats.total_speak_sec += result.duration_sec

        # ── SELF-ECHO GATE (B0) — the mouth is about to open ────────────
        # Register this utterance with the SHARED ledger before a single
        # sample leaves the speaker. wake_word.py already publishes here;
        # this path did not, which is why a chunk recorded during playback
        # could be consumed after `_speaking_cancel` cleared and pass clean.
        # note_spoken_text() supplies the text fingerprint; open_playback()
        # supplies the mouth-open interval. Both are needed: the gate
        # rejects only when text overlap AND capture position agree.
        _pb = None
        try:
            audio_gate.note_spoken_text(text)
            _pb = audio_gate.open_playback(
                expected_duration_s=result.duration_sec, text=text)
        except Exception as e:
            print(f"[VOICE] audio_gate register failed (echo gate degraded): {e}")

        # Hand off to audio-out callback if registered
        if self._on_audio_out:
            try:
                self._on_audio_out(result.wav_bytes, result.sample_rate)
            except Exception as e:
                print(f"[VOICE] audio_out callback error: {e}")

        if _pb is not None:
            try:
                audio_gate.close_playback(_pb)
            except Exception:
                pass
        with self._lock:
            if self.state == PipelineState.SPEAKING:  # not barged-in
                self.state = PipelineState.LISTENING
        return result

    def _quarantine(self, text: str, rec_start: float, duration: float,
                    score: float) -> None:
        """A turn we could not attribute to the operator. Logged, never promoted.

        B0: an echoed imperative ("go ahead", "ship it") promoted to a user
        turn is self-manufactured authorization under the autonomy rule. The
        row exists so a silent drop is never indistinguishable from a turn
        that never happened.
        """
        import json as _json, os as _os
        rec = {
            "ts": time.time(), "event": "voice_quarantine",
            "reason": "self_echo", "text_preview": (text or "")[:120],
            "record_start_ts": rec_start, "duration_s": duration,
            "echo_overlap": round(float(score), 3),
            "promoted_to_user_turn": False,
        }
        print(f"[VOICE] QUARANTINED self-echo (overlap {score:.2f}): {text[:60]!r}")
        try:
            d = _os.environ.get("LEON_BRAIN_STATE", "/opt/leon-brain/brain_state")
            _os.makedirs(d, exist_ok=True)
            with open(_os.path.join(d, "voice_quarantine.jsonl"), "a") as fh:
                fh.write(_json.dumps(rec) + "\n")
        except Exception:
            pass

    def set_audio_out(self, callback: Callable[[bytes, int], None]):
        """Register a callback that receives WAV bytes + sample rate to play."""
        self._on_audio_out = callback

    # ---------- Internal ----------

    def _finalize_utterance(
        self, audio: bytes, duration: float, end_ts: float, barge: bool
    ) -> UtteranceEvent:
        """Run STT inline (caller wants the event back with text), then
        kick on_utterance + speak to a worker thread so subsequent mic
        chunks can flow through feed_audio without queuing.

        State is THINKING on entry (set by feed_audio under the lock).
        Worker resets state to LISTENING on completion.
        """
        # STT — inline so the returned UtteranceEvent carries text.
        # No lock held here; only one in-flight finalize at a time per
        # mic feeder (utterances don't overlap by construction).
        t_stt = time.time()
        try:
            stt = self.stt.transcribe(audio, self.sample_rate)
        except Exception as e:
            print(f"[VOICE] STT failed: {e}")
            # Reset state and bail with an empty event so caller sees the
            # silence-end but the worker isn't spawned with junk.
            with self._lock:
                if self.state == PipelineState.THINKING:
                    self.state = PipelineState.LISTENING
            return UtteranceEvent(
                text="", start_ts=end_ts - duration, end_ts=end_ts,
                duration_sec=duration, vad_state=self.vad.backend_name,
                barge_in=barge,
            )
        stt_ms = (time.time() - t_stt) * 1000

        with self._lock:
            self.stats.utterances += 1
            self.stats.total_listen_sec += duration
            prev_avg = self.stats.avg_response_ms
            n = self.stats.utterances
            self.stats.avg_response_ms = ((prev_avg * (n - 1)) + stt_ms) / n

        # ── SELF-ECHO GATE (B0) — judged at RECORD time, fails CLOSED ───
        # `end_ts - duration` is when this audio STARTED being captured, not
        # when it was consumed. That distinction is the whole bug: a chunk
        # recorded while Leon was speaking must be rejected no matter how
        # late STT gets to it.
        rec_start = end_ts - duration
        quarantined = False
        echo_score = 0.0
        if stt.text:
            try:
                quarantined, echo_score = audio_gate.transcript_is_self_echo_at(
                    stt.text, rec_start, span_s=duration)
            except Exception as e:
                # Cannot decide => cannot attribute. An unattributable turn
                # must never become an operator instruction.
                print(f"[VOICE] echo gate error — quarantining turn: {e}")
                quarantined = True
        if quarantined:
            self._quarantine(stt.text, rec_start, duration, echo_score)

        event = UtteranceEvent(
            text=stt.text,
            start_ts=end_ts - duration,
            end_ts=end_ts,
            duration_sec=duration,
            vad_state=self.vad.backend_name,
            barge_in=barge,
        )
        with self._lock:
            self._utterances.append(event)

        # Hand off on_utterance + speak to a worker so this call returns
        # immediately. Subsequent feed_audio calls only contend on the
        # cheap VAD/buffer lock — barge-in detection (which only fires
        # when state==SPEAKING) becomes meaningful.
        if self.on_utterance and stt.text and not quarantined:
            threading.Thread(
                target=self._handler_worker,
                args=(stt.text,),
                name="voice-handler",
                daemon=True,
            ).start()
        else:
            # No handler or empty STT — just go back to LISTENING.
            with self._lock:
                if self.state == PipelineState.THINKING:
                    self.state = PipelineState.LISTENING

        return event

    def _handler_worker(self, user_text: str):
        """Background thread: run on_utterance handler, then speak the
        reply. State transitions: THINKING (already set) → SPEAKING
        (via self.speak) → LISTENING (set on exit).

        Errors are logged but never raised — this is a daemon thread
        and a crash here would silently kill the response path.
        """
        try:
            reply = self.on_utterance(user_text)
            if reply:
                # speak() handles state SPEAKING→LISTENING transitions
                # and respects _speaking_cancel for barge-in.
                self.speak(reply)
        except Exception as e:
            print(f"[VOICE] on_utterance handler error: {e}")
        finally:
            with self._lock:
                if self.state in (PipelineState.THINKING, PipelineState.BARGED_IN):
                    self.state = PipelineState.LISTENING

    def recent_utterances(self, limit: int = 20) -> list:
        return [
            {
                "text": u.text,
                "start_ts": u.start_ts,
                "end_ts": u.end_ts,
                "duration_sec": round(u.duration_sec, 2),
                "vad_state": u.vad_state,
                "barge_in": u.barge_in,
            }
            for u in self._utterances[-limit:]
        ]

    def status(self) -> dict:
        return {
            "state": self.state.value,
            "vad_backend": self.vad.backend_name,
            "stt_backend": self.stt.backend_name,
            "tts_backend": self.tts.backend_name,
            "sample_rate": self.sample_rate,
            "stats": self.stats.to_dict(),
            "recent_utterances": self.recent_utterances(5),
        }
