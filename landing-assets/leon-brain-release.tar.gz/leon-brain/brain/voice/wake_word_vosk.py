"""
Vosk-backed wake word listener — supports ARBITRARY phrases, including
"leon" or "hey leon", because Vosk runs free-form streaming ASR rather
than relying on a pre-trained per-phrase model.

Tradeoff vs openWakeWord: ~3x the CPU (still <10% of one core on a
modern desktop with the small en-us model) and ~500ms slower wake
latency. Worth it: the wake phrase actually matches the brain's name.

Same public interface as `brain.voice.wake_word.WakeWordListener` so
the orchestrator and server endpoints don't care which backend is in
use — pick via env var:

    LEON_WAKE_BACKEND=vosk            (default — for "hey leon")
    LEON_WAKE_BACKEND=openwakeword    (legacy — for "hey jarvis")
    LEON_WAKE_PHRASES="hey leon|leon" (pipe-separated, lowercase)
    LEON_VOSK_MODEL=/path/to/vosk-model-small-en-us-0.15
"""

from __future__ import annotations

import json
import os
import queue
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

# Reuse types from the openWakeWord backend so the orchestrator's
# UtteranceCapture handling Just Works regardless of which listener it's
# wired to.
from brain.voice.wake_word import (
    SAMPLE_RATE, CHUNK_SAMPLES, UTT_MAX_SEC, UTT_SILENCE_END_MS,
    UTT_PRE_ROLL_MS, WakeEvent, UtteranceCapture, pcm16_to_wav_bytes,
    AdaptiveVoiceFloor, utterance_grace_ms,
)
from brain.voice import audio_gate
from brain.voice.audio_gate import TimedChunk


def chunk_is_gated(chunk: TimedChunk, now: Optional[float] = None) -> bool:
    """Should this captured chunk be thrown away before wake detection?

    The whole self-hearing fix in one predicate: the answer depends on
    WHEN THE CHUNK WAS RECORDED (`chunk.ts`), never on when it was pulled
    off the queue. The old code asked "is TTS playing right now?" at
    consume time, so a chunk recorded mid-sentence that got consumed a
    few hundred ms after playback ended sailed through and fired the wake
    on Leon's own voice. Kept module-level so the regression test can
    exercise the exact decision the capture loop makes.
    """
    return audio_gate.chunk_is_speaker(chunk, now=now)


_DEFAULT_MODEL_REL = "brain_state/voice/vosk/vosk-model-small-en-us-0.15"

_VOSK_MODEL_URL = (
    "https://alphacephei.com/vosk/models/"
    "vosk-model-small-en-us-0.15.zip"
)


def _ensure_vosk_model(model_path: str) -> bool:
    """Download + unzip the small en-US Vosk model to model_path if missing.
    Returns True if the model dir exists afterward. Best-effort, idempotent —
    safe to call from multiple inits (uses a temp file + atomic-ish rename)."""
    import urllib.request
    import zipfile
    import tempfile
    import shutil

    if os.path.isdir(model_path):
        return True
    parent = os.path.dirname(os.path.abspath(model_path))
    try:
        os.makedirs(parent, exist_ok=True)
    except OSError as e:
        print(f"[WAKE-VOSK] cannot create model dir {parent}: {e}", flush=True)
        return False
    print(f"[WAKE-VOSK] model missing — downloading (~40MB) from "
          f"{_VOSK_MODEL_URL}", flush=True)
    tmp_zip = None
    try:
        fd, tmp_zip = tempfile.mkstemp(suffix=".zip", dir=parent)
        os.close(fd)
        req = urllib.request.Request(
            _VOSK_MODEL_URL, headers={"User-Agent": "leon-brain/1.0"})
        with urllib.request.urlopen(req, timeout=120) as r, open(tmp_zip, "wb") as f:
            shutil.copyfileobj(r, f)
        with zipfile.ZipFile(tmp_zip) as z:
            z.extractall(parent)
        # The zip extracts to a folder named exactly vosk-model-small-en-us-0.15.
        ok = os.path.isdir(model_path)
        if ok:
            print(f"[WAKE-VOSK] model ready at {model_path}", flush=True)
        else:
            print(f"[WAKE-VOSK] unzip did not produce {model_path}", flush=True)
        return ok
    except Exception as e:
        print(f"[WAKE-VOSK] model auto-download failed: "
              f"{type(e).__name__}: {e}", flush=True)
        return False
    finally:
        if tmp_zip and os.path.exists(tmp_zip):
            try: os.remove(tmp_zip)
            except OSError: pass
# Bare "leon" was too false-fire-prone (matches "alone", "lemon", "lean",
# audio from speakerphone calls etc.). Default to the full phrase only;
# users can still opt into bare phrases via LEON_WAKE_PHRASES.
_DEFAULT_PHRASES = ("hey leon",)
_PHRASE_COOLDOWN_S = 2.5
# Silero VAD gate — only run Vosk on chunks where Silero says voice is
# present. Cuts CPU and (more importantly) cuts false fires from TV /
# music / phone speakers / desk thumps. Threshold tuned conservatively;
# a value below 0.5 means "definitely not speech".
_VAD_THRESHOLD = 0.5


def _project_root() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


class _SileroVADGate:
    """Thin wrapper around the openWakeWord-bundled Silero VAD ONNX so we
    can quickly screen out non-voiced audio before paying Vosk's cost.

    The model expects 30ms / 480-sample chunks at 16kHz, but we feed it
    larger 80ms / 1280-sample chunks (matching openWakeWord's own usage
    pattern) and average the per-window confidences.

    Loads lazily — if onnxruntime or the model file is missing, the
    gate becomes a passthrough (`is_speech` always True) so wake
    detection still works, just without the false-fire defense.
    """
    def __init__(self):
        self._sess = None
        self._h = None
        self._c = None
        self._available = False
        try:
            import onnxruntime as ort
            import numpy as np
            import openwakeword as _ow
            model_path = os.path.join(
                os.path.dirname(_ow.__file__), "resources", "models",
                "silero_vad.onnx",
            )
            if os.path.exists(model_path):
                # Single non-spinning thread: ORT's default intra-op pool
                # spin-waits between inferences, and at one inference per
                # 80ms chunk the spinners never park — measured 429% CPU
                # vs 1% with this config. The VAD model is tiny; one
                # thread is plenty.
                so = ort.SessionOptions()
                so.intra_op_num_threads = 1
                so.inter_op_num_threads = 1
                so.add_session_config_entry(
                    "session.intra_op.allow_spinning", "0")
                self._sess = ort.InferenceSession(
                    model_path, sess_options=so,
                    providers=["CPUExecutionProvider"],
                )
                self._h = np.zeros((2, 1, 64), dtype=np.float32)
                self._c = np.zeros((2, 1, 64), dtype=np.float32)
                self._available = True
        except Exception as e:
            print(f"[WAKE-VOSK] Silero VAD unavailable: {e}")

    @property
    def available(self) -> bool:
        return self._available

    def is_speech(self, pcm16_chunk: bytes, threshold: float = _VAD_THRESHOLD) -> bool:
        """Return True if any 30ms slice in this chunk looks like speech.
        When the model is unavailable, default-allow."""
        if not self._available:
            return True
        try:
            import numpy as np
            samples = np.frombuffer(pcm16_chunk, dtype=np.int16).astype(np.float32) / 32768.0
            sr = np.array(16000, dtype=np.int64)
            # Process in 480-sample slices (Silero's preferred frame size)
            best = 0.0
            for i in range(0, len(samples) - 480 + 1, 480):
                frame = samples[i:i + 480].reshape(1, -1)
                out, self._h, self._c = self._sess.run(
                    None,
                    {"input": frame, "sr": sr, "h": self._h, "c": self._c},
                )
                conf = float(out[0][0])
                if conf > best:
                    best = conf
            return best >= threshold
        except Exception as e:
            print(f"[WAKE-VOSK] VAD inference err: {e}")
            return True


class VoskWakeWordListener:
    """Mic listener that fires `on_wake` when the partial transcript
    contains any configured wake phrase. After firing, captures the
    follow-up utterance via the same VAD / silence logic as the
    openWakeWord listener.

    The class deliberately mirrors `WakeWordListener` field-by-field so
    the orchestrator can swap one for the other.
    """

    def __init__(
        self,
        wake_word: Optional[str] = None,             # cosmetic display name
        on_wake: Optional[Callable[[WakeEvent], None]] = None,
        on_utterance: Optional[Callable[[UtteranceCapture], None]] = None,
        threshold: float = 0.5,                      # unused; here for API parity
        custom_model_path: Optional[str] = None,     # unused
        phrases: Optional[List[str]] = None,
        model_path: Optional[str] = None,
    ):
        _si = (os.environ.get("LEON_SI_NAME") or "Leon").strip().lower() or "leon"
        self.wake_word = (wake_word or os.environ.get("LEON_WAKE_WORD")
                          or f"hey {_si}")
        self.threshold = threshold
        self.on_wake = on_wake
        self.on_utterance = on_utterance

        # Resolve phrases: env override > ctor arg > default
        env_phrases = os.environ.get("LEON_WAKE_PHRASES", "").strip()
        if env_phrases:
            phrase_list = [p.strip().lower() for p in env_phrases.split("|") if p.strip()]
        elif phrases:
            phrase_list = [p.strip().lower() for p in phrases if p.strip()]
        else:
            # Default to the SI's OWN name — "hey jarvis"/"jarvis" — so a fresh
            # client install responds to its own name off the rip, not "leon".
            phrase_list = [f"hey {_si}", _si]
        # Sort longest-first so multi-word phrases match before single words
        self.phrases = sorted(phrase_list, key=len, reverse=True)
        # Compile a regex that matches any phrase as whole-word(s)
        self._phrase_re = re.compile(
            r"\b(?:" + "|".join(re.escape(p) for p in self.phrases) + r")\b",
            re.IGNORECASE,
        )

        # Resolve Vosk model path
        env_model = os.environ.get("LEON_VOSK_MODEL", "").strip()
        if env_model:
            self.model_path = env_model
        elif model_path:
            self.model_path = model_path
        else:
            self.model_path = os.path.join(_project_root(), _DEFAULT_MODEL_REL)

        self._vosk_model = None
        self._recognizer = None
        self._vad: Optional[_SileroVADGate] = None
        self._stream = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._paused = threading.Event()
        self._last_wake_ts = 0.0
        self._enabled = False
        self._frames_gated = 0   # frames blocked by VAD (for stats)

        self.stats = {
            "started_at": 0.0,
            "frames_processed": 0,
            "wake_count": 0,
            "last_wake_ts": 0.0,
            "last_wake_score": 0.0,
            "last_wake_word": "",
            "best_score_recent": 0.0,
            "available": False,
            "error": None,
            "backend": "vosk",
        }

    # ── Status helpers (mirror openWakeWord backend) ─────────────────────
    @property
    def active(self) -> bool:
        return self._enabled and not self._paused.is_set()

    def is_running(self) -> bool:
        return self._enabled

    def get_state(self) -> dict:
        s = dict(self.stats)
        s["wake_word"] = self.wake_word
        s["phrases"] = self.phrases
        s["threshold"] = self.threshold
        s["enabled"] = self._enabled
        s["paused"] = self._paused.is_set()
        s["uptime_s"] = (time.time() - self.stats["started_at"]) if self.stats["started_at"] else 0
        s["model_path"] = self.model_path
        return s

    # ── Lifecycle ────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self._enabled:
            return True
        try:
            self._init_engine()
        except Exception as e:
            self.stats["error"] = f"{type(e).__name__}: {e}"
            print(f"[WAKE-VOSK] init failed: {e}")
            return False
        self._stop.clear()
        self._paused.clear()
        self._enabled = True
        self.stats["started_at"] = time.time()
        self.stats["available"] = True
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="wake-word-vosk",
        )
        self._thread.start()
        print(f"[WAKE-VOSK] listening for {self.phrases} (model={os.path.basename(self.model_path)})")
        return True

    def stop(self) -> None:
        self._enabled = False
        self._stop.set()
        if self._stream is not None:
            try: self._stream.stop(); self._stream.close()
            except Exception: pass
            self._stream = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        print("[WAKE-VOSK] stopped")

    def pause(self) -> None:
        self._paused.set()

    def resume(self) -> None:
        self._paused.clear()
        # Reset recognizer so we don't trigger on residual audio that
        # was buffered while paused.
        if self._recognizer is not None:
            try: self._recognizer.Reset()
            except Exception: pass

    # ── Engine init ──────────────────────────────────────────────────────
    def _init_engine(self) -> None:
        if not os.path.isdir(self.model_path):
            # Self-heal: the small en-US model isn't shipped in the tarball
            # (keeps the download lean). Fetch it on first use instead of
            # hard-failing always-listening on a fresh install.
            if not _ensure_vosk_model(self.model_path):
                raise RuntimeError(
                    f"Vosk model dir not found and auto-download failed: "
                    f"{self.model_path}. Set LEON_VOSK_MODEL or download to "
                    f"{_DEFAULT_MODEL_REL}."
                )
        from vosk import Model, KaldiRecognizer, SetLogLevel  # type: ignore
        SetLogLevel(-1)   # silence Vosk's chatty stderr
        # Restrict the grammar to wake phrases + "[unk]" so the recognizer
        # is biased toward our keywords. Vastly reduces CPU vs full LM.
        grammar_words = set()
        for p in self.phrases:
            for w in p.split():
                grammar_words.add(w)
        grammar = json.dumps(sorted(grammar_words) + ["[unk]"])
        self._vosk_model = Model(self.model_path)
        self._recognizer = KaldiRecognizer(self._vosk_model, SAMPLE_RATE, grammar)
        self._recognizer.SetWords(False)
        # Silero VAD gate — only run Vosk on chunks where speech is
        # actually present. Cuts false fires from phone calls / TV.
        self._vad = _SileroVADGate()
        if self._vad.available:
            print(f"[WAKE-VOSK] Silero VAD pre-gate active (threshold={_VAD_THRESHOLD})")
        else:
            print(f"[WAKE-VOSK] Silero VAD unavailable — wake will be more false-fire prone")

    # ── Main loop ────────────────────────────────────────────────────────
    def _run(self) -> None:
        try:
            import sounddevice as sd
        except Exception as e:
            self.stats["error"] = f"sounddevice missing: {e}"
            return

        pre_roll_chunks = max(1, int((UTT_PRE_ROLL_MS / 1000) * SAMPLE_RATE / CHUNK_SAMPLES))
        recent: List[TimedChunk] = []
        # Longer rolling window used ONLY for the loopback correlation
        # check — a single 80ms chunk is too short to correlate reliably.
        echo_window: List[TimedChunk] = []
        echo_window_chunks = max(4, int(1.0 * SAMPLE_RATE / CHUNK_SAMPLES))

        # Timestamped AT CAPTURE inside the callback — the foundation of
        # the whole self-hearing fix (see brain/voice/audio_gate.py).
        chunk_q: "queue.Queue[TimedChunk]" = queue.Queue(maxsize=64)

        def _on_audio(indata, frames, time_info, status):
            tc = audio_gate.now_chunk(bytes(indata), frames, SAMPLE_RATE)
            try:
                chunk_q.put_nowait(tc)
            except queue.Full:
                try: chunk_q.get_nowait()
                except queue.Empty: pass
                try: chunk_q.put_nowait(tc)
                except queue.Full: pass

        try:
            self._stream = sd.RawInputStream(
                samplerate=SAMPLE_RATE,
                blocksize=CHUNK_SAMPLES,
                dtype="int16", channels=1, callback=_on_audio,
            )
            self._stream.start()
        except Exception as e:
            self.stats["error"] = f"mic open failed: {e}"
            self._enabled = False
            return

        while not self._stop.is_set():
            try:
                chunk = chunk_q.get(timeout=0.5)
            except queue.Empty:
                continue
            recent.append(chunk)
            if len(recent) > pre_roll_chunks:
                recent = recent[-pre_roll_chunks:]
            echo_window.append(chunk)
            if len(echo_window) > echo_window_chunks:
                echo_window = echo_window[-echo_window_chunks:]

            if self._paused.is_set():
                while not chunk_q.empty():
                    try: chunk_q.get_nowait()
                    except queue.Empty: break
                continue

            # ── THE gate ──────────────────────────────────────────────
            # Decided against the chunk's own capture timestamp. If the
            # speakers were live when this air hit the mic, it is Leon's
            # voice — drop it and reset the recognizer so no half-built
            # partial survives to match a phrase later.
            if chunk_is_gated(chunk):
                self.stats["frames_gated_speaker"] = \
                    self.stats.get("frames_gated_speaker", 0) + 1
                if self._recognizer is not None:
                    try: self._recognizer.Reset()
                    except Exception: pass
                continue

            self.stats["frames_processed"] += 1
            # VAD pre-gate — skip Vosk entirely when this chunk has no
            # speech. Cuts ~95% of CPU during silence + kills false
            # fires from phone speakers / TV / desk noise.
            if self._vad is not None and self._vad.available:
                if not self._vad.is_speech(chunk.pcm):
                    self._frames_gated += 1
                    self.stats["frames_gated"] = self._frames_gated
                    continue
            try:
                # AcceptWaveform returns True when an utterance closes,
                # but for wake detection we care about PartialResult so we
                # can fire mid-utterance the moment the phrase appears.
                self._recognizer.AcceptWaveform(chunk.pcm)
                partial = json.loads(self._recognizer.PartialResult()).get("partial", "")
            except Exception as e:
                self.stats["error"] = f"recognize failed: {e}"
                continue

            if not partial:
                continue
            text = partial.lower()
            m = self._phrase_re.search(text)
            if not m:
                continue

            now = time.time()
            if (now - self._last_wake_ts) < _PHRASE_COOLDOWN_S:
                continue
            phrase = m.group(0)

            # ── Second, clock-independent line of defence ─────────────
            # (a) If a loopback/system-audio reference is reachable,
            #     reject a wake whose mic audio correlates with what
            #     actually came out of the speakers.
            is_echo, corr = audio_gate.looks_like_echo(
                b"".join(c.pcm for c in echo_window),
                echo_window[0].ts if echo_window else chunk.ts,
                SAMPLE_RATE)
            if is_echo:
                print(f"[WAKE-VOSK] wake rejected — correlates with played "
                      f"output (corr={corr:.2f})", flush=True)
                try: self._recognizer.Reset()
                except Exception: pass
                continue
            # (b) Fallback where no reference exists: reject a wake whose
            #     phrase is verbatim inside a sentence Leon just spoke.
            #     This is Dean's exact report — Leon says "Leon" in his
            #     own reply and wakes himself. The phrase match is only a
            #     TIEBREAKER: wake_is_self_echo also requires chunk.ts to
            #     land in/next to a speaker interval, so Dean saying "hey
            #     Leon" right after Leon said it is not rejected.
            if audio_gate.wake_is_self_echo(phrase, chunk.ts):
                print(f"[WAKE-VOSK] wake rejected — '{phrase}' is in what "
                      f"Leon just said", flush=True)
                try: self._recognizer.Reset()
                except Exception: pass
                continue

            self._last_wake_ts = now
            self.stats["wake_count"] += 1
            self.stats["last_wake_ts"] = now
            self.stats["last_wake_score"] = 1.0
            self.stats["last_wake_word"] = phrase
            # Reset recognizer state so the phrase doesn't keep matching
            try: self._recognizer.Reset()
            except Exception: pass

            event = WakeEvent(wake_word=phrase, score=1.0)
            if self.on_wake is not None:
                try: self.on_wake(event)
                except Exception as e: print(f"[WAKE-VOSK] on_wake error: {e}")

            pre_roll = b"".join(
                c.pcm for c in recent if not chunk_is_gated(c))
            pre_roll_ts = recent[0].ts if recent else chunk.ts
            recent = []
            utt = self._capture_utterance(chunk_q, pre_roll, event,
                                          pre_roll_ts=pre_roll_ts)
            if utt and self.on_utterance is not None:
                try: self.on_utterance(utt)
                except Exception as e: print(f"[WAKE-VOSK] on_utterance error: {e}")

            # Drain pent-up audio so we don't process backlog
            while not chunk_q.empty():
                try: chunk_q.get_nowait()
                except queue.Empty: break

        try:
            if self._stream is not None:
                self._stream.stop(); self._stream.close()
        except Exception:
            pass
        self._stream = None

    # ── Utterance capture (post-wake) ────────────────────────────────────
    def _capture_utterance(self, chunk_q, pre_roll: bytes, event: WakeEvent,
                           pre_roll_ts: float = 0.0):
        """Capture post-wake utterance with silence detection.

        Self-hearing protection here is per-chunk and capture-time based:
        any chunk recorded while the speakers were live (per the one
        ledger in brain/voice/audio_gate.py) is dropped, so Leon's own
        TTS can neither keep the RMS above the silence threshold nor end
        up in the PCM that goes to STT. `self._paused` is still honoured
        as an explicit "this turn is over" signal from the orchestrator.
        """
        import numpy as np

        chunks: List[bytes] = []
        if pre_roll:
            chunks.append(pre_roll)
        start = time.time()
        first_ts = pre_roll_ts or start
        last_ts = start
        last_voice_ts = start
        # Adaptive: learns the room's noise floor instead of guessing it.
        floor = AdaptiveVoiceFloor()
        # First few chunks always count as voice — we just woke the user
        # mid-syllable.
        warmup_chunks = 4
        chunks_seen = 0
        while not self._stop.is_set():
            # Explicit stand-down from the orchestrator / push-to-talk
            # floor. (Speaker audio itself is handled per-chunk below.)
            if self._paused.is_set():
                print(f"[WAKE-VOSK] capture aborted — listener paused "
                      f"({chunks_seen} chunks, {time.time()-start:.1f}s)",
                      flush=True)
                break
            if (time.time() - start) > UTT_MAX_SEC:
                break
            try:
                chunk = chunk_q.get(timeout=0.5)
            except queue.Empty:
                if (time.time() - last_voice_ts) * 1000 > utterance_grace_ms(last_voice_ts - start):
                    break
                continue
            # Speaker audio never enters the utterance, whenever it is
            # dequeued. Silence bookkeeping ignores it too — otherwise
            # Leon's own voice would keep the capture alive forever.
            if chunk_is_gated(chunk):
                continue
            chunks.append(chunk.pcm)
            last_ts = chunk.end_ts
            chunks_seen += 1

            samples = np.frombuffer(chunk.pcm, dtype=np.int16).astype(np.float32)
            rms = float(np.sqrt(np.mean(samples * samples) + 1e-9))
            is_voice = (chunks_seen <= warmup_chunks) or floor.is_voice(rms)
            if is_voice:
                last_voice_ts = time.time()
            else:
                if (time.time() - last_voice_ts) * 1000 > utterance_grace_ms(last_voice_ts - start):
                    break

        pcm = b"".join(chunks)
        duration = (len(pcm) // 2) / SAMPLE_RATE
        if duration < 0.4:
            return None
        return UtteranceCapture(
            pcm16=pcm, duration_s=duration,
            wake_word=event.wake_word, wake_score=event.score,
            started_ts=first_ts, ended_ts=last_ts,
        )
