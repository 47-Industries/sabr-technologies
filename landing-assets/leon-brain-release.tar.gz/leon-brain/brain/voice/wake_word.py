"""
Always-On Wake Word Listener — Step 5 of the full-Jarvis roadmap.

Replaces push-to-talk with a continuous mic stream that wakes Leon when
it hears the configured wake word. Built on openWakeWord (pure ONNX,
~1-3% CPU on a modern desktop) plus sounddevice for capture.

Default wake word: **"hey jarvis"** (the bundled openWakeWord model
that's the closest pre-trained match to Leon's "Jarvis-style assistant"
posture). A custom "hey leon" model can be trained later via
openWakeWord's synthetic-data pipeline and dropped in via the
`LEON_WAKE_WORD` env var pointing at the .onnx file.

Pipeline once wake fires:
  wake → start recording → VAD endpoints utterance → faster-whisper STT
  → BrainAPIResponder → TTS plays response → resume listening.

Critical detail: the listener PAUSES while Leon's TTS is speaking, so
the speaker output never feeds back into the mic and re-triggers the
wake word. Caller is responsible for calling pause()/resume() around
audio playback.
"""

from __future__ import annotations

import os
import queue
import threading
import time
import wave
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from brain.voice import audio_gate
from brain.voice.audio_gate import TimedChunk


# ── Config ────────────────────────────────────────────────────────────────
SAMPLE_RATE = 16000               # openWakeWord requirement
CHUNK_SAMPLES = 1280              # 80ms @ 16kHz; openWakeWord's expected chunk
WAKE_THRESHOLD = 0.5              # 0–1 confidence; tuned for "hey jarvis"
WAKE_COOLDOWN_S = 1.5             # ignore further hits in this window
UTT_MAX_SEC = 60.0                # cap per-utterance length. Dean gives long,
                                  # detailed instructions from across the room;
                                  # 20s truncated him mid-thought (2026-08-02).
UTT_SILENCE_END_MS = 2200         # trailing silence to end a SETTLED utterance
                                  # (he's already been talking a while).
UTT_SILENCE_GRACE_MS = 7000       # trailing silence to end an utterance that has
                                  # barely started. Dean's #1 wake-word complaint
                                  # (2026-08-02): "it lets me talk for a couple
                                  # seconds then cuts me off." A person who just
                                  # said "hey Leon" usually pauses to think before
                                  # the real sentence. Be patient at the start,
                                  # snappy once they're clearly rolling.
UTT_SETTLED_S = 6.0               # speech this long == settled; drop to the
                                  # short grace so replies stay responsive.
UTT_NOISE_FLOOR_MULT = 2.6        # voice threshold = ambient floor * this
UTT_MIN_VOICE_RMS = 120           # absolute floor; a quiet voice from bed is
                                  # ~150-250 RMS, well under the old fixed 280
                                  # that was silently eating half his sentences.
UTT_PRE_ROLL_MS = 200             # keep last N ms of pre-wake audio


def utterance_grace_ms(speech_seconds: float) -> float:
    """How much trailing silence should end the utterance.

    Generous while the speaker is just getting going, tight once they've
    clearly been talking. Ending an utterance early is far more damaging
    than ending it late: late costs a couple of seconds, early costs the
    whole thought and makes Leon talk over a person.
    """
    if speech_seconds < UTT_SETTLED_S:
        return UTT_SILENCE_GRACE_MS
    return UTT_SILENCE_END_MS


class AdaptiveVoiceFloor:
    """Tracks ambient RMS and reports whether a chunk contains voice.

    A fixed threshold can't work across a headset at the desk and a voice
    from the bed eight feet away. This learns the room from the quiet
    chunks and sets the bar just above it.
    """

    def __init__(self, mult: float = UTT_NOISE_FLOOR_MULT,
                 min_rms: float = UTT_MIN_VOICE_RMS):
        self.mult = mult
        self.min_rms = min_rms
        self.floor: float = 0.0
        self._seen = 0

    @property
    def threshold(self) -> float:
        if self._seen == 0:
            return self.min_rms
        return max(self.min_rms, self.floor * self.mult)

    def is_voice(self, rms: float) -> bool:
        self._seen += 1
        thr = self.threshold
        voice = rms > thr
        if not voice:
            # decay toward the observed quiet level
            self.floor = rms if self.floor == 0.0 else (
                0.9 * self.floor + 0.1 * rms)
        return voice



@dataclass
class WakeEvent:
    """Emitted on detection."""
    wake_word: str
    score: float
    ts: float = field(default_factory=time.time)


@dataclass
class UtteranceCapture:
    """Result of a wake → record cycle."""
    pcm16: bytes                  # raw 16-bit mono 16kHz audio
    duration_s: float
    wake_word: str
    wake_score: float
    # Capture-time bounds of the audio in pcm16. Consumers (STT, relay)
    # need these to ask the gate about the instant the audio was RECORDED
    # rather than the instant they got around to looking at it.
    started_ts: float = 0.0
    ended_ts: float = 0.0


class WakeWordListener:
    """Background mic listener with wake-word detection and post-wake
    utterance capture.

    Construction is cheap (lazy-loads heavy deps); call start() to spin
    up the capture thread. on_utterance is called with an UtteranceCapture
    after each wake → record cycle finishes.
    """

    def __init__(
        self,
        wake_word: Optional[str] = None,
        on_wake: Optional[Callable[[WakeEvent], None]] = None,
        on_utterance: Optional[Callable[[UtteranceCapture], None]] = None,
        threshold: float = WAKE_THRESHOLD,
        custom_model_path: Optional[str] = None,
    ):
        # `wake_word` is the model key inside openWakeWord's bundle (e.g.
        # "hey_jarvis", "alexa", "hey_mycroft"). Custom models pass the
        # .onnx path via custom_model_path; their key is the basename.
        self.wake_word = wake_word or os.environ.get("LEON_WAKE_WORD") or "hey_jarvis"
        self.custom_model_path = custom_model_path or os.environ.get("LEON_WAKE_MODEL_PATH")
        self.on_wake = on_wake
        self.on_utterance = on_utterance
        self.threshold = threshold

        self._owW_model = None     # openWakeWord.model.Model
        self._stream = None        # sounddevice.RawInputStream
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._paused = threading.Event()        # set ⇒ paused
        self._last_wake_ts = 0.0
        self._enabled = False

        # Stats for the dashboard
        self.stats = {
            "started_at": 0.0,
            "frames_processed": 0,
            "wake_count": 0,
            "last_wake_ts": 0.0,
            "last_wake_score": 0.0,
            "last_wake_word": "",
            "best_score_recent": 0.0,
            "available": False,
            "error": None,
        }

    # ── State helpers ─────────────────────────────────────────────────────
    @property
    def active(self) -> bool:
        return self._enabled and not self._paused.is_set()

    def is_running(self) -> bool:
        return self._enabled

    def get_state(self) -> dict:
        s = dict(self.stats)
        s["wake_word"] = self.wake_word
        s["threshold"] = self.threshold
        s["enabled"] = self._enabled
        s["paused"] = self._paused.is_set()
        s["uptime_s"] = (time.time() - self.stats["started_at"]) if self.stats["started_at"] else 0
        return s

    # ── Lifecycle ────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self._enabled:
            return True
        try:
            self._init_engine()
        except Exception as e:
            self.stats["error"] = f"{type(e).__name__}: {e}"
            print(f"[WAKE] init failed: {e}")
            return False
        self._stop.clear()
        self._paused.clear()
        self._enabled = True
        self.stats["started_at"] = time.time()
        self.stats["available"] = True
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="wake-word-listener",
        )
        self._thread.start()
        print(f"[WAKE] listening for '{self.wake_word}' (threshold={self.threshold})")
        return True

    def stop(self) -> None:
        self._enabled = False
        self._stop.set()
        if self._stream is not None:
            try:
                self._stream.stop(); self._stream.close()
            except Exception:
                pass
            self._stream = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        print("[WAKE] stopped")

    def pause(self) -> None:
        """Suspend wake detection (e.g. while TTS is playing). Stream stays
        open so resume() is instant; we just gate prediction in the loop."""
        self._paused.set()

    def resume(self) -> None:
        self._paused.clear()

    # ── Engine init ──────────────────────────────────────────────────────
    def _init_engine(self) -> None:
        """Load openWakeWord. Raises on failure."""
        from openwakeword.model import Model  # type: ignore

        kwargs = {}
        if self.custom_model_path:
            kwargs["wakeword_model_paths"] = [self.custom_model_path]
            # Custom models become available under their file basename
            self.wake_word = os.path.splitext(os.path.basename(self.custom_model_path))[0]

        self._owW_model = Model(**kwargs)
        if self.wake_word not in self._owW_model.models:
            avail = list(self._owW_model.models.keys())
            raise RuntimeError(
                f"wake word '{self.wake_word}' not loaded. available: {avail}"
            )

    # ── Capture loop ─────────────────────────────────────────────────────
    def _run(self) -> None:
        try:
            import sounddevice as sd
        except Exception as e:
            self.stats["error"] = f"sounddevice missing: {e}"
            return

        # Ring buffer of recent audio so we can attach pre-roll to the
        # captured utterance (the user often starts talking the same instant
        # the wake word ends — pre-roll prevents chopping off the first phoneme).
        pre_roll_chunks = max(1, int((UTT_PRE_ROLL_MS / 1000) * SAMPLE_RATE / CHUNK_SAMPLES))
        recent: List[TimedChunk] = []
        # ~1s rolling window for the loopback correlation check; a single
        # 80ms chunk is too short to correlate against played output.
        echo_window: List[TimedChunk] = []
        echo_window_chunks = max(4, int(1.0 * SAMPLE_RATE / CHUNK_SAMPLES))

        # sounddevice writes mic data into a thread-safe queue; the main
        # loop drains it. RawInputStream gives us raw int16 bytes directly.
        # Chunks are TIMESTAMPED AT CAPTURE — see brain/voice/audio_gate.py.
        # Without the capture timestamp, audio recorded while Leon was
        # speaking is indistinguishable from audio recorded after he
        # stopped by the time it reaches this queue's consumer.
        chunk_q: "queue.Queue[TimedChunk]" = queue.Queue(maxsize=64)

        def _on_audio(indata, frames, time_info, status):
            if status:
                # Common: input overflow when system's busy. Don't crash.
                pass
            tc = audio_gate.now_chunk(bytes(indata), frames, SAMPLE_RATE)
            try:
                chunk_q.put_nowait(tc)
            except queue.Full:
                # Drop oldest to keep up with realtime
                try: chunk_q.get_nowait()
                except queue.Empty: pass
                try: chunk_q.put_nowait(tc)
                except queue.Full: pass

        try:
            self._stream = sd.RawInputStream(
                samplerate=SAMPLE_RATE,
                blocksize=CHUNK_SAMPLES,
                dtype="int16",
                channels=1,
                callback=_on_audio,
            )
            self._stream.start()
        except Exception as e:
            self.stats["error"] = f"mic open failed: {e}"
            self._enabled = False
            return

        while not self._stop.is_set():
            try:
                chunk = chunk_q.get(timeout=0.5)
            except queue.Empty:
                continue
            recent.append(chunk)
            if len(recent) > pre_roll_chunks:
                recent = recent[-pre_roll_chunks:]
            echo_window.append(chunk)
            if len(echo_window) > echo_window_chunks:
                echo_window = echo_window[-echo_window_chunks:]

            if self._paused.is_set():
                # Drain queue while paused so we don't process stale audio
                # when we resume.
                while not chunk_q.empty():
                    try: chunk_q.get_nowait()
                    except queue.Empty: break
                continue

            # ── THE gate: decided on the chunk's CAPTURE timestamp ──
            # A chunk recorded while the speakers were live is Leon's own
            # voice, full stop — discard it however late it arrives here.
            if audio_gate.chunk_is_speaker(chunk):
                self.stats["frames_gated_speaker"] = \
                    self.stats.get("frames_gated_speaker", 0) + 1
                try: self._owW_model.reset()
                except Exception: pass
                continue

            # openWakeWord wants int16 numpy 1-D
            self.stats["frames_processed"] += 1
            try:
                import numpy as np
                samples = np.frombuffer(chunk.pcm, dtype=np.int16)
                scores = self._owW_model.predict(samples)
            except Exception as e:
                self.stats["error"] = f"predict failed: {e}"
                continue

            # Score for our chosen wake word
            score = float(scores.get(self.wake_word, 0.0))
            if score > self.stats["best_score_recent"]:
                self.stats["best_score_recent"] = score

            now = time.time()
            in_cooldown = (now - self._last_wake_ts) < WAKE_COOLDOWN_S
            if score >= self.threshold and not in_cooldown:
                # Second line of defence, clock-independent: does this
                # audio correlate with what actually left the speakers?
                is_echo, corr = audio_gate.looks_like_echo(
                    b"".join(c.pcm for c in echo_window),
                    echo_window[0].ts if echo_window else chunk.ts,
                    SAMPLE_RATE)
                if is_echo:
                    print(f"[WAKE] wake rejected — echo of own output "
                          f"(corr={corr:.2f})", flush=True)
                    continue
                self._last_wake_ts = now
                self.stats["wake_count"] += 1
                self.stats["last_wake_ts"] = now
                self.stats["last_wake_score"] = score
                self.stats["last_wake_word"] = self.wake_word
                # Snapshot best_score and reset rolling tracker
                self.stats["best_score_recent"] = 0.0

                event = WakeEvent(wake_word=self.wake_word, score=score)
                if self.on_wake is not None:
                    try: self.on_wake(event)
                    except Exception as e: print(f"[WAKE] on_wake error: {e}")

                # Pause openWakeWord during utterance capture. Reset its
                # internal state so the next listening window starts clean.
                pre_roll = b"".join(
                    c.pcm for c in recent if not audio_gate.chunk_is_speaker(c))
                pre_roll_ts = recent[0].ts if recent else chunk.ts
                recent = []
                try:
                    self._owW_model.reset()
                except Exception:
                    pass

                utt = self._capture_utterance(chunk_q, pre_roll, event,
                                              pre_roll_ts=pre_roll_ts)
                if utt and self.on_utterance is not None:
                    try: self.on_utterance(utt)
                    except Exception as e: print(f"[WAKE] on_utterance error: {e}")
                # After dispatch, drop any audio that piled up while STT/Claude
                # ran so we don't process a backlog.
                while not chunk_q.empty():
                    try: chunk_q.get_nowait()
                    except queue.Empty: break

        # Cleanup
        try:
            if self._stream is not None:
                self._stream.stop(); self._stream.close()
        except Exception:
            pass
        self._stream = None

    # ── Utterance capture (post-wake) ────────────────────────────────────
    def _capture_utterance(
        self, chunk_q: "queue.Queue[TimedChunk]", pre_roll: bytes,
        event: WakeEvent, pre_roll_ts: float = 0.0,
    ) -> Optional[UtteranceCapture]:
        """Record audio after a wake until either UTT_MAX_SEC elapses or
        we've seen UTT_SILENCE_END_MS of trailing silence.

        Uses a simple RMS-based silence detector — Silero is overkill
        here, the wake just primed us so we already know speech is
        starting. We only need to know when the speaker stops."""
        import numpy as np

        chunks: List[bytes] = []
        if pre_roll:
            chunks.append(pre_roll)
        start = time.time()
        first_ts = pre_roll_ts or start
        last_ts = start
        last_voice_ts = start
        # Adaptive: learns the room's noise floor instead of guessing it.
        floor = AdaptiveVoiceFloor()
        # First few chunks always count as voice — we just woke the user
        # mid-syllable.
        warmup_chunks = 4

        chunks_seen = 0
        while not self._stop.is_set():
            elapsed = time.time() - start
            if elapsed > UTT_MAX_SEC:
                break
            try:
                chunk = chunk_q.get(timeout=0.5)
            except queue.Empty:
                # Microphone went quiet (no audio frames at all) — treat
                # as silence to avoid hanging if device disappears.
                if (time.time() - last_voice_ts) * 1000 > utterance_grace_ms(last_voice_ts - start):
                    break
                continue
            # Drop audio the speakers were responsible for — by CAPTURE
            # time, not by when we dequeued it.
            if audio_gate.chunk_is_speaker(chunk):
                continue
            chunks.append(chunk.pcm)
            last_ts = chunk.end_ts
            chunks_seen += 1

            samples = np.frombuffer(chunk.pcm, dtype=np.int16).astype(np.float32)
            rms = float(np.sqrt(np.mean(samples * samples) + 1e-9))
            is_voice = (chunks_seen <= warmup_chunks) or floor.is_voice(rms)
            if is_voice:
                last_voice_ts = time.time()
            else:
                if (time.time() - last_voice_ts) * 1000 > utterance_grace_ms(last_voice_ts - start):
                    break

        pcm = b"".join(chunks)
        duration = (len(pcm) // 2) / SAMPLE_RATE
        if duration < 0.4:
            # Almost certainly a misfire / no real speech captured.
            return None
        return UtteranceCapture(
            pcm16=pcm, duration_s=duration,
            wake_word=event.wake_word, wake_score=event.score,
            started_ts=first_ts, ended_ts=last_ts,
        )


# ── Helpers ───────────────────────────────────────────────────────────────
def pcm16_to_wav_bytes(pcm: bytes, sample_rate: int = SAMPLE_RATE) -> bytes:
    """Wrap raw PCM16 mono in a WAV header so it can be passed to STT
    backends that want a file-like object."""
    import io
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm)
    return buf.getvalue()
