"""
audio_gate.py — the ONE owner of "was the speaker active at instant T".

Why this module exists
----------------------
Leon's TTS plays through the PC speakers, the mic hears it, and when his
own reply contains his name the Vosk wake listener fires on Leon's own
voice. Every previous fix was a timing patch (a cooldown, a blanking
window, a polling gate thread that flips `listener._paused`) and every
one of them raced, because they all shared the same structural bug:

    the suppression decision was evaluated at CONSUME time against the
    current wall clock, while the audio it was suppressing had been
    RECORDED at some earlier, unrelated instant.

A chunk recorded while Leon was mid-sentence can sit in the capture queue
and be consumed 300ms after the gate lifts — at which point every
wall-clock check says "not speaking" and the wake fires on Leon's voice.
No amount of extra milliseconds on the cooldown closes that hole; the
decision is simply attached to the wrong instant.

The fix, and the rule this module enforces
------------------------------------------
1. Every mic chunk is timestamped AT CAPTURE, inside the audio callback
   (see `TimedChunk`). Chunks are (ts, pcm), never bare bytes.
2. Speaker-active state lives in exactly ONE place: `LEDGER`, a list of
   [start_ts, end_ts] intervals. The TTS player PUBLISHES open/close.
   Nothing polls, nothing guesses, nothing keeps a second copy.
3. The gate compares the CHUNK'S OWN timestamp against the ledger. A
   chunk recorded inside a speaker interval is discarded no matter when
   it is consumed, even if playback finished ten seconds ago.

Second line of defence (clock-independent)
------------------------------------------
Clocks can still be wrong — the browser starts playback some unknown
number of milliseconds after the server hands it the WAV. So there are
two content-based checks that don't depend on time at all:

  * `EchoReference` — the loopback / system-audio monitor stream (already
    captured by brain/audio_daemon.py's `_system_callback`) is kept as a
    short reference ring buffer. `looks_like_echo()` correlates a mic
    window's envelope against what actually came out of the speakers.
  * `transcript_is_self_echo()` / `wake_is_self_echo()` — compares what
    we think we heard against what Leon last SAID. Used where the
    loopback reference isn't reachable (e.g. the PC-side relay process,
    which has the mic but not the VPS's monitor stream).

Barge-in ENDS the interval — it does not bypass the gate
--------------------------------------------------------
Push-to-talk used to be an exception: button audio skipped the gate
entirely. That reopened the self-hearing hole from the other side. When
Dean barges in, playback is *stopped*, but the audio already handed to
the sink keeps coming out of the speakers for another 200-500ms while it
drains. A bypass feeds that drain window straight to STT as if Dean had
said it — and a false UTTERANCE is strictly worse than a false wake: a
wake is discarded, an utterance is answered and burns a turn.

So there is exactly ONE decision rule — the chunk's capture timestamp
against the ledger — and barge-in falls out of it for free: pressing the
button STOPS playback and CLOSES the open interval at
`stop_ts + SINK_DRAIN_S`. Everything Dean says after the drain window is
outside every interval and passes the same single rule that everything
else does. Nothing gets a second rule that can disagree with the first.

Text is never sufficient on its own
-----------------------------------
`transcript_is_self_echo_at()` / `wake_is_self_echo()` reject on what
Leon just SAID, but only as a TIEBREAKER on audio that was captured in or
next to a speaker interval. Dean quotes Leon back constantly; a text-only
reject eats his real speech. See `audio_near_speaker()`.

Env overrides
-------------
    LEON_AUDIO_GATE=0                  disable gating entirely (debug)
    LEON_AUDIO_GATE_PRE_GUARD_MS=150   margin before an interval starts
    LEON_AUDIO_GATE_POST_GUARD_MS=700  margin after an interval ends
    LEON_AUDIO_SINK_DRAIN_MS=350       audio still in the sink at stop()
    LEON_AUDIO_GATE_MAX_OPEN_S=60      cap on a never-closed interval
    LEON_AUDIO_GATE_ECHO_CORR=0.55     loopback correlation reject level
    LEON_AUDIO_GATE_ECHO_TEXT=0.6      transcript overlap reject level
    LEON_AUDIO_GATE_TEXT_SLACK_MS=1500 how far outside an interval the
                                       text tiebreaker may still apply
"""

from __future__ import annotations

import os
import re
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple


# ── Tunables (named constants, env-overridable) ───────────────────────

def _env_float(name: str, default: float) -> float:
    try:
        v = os.environ.get(name, "").strip()
        return float(v) if v else default
    except (TypeError, ValueError):
        return default


#: A chunk recorded this long BEFORE playback is logged as starting is
#: still treated as Leon's own voice. Covers the gap between "server
#: dispatched the WAV" and "speakers actually moved air".
PRE_GUARD_S: float = _env_float("LEON_AUDIO_GATE_PRE_GUARD_MS", 150.0) / 1000.0

#: A chunk recorded this long AFTER playback ends is still suppressed.
#: Covers room reverb and the tail of the speaker cone.
POST_GUARD_S: float = _env_float("LEON_AUDIO_GATE_POST_GUARD_MS", 700.0) / 1000.0

#: Audio already handed to the sound sink when playback is STOPPED still
#: reaches the speakers. Stopping is not silence: the ring buffer /
#: browser AudioContext keeps emitting for this long. A barge-in closes
#: the speaker interval at stop_ts + this, never at stop_ts.
SINK_DRAIN_S: float = _env_float("LEON_AUDIO_SINK_DRAIN_MS", 350.0) / 1000.0

#: How far OUTSIDE a speaker interval (beyond the guards) the text-echo
#: tiebreaker may still fire. Text alone never rejects anything; this is
#: the fuzzy edge where a strong text match is allowed to tip a decision
#: the timestamps left ambiguous.
TEXT_TIEBREAK_SLACK_S: float = _env_float("LEON_AUDIO_GATE_TEXT_SLACK_MS", 1500.0) / 1000.0

#: The server SYNTHESIZES a streaming reply's sentences far faster than
#: the dashboard PLAYS them (tokens arrive in ~1s, each clip is ~4s of
#: audio). Publishing every interval at synthesis time therefore leaves
#: the tail of a long reply completely ungated — Leon hears his own voice
#: and files it as Dean. So intervals from the synthesis path queue:
#: a clip starts at max(now, end-of-the-last-queued-clip). This caps how
#: far ahead that cursor may run, so a runaway publisher can never mute
#: the mic for minutes.
MAX_QUEUE_LEAD_S: float = _env_float("LEON_AUDIO_GATE_MAX_QUEUE_LEAD_S", 90.0)

#: A publisher that opens an interval and dies without closing it must
#: never deafen Leon permanently. Open intervals expire after this.
MAX_OPEN_INTERVAL_S: float = _env_float("LEON_AUDIO_GATE_MAX_OPEN_S", 60.0)

#: How much history the ledger keeps. Longer than any plausible queue
#: backlog, short enough to stay O(few) entries.
LEDGER_HORIZON_S: float = _env_float("LEON_AUDIO_GATE_HORIZON_S", 120.0)

#: Normalized envelope correlation above which a mic window is judged to
#: be the speakers rather than a human.
ECHO_CORR_THRESHOLD: float = _env_float("LEON_AUDIO_GATE_ECHO_CORR", 0.55)

#: Token-overlap ratio above which a transcript is judged to be Leon
#: quoting himself.
ECHO_TEXT_THRESHOLD: float = _env_float("LEON_AUDIO_GATE_ECHO_TEXT", 0.6)

#: How long after Leon speaks a sentence the text-echo check still applies.
ECHO_TEXT_WINDOW_S: float = _env_float("LEON_AUDIO_GATE_ECHO_TEXT_WINDOW_S", 12.0)

#: Seconds of loopback reference audio retained for correlation.
REFERENCE_HORIZON_S: float = _env_float("LEON_AUDIO_GATE_REF_HORIZON_S", 20.0)


def enabled() -> bool:
    """Master switch. Read live so it can be flipped without a restart."""
    return os.environ.get("LEON_AUDIO_GATE", "1").strip() != "0"


# ── Timestamped audio ─────────────────────────────────────────────────

@dataclass(frozen=True)
class TimedChunk:
    """A mic chunk plus the instant it was CAPTURED.

    `ts` is the wall-clock time of the START of the chunk, computed
    inside the audio callback. `duration_s` lets the gate consider the
    whole span the chunk covers, not just its first sample.
    """
    ts: float
    pcm: bytes
    duration_s: float = 0.0

    @property
    def end_ts(self) -> float:
        return self.ts + self.duration_s


def now_chunk(pcm: bytes, frames: int, sample_rate: int) -> TimedChunk:
    """Build a TimedChunk from inside an audio callback.

    The callback runs when the block is already full, so the block's
    audio spans [now - frames/sr, now]. Stamping the START is what makes
    the gate correct: a chunk whose first sample landed during playback
    is Leon's voice regardless of when the callback ran.
    """
    dur = (frames / float(sample_rate)) if sample_rate else 0.0
    return TimedChunk(ts=time.time() - dur, pcm=pcm, duration_s=dur)


# ── The ledger: one owner of speaker-active state ─────────────────────

@dataclass
class SpeakerInterval:
    start_ts: float
    end_ts: Optional[float] = None     # None ⇒ still playing
    source: str = "tts"
    text: str = ""
    expected_duration_s: Optional[float] = None

    def effective_end(self, now: Optional[float] = None) -> float:
        """End instant to gate against.

        Closed interval → its real end. Still-open interval → at least
        "up to now", extended to the known clip length when the publisher
        told us one, and hard-capped so a lost close() can't deafen Leon.
        """
        if self.end_ts is not None:
            return self.end_ts
        now = time.time() if now is None else now
        end = max(now, self.start_ts + (self.expected_duration_s or 0.0))
        return min(end, self.start_ts + MAX_OPEN_INTERVAL_S)

    def covers(self, ts: float, span_s: float = 0.0,
               now: Optional[float] = None, slack_s: float = 0.0) -> bool:
        """Does [ts, ts+span] fall inside this interval (plus guards)?

        `slack_s` widens both edges. It is 0 for THE gate — the one
        decision rule — and non-zero only for the text tiebreaker, which
        is allowed to look a little further out but can never fire on
        text alone.
        """
        lo = self.start_ts - PRE_GUARD_S - slack_s
        hi = self.effective_end(now) + POST_GUARD_S + slack_s
        return (ts + span_s) > lo and ts < hi


class SpeakerLedger:
    """Append-only (pruned) record of when the speakers were live.

    THE single source of truth. `brain.audio_daemon._tts_playing_until`
    and sensor_relay's tts-gate thread both used to hold their own copy
    of this state; both now route through here.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._intervals: List[SpeakerInterval] = []
        self._next_handle = 1
        self._handles: dict = {}
        self._spoken: List[Tuple[float, str]] = []   # (ts, sentence)
        #: End of the last clip handed to the serial player. Synthesis
        #: runs ahead of playback; this is where the speakers actually
        #: are, not where the synthesizer is.
        self._cursor: float = 0.0

    # -- publishing ----------------------------------------------------
    def open(self, source: str = "tts", expected_duration_s: Optional[float] = None,
             text: str = "", start_ts: Optional[float] = None) -> int:
        """Playback STARTED. Returns a handle to close with.

        `start_ts` may be back-dated when the publisher learned about the
        playback late (e.g. reading a marker file's mtime) — back-dating
        is strictly better than pretending it started when we noticed.
        """
        with self._lock:
            iv = SpeakerInterval(
                start_ts=float(start_ts if start_ts is not None else time.time()),
                end_ts=None, source=source, text=text or "",
                expected_duration_s=expected_duration_s,
            )
            h = self._next_handle
            self._next_handle += 1
            self._handles[h] = iv
            self._intervals.append(iv)
            if text:
                self._spoken.append((iv.start_ts, text))
            self._prune_locked()
            return h

    def close(self, handle: int, end_ts: Optional[float] = None) -> None:
        """Playback FINISHED."""
        with self._lock:
            iv = self._handles.pop(handle, None)
            if iv is None:
                return
            iv.end_ts = float(end_ts if end_ts is not None else time.time())

    def publish_playback(self, duration_s: float, text: str = "",
                         source: str = "tts",
                         start_ts: Optional[float] = None) -> int:
        """Publish a complete interval in one shot.

        For players that hand off a finished clip of KNOWN length (the
        server synthesizes the WAV, so the duration is exact) and cannot
        themselves observe the last sample leaving the speaker. This is
        not a timer and not a guess: it is the clip's own length, written
        once. No thread waits on it.

        QUEUED, not instantaneous. The player is serial: a clip cannot
        begin before the previous one has finished coming out of the
        speakers. Synthesis is not — a ten-sentence reply is fully
        synthesized in the time the first three sentences play. So a
        `tts` clip starts at max(requested, cursor), and the cursor is
        where the SPEAKERS are. Publishing at synthesis time instead was
        the self-hearing bug: the last 20-30s of a long reply fell
        outside every interval and came back through the mic as Dean.

        Other sources (`tts-marker`, which back-dates from a file mtime,
        and anything observing real playback) are not queued — they
        already report the true instant.
        """
        dur = max(0.0, float(duration_s))
        now = time.time()
        requested = float(start_ts if start_ts is not None else now)
        queued = (source == "tts")
        with self._lock:
            if queued:
                start = max(requested, self._cursor)
                # Never let the cursor run arbitrarily far ahead of the
                # wall clock — a stuck or abandoned queue must not deafen
                # Leon for minutes.
                if start - now > MAX_QUEUE_LEAD_S:
                    start = now + MAX_QUEUE_LEAD_S
            else:
                start = requested
        h = self.open(source=source, expected_duration_s=dur,
                      text=text, start_ts=start)
        self.close(h, end_ts=start + dur)
        if queued:
            with self._lock:
                self._cursor = max(self._cursor, start + dur)
        return h

    def queued_playback_end(self) -> float:
        """Epoch instant the speakers are expected to fall silent.

        The PC-side mic marker needs this, not the clip length: a marker
        set for 4s while 40s of reply is queued lifts the gate 36s early.
        """
        with self._lock:
            return self._cursor

    def end_all(self, stop_ts: Optional[float] = None,
                drain_s: Optional[float] = None) -> float:
        """Playback was STOPPED (barge-in). End every live interval.

        This is how push-to-talk participates in the gate instead of
        bypassing it. Two things matter:

        * The interval ends at `stop_ts + SINK_DRAIN_S`, not at
          `stop_ts`. Audio already inside the sound sink keeps coming out
          of the speakers after stop() returns; that audio is still
          Leon's voice and must still be discarded. Without the drain
          margin the first 200-500ms of the "barge-in" is Leon being fed
          to STT as if Dean had said it.
        * It only ever SHORTENS. An interval published with a known clip
          length (`publish_playback`) reaches into the future; barge-in
          truncates it so Dean's words, spoken after the drain, fall
          outside every interval and pass THE gate for free. An interval
          that already ended before the barge-in is left alone.

        Returns the drain deadline.
        """
        stop = float(stop_ts if stop_ts is not None else time.time())
        deadline = stop + (SINK_DRAIN_S if drain_s is None else float(drain_s))
        with self._lock:
            # A queued clip that had not STARTED yet when Dean cut in
            # never reaches the speakers at all — the player's queue is
            # flushed. Truncating it to max(start, deadline) would leave
            # a phantom interval sitting in the future, muting Dean at a
            # moment when the room is silent. Drop those outright.
            self._intervals = [iv for iv in self._intervals
                               if iv.start_ts < deadline]
            for iv in self._intervals:
                if iv.end_ts is None or iv.end_ts > deadline:
                    iv.end_ts = max(iv.start_ts, deadline)
            # The speakers are where the barge-in left them, so the next
            # reply queues from here, not behind the abandoned backlog.
            self._cursor = min(self._cursor, deadline)
            # Drop the handles too: a publisher that later calls close()
            # on one of these must be a no-op, never a re-open or a
            # second, later end time.
            self._handles.clear()
        return deadline

    def is_open(self, handle: int) -> bool:
        """Is this handle still the owner of a live interval?

        False after `end_all()` truncated it — which is how the marker
        publisher notices a barge-in happened underneath it.
        """
        with self._lock:
            return handle in self._handles

    def extend_open(self, handle: int, expected_duration_s: float) -> None:
        """Grow an open interval's known length (multi-sentence replies)."""
        with self._lock:
            iv = self._handles.get(handle)
            if iv is not None:
                iv.expected_duration_s = max(iv.expected_duration_s or 0.0,
                                             float(expected_duration_s))

    def note_spoken_text(self, text: str, ts: Optional[float] = None) -> None:
        """Record a sentence Leon actually said (for the text-echo check)."""
        text = (text or "").strip()
        if not text:
            return
        with self._lock:
            self._spoken.append((float(ts if ts is not None else time.time()), text))
            self._prune_locked()

    # -- querying ------------------------------------------------------
    def is_speaker_active_at(self, ts: float, span_s: float = 0.0,
                             now: Optional[float] = None) -> bool:
        """THE gating question. Was the speaker live at capture instant `ts`?

        Note what is NOT here: the current wall clock plays no role in the
        answer beyond bounding a still-open interval. Consuming this chunk
        late cannot change the verdict.
        """
        with self._lock:
            for iv in self._intervals:
                if iv.covers(ts, span_s, now):
                    return True
            return False

    def chunk_is_speaker(self, chunk: TimedChunk,
                         now: Optional[float] = None) -> bool:
        return self.is_speaker_active_at(chunk.ts, chunk.duration_s, now)

    def is_near_speaker_at(self, ts: float, span_s: float = 0.0,
                           slack_s: float = TEXT_TIEBREAK_SLACK_S,
                           now: Optional[float] = None) -> bool:
        """Same question as `is_speaker_active_at`, asked with a wider
        margin. ONLY for the text tiebreaker — never for THE gate."""
        with self._lock:
            for iv in self._intervals:
                if iv.covers(ts, span_s, now, slack_s=slack_s):
                    return True
            return False

    def active_now(self) -> bool:
        """Convenience for callers that genuinely mean 'right this second'
        (e.g. 'should I start speaking?'), NOT for gating captured audio."""
        return self.is_speaker_active_at(time.time())

    def recent_speech(self, window_s: float = ECHO_TEXT_WINDOW_S,
                      now: Optional[float] = None) -> List[str]:
        now = time.time() if now is None else now
        with self._lock:
            return [t for (ts, t) in self._spoken if (now - ts) <= window_s]

    def intervals(self) -> List[SpeakerInterval]:
        with self._lock:
            return list(self._intervals)

    def reset(self) -> None:
        """Tests only."""
        with self._lock:
            self._intervals.clear()
            self._handles.clear()
            self._spoken.clear()
            self._cursor = 0.0

    # -- housekeeping --------------------------------------------------
    def _prune_locked(self) -> None:
        cutoff = time.time() - LEDGER_HORIZON_S
        self._intervals = [
            iv for iv in self._intervals
            if iv.end_ts is None or iv.end_ts >= cutoff
        ]
        self._spoken = [(ts, t) for (ts, t) in self._spoken if ts >= cutoff]


LEDGER = SpeakerLedger()


# ── Line of defence #2a: loopback / system-audio correlation ──────────

class EchoReference:
    """Ring buffer of what actually came OUT of the speakers.

    Fed from brain/audio_daemon.py's system-audio monitor callback (the
    PulseAudio/PipeWire `.monitor` source). Gives a clock-independent
    answer to "is this mic audio just our own output coming back?" —
    if the mic envelope correlates with the loopback envelope, it's echo,
    whatever any timestamp says.
    """

    _FRAME_S = 0.02   # 20ms envelope resolution

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._env: List[Tuple[float, float]] = []   # (ts, rms)
        self._have_signal = False

    @property
    def available(self) -> bool:
        """True once a loopback stream has actually delivered audio."""
        with self._lock:
            return self._have_signal

    def note_output(self, samples, sample_rate: int,
                    ts: Optional[float] = None) -> None:
        """Publish a block of speaker-bound audio, timestamped at capture."""
        try:
            import numpy as np
        except Exception:
            return
        try:
            arr = np.asarray(samples, dtype=np.float32).reshape(-1)
        except Exception:
            return
        if arr.size == 0 or not sample_rate:
            return
        dur = arr.size / float(sample_rate)
        start = float(ts if ts is not None else time.time()) - dur
        step = max(1, int(self._FRAME_S * sample_rate))
        out: List[Tuple[float, float]] = []
        for i in range(0, arr.size, step):
            seg = arr[i:i + step]
            if seg.size == 0:
                continue
            out.append((start + i / float(sample_rate),
                        float(np.sqrt(np.mean(seg * seg) + 1e-12))))
        if not out:
            return
        cutoff = time.time() - REFERENCE_HORIZON_S
        with self._lock:
            self._env.extend(out)
            self._env = [e for e in self._env if e[0] >= cutoff]
            if max(r for _, r in out) > 1e-4:
                self._have_signal = True

    def _reference_envelope(self, start_ts: float, end_ts: float) -> List[float]:
        with self._lock:
            return [r for (ts, r) in self._env if start_ts <= ts <= end_ts]

    def looks_like_echo(self, pcm16: bytes, ts: float, sample_rate: int,
                        threshold: Optional[float] = None) -> Tuple[bool, float]:
        """Correlate a captured window's envelope with the loopback's.

        Returns (is_echo, score). Score is the best normalized
        correlation across plausible lags (0-400ms of playback latency).
        Returns (False, 0.0) when no reference is available — this check
        can only ever ADD a rejection, never create a false accept.
        """
        thr = ECHO_CORR_THRESHOLD if threshold is None else threshold
        if not self.available or not pcm16:
            return False, 0.0
        try:
            import numpy as np
        except Exception:
            return False, 0.0
        try:
            mic = np.frombuffer(pcm16, dtype=np.int16).astype(np.float32) / 32768.0
        except Exception:
            return False, 0.0
        if mic.size == 0:
            return False, 0.0
        dur = mic.size / float(sample_rate)
        step = max(1, int(self._FRAME_S * sample_rate))
        mic_env = np.array([
            float(np.sqrt(np.mean(mic[i:i + step] ** 2) + 1e-12))
            for i in range(0, mic.size, step) if mic[i:i + step].size
        ], dtype=np.float32)
        # Reference over the same window plus room/playback latency slack.
        ref_env = np.array(
            self._reference_envelope(ts - 0.1, ts + dur + 0.5), dtype=np.float32)
        if mic_env.size < 4 or ref_env.size < mic_env.size:
            return False, 0.0
        if float(mic_env.max()) < 1e-4 or float(ref_env.max()) < 1e-4:
            return False, 0.0

        def _norm(v):
            v = v - v.mean()
            n = float(np.linalg.norm(v))
            return v / n if n > 1e-9 else v

        m = _norm(mic_env)
        best = 0.0
        max_lag = int(0.4 / self._FRAME_S) + 1
        for lag in range(0, min(max_lag, ref_env.size - mic_env.size) + 1):
            seg = ref_env[lag:lag + mic_env.size]
            if seg.size != mic_env.size:
                break
            score = float(np.dot(m, _norm(seg)))
            if score > best:
                best = score
        return best >= thr, best

    def reset(self) -> None:
        """Tests only."""
        with self._lock:
            self._env.clear()
            self._have_signal = False


REFERENCE = EchoReference()


# ── Line of defence #2b: transcript vs. what Leon just said ───────────

_WORD_RE = re.compile(r"[a-z0-9']+")


def _tokens(text: str) -> List[str]:
    return _WORD_RE.findall((text or "").lower())


def transcript_is_self_echo(transcript: str,
                            window_s: float = ECHO_TEXT_WINDOW_S,
                            threshold: Optional[float] = None,
                            now: Optional[float] = None) -> Tuple[bool, float]:
    """Text-overlap SCORE between this transcript and Leon's recent lines.

    NOT a verdict on its own. Dean quotes Leon back constantly ("so you
    pushed the fix and restarted the daemon?"), so a high overlap is
    perfectly normal for real human speech. Callers must combine this
    with WHERE THE AUDIO WAS CAPTURED — use `transcript_is_self_echo_at`,
    which does exactly that.
    """
    thr = ECHO_TEXT_THRESHOLD if threshold is None else threshold
    toks = _tokens(transcript)
    if not toks:
        return False, 0.0
    best = 0.0
    for said in LEDGER.recent_speech(window_s, now=now):
        said_toks = set(_tokens(said))
        if not said_toks:
            continue
        overlap = sum(1 for t in toks if t in said_toks) / float(len(toks))
        if overlap > best:
            best = overlap
    return best >= thr, best


def transcript_is_self_echo_at(transcript: str, ts: float,
                               span_s: float = 0.0,
                               window_s: float = ECHO_TEXT_WINDOW_S,
                               threshold: Optional[float] = None,
                               now: Optional[float] = None) -> Tuple[bool, float]:
    """THE text-echo verdict. Text is a TIEBREAKER, never a reason.

    RULE (do not undo this): a text-based reject may fire ONLY when the
    audio's own capture window `[ts, ts+span_s]` also falls inside a
    speaker interval — or within the guard margins plus
    TEXT_TIEBREAK_SLACK_S of one. Text alone is NEVER sufficient. Dean
    repeats Leon's own words back at him constantly, and a transcript
    rejected in error is a turn he has to say twice.

    Returns (reject, overlap_score) so callers can log the score even
    when the audio position vetoed the reject.
    """
    echoed, score = transcript_is_self_echo(transcript, window_s=window_s,
                                            threshold=threshold, now=now)
    if not echoed:
        return False, score
    if not audio_near_speaker(ts, span_s, now=now):
        return False, score
    return True, score


def wake_is_self_echo(phrase: str, ts: float,
                      window_s: float = ECHO_TEXT_WINDOW_S,
                      now: Optional[float] = None) -> bool:
    """Reject a wake whose phrase appears verbatim in something Leon just
    said. This is the case Dean reported: Leon's reply contains "Leon",
    the speakers say it, the mic hears it, Vosk wakes on his own name.

    Same rule as `transcript_is_self_echo_at`: the phrase match is a
    TIEBREAKER on audio captured in or beside a speaker interval. `ts` is
    the wake's own capture instant and it is load-bearing — without it
    this would reject Dean saying "hey Leon" right after Leon said his
    own name, which is most of how Dean talks.
    """
    toks = _tokens(phrase)
    if not toks:
        return False
    now = time.time() if now is None else now
    if not audio_near_speaker(ts, now=now):
        return False
    for said in LEDGER.recent_speech(window_s, now=now):
        said_toks = _tokens(said)
        n = len(toks)
        for i in range(0, max(0, len(said_toks) - n + 1)):
            if said_toks[i:i + n] == toks:
                return True
    return False


# ── Module-level convenience (the API callers should use) ─────────────

def open_playback(expected_duration_s: Optional[float] = None, text: str = "",
                  source: str = "tts", start_ts: Optional[float] = None) -> int:
    return LEDGER.open(source=source, expected_duration_s=expected_duration_s,
                       text=text, start_ts=start_ts)


def close_playback(handle: int, end_ts: Optional[float] = None) -> None:
    LEDGER.close(handle, end_ts=end_ts)


def publish_playback(duration_s: float, text: str = "", source: str = "tts",
                     start_ts: Optional[float] = None) -> int:
    return LEDGER.publish_playback(duration_s, text=text, source=source,
                                   start_ts=start_ts)


def note_spoken_text(text: str, ts: Optional[float] = None) -> None:
    LEDGER.note_spoken_text(text, ts=ts)


def note_barge_in(stop_ts: Optional[float] = None,
                  drain_s: Optional[float] = None) -> float:
    """Dean took the floor: playback has been STOPPED.

    Call this from the same place that stops the audio, on the RISING
    edge only (a held button that re-asserts itself every few seconds
    must not keep truncating intervals, or a reply that starts while the
    floor is held would go ungated).

    This is the whole of push-to-talk's relationship with the gate. PTT
    audio is not exempt and never was safe to exempt — it just ends the
    speaker interval, and then passes the one timestamp rule like
    everything else.
    """
    return LEDGER.end_all(stop_ts=stop_ts, drain_s=drain_s)


_seen_speech_lock = threading.Lock()
_seen_speech: List[str] = []


def note_recent_speech_once(text: str) -> None:
    """Idempotent `note_spoken_text` for pollers.

    The relay learns what Leon said by polling an endpoint, so the same
    sentence arrives many times; stamping it repeatedly would keep the
    echo window alive forever. Record each sentence exactly once.
    """
    text = (text or "").strip()
    if not text:
        return
    with _seen_speech_lock:
        if text in _seen_speech:
            return
        _seen_speech.append(text)
        del _seen_speech[:-64]
    note_spoken_text(text)


def note_reference_audio(samples, sample_rate: int,
                         ts: Optional[float] = None) -> None:
    REFERENCE.note_output(samples, sample_rate, ts=ts)


def speaker_active_now() -> bool:
    return enabled() and LEDGER.active_now()


def chunk_is_speaker(chunk: TimedChunk, now: Optional[float] = None) -> bool:
    """True ⇒ this chunk was recorded while Leon's own voice was playing,
    so it must be discarded no matter how late it is being consumed."""
    if not enabled():
        return False
    return LEDGER.chunk_is_speaker(chunk, now=now)


def audio_is_speaker(ts: float, span_s: float = 0.0,
                     now: Optional[float] = None) -> bool:
    if not enabled():
        return False
    return LEDGER.is_speaker_active_at(ts, span_s, now=now)


def audio_near_speaker(ts: float, span_s: float = 0.0,
                       slack_s: float = TEXT_TIEBREAK_SLACK_S,
                       now: Optional[float] = None) -> bool:
    """Was this audio captured in — or just beside — a speaker interval?

    The ONLY caller of this should be the text-echo tiebreaker. THE gate
    (`audio_is_speaker` / `chunk_is_speaker`) uses the exact guards and
    nothing else; widening those would weaken the one decision rule.
    """
    if not enabled():
        return False
    return LEDGER.is_near_speaker_at(ts, span_s, slack_s=slack_s, now=now)


def looks_like_echo(pcm16: bytes, ts: float, sample_rate: int) -> Tuple[bool, float]:
    if not enabled():
        return False, 0.0
    return REFERENCE.looks_like_echo(pcm16, ts, sample_rate)


# ── Cross-process publisher: the PC's TTS marker file ─────────────────

def _default_marker_path() -> str:
    """Where the TTS marker file lives, on any OS.

    This was hardcoded to "/tmp/leon-tts-active". Windows has no /tmp, so
    the publisher watched a path that could never appear, the ledger stayed
    empty, and EVERY downstream echo defence silently degraded to
    pass-everything -- which is how the SI ended up transcribing its own
    voice as the owner's. leon_transport.py already ate this exact bug once
    for the socket path; same mistake, second file.
    """
    import tempfile
    override = os.environ.get("LEON_TTS_MARKER", "").strip()
    if override:
        return override
    return os.path.join(tempfile.gettempdir(), "leon-tts-active")


DEFAULT_MARKER = _default_marker_path()


def marker_publisher(marker_path: str = DEFAULT_MARKER,
                     running=lambda: True, poll_s: float = 0.1,
                     stale_s: float = 30.0) -> None:
    """Bridge a cross-process TTS marker file into the ledger.

    The mic (and therefore the wake listener) lives in the PC relay
    process; TTS is synthesized on the VPS and played by the dashboard.
    The only channel between them is the marker file the actuator touches
    for the playback window — so this translates marker→interval.

    It polls because a file is the transport, but it is NOT the old
    polling gate: it publishes into the one ledger instead of holding its
    own copy of the state, and it BACK-DATES the interval to the marker's
    mtime, so the poll interval no longer creates a latency window where
    Leon's first syllable slips through ungated.

    Run it in a daemon thread; it returns when `running()` is False.
    """
    handle: Optional[int] = None
    opened_mtime = 0.0
    while running():
        try:
            exists = os.path.exists(marker_path)
            mtime = os.path.getmtime(marker_path) if exists else 0.0
            fresh = exists and (time.time() - mtime) < stale_s
        except OSError:
            fresh, mtime = False, 0.0
        # A barge-in (`note_barge_in`) ends every interval underneath us,
        # including this one. Treat that as "no longer ours": if the
        # marker is later touched AGAIN — new playback after the
        # interruption — open a fresh interval instead of assuming the
        # closed one still covers it.
        if handle is not None and not LEDGER.is_open(handle):
            handle = None
        if fresh and handle is None and mtime > opened_mtime:
            handle = LEDGER.open(source="tts-marker", start_ts=mtime)
            opened_mtime = mtime
        elif not fresh and handle is not None:
            LEDGER.close(handle)
            handle = None
        time.sleep(poll_s)
    if handle is not None:
        LEDGER.close(handle)


# ---------------------------------------------------------------------------
# Near-duplicate transcript suppression
# ---------------------------------------------------------------------------
# Distinct from transcript_is_self_echo(), which catches Leon hearing his OWN
# voice through the speakers. This catches the OTHER duplicate: the SAME human
# utterance getting transcribed and routed twice, seconds apart, with slightly
# different wording each time ("...he does not sleep" / "...he doesn't sleep").
# An exact-match guard never fires on those, because ASR is non-deterministic
# on a re-decode. So compare fuzzily inside a short time window.

REPEAT_WINDOW_S = 25.0      # beyond this, a repeat is probably intentional
REPEAT_SIMILARITY = 0.72    # ratio above which two transcripts are "the same"


def transcript_is_near_repeat(
    text: str,
    last_text: str,
    dt: float,
    window_s: float = REPEAT_WINDOW_S,
    threshold: float = REPEAT_SIMILARITY,
):
    """True if `text` is a re-transcription of `last_text`.

    Returns (is_repeat, similarity). Only fires inside `window_s`, so a
    genuine repeat minutes later ("I said, check the logs") still gets through.
    """
    from difflib import SequenceMatcher
    if not text or not last_text:
        return False, 0.0
    if dt < 0 or dt > window_s:
        return False, 0.0
    a = _norm_words(text)
    b = _norm_words(last_text)
    if not a or not b:
        return False, 0.0
    # Compare WORD sequences, not characters. Two things matter here:
    #  1. autojunk=False — difflib's heuristic treats elements appearing in
    #     >1% of a long sequence as junk, which on a 60-word utterance means
    #     every common word is ignored and the ratio collapses (measured 0.28
    #     on a pair that is obviously the same sentence). That heuristic is
    #     built for source diffs, not prose.
    #  2. Word-level alignment survives ASR swapping "talk"/"talked",
    #     "doesn't"/"does not" — character-level does not.
    ratio = SequenceMatcher(None, a, b, autojunk=False).ratio()
    if ratio >= threshold:
        return True, ratio
    # Fall back to bag-of-words overlap (Jaccard). Catches the case where ASR
    # reorders or drops a clause, which wrecks sequence alignment but leaves
    # the vocabulary nearly identical.
    sa, sb = set(a), set(b)
    jac = len(sa & sb) / max(1, len(sa | sb))
    if jac >= threshold and min(len(a), len(b)) >= 8:
        return True, jac
    return False, max(ratio, jac)


def _norm_words(text: str):
    """Lowercase, strip punctuation, expand the contractions ASR flips on."""
    import re as _re
    t = text.lower()
    for a, b in (("n't", " not"), ("'re", " are"), ("'s", " is"),
                 ("'ll", " will"), ("'ve", " have"), ("'m", " am")):
        t = t.replace(a, b)
    t = _re.sub(r"[^a-z0-9 ]+", " ", t)
    return t.split()
