"""
ingress_gate.py — the CONSUMER-side net for transcribed utterances.

Why this exists (2026-08-05, rows 15895/15896)
----------------------------------------------
Every self-hearing defence lived on the PRODUCER side: sensor_relay gates
mic chunks by capture timestamp, checks wake phrases, runs the text
tiebreaker — all on Dean's PC. The VPS ingress (/api/relay/heard →
handle_voice_utterance) trusted whatever text arrived and handed it to
the responder, which stored it as Dean (claude_api_responder.py:3061,
model='pre-response'). One producer failure — a stale relay process, the
tts.marker_set actuator call swallowed by its except-pass, a different
mic path — and Leon's own voice was filed as Dean's words. Proven:
conversation_history rows 15895 (Leon's spoken reply) and 15896 (the
same reply, Whisper-garbled, role=user, 0.919 token overlap).

This module is the second, consumer-side net at the last shared point
before storage — in the SAME process whose audio_gate LEDGER was armed
with the exact playback interval and the spoken text all along.

The rules (inherited from audio_gate, do not weaken them)
---------------------------------------------------------
* When the producer supplies the capture timestamp, use THE gate rule:
  a transcript whose audio was captured inside a speaker interval is
  rejected no matter when it arrives, and the text check runs as the
  tiebreaker it was designed to be (`transcript_is_self_echo_at`).
* When there is no capture timestamp (today's producers don't send one),
  arrival time bounds capture time: STT + network put the POST within a
  bounded lag of the audio. The text-echo check may then reject ONLY if
  a speaker interval overlaps that plausible capture window — text alone
  is NEVER sufficient. Dean quotes Leon back constantly; a transcript
  rejected in error is a turn he has to say twice.
* Speakers live RIGHT NOW with no barge-in ⇒ reject outright. A
  legitimate barge-in ends the intervals (note_barge_in), so this only
  fires when a producer's own gates have already failed.

Env:
    LEON_VOICE_INGRESS_STT_WINDOW_S=12   plausible capture-to-arrival lag
    LEON_VOICE_INGRESS_GATE=0            disable (debug) — audio_gate's
                                         master switch also disables this
"""

from __future__ import annotations

import os
import time
from typing import Optional, Tuple

from brain.voice import audio_gate


def _env_float(name: str, default: float) -> float:
    try:
        v = os.environ.get(name, "").strip()
        return float(v) if v else default
    except (TypeError, ValueError):
        return default


#: How long before its arrival an utterance's audio could plausibly have
#: been captured. Whisper on the PC GPU takes ~1-4s for a sentence and the
#: POST is immediate; 12s is generous without reaching back far enough to
#: collide with Dean discussing a reply Leon finished a while ago.
STT_WINDOW_S: float = _env_float("LEON_VOICE_INGRESS_STT_WINDOW_S", 12.0)


def enabled() -> bool:
    return (os.environ.get("LEON_VOICE_INGRESS_GATE", "1").strip() != "0"
            and audio_gate.enabled())


def verdict(text: str, source: str = "voice",
            captured_ts: Optional[float] = None,
            now: Optional[float] = None) -> Tuple[bool, str, float]:
    """Should this transcribed utterance be treated as the user speaking?

    Returns (accept, reason, echo_score). `echo_score` is the best token
    overlap against Leon's recent speech — logged either way so a wrong
    threshold is visible in the logs before it is felt in conversation.
    """
    now = time.time() if now is None else now
    text = (text or "").strip()
    if not text:
        return False, "empty", 0.0
    if not enabled():
        return True, "gate-disabled", 0.0

    # The text-echo window must reach back past the START of a long clip:
    # LEDGER._spoken stamps sentences at playback START, and a 45s reply
    # has aged out of the default 12s window before its own echo can even
    # arrive (that is precisely the row-15896 case — long reply, echo
    # POSTed after the tail). Widening the SCORE window is safe: text
    # still only ever rejects alongside the audio-position condition.
    text_window_s = STT_WINDOW_S + audio_gate.MAX_OPEN_INTERVAL_S

    if captured_ts is not None:
        # Producer told us when the audio was captured — use THE gate rule.
        if audio_gate.audio_is_speaker(captured_ts, now=now):
            return False, "captured-during-playback", 1.0
        echoed, score = audio_gate.transcript_is_self_echo_at(
            text, captured_ts,
            window_s=max(text_window_s, (now - captured_ts) + text_window_s),
            now=now)
        if echoed:
            return False, "self-echo-text", score
        return True, "ok", score

    # No capture timestamp. Arrival bounds capture: the audio behind this
    # transcript was recorded somewhere in [now - STT_WINDOW_S, now].
    if audio_gate.audio_is_speaker(now, now=now):
        # Leon's voice is coming out of the speakers at `now` and no
        # barge-in has ended the interval. A real Dean turn arrives through
        # paths that DO end it (PTT) or through producer gates that hold
        # audio back; text landing here now is a failed producer's leak.
        # (audio_is_speaker(now) rather than speaker_active_now(): same
        # question, but it honours an injected clock — tests and replays
        # must be able to ask about instants other than the wall clock.)
        return False, "speakers-live-now", 1.0

    echoed, score = audio_gate.transcript_is_self_echo(
        text, window_s=text_window_s, now=now)
    if echoed and audio_gate.audio_near_speaker(
            now - STT_WINDOW_S, span_s=STT_WINDOW_S, now=now):
        # High overlap with something Leon just said AND playback overlaps
        # the plausible capture window. Both conditions — never text alone.
        return False, "self-echo-near-playback", score
    return True, "ok", score
