"""
ingress_gate.py — the CONSUMER-side net for transcribed utterances.

Why this exists (2026-08-05, rows 15895/15896)
----------------------------------------------
Every self-hearing defence lived on the PRODUCER side: sensor_relay gates
mic chunks by capture timestamp, checks wake phrases, runs the text
tiebreaker — all on Dean's PC. The VPS ingress (/api/relay/heard →
handle_voice_utterance) trusted whatever text arrived and handed it to
the responder, which stored it as Dean (claude_api_responder.py:3061,
model='pre-response'). One producer failure — a stale relay process, the
tts.marker_set actuator call swallowed by its except-pass, a different
mic path — and Leon's own voice was filed as Dean's words. Proven:
conversation_history rows 15895 (Leon's spoken reply) and 15896 (the
same reply, Whisper-garbled, role=user, 0.919 token overlap).

This module is the second, consumer-side net at the last shared point
before storage — in the SAME process whose audio_gate LEDGER was armed
with the exact playback interval and the spoken text all along.

The rules (inherited from audio_gate, do not weaken them)
---------------------------------------------------------
* When the producer supplies the capture timestamp, use THE gate rule:
  a transcript whose audio was captured inside a speaker interval is
  rejected no matter when it arrives, and the text check runs as the
  tiebreaker it was designed to be (`transcript_is_self_echo_at`).
* When there is no capture timestamp (today's producers don't send one),
  arrival time bounds capture time: STT + network put the POST within a
  bounded lag of the audio. The text-echo check may then reject ONLY if
  a speaker interval overlaps that plausible capture window — text alone
  is NEVER sufficient. Dean quotes Leon back constantly; a transcript
  rejected in error is a turn he has to say twice.
* Speakers live RIGHT NOW with no barge-in ⇒ reject outright. A
  legitimate barge-in ends the intervals (note_barge_in), so this only
  fires when a producer's own gates have already failed.

Env:
    LEON_VOICE_INGRESS_STT_WINDOW_S=12   plausible capture-to-arrival lag
    LEON_VOICE_INGRESS_GATE=0            disable (debug) — audio_gate's
                                         master switch also disables this
"""

from __future__ import annotations

import os
import time
from typing import Optional, Tuple

from brain.voice import audio_gate


def _env_float(name: str, default: float) -> float:
    try:
        v = os.environ.get(name, "").strip()
        return float(v) if v else default
    except (TypeError, ValueError):
        return default


#: How long before its arrival an utterance's audio could plausibly have
#: been captured. Whisper on the PC GPU takes ~1-4s for a sentence and the
#: POST is immediate; 12s is generous without reaching back far enough to
#: collide with Dean discussing a reply Leon finished a while ago.
STT_WINDOW_S: float = _env_float("LEON_VOICE_INGRESS_STT_WINDOW_S", 12.0)

#: Plausibility bounds on a capture stamp that arrived from another machine.
#: Audio cannot be captured in the future (small slack absorbs honest jitter
#: and sub-second clock differences), and cannot plausibly be older than one
#: STT window. The relay POSTs immediately after transcription (~1-4s), so
#: an HONEST stamp is always young — even mid-barge-in during a 45s reply,
#: because it stamps the capture, not the reply. The ceiling is therefore
#: tight on purpose: anything older is skew, and falling back costs only
#: the barge-in allowance, while trusting it costs a forged user turn.
CAPTURE_FUTURE_SLACK_S: float = _env_float(
    "LEON_VOICE_CAPTURE_FUTURE_SLACK_S", 2.0)
CAPTURE_MAX_AGE_S: float = _env_float(
    "LEON_VOICE_CAPTURE_MAX_AGE_S", 20.0)


def enabled() -> bool:
    return (os.environ.get("LEON_VOICE_INGRESS_GATE", "1").strip() != "0"
            and audio_gate.enabled())


def verdict(text: str, source: str = "voice",
            captured_ts: Optional[float] = None,
            now: Optional[float] = None) -> Tuple[bool, str, float]:
    """Should this transcribed utterance be treated as the user speaking?

    Returns (accept, reason, echo_score). `echo_score` is the best token
    overlap against Leon's recent speech — logged either way so a wrong
    threshold is visible in the logs before it is felt in conversation.
    """
    now = time.time() if now is None else now
    text = (text or "").strip()
    if not text:
        return False, "empty", 0.0
    if not enabled():
        return True, "gate-disabled", 0.0

    # The text-echo window must reach back past the START of a long clip:
    # LEDGER._spoken stamps sentences at playback START, and a 45s reply
    # has aged out of the default 12s window before its own echo can even
    # arrive (that is precisely the row-15896 case — long reply, echo
    # POSTed after the tail). Widening the SCORE window is safe: text
    # still only ever rejects alongside the audio-position condition.
    text_window_s = STT_WINDOW_S + audio_gate.MAX_OPEN_INTERVAL_S

    # CLOCK-SKEW GUARD — captured_ts crosses a MACHINE boundary.
    # The relay posts epoch seconds from the BODY PC; this gate runs on the
    # VPS. Nothing keeps those two wall clocks in step, and a skewed stamp
    # makes this gate fail OPEN: the capture instant lands outside every
    # playback interval, so Leon's own voice is accepted as a user turn —
    # which under full autonomy is instruction forgery, not a nuisance.
    # Reproduced 2026-08-10 against the live gate: same echo text, same
    # ledger, +45s skew -> "ok", -45s skew -> "ok", no skew -> rejected.
    # A stamp that cannot be true is worse than no stamp, because it
    # OVERRIDES the arrival-window rule that catches this case on its own
    # (verified: falls through to "speakers-live-now").
    # The guard does NOT simply discard the stamp: a stale-but-honest stamp
    # is the ONLY thing that rejects audio captured mid-playback and consumed
    # minutes later (test_captured_ts_rule_survives_late_consume), and
    # dropping it there fails open too. So a suspect stamp is DEMOTED, not
    # deleted — its own rule still runs, and the arrival rule runs as well,
    # and either one may reject. Suspicion can only ever make this stricter.
    # NOTE: do NOT "fix" this with time.monotonic() — monotonic values are
    # meaningless across processes and machines, and this stamp arrives
    # over HTTP from another box.
    _skewed = False
    if captured_ts is not None:
        _age = now - captured_ts
        if _age < -CAPTURE_FUTURE_SLACK_S or _age > CAPTURE_MAX_AGE_S:
            _skewed = True
            print(f"[INGRESS] captured_ts implausible (age={_age:.1f}s) — "
                  f"clock skew suspected, also applying arrival rule")

    if captured_ts is not None:
        # Producer told us when the audio was captured — use THE gate rule.
        if audio_gate.audio_is_speaker(captured_ts, now=now):
            return False, "captured-during-playback", 1.0
        echoed, score = audio_gate.transcript_is_self_echo_at(
            text, captured_ts,
            window_s=max(text_window_s, (now - captured_ts) + text_window_s),
            now=now)
        if echoed:
            return False, "self-echo-text", score
        if not _skewed:
            return True, "ok", score
        # Skewed and the capture rule cleared it — fall through to the
        # arrival rule, which does not depend on the other machine's clock.

    # No capture timestamp. Arrival bounds capture: the audio behind this
    # transcript was recorded somewhere in [now - STT_WINDOW_S, now].
    if audio_gate.audio_is_speaker(now, now=now):
        # Leon's voice is coming out of the speakers at `now` and no
        # barge-in has ended the interval. A real Dean turn arrives through
        # paths that DO end it (PTT) or through producer gates that hold
        # audio back; text landing here now is a failed producer's leak.
        # (audio_is_speaker(now) rather than speaker_active_now(): same
        # question, but it honours an injected clock — tests and replays
        # must be able to ask about instants other than the wall clock.)
        return False, "speakers-live-now", 1.0

    echoed, score = audio_gate.transcript_is_self_echo(
        text, window_s=text_window_s, now=now)
    if echoed and audio_gate.audio_near_speaker(
            now - STT_WINDOW_S, span_s=STT_WINDOW_S, now=now):
        # High overlap with something Leon just said AND playback overlaps
        # the plausible capture window. Both conditions — never text alone.
        return False, "self-echo-near-playback", score
    return True, "ok", score
