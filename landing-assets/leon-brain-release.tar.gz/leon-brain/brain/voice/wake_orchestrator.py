"""
Wake Orchestrator — owns the always-listening conversation loop.

When `WakeWordListener` fires:
  1. Capture utterance (the listener already does this, hands us PCM)
  2. Run STT (faster-whisper)
  3. Hand transcript to BrainAPIResponder via the same path text input
     uses, so per-sentence TTS / streaming / tools all work for free
  4. Pause the listener for the duration of TTS playback so Leon
     doesn't hear his own voice and re-trigger
  5. Re-arm

The server module instantiates a single Orchestrator and passes:
  - the WakeWordListener
  - the brain (for inject_sensory_input + state)
  - the BrainAPIResponder
  - a `notify` callable that pushes events to all WebSocket clients
    (`{type: "wake_listening" | "wake_triggered" | "wake_transcribed", ...}`)
  - a `tts_speak` callable that yields per-sentence WAV (or returns a
    list of WAVs); orchestrator pauses listener for the full duration
"""

from __future__ import annotations

import threading
import time
from typing import Any, Callable, Optional

from brain.voice.wake_word import UtteranceCapture, pcm16_to_wav_bytes


class WakeOrchestrator:
    def __init__(
        self,
        listener: Any,                   # WakeWordListener | VoskWakeWordListener
        brain,
        text_encoder,
        responder,                       # BrainAPIResponder
        notify: Callable[[dict], None],  # broadcast to all WS clients
        tts_for_text: Callable[[str], Optional[dict]],  # per-sentence b64 WAV
        stt=None,                        # optional pre-built brain.voice.stt.STT
        confirm_callback: Optional[Callable[[str, dict, str], bool]] = None,
        responder_lock: Optional[threading.Lock] = None,
    ):
        self.listener = listener
        self.brain = brain
        self.text_encoder = text_encoder
        self.responder = responder
        self.notify = notify
        self.tts_for_text = tts_for_text
        self._stt = stt
        self._stt_lock = threading.Lock()
        self._busy = threading.Event()  # set ⇒ a wake cycle is active
        # Approver for HIGH-risk tools triggered from a voice command. The
        # text-input path uses a per-WS callback that targets a single tab;
        # voice has no originating tab, so this one should broadcast the
        # modal to every dashboard and accept the first answer.
        self._confirm_cb = confirm_callback
        # Shared with the text-input path and the proactive loop. Held
        # for the full responder stream so proactive's non-blocking
        # acquire skips its cycle while a wake turn is mid-flight.
        self._responder_lock = responder_lock

        # Wire the listener's callbacks into our handlers
        listener.on_wake = self._on_wake
        listener.on_utterance = self._on_utterance

    # ── Lazy STT init ────────────────────────────────────────────────────
    def _get_stt(self):
        if self._stt is not None:
            return self._stt
        import os as _os
        with self._stt_lock:
            if self._stt is None:
                # Try the server's pre-warmed instance first — saves us
                # ~5-15s on the first wake if pre-warm finished by now.
                try:
                    import server as _srv
                    if getattr(_srv, "_prewarmed_stt", None) is not None:
                        self._stt = _srv._prewarmed_stt
                        print("[WAKE-ORCH] using pre-warmed STT")
                        return self._stt
                except Exception:
                    pass
                from brain.voice.stt import STT
                # "small" is the sweet spot: noticeably better than "base"
                # on accents/noise/short utterances, ~3x slower (still
                # well under realtime on CPU). Configurable via env so
                # Dean can A/B "tiny"/"base"/"small"/"medium" without
                # editing code. Default = "small" (was "base").
                size = _os.environ.get("LEON_STT_MODEL_SIZE", "small").strip().lower()
                self._stt = STT(model_size=size)
                print(f"[WAKE-ORCH] STT loaded: {self._stt.backend_name} ({size})")
        return self._stt

    # ── Listener callbacks (run on listener thread) ──────────────────────
    def _on_wake(self, event) -> None:
        self._busy.set()
        # Pause downstream wake detection while we capture + speak the
        # response. The listener also drains its queue so it doesn't
        # pile up audio behind us.
        try:
            self.notify({
                "type": "wake_triggered",
                "wake_word": event.wake_word,
                "score": round(event.score, 3),
                "ts": event.ts,
            })
        except Exception:
            pass

    def _on_utterance(self, capture: UtteranceCapture) -> None:
        try:
            self._handle_utterance(capture)
        finally:
            self._busy.clear()
            # Resume in case TTS path didn't reset us (e.g. STT empty,
            # exception, etc.)
            self.listener.resume()

    # ── Wake → STT → Brain → TTS ─────────────────────────────────────────
    def _handle_utterance(self, capture: UtteranceCapture) -> None:
        # Pause the listener while we do all the heavy lifting; resume
        # in the finally block of the caller. This is the simplest way
        # to prevent self-triggering without timing knowledge of TTS.
        self.listener.pause()

        # 1) STT
        try:
            stt = self._get_stt()
            result = stt.transcribe(capture.pcm16, sample_rate=16000)
            transcript = (result.text or "").strip()
        except Exception as e:
            print(f"[WAKE-ORCH] STT failed: {e}")
            transcript = ""

        # Clock-free self-echo check before we burn a Claude turn: if the
        # transcript is mostly words Leon himself just spoke, the mic heard
        # the speakers, not Dean. (The capture-timestamp gate in the
        # listener should already have dropped that audio — this is the
        # independent second line of defence, and it is content-based, so
        # it holds even if every clock in the system is wrong.)
        try:
            from brain.voice import audio_gate
            echoed, overlap = audio_gate.transcript_is_self_echo(transcript)
            if echoed:
                print(f"[WAKE-ORCH] utterance dropped — echo of Leon's own "
                      f"speech (overlap={overlap:.2f}): {transcript[:60]!r}")
                transcript = ""
        except Exception:
            pass

        # Addressing gate: the wake word proves a SOUND happened, not that
        # the sentence was aimed at Leon. Dean talking to Wesley *about*
        # Leon used to fire a wake and burn a full Opus turn answering a
        # conversation Leon wasn't in. Judged on the cheap lane, and it
        # fails OPEN — a false silence is worse than a false answer.
        if transcript:
            try:
                from brain.voice import addressing_gate
                addressed, why = addressing_gate.is_addressed_to_leon(
                    transcript,
                    push_to_talk=bool(getattr(capture, "push_to_talk", False)),
                )
                if not addressed:
                    print(f"[WAKE-ORCH] utterance dropped — not addressed to "
                          f"Leon ({why}): {transcript[:60]!r}")
                    transcript = ""
            except Exception as e:
                print(f"[WAKE-ORCH] addressing gate error, answering: {e}")

        if not transcript or transcript.lower().startswith("[mock"):
            # No usable speech — short-circuit, no Claude burn.
            try:
                self.notify({
                    "type": "wake_transcribed",
                    "transcript": "",
                    "duration_s": round(capture.duration_s, 2),
                    "wake_word": capture.wake_word,
                    "rejected": True,
                })
            except Exception:
                pass
            return

        try:
            self.notify({
                "type": "wake_transcribed",
                "transcript": transcript,
                "duration_s": round(capture.duration_s, 2),
                "wake_word": capture.wake_word,
                "rejected": False,
            })
        except Exception:
            pass

        # 2) Inject into the brain so neuromodulators move on this input
        try:
            features = self.text_encoder.encode(transcript)
            self.brain.inject_sensory_input("text", features)
        except Exception as e:
            print(f"[WAKE-ORCH] inject failed: {e}")

        # 3) Stream Claude's reply, and synthesize per-sentence TTS so the
        # first sentence speaks while later ones are still generating.
        response_id = f"w{int(time.time()*1000)}"
        try:
            state = self.brain.get_state()
        except Exception:
            state = {}

        # Tell every dashboard client a streaming response is starting
        try:
            self.notify({
                "type": "brain_response_start",
                "user": transcript, "response_id": response_id,
                "from_wake": True,
            })
        except Exception:
            pass

        full = ""
        # Acquire the shared responder lock for the full stream so the
        # proactive loop won't try to interleave a parallel turn.
        if self._responder_lock is not None:
            self._responder_lock.acquire()
        try:
            for ev in self.responder.respond_streaming(
                transcript, state, confirm_callback=self._confirm_cb, supervised=True,
            ):
                if ev.type == "model":
                    self.notify({"type": "brain_response_model",
                                 "response_id": response_id,
                                 "model": ev.model, "tier": ev.tier})
                elif ev.type == "tool_use":
                    self.notify({"type": "brain_tool_use",
                                 "response_id": response_id,
                                 "tool": ev.text, "tool_id": ev.tool_id,
                                 "risk": ev.risk, "input": ev.full_text})
                elif ev.type == "tool_result":
                    self.notify({"type": "brain_tool_result",
                                 "response_id": response_id,
                                 "tool": ev.text, "tool_id": ev.tool_id,
                                 "summary": ev.full_text})
                elif ev.type == "delta":
                    self.notify({"type": "brain_response_delta",
                                 "response_id": response_id,
                                 "text": ev.text})
                elif ev.type == "sentence":
                    # Per-sentence TTS — same shape the WS handler uses
                    audio = self.tts_for_text(ev.text)
                    if audio:
                        self.notify({"type": "brain_audio",
                                     "response_id": response_id,
                                     "sentence_index": ev.index, **audio})
                elif ev.type == "done":
                    full = ev.full_text
                    self.notify({"type": "brain_response_end",
                                 "response_id": response_id,
                                 "response": full})
                elif ev.type == "error":
                    self.notify({"type": "brain_response_end",
                                 "response_id": response_id,
                                 "response": f"(error: {ev.error})"})
        except Exception as e:
            print(f"[WAKE-ORCH] stream failed: {e}")
            self.notify({"type": "brain_response_end",
                         "response_id": response_id,
                         "response": f"(error: {e})"})
        finally:
            if self._responder_lock is not None:
                try: self._responder_lock.release()
                except Exception: pass

        # 4) Listener stays paused until the resume() call in _on_utterance
        # finally block — and the dashboard can ALSO ping the listener to
        # resume earlier (e.g. once it knows TTS is done) via the WS.

    # ── State for /api/wake/state ────────────────────────────────────────
    def get_state(self) -> dict:
        s = self.listener.get_state()
        s["busy"] = self._busy.is_set()
        return s
