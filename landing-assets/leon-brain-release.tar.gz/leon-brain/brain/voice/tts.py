"""
Text-to-Speech.

Backends (preference order):
  1. Piper         — local, fast, open-source, decent quality
  2. pyttsx3       — system TTS (SAPI on Windows, NSSpeech on macOS, espeak on Linux)
  3. ElevenLabs    — highest quality, cloud, requires key
  4. Mock          — silent WAV for testing

Every backend exposes .speak(text) → bytes of WAV audio plus an optional
streaming generator synthesize_stream(text) for barge-in support.
"""

from __future__ import annotations

import io
import os
import struct
import wave
from dataclasses import dataclass
from typing import Any, Generator, Optional


@dataclass
class TTSResult:
    wav_bytes: bytes
    sample_rate: int
    backend: str
    duration_sec: float


class _MockTTS:
    name = "mock"

    def speak(self, text: str) -> TTSResult:
        # Generate 0.5s of silence per 20 characters as a stand-in
        sr = 16000
        seconds = max(0.3, len(text) / 40.0)
        n_samples = int(sr * seconds)
        pcm = b"\x00\x00" * n_samples
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(pcm)
        return TTSResult(
            wav_bytes=buf.getvalue(),
            sample_rate=sr,
            backend=self.name,
            duration_sec=seconds,
        )


class _Pyttsx3TTS:
    name = "pyttsx3"

    def __init__(self):
        try:
            import pyttsx3  # type: ignore
        except ImportError as e:
            raise RuntimeError("pyttsx3 not installed") from e
        self._engine = pyttsx3.init()

    def speak(self, text: str) -> TTSResult:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            path = tmp.name
        try:
            self._engine.save_to_file(text, path)
            self._engine.runAndWait()
            with open(path, "rb") as f:
                wav = f.read()
            with wave.open(io.BytesIO(wav), "rb") as w:
                sr = w.getframerate()
                duration = w.getnframes() / sr
            return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)
        finally:
            try:
                os.remove(path)
            except Exception:
                pass


def speakable(text: str) -> str:
    """Turn written text into text meant to be HEARD.

    Piper's phonemizer reads punctuation literally, which is why periods kept
    coming out as the word "dot" — an ellipsis becomes "dot dot dot", a domain
    like sabr.co becomes "sabr dot co", and a bullet or asterisk gets spoken
    outright. None of that is Piper being broken; nothing was ever cleaning
    the string. This does.

    Applied to every backend, not just Piper, so the fix can't drift again
    the way the Kokoro wiring did.
    """
    import re

    t = text

    # Markdown scaffolding — asterisks and backticks get read aloud.
    t = re.sub(r"[*_`#>]+", " ", t)
    # Bullets and list glyphs.
    t = re.sub(r"^[\s\-•·–]+", "", t, flags=re.MULTILINE)
    # Ellipsis -> a real pause, not three spoken dots.
    t = re.sub(r"\.{2,}", ",", t)
    # Dashes used as pauses -> comma. Keeps the rhythm, loses the word.
    t = re.sub(r"\s*[—–]\s*", ", ", t)
    # Bare URLs read as an unbroken stream of symbols. This MUST run before
    # the domain rule below — otherwise the domain rule splits the host, the
    # URL pattern then only matches the front half, and you get the literal
    # nonsense "a link com/dashboard". Caught by the test, not by reading it.
    t = re.sub(r"https?://\S+", "a link", t)
    # Domains and file extensions: say the name, not the punctuation.
    t = re.sub(r"\b([A-Za-z0-9-]+)\.(com|org|net|io|co|ai|dev|py|js|sh|md|json)\b",
               r"\1 \2", t)
    # Stray symbols with no spoken form.
    t = re.sub(r"[\[\]{}|\\<>~^]+", " ", t)
    t = t.replace("&", " and ").replace("%", " percent").replace("+", " plus ")
    # Collapse the whitespace all that substitution just created.
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s*\n\s*", ". ", t.strip())
    # Substitution can leave doubled punctuation, which reads as a stumble.
    t = re.sub(r"([,.])\s*[,.]+", r"\1", t)
    return t.strip()


class _PiperTTS:
    name = "piper"

    def __init__(self, model_path: Optional[str] = None):
        try:
            from piper import PiperVoice  # type: ignore
        except ImportError as e:
            raise RuntimeError("piper-tts not installed") from e
        if model_path is None:
            # Look for a default model in brain_state/voice/piper/
            # Users should drop en_US-lessac-medium.onnx in that folder.
            raise RuntimeError("Piper voice model path not provided")
        if not os.path.exists(model_path):
            raise RuntimeError(f"Piper model not found: {model_path}")
        self._voice = PiperVoice.load(model_path)

    def speak(self, text: str) -> TTSResult:
        # Piper also clips last word without trailing punctuation
        tts_text = speakable(text).rstrip()
        if tts_text and tts_text[-1] not in ".!?;:—":
            tts_text += "."
        # piper-tts >=1.4 split the API: `synthesize` returns audio chunks,
        # `synthesize_wav` writes a fully-formed WAV (header + frames) to
        # the given wave.Wave_write. Let it set its own WAV format so we
        # don't double-write the header.
        # length_scale < 1.0 = faster speech. Env-tunable.
        from piper.config import SynthesisConfig
        _speed = float(os.environ.get("PIPER_LENGTH_SCALE", "0.75"))
        _syn = SynthesisConfig(length_scale=_speed)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            self._voice.synthesize_wav(tts_text, w, syn_config=_syn,
                                       set_wav_format=True)
        wav = buf.getvalue()
        with wave.open(io.BytesIO(wav), "rb") as w:
            sr = w.getframerate()
            duration = w.getnframes() / sr if sr > 0 else 0.0
        return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)


class _ElevenLabsTTS:
    name = "elevenlabs"

    def __init__(self, voice_id: Optional[str] = None):
        self.api_key = os.environ.get("ELEVENLABS_API_KEY")
        if not self.api_key:
            raise RuntimeError("ELEVENLABS_API_KEY not set")
        self.voice_id = voice_id or os.environ.get("ELEVENLABS_VOICE_ID") or "21m00Tcm4TlvDq8ikWAM"
        self.model_id = os.environ.get("ELEVENLABS_MODEL", "eleven_turbo_v2_5")
        # Free-tier accounts can't request raw PCM (402 Payment Required) —
        # only mp3. Discovered live 2026-06-11 with Dean's new key. We try
        # PCM first (best path, no transcode) and remember the downgrade.
        self._use_mp3 = False

    def _request(self, tts_text: str, fmt: str) -> bytes:
        import urllib.request
        import json
        url = (f"https://api.elevenlabs.io/v1/text-to-speech/"
               f"{self.voice_id}/stream?output_format={fmt}")
        settings = {
            # Higher stability = flatter, more controlled delivery — pairs
            # with the LEON_VOICE_FX robot treatment. Env-tunable.
            "stability": float(os.environ.get("ELEVENLABS_STABILITY", "0.5")),
            "similarity_boost": float(os.environ.get("ELEVENLABS_SIMILARITY", "0.75")),
        }
        _style = os.environ.get("ELEVENLABS_STYLE", "").strip()
        if _style:
            settings["style"] = float(_style)
        body = json.dumps({
            "text": tts_text,
            "model_id": self.model_id,
            "voice_settings": settings,
        }).encode("utf-8")
        req = urllib.request.Request(
            url, data=body,
            headers={
                "xi-api-key": self.api_key,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read()

    def speak(self, text: str) -> TTSResult:
        import urllib.error
        # ElevenLabs clips the last word if text doesn't end with punctuation.
        tts_text = text.rstrip()
        if tts_text and tts_text[-1] not in ".!?;:—":
            tts_text += "."

        raw = None
        if not self._use_mp3:
            try:
                raw = self._request(tts_text, "pcm_16000")
            except urllib.error.HTTPError as e:
                if e.code != 402:
                    raise
                # PCM is paid-tier only — drop to mp3 for this process's life.
                self._use_mp3 = True
        if self._use_mp3:
            mp3 = self._request(tts_text, "mp3_44100_128")
            # Transcode mp3 → 16k mono WAV via ffmpeg (present on the VPS).
            import subprocess
            proc = subprocess.run(
                ["ffmpeg", "-hide_banner", "-loglevel", "error",
                 "-i", "pipe:0", "-f", "wav", "-acodec", "pcm_s16le",
                 "-ar", "16000", "-ac", "1", "pipe:1"],
                input=mp3, capture_output=True, timeout=30,
            )
            if proc.returncode != 0 or not proc.stdout:
                raise RuntimeError(
                    f"ffmpeg transcode failed: {proc.stderr[:200]!r}")
            wav_bytes = proc.stdout
            duration = max(0.0, (len(wav_bytes) - 44) / 2 / 16000)
            return TTSResult(wav_bytes=wav_bytes, sample_rate=16000,
                             backend=self.name, duration_sec=duration)

        # PCM path — wrap raw PCM in a WAV header
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            w.writeframes(raw)
        duration = len(raw) / 2 / 16000
        return TTSResult(wav_bytes=buf.getvalue(), sample_rate=16000,
                         backend=self.name, duration_sec=duration)


class _KokoroTTS:
    """Kokoro-82M via isolated venv. Local, free, no API key, no quota."""
    name = "kokoro"
    VENV = "/opt/kokoro-venv/bin/python"
    DIR = "/opt/leon-brain/brain_state/voice/kokoro"

    def __init__(self, voice: Optional[str] = None):
        import os as _os
        if not _os.path.exists(self.VENV):
            raise RuntimeError("kokoro venv missing")
        if not _os.path.exists(_os.path.join(self.DIR, "kokoro-v1.0.onnx")):
            raise RuntimeError("kokoro model missing")
        self.voice = voice or _os.environ.get("LEON_KOKORO_VOICE", "am_michael")
        self.speed = float(_os.environ.get("LEON_KOKORO_SPEED", "1.05"))

    def speak(self, text: str) -> TTSResult:
        import subprocess, tempfile, json, os as _os
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            out = f.name
        script = (
            "import sys,soundfile as sf\n"
            "from kokoro_onnx import Kokoro\n"
            "txt=sys.stdin.read()\n"
            "k=Kokoro(r'%s/kokoro-v1.0.onnx',r'%s/voices-v1.0.bin')\n"
            "s,sr=k.create(txt,voice=%r,speed=%r,lang=%r)\n"
            "sf.write(r'%s',s,sr)\n"
            "print(sr)\n" % (self.DIR, self.DIR, self.voice, self.speed,
               'en-gb' if self.voice.startswith(('bm_', 'bf_')) else 'en-us', out)
        )
        pr = subprocess.run([self.VENV, "-c", script], input=text.encode(),
                            capture_output=True, timeout=120)
        if pr.returncode != 0 or not _os.path.exists(out):
            raise RuntimeError("kokoro synth failed: %s" % pr.stderr.decode()[-300:])
        wav_bytes = open(out, "rb").read()
        _os.unlink(out)
        with wave.open(io.BytesIO(wav_bytes)) as w:
            sr = w.getframerate()
            dur = w.getnframes() / float(sr)
        return TTSResult(wav_bytes=wav_bytes, sample_rate=sr,
                         backend=self.name, duration_sec=dur)


class TTS:
    def __init__(
        self,
        prefer: Optional[str] = None,
        piper_model: Optional[str] = None,
        elevenlabs_voice_id: Optional[str] = None,
    ):
        self.backend: Any = None
        self.backend_name: str = ""
        order = [prefer] if prefer else []
        order += ["kokoro", "piper", "pyttsx3", "elevenlabs", "mock"]
        errors = []
        for name in order:
            if name is None:
                continue
            try:
                if name == "kokoro":
                    self.backend = _KokoroTTS()
                elif name == "piper":
                    self.backend = _PiperTTS(piper_model)
                elif name == "pyttsx3":
                    self.backend = _Pyttsx3TTS()
                elif name == "elevenlabs":
                    self.backend = _ElevenLabsTTS(elevenlabs_voice_id)
                elif name == "mock":
                    self.backend = _MockTTS()
                else:
                    continue
                self.backend_name = self.backend.name
                break
            except Exception as e:
                errors.append(f"{name}: {e}")
                continue
        if self.backend is None:
            raise RuntimeError(f"No TTS backend available. Tried: {errors}")

    def speak(self, text: str) -> TTSResult:
        # Ensure text ends with punctuation so TTS renders the final word/sentence.
        # Applied here once, universally, regardless of backend.
        text = text.rstrip()
        if text and text[-1] not in ".!?;:—":
            text += "."
        return self.backend.speak(text)
