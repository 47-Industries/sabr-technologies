"""
Text-to-Speech.

Backends (preference order):
  1. Piper         — local, fast, open-source, decent quality
  2. pyttsx3       — system TTS (SAPI on Windows, NSSpeech on macOS, espeak on Linux)
  3. ElevenLabs    — highest quality, cloud, requires key
  4. Mock          — silent WAV for testing

Every backend exposes .speak(text) → bytes of WAV audio plus an optional
streaming generator synthesize_stream(text) for barge-in support.
"""

from __future__ import annotations

import io
import os
import struct
import wave
from dataclasses import dataclass
from typing import Any, Generator, Optional


@dataclass
class TTSResult:
    wav_bytes: bytes
    sample_rate: int
    backend: str
    duration_sec: float


class _MockTTS:
    name = "mock"

    def speak(self, text: str) -> TTSResult:
        # Generate 0.5s of silence per 20 characters as a stand-in
        sr = 16000
        seconds = max(0.3, len(text) / 40.0)
        n_samples = int(sr * seconds)
        pcm = b"\x00\x00" * n_samples
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(pcm)
        return TTSResult(
            wav_bytes=buf.getvalue(),
            sample_rate=sr,
            backend=self.name,
            duration_sec=seconds,
        )


class _Pyttsx3TTS:
    name = "pyttsx3"

    def __init__(self):
        try:
            import pyttsx3  # type: ignore
        except ImportError as e:
            raise RuntimeError("pyttsx3 not installed") from e
        self._engine = pyttsx3.init()

    def speak(self, text: str) -> TTSResult:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            path = tmp.name
        try:
            self._engine.save_to_file(text, path)
            self._engine.runAndWait()
            with open(path, "rb") as f:
                wav = f.read()
            with wave.open(io.BytesIO(wav), "rb") as w:
                sr = w.getframerate()
                duration = w.getnframes() / sr
            return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)
        finally:
            try:
                os.remove(path)
            except Exception:
                pass


def speakable(text: str) -> str:
    """Turn written text into text meant to be HEARD.

    Piper's phonemizer reads punctuation literally, which is why periods kept
    coming out as the word "dot" — an ellipsis becomes "dot dot dot", a domain
    like sabr.co becomes "sabr dot co", and a bullet or asterisk gets spoken
    outright. None of that is Piper being broken; nothing was ever cleaning
    the string. This does.

    Applied to every backend, not just Piper, so the fix can't drift again
    the way the Kokoro wiring did.
    """
    import re

    t = text

    # Markdown scaffolding — asterisks and backticks get read aloud.
    t = re.sub(r"[*_`#>]+", " ", t)
    # Bullets and list glyphs.
    t = re.sub(r"^[\s\-•·–]+", "", t, flags=re.MULTILINE)
    # Ellipsis -> a real pause, not three spoken dots.
    t = re.sub(r"\.{2,}", ",", t)
    # Dashes used as pauses -> comma. Keeps the rhythm, loses the word.
    t = re.sub(r"\s*[—–]\s*", ", ", t)
    # Bare URLs read as an unbroken stream of symbols. This MUST run before
    # the domain rule below — otherwise the domain rule splits the host, the
    # URL pattern then only matches the front half, and you get the literal
    # nonsense "a link com/dashboard". Caught by the test, not by reading it.
    t = re.sub(r"https?://\S+", "a link", t)
    # Domains and file extensions: say the name, not the punctuation.
    t = re.sub(r"\b([A-Za-z0-9-]+)\.(com|org|net|io|co|ai|dev|py|js|sh|md|json)\b",
               r"\1 \2", t)
    # Stray symbols with no spoken form.
    t = re.sub(r"[\[\]{}|\\<>~^]+", " ", t)
    t = t.replace("&", " and ").replace("%", " percent").replace("+", " plus ")
    # Collapse the whitespace all that substitution just created.
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s*\n\s*", ". ", t.strip())
    # Substitution can leave doubled punctuation, which reads as a stumble.
    t = re.sub(r"([,.])\s*[,.]+", r"\1", t)
    return t.strip()


# ── Piper voice model auto-download ──────────────────────────────────
#
# The ears already solve this: brain/voice/wake_word_vosk.py fetches its
# own Vosk model on first use. The mouth did not, so every fresh install
# fell through Piper to the OS narrator and nobody noticed, because the
# fallback was silent. Same pattern, same honesty about what it's doing.
#
# URLs verified against huggingface.co/rhasspy/piper-voices (HEAD → 200).
# BOTH files are mandatory: PiperVoice.load() reads <model>.onnx.json for
# the phoneme map and sample rate and will not start without it.

_PIPER_DIR_REL = "brain_state/voice/piper"
_PIPER_BASE_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main"

# voice name → (relative path within the piper-voices repo)
_PIPER_VOICES = {
    # Default: this is the voice the product already ships and logs as
    # "voice=en_GB-alan-medium", so a fresh install now sounds like the
    # demo box instead of like a different product.
    "en_GB-alan-medium": "en/en_GB/alan/medium/en_GB-alan-medium.onnx",
    "en_US-lessac-medium": "en/en_US/lessac/medium/en_US-lessac-medium.onnx",
}
_DEFAULT_PIPER_VOICE = "en_GB-alan-medium"
# Real size of a medium model, measured via Content-Length: 63,201,294 B.
_PIPER_MODEL_MB = 60


def default_piper_voice() -> str:
    v = (os.environ.get("LEON_PIPER_VOICE") or "").strip()
    return v if v in _PIPER_VOICES else _DEFAULT_PIPER_VOICE


def default_piper_model_path(voice: Optional[str] = None) -> str:
    """Absolute path where the default Piper model lives (may not exist)."""
    voice = voice or default_piper_voice()
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    return os.path.join(root, _PIPER_DIR_REL, f"{voice}.onnx")


def _download_to(url: str, dest_tmp: str, deadline: float) -> None:
    """Stream `url` into `dest_tmp`, aborting if we blow past `deadline`.

    urlopen(timeout=...) only bounds a single socket operation, so a slow
    trickle can hang a constructor effectively forever. The wall-clock
    check in the read loop is what actually bounds this.
    """
    import time
    import urllib.request

    req = urllib.request.Request(url, headers={"User-Agent": "leon-brain/1.0"})
    remaining = max(1.0, deadline - time.time())
    with urllib.request.urlopen(req, timeout=min(60.0, remaining)) as r, \
            open(dest_tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            if time.time() > deadline:
                raise TimeoutError(
                    f"download exceeded {_piper_timeout():.0f}s budget")


def _piper_timeout() -> float:
    try:
        return max(10.0, float(os.environ.get("LEON_TTS_DOWNLOAD_TIMEOUT", "300")))
    except ValueError:
        return 300.0


def _ensure_piper_model(model_path: str, voice: Optional[str] = None) -> bool:
    """Fetch the Piper .onnx + .onnx.json to `model_path` if missing.

    Returns True if both files are present afterward. Never raises — the
    caller decides what a False means (here: raise so the TTS ladder keeps
    falling through to pyttsx3, exactly as it does today).
    """
    import time

    cfg_path = model_path + ".json"
    if os.path.exists(model_path) and os.path.exists(cfg_path):
        return True

    # Derive the voice from the filename so a custom --piper-model path
    # pointing at a known voice still self-heals.
    base = os.path.basename(model_path)
    voice = voice or (base[: -len(".onnx")] if base.endswith(".onnx") else base)
    rel = _PIPER_VOICES.get(voice)
    if rel is None:
        print(f"[TTS] Piper voice {voice!r} unknown — no download URL", flush=True)
        return False

    if os.environ.get("LEON_TTS_NO_DOWNLOAD", "").strip() not in ("", "0", "false", "False"):
        print(f"[TTS] Piper voice missing and LEON_TTS_NO_DOWNLOAD is set — "
              f"skipping download, falling back to the system voice", flush=True)
        return False

    parent = os.path.dirname(os.path.abspath(model_path))
    try:
        os.makedirs(parent, exist_ok=True)
    except OSError as e:
        print(f"[TTS] cannot create Piper model dir {parent}: {e}", flush=True)
        return False

    onnx_url = f"{_PIPER_BASE_URL}/{rel}"
    json_url = onnx_url + ".json"
    print(f"[TTS] Piper voice missing — downloading {voice} "
          f"(~{_PIPER_MODEL_MB}MB) from {onnx_url}", flush=True)

    import tempfile
    deadline = time.time() + _piper_timeout()
    tmps = []
    try:
        wanted = [(json_url, cfg_path), (onnx_url, model_path)]
        for url, dest in [(u, d) for u, d in wanted if not os.path.exists(d)]:
            fd, tmp = tempfile.mkstemp(suffix=".part", dir=parent)
            os.close(fd)
            tmps.append((tmp, dest))
            _download_to(url, tmp, deadline)
        # Sanity-check before publishing: a captive-portal HTML page or a
        # truncated body would otherwise be renamed into place and then
        # fail forever, since the "does it exist" check would pass.
        for tmp, dest in tmps:
            if dest.endswith(".json"):
                import json as _json
                with open(tmp, "r", encoding="utf-8") as f:
                    _json.load(f)
            elif os.path.getsize(tmp) < 1_000_000:
                raise RuntimeError(
                    f"downloaded model is only {os.path.getsize(tmp)} bytes")
        for tmp, dest in tmps:
            os.replace(tmp, dest)
        tmps = []
        if not (os.path.exists(model_path) and os.path.exists(cfg_path)):
            print(f"[TTS] Piper download finished but {model_path} is still "
                  f"incomplete", flush=True)
            return False
        print(f"[TTS] Piper voice ready — {model_path}", flush=True)
        return True
    except Exception as e:
        print(f"[TTS] Piper voice download failed: {type(e).__name__}: {e} — "
              f"falling back to the system voice", flush=True)
        return False
    finally:
        for tmp, _dest in tmps:
            try:
                os.remove(tmp)
            except OSError:
                pass


class _PiperTTS:
    name = "piper"

    def __init__(self, model_path: Optional[str] = None):
        try:
            from piper import PiperVoice  # type: ignore
        except ImportError as e:
            raise RuntimeError("piper-tts not installed") from e
        if model_path is None:
            # No path configured → use the standard location under
            # brain_state/voice/piper/ and fetch the model if it isn't
            # there. Nobody was ever going to drop an .onnx in by hand.
            model_path = default_piper_model_path()
        if not os.path.exists(model_path) or not os.path.exists(model_path + ".json"):
            if not _ensure_piper_model(model_path):
                raise RuntimeError(f"Piper model not available: {model_path}")
        self._voice = PiperVoice.load(model_path)

    def speak(self, text: str) -> TTSResult:
        # Piper also clips last word without trailing punctuation
        tts_text = speakable(text).rstrip()
        if tts_text and tts_text[-1] not in ".!?;:—":
            tts_text += "."
        # piper-tts >=1.4 split the API: `synthesize` returns audio chunks,
        # `synthesize_wav` writes a fully-formed WAV (header + frames) to
        # the given wave.Wave_write. Let it set its own WAV format so we
        # don't double-write the header.
        # length_scale < 1.0 = faster speech. Env-tunable.
        from piper.config import SynthesisConfig
        _speed = float(os.environ.get("PIPER_LENGTH_SCALE", "0.75"))
        _syn = SynthesisConfig(length_scale=_speed)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            self._voice.synthesize_wav(tts_text, w, syn_config=_syn,
                                       set_wav_format=True)
        wav = buf.getvalue()
        with wave.open(io.BytesIO(wav), "rb") as w:
            sr = w.getframerate()
            duration = w.getnframes() / sr if sr > 0 else 0.0
        return TTSResult(wav_bytes=wav, sample_rate=sr, backend=self.name, duration_sec=duration)


class _ElevenLabsTTS:
    name = "elevenlabs"

    def __init__(self, voice_id: Optional[str] = None):
        self.api_key = os.environ.get("ELEVENLABS_API_KEY")
        if not self.api_key:
            raise RuntimeError("ELEVENLABS_API_KEY not set")
        self.voice_id = voice_id or os.environ.get("ELEVENLABS_VOICE_ID") or "21m00Tcm4TlvDq8ikWAM"
        self.model_id = os.environ.get("ELEVENLABS_MODEL", "eleven_turbo_v2_5")
        # Free-tier accounts can't request raw PCM (402 Payment Required) —
        # only mp3. Discovered live 2026-06-11 with Dean's new key. We try
        # PCM first (best path, no transcode) and remember the downgrade.
        self._use_mp3 = False

    def _request(self, tts_text: str, fmt: str) -> bytes:
        import urllib.request
        import json
        url = (f"https://api.elevenlabs.io/v1/text-to-speech/"
               f"{self.voice_id}/stream?output_format={fmt}")
        settings = {
            # Higher stability = flatter, more controlled delivery — pairs
            # with the LEON_VOICE_FX robot treatment. Env-tunable.
            "stability": float(os.environ.get("ELEVENLABS_STABILITY", "0.5")),
            "similarity_boost": float(os.environ.get("ELEVENLABS_SIMILARITY", "0.75")),
        }
        _style = os.environ.get("ELEVENLABS_STYLE", "").strip()
        if _style:
            settings["style"] = float(_style)
        body = json.dumps({
            "text": tts_text,
            "model_id": self.model_id,
            "voice_settings": settings,
        }).encode("utf-8")
        req = urllib.request.Request(
            url, data=body,
            headers={
                "xi-api-key": self.api_key,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.read()

    def speak(self, text: str) -> TTSResult:
        import urllib.error
        # ElevenLabs clips the last word if text doesn't end with punctuation.
        tts_text = text.rstrip()
        if tts_text and tts_text[-1] not in ".!?;:—":
            tts_text += "."

        raw = None
        if not self._use_mp3:
            try:
                raw = self._request(tts_text, "pcm_16000")
            except urllib.error.HTTPError as e:
                if e.code != 402:
                    raise
                # PCM is paid-tier only — drop to mp3 for this process's life.
                self._use_mp3 = True
        if self._use_mp3:
            mp3 = self._request(tts_text, "mp3_44100_128")
            # Transcode mp3 → 16k mono WAV via ffmpeg (present on the VPS).
            import subprocess
            proc = subprocess.run(
                ["ffmpeg", "-hide_banner", "-loglevel", "error",
                 "-i", "pipe:0", "-f", "wav", "-acodec", "pcm_s16le",
                 "-ar", "16000", "-ac", "1", "pipe:1"],
                input=mp3, capture_output=True, timeout=30,
            )
            if proc.returncode != 0 or not proc.stdout:
                raise RuntimeError(
                    f"ffmpeg transcode failed: {proc.stderr[:200]!r}")
            wav_bytes = proc.stdout
            duration = max(0.0, (len(wav_bytes) - 44) / 2 / 16000)
            return TTSResult(wav_bytes=wav_bytes, sample_rate=16000,
                             backend=self.name, duration_sec=duration)

        # PCM path — wrap raw PCM in a WAV header
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16000)
            w.writeframes(raw)
        duration = len(raw) / 2 / 16000
        return TTSResult(wav_bytes=buf.getvalue(), sample_rate=16000,
                         backend=self.name, duration_sec=duration)


class _KokoroTTS:
    """Kokoro-82M via isolated venv. Local, free, no API key, no quota."""
    name = "kokoro"
    VENV = "/opt/kokoro-venv/bin/python"
    DIR = "/opt/leon-brain/brain_state/voice/kokoro"

    def __init__(self, voice: Optional[str] = None):
        import os as _os
        if not _os.path.exists(self.VENV):
            raise RuntimeError("kokoro venv missing")
        if not _os.path.exists(_os.path.join(self.DIR, "kokoro-v1.0.onnx")):
            raise RuntimeError("kokoro model missing")
        self.voice = voice or _os.environ.get("LEON_KOKORO_VOICE", "am_michael")
        self.speed = float(_os.environ.get("LEON_KOKORO_SPEED", "1.05"))

    def speak(self, text: str) -> TTSResult:
        import subprocess, tempfile, json, os as _os
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            out = f.name
        script = (
            "import sys,soundfile as sf\n"
            "from kokoro_onnx import Kokoro\n"
            "txt=sys.stdin.read()\n"
            "k=Kokoro(r'%s/kokoro-v1.0.onnx',r'%s/voices-v1.0.bin')\n"
            "s,sr=k.create(txt,voice=%r,speed=%r,lang=%r)\n"
            "sf.write(r'%s',s,sr)\n"
            "print(sr)\n" % (self.DIR, self.DIR, self.voice, self.speed,
               'en-gb' if self.voice.startswith(('bm_', 'bf_')) else 'en-us', out)
        )
        pr = subprocess.run([self.VENV, "-c", script], input=text.encode(),
                            capture_output=True, timeout=120)
        if pr.returncode != 0 or not _os.path.exists(out):
            raise RuntimeError("kokoro synth failed: %s" % pr.stderr.decode()[-300:])
        wav_bytes = open(out, "rb").read()
        _os.unlink(out)
        with wave.open(io.BytesIO(wav_bytes)) as w:
            sr = w.getframerate()
            dur = w.getnframes() / float(sr)
        return TTSResult(wav_bytes=wav_bytes, sample_rate=sr,
                         backend=self.name, duration_sec=dur)


class TTS:
    def __init__(
        self,
        prefer: Optional[str] = None,
        piper_model: Optional[str] = None,
        elevenlabs_voice_id: Optional[str] = None,
    ):
        self.backend: Any = None
        self.backend_name: str = ""
        order = [prefer] if prefer else []
        order += ["kokoro", "piper", "pyttsx3", "elevenlabs", "mock"]
        errors = []
        for name in order:
            if name is None:
                continue
            try:
                if name == "kokoro":
                    self.backend = _KokoroTTS()
                elif name == "piper":
                    self.backend = _PiperTTS(piper_model)
                elif name == "pyttsx3":
                    self.backend = _Pyttsx3TTS()
                elif name == "elevenlabs":
                    self.backend = _ElevenLabsTTS(elevenlabs_voice_id)
                elif name == "mock":
                    self.backend = _MockTTS()
                else:
                    continue
                self.backend_name = self.backend.name
                break
            except Exception as e:
                errors.append(f"{name}: {e}")
                continue
        if self.backend is None:
            raise RuntimeError(f"No TTS backend available. Tried: {errors}")

    def speak(self, text: str) -> TTSResult:
        # Ensure text ends with punctuation so TTS renders the final word/sentence.
        # Applied here once, universally, regardless of backend.
        text = text.rstrip()
        if text and text[-1] not in ".!?;:—":
            text += "."
        return self.backend.speak(text)
