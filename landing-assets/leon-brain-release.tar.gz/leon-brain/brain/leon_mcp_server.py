"""
Leon MCP server — stdio JSON-RPC bridge that exposes the brain's tool surface
to `claude -p`. This is what makes the Max-plan CLI path tool-capable.

Architecture:
    `claude -p --mcp-config '{...stdio→this script...}' "user msg"`
        ↓ spawns this as a subprocess
    This server fetches /api/leon/tools from the running brain server,
    declares each tool to Claude Code, and proxies invocations to
    /api/leon/tool. No duplicate dispatch logic.

Run standalone for testing:
    python3 -m brain.leon_mcp_server

Brain server must be running on http://localhost:8000.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import urllib.error
import urllib.request

# Make brain.* imports work no matter the spawn cwd — `claude` launches this
# script with cwd=/tmp, so package-relative imports (brain.tool_classification)
# failed and the classifier silently fell back to detect-only. The repo root
# is one level up from this file.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent, ImageContent
except ImportError:
    print("ERROR: mcp package not installed. Run: pip install --user --break-system-packages mcp",
          file=sys.stderr)
    sys.exit(1)

# Quiet down: stdout is the JSON-RPC channel — logs MUST go to stderr.
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stderr,
    format="[leon-mcp] %(message)s",
)
log = logging.getLogger("leon-mcp")

BRAIN_URL = os.environ.get("LEON_BRAIN_URL", "http://127.0.0.1:8000")

# Direct actuator socket access — bypasses the HTTP round-trip for tools
# that live on the actuator (screen/mouse/keyboard/shell/file/browser).
# Saves ~1-2s per tool call.
ACTUATOR_SOCK = "/tmp/leon-actuator.sock"


def _actuator_call(tool: str, args: dict, timeout: float = 15.0) -> dict:
    """Call the actuator directly via TCP (socat bridge to Dean's PC).
    Inlined to avoid import issues."""
    import socket as _socket, time as _time
    payload = (json.dumps({"tool": tool, "args": args}) + "\n").encode("utf-8")
    try:
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((os.environ.get("LEON_BRAIN_HOST", "127.0.0.1"), 9999))
        s.sendall(payload)
        buf = b""
        deadline = _time.time() + timeout
        while not buf.endswith(b"\n"):
            if _time.time() > deadline:
                return {"ok": False, "error": "actuator timeout"}
            chunk = s.recv(65536)
            if not chunk:
                break
            buf += chunk
        s.close()
        if not buf:
            return {"ok": False, "error": "empty actuator response"}
        return json.loads(buf.decode("utf-8"))
    except Exception as e:
        return {"ok": False, "error": f"actuator: {e}"}


def _auth_headers() -> dict:
    """Bearer header for LEON_API_KEY, empty if unset."""
    tok = os.environ.get("LEON_API_KEY", "")
    return {"Authorization": f"Bearer {tok}"} if tok else {}


def _http_get(path: str, timeout: float = 8.0) -> dict:
    req = urllib.request.Request(BRAIN_URL + path, headers=_auth_headers())
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _http_post(path: str, body: dict, timeout: float = 60.0) -> dict:
    data = json.dumps(body).encode("utf-8")
    headers = {"Content-Type": "application/json", **_auth_headers()}
    req = urllib.request.Request(
        BRAIN_URL + path,
        data=data,
        headers=headers,
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


# Essential tools Leon actually needs. 1,600 tools drowns Claude's context.
# Only expose the tools that matter for a being with agency.
_ESSENTIAL_TOOLS = {
    # See the world
    "screen_capture", "webcam_capture", "vision_describe",
    # Act on the computer
    "shell_exec", "keyboard_type", "mouse_click", "click_text",
    "click_element",  # visual clicking (Moondream-based, works on any app)
    "app_launch", "app_close", "browser_open", "web_search",
    # Browser DOM (interact with web pages directly)
    "browser_dom_click", "browser_dom_state", "browser_dom_extract",
    "browser_dom_get_text", "browser_dom_fill", "browser_dom_scroll_to",
    "browser_solve_captcha", "browser_close_tab", "browser_cleanup",
    # Browser navigation (without these, Claude hallucinates names like
    # `browser.evaluate_js` for `browser.execute_js` and `browser.navigate`
    # for `browser.new_tab` — observed 2026-06-09 mid-task).
    "browser_new_tab", "browser_switch_tab", "browser_list_tabs",
    "browser_execute_js", "browser_screenshot_full",
    # Files
    "file_read", "file_write", "file_list", "code_edit", "code_restore",
    # Memory
    "knowledge_search",
    # Communication
    "notify",
    # Email (send via SMTP)
    "email.send", "email.draft",
    # Email (read via Gmail API / IMAP)
    "email_gmail_inbox", "email_gmail_search", "email_gmail_read",
    "email_gmail_unread_count", "email_gmail_reply",
    # Reddit (lead hunting — public API, no auth for reading)
    "research_reddit_search", "research_reddit_top", "research_reddit_hot",
    "research_reddit_comments",
    # Task management (local, no API key needed)
    "task_add", "task_list", "task_complete", "task_search", "task_today",
    # Notes (local)
    "notes_quick_add", "notes_quick_list", "notes_quick_search",
    "notes_capture_thought",
    # Clipboard
    "clipboard_copy", "clipboard_paste",
    # System
    "window_list", "window_focus",
    # Reminders
    "reminder_set", "reminder_list", "reminder_cancel",
    # Network
    "http_request",
    # Self
    "restart_self",
    # Business platform (CRM, outreach, demos) — Leon's sales surface.
    # These were MISSING from the essential set while the persona told
    # Leon to use them (9da316a) — he could never actually see them as
    # tools and resorted to Bash-curling the brain API (found 2026-06-11).
    "business_find_leads", "business_list_leads", "business_lead_detail",
    "business_send_outreach", "business_send_sms", "business_generate_demo",
    "business_add_lead", "business_pipeline_report", "business_pipeline_tick",
}


def _fetch_catalog() -> list[dict]:
    try:
        cat = _http_get("/api/leon/tools")
        all_tools = cat.get("tools", [])
        # Filter to essential tools only — Leon needs 25, not 1,600
        essential = [t for t in all_tools if t.get("name") in _ESSENTIAL_TOOLS]
        log.info("Tool catalog: %d total, %d essential loaded",
                 len(all_tools), len(essential))
        return essential
    except Exception as e:
        log.error("fetch /api/leon/tools failed: %s", e)
        return []


def _shape_for_mcp(t: dict) -> Tool:
    """Convert our catalog entry into an mcp.types.Tool."""
    schema = t.get("input_schema") or {"type": "object", "properties": {}, "additionalProperties": False}
    # MCP requires type==object at the top.
    if schema.get("type") != "object":
        schema = {"type": "object", "properties": {}, "additionalProperties": False}
    desc = t.get("description", "")
    risk = t.get("risk", "low")
    if risk == "high":
        desc = f"[HIGH-RISK — Dean's confirmation may be required] {desc}"
    elif risk == "medium":
        desc = f"[medium-risk] {desc}"
    return Tool(name=t["name"], description=desc, inputSchema=schema)


def _result_to_mcp_content(name: str, result: dict) -> list:
    """Turn an /api/leon/tool result into MCP content blocks.

    Special-case: screen_capture / webcam_capture return base64 images —
    surface those as ImageContent so Claude actually sees the pixels.
    """
    blocks: list = []
    value = result.get("value")

    # Image-returning tools — try multiple shapes for the base64.
    if name in ("screen_capture", "webcam_capture"):
        img_b64 = None
        mime = "image/png"
        if isinstance(value, dict):
            img_b64 = (
                value.get("image_b64")
                or value.get("base64")
                or value.get("data")
                or ((value.get("result") or {}).get("image_b64")
                    if isinstance(value.get("result"), dict) else None)
            )
            mime = value.get("mime") or value.get("content_type") or "image/png"
        if img_b64:
            blocks.append(ImageContent(type="image", data=img_b64, mimeType=mime))

    # Always append a JSON text block so Claude sees structured fields too.
    text = json.dumps(
        {
            "ok": result.get("ok", False),
            "tool": result.get("tool", name),
            "error": result.get("error"),
            # Trim binary payloads from the text echo — already in ImageContent.
            "value": _slim_for_text(name, value),
            "source": result.get("source"),
        },
        ensure_ascii=False,
        indent=2,
    )
    blocks.append(TextContent(type="text", text=text))
    return blocks


def _slim_for_text(name: str, value):
    """Strip large base64 payloads from the text echo to keep tokens low."""
    if not isinstance(value, dict):
        return value
    redacted = dict(value)
    for k in ("image_b64", "base64", "data"):
        if k in redacted and isinstance(redacted[k], str) and len(redacted[k]) > 200:
            redacted[k] = f"<{len(redacted[k])} base64 chars>"
    return redacted


# --- MCP server -------------------------------------------------------------

server = Server("leon")

# Cache the catalog on startup — the brain server is the source of truth, but
# refetching on every list_tools call is wasteful.
_catalog: list[dict] = []
_by_name: dict[str, dict] = {}


def _refresh_catalog():
    global _catalog, _by_name
    _catalog = _fetch_catalog()
    _by_name = {t["name"]: t for t in _catalog}
    log.info("catalog: %d tools", len(_catalog))


@server.list_tools()
async def list_tools() -> list[Tool]:
    if not _catalog:
        _refresh_catalog()
    return [_shape_for_mcp(t) for t in _catalog]


def _load_actuator_map() -> dict:
    """Load the tool→actuator name map so we know which tools can go direct."""
    try:
        import importlib.util, types
        spec = importlib.util.spec_from_file_location(
            "actuator_client",
            os.path.join(os.path.dirname(__file__), "actuator_client.py"),
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return getattr(mod, "_TOOL_NAME_MAP", {})
    except Exception as e:
        log.warning("couldn't load actuator map: %s", e)
        return {}


_actuator_map: dict = {}  # populated on first call
_BRAIN_LOCAL_TOOLS: set[str] = set()  # tools the actuator returned "unknown tool" for — never retry the fast path

# Shared brain-local classifier (auto-scanned at import time)
try:
    from brain.tool_classification import is_brain_local as _is_brain_local
except Exception as _e:
    log.warning("tool_classification import failed (%s); falling back to lazy detect-only", _e)
    def _is_brain_local(_n: str) -> bool:  # type: ignore[misc]
        return False


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list:
    global _actuator_map
    if not _actuator_map:
        _actuator_map = _load_actuator_map()

    log.info("call %s args=%s", name, json.dumps(arguments)[:200])

    # FAST PATH: tools that live on the actuator socket — skip HTTP entirely.
    # This saves ~1-2s per call by going Unix socket → actuator directly.
    #
    # Caveat: actuator_client.py _TOOL_NAME_MAP contains BOTH actuator-backed
    # tools AND brain-local tools (memory_*, audit_*, prompt_*, undo_*,
    # tentacle_*, presence_*, reports_*, plus all lazy-loaded integration
    # tools — cal_*, email_*, finance_*, smart_home_*, etc.). For the latter,
    # the actuator will return "unknown tool: <name>" because it never had
    # those bound.
    #
    # First defence: brain.tool_classification.is_brain_local() — auto-scanned
    # at import time from every brain module that registers an EXTRA_TOOLS
    # dict. This skips the actuator round-trip preemptively for known
    # brain-local tools, keeping the audit log clean.
    #
    # Second defence: cache + fall-through. If the prefix scan missed a tool
    # (false negative) AND the actuator returns "unknown tool", we cache the
    # determination per process and fall through to the brain server below.
    actuator_name = _actuator_map.get(name)
    # The Unix-socket fast path only exists where an actuator runs LOCALLY
    # (PC deployments). On the VPS there is no /tmp/leon-actuator.sock —
    # the brain HTTP path below routes through the PC relay instead. The
    # old code attempted the socket anyway and returned "actuator: [Errno
    # 2] ..." as the tool RESULT instead of falling through (would have
    # broken every desktop tool the moment MCP came alive on the VPS).
    if (actuator_name and name not in _BRAIN_LOCAL_TOOLS
            and os.path.exists(ACTUATOR_SOCK)):
        if _is_brain_local(name) or _is_brain_local(actuator_name):
            # Skip the round-trip entirely; brain server handles via local_tools.
            _BRAIN_LOCAL_TOOLS.add(name)
        else:
            result = _actuator_call(actuator_name, arguments or {})
            err = (result or {}).get("error", "") or ""
            if "unknown tool" in err.lower():
                _BRAIN_LOCAL_TOOLS.add(name)
                log.info("tool %s is brain-local (actuator unknown), caching", name)
                # Fall through to brain server path below.
            elif err.startswith("actuator:"):
                # Socket-level failure (dead/refused/mid-restart) — fall
                # through to the brain HTTP path rather than failing the
                # tool call outright.
                log.info("actuator socket failed for %s (%s) — using brain HTTP",
                         name, err[:80])
            else:
                wrapped = {
                    "ok": bool(result.get("ok", False)),
                    "tool": name,
                    "value": result,
                    "source": "actuator-direct",
                }
                return _result_to_mcp_content(name, wrapped)

    # NORMAL PATH: tools that need brain server (local_tools like
    # click_element, vision_describe, knowledge_search, webcam_capture,
    # or registry tools like gmail, sheets, etc.)
    try:
        result = _http_post("/api/leon/tool", {"tool": name, "args": arguments or {}})
    except urllib.error.URLError as e:
        return [TextContent(type="text", text=json.dumps({
            "ok": False, "tool": name,
            "error": f"brain server unreachable at {BRAIN_URL}: {e}",
        }))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "ok": False, "tool": name,
            "error": f"{type(e).__name__}: {e}",
        }))]
    return _result_to_mcp_content(name, result)


async def _main():
    _refresh_catalog()
    if not _catalog:
        log.warning("started with empty catalog (brain server not responding?). Will retry on first call.")
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
