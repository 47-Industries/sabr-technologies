"""
self_improve.py — Leon's Phase 4/8 self-test, codebase-health, and
meta-improvement tool surface.

This module gives Leon the ability to:
  1. Run regression batteries against his own tool surface (selftest.*)
  2. Inspect his own source code for size, dead imports, TODOs,
     long functions, missing docstrings, and dependency edges (code.*)
  3. Snapshot / restore brain state, A/B test prompts, store config,
     and surface failure clusters from the audit log (meta.*)
  4. Replay last failed calls + comprehensive health-checks (reliability.*)

All tools share the same {ok, result|error} contract used by
`memory_extras.py`. The EXTRA_TOOLS dict at the bottom maps dotted
tool names to their implementations.

These tools are BRAIN-LOCAL — they are called via the brain's
`local_tools` path, not through the actuator socket. They operate
ONLY on paths under the project root
(the install root); calls that would
escape that root return ok=False rather than touching system dirs.
"""

from __future__ import annotations

import ast
import importlib
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import time
from collections import Counter, defaultdict
from typing import Any, Callable, Dict, List, Optional, Tuple


# ──────────────────────────────────────────────────────────────────────────
# PATHS & GUARDS
# ──────────────────────────────────────────────────────────────────────────


def _project_root() -> str:
    """Project directory (parent of brain/). All file ops must stay
    under this root — see `_safe_under_root`."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _brain_state_dir() -> str:
    p = os.path.join(_project_root(), "brain_state")
    os.makedirs(p, exist_ok=True)
    return p


def _selftest_suites_dir() -> str:
    p = os.path.join(_brain_state_dir(), "selftest-suites")
    os.makedirs(p, exist_ok=True)
    return p


def _snapshots_dir() -> str:
    p = os.path.join(_project_root(), "brain_state-snapshots")
    os.makedirs(p, exist_ok=True)
    return p


def _config_path() -> str:
    return os.path.join(_brain_state_dir(), "config.json")


def _audit_log_candidates() -> List[str]:
    """Possible locations of the actuator audit log — checked in order."""
    root = _project_root()
    return [
        os.path.join(root, "brain_state", "actuator-audit.jsonl"),
        os.path.join(root, "leon-actuator", "actuator-audit.jsonl"),
        os.path.join(root, "actuator-audit.jsonl"),
        os.path.expanduser("~/.openclaw/leon/actuator-audit.jsonl"),
    ]


def _audit_log_path() -> Optional[str]:
    """Return the first audit log path that exists, or None."""
    for p in _audit_log_candidates():
        if os.path.exists(p):
            return p
    return None


def _safe_under_root(path: str) -> bool:
    """True iff `path` resolves inside the project root. Prevents
    escapes via `..` or absolute paths outside the project."""
    root = os.path.realpath(_project_root())
    try:
        target = os.path.realpath(path)
    except Exception:
        return False
    return target == root or target.startswith(root + os.sep)


def _resolve_root_relative(root: Optional[str]) -> Optional[str]:
    """Resolve a user-supplied `root` argument to an absolute path
    under the project. None → project root. Returns None if the
    resolved path escapes the project."""
    project = _project_root()
    if root is None or root == "":
        target = project
    elif os.path.isabs(root):
        target = root
    else:
        target = os.path.join(project, root)
    if not _safe_under_root(target):
        return None
    return target


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _iter_py_files(root_dir: str) -> List[str]:
    """Walk `root_dir` and return all .py files. Skips __pycache__,
    .git, node_modules, and any 'vendor' directory."""
    skip_dirs = {"__pycache__", ".git", "node_modules", "vendor",
                 ".venv", "venv", "env", ".mypy_cache", ".pytest_cache"}
    out: List[str] = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for fn in filenames:
            if fn.endswith(".py"):
                out.append(os.path.join(dirpath, fn))
    return out


def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _rel(path: str) -> str:
    """Return path relative to the project root for compact reporting."""
    try:
        return os.path.relpath(path, _project_root())
    except Exception:
        return path


# ──────────────────────────────────────────────────────────────────────────
# LAZY ACCESS TO BRAIN INTERNALS  (avoid heavy imports at module load)
# ──────────────────────────────────────────────────────────────────────────


def _try_import(modname: str):
    """Import a module by dotted name, returning None on failure."""
    try:
        return importlib.import_module(modname)
    except Exception:
        return None


def _knowledge_store():
    mod = _try_import("brain.knowledge_store")
    if mod is None or not hasattr(mod, "KnowledgeStore"):
        return None
    try:
        return mod.KnowledgeStore()
    except Exception:
        return None


def _local_tools_registry() -> Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]]:
    """Best-effort: gather every EXTRA_TOOLS dict exposed by brain
    sub-modules. Used by selftest.run_battery so it can dispatch
    arbitrary `tool` names against the local surface without needing
    a reference to the responder."""
    registry: Dict[str, Callable] = {}
    # Always include our own tools
    registry.update(EXTRA_TOOLS)
    for modname in (
        "brain.memory_extras",
        "brain.introspection",
        "brain.info_tools",
        "brain.browser_apps",
        "brain.tentacle_orchestration",
        "brain.reports",
        "brain.presence",
        "brain.routines",
    ):
        mod = _try_import(modname)
        if mod is None:
            continue
        extra = getattr(mod, "EXTRA_TOOLS", None)
        if isinstance(extra, dict):
            registry.update(extra)
    return registry


# ──────────────────────────────────────────────────────────────────────────
# SELFTEST
# ──────────────────────────────────────────────────────────────────────────


def _suite_path(suite_name: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", suite_name).strip("_") or "suite"
    return os.path.join(_selftest_suites_dir(), f"{safe}.json")


def _check_expectation(result: Dict[str, Any],
                       expect: Dict[str, Any]) -> Tuple[bool, str]:
    """Return (passed, reason). Supported expectations:
      - {"ok": True/False}                     — exact match on result.ok
      - {"field_contains": {"path.to.field": "needle"}}
        Dotted-path lookup against the result dict; string check uses
        substring (case-insensitive); list check uses membership;
        numeric uses equality.
    Unknown keys in `expect` are ignored (tolerant)."""
    if not isinstance(expect, dict):
        return True, "no expectation"
    if "ok" in expect:
        want_ok = bool(expect["ok"])
        got_ok = bool(result.get("ok"))
        if want_ok != got_ok:
            return False, f"ok mismatch: expected {want_ok}, got {got_ok}"
    field_contains = expect.get("field_contains") or {}
    if not isinstance(field_contains, dict):
        return False, "expect.field_contains must be a dict"
    for dotted, needle in field_contains.items():
        cursor: Any = result
        for part in str(dotted).split("."):
            if isinstance(cursor, dict) and part in cursor:
                cursor = cursor[part]
            else:
                return False, f"field {dotted!r} not found"
        if isinstance(cursor, str):
            if str(needle).lower() not in cursor.lower():
                return False, f"field {dotted!r} missing {needle!r}"
        elif isinstance(cursor, (list, tuple, set)):
            if needle not in cursor:
                return False, f"field {dotted!r} list missing {needle!r}"
        else:
            if cursor != needle:
                return False, f"field {dotted!r} = {cursor!r}, expected {needle!r}"
    return True, "ok"


def run_battery(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a saved test battery. If `suite_name` is None, run every
    suite in brain_state/selftest-suites/. Returns per-test pass/fail
    plus aggregate counts."""
    suite_name = args.get("suite_name")
    suites: List[Tuple[str, str]] = []  # (name, path)
    try:
        if suite_name:
            path = _suite_path(suite_name)
            if not os.path.exists(path):
                return _err(f"suite not found: {suite_name}")
            suites.append((suite_name, path))
        else:
            dirpath = _selftest_suites_dir()
            for fn in sorted(os.listdir(dirpath)):
                if fn.endswith(".json"):
                    suites.append((fn[:-5], os.path.join(dirpath, fn)))
            if not suites:
                return _ok({"suites_run": 0, "results": [],
                            "note": "no suites found"})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")

    registry = _local_tools_registry()
    all_results: List[Dict[str, Any]] = []
    grand_pass = 0
    grand_fail = 0
    grand_total = 0

    for sname, spath in suites:
        try:
            with open(spath, "r", encoding="utf-8") as f:
                tests = json.load(f)
        except Exception as e:
            all_results.append({
                "suite": sname,
                "error": f"failed to load: {type(e).__name__}: {e}",
                "passed": 0, "failed": 0, "total": 0,
            })
            continue
        if not isinstance(tests, list):
            all_results.append({
                "suite": sname,
                "error": "suite file must contain a JSON list of tests",
                "passed": 0, "failed": 0, "total": 0,
            })
            continue

        suite_pass = 0
        suite_fail = 0
        per_test: List[Dict[str, Any]] = []
        for i, test in enumerate(tests):
            if not isinstance(test, dict):
                per_test.append({"index": i, "passed": False,
                                 "reason": "test is not a dict"})
                suite_fail += 1
                continue
            name = test.get("name") or f"test_{i}"
            tool_name = test.get("tool")
            test_args = test.get("args") or {}
            expect = test.get("expect") or {}
            if not tool_name:
                per_test.append({"index": i, "name": name, "passed": False,
                                 "reason": "missing 'tool' field"})
                suite_fail += 1
                continue
            fn = registry.get(tool_name)
            if fn is None:
                per_test.append({"index": i, "name": name, "tool": tool_name,
                                 "passed": False,
                                 "reason": f"tool {tool_name!r} not in local registry"})
                suite_fail += 1
                continue
            t0 = time.time()
            try:
                result = fn(test_args)
                if not isinstance(result, dict):
                    result = {"ok": False, "error": f"tool returned {type(result).__name__}"}
            except Exception as e:
                result = {"ok": False, "error": f"{type(e).__name__}: {e}"}
            elapsed_ms = int((time.time() - t0) * 1000)
            passed, reason = _check_expectation(result, expect)
            per_test.append({
                "index": i,
                "name": name,
                "tool": tool_name,
                "passed": passed,
                "reason": reason,
                "elapsed_ms": elapsed_ms,
                "result_ok": bool(result.get("ok")),
                "result_error": result.get("error") if not passed else None,
            })
            if passed:
                suite_pass += 1
            else:
                suite_fail += 1

        all_results.append({
            "suite": sname,
            "total": len(tests),
            "passed": suite_pass,
            "failed": suite_fail,
            "pass_rate": (suite_pass / len(tests)) if tests else 0.0,
            "tests": per_test,
        })
        grand_pass += suite_pass
        grand_fail += suite_fail
        grand_total += len(tests)

    return _ok({
        "suites_run": len(suites),
        "total_tests": grand_total,
        "total_passed": grand_pass,
        "total_failed": grand_fail,
        "pass_rate": (grand_pass / grand_total) if grand_total else 0.0,
        "results": all_results,
    })


def list_suites(args: Dict[str, Any]) -> Dict[str, Any]:
    """List every suite JSON file under brain_state/selftest-suites/."""
    try:
        dirpath = _selftest_suites_dir()
        suites: List[Dict[str, Any]] = []
        for fn in sorted(os.listdir(dirpath)):
            if not fn.endswith(".json"):
                continue
            path = os.path.join(dirpath, fn)
            try:
                stat = os.stat(path)
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                n_tests = len(data) if isinstance(data, list) else None
            except Exception as e:
                n_tests = None
                stat = None
            suites.append({
                "name": fn[:-5],
                "path": path,
                "tests": n_tests,
                "size_bytes": stat.st_size if stat else None,
                "mtime": stat.st_mtime if stat else None,
            })
        return _ok({"count": len(suites), "suites": suites,
                    "dir": dirpath})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def save_suite(args: Dict[str, Any]) -> Dict[str, Any]:
    """Write a list of tests to brain_state/selftest-suites/{name}.json."""
    name = (args.get("suite_name") or "").strip()
    tests = args.get("tests_list")
    if not name:
        return _err("suite_name is required")
    if not isinstance(tests, list):
        return _err("tests_list must be a list of test dicts")
    # Validate each test minimally
    for i, t in enumerate(tests):
        if not isinstance(t, dict):
            return _err(f"tests_list[{i}] is not a dict")
        if "tool" not in t:
            return _err(f"tests_list[{i}] missing 'tool' field")
    try:
        path = _suite_path(name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tests, f, indent=2)
        return _ok({"path": path, "tests": len(tests), "suite_name": name})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _try_call(tool_name: str, registry: Dict[str, Callable],
              args: Dict[str, Any]) -> Tuple[bool, Dict[str, Any], int]:
    """Call a tool from the registry, returning (ok, result, elapsed_ms)."""
    fn = registry.get(tool_name)
    if fn is None:
        return False, {"ok": False, "error": f"tool {tool_name!r} not registered"}, 0
    t0 = time.time()
    try:
        result = fn(args)
        if not isinstance(result, dict):
            result = {"ok": False, "error": f"tool returned {type(result).__name__}"}
    except Exception as e:
        result = {"ok": False, "error": f"{type(e).__name__}: {e}"}
    elapsed_ms = int((time.time() - t0) * 1000)
    return bool(result.get("ok")), result, elapsed_ms


def _try_actuator_call(tool_name: str, args: Dict[str, Any],
                       timeout: float = 5.0) -> Tuple[bool, Dict[str, Any], int]:
    """Best-effort call into the leon-actuator over its Unix socket.
    Returns (ok, response, elapsed_ms). If the actuator isn't running
    or the protocol doesn't match, returns ok=False with an error."""
    sock_path = os.path.expanduser("~/.openclaw/leon/actuator.sock")
    if not os.path.exists(sock_path):
        # Try alt locations
        for alt in (
            os.path.join(_project_root(), "leon-actuator", "actuator.sock"),
            "/tmp/leon-actuator.sock",
        ):
            if os.path.exists(alt):
                sock_path = alt
                break
        else:
            return False, {"ok": False, "error": "actuator socket not found"}, 0
    t0 = time.time()
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(sock_path)
        payload = json.dumps({"tool": tool_name, "args": args}).encode("utf-8") + b"\n"
        s.sendall(payload)
        chunks: List[bytes] = []
        while True:
            chunk = s.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
            if chunk.endswith(b"\n"):
                break
        s.close()
        raw = b"".join(chunks).decode("utf-8", errors="replace").strip()
        elapsed_ms = int((time.time() - t0) * 1000)
        if not raw:
            return False, {"ok": False, "error": "empty response from actuator"}, elapsed_ms
        try:
            resp = json.loads(raw.splitlines()[-1])
        except Exception as e:
            return False, {"ok": False, "error": f"bad JSON: {e}"}, elapsed_ms
        return bool(resp.get("ok")), resp, elapsed_ms
    except Exception as e:
        elapsed_ms = int((time.time() - t0) * 1000)
        return False, {"ok": False, "error": f"{type(e).__name__}: {e}"}, elapsed_ms


def smoke_actuator(args: Dict[str, Any]) -> Dict[str, Any]:
    """Quick health probe of three core actuator tools. Reports each
    call's ok-status + elapsed_ms and an overall ok-rate."""
    probes = [
        ("screen.capture", {}),
        ("window.list_monitors", {}),
        ("system.resource_summary", {}),
    ]
    rows: List[Dict[str, Any]] = []
    okay = 0
    for tname, targs in probes:
        ok, resp, ms = _try_actuator_call(tname, targs, timeout=5.0)
        if ok:
            okay += 1
        rows.append({
            "tool": tname,
            "ok": ok,
            "elapsed_ms": ms,
            "error": resp.get("error") if not ok else None,
        })
    return _ok({
        "probes": rows,
        "ok_count": okay,
        "total": len(probes),
        "ok_rate": okay / len(probes),
    })


def smoke_memory(args: Dict[str, Any]) -> Dict[str, Any]:
    """Round-trip a glossary entry: add → lookup → delete. Verifies
    brain.memory_extras is wired and SQLite is writable."""
    mem = _try_import("brain.memory_extras")
    if mem is None:
        return _err("brain.memory_extras not importable")
    term = f"__selftest_{int(time.time())}"
    definition = "selftest entry — safe to delete"
    steps: List[Dict[str, Any]] = []
    try:
        # Add
        r1 = mem.glossary_add({"term": term, "definition": definition})
        steps.append({"step": "glossary_add", "ok": bool(r1.get("ok")),
                      "error": r1.get("error")})
        if not r1.get("ok"):
            return _ok({"steps": steps, "passed": False,
                        "reason": "glossary_add failed"})
        # Lookup
        r2 = mem.glossary_lookup({"term": term})
        found = False
        if r2.get("ok"):
            entries = (r2.get("result") or {}).get("entries") or []
            found = any(e.get("term") == term for e in entries)
        steps.append({"step": "glossary_lookup", "ok": bool(r2.get("ok")),
                      "found": found, "error": r2.get("error")})
        # Delete (direct SQL — there's no glossary_delete tool)
        try:
            db_path = os.path.join(_brain_state_dir(), "memory.db")
            conn = sqlite3.connect(db_path, timeout=10)
            conn.execute("DELETE FROM glossary WHERE term = ?", (term,))
            conn.commit()
            conn.close()
            steps.append({"step": "delete", "ok": True})
        except Exception as e:
            steps.append({"step": "delete", "ok": False,
                          "error": f"{type(e).__name__}: {e}"})
        passed = all(s.get("ok") for s in steps) and found
        return _ok({"steps": steps, "passed": passed,
                    "term": term})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def smoke_brain(args: Dict[str, Any]) -> Dict[str, Any]:
    """Round-trip the knowledge store: add a test entry, search for
    it, then delete it. Uses brain.memory_extras if available, else
    falls back to direct KnowledgeStore usage."""
    needle = f"selftest-knowledge-{int(time.time())}"
    text = f"This is a Leon selftest entry — {needle}. Safe to delete."
    steps: List[Dict[str, Any]] = []
    ks = _knowledge_store()
    if ks is None:
        return _err("KnowledgeStore not available")
    entry_id: Optional[int] = None
    try:
        entry_id = ks.store(text, source="selftest", tags=["selftest"])
        steps.append({"step": "store", "ok": entry_id is not None and entry_id >= 0,
                      "id": entry_id})
        if entry_id is None or entry_id < 0:
            return _ok({"steps": steps, "passed": False,
                        "reason": "store rejected the entry"})
        hits = ks.search(needle, limit=5) or []
        found = any(needle in (h.get("text") or "") for h in hits if isinstance(h, dict))
        steps.append({"step": "search", "ok": True, "hits": len(hits),
                      "found_needle": found})
        deleted = False
        try:
            deleted = bool(ks.delete(entry_id))
        except Exception as e:
            steps.append({"step": "delete", "ok": False,
                          "error": f"{type(e).__name__}: {e}"})
        else:
            steps.append({"step": "delete", "ok": deleted, "id": entry_id})
        passed = all(s.get("ok") for s in steps) and found
        return _ok({"steps": steps, "passed": passed, "needle": needle})
    except Exception as e:
        # Best-effort cleanup
        if entry_id is not None and entry_id >= 0:
            try:
                ks.delete(entry_id)
            except Exception:
                pass
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# CODE HEALTH
# ──────────────────────────────────────────────────────────────────────────


def scan_largest_files(args: Dict[str, Any]) -> Dict[str, Any]:
    """List .py files under `root` by line count, descending."""
    root = args.get("root", "brain")
    try:
        top_n = int(args.get("top_n") or 20)
    except (TypeError, ValueError):
        top_n = 20
    target = _resolve_root_relative(root)
    if target is None:
        return _err(f"root {root!r} escapes project")
    if not os.path.isdir(target):
        return _err(f"not a directory: {_rel(target)}")
    try:
        rows: List[Dict[str, Any]] = []
        for path in _iter_py_files(target):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    lines = sum(1 for _ in f)
            except Exception:
                continue
            rows.append({"path": _rel(path), "lines": lines})
        rows.sort(key=lambda r: r["lines"], reverse=True)
        return _ok({
            "root": _rel(target),
            "total_files": len(rows),
            "top": rows[:top_n],
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _names_from_import(node: ast.AST) -> List[str]:
    """Return the locally bound names for an Import or ImportFrom node."""
    names: List[str] = []
    if isinstance(node, ast.Import):
        for alias in node.names:
            local = alias.asname or alias.name.split(".")[0]
            names.append(local)
    elif isinstance(node, ast.ImportFrom):
        for alias in node.names:
            if alias.name == "*":
                continue
            local = alias.asname or alias.name
            names.append(local)
    return names


def scan_dead_imports(args: Dict[str, Any]) -> Dict[str, Any]:
    """Naive dead-import detector: for each top-level import in each
    file, count occurrences of the bound name outside the import line.
    Zero references → flagged. False positives are possible (e.g.
    imports used only in string-typing annotations); use as a hint."""
    root = args.get("root", "brain")
    target = _resolve_root_relative(root)
    if target is None:
        return _err(f"root {root!r} escapes project")
    if not os.path.isdir(target):
        return _err(f"not a directory: {_rel(target)}")
    flagged: List[Dict[str, Any]] = []
    files_scanned = 0
    try:
        for path in _iter_py_files(target):
            try:
                src = _read_text(path)
                tree = ast.parse(src, filename=path)
            except Exception:
                continue
            files_scanned += 1
            for node in tree.body:
                if not isinstance(node, (ast.Import, ast.ImportFrom)):
                    continue
                names = _names_from_import(node)
                for name in names:
                    # Skip dunder / `_` / future imports
                    if isinstance(node, ast.ImportFrom) and node.module == "__future__":
                        continue
                    if name.startswith("_"):
                        continue
                    # Count word-boundary matches across the file
                    pattern = re.compile(rf"\b{re.escape(name)}\b")
                    hits = len(pattern.findall(src))
                    # The import line itself contributes 1 hit (or more
                    # for `import X as Y` where X also appears). 1 is
                    # the lower-bound for "only in the import statement".
                    if hits <= 1:
                        flagged.append({
                            "file": _rel(path),
                            "line": getattr(node, "lineno", None),
                            "name": name,
                            "kind": "from" if isinstance(node, ast.ImportFrom) else "import",
                            "occurrences_outside_import_stmt": max(0, hits - 1),
                        })
        return _ok({
            "root": _rel(target),
            "files_scanned": files_scanned,
            "flagged_count": len(flagged),
            "flagged": flagged,
            "note": "naive — string-only refs, __all__, and runtime imports may produce false positives",
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def scan_todo_comments(args: Dict[str, Any]) -> Dict[str, Any]:
    """Grep for TODO / FIXME / XXX / HACK markers (case-insensitive)
    in .py files. `root` defaults to the project root."""
    root = args.get("root", None)
    target = _resolve_root_relative(root)
    if target is None:
        return _err(f"root {root!r} escapes project")
    if not os.path.isdir(target):
        return _err(f"not a directory: {_rel(target)}")
    pattern = re.compile(r"\b(TODO|FIXME|XXX|HACK)\b[:\s]*(.*)", re.IGNORECASE)
    hits: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    files_scanned = 0
    try:
        for path in _iter_py_files(target):
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, start=1):
                        m = pattern.search(line)
                        if not m:
                            continue
                        marker = m.group(1).upper()
                        counts[marker] += 1
                        hits.append({
                            "file": _rel(path),
                            "line": i,
                            "marker": marker,
                            "text": line.strip()[:200],
                        })
            except Exception:
                continue
            files_scanned += 1
        return _ok({
            "root": _rel(target),
            "files_scanned": files_scanned,
            "total_hits": len(hits),
            "by_marker": dict(counts),
            "hits": hits,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _function_line_span(node: ast.AST, src_lines_count: int) -> int:
    """Compute span of a function/method node using end_lineno when
    available (Python 3.8+), else estimate by descending nodes."""
    start = getattr(node, "lineno", None)
    end = getattr(node, "end_lineno", None)
    if start is None:
        return 0
    if end is not None:
        return max(0, end - start + 1)
    # Fallback estimate
    last = start
    for child in ast.walk(node):
        ln = getattr(child, "lineno", None)
        if ln is not None and ln > last:
            last = ln
    return max(0, last - start + 1)


def scan_long_functions(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find function/method definitions over `threshold_lines` long."""
    root = args.get("root", "brain")
    try:
        threshold = int(args.get("threshold_lines") or 60)
    except (TypeError, ValueError):
        threshold = 60
    target = _resolve_root_relative(root)
    if target is None:
        return _err(f"root {root!r} escapes project")
    if not os.path.isdir(target):
        return _err(f"not a directory: {_rel(target)}")
    long_funcs: List[Dict[str, Any]] = []
    files_scanned = 0
    try:
        for path in _iter_py_files(target):
            try:
                src = _read_text(path)
                tree = ast.parse(src, filename=path)
            except Exception:
                continue
            files_scanned += 1
            n_lines = src.count("\n") + 1
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    span = _function_line_span(node, n_lines)
                    if span > threshold:
                        long_funcs.append({
                            "file": _rel(path),
                            "name": node.name,
                            "line": node.lineno,
                            "lines": span,
                        })
        long_funcs.sort(key=lambda r: r["lines"], reverse=True)
        return _ok({
            "root": _rel(target),
            "threshold_lines": threshold,
            "files_scanned": files_scanned,
            "long_function_count": len(long_funcs),
            "long_functions": long_funcs,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _has_docstring(node: ast.AST) -> bool:
    return ast.get_docstring(node) not in (None, "")


def scan_missing_docstrings(args: Dict[str, Any]) -> Dict[str, Any]:
    """Find public (non-underscore-prefixed) functions, methods, and
    classes that lack a docstring. Skips private/dunder names and
    `__init__` methods (often left undocumented by convention)."""
    root = args.get("root", "brain")
    target = _resolve_root_relative(root)
    if target is None:
        return _err(f"root {root!r} escapes project")
    if not os.path.isdir(target):
        return _err(f"not a directory: {_rel(target)}")
    missing: List[Dict[str, Any]] = []
    files_scanned = 0
    try:
        for path in _iter_py_files(target):
            try:
                src = _read_text(path)
                tree = ast.parse(src, filename=path)
            except Exception:
                continue
            files_scanned += 1
            # Walk classes + module-level defs
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                     ast.ClassDef)):
                    if node.name.startswith("_") and node.name != "__init__":
                        continue
                    if node.name == "__init__":
                        continue
                    if _has_docstring(node):
                        continue
                    missing.append({
                        "file": _rel(path),
                        "name": node.name,
                        "kind": type(node).__name__,
                        "line": node.lineno,
                    })
        return _ok({
            "root": _rel(target),
            "files_scanned": files_scanned,
            "missing_count": len(missing),
            "missing": missing,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def dependency_graph(args: Dict[str, Any]) -> Dict[str, Any]:
    """Parse the imports of a single Python file. Returns the imported
    module names split into stdlib-ish / third-party / project-local
    buckets, plus the raw list."""
    file_path = args.get("file_path")
    if not file_path:
        return _err("file_path is required")
    if not os.path.isabs(file_path):
        file_path = os.path.join(_project_root(), file_path)
    if not _safe_under_root(file_path):
        return _err(f"path escapes project root")
    if not os.path.isfile(file_path):
        return _err(f"file not found: {_rel(file_path)}")
    try:
        src = _read_text(file_path)
        tree = ast.parse(src, filename=file_path)
    except Exception as e:
        return _err(f"parse failed: {type(e).__name__}: {e}")

    raw: List[Dict[str, Any]] = []
    project_local: List[str] = []
    third_party: List[str] = []
    stdlib_like: List[str] = []

    # Quick stdlib heuristic — single-segment names matching common ones
    stdlib_names = {
        "os", "sys", "re", "json", "time", "math", "io", "ast", "typing",
        "subprocess", "shutil", "socket", "threading", "queue", "asyncio",
        "datetime", "collections", "itertools", "functools", "pathlib",
        "sqlite3", "uuid", "random", "hashlib", "base64", "logging",
        "argparse", "tempfile", "contextlib", "copy", "string", "struct",
        "traceback", "warnings", "inspect", "importlib", "glob", "csv",
        "html", "http", "urllib", "email", "xml", "zipfile", "tarfile",
        "platform", "signal", "atexit", "weakref", "enum", "dataclasses",
        "abc", "concurrent",
    }

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modname = alias.name
                raw.append({"kind": "import", "module": modname,
                            "alias": alias.asname, "line": node.lineno})
                top = modname.split(".")[0]
                if top == "brain" or top.startswith("brain"):
                    project_local.append(modname)
                elif top in stdlib_names:
                    stdlib_like.append(modname)
                else:
                    third_party.append(modname)
        elif isinstance(node, ast.ImportFrom):
            modname = node.module or ""
            level = node.level or 0
            full = ("." * level) + modname
            for alias in node.names:
                raw.append({
                    "kind": "from",
                    "module": full,
                    "name": alias.name,
                    "alias": alias.asname,
                    "line": node.lineno,
                })
            top = modname.split(".")[0] if modname else ""
            label = full or "(relative)"
            if level > 0 or top == "brain" or top.startswith("brain"):
                project_local.append(label)
            elif top in stdlib_names:
                stdlib_like.append(label)
            elif top:
                third_party.append(label)

    def _uniq(seq: List[str]) -> List[str]:
        seen = set()
        out: List[str] = []
        for s in seq:
            if s not in seen:
                seen.add(s)
                out.append(s)
        return out

    return _ok({
        "file": _rel(file_path),
        "import_count": len(raw),
        "project_local": _uniq(project_local),
        "third_party": _uniq(third_party),
        "stdlib": _uniq(stdlib_like),
        "imports": raw,
    })


def audit_jsonl_size_check(args: Dict[str, Any]) -> Dict[str, Any]:
    """Check the size of audit log files. Warns if any is over 100MB."""
    threshold = 100 * 1024 * 1024
    rows: List[Dict[str, Any]] = []
    try:
        for path in _audit_log_candidates():
            if not os.path.exists(path):
                continue
            try:
                size = os.path.getsize(path)
            except Exception:
                continue
            rows.append({
                "path": path,
                "size_bytes": size,
                "size_mb": round(size / (1024 * 1024), 2),
                "over_threshold": size > threshold,
            })
        warnings = [r for r in rows if r["over_threshold"]]
        return _ok({
            "threshold_mb": 100,
            "audit_files_found": len(rows),
            "files": rows,
            "warnings": warnings,
            "warning_count": len(warnings),
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ──────────────────────────────────────────────────────────────────────────
# META-IMPROVEMENT  (audit, snapshot, A/B, config, routine proposals)
# ──────────────────────────────────────────────────────────────────────────


def _read_audit_jsonl(path: str, since_ts: Optional[float] = None,
                      max_rows: int = 50000) -> List[Dict[str, Any]]:
    """Read an actuator-audit.jsonl, optionally filtered to entries
    newer than `since_ts`. Caps at `max_rows`."""
    rows: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                ts = row.get("ts") or row.get("timestamp")
                if isinstance(ts, str):
                    # Try ISO timestamp
                    try:
                        import datetime as _dt
                        s = ts.rstrip("Z")
                        dt = _dt.datetime.fromisoformat(s)
                        ts = dt.timestamp()
                    except Exception:
                        ts = None
                if since_ts is not None and isinstance(ts, (int, float)):
                    if ts < since_ts:
                        continue
                rows.append(row)
                if len(rows) >= max_rows:
                    break
    except Exception:
        pass
    return rows


def _suggest_fix_for_error(tool: str, error: str) -> str:
    """Heuristic mapping from common error substrings to suggestions."""
    e = (error or "").lower()
    if "permission denied" in e:
        return "check file permissions / running user"
    if "not found" in e or "no such file" in e:
        return "verify path / install missing dependency"
    if "timeout" in e or "timed out" in e:
        return "increase timeout or check upstream service"
    if "connection refused" in e or "socket" in e:
        return "ensure target service (actuator/server) is running"
    if "api key" in e or "anthropic_api_key" in e or "unauthorized" in e:
        return "set ANTHROPIC_API_KEY environment variable"
    if "json" in e and ("decode" in e or "parse" in e):
        return "upstream returned non-JSON — inspect response"
    if "missing" in e and "required" in e:
        return "tool args missing — check schema / caller"
    if "not in local registry" in e or "not registered" in e:
        return "register tool in EXTRA_TOOLS or wire module into responder"
    return "investigate — no obvious pattern"


def list_recent_failures(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read the actuator audit log and surface failure clusters with
    suggested fixes."""
    try:
        days = int(args.get("days") or 7)
    except (TypeError, ValueError):
        days = 7
    if days <= 0:
        return _err("days must be positive")
    audit_path = _audit_log_path()
    if audit_path is None:
        return _ok({
            "days": days,
            "audit_path": None,
            "note": "no actuator-audit.jsonl found in expected locations",
            "candidates": _audit_log_candidates(),
            "failures": [],
        })
    since_ts = time.time() - (days * 86400)
    rows = _read_audit_jsonl(audit_path, since_ts=since_ts)
    failures: List[Dict[str, Any]] = []
    for r in rows:
        ok = r.get("ok")
        if ok is None:
            result = r.get("result") or {}
            ok = result.get("ok") if isinstance(result, dict) else None
        if ok is False:
            err = r.get("error")
            if not err and isinstance(r.get("result"), dict):
                err = r["result"].get("error")
            failures.append({
                "ts": r.get("ts") or r.get("timestamp"),
                "tool": r.get("tool") or r.get("name"),
                "error": err or "(unknown)",
                "args": r.get("args"),
            })
    by_tool: Counter = Counter()
    by_signature: Counter = Counter()
    for f in failures:
        by_tool[f.get("tool") or "(unknown)"] += 1
        sig = f"{f.get('tool') or '?'} :: {(f.get('error') or '')[:80]}"
        by_signature[sig] += 1
    clusters: List[Dict[str, Any]] = []
    for sig, count in by_signature.most_common(20):
        # Pick a representative failure for the suggestion
        rep = next((f for f in failures
                    if f"{f.get('tool') or '?'} :: {(f.get('error') or '')[:80]}" == sig),
                   None)
        clusters.append({
            "signature": sig,
            "count": count,
            "suggested_fix": _suggest_fix_for_error(
                (rep or {}).get("tool") or "",
                (rep or {}).get("error") or "",
            ),
        })
    return _ok({
        "days": days,
        "audit_path": audit_path,
        "rows_scanned": len(rows),
        "failure_count": len(failures),
        "by_tool": dict(by_tool.most_common(20)),
        "clusters": clusters,
        "recent_failures": failures[-20:],
    })


# Rolling cap on brain_state-snapshots/ — mirrors persistence.py's
# MAX_BACKUPS pattern for brain_state/backups/. Unlike those backups (which
# are scoped to just regions/synapses/meta.json/self_model.json, ~90MB
# each), a self-improve snapshot deliberately mirrors the ENTIRE
# brain_state/ dir — snapshot_restore() below replaces brain_state/
# wholesale from one, so trimming what a snapshot CONTAINS would silently
# delete live databases/voice models/logs the next time someone restores.
# The only lever that is safe to pull here is COUNT.
#
# Found 2026-08-25 auditing "brain state ballooned in size abnormally
# fast": snapshot_brain_state() had no rotation of any kind — every call
# left a full, permanent copy of brain_state/ (voice models, every
# database, everything) under brain_state-snapshots/, forever. Evidence
# on this VPS: four snapshots created ~5-6 minutes apart (an agent
# exercising its own meta.* tools) total 1.3GB, one of them alone 1.1GB.
# Nothing before this cap would ever have stopped that from becoming
# unbounded disk growth on a long-lived or heavily self-editing SI —
# including a fresh install whose agent explores its own tool surface.
MAX_SNAPSHOTS = 5


def _rotate_snapshots():
    """Keep only the newest MAX_SNAPSHOTS snapshot directories."""
    try:
        root = _snapshots_dir()
        entries = [
            os.path.join(root, d) for d in os.listdir(root)
            if os.path.isdir(os.path.join(root, d))
        ]
        entries.sort(key=lambda p: os.path.getmtime(p))
        while len(entries) > MAX_SNAPSHOTS:
            oldest = entries.pop(0)
            shutil.rmtree(oldest, ignore_errors=True)
    except Exception:
        pass


def snapshot_brain_state(args: Dict[str, Any]) -> Dict[str, Any]:
    """Copy brain_state/ to brain_state-snapshots/{label}_{ts}/.
    `label` is sanitized; if omitted, defaults to 'snapshot'.
    Rolling cap: only the newest MAX_SNAPSHOTS copies are kept (see
    _rotate_snapshots) — this can create large directories (it mirrors
    everything, including voice models and databases, because
    snapshot_restore() needs a complete copy to restore from), so an
    unbounded count of them is exactly the "unbounded growth loop" class
    of bug this cap exists to close."""
    label = (args.get("label") or "snapshot").strip()
    safe_label = re.sub(r"[^A-Za-z0-9_.-]", "_", label).strip("_") or "snapshot"
    ts = int(time.time())
    target_name = f"{safe_label}_{ts}"
    src = _brain_state_dir()
    dst = os.path.join(_snapshots_dir(), target_name)
    if not _safe_under_root(dst):
        return _err("snapshot path escapes project")
    try:
        if not os.path.isdir(src):
            return _err(f"brain_state dir missing: {src}")
        shutil.copytree(src, dst, symlinks=False,
                        ignore=shutil.ignore_patterns("*.lock", "*.tmp"))
        # Tally size
        total_bytes = 0
        file_count = 0
        for dp, _dn, fns in os.walk(dst):
            for fn in fns:
                try:
                    total_bytes += os.path.getsize(os.path.join(dp, fn))
                    file_count += 1
                except Exception:
                    pass
        _rotate_snapshots()
        return _ok({
            "label": safe_label,
            "snapshot_dir": dst,
            "files": file_count,
            "bytes": total_bytes,
            "mb": round(total_bytes / (1024 * 1024), 2),
            "ts": ts,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def snapshot_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List available brain_state snapshots, newest first."""
    try:
        root = _snapshots_dir()
        rows: List[Dict[str, Any]] = []
        for name in sorted(os.listdir(root)):
            path = os.path.join(root, name)
            if not os.path.isdir(path):
                continue
            try:
                stat = os.stat(path)
            except Exception:
                continue
            total_bytes = 0
            file_count = 0
            for dp, _dn, fns in os.walk(path):
                for fn in fns:
                    try:
                        total_bytes += os.path.getsize(os.path.join(dp, fn))
                        file_count += 1
                    except Exception:
                        pass
            rows.append({
                "label": name,
                "path": path,
                "mtime": stat.st_mtime,
                "files": file_count,
                "bytes": total_bytes,
                "mb": round(total_bytes / (1024 * 1024), 2),
            })
        rows.sort(key=lambda r: r["mtime"], reverse=True)
        return _ok({"count": len(rows), "snapshots": rows, "dir": root})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def snapshot_restore(args: Dict[str, Any]) -> Dict[str, Any]:
    """Restore brain_state/ from a previously created snapshot.
    HIGH-RISK — replaces the live state. Before overwriting, the
    current brain_state/ is itself snapshotted to
    brain_state-snapshots/pre-restore_{ts}/ so the caller can roll
    back. Caller must pass confirm=True (or 'yes'/1) to proceed."""
    label = (args.get("label") or "").strip()
    if not label:
        return _err("label is required")
    confirm = args.get("confirm")
    if confirm not in (True, "yes", "true", 1, "1"):
        return _err("confirm=True is required (HIGH-RISK irreversible op)")
    snap_dir = os.path.join(_snapshots_dir(), label)
    if not _safe_under_root(snap_dir):
        return _err("snapshot path escapes project")
    if not os.path.isdir(snap_dir):
        return _err(f"snapshot not found: {label}")
    try:
        # Pre-restore safety snapshot
        pre = snapshot_brain_state({"label": "pre-restore"})
        live = _brain_state_dir()
        # Remove live contents but keep the directory itself
        for entry in os.listdir(live):
            ep = os.path.join(live, entry)
            try:
                if os.path.isdir(ep) and not os.path.islink(ep):
                    shutil.rmtree(ep)
                else:
                    os.remove(ep)
            except Exception:
                pass
        # Copy snapshot contents into live
        for entry in os.listdir(snap_dir):
            sp = os.path.join(snap_dir, entry)
            dp = os.path.join(live, entry)
            if os.path.isdir(sp):
                shutil.copytree(sp, dp, symlinks=False)
            else:
                shutil.copy2(sp, dp)
        return _ok({
            "restored_from": label,
            "live_dir": live,
            "pre_restore_snapshot": (pre.get("result") or {}).get("snapshot_dir"),
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def prompt_ab_compare(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run two prompts against the same set of inputs via the
    Anthropic API and return side-by-side outputs. Best-effort:
    returns ok=False with a friendly message if the SDK is missing
    or ANTHROPIC_API_KEY is unset."""
    prompt_a = args.get("prompt_a")
    prompt_b = args.get("prompt_b")
    test_inputs = args.get("test_inputs")
    model = args.get("model") or "claude-haiku-4-5"
    if not prompt_a or not prompt_b:
        return _err("prompt_a and prompt_b are required")
    if not isinstance(test_inputs, list) or not test_inputs:
        return _err("test_inputs must be a non-empty list of strings")
    try:
        import anthropic  # noqa: F401
    except Exception:
        return _err("anthropic SDK not installed (pip install anthropic)")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return _err("ANTHROPIC_API_KEY env var not set")
    try:
        from anthropic import Anthropic
        client = Anthropic()
    except Exception as e:
        return _err(f"failed to init Anthropic client: {type(e).__name__}: {e}")

    def _ask(system_prompt: str, user_input: str) -> Dict[str, Any]:
        t0 = time.time()
        try:
            resp = client.messages.create(
                model=model,
                max_tokens=512,
                system=str(system_prompt),
                messages=[{"role": "user", "content": str(user_input)}],
            )
            text_chunks = []
            for block in (resp.content or []):
                # SDK blocks expose .text on text blocks
                text = getattr(block, "text", None)
                if text:
                    text_chunks.append(text)
            return {
                "ok": True,
                "text": "".join(text_chunks),
                "elapsed_ms": int((time.time() - t0) * 1000),
                "stop_reason": getattr(resp, "stop_reason", None),
                "input_tokens": getattr(getattr(resp, "usage", None), "input_tokens", None),
                "output_tokens": getattr(getattr(resp, "usage", None), "output_tokens", None),
            }
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}",
                    "elapsed_ms": int((time.time() - t0) * 1000)}

    rows: List[Dict[str, Any]] = []
    for user_input in test_inputs:
        ra = _ask(prompt_a, user_input)
        rb = _ask(prompt_b, user_input)
        rows.append({
            "input": user_input,
            "a": ra,
            "b": rb,
        })
    return _ok({
        "model": model,
        "test_count": len(test_inputs),
        "comparisons": rows,
    })


def _read_config() -> Dict[str, Any]:
    path = _config_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_config(data: Dict[str, Any]) -> None:
    path = _config_path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def config_get(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read a key (dotted path) from brain_state/config.json. Pass
    no key (or key=None) to return the whole config."""
    key = args.get("key")
    try:
        cfg = _read_config()
        if key is None or key == "":
            return _ok({"path": _config_path(), "config": cfg})
        cursor: Any = cfg
        for part in str(key).split("."):
            if isinstance(cursor, dict) and part in cursor:
                cursor = cursor[part]
            else:
                return _ok({"path": _config_path(), "key": key,
                            "exists": False, "value": None})
        return _ok({"path": _config_path(), "key": key,
                    "exists": True, "value": cursor})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def config_set(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set a key (dotted path) in brain_state/config.json. Intermediate
    dicts are created as needed. Value must be JSON-serializable."""
    key = (args.get("key") or "").strip()
    if not key:
        return _err("key is required")
    if "value" not in args:
        return _err("value is required (use null to clear)")
    value = args["value"]
    # Make sure value is JSON-serializable
    try:
        json.dumps(value)
    except (TypeError, ValueError) as e:
        return _err(f"value not JSON-serializable: {e}")
    try:
        cfg = _read_config()
        parts = key.split(".")
        cursor = cfg
        for part in parts[:-1]:
            if part not in cursor or not isinstance(cursor[part], dict):
                cursor[part] = {}
            cursor = cursor[part]
        cursor[parts[-1]] = value
        _write_config(cfg)
        return _ok({"path": _config_path(), "key": key, "value": value})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def routine_proposal_from_audit(args: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze the audit log for repeated manual patterns and suggest
    candidate routines. A 'pattern' is a (tool, day-of-week, hour)
    bucket that fires often enough to look habitual."""
    try:
        days = int(args.get("days") or 7)
    except (TypeError, ValueError):
        days = 7
    audit_path = _audit_log_path()
    if audit_path is None:
        return _ok({
            "days": days,
            "audit_path": None,
            "proposals": [],
            "note": "no actuator-audit.jsonl found",
        })
    since_ts = time.time() - (days * 86400)
    rows = _read_audit_jsonl(audit_path, since_ts=since_ts)

    # Bucket: (tool, weekday, hour) → count
    buckets: Counter = Counter()
    tool_counts: Counter = Counter()
    tool_hours: Dict[str, Counter] = defaultdict(Counter)
    for r in rows:
        tool = r.get("tool") or r.get("name")
        if not tool:
            continue
        ts = r.get("ts") or r.get("timestamp")
        if isinstance(ts, str):
            try:
                import datetime as _dt
                s = ts.rstrip("Z")
                ts = _dt.datetime.fromisoformat(s).timestamp()
            except Exception:
                ts = None
        if not isinstance(ts, (int, float)):
            continue
        try:
            lt = time.localtime(ts)
        except Exception:
            continue
        tool_counts[tool] += 1
        tool_hours[tool][lt.tm_hour] += 1
        buckets[(tool, lt.tm_wday, lt.tm_hour)] += 1

    # A pattern looks habitual if it occurs at least 3x in the window
    # OR represents >=50% of a tool's total invocations
    proposals: List[Dict[str, Any]] = []
    seen_tools = set()
    for (tool, wday, hour), count in buckets.most_common():
        if count < 3:
            continue
        tool_total = tool_counts[tool] or 1
        if count < 3 and (count / tool_total) < 0.5:
            continue
        if tool in seen_tools:
            continue
        seen_tools.add(tool)
        proposals.append({
            "tool": tool,
            "weekday": wday,
            "hour": hour,
            "occurrences": count,
            "tool_total": tool_total,
            "fraction": round(count / tool_total, 3),
            "suggested_routine": (
                f"routine: every {_weekday_name(wday)} at "
                f"{hour:02d}:00 → call {tool!r}"
            ),
        })

    # Top "always-fires-around-this-hour" hints (regardless of weekday)
    hot_tools: List[Dict[str, Any]] = []
    for tool, total in tool_counts.most_common(10):
        if total < 5:
            continue
        hr_counter = tool_hours[tool]
        if not hr_counter:
            continue
        peak_hour, peak_count = hr_counter.most_common(1)[0]
        if peak_count / total >= 0.4:
            hot_tools.append({
                "tool": tool,
                "peak_hour": peak_hour,
                "peak_count": peak_count,
                "total": total,
                "fraction": round(peak_count / total, 3),
                "hint": f"{tool} clusters around {peak_hour:02d}:00",
            })

    return _ok({
        "days": days,
        "rows_scanned": len(rows),
        "unique_tools": len(tool_counts),
        "proposals": proposals[:20],
        "hot_hour_hints": hot_tools,
    })


def _weekday_name(wday: int) -> str:
    names = ["Monday", "Tuesday", "Wednesday", "Thursday",
             "Friday", "Saturday", "Sunday"]
    if 0 <= wday < 7:
        return names[wday]
    return f"weekday_{wday}"


# ──────────────────────────────────────────────────────────────────────────
# RELIABILITY
# ──────────────────────────────────────────────────────────────────────────


def retry_last_failure(args: Dict[str, Any]) -> Dict[str, Any]:
    """Replay the most recent failed tool call from the audit log,
    using the same args. Returns the new result alongside the
    original failure for comparison."""
    audit_path = _audit_log_path()
    if audit_path is None:
        return _err("no actuator-audit.jsonl found")
    try:
        last_failure: Optional[Dict[str, Any]] = None
        with open(audit_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                ok = row.get("ok")
                if ok is None and isinstance(row.get("result"), dict):
                    ok = row["result"].get("ok")
                if ok is False:
                    last_failure = row
        if last_failure is None:
            return _ok({"replayed": False, "note": "no failures in audit log"})
        tool_name = last_failure.get("tool") or last_failure.get("name")
        call_args = last_failure.get("args") or {}
        if not tool_name:
            return _err("last failure row missing 'tool' field")
        # Try local registry first, then actuator socket
        registry = _local_tools_registry()
        if tool_name in registry:
            ok, new_result, ms = _try_call(tool_name, registry, call_args)
            via = "local"
        else:
            ok, new_result, ms = _try_actuator_call(tool_name, call_args)
            via = "actuator"
        return _ok({
            "replayed": True,
            "via": via,
            "tool": tool_name,
            "args": call_args,
            "original_failure": {
                "ts": last_failure.get("ts") or last_failure.get("timestamp"),
                "error": last_failure.get("error")
                         or (last_failure.get("result") or {}).get("error"),
            },
            "new_result": new_result,
            "new_ok": ok,
            "elapsed_ms": ms,
        })
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _ws_clients_count() -> Optional[int]:
    """Best-effort: read the brain server's WS-client count via the
    server's HTTP endpoint. Returns None if not reachable."""
    try:
        import urllib.request, os as _os
        _tok = _os.environ.get("LEON_API_KEY", "")
        if not _tok:
            # Without the key this request can only 401 — skip instead
            # of spamming the auth log every poll cycle.
            return None
        _hdrs = {"Authorization": f"Bearer {_tok}"}
        _req = urllib.request.Request(
            "http://127.0.0.1:8000/api/health", headers=_hdrs,
        )
        with urllib.request.urlopen(_req, timeout=2.0) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            data = json.loads(body)
            if isinstance(data, dict):
                for key in ("ws_clients", "clients", "connected_clients"):
                    if key in data:
                        return int(data[key])
    except Exception:
        pass
    return None


def _claude_warm() -> Dict[str, Any]:
    """Check whether the `claude` CLI is on PATH and responds to
    --version. Tight 5s timeout."""
    info: Dict[str, Any] = {"available": False}
    claude_path = shutil.which("claude")
    info["path"] = claude_path
    if claude_path is None:
        info["note"] = "`claude` CLI not on PATH"
        return info
    try:
        t0 = time.time()
        out = subprocess.run([claude_path, "--version"],
                             capture_output=True, text=True, timeout=5.0)
        info["available"] = out.returncode == 0
        info["version"] = (out.stdout or out.stderr or "").strip().splitlines()[:1]
        info["elapsed_ms"] = int((time.time() - t0) * 1000)
    except Exception as e:
        info["error"] = f"{type(e).__name__}: {e}"
    return info


def _gpu_available() -> Dict[str, Any]:
    """Best-effort: nvidia-smi → returncode 0 means a GPU is present."""
    info: Dict[str, Any] = {"available": False}
    nvidia = shutil.which("nvidia-smi")
    info["nvidia_smi"] = nvidia
    if nvidia is None:
        info["note"] = "nvidia-smi not found"
        return info
    try:
        out = subprocess.run(
            [nvidia, "--query-gpu=name,memory.total,memory.used,utilization.gpu",
             "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5.0,
        )
        if out.returncode == 0:
            info["available"] = True
            info["gpus"] = [ln.strip() for ln in out.stdout.splitlines() if ln.strip()]
        else:
            info["error"] = out.stderr.strip()[:200]
    except Exception as e:
        info["error"] = f"{type(e).__name__}: {e}"
    return info


def _writable(path: str) -> Dict[str, Any]:
    info: Dict[str, Any] = {"path": path, "exists": os.path.exists(path),
                             "writable": False}
    try:
        if os.path.isdir(path):
            test = os.path.join(path, f".__leon_writetest_{int(time.time())}")
            with open(test, "w") as f:
                f.write("x")
            os.remove(test)
            info["writable"] = True
        elif os.path.isfile(path):
            info["writable"] = os.access(path, os.W_OK)
        else:
            # Try to create parent if path is missing
            parent = os.path.dirname(path) or "."
            info["writable"] = os.access(parent, os.W_OK)
    except Exception as e:
        info["error"] = f"{type(e).__name__}: {e}"
    return info


def healthcheck_all(args: Dict[str, Any]) -> Dict[str, Any]:
    """Comprehensive health probe: actuator socket, WS clients,
    claude CLI warmth, GPU, key dirs writable, audit log size."""
    root = _project_root()
    state_dir = _brain_state_dir()
    snaps_dir = _snapshots_dir()

    # Actuator
    ok_act, _resp, ms_act = _try_actuator_call("system.resource_summary", {},
                                               timeout=3.0)
    actuator = {
        "reachable": ok_act,
        "elapsed_ms": ms_act,
    }

    # WS clients
    ws_count = _ws_clients_count()

    # Claude CLI
    claude_info = _claude_warm()

    # GPU
    gpu_info = _gpu_available()

    # Writable dirs
    writable = {
        "project_root": _writable(root),
        "brain_state": _writable(state_dir),
        "snapshots_dir": _writable(snaps_dir),
    }

    # Audit log size
    audit = audit_jsonl_size_check({})
    audit_summary = audit.get("result") if audit.get("ok") else None

    # Aggregate verdict
    components = {
        "actuator": actuator["reachable"],
        "claude_cli": bool(claude_info.get("available")),
        "gpu": bool(gpu_info.get("available")),
        "ws_server": ws_count is not None,
        "brain_state_writable": bool(writable["brain_state"].get("writable")),
        "snapshots_dir_writable": bool(writable["snapshots_dir"].get("writable")),
    }
    healthy = sum(1 for v in components.values() if v)
    return _ok({
        "components": components,
        "healthy_count": healthy,
        "total_components": len(components),
        "actuator": actuator,
        "ws_clients": ws_count,
        "claude": claude_info,
        "gpu": gpu_info,
        "writable_dirs": writable,
        "audit_log": audit_summary,
    })


# ──────────────────────────────────────────────────────────────────────────
# TOOL REGISTRY
# ──────────────────────────────────────────────────────────────────────────


EXTRA_TOOLS: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {
    # Self-test framework
    "selftest.run_battery": run_battery,
    "selftest.list_suites": list_suites,
    "selftest.save_suite": save_suite,
    "selftest.smoke_actuator": smoke_actuator,
    "selftest.smoke_memory": smoke_memory,
    "selftest.smoke_brain": smoke_brain,
    # Codebase health
    "code.scan_largest_files": scan_largest_files,
    "code.scan_dead_imports": scan_dead_imports,
    "code.scan_todo_comments": scan_todo_comments,
    "code.scan_long_functions": scan_long_functions,
    "code.scan_missing_docstrings": scan_missing_docstrings,
    "code.dependency_graph": dependency_graph,
    "code.audit_jsonl_size_check": audit_jsonl_size_check,
    # Meta-improvement
    "meta.list_recent_failures": list_recent_failures,
    "meta.snapshot_brain_state": snapshot_brain_state,
    "meta.snapshot_list": snapshot_list,
    "meta.snapshot_restore": snapshot_restore,
    "meta.prompt_ab_compare": prompt_ab_compare,
    "meta.config_get": config_get,
    "meta.config_set": config_set,
    "meta.routine_proposal_from_audit": routine_proposal_from_audit,
    # Reliability
    "reliability.retry_last_failure": retry_last_failure,
    "reliability.healthcheck_all": healthcheck_all,
}
