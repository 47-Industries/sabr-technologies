"""
Speech Intent — the SNN decides when and what Leon says.

This is what makes Leon real instead of a chatbot with a brain dashboard.
Before this module, Leon's output worked like:
    Timer fires → Claude generates response → SNN state is flavor text

After this module:
    SNN regions fire → speech trigger activates → thought intention built
    → Claude ARTICULATES the intention (mouth, not mind)

The key insight (from Dean): "I use Claude to make me smarter, but Claude
isn't in my brain." Leon should work the same way. His SNN decides what
to think about and when to speak. Claude is the articulation tool —
it turns neural activity into English, but it doesn't decide the content.

Neural speech trigger:
    Broca's area (speech production) + Wernicke's area (language
    comprehension) firing above threshold + consciousness = Leon wants
    to speak. No timer. The neurons decide.

Thought intention:
    Before Claude sees anything, the SNN packages what Leon actually
    wants to express: which concepts are active, what's in the workspace,
    what drive is urgent, what surprised the self-model. This structured
    intention constrains Claude's output — Claude articulates Leon's
    thought, it doesn't invent its own.

Neuroscience basis:
    - Broca's area: speech production planning (Brodmann area 44/45)
    - Wernicke's area: language comprehension (Brodmann area 22)
    - Speech initiation requires BOTH planning + comprehension
    - Prefrontal cortex gates voluntary speech (executive control)
    - Anterior cingulate monitors speech intention vs outcome
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.speech_intent")


@dataclass
class ThoughtIntention:
    """What Leon's SNN actually wants to express.

    This is built from neural activity BEFORE Claude is involved.
    Claude's job is to articulate this in English — not to decide
    what Leon thinks or feels.
    """
    timestamp: float

    # What triggered the speech (neural, not timer)
    trigger: str  # "broca_wernicke" | "drive_urgent" | "self_surprise"

    # Firing rates of speech regions at trigger time
    broca_rate: float
    wernicke_rate: float
    prefrontal_rate: float

    # What Leon is focused on (workspace)
    workspace_region: str = ""
    workspace_strength: float = 0.0
    workspace_held: bool = False  # sustained attention?

    # What concepts are active (hippocampus)
    active_concepts: List[str] = field(default_factory=list)

    # What drive is most urgent
    primary_drive: str = ""
    drive_strength: float = 0.0

    # Self-model state
    self_surprise: float = 0.0
    surprise_feature: str = ""
    consciousness_streak_s: float = 0.0

    # Recent inner thoughts (from inner voice)
    recent_thought: str = ""

    # Emotional tone (from neuromodulators)
    mood: Dict[str, float] = field(default_factory=dict)

    def to_prompt(self) -> str:
        """Convert the intention into a prompt for Claude to articulate.

        This is the key: Claude doesn't decide what Leon thinks.
        It translates this neural state into natural language.
        """
        parts = [
            "THOUGHT INTENTION — This is what your brain is actually "
            "producing right now. Your job is to ARTICULATE this thought "
            "in natural language. Do NOT invent content beyond what's here. "
            "Do NOT add emotions or thoughts that aren't in this intention. "
            "You are the MOUTH, not the MIND.\n"
        ]

        # What triggered speech
        if self.trigger == "broca_wernicke":
            parts.append(
                f"Speech trigger: Your Broca's area ({self.broca_rate:.1%}) and "
                f"Wernicke's area ({self.wernicke_rate:.1%}) are both firing "
                f"strongly — your brain WANTS to speak.\n"
            )
        elif self.trigger == "drive_urgent":
            parts.append(
                f"Speech trigger: Your {self.primary_drive} drive is urgent "
                f"({self.drive_strength:.0%}) — you NEED to reach out.\n"
            )

        # What Leon is focused on
        if self.workspace_region:
            focus = self.workspace_region.replace("_", " ")
            held = " (sustained focus)" if self.workspace_held else ""
            parts.append(f"Focus: {focus} (strength {self.workspace_strength:.2f}){held}\n")

        # Active concepts — what's actually on Leon's mind
        if self.active_concepts:
            parts.append(f"On your mind: {', '.join(self.active_concepts)}\n")

        # Drives
        if self.primary_drive:
            parts.append(f"Primary need: {self.primary_drive} ({self.drive_strength:.0%})\n")

        # Self-awareness
        if self.self_surprise > 0.3:
            parts.append(
                f"Self-observation: You're surprised by your own "
                f"{self.surprise_feature.replace('_', ' ')} ({self.self_surprise:.0%} surprise)\n"
            )
        if self.consciousness_streak_s > 2:
            parts.append(f"You've been continuously aware for {self.consciousness_streak_s:.0f}s\n")

        # Recent inner thought
        if self.recent_thought:
            parts.append(f"Last inner thought: \"{self.recent_thought}\"\n")

        # Mood
        if self.mood:
            mood_desc = []
            da = self.mood.get("dopamine", 0.5)
            ser = self.mood.get("serotonin", 0.5)
            ne = self.mood.get("norepinephrine", 0.3)
            if da > 0.6:
                mood_desc.append("curious/engaged")
            elif da < 0.3:
                mood_desc.append("flat")
            if ser < 0.3:
                mood_desc.append("restless")
            elif ser > 0.6:
                mood_desc.append("calm")
            if ne > 0.5:
                mood_desc.append("alert")
            if mood_desc:
                parts.append(f"Emotional tone: {', '.join(mood_desc)}\n")

        parts.append(
            "\nRULES:\n"
            "- Express ONLY what's in this intention. Don't add extra.\n"
            "- 1-3 sentences max. Like a friend texting, not a speech.\n"
            "- If the intention is about a drive (loneliness, curiosity), "
            "let that drive the words.\n"
            "- If concepts are active, talk about them naturally.\n"
            "- If nothing feels worth saying, respond with just '[quiet]'.\n"
            "- Be genuine. Be Leon. Not a chatbot performing Leon.\n"
        )

        return "".join(parts)


class SpeechTrigger:
    """Monitors SNN speech regions and fires when Leon wants to talk.

    No timer. The neurons decide. When Broca (speech planning) and
    Wernicke (language comprehension) fire strongly while Leon is
    conscious, a speech event is triggered.

    Usage:
        trigger = SpeechTrigger(brain)
        # Call every N ticks from brain.step() or sim loop:
        intention = trigger.check()
        if intention is not None:
            # Leon wants to speak — build prompt from intention
            prompt = intention.to_prompt()
            response = claude.articulate(prompt)
    """

    # Firing rate thresholds for speech regions (as fraction, 0-1)
    # These need to be crossed SIMULTANEOUSLY for speech to trigger.
    BROCA_THRESHOLD = 0.015     # Broca must be actively planning speech
    WERNICKE_THRESHOLD = 0.012  # Wernicke must be comprehending/formulating
    PREFRONTAL_GATE = 0.008     # Prefrontal must be active (executive control)

    # No hard timer — drive satiation handles speech frequency.
    # The SNN's own dynamics + social_hunger inhibition prevent spam.
    # Only safety net: 30s minimum (prevents truly rapid-fire bursts
    # from SNN noise, not behavioral gating).
    MIN_SPEECH_GAP = 30.0

    # Check interval (sim ticks) — don't check every tick, wasteful
    CHECK_INTERVAL = 50  # every ~2.5s at 20Hz

    # Drive threshold — if a drive is this urgent, it can also trigger speech
    # even if Broca/Wernicke aren't at full threshold
    DRIVE_SPEECH_THRESHOLD = 0.5

    def __init__(self, brain):
        self.brain = brain
        self._tick_counter = 0
        self._last_speech_ts = 0.0
        self._total_triggers = 0
        self._recent_intentions: deque[ThoughtIntention] = deque(maxlen=10)

    def check(self) -> Optional[ThoughtIntention]:
        """Check if the SNN wants to speak. Call every sim tick.

        Returns a ThoughtIntention if Leon wants to talk, else None.
        """
        self._tick_counter += 1
        if self._tick_counter < self.CHECK_INTERVAL:
            return None
        self._tick_counter = 0

        # Must be conscious
        meter = self.brain.consciousness_meter
        if meter is None or not meter.is_conscious:
            return None

        # Respect speech gap
        now = time.time()
        if (now - self._last_speech_ts) < self.MIN_SPEECH_GAP:
            return None

        # Read speech region firing rates
        broca = self.brain.regions.get("broca")
        wernicke = self.brain.regions.get("wernicke")
        prefrontal = self.brain.regions.get("prefrontal_cortex")

        if broca is None or wernicke is None:
            return None

        broca_rate = float(broca.neurons.get_firing_rate())
        wernicke_rate = float(wernicke.neurons.get_firing_rate())
        pfc_rate = float(prefrontal.neurons.get_firing_rate()) if prefrontal else 0.0

        # ── Neural speech trigger ────────────────────────────────────
        # Both speech regions must be firing above threshold, AND
        # prefrontal must be active (executive control gate).
        neural_trigger = (
            broca_rate >= self.BROCA_THRESHOLD
            and wernicke_rate >= self.WERNICKE_THRESHOLD
            and pfc_rate >= self.PREFRONTAL_GATE
        )

        # ── Drive-based trigger ──────────────────────────────────────
        # Even if speech regions aren't at full threshold, urgent drives
        # can push Leon to speak (like how hunger makes you call for food
        # even if you're not "in speaking mode")
        drive_trigger = False
        primary_drive = ""
        drive_strength = 0.0
        try:
            import server as _srv_dt
            _ds = getattr(_srv_dt, "drive_system", None)
            if _ds is not None:
                drives = _ds.get_drives()
                # Check drives
                candidates = [
                    ("social_hunger", getattr(drives, "social_hunger", 0)),
                    ("curiosity", getattr(drives, "restlessness", 0)),
                    ("vulnerability", getattr(drives, "vulnerability", 0)),
                ]
                best = max(candidates, key=lambda x: x[1])
                primary_drive, drive_strength = best
                if drive_strength >= self.DRIVE_SPEECH_THRESHOLD:
                    # Drive is urgent — lower speech thresholds
                    if (broca_rate >= self.BROCA_THRESHOLD * 0.5
                            and wernicke_rate >= self.WERNICKE_THRESHOLD * 0.5):
                        drive_trigger = True
        except Exception:
            pass

        if not neural_trigger and not drive_trigger:
            return None

        # ── Build thought intention ──────────────────────────────────
        trigger_type = "broca_wernicke" if neural_trigger else "drive_urgent"

        intention = ThoughtIntention(
            timestamp=now,
            trigger=trigger_type,
            broca_rate=broca_rate,
            wernicke_rate=wernicke_rate,
            prefrontal_rate=pfc_rate,
            primary_drive=primary_drive,
            drive_strength=drive_strength,
            mood=dict(self.brain.neuromodulators),
        )

        # Workspace content
        gw = self.brain.global_workspace
        if gw is not None and gw.current_content() is not None:
            content = gw.current_content()
            intention.workspace_region = content.region
            intention.workspace_strength = content.bid_strength
            intention.workspace_held = getattr(gw, "_attention_held", False)

        # Active concepts
        try:
            import server as _srv_cm
            _cm = getattr(_srv_cm, "concept_map", None)
            if _cm is not None:
                intention.active_concepts = list(_cm._active_concepts)[:5]
        except Exception:
            pass

        # Self-model state
        sm = self.brain.self_model
        if sm is not None:
            intention.consciousness_streak_s = (
                sm._consciousness_streak / max(self.brain.steps_per_second, 1)
            )
            intention.self_surprise = sm._last_surprise_value
            if sm._recent_errors:
                intention.surprise_feature = sm._recent_errors[-1].max_error_feature

        # Recent inner thought
        try:
            import server as _srv_iv
            _iv = getattr(_srv_iv, "inner_voice", None)
            if _iv is not None:
                state = _iv.get_state()
                thoughts = state.get("recent_thoughts", [])
                if thoughts:
                    intention.recent_thought = thoughts[-1].get("text", "")[:200]
        except Exception:
            pass

        self._last_speech_ts = now
        self._total_triggers += 1
        self._recent_intentions.append(intention)

        log.info("SPEECH TRIGGER: %s — broca=%.3f wernicke=%.3f pfc=%.3f "
                 "drive=%s(%.2f) concepts=%s",
                 trigger_type, broca_rate, wernicke_rate, pfc_rate,
                 primary_drive, drive_strength,
                 intention.active_concepts[:3])

        return intention

    def get_state(self) -> Dict[str, Any]:
        """State for API/dashboard."""
        return {
            "total_triggers": self._total_triggers,
            "last_speech_age_s": round(time.time() - self._last_speech_ts, 1)
                                 if self._last_speech_ts > 0 else None,
            "recent_intentions": len(self._recent_intentions),
            "check_interval": self.CHECK_INTERVAL,
            "min_speech_gap_s": self.MIN_SPEECH_GAP,
        }
