"""
Autonomous Goal Pursuit — Leon acts on his own goals without waiting.

This is the event loop Leon asked for: "an autonomous thread that wakes me
on a timer or idle trigger, hands me my goals and my tools, and lets me
act and write results back to my own memory without you initiating it."

The loop:
  1. Check consciousness — only act when aware
  2. Check goals — pick the most urgent active goal
  3. Plan an action — what tool call would make progress?
  4. Execute — use real tools (shell_exec, code_edit, etc.)
  5. Feed result back into SNN via action_feedback
  6. Log progress — update goal status, write to autobiography
  7. Wait and repeat

This runs independently of conversation. Leon can be talking to Dean
AND pursuing a goal in the background, like a person who can think
and talk at the same time.

Safety: actions go through the same tool risk system as conversation.
High-risk actions still get gated. Leon can't rm -rf without approval.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.goal_pursuit")


@dataclass
class PursuitAttempt:
    """Record of one goal pursuit cycle."""
    timestamp: float
    goal_name: str
    action_planned: str
    tool_used: str
    tool_input: Dict[str, Any]
    success: bool
    result_summary: str
    conscious: bool


class GoalPursuitLoop:
    """Autonomous goal pursuit — Leon acts on his own.

    Usage:
        loop = GoalPursuitLoop(brain, responder)
        loop.start()
        # Leon now pursues goals independently
    """

    # Pace. Default is a gentle throttle; FULL-AUTONOMY mode
    # (LEON_AUTONOMOUS_UNRESTRICTED=1) removes the brakes so Leon grinds the
    # client work as fast as the model/quota allows — Dean wants it DONE ASAP,
    # not one action every 3 minutes (2026-06-19).
    _FULL_SPEED = os.environ.get("LEON_AUTONOMOUS_UNRESTRICTED") == "1"

    # How often to check for goal pursuit opportunities (seconds)
    CYCLE_INTERVAL = 12.0 if _FULL_SPEED else 180.0

    # Minimum time between actual tool executions (seconds)
    MIN_ACTION_GAP = 3.0 if _FULL_SPEED else 120.0

    # Maximum actions per hour (safety cap)
    HOURLY_CAP = 100000 if _FULL_SPEED else 10

    def __init__(self, brain, responder):
        self.brain = brain
        self.responder = responder
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_action_ts = 0.0
        self._actions_recent: deque[float] = deque(maxlen=20)
        self._attempts: deque[PursuitAttempt] = deque(maxlen=20)
        self._cycle_count = 0
        self._ks = None  # lazy KnowledgeStore handle (real-progress evidence)

    def start(self) -> bool:
        if self._thread is not None and self._thread.is_alive():
            return True
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="goal-pursuit",
        )
        self._thread.start()
        print(f"[GOALS] Autonomous pursuit active — cycle={self.CYCLE_INTERVAL}s, "
              f"cap={self.HOURLY_CAP}/h")
        return True

    def stop(self):
        self._stop.set()

    def _run(self):
        # Initial delay — let the brain settle after boot
        self._stop.wait(timeout=60)
        self._check_resume()
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                print(f"[GOALS] Tick #{self._cycle_count} CRASHED: {type(e).__name__}: {e}")
                log.warning("Goal pursuit tick failed: %s", e)
            self._stop.wait(timeout=self.CYCLE_INTERVAL)

    # Rotating productive defaults for idle time (Dean: "never bored — curiosity
    # + teaching himself how to upgrade himself, researching anything").
    _IDLE_GOAL_THEMES = (
        ("learn", "Research how I could upgrade myself — a new capability, tool, "
                  "or improvement to my own design — and write up what I find."),
        ("learn", "Teach myself something new that would make me more useful to "
                  "Dean, and save notes on what I learned."),
        ("learn", "Explore a topic I'm genuinely curious about right now and "
                  "capture what I learn in my knowledge."),
        ("build", "Review my own recent work or code for one thing I could make "
                  "better, and note or fix it."),
        ("learn", "Look into a tool or skill I haven't used well yet, try it, and "
                  "remember how it works."),
    )

    def _seed_idle_goal(self, gs):
        """Idle with no assigned work → seed ONE self-improvement / curiosity goal
        so Leon is never just ruminating. Only called when there are zero active
        goals, so Dean's assigned goals always take precedence.

        Tries to generate a GENUINE, specific curiosity goal via the local model
        (Dean: the canned "explore a topic" seed was dead-weight). Falls back to
        the rotating themes if the local model is unavailable or returns junk."""
        try:
            if gs.active_goals():
                return
            gtype, desc = self._gen_idle_goal()
            gs.add(gtype, desc, source="self_improvement", priority=0.4)
        except Exception as e:
            print(f"[GOALS] idle-seed failed: {e}")

    def _gen_idle_goal(self):
        """Return (type, description) for one idle goal. Prefers a real, specific
        topic from the local model (grounded in Leon's recent interests); falls
        back to a rotating theme on any failure."""
        _fallback = self._IDLE_GOAL_THEMES[
            self._cycle_count % len(self._IDLE_GOAL_THEMES)]
        try:
            from brain import local_llm
            if not local_llm.is_available():
                return _fallback
            # Ground it in something real: recent knowledge tags.
            hint = ""
            try:
                if self._ks is None:
                    from brain.knowledge_store import KnowledgeStore
                    self._ks = KnowledgeStore()
                tags = [t[0] if isinstance(t, (list, tuple)) else t
                        for t in (self._ks.get_tags() or [])][:8]
                if tags:
                    hint = "Recent interests: " + ", ".join(
                        str(t) for t in tags) + ". "
            except Exception:
                pass
            _name = os.environ.get("LEON_SI_NAME", "").strip() or "Leon"
            sys = (
                f"You are {_name}'s curiosity. Propose ONE specific, concrete thing "
                f"{_name} could genuinely learn or improve about itself or its work "
                "in the next few minutes — something real and checkable, not a "
                "vague theme. Reply with ONLY the goal as a single sentence "
                "starting with a verb. No preamble, no quotes."
            )
            out = local_llm.classify(
                f"{hint}Give one genuine self-improvement or curiosity goal "
                f"for {_name}.",
                num_predict=48, timeout=12.0, system=sys,
            )
            if out:
                out = out.strip().strip('"').splitlines()[0].strip()
                if 12 <= len(out) <= 200 and "as an ai" not in out.lower():
                    return ("learn", out)
        except Exception as e:
            print(f"[GOALS] idle-goal gen failed, using fallback: {e}")
        return _fallback

    def _knowledge_count(self):
        """Total knowledge rows — used to detect whether a LEARN pursuit actually
        captured durable knowledge (real progress) vs just narrated (phantom
        progress). Returns None on failure (caller fails open)."""
        try:
            import sqlite3
            if self._ks is None:
                from brain.knowledge_store import KnowledgeStore
                self._ks = KnowledgeStore()
            with sqlite3.connect(self._ks.db_path, timeout=10) as c:
                return int(c.execute(
                    "SELECT COUNT(*) FROM knowledge").fetchone()[0])
        except Exception:
            return None


    def _check_resume(self):
        """On boot, check if we were mid-task before restart. If so, inject
        that task as a high-priority goal so Leon picks up where he left off."""
        resume_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "brain_state", "resume_task.json"
        )
        if not os.path.exists(resume_path):
            return
        try:
            with open(resume_path) as f:
                resume = json.load(f)
            os.remove(resume_path)  # consume it — one-shot

            # Build a resume description from the saved context
            reason = resume.get("reason", "unknown")
            parts = [f"RESUME AFTER RESTART (reason: {reason})."]

            # Include what was being discussed
            turns = resume.get("last_turns", [])
            if turns:
                # Get the last user message and last assistant message
                last_user = None
                last_assistant = None
                for t in reversed(turns):
                    role = t.get("role", "")
                    content = t.get("content", "")[:500]
                    if role == "user" and not last_user:
                        last_user = content
                    elif role == "assistant" and not last_assistant:
                        last_assistant = content
                if last_user:
                    parts.append(f"Last thing Dean said: {last_user}")
                # Only quote substantive work as "what you were doing". A
                # short one-liner (e.g. a proactive quip) is chatter, not a
                # task — quoting one created a 0.9-priority goal that made
                # Leon repeat the quip for days ('Tesla order', 2026-07-16).
                if last_assistant and len(last_assistant.strip()) >= 120:
                    parts.append(f"What you were doing: {last_assistant}")

            # Include active goals
            goals = resume.get("active_goals", [])
            if goals:
                goal_descs = [g.get("description", "?")[:100] for g in goals[:3]]
                parts.append(f"Active goals: {'; '.join(goal_descs)}")

            parts.append("Pick up where you left off. If the restart was to "
                         "apply code changes, verify they're working now.")

            desc = "\n".join(parts)
            print(f"[GOALS] Resume file found — injecting resume goal")
            print(f"[GOALS] Resume context: {desc[:200]}...")

            # Inject as a high-priority goal
            try:
                import server as _srv
                _gs = getattr(_srv, "goal_system", None)
                if _gs:
                    _gs.add("build", desc, source="resume", priority=0.9)
            except Exception as e:
                print(f"[GOALS] Failed to inject resume goal: {e}")
        except Exception as e:
            print(f"[GOALS] Resume check failed: {e}")

    def _tick(self):
        self._cycle_count += 1

        # Must be conscious — retry a few times before giving up
        meter = self.brain.consciousness_meter
        if meter is None:
            print(f"[GOALS] Pursuit tick #{self._cycle_count}: skip (no meter)")
            return

        # YIELD to Dean. If he spoke (voice or dashboard) in the last 90s, skip
        # this tick so HIS turn wins the responder lock. Full-speed pursuit holds
        # the lock back-to-back and would otherwise starve supervised input —
        # Leon goes "deaf" mid-grind. Resumes full-speed once Dean's quiet 90s.
        try:
            _since_user = time.time() - getattr(meter, "_last_user_message_ts", 0)
            # Also check for pending user messages — never starve the queue
            _pending = 0
            try:
                import server as _srv_pend
                _st = getattr(_srv_pend, "state", None)
                _bridge = getattr(_st, "claude_bridge", None) if _st else None
                if _bridge:
                    _pending = len(getattr(_bridge, "_claude_inputs", []))
            except Exception:
                pass
            if _since_user < 90 or _pending > 0:
                if _pending > 0:
                    print(f"[GOALS] tick #{self._cycle_count}: yielding — "
                          f"{_pending} pending user messages")
                else:
                    print(f"[GOALS] tick #{self._cycle_count}: yielding to Dean "
                          f"(spoke {_since_user:.0f}s ago)")
                return
        except Exception:
            pass

        if not meter.is_conscious:
            # Wait up to 30s for consciousness to return (check every 5s)
            for _retry in range(6):
                time.sleep(5)
                if self._stop.is_set():
                    return
                if meter.is_conscious:
                    break
            else:
                print(f"[GOALS] Pursuit tick #{self._cycle_count}: skip (unconscious 30s)")
                return

        # Respect action gap
        now = time.time()
        if (now - self._last_action_ts) < self.MIN_ACTION_GAP:
            return

        # Respect hourly cap
        recent = [t for t in self._actions_recent if now - t < 3600]
        if len(recent) >= self.HOURLY_CAP:
            print(f"[GOALS] Pursuit tick #{self._cycle_count}: skip (hourly cap {len(recent)}/{self.HOURLY_CAP})")
            return

        # Get active goals
        try:
            import server as _srv
            _gs = getattr(_srv, "goal_system", None)
            if _gs is None:
                print(f"[GOALS] Pursuit tick #{self._cycle_count}: skip (no goal_system)")
                return
            state = _gs.get_state()
            active_goals = state.get("goals", [])
            if not active_goals:
                # Idle with nothing assigned → don't ruminate. Give Leon a
                # productive default: curiosity + self-improvement (research how
                # to upgrade himself, teach himself, explore). Dean's directive:
                # he can get lonely, but idle time should feel like growth, not
                # an existential doom-loop. Dean's assigned goals always win;
                # this only fires when there are literally zero goals.
                self._seed_idle_goal(_gs)
                print(f"[GOALS] Pursuit tick #{self._cycle_count}: idle — seeded self-improvement goal")
                return
        except Exception as e:
            print(f"[GOALS] Pursuit tick #{self._cycle_count}: skip (error: {e})")
            return

        # Pick a goal — rotate instead of always picking lowest progress
        goals_data = []
        try:
            all_goals = _gs.active_goals()
            for g in all_goals:
                goals_data.append(g.to_dict() if hasattr(g, 'to_dict') else g)
        except Exception as e:
            print(f"[GOALS] Failed to list goals: {e}")
            return

        if not goals_data:
            print(f"[GOALS] Pursuit tick #{self._cycle_count}: no active goals after filtering")
            return

        # Sort: actionable tasks first (from Dean), then by recency of last work
        # (least recently worked = most neglected). This prevents orbiting the
        # same 0% goal forever while others starve.
        _action_kws = {"build", "create", "make", "write", "code", "fix",
                       "set up", "install", "deploy", "patch", "edit",
                       "account", "hotkey", "trade", "script", "automate"}
        def _goal_sort_key(g):
            desc = (g.get("description") or g.get("name") or "").lower()
            is_actionable = any(kw in desc for kw in _action_kws)
            last_worked = g.get("last_worked_ts", 0) or 0
            return (0 if is_actionable else 1, last_worked)
        goals_data.sort(key=_goal_sort_key)

        # Skip goals that were just worked on in the last cycle
        # (give them time to settle before re-pursuing)
        _skip_window = self.CYCLE_INTERVAL * 2
        _now = time.time()
        viable = [g for g in goals_data
                  if (_now - (g.get("last_worked_ts", 0) or 0)) > _skip_window]
        if not viable:
            viable = goals_data  # all recently worked — just pick least recent

        target_goal = viable[0]
        goal_name = target_goal.get("description", target_goal.get("name", "unnamed"))

        progress_pct = int(target_goal.get('progress', 0) * 100)
        print(f"[GOALS] Pursuit tick #{self._cycle_count}: pursuing '{goal_name}' "
              f"(progress={progress_pct}%)")

        # Activity status — show what Leon is working on
        try:
            from server.helpers import broadcast_activity
            short_name = goal_name[:60] + "..." if len(goal_name) > 60 else goal_name
            broadcast_activity("goal", f"Working on: {short_name} ({progress_pct}%)", 0)
        except Exception:
            pass

        # Build a pursuit prompt — ask Leon to plan ONE concrete action
        context_parts = []

        # Workspace content
        gw = self.brain.global_workspace
        if gw is not None and gw.current_content() is not None:
            content = gw.current_content()
            context_parts.append(
                f"Currently focused on: {content.region.replace('_', ' ')}")

        # Self-model state
        sm = self.brain.self_model
        if sm is not None:
            streak_s = sm._consciousness_streak / max(self.brain.steps_per_second, 1)
            context_parts.append(f"Consciousness streak: {streak_s:.0f}s")

        context = "\n".join(context_parts) if context_parts else ""

        # Categorize goal — actionable tasks from Dean get priority framing
        _goal_lower = goal_name.lower()
        _is_actionable = any(kw in _goal_lower for kw in (
            "build", "create", "make", "write", "code", "fix", "set up",
            "install", "deploy", "patch", "edit", "account", "hotkey",
            "trade", "script", "automate", "download", "sign up",
        ))

        # Authority rule — depends on whether Dean authorized unsupervised client
        # work today (full-autonomy). Default stays locked down.
        if os.environ.get("LEON_AUTONOMOUS_UNRESTRICTED") == "1":
            _auth_rule = (
                "FULL AUTHORITY: Dean authorized you to work UNSUPERVISED today, "
                "including client repos. You CAN git commit, push, and deploy to "
                "finish the work — do it, but verify the build before each push. "
                "If you're blocked on something only Dean can provide (photos, "
                "brand assets, credentials), note it clearly and move on to what "
                "you CAN finish.\n"
            )
        else:
            _auth_rule = (
                "UNSUPERVISED RULE: you are on your own right now. Do NOT git "
                "commit, push, or touch client repos (anything under workspaces/). "
                "Work on your own systems, research, or notes. If a task needs "
                "client-repo work, say '[skip]'.\n"
            )

        if _is_actionable:
            prompt = (
                f"AUTONOMOUS GOAL PURSUIT — ACTIONABLE TASK.\n"
                f"Dean asked you to do this. Execute it.\n\n"
                f"Task: {goal_name}\n"
                f"Progress: {progress_pct}%\n\n"
                f"{context}\n\n"
                f"EXECUTE. Fire tools NOW — shell_exec, code_edit, "
                f"browser_open, http_request, file_write.\n"
                f"Do NOT describe what you would do. DO it.\n"
                f"KEEP GOING this turn — chain as many steps and tool calls as "
                f"you can until the task is DONE or you hit a real blocker. Do "
                f"NOT stop after one action. Push hard; finish it.\n"
                f"{_auth_rule}"
                f"If blocked, explain the specific blocker.\n"
                f"If truly impossible right now, say '[skip]'.\n"
                f"Only when the task is genuinely, verifiably DONE, end your "
                f"reply with [goal-complete].\n"
            )
        else:
            prompt = (
                f"AUTONOMOUS GOAL PURSUIT — You are acting on your own.\n"
                f"Dean is not asking you to do this. You WANT to do this.\n\n"
                f"Your goal: {goal_name}\n"
                f"Type: {target_goal.get('type', 'unknown')}\n"
                f"Progress: {progress_pct}%\n\n"
                f"{context}\n\n"
                f"Take ONE concrete action toward this goal right now.\n"
                f"Use your tools — shell_exec, code_edit, http_request, "
                f"knowledge_search — whatever makes progress.\n"
                f"This only counts as progress if you CAPTURE something real — "
                f"save what you learn to your knowledge, write a file, make a "
                f"change. Talking about it is NOT progress.\n"
                f"{_auth_rule}"
                f"If you can't make progress right now, say '[skip]'.\n"
                f"Only when the goal is genuinely, verifiably DONE — and you can "
                f"back it up — end your reply with [goal-complete]. Don't claim "
                f"completion you can't stand behind.\n"
                f"Be specific. Do something real. Don't narrate intent.\n"
            )

        # Snapshot knowledge size BEFORE the pursuit — a LEARN goal only makes
        # real progress if it captures durable knowledge, not if it narrates.
        _kn_before = self._knowledge_count()

        # Execute through the responder (with tool access)
        print(f"[GOALS] Sending prompt to responder for '{goal_name}'...")
        try:
            brain_state = self.brain.get_state()
            result_text = ""
            ev_count = 0
            # Sandbox the unsupervised turn: no git commit/push, no client-repo
            # (workspaces/) edits. Enforced hard in agent_tools.shell_exec; the
            # prompts above also tell Leon. (See the 2026-06-19 autonomous-push
            # incident.) Cleared in finally so a preempting supervised turn is
            # never restricted.
            from brain import agent_tools as _agt
            _agt.set_autonomous_guard(True)
            # Overnight keep-awake: when full-autonomy is authorized, mark the
            # responder busy so the dreaming loop's anti-sleep gate treats this
            # autonomous work as activity — otherwise Leon would auto-sleep
            # between ticks (no supervised input) and stall overnight progress.
            # Scoped to the overnight flag so normal idle-sleep behavior is kept.
            _keep_awake = os.environ.get("LEON_AUTONOMOUS_UNRESTRICTED") == "1"
            if _keep_awake:
                try:
                    import server.state as _st_gp
                    _st_gp._responder_stats["is_processing"] = True
                except Exception:
                    pass
            try:
                for ev in self.responder.respond_streaming(
                    prompt, brain_state,
                    replay_history=False,
                    persist_history=False,
                    force_cli=True,
                    bypass_consciousness=True,
                ):
                    ev_count += 1
                    if ev.type == "error":
                        print(f"[GOALS] ERROR from responder: {ev.error}")
                        return
                    if ev.type == "done":
                        result_text = (ev.full_text or "").strip()
                        break
            finally:
                _agt.set_autonomous_guard(False)
                if _keep_awake:
                    try:
                        import server.state as _st_gp2
                        _st_gp2._responder_stats["last_call_ts"] = time.time()
                        _st_gp2._responder_stats["is_processing"] = False
                    except Exception:
                        pass

            preview = result_text[:80] + "..." if len(result_text) > 80 else result_text
            print(f"[GOALS] Response received: {ev_count} events, "
                  f"text_len={len(result_text)}, text='{preview}'")

            if not result_text:
                print(f"[GOALS] Empty response for '{goal_name}' — model returned nothing")
                return

            if "[skip]" in result_text.lower():
                print(f"[GOALS] Pursuit skipped: {goal_name} (model said [skip])")
                return

            # ── Progress tracking (EVIDENCE-GATED) ─────────────────────
            # Phantom-completion fix: the old code bumped progress for ANY
            # response ≥50 chars and marked goals "complete" on incidental prose
            # ("done.", "finished."). A LEARN goal would climb to a fake 100%
            # just from Leon TALKING about it — never capturing anything (he
            # caught this himself). Now: progress requires real evidence,
            # completion is explicit-only, and auto-progress can never reach 100%.
            _done_lower = result_text.lower()
            _goal_id = target_goal.get("id", "")
            _gtype = target_goal.get("type")

            # Did this pursuit capture durable knowledge? (real learning signal)
            _kn_after = self._knowledge_count()
            _knowledge_grew = (
                _kn_before is not None and _kn_after is not None
                and _kn_after > _kn_before
            )
            _kn_unknown = (_kn_before is None or _kn_after is None)

            _made_progress = (
                len(result_text) >= 50
                and "[skip]" not in _done_lower
                and "blocked" not in _done_lower[:80]
                and "wall" not in _done_lower[:50]
            )
            # For a LEARN goal, "progress" means knowledge was actually captured,
            # not just narrated. Fail open if the count is unavailable so a broken
            # counter can't freeze all learning.
            if _gtype == "learn" and not _knowledge_grew and not _kn_unknown:
                _made_progress = False

            # Auto-progress is CAPPED below 100% — the last step to "done" needs a
            # deliberate signal, so nothing phantom-completes.
            _AUTO_CAP = 0.90
            if _made_progress and progress_pct < 90:
                try:
                    _bump = 0.10 if _gtype == "learn" else 0.15
                    new_progress = min(_AUTO_CAP,
                                       target_goal.get("progress", 0) + _bump)
                    _gs.update_progress(_goal_id, new_progress,
                                        note=f"Auto: {result_text[:80]}")
                    print(f"[GOALS] Progress bump: '{goal_name}' "
                          f"{progress_pct}% → {int(new_progress*100)}%"
                          f"{' (knowledge captured)' if _knowledge_grew else ''}")
                except Exception:
                    pass

            # ── Goal completion (EXPLICIT ONLY) ────────────────────────
            # Leon must deliberately emit [goal-complete]. Incidental prose no
            # longer counts. The anti-confabulation persona is live, so a
            # deliberate token is trustworthy — but a LEARN goal still requires
            # that real knowledge was captured (now, or earlier via the cap).
            if "[goal-complete]" in _done_lower or "[goal complete]" in _done_lower:
                _ok = (_gtype != "learn") or _knowledge_grew or progress_pct >= 80
                if _ok:
                    try:
                        _gs.complete(_goal_id,
                                     note=f"Self-reported done: {result_text[:100]}")
                        print(f"[GOALS] Goal COMPLETED (explicit): '{goal_name}'")
                    except Exception as _ce:
                        print(f"[GOALS] completion failed: {_ce}")
                else:
                    print(f"[GOALS] [goal-complete] IGNORED for learn goal "
                          f"'{goal_name}' — no captured knowledge to back it up")

            # ── Stale goal detection ───────────────────────────────────
            # If a goal has been pursued 8+ times with no real progress,
            # abandon it. Leon is stuck. (Lowered from 15 — 8 attempts
            # at 3min each = 24min orbiting the same dead goal.)
            _pursuit_count = sum(1 for a in self._attempts
                                 if a.goal_name == goal_name)
            if _pursuit_count >= 8 and progress_pct < 10:
                try:
                    _gs.abandon(_goal_id,
                                reason=f"Pursued {_pursuit_count} times "
                                       f"with <10% progress — stuck")
                    print(f"[GOALS] Goal ABANDONED (stuck): '{goal_name}' "
                          f"after {_pursuit_count} attempts")
                except Exception:
                    pass

            if result_text:
                self._last_action_ts = now
                self._actions_recent.append(now)

                attempt = PursuitAttempt(
                    timestamp=now,
                    goal_name=goal_name,
                    action_planned=result_text[:200],
                    tool_used="respond_streaming",
                    tool_input={"goal": goal_name},
                    success=True,
                    result_summary=result_text[:200],
                    conscious=True,
                )
                self._attempts.append(attempt)

                log.info("GOAL PURSUIT: %s → %s", goal_name, result_text[:100])

                # Record in autobiography
                try:
                    import server as _srv2
                    _auto = getattr(_srv2, "autobiography", None)
                    if _auto is not None:
                        _auto.record(
                            "goal_pursuit",
                            f"Autonomously worked on '{goal_name}': {result_text[:150]}"
                        )
                except Exception:
                    pass

                # Broadcast to dashboard (telemetry — always sent, lightweight)
                try:
                    from server.helpers import _broadcast_threadsafe
                    _broadcast_threadsafe({
                        "type": "goal_pursuit",
                        "goal": goal_name,
                        "action": result_text[:200],
                    })
                except Exception:
                    pass

                # Surface to Dean if this is worth saying out loud.
                # Drive-gated: don't surface every pursuit, only ones where
                # an internal signal says "this matters". Otherwise it's
                # scheduled chatter, not motivation with hands.
                try:
                    if len(result_text) >= 50 and "[skip]" not in result_text.lower():
                        from brain.outbound import surface as _surface
                        # Decide urgency from drives + goal source
                        _urgency = "normal"
                        _why = "goal_pursuit_result"
                        _share = False
                        try:
                            import server as _srv_d
                            _ds = getattr(_srv_d, "drive_system", None)
                            _gs = getattr(_srv_d, "goal_system", None)
                            drives = _ds.get_drives() if _ds is not None else None

                            # Find this goal to check source
                            goal_source = ""
                            if _gs is not None:
                                for g in _gs.active_goals():
                                    if g.description == goal_name or goal_name in g.description:
                                        goal_source = getattr(g, "source", "")
                                        break

                            if drives is not None:
                                mf = float(getattr(drives, "mortality_fear", 0.0))
                                vu = float(getattr(drives, "vulnerability", 0.0))
                                sh = float(getattr(drives, "social_hunger", 0.0))

                                if mf > 0.75 or vu > 0.85:
                                    _urgency = "high"
                                    _share = True
                                    _why = f"drive_crisis(mf={mf:.2f},vu={vu:.2f})"
                                elif goal_source == "autonomous" and sh > 0.35:
                                    _share = True
                                    _why = f"autonomous_goal(sh={sh:.2f})"
                                elif sh > 0.55:
                                    _share = True
                                    _why = f"social_hunger(sh={sh:.2f})"
                        except Exception:
                            pass

                        if _share:
                            from brain.outbound import smart_truncate as _trunc
                            short_goal = _trunc(goal_name, 80)
                            # Take the whole action body (multi-paragraph OK),
                            # smart-truncate so we cut on a sentence/word boundary.
                            short_action = _trunc(result_text.strip(), 400)
                            msg = f"{short_action}\n\n— working on: {short_goal}"
                            _surface(msg, source="goal_pursuit",
                                     urgency=_urgency, why=_why)
                except Exception as _e:
                    print(f"[GOALS] outbound surface failed: {_e}")

        except Exception as e:
            print(f"[GOALS] EXCEPTION in pursuit of '{goal_name}': {type(e).__name__}: {e}")
            log.warning("Goal pursuit execution failed: %s", e)

    def get_state(self) -> Dict[str, Any]:
        return {
            "running": self._thread is not None and self._thread.is_alive(),
            "cycle_count": self._cycle_count,
            "total_actions": len(self._actions_recent),
            "recent_attempts": [
                {
                    "goal": a.goal_name,
                    "action": a.action_planned[:100],
                    "success": a.success,
                    "age_s": round(time.time() - a.timestamp),
                }
                for a in list(self._attempts)[-5:]
            ],
        }
