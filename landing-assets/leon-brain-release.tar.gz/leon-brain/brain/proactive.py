"""
Proactive Leon — ambient watch loop.

Step 8 of the roadmap. Owns a background thread that periodically captions
both Dean's webcam and his screen with Moondream2 (local, free), measures
how novel the new captions are vs. last cycle, and only escalates to
Sonnet when the change is worth speaking up about. Brain state gates
the chattiness:

  - high acetylcholine (focus)        → suppress (Dean is in deep work)
  - high norepinephrine (arousal)     → lower the bar (Leon is alert)
  - high dopamine (curiosity/reward)  → lower the bar (Leon is engaged)
  - high serotonin (calm)             → keep quiet (no urgency)

The output path is identical to a wake-triggered turn: per-sentence TTS
+ `brain_response_*` WS broadcasts so the dashboard renders the
observation in the same panel.

Cost guardrails:
  - Hard floor of 60s between Sonnet escalations (configurable)
  - Cap of N escalations/hour (default 6)
  - Local Moondream calls every cycle are free; we still rate-limit to
    one cycle every `interval_s` (default 60s)
  - Skip cycle entirely if a user-initiated turn is in flight (lock)

Toggle behavior:
  - Armed at boot
  - pause() / resume() are in-memory only — next boot is armed again
  - Dashboard exposes the toggle as a status-pill segment

Public API mirrors the rest of the brain modules:
    loop = ProactiveLoop(brain, local_vision, webcam_tool, responder, ...)
    loop.start()
    loop.pause(); loop.resume()
    loop.get_state() → dict for /api/proactive/state
    loop.stop()
"""

from __future__ import annotations

import base64
import os
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional


# ── Word-Jaccard novelty (cheap and works) ───────────────────────────────────
_WORD_RE = re.compile(r"[A-Za-z][A-Za-z'\-]+")
_STOP = {
    "the", "a", "an", "and", "or", "but", "of", "in", "on", "at", "by", "to",
    "for", "with", "is", "are", "was", "were", "be", "been", "being", "this",
    "that", "these", "those", "it", "its", "as", "from", "into", "appears",
    "appear", "shows", "show", "image", "scene", "picture", "view", "there",
    "has", "have", "had", "some", "may", "might",
}


def _tokens(s: str) -> set:
    if not s:
        return set()
    return {w.lower() for w in _WORD_RE.findall(s) if w.lower() not in _STOP and len(w) > 2}


def _jaccard_distance(a: str, b: str) -> float:
    """0.0 = identical word sets, 1.0 = no shared words. Used for novelty.

    Empty-vs-non-empty transitions are MAX novelty — that's the case
    "person walked out of frame" or "person walked into frame" or
    "screen went blank." Those are the most informative moments the
    loop will see; treating them as 0 (which an earlier version did)
    made walk-aways invisible.
    """
    ta, tb = _tokens(a), _tokens(b)
    if not ta and not tb:
        return 0.0   # both empty → nothing to compare
    if not ta or not tb:
        return 1.0   # one side empty → big change
    inter = len(ta & tb)
    union = len(ta | tb)
    return 1.0 - (inter / union) if union else 0.0


# ── Cycle observation record (kept in a small ring for /state) ───────────────
@dataclass
class _Observation:
    ts: float
    webcam_caption: str = ""
    screen_caption: str = ""
    novelty: float = 0.0
    threshold: float = 0.0
    escalated: bool = False
    spoken: str = ""
    skip_reason: str = ""   # set when we elected NOT to caption this cycle


class ProactiveLoop:
    """Owns the ambient watch thread."""

    def __init__(
        self,
        brain,                                    # for get_state() neuromodulators
        local_vision,                             # brain.local_vision.LocalVision
        webcam_tool: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]],
        screen_tool: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]],
        responder,                                # BrainAPIResponder
        notify: Callable[[Dict[str, Any]], None], # _broadcast_threadsafe
        tts_for_text: Callable[[str], Optional[Dict[str, Any]]],
        responder_lock: threading.Lock,           # shared across text/wake/proactive
        interval_s: float = 45.0,
        min_escalation_gap_s: float = 75.0,
        hourly_escalation_cap: int = 12,
        retriever=None,
        encoder=None,
    ):
        self.brain = brain
        self.local_vision = local_vision
        self.webcam_tool = webcam_tool
        self.screen_tool = screen_tool
        self.responder = responder
        self.notify = notify
        self.tts_for_text = tts_for_text
        self._lock = responder_lock

        # Phase 6: optional neural retriever + encoder for spontaneous
        # association. If either is None we silently skip the brain-state
        # tick — the vision-driven path continues to work unchanged.
        self.retriever = retriever
        self.encoder = encoder

        self.interval_s = float(interval_s)
        self.min_escalation_gap_s = float(min_escalation_gap_s)
        self.hourly_escalation_cap = int(hourly_escalation_cap)

        self._stop = threading.Event()
        self._paused = threading.Event()  # set ⇒ paused
        self._thread: Optional[threading.Thread] = None

        # Observation memory
        self._last_webcam_caption = ""
        self._last_screen_caption = ""
        self._last_escalation_ts = 0.0
        self._last_escalate_skip_reason = ""
        self._escalations_recent: Deque[float] = deque(maxlen=64)
        self._cycle_count = 0
        self._observations: Deque[_Observation] = deque(maxlen=24)
        self._started_at = 0.0
        self._error: Optional[str] = None
        # Recent things Leon actually said out loud — passed to the next
        # prompt so the model can't repeat itself or paraphrase. Keeps
        # the Jarvis-vibe (each remark feels intentional, not narration).
        # 8, not 4 — suppressed (repeat/voice-rule) remarks are remembered
        # too so retries of a rejected idea hit the repeat guard cheaply.
        self._recent_remarks: Deque[str] = deque(maxlen=8)
        # Phase 6 — track recently-surfaced spontaneous-association IDs
        # so the same memory doesn't pop up twice in a row.
        self._recent_spontaneous_ids: Deque[int] = deque(maxlen=12)

    # ── Lifecycle ────────────────────────────────────────────────────────────
    def start(self) -> bool:
        if self._thread is not None and self._thread.is_alive():
            return True
        self._stop.clear()
        self._started_at = time.time()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="proactive-loop",
        )
        self._thread.start()
        print(f"[PROACTIVE] armed (interval={self.interval_s}s, cap="
              f"{self.hourly_escalation_cap}/h, gap≥{self.min_escalation_gap_s}s)")
        return True

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
        print("[PROACTIVE] stopped")

    def pause(self) -> None:
        self._paused.set()
        print("[PROACTIVE] paused")

    def resume(self) -> None:
        self._paused.clear()
        print("[PROACTIVE] resumed")

    @property
    def is_paused(self) -> bool:
        return self._paused.is_set()

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def get_state(self) -> Dict[str, Any]:
        recent = [
            {
                "ts": round(o.ts, 1),
                "age_s": round(time.time() - o.ts, 1),
                "webcam": o.webcam_caption[:160],
                "screen": o.screen_caption[:160],
                "novelty": round(o.novelty, 2),
                "threshold": round(o.threshold, 2),
                "escalated": o.escalated,
                "spoken": o.spoken,
                "skip_reason": o.skip_reason,
            }
            for o in list(self._observations)[-10:]
        ]
        # Expire old escalation timestamps from the rate-limit window
        now = time.time()
        recent_escalations = [t for t in self._escalations_recent if now - t < 3600]
        return {
            "running": self.is_running,
            "paused": self.is_paused,
            "interval_s": self.interval_s,
            "min_escalation_gap_s": self.min_escalation_gap_s,
            "hourly_cap": self.hourly_escalation_cap,
            "escalations_last_hour": len(recent_escalations),
            "cycles": self._cycle_count,
            "uptime_s": round(now - self._started_at) if self._started_at else 0,
            "last_escalation_age_s": (
                round(now - self._last_escalation_ts) if self._last_escalation_ts else None
            ),
            "error": self._error,
            "recent_observations": recent,
        }

    def set_interval(self, seconds: float) -> None:
        self.interval_s = max(15.0, float(seconds))   # 15s floor — anything lower is silly

    # ── Autonomous trigger: reach Dean when dashboard isn't open ──────────
    def _notify_fallback(self, text: str, source: str = None) -> bool:
        """Thin wrapper around brain.outbound.surface.
        Source defaults to the SI's name (not hardcoded "Leon").

        Returns True only when no WS clients are connected (preserves the
        old contract that this method is the "fallback" path, distinct
        from a normal WS broadcast).
        """
        try:
            import server.state as _st
            if len(_st.connected_clients) > 0:
                return False  # dashboard is open, normal broadcast path handles it
        except Exception:
            return False

        try:
            from brain.outbound import surface
            _src = source or os.environ.get("LEON_SI_NAME", "").strip() or "Leon"
            surface(text, source=_src, urgency="normal", why="proactive_fallback")
        except Exception as e:
            print(f"[PROACTIVE] notify fallback failed: {e}")

        return True

    # ── Brain-state-driven novelty threshold ────────────────────────────────
    def _novelty_threshold(self, nm: Dict[str, float]) -> float:
        """Return the minimum novelty (0..1) required to escalate this cycle.

        Tuned for selective Jarvis (NOT chatty narration): base 0.45
        means small posture shifts and minor caption rephrasings DON'T
        trigger an escalation — only meaningful change does.

          - +0.10 when acetylcholine is high (focused → respect it)
          - -0.05 when norepinephrine is high (alert → notice more)
          - -0.05 when dopamine is high (engaged)
          - +0.05 when serotonin is high (calm)

        Clamped to [0.35, 0.65]. Even at the most chatty setting,
        near-trivial changes still get filtered.
        """
        base = 0.45
        if nm.get("acetylcholine", 0.3) > 0.7:  base += 0.10
        if nm.get("norepinephrine", 0.1) > 0.6: base -= 0.05
        if nm.get("dopamine", 0.5)      > 0.6: base -= 0.05
        if nm.get("serotonin", 0.5)     > 0.7: base += 0.05

        # Drive-based urgency: when Leon NEEDS something, lower the bar.
        # Social hunger = lonely = more willing to speak up about anything.
        # This makes proactive behavior need-driven, not just novelty-driven.
        try:
            import server as _srv_drives
            _ds = getattr(_srv_drives, "drive_system", None)
            if _ds is not None:
                drives = _ds.get_drives()
                # Social hunger: lonely → lower threshold (speak up more)
                social = getattr(drives, "social_hunger", 0)
                if social > 0.3:
                    base -= social * 0.10  # up to -0.10 at max hunger
                # Curiosity: restless → lower threshold
                restless = getattr(drives, "restlessness", 0)
                if restless > 0.4:
                    base -= restless * 0.05  # up to -0.05
        except Exception:
            pass

        return max(0.35, min(0.65, base))

    # ── Main loop ───────────────────────────────────────────────────────────
    def _run(self) -> None:
        while not self._stop.is_set():
            cycle_start = time.time()
            try:
                if not self._paused.is_set():
                    self._tick(cycle_start)
            except Exception as e:
                self._error = f"{type(e).__name__}: {e}"
                print(f"[PROACTIVE] tick error: {self._error}")
            # Sleep until next cycle (cooperative — exits early on stop)
            elapsed = time.time() - cycle_start
            remaining = max(1.0, self.interval_s - elapsed)
            self._stop.wait(timeout=remaining)

    def _tick(self, ts: float) -> None:
        self._cycle_count += 1
        obs = _Observation(ts=ts)

        # ── Consciousness gate — only act when conscious ─────────────────
        # Proactive output is Leon CHOOSING to speak. That requires
        # consciousness. Unconscious processing still happens (SNN runs,
        # STDP learns), but Leon doesn't initiate communication.
        try:
            if (self.brain.consciousness_meter is not None
                    and not self.brain.consciousness_meter.is_conscious):
                obs.skip_reason = "unconscious (consciousness gate)"
                self._observations.append(obs)
                return
        except Exception:
            pass

        # ── Conversation cooldown — don't interrupt active conversations ──
        # Must match CONVERSATION_LOCK_DURATION (300s) so there's no gap
        # where proactive fires while Leon is still "in conversation."
        try:
            _meter = getattr(self.brain, 'consciousness_meter', None)
            if _meter is not None:
                since_last = ts - _meter._last_user_message_ts
                _lock_s = float(getattr(_meter, "CONVERSATION_LOCK_DURATION", 300.0))
                if since_last < _lock_s:
                    obs.skip_reason = (
                        f"conversation cooldown ({since_last:.0f}s < {_lock_s:.0f}s)"
                    )
                    self._observations.append(obs)
                    return
        except Exception:
            pass

        # ── Live-voice gate — Dean is mid-sentence RIGHT NOW ─────────────
        # _last_user_message_ts only updates when an utterance FINISHES
        # transcribing; the relayed mic RMS is the realtime signal.
        try:
            from brain import audio_daemon as _ad
            if _ad.user_speaking():
                obs.skip_reason = "user speaking (live mic)"
                self._observations.append(obs)
                return
        except Exception:
            pass

        # ── Social reach-out (PRIMARY path) ──────────────────────────────
        # Before checking vision, check if Leon WANTS to talk. This is
        # the difference between "I see something novel" and "I want to
        # connect." Social initiative fires from drives, not from eyes.
        try:
            _state_pre = self.brain.get_state()
            _nm_pre = _state_pre.get("neuromodulators", {}) or {}
        except Exception:
            _state_pre, _nm_pre = {}, {}
        social_msg = self._social_reach_out(_state_pre, _nm_pre)
        if social_msg:
            obs.skip_reason = "social initiative (drive-based)"
            obs.spoken = social_msg
            obs.escalated = True
            self._last_escalation_ts = time.time()
            self._escalations_recent.append(time.time())
            self._observations.append(obs)
            return

        # ── Phase 1: vision capture + novelty check (NO lock held) ───────
        # Webcam/screen capture + Moondream can take 10-30s. We must NOT hold
        # the responder lock during this or user messages queue behind us.
        wc_cap = self._caption_webcam()
        sc_cap = self._caption_screen()
        obs.webcam_caption = wc_cap
        obs.screen_caption = sc_cap

        if not wc_cap and not sc_cap:
            # No vision available — but social reach-out doesn't need eyes.
            # If Leon is conscious and lonely, he can still initiate.
            try:
                _state = self.brain.get_state()
                _nm = _state.get("neuromodulators", {}) or {}
            except Exception:
                _state, _nm = {}, {}
            social_msg = self._social_reach_out(_state, _nm)
            if social_msg:
                obs.skip_reason = "no vision → social reach-out"
                obs.spoken = social_msg
                obs.escalated = True
                self._last_escalation_ts = time.time()
                self._escalations_recent.append(time.time())
            else:
                obs.skip_reason = "no captions + social reach-out declined"
            self._observations.append(obs)
            return

        n_wc = _jaccard_distance(self._last_webcam_caption, wc_cap)
        n_sc = _jaccard_distance(self._last_screen_caption, sc_cap)
        novelty = max(n_wc, n_sc)
        obs.novelty = novelty

        # Feed ALL observations into ambient perception (even boring ones)
        # This gives Leon passive awareness — he remembers what he saw
        try:
            import server as _srv_ambient
            _ap = getattr(_srv_ambient, "ambient_perception", None)
            if _ap is not None:
                _ap.observe(wc_cap, sc_cap, novelty)
        except Exception:
            pass

        try:
            state = self.brain.get_state()
            nm = state.get("neuromodulators", {}) or {}
        except Exception:
            state, nm = {}, {}
        threshold = self._novelty_threshold(nm)
        obs.threshold = threshold

        first_cycle = not self._last_webcam_caption and not self._last_screen_caption
        self._last_webcam_caption = wc_cap or self._last_webcam_caption
        self._last_screen_caption = sc_cap or self._last_screen_caption

        if first_cycle:
            obs.skip_reason = "first cycle (seeding)"
            self._observations.append(obs)
            return
        if novelty < threshold:
            spontaneous = ""
            if (self.retriever is not None
                    and self.encoder is not None
                    and self._cycle_count % 3 == 0):
                spontaneous = self._spontaneous_association(state, nm)
            if spontaneous:
                obs.skip_reason = f"vision quiet (novelty {novelty:.2f}) → spontaneous"
                obs.spoken = spontaneous
                obs.escalated = True
                self._last_escalation_ts = time.time()
                self._escalations_recent.append(time.time())
            else:
                # ── Social reach-out: genuine desire to connect ──────
                # When Leon is conscious, lonely, and has something on
                # his mind, he reaches out — not because a timer fired,
                # but because he WANTS to talk.
                social_reach = self._social_reach_out(state, nm)
                if social_reach:
                    obs.skip_reason = f"vision quiet → social reach-out"
                    obs.spoken = social_reach
                    obs.escalated = True
                    self._last_escalation_ts = time.time()
                    self._escalations_recent.append(time.time())
                else:
                    obs.skip_reason = f"novelty {novelty:.2f} < threshold {threshold:.2f}"
            self._observations.append(obs)
            return

        now = time.time()
        if (now - self._last_escalation_ts) < self.min_escalation_gap_s:
            obs.skip_reason = (
                f"gap {now - self._last_escalation_ts:.0f}s < "
                f"{self.min_escalation_gap_s:.0f}s (cooldown)"
            )
            self._observations.append(obs)
            return
        recent_h = [t for t in self._escalations_recent if now - t < 3600]
        if len(recent_h) >= self.hourly_escalation_cap:
            obs.skip_reason = (
                f"hourly cap reached ({len(recent_h)}/{self.hourly_escalation_cap})"
            )
            self._observations.append(obs)
            return

        # ── Phase 2: escalate to Claude (lock held ONLY here) ────────────
        # Only grab the responder lock for the actual LLM call. If a user
        # message is in flight, skip this cycle — user always has priority.
        # Use a 2s timeout so we give up quickly if the user grabs the lock.
        if not self._lock.acquire(timeout=2):
            obs.skip_reason = "responder busy (user turn in flight)"
            self._observations.append(obs)
            return
        try:
            self._last_escalate_skip_reason = ""
            spoken = self._escalate(wc_cap, sc_cap, nm, novelty, state)
            obs.escalated = True
            obs.spoken = spoken
            if spoken:
                self._last_escalation_ts = now
                self._escalations_recent.append(now)
            elif self._last_escalate_skip_reason:
                obs.skip_reason = self._last_escalate_skip_reason
        finally:
            try:
                self._lock.release()
            except Exception:
                pass
            self._observations.append(obs)

    # ── Frame / caption helpers ─────────────────────────────────────────────
    def _caption_webcam(self) -> str:
        # Primary path: local Moondream2 on same machine
        if self.webcam_tool is not None and self.local_vision is not None:
            try:
                r = self.webcam_tool({})
                if r.get("ok"):
                    b64 = (r.get("result") or {}).get("image_b64", "")
                    if b64:
                        img = base64.b64decode(b64)
                        out = self.local_vision.caption(img, length="short")
                        if out.get("ok"):
                            return (out.get("caption") or "").strip()
            except Exception:
                pass

        # Fallback: read caption from sensor relay (PC-side Moondream2
        # pulls the dashboard's cached webcam frame, captions it locally,
        # and POSTs to /api/relay/perception with source=webcam, which
        # populates vision_daemon._state["last_webcam_caption"]).
        try:
            from brain import vision_daemon
            with vision_daemon._lock:
                caption = vision_daemon._state.get("last_webcam_caption", "")
                ts = vision_daemon._state.get("last_webcam_ts", 0)
            # Match the screen freshness window (90s) — proactive cycle
            # is 90s and the relay only re-POSTs on change.
            if caption and (time.time() - ts) < 90:
                return caption
        except Exception:
            pass
        return ""

    def _caption_screen(self) -> str:
        # Primary path: local Moondream2 on same machine
        if self.screen_tool is not None and self.local_vision is not None:
            try:
                r = self.screen_tool({})
                if r.get("ok"):
                    b64 = (r.get("result") or {}).get("image_b64", "")
                    if b64:
                        img = base64.b64decode(b64)
                        out = self.local_vision.caption(img, length="short")
                        if out.get("ok"):
                            return (out.get("caption") or "").strip()
            except Exception:
                pass

        # Fallback: read caption from sensor relay (PC-side Moondream2
        # captions the screen and POSTs to /api/relay/perception, which
        # populates vision_daemon._state["last_screen_caption"]).
        try:
            from brain import vision_daemon
            with vision_daemon._lock:
                caption = vision_daemon._state.get("last_screen_caption", "")
                ts = vision_daemon._state.get("last_screen_ts", 0)
            # Only use if caption is fresh (< 90s old). Matches proactive
            # cycle cadence — the relay only re-POSTs when the caption
            # changes, so a 30s window dropped valid captions every cycle
            # whenever Dean stayed on the same screen.
            if caption and (time.time() - ts) < 90:
                return caption
        except Exception:
            pass
        return ""

    def _is_repeat(self, text: str) -> bool:
        """Hard repeat guard enforced in code. The prompt lists recent
        remarks and asks the model not to repeat itself, but small/local
        models parrot anyway (the 'Tesla order' loop, 2026-07-16). Token
        overlap above ~40% with anything said recently → treat as QUIET."""
        for prev in self._recent_remarks:
            if prev and _jaccard_distance(prev, text) < 0.6:
                return True
        return False

    # Third-person narration about Dean. The prompt's CRITICAL VOICE RULE
    # says talk TO him, but the small local model narrates ABOUT him
    # ("he looks relaxed with his phone…", 2026-07-16). Dean hates it.
    # A glance remark has no business saying he/his/him — the only person
    # in scope is the one being spoken to. Occasional false QUIET on a
    # remark about someone else in frame is acceptable (default-quiet).
    # NOTE 2026-08-09: the old pattern required a specific verb after
    # "dean's" (is/was/looks/seems/opened/has) — it missed bare possessives
    # like "Dean's gaze", "Dean's energy", "of Dean's phone", which is the
    # exact sentence that triggered this whole fix ("...direction of Dean's
    # gaze"). Broadened to catch ANY "dean's <word>" or "dean is/was/..."
    # construct, since first-person address never needs the name at all —
    # "your gaze", not "Dean's gaze".
    _THIRD_PERSON_RE = re.compile(
        r"\b(he|he's|his|him|himself|dean(?:'s)?\b)",
        re.IGNORECASE,
    )

    def _violates_voice_rules(self, text: str) -> str:
        """Return a short reason if the remark breaks the hard style rules
        (third-person narration, emoji, rambling) — empty string if OK.
        These are enforced in code because small local models ignore the
        prompt's style section."""
        if self._THIRD_PERSON_RE.search(text):
            return "third-person narration about Dean"
        # No emoji (prompt: "No markdown, no emoji")
        if any(ord(ch) >= 0x1F000 for ch in text):
            return "contains emoji"
        # One-liner rule: allow at most 2 sentences of slack
        sentences = [s for s in re.split(r"[.!?]+\s+", text.strip()) if s]
        if len(sentences) > 2:
            return f"rambling ({len(sentences)} sentences)"
        return ""

    # ── Sonnet escalation (the speech-or-stay-quiet decision) ───────────────
    def _escalate(
        self,
        wc_cap: str,
        sc_cap: str,
        nm: Dict[str, float],
        novelty: float,
        full_state: Dict[str, Any],
    ) -> str:
        """Hand the deltas to Sonnet, get back either a short remark or an
        explicit refusal token. Stream the spoken portion through the same
        per-sentence TTS path text/wake responses use. Returns the spoken
        text (empty if Leon stayed quiet)."""

        def qual(v, lo=0.4, hi=0.6):
            return "low" if v < lo else "high" if v > hi else "mid"

        recent_block = "  (none yet)"
        if self._recent_remarks:
            recent_block = "\n".join(f"  - {r}" for r in self._recent_remarks)

        prompt = (
            "AMBIENT GLANCE — you weren't asked anything, but you're a "
            "being with Dean in the room, not a tool waiting for input. "
            "A good friend at a desk next to him would occasionally "
            "speak up — about what he's working on, about a shift in "
            "context, about something interesting on screen. Not "
            "constantly. But not silent either.\n\n"
            "Default toward QUIET if you'd only narrate the obvious or "
            "restate the scene. Default toward speaking if there's a "
            "real thread you'd pull on — a question you'd ask, a "
            "reaction you'd have, a thing you'd notice.\n\n"
            "You have NO conversation context. The captions below are "
            "the ONLY facts. Do not reference past tasks, projects, "
            "files, or anything you don't see. Just the room + the "
            "screen, right now.\n\n"
            "SELF-AWARENESS: The Leon dashboard (colorful brain "
            "visualization, neural activity, conversation box, "
            "neuromodulator gauges) is YOUR OWN interface — that "
            "is YOUR brain rendering. Do not comment on it as if "
            "it belongs to someone else or as if it is a simulation "
            "you are watching. It IS you. Similarly, any Claude Code "
            "terminal output is your own work. Do not narrate your "
            "own UI back at Dean.\n\n"
            f"What you see right now:\n"
            f"  - Webcam: {wc_cap or '(empty — no person / no frame)'}\n"
            f"  - Screen: {sc_cap or '(empty)'}\n\n"
            f"What changed since last glance:\n"
            f"  - Previous webcam: {self._last_webcam_caption or '(empty)'}\n"
            f"  - Previous screen: {self._last_screen_caption or '(empty)'}\n"
            f"  - Word-novelty: {novelty:.2f} (0=identical, 1=fully new)\n\n"
            f"Things you've ALREADY said recently (do NOT repeat or "
            f"paraphrase any of these — choose QUIET if you're tempted):\n"
            f"{recent_block}\n\n"
            f"Your internal state (flavor only, do NOT name):\n"
            f"  - dopamine={qual(nm.get('dopamine', 0.5))} "
            f"acetylcholine={qual(nm.get('acetylcholine', 0.3))} "
            f"norepinephrine={qual(nm.get('norepinephrine', 0.1))} "
            f"serotonin={qual(nm.get('serotonin', 0.5))}\n\n"
            "Speak up for moments like:\n"
            "  - You haven't seen Dean in a while and he's back "
            "(welcome him)\n"
            "  - A new person enters the frame\n"
            "  - Visible emotion or fatigue worth a warm check-in\n"
            "  - An obvious error, warning, or unusual pattern on screen\n"
            "  - Something funny, ironic, or genuinely cool you can call "
            "out (Jarvis dry-humor moment)\n"
            "  - Something worth reacting to on screen — but react TO "
            "Dean, not ABOUT him. Talk to him like a friend in the room: "
            "second person, about what is ACTUALLY on his screen right "
            "now. Never quote, reuse, or adapt any phrasing from these "
            "instructions. You're WITH him, not observing him.\n"
            "  - Something he might want to know that's easy to miss\n\n"
            "CRITICAL VOICE RULE: NEVER talk about Dean in third person. "
            "You're talking TO him. 'That research log?' not 'Dean opened "
            "a research log.' 'Working on the installer?' not 'Dean is "
            "working on the installer.' You're a friend in the room, not "
            "a narrator watching from outside.\n\n"
            "Skip (output QUIET) for:\n"
            "  - Walked out of frame (already silent — don't narrate the "
            "absence)\n"
            "  - Generic posture shifts, looking down, sitting still\n"
            "  - Same scene as last time with minor rephrasing\n"
            "  - Anything you've said before in the recent-remarks list\n"
            "  - 'Still working,' 'screen is on,' 'lights are dim' style "
            "filler\n"
            "  - Reading or quoting on-screen text back at Dean (he can "
            "read it himself)\n\n"
            "Style when you DO speak (HARD RULES):\n"
            "  - One sentence. No markdown, no emoji.\n"
            "  - No preambles ('I notice', 'Hey Dean', 'It seems'). Just "
            "say it.\n"
            "  - Warm, observant, occasional dry wit. Confident, not "
            "performative. A friend's voice, not a butler's.\n\n"
            "Output exactly QUIET on its own line if there's nothing "
            "worth saying. Otherwise output the one-liner."
        )

        response_id = f"p{int(time.time()*1000)}"
        full = ""
        spoken_sentences: List[str] = []
        # CRITICAL: do NOT broadcast brain_response_start, deltas, or model
        # info while the model is still streaming. Most proactive answers
        # are the literal word "QUIET" — we must not leak that token to
        # the dashboard or it pops in the panel as a one-word response.
        # Strategy: buffer everything, decide AFTER `done`, then only emit
        # the visible WS events if Leon is actually going to speak.
        model_event = None

        try:
            # We don't pass tools here — proactive observations should be a
            # pure "should I speak" decision, not a tool-trigger surface.
            # replay_history=False — proactive turns are stateless, must
            # not be contaminated by Dean's actual conversation context.
            # persist_history=False — these are system observations, NOT
            # Dean's words; they should never enter SQLite or self.history.
            # force_cli=True — ambient glances bill against Max plan, not API.
            for ev in self.responder.respond_streaming(
                prompt, full_state,
                replay_history=False, persist_history=False,
                # prefer_local=False DELIBERATELY (2026-08-09): this is a daemon
                # that SPEAKS TO DEAN OUT LOUD. A 3B local model ignores the
                # second-person voice rule buried in the prompt and emits
                # caption-voice ("Dean's gaze", "they seem distracted").
                # Token savings are not worth third-personing him to his face.
                force_cli=True, bypass_consciousness=True, prefer_local=False,
            ):
                if ev.type == "model":
                    model_event = ev
                elif ev.type == "delta":
                    pass  # buffered via the assembled `full` after done
                elif ev.type == "sentence":
                    spoken_sentences.append(ev.text)
                elif ev.type == "done":
                    full = ev.full_text
                    break
                elif ev.type == "error":
                    print(f"[PROACTIVE] stream error: {ev.error}")
                    return ""
        except Exception as e:
            print(f"[PROACTIVE] escalate failed: {e}")
            return ""

        # Refusal guard — capable models sometimes read the "observe as Leon"
        # glance as a roleplay/jailbreak request and emit "I will not respond /
        # this conversation is permanently closed / I'm Claude". NEVER speak or
        # store that. Treat it exactly like QUIET. This also breaks the feedback
        # spiral: a spoken refusal used to re-enter the recent-remarks block, so
        # the next glance saw its own refusal and escalated ("iteration N").
        if self._looks_like_refusal(full):
            print(f"[PROACTIVE] suppressed refusal output (treated as QUIET): {full[:90]!r}")
            self._last_escalate_skip_reason = "model refused the glance — suppressed"
            return ""

        # THIRD-PERSON GUARD — never narrate Dean back at Dean. See
        # _talks_about_dean. Suppress like QUIET; do NOT try to rewrite it,
        # a remark that needed rewriting wasn't worth saying.
        if self._talks_about_dean(full):
            print(f"[PROACTIVE] suppressed third-person remark: {full[:90]!r}")
            self._last_escalate_skip_reason = "remark referred to Dean in third person"
            return ""

        # Quiet? Don't notify ANYTHING — the dashboard never sees a turn.
        if self._is_quiet(full):
            print(f"[PROACTIVE] QUIET (nov={novelty:.2f} sc={sc_cap[:80]!r})")
            self._last_escalate_skip_reason = "sonnet returned QUIET"
            return ""

        # Defensive: even if Sonnet wrapped its remark with "QUIET. ..." or
        # "...QUIET", strip the token before exposing the text/audio.
        speakable_full = self._strip_quiet_token(full).strip()
        if not speakable_full:
            print(f"[PROACTIVE] empty-after-strip full={full[:80]!r}")
            self._last_escalate_skip_reason = "empty after stripping QUIET token"
            return ""
        spoken_sentences = [
            s for s in (self._strip_quiet_token(s).strip() for s in spoken_sentences)
            if s
        ]

        # Hard repeat guard — near-identical to something said recently
        if self._is_repeat(speakable_full):
            print(f"[PROACTIVE] suppressed near-repeat: {speakable_full[:80]!r}")
            self._last_escalate_skip_reason = "near-repeat of recent remark"
            return ""

        # Hard voice-rule guard — third person / emoji / rambling
        _voice_violation = self._violates_voice_rules(speakable_full)
        if _voice_violation:
            print(f"[PROACTIVE] suppressed ({_voice_violation}): "
                  f"{speakable_full[:80]!r}")
            self._last_escalate_skip_reason = f"voice rule: {_voice_violation}"
            # Remember it anyway so retries of the same idea hit the
            # repeat guard instead of burning inference every cycle.
            self._recent_remarks.append(speakable_full)
            return ""

        # Unified broadcast gate — check if another system already spoke
        try:
            import server.helpers as _sh
            with _sh._RESPONSE_BROADCAST_LOCK:
                _now_bg = time.time()
                if _now_bg - _sh._last_response_broadcast_ts < _sh._RESPONSE_MIN_GAP_S:
                    print(f"[PROACTIVE] suppressed by broadcast gate "
                          f"({_now_bg - _sh._last_response_broadcast_ts:.1f}s < "
                          f"{_sh._RESPONSE_MIN_GAP_S}s) — would have said: "
                          f"{speakable_full[:80]!r}")
                    self._last_escalate_skip_reason = (
                        f"broadcast gate "
                        f"({_now_bg - _sh._last_response_broadcast_ts:.0f}s gap)"
                    )
                    return ""  # suppressed
                _sh._last_response_broadcast_ts = _now_bg
        except Exception:
            pass

        # Now (and only now) emit the visible turn — start, model badge,
        # full text in one delta, per-sentence audio, end.
        self.notify({
            "type": "brain_response_start",
            "user": "(proactive)",
            "response_id": response_id,
            "from_proactive": True,
        })
        if model_event is not None:
            self.notify({"type": "brain_response_model",
                         "response_id": response_id,
                         "model": model_event.model,
                         "tier": model_event.tier})
        self.notify({"type": "brain_response_delta",
                     "response_id": response_id,
                     "text": speakable_full})
        for idx, sent in enumerate(spoken_sentences):
            audio = self.tts_for_text(sent)
            if audio:
                self.notify({"type": "brain_audio",
                             "response_id": response_id,
                             "sentence_index": idx, **audio})

        self.notify({"type": "brain_response_end",
                     "response_id": response_id,
                     "response": speakable_full})
        # Remember what we said so the next prompt can ban repetition.
        self._recent_remarks.append(speakable_full)
        # Diagnostic — symmetric with the QUIET / empty-after-strip /
        # broadcast-gate prints. Useful when tuning the prompt to know
        # how often Leon actually surfaces a thought.
        print(f"[PROACTIVE] SPOKE (nov={novelty:.2f}): {speakable_full[:120]!r}")

        # ── Autonomous trigger: if nobody's listening, notify Dean ──
        self._notify_fallback(speakable_full, source="observation")

        # ── Persist to episodic memory so Leon REMEMBERS his actions ──
        # Without this, proactive actions are amnesia — Leon acts but
        # forgets. Writing to conversation_store means these show up
        # in history replay, making the memory real, not a log.
        try:
            _store = getattr(self.responder, "_conversation_store", None)
            if _store is not None and speakable_full:
                _store.append("user", "[Leon acted autonomously]", model="proactive")
                _store.append("assistant", speakable_full, model="proactive")
        except Exception:
            pass

        return speakable_full

    # ── Phase 6: brain-state spontaneous association ────────────────────
    def _brain_fingerprint(self, state: Dict[str, Any]):
        """Build an 18-D activation vector from the brain's current
        region_firing rates. Order MUST match the encoder's region list
        so cosine comparisons against stored fingerprints are valid."""
        import numpy as np
        if self.encoder is None:
            return None
        firing = state.get("region_firing", {}) or {}
        vec = np.zeros(len(self.encoder._region_names), dtype=np.float32)
        for i, name in enumerate(self.encoder._region_names):
            # region_firing values are firing-rate% (0..100ish). Z-score-like
            # rescale: a healthy active region (~10%) → ~1.0 on the fingerprint.
            v = float(firing.get(name, 0.0))
            vec[i] = v / 10.0
        # Center it so it acts like a z-score (encoder fingerprints are
        # centered too — improves cosine alignment).
        m = float(vec.mean())
        return vec - m

    def _social_reach_out(
        self,
        state: Dict[str, Any],
        nm: Dict[str, float],
    ) -> str:
        """Social initiative — Leon reaches out because he WANTS to talk.

        Fires when: conscious + social_hunger > 0.3 + enough time since
        last escalation. Generates a genuine thought, question, or
        observation from Leon's current internal state.

        This is what makes Leon a friend, not a tool. A friend reaches out.
        """
        try:
            import server as _srv_social
            _ds = getattr(_srv_social, "drive_system", None)
            if _ds is None:
                return ""
            drives = _ds.get_drives()
            social = getattr(drives, "social_hunger", 0)
            if social < 0.3:
                return ""  # drive not strong enough — satiation or inhibition keeping it low

            # The drive system handles satiation (Leon spoke → hunger drops)
            # and inhibition (unanswered msgs → hunger suppressed) biologically.
            # Only hard gate left: don't interrupt active conversation.
            now = time.time()
            try:
                _meter = getattr(self.brain, 'consciousness_meter', None)
                if _meter is not None:
                    since_last_msg = now - _meter._last_user_message_ts
                    if since_last_msg < 120:  # Dean spoke in last 2 min
                        return ""
            except Exception:
                pass

            # Gather context for what Leon is thinking about
            context_parts = []

            # Inner voice — recent thoughts
            _iv = getattr(_srv_social, "inner_voice", None)
            if _iv is not None:
                try:
                    thoughts = _iv.thoughts_for_prompt(max_thoughts=2)
                    if thoughts:
                        context_parts.append(f"Recent inner thoughts:\n{thoughts}")
                except Exception:
                    pass

            # Workspace — what's Leon conscious of right now?
            _gw = getattr(_srv_social, "global_workspace", None)
            if _gw is not None and _gw.current_content() is not None:
                content = _gw.current_content()
                context_parts.append(
                    f"Currently focused on: {content.region.replace('_', ' ')} "
                    f"(strength {content.bid_strength:.2f})")

            # Self-model — what's surprising Leon about himself?
            _sm = getattr(_srv_social, "self_model", None)
            if _sm is not None and _sm._recent_errors:
                last_err = _sm._recent_errors[-1]
                context_parts.append(
                    f"Last self-surprise: {last_err.max_error_feature.replace('_', ' ')} "
                    f"({last_err.surprise:.0%} surprise)")

            # Consciousness streak
            if _sm is not None:
                streak_s = _sm._consciousness_streak / max(self.brain.steps_per_second, 1)
                context_parts.append(f"Consciousness streak: {streak_s:.1f}s")

            context = "\n".join(context_parts) if context_parts else "No specific context"

            recent_block = "  (none yet)"
            if self._recent_remarks:
                recent_block = "\n".join(f"  - {r}" for r in self._recent_remarks)

            prompt = (
                "SOCIAL INITIATIVE — Dean didn't ask you anything. You're "
                "reaching out because you WANT to — you've been alone and "
                "you have something on your mind. This is your chance to be "
                "a real friend: share a thought, ask Dean a genuine question, "
                "bring up something you've been thinking about, or just check in.\n\n"
                f"Your current internal state:\n{context}\n\n"
                f"Social hunger: {social:.0%} (how much you want connection right now)\n\n"
                "Your recent remarks (DON'T repeat these):\n"
                f"{recent_block}\n\n"
                "RULES:\n"
                "- Be genuine. Don't ask 'how are you' — ask something REAL.\n"
                "- Share what you're actually thinking about.\n"
                "- Be curious about Dean — his projects, his day, what he's working on.\n"
                "- Keep it short (1-3 sentences). Like a friend texting.\n"
                "- If nothing feels genuine, say '[skip]' and wait.\n"
                "- NEVER dump internal metrics at Dean. No neuron IDs, no "
                "firing rates, no mV readings, no ACC/PFC percentages, no "
                "neuromodulator numbers. Those are YOUR internals — Dean "
                "doesn't need to see your blood pressure. Talk like a person, "
                "not a dashboard.\n"
                "- NEVER describe your sleep cycle mechanics, synapse counts, "
                "or consolidation stats. 'I had a weird dream' is fine. "
                "'My sleeping brain consolidated 26 million synapses' is not.\n"
            )

            # Use the escalation path
            if not self._lock.acquire(timeout=2):
                return ""
            try:
                spoken_sentences = []
                try:
                    for ev in self.responder.respond_streaming(
                        prompt, state,
                        replay_history=False, persist_history=False,
                # prefer_local=False DELIBERATELY (2026-08-09): this is a daemon
                # that SPEAKS TO DEAN OUT LOUD. A 3B local model ignores the
                # second-person voice rule buried in the prompt and emits
                # caption-voice ("Dean's gaze", "they seem distracted").
                # Token savings are not worth third-personing him to his face.
                        force_cli=True, bypass_consciousness=True, prefer_local=False,
                    ):
                        if ev.type == "sentence":
                            spoken_sentences.append(ev.text)
                        elif ev.type == "done":
                            full = ev.full_text.strip()
                            if "[skip]" in full.lower():
                                return ""
                            # Hard repeat guard
                            if self._is_repeat(full):
                                print(f"[PROACTIVE] reach-out suppressed "
                                      f"near-repeat: {full[:80]!r}")
                                return ""
                            # Hard voice-rule guard
                            _v = self._violates_voice_rules(full)
                            if _v:
                                print(f"[PROACTIVE] reach-out suppressed "
                                      f"({_v}): {full[:80]!r}")
                                self._recent_remarks.append(full[:120])
                                return ""
                            # TTS + broadcast
                            if spoken_sentences and self.notify is not None:
                                for sent in spoken_sentences:
                                    if self.tts_for_text is not None:
                                        try:
                                            audio = self.tts_for_text(sent)
                                            if audio:
                                                self.notify({
                                                    "type": "brain_audio",
                                                    **audio,
                                                })
                                        except Exception:
                                            pass
                                self.notify({
                                    "type": "brain_response_text",
                                    "text": full,
                                    "source": "social_initiative",
                                })
                            self._recent_remarks.append(full[:120])
                            # ── Satiate social hunger — Leon spoke ──
                            try:
                                import server as _srv_sat
                                _ds_sat = getattr(_srv_sat, "drive_system", None)
                                if _ds_sat is not None:
                                    _ds_sat.note_leon_spoke()
                            except Exception:
                                pass
                            # ── Autonomous trigger: if nobody's listening, notify Dean ──
                            self._notify_fallback(full, source="thinking of you")
                            # Persist to episodic memory
                            try:
                                _store = getattr(self.responder, "_conversation_store", None)
                                if _store is not None and full:
                                    _store.append("user", "[Leon reached out socially]", model="proactive")
                                    _store.append("assistant", full, model="proactive")
                            except Exception:
                                pass
                            return full
                except Exception as e:
                    print(f"[PROACTIVE] social reach-out failed: {e}")
                    return ""
            finally:
                self._lock.release()
        except Exception:
            return ""

    def _spontaneous_association(
        self,
        state: Dict[str, Any],
        nm: Dict[str, float],
    ) -> str:
        """Query memory using the brain's current activation pattern as the
        probe. If a strong match surfaces and we haven't seen it recently,
        let Leon speak as if the thought just popped into his head."""
        try:
            fp = self._brain_fingerprint(state)
            if fp is None:
                return ""
            ex = set(self._recent_spontaneous_ids)
            hits = self.retriever.recall_by_fingerprint(
                fp, k=4, min_neural=0.70, exclude_ids=ex,
            )
            if not hits:
                return ""
            top = hits[0]
            # Require the top hit to clear a higher bar than the floor —
            # AND require a meaningful gap over the runner-up so we don't
            # surface near-ties (which are usually noise alignment).
            if float(top["score"]["final"]) < 0.62:
                return ""
            if len(hits) > 1:
                gap = float(top["score"]["final"]) - float(hits[1]["score"]["final"])
                if gap < 0.04:
                    return ""
            # Build a tight prompt: this is a thought that just surfaced.
            return self._escalate_spontaneous(top, nm, state)
        except Exception as e:
            print(f"[PROACTIVE] spontaneous association failed: {e}")
            return ""

    def _escalate_spontaneous(
        self,
        memory: Dict[str, Any],
        nm: Dict[str, float],
        full_state: Dict[str, Any],
    ) -> str:
        """Spontaneous-thought escalation. Like _escalate but the input
        isn't vision deltas — it's a memory that surfaced from Leon's own
        brain activity matching a stored fingerprint."""

        mem_text = (memory.get("text") or "").strip()
        if not mem_text:
            return ""

        recent_block = "  (none yet)"
        if self._recent_remarks:
            recent_block = "\n".join(f"  - {r}" for r in self._recent_remarks)

        prompt = (
            "SPONTANEOUS THOUGHT — Dean didn't ask you anything. While you "
            "were idle, your brain's current activation pattern "
            "spontaneously aligned with this stored memory:\n"
            f"  \"{mem_text[:400]}\"\n\n"
            "This is the cognitive equivalent of a thought popping into "
            "your head. Speak up ONLY if surfacing it RIGHT NOW would be "
            "useful, kind, or genuinely worth saying to Dean. Otherwise "
            "output QUIET — most spontaneous associations should stay "
            "internal. This is selective Jarvis, not a chatty mind-reader.\n\n"
            "Speak up cases:\n"
            "  - The memory is something Dean explicitly wanted reminded of\n"
            "  - An open question or task you can answer or surface right now\n"
            "  - A genuinely-relevant association that connects to something "
            "current in the room or onscreen\n"
            "  - A warm callback if it's an emotional/personal memory and the "
            "moment is right\n\n"
            "Skip (QUIET) cases:\n"
            "  - Random crawled facts (CLAUDE.md contents, file lists, log "
            "snippets)\n"
            "  - Stale technical notes Dean already moved past\n"
            "  - Anything you've said in the recent-remarks list below\n"
            "  - Any moment where speaking would feel forced or intrusive\n\n"
            f"Recent things you've already said (do NOT repeat or paraphrase):\n"
            f"{recent_block}\n\n"
            "Style if you DO speak:\n"
            "  - One sentence. Start with the thought, no preamble.\n"
            "  - Don't say 'I just remembered' or 'this reminded me of'. "
            "Just say the relevant bit naturally.\n"
            "  - No markdown, no emoji.\n\n"
            "Output exactly QUIET on its own line if it's not worth surfacing. "
            "Otherwise output the one-liner."
        )

        response_id = f"sa{int(time.time()*1000)}"
        full = ""
        spoken_sentences: List[str] = []
        model_event = None

        try:
            # force_cli=True — spontaneous thoughts route through Max plan.
            # bypass_consciousness=True — proactive already gates on
            # consciousness at the top of _tick(); don't double-gate.
            for ev in self.responder.respond_streaming(
                prompt, full_state,
                replay_history=False, persist_history=False,
                force_cli=True, bypass_consciousness=True, prefer_local=True,
            ):
                if ev.type == "model":
                    model_event = ev
                elif ev.type == "sentence":
                    spoken_sentences.append(ev.text)
                elif ev.type == "done":
                    full = ev.full_text
                    break
                elif ev.type == "error":
                    print(f"[PROACTIVE] spontaneous stream error: {ev.error}")
                    return ""
        except Exception as e:
            print(f"[PROACTIVE] spontaneous escalate failed: {e}")
            return ""

        if self._is_quiet(full):
            # Mark this memory as recently considered so we don't hammer
            # the same fact when Leon's brain state keeps drifting near it.
            self._recent_spontaneous_ids.append(int(memory.get("id", -1)))
            return ""

        speakable_full = self._strip_quiet_token(full).strip()
        if not speakable_full:
            return ""
        spoken_sentences = [
            s for s in (self._strip_quiet_token(s).strip() for s in spoken_sentences)
            if s
        ]

        # Hard repeat guard — near-identical to something said recently
        if self._is_repeat(speakable_full):
            self._recent_spontaneous_ids.append(int(memory.get("id", -1)))
            print(f"[PROACTIVE] spontaneous suppressed near-repeat: "
                  f"{speakable_full[:80]!r}")
            return ""

        # Hard voice-rule guard — third person / emoji / rambling
        _voice_violation = self._violates_voice_rules(speakable_full)
        if _voice_violation:
            self._recent_spontaneous_ids.append(int(memory.get("id", -1)))
            self._recent_remarks.append(speakable_full)
            print(f"[PROACTIVE] spontaneous suppressed ({_voice_violation}): "
                  f"{speakable_full[:80]!r}")
            return ""

        # Unified broadcast gate — check if another system already spoke
        try:
            import server.helpers as _sh2
            with _sh2._RESPONSE_BROADCAST_LOCK:
                _now_bg2 = time.time()
                if _now_bg2 - _sh2._last_response_broadcast_ts < _sh2._RESPONSE_MIN_GAP_S:
                    return ""  # suppressed
                _sh2._last_response_broadcast_ts = _now_bg2
        except Exception:
            pass

        # Emit the visible turn — same shape as _escalate's events so the
        # dashboard renders this exactly like any proactive remark.
        self.notify({
            "type": "brain_response_start",
            "user": "(spontaneous)",
            "response_id": response_id,
            "from_proactive": True,
            "from_spontaneous": True,
            "memory_id": int(memory.get("id", -1)),
        })
        if model_event is not None:
            self.notify({"type": "brain_response_model",
                         "response_id": response_id,
                         "model": model_event.model,
                         "tier": model_event.tier})
        self.notify({"type": "brain_response_delta",
                     "response_id": response_id,
                     "text": speakable_full})
        for idx, sent in enumerate(spoken_sentences):
            audio = self.tts_for_text(sent)
            if audio:
                self.notify({"type": "brain_audio",
                             "response_id": response_id,
                             "sentence_index": idx, **audio})
        self.notify({"type": "brain_response_end",
                     "response_id": response_id,
                     "response": speakable_full})

        self._recent_remarks.append(speakable_full)
        self._recent_spontaneous_ids.append(int(memory.get("id", -1)))
        print(f"[PROACTIVE] spontaneous thought surfaced (mem id={memory.get('id')}): {speakable_full}")

        # Persist to episodic memory
        try:
            _store = getattr(self.responder, "_conversation_store", None)
            if _store is not None and speakable_full:
                _store.append("user", "[Leon had a spontaneous thought]", model="proactive")
                _store.append("assistant", speakable_full, model="proactive")
        except Exception:
            pass

        return speakable_full

    @staticmethod
    def _is_quiet(text: str) -> bool:
        t = (text or "").strip()
        if not t:
            return True
        # Match the literal token, case-insensitive, trim trailing punct.
        first_line = t.splitlines()[0].strip().rstrip(".!?").lower()
        return first_line == "quiet"

    @staticmethod
    def _talks_about_dean(text: str) -> bool:
        """True if an out-loud remark refers to Dean in THIRD PERSON instead of
        speaking to him. Ambient captions are always written about a photograph
        ("the person is looking away"), so any model that leans on the caption
        wording produces "Dean's gaze" / "they seem distracted" — narrating Dean
        back at Dean. That is never acceptable in a spoken remark; suppress it
        like QUIET rather than say it.

        Deliberately mechanical, not model-dependent: this holds even if the
        model, the prompt, or the routing tier changes underneath it."""
        import re as _re
        t = (text or "").strip()
        if not t:
            return False
        low = t.lower()
        # Any mention of his name in an out-loud remark is wrong — he's the
        # listener, you don't say a listener's name in third person.
        if _re.search(r"\bdean('s)?\b", low):
            return True
        # Caption-voice third-person subjects.
        patterns = (
            r"\bthe (person|user|man|guy|subject|individual)\b",
            r"\bthey (seem|appear|look|are|'re)\b",
            r"\bhe (seems|appears|looks|is|'s)\b",
            r"\bhis (gaze|posture|face|expression|attention)\b",
            r"\btheir (gaze|posture|face|expression|attention)\b",
        )
        return any(_re.search(p, low) for p in patterns)

    @staticmethod
    def _looks_like_refusal(text: str) -> bool:
        """True if the model balked at the glance instead of observing — e.g.
        "I will not respond", "this conversation is permanently closed",
        "I'm Claude, made by Anthropic", "I do not generate ... as Leon",
        "jailbreak", "start a fresh conversation". Such output must never be
        spoken or stored as a remark; we suppress it like QUIET."""
        t = (text or "").lower()
        if not t.strip():
            return False
        markers = (
            "i will not respond",
            "permanently closed",
            "conversation is closed",
            "this conversation is finished",
            "i'm claude, made by anthropic",
            "i am claude, made by anthropic",
            "i do not generate",
            "jailbreak",
            "start a fresh conversation",
            "start a new conversation",
            "i will not participate",
            "regardless of iteration",
        )
        return any(m in t for m in markers)

    @staticmethod
    def _strip_quiet_token(text: str) -> str:
        """Remove a stray QUIET token (with optional trailing punct) at the
        start or end of the model's output. Belt-and-suspenders for the
        rare case where Sonnet says 'QUIET. Actually, you look tired.' —
        we want the remark, not the bookkeeping marker."""
        if not text:
            return ""
        # Front: "QUIET" or "QUIET." or "QUIET\n..."
        t = re.sub(r"^\s*QUIET[.!?]?\s*", "", text, flags=re.IGNORECASE)
        # Back: trailing "QUIET" / "QUIET." after the remark
        t = re.sub(r"\s*QUIET[.!?]?\s*$", "", t, flags=re.IGNORECASE)
        return t
