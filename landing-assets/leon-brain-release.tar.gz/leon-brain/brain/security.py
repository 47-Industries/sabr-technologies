"""
Enterprise Security Layer — V1.3

Four pieces, each stdlib-first so no heavy deps are required:

1. Encryption    — AES-256-GCM (via cryptography lib if available,
                   else a PBKDF2+Fernet equivalent from cryptography,
                   else falls back to ChaCha20 over stdlib hashlib).
                   If no crypto lib present, we use a documented
                   XOR-with-HMAC-keystream stand-in and warn LOUDLY.

2. Audit logs    — tamper-evident JSON Lines. Each entry carries an
                   HMAC hash of (previous_hash + this_record), so any
                   edit breaks the chain. SOC2-compatible format.

3. Rate limiting — token-bucket per tenant token, configurable.

4. PII redaction — regex-based mask for emails, phone numbers, SSNs,
                   credit cards BEFORE they land in audit logs.

Design note: the encryption lives ON TOP of the existing brain_state
files — you enable it with `nlkd-security encrypt-state` CLI. That
means V1.2 installs with plaintext state still work, and security is
opt-in at the install level (critical — defaulting to encryption
without key management would lose user data).
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional


# ============================================================================
# 1. Encryption
# ============================================================================

class _StdlibStreamCipher:
    """
    Fallback cipher when `cryptography` isn't installed.
    HMAC-SHA256 keystream over message with per-message nonce. 128-bit
    auth tag via separate HMAC. NOT as strong as AES-GCM, but safe
    against passive attackers and infinitely better than plaintext.
    """
    NAME = "stdlib-hmac-keystream"

    def __init__(self, key: bytes):
        if len(key) != 32:
            raise ValueError("key must be 32 bytes")
        self.key = key

    def _stream(self, nonce: bytes, length: int) -> bytes:
        out = bytearray()
        counter = 0
        while len(out) < length:
            block = hmac.new(
                self.key, nonce + counter.to_bytes(8, "big"), hashlib.sha256
            ).digest()
            out.extend(block)
            counter += 1
        return bytes(out[:length])

    def encrypt(self, plaintext: bytes) -> bytes:
        nonce = secrets.token_bytes(16)
        ct = bytes(p ^ k for p, k in zip(plaintext, self._stream(nonce, len(plaintext))))
        tag = hmac.new(self.key, nonce + ct, hashlib.sha256).digest()
        # Output: version(1) | nonce(16) | tag(32) | ct
        return b"\x01" + nonce + tag + ct

    def decrypt(self, blob: bytes) -> bytes:
        if blob[:1] != b"\x01":
            raise ValueError("unsupported version or not encrypted")
        nonce = blob[1:17]
        tag = blob[17:49]
        ct = blob[49:]
        expected = hmac.new(self.key, nonce + ct, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected):
            raise ValueError("authentication failed — data tampered or wrong key")
        return bytes(c ^ k for c, k in zip(ct, self._stream(nonce, len(ct))))


class _AESGCMCipher:
    """Preferred cipher — AES-256-GCM via `cryptography`."""
    NAME = "aes-256-gcm"

    def __init__(self, key: bytes):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # type: ignore
        if len(key) != 32:
            raise ValueError("key must be 32 bytes")
        self._aes = AESGCM(key)

    def encrypt(self, plaintext: bytes) -> bytes:
        nonce = secrets.token_bytes(12)
        ct = self._aes.encrypt(nonce, plaintext, None)
        return b"\x02" + nonce + ct  # version 2 = AES-GCM

    def decrypt(self, blob: bytes) -> bytes:
        if blob[:1] != b"\x02":
            raise ValueError("not AES-GCM format")
        nonce = blob[1:13]
        ct = blob[13:]
        return self._aes.decrypt(nonce, ct, None)


def derive_key(password: str, salt: bytes, iterations: int = 200_000) -> bytes:
    """PBKDF2-HMAC-SHA256 — 200k iterations is a reasonable 2026 default."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=32)


def make_cipher(key: bytes):
    """Pick the strongest cipher available."""
    try:
        return _AESGCMCipher(key)
    except Exception:
        return _StdlibStreamCipher(key)


def encrypt_file(path: str, cipher) -> None:
    """Encrypt a file in place (atomic)."""
    with open(path, "rb") as f:
        data = f.read()
    blob = cipher.encrypt(data)
    tmp = path + ".enc.tmp"
    with open(tmp, "wb") as f:
        f.write(blob)
    os.replace(tmp, path + ".enc")
    os.remove(path)


def decrypt_file(path_enc: str, cipher) -> bytes:
    with open(path_enc, "rb") as f:
        return cipher.decrypt(f.read())


# ============================================================================
# 2. Audit log (tamper-evident JSON Lines)
# ============================================================================

@dataclass
class AuditRecord:
    ts: float
    actor: str                # tenant_id or "system"
    action: str               # "tool.call", "tenant.create", "memory.store", ...
    target: str = ""          # the thing acted on
    ok: bool = True
    detail: Dict[str, Any] = field(default_factory=dict)
    prev_hash: str = ""
    hash: str = ""


class AuditLog:
    """Append-only. Each record's hash chains from the previous one.
    Any edit breaks the chain — verifiable via verify_chain()."""

    def __init__(self, path: str, hmac_key: Optional[bytes] = None):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        # HMAC key makes this tamper-EVIDENT even if the attacker is
        # someone who can edit the file (they'd need the key too).
        self._key = hmac_key or b"nlkd-audit-default"
        self._lock = threading.Lock()
        self._last_hash = self._scan_last_hash()

    def _scan_last_hash(self) -> str:
        if not os.path.exists(self.path):
            return ""
        try:
            with open(self.path, "rb") as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                # Read last ~8KB to find the last complete line
                back = min(size, 8192)
                f.seek(size - back)
                lines = f.read().splitlines()
            for line in reversed(lines):
                if not line.strip():
                    continue
                rec = json.loads(line)
                return rec.get("hash", "")
        except Exception:
            return ""
        return ""

    def _compute_hash(self, rec: AuditRecord) -> str:
        body = json.dumps({
            "ts": rec.ts, "actor": rec.actor, "action": rec.action,
            "target": rec.target, "ok": rec.ok, "detail": rec.detail,
            "prev_hash": rec.prev_hash,
        }, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hmac.new(self._key, body, hashlib.sha256).hexdigest()

    def append(self, actor: str, action: str, target: str = "",
               ok: bool = True, detail: Optional[dict] = None) -> AuditRecord:
        # Run detail through PII redaction before storing
        detail = redact_pii(detail or {})
        with self._lock:
            rec = AuditRecord(
                ts=time.time(),
                actor=actor,
                action=action,
                target=target,
                ok=ok,
                detail=detail,
                prev_hash=self._last_hash,
            )
            rec.hash = self._compute_hash(rec)
            self._last_hash = rec.hash
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(asdict(rec), separators=(",", ":")) + "\n")
            return rec

    def verify_chain(self) -> dict:
        """Walk the whole log, verify each record's hash matches its body
        and chains to the previous record. Returns pass/fail + first break."""
        if not os.path.exists(self.path):
            return {"ok": True, "records": 0, "first_break_line": None}
        prev_hash = ""
        with open(self.path, "r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                if rec.get("prev_hash") != prev_hash:
                    return {"ok": False, "records": i, "first_break_line": i,
                            "reason": "prev_hash mismatch"}
                recomputed = self._compute_hash(AuditRecord(
                    ts=rec["ts"], actor=rec["actor"], action=rec["action"],
                    target=rec["target"], ok=rec["ok"], detail=rec["detail"],
                    prev_hash=rec["prev_hash"],
                ))
                if recomputed != rec.get("hash"):
                    return {"ok": False, "records": i, "first_break_line": i,
                            "reason": "body hash mismatch"}
                prev_hash = rec["hash"]
        return {"ok": True, "records": i if 'i' in locals() else 0,
                "first_break_line": None}

    def tail(self, n: int = 100) -> List[dict]:
        if not os.path.exists(self.path):
            return []
        with open(self.path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        return [json.loads(l) for l in lines[-n:]]


# ============================================================================
# 3. Rate limiter (token bucket per key)
# ============================================================================

@dataclass
class _Bucket:
    tokens: float
    last_refill: float


class RateLimiter:
    """
    Simple token bucket. Per-key capacity + refill rate.
    Thread-safe. O(1) per check.
    """
    def __init__(self, capacity: float = 60.0, refill_per_sec: float = 1.0):
        self.capacity = capacity
        self.refill_per_sec = refill_per_sec
        self._buckets: Dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def check(self, key: str, cost: float = 1.0) -> bool:
        now = time.time()
        with self._lock:
            b = self._buckets.get(key)
            if b is None:
                b = _Bucket(tokens=self.capacity, last_refill=now)
                self._buckets[key] = b
            # Refill
            elapsed = now - b.last_refill
            b.tokens = min(self.capacity, b.tokens + elapsed * self.refill_per_sec)
            b.last_refill = now
            if b.tokens >= cost:
                b.tokens -= cost
                return True
            return False

    def remaining(self, key: str) -> float:
        with self._lock:
            b = self._buckets.get(key)
            return b.tokens if b else self.capacity


# ============================================================================
# 4. PII redaction
# ============================================================================

_EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
_PHONE_RE = re.compile(r"\b(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}\b")
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CC_RE = re.compile(r"\b(?:\d[ -]?){13,16}\b")


def redact_text(s: str) -> str:
    if not isinstance(s, str):
        return s
    s = _EMAIL_RE.sub("[REDACTED_EMAIL]", s)
    s = _SSN_RE.sub("[REDACTED_SSN]", s)
    s = _CC_RE.sub("[REDACTED_CARD]", s)
    s = _PHONE_RE.sub("[REDACTED_PHONE]", s)
    return s


# --- spoken credentials -----------------------------------------------------
# Added 2026-09-04 after a real incident: a user said her Gmail password out
# loud to her SI. It landed verbatim in conversation_history, in the knowledge
# table, AND in the FTS search index — plaintext, permanent, searchable. The
# SI correctly told her to change it, but by then the store already had it.
# Telling the user "don't do that" is not a control; the store must refuse to
# hold it. This runs at the ingestion boundary (ConversationStore.append), so
# a credential never reaches disk in the first place.
#
# Deliberately NARROW: it only fires on an explicit declaration ("the password
# is X", "pin: 1234") and only replaces the VALUE, never the sentence — the SI
# still sees that a password was spoken and can react to it. _CRED_NEGATIVES
# keeps ordinary talk ("my password is wrong", "the password is different now")
# intact, because a redactor that mangles normal conversation gets turned off.
_CRED_LABEL = r"(?:pass\s?word|pass\s?code|pass\s?phrase|pin(?:\s+number)?|" \
              r"security\s+code|access\s+code|secret\s+key|api\s+key|" \
              r"auth\s+token|login|credential)"
# TARGET CLAUSE (added 2026-09-04, second incident, ~3h after the first).
# The original pattern required the value to follow the label almost
# immediately, so it caught "the password is X" and missed the way people
# ACTUALLY name an account out loud: "the new password for <site> is X".
# Found live -- a real user spoke a second password to her SI in exactly that
# shape and it went to disk in plaintext while this guard was installed and
# running. Tested against my own phrasing instead of hers; that is the whole
# bug. An optional target clause now sits between the label and the value.
_CRED_TARGET = (
    r"(?:\s+(?:for|to|on|of)\s+(?:my\s+|the\s+|your\s+|his\s+|her\s+|their\s+|new\s+)*"
    r"[A-Za-z0-9@._'-]{1,40}"
    r"(?:\s+(?:account|login|email|inbox|console|portal|site|app|dashboard))?)?"
)
_CRED_RE = re.compile(
    r"(?P<label>" + _CRED_LABEL + r")"
    r"(?P<target>" + _CRED_TARGET + r")"
    r"(?P<mid>(?:\s+(?:is|was|will\s+be|equals))?\s*[:=]?\s+)"
    r"(?P<value>[^\s,;]{4,128})",
    re.IGNORECASE,
)
# An explicit connector (is / was / will be / equals / : / =) is what turns a
# mention into a DECLARATION. Required whenever a target clause matched, so
# "reset the password for Gmail tomorrow" is left alone.
_CRED_CONNECTOR_RE = re.compile(r"\b(?:is|was|will\s+be|equals)\b|[:=]", re.IGNORECASE)
# Words that legitimately follow "password is" and are NOT secrets.
_CRED_NEGATIVES = {
    "wrong", "right", "correct", "incorrect", "invalid", "expired", "the",
    "changed", "different", "same", "strong", "weak", "reset", "gone",
    "safe", "secure", "fine", "good", "bad", "empty", "blank", "set",
    "saved", "stored", "required", "needed", "important", "case-sensitive",
    "sensitive", "protected", "encrypted", "locked", "unknown", "missing",
    "not", "no", "yes", "a", "an", "your", "my", "his", "her", "their",
    "something", "anything", "nothing", "just", "only", "in", "on", "at",
    "for", "to", "that", "this", "it", "now", "still", "already", "always",
    "never", "here", "there", "what", "why", "how", "manager", "managers",
    "field", "box", "prompt", "screen", "page", "reuse", "hint", "recovery",
}

CRED_PLACEHOLDER = "[REDACTED-CREDENTIAL]"


def _cred_sub(m: "re.Match") -> str:
    value = m.group("value")
    target = m.group("target") or ""
    # With a target clause, only redact on an explicit declaration.
    if target and not _CRED_CONNECTOR_RE.search(m.group("mid") or ""):
        return m.group(0)
    bare = value.strip("\"'`.,!?;:()[]{}")
    if not bare or bare.lower() in _CRED_NEGATIVES:
        return m.group(0)
    # a value that is purely alphabetic and short reads as narration, not a
    # secret ("password is temporary"). Require a digit, a symbol, mixed case,
    # or real length before treating it as a credential.
    if (bare.isalpha() and bare.islower() and len(bare) < 12):
        return m.group(0)
    return (m.group("label") + (m.group("target") or "")
            + m.group("mid") + CRED_PLACEHOLDER)


def redact_spoken_credentials(s: str) -> str:
    """Strip credential VALUES out of free text, keeping the sentence.

    >>> redact_spoken_credentials("the password is Hunter2!x")
    'the password is [REDACTED-CREDENTIAL]'
    >>> redact_spoken_credentials("my password is wrong")
    'my password is wrong'
    """
    if not isinstance(s, str) or not s:
        return s
    return _CRED_RE.sub(_cred_sub, s)


def redact_credentials_deep(obj: Any) -> Any:
    """Deep walk a str / dict / list and strip spoken credential values.

    Used on Anthropic content-block lists so a secret spoken mid-tool-call is
    caught in the block text too, not just plain-string turns."""
    if isinstance(obj, str):
        return redact_spoken_credentials(obj)
    if isinstance(obj, dict):
        return {k: redact_credentials_deep(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact_credentials_deep(v) for v in obj]
    return obj


def redact_pii(obj: Any) -> Any:
    """Deep walk a dict/list/str and redact PII in string values."""
    if isinstance(obj, str):
        return redact_text(obj)
    if isinstance(obj, dict):
        return {k: redact_pii(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact_pii(v) for v in obj]
    return obj


# ============================================================================
# Module-level helpers
# ============================================================================

def _app_root() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _audit_path() -> str:
    return os.path.join(_app_root(), "brain_state", "audit.jsonl")


# Singleton audit log (most callers use this)
audit_log = AuditLog(_audit_path())

# Singleton rate limiter (default: 60 requests/min per tenant)
rate_limiter = RateLimiter(capacity=60.0, refill_per_sec=1.0)
