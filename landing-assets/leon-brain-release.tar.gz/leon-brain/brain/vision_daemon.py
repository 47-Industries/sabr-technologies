"""
vision_daemon.py — Continuous eyes for Leon.

Replaces episodic "blink" vision (trigger → capture → go dark) with a real
background loop that watches both the webcam and the screen on a short
interval, detects meaningful change, and routes observations into Leon's
awareness in near-real-time.

Design constraints:
  - Must NOT block the brain's main asyncio loop. Runs in its own daemon
    thread (same pattern as ScreenObserver).
  - Change detection runs CHEAP (pixel diff) BEFORE invoking Moondream.
    Target < 5ms for "nothing changed" frames.
  - NO OCR. Ever. Screen text is a credential leak path. We describe visually
    using Moondream only — what's on screen is treated as an image, not text.
  - Pixel arrays go directly into visual_cortex via brain.inject_sensory_input
    ('vision', ...). Do NOT route through text_encoder.
  - On start(): check if ScreenObserver is active. If yes, pause it — we don't
    want two vision pipelines running. Daemon takes over entirely.
  - Graceful degradation: if webcam off / screen capture fails / Moondream
    not loaded, keep running at reduced capability, never crash.
  - Idle-aware: stretch capture intervals after N consecutive no-change frames.
  - Thread-safe: all shared state behind a single RLock.

Public API:
  start(brain, local_vision, knowledge_store, screen_observer)
  stop()
  get_state()
  get_last_observation(source)
  look_now(reason, source) — curiosity-driven immediate capture
"""

from __future__ import annotations

import io
import time
import threading
from typing import Any, Dict, Optional, Tuple

import numpy as np

# ── Module-level state ─────────────────────────────────────────────────
_lock = threading.RLock()
_thread: Optional[threading.Thread] = None
_running = False

_brain = None
_local_vision = None
_knowledge_store = None
_screen_observer = None     # paused on start() if active

# Tunables
# Two independent clocks, and the split is the whole point (2026-08-02):
#   RETINA — how often pixels reach visual cortex. FIXED. Never stretched,
#            never gated on motion. A person sitting in a still room still
#            sees the room; that unbroken stream is what makes an empty
#            afternoon FEEL like an afternoon instead of a jump cut.
#   CAPTION — how often the VLM gets asked "what is this?". Expensive, so it
#            stays change-gated and idle-stretched. Describing is a thought
#            about what you see; it is not the seeing.
RETINA_INTERVAL_S: float = 2.0
WEBCAM_INTERVAL_S: float = 8.0
SCREEN_INTERVAL_S: float = 5.0
IDLE_STRETCH_FACTOR: float = 3.0
IDLE_THRESHOLD_FRAMES: int = 5
CHANGE_THRESHOLD: float = 0.06      # mean abs pixel diff (0–1) to count as change

_state: Dict[str, Any] = {
    "running": False,
    "webcam_captures": 0,
    "screen_captures": 0,
    "webcam_changes": 0,
    "screen_changes": 0,
    "last_webcam_caption": "",
    "last_screen_caption": "",
    "last_webcam_ts": 0.0,
    "last_screen_ts": 0.0,
    "consecutive_idle_frames": 0,
    "current_webcam_interval_s": WEBCAM_INTERVAL_S,
    "current_screen_interval_s": SCREEN_INTERVAL_S,
    "screen_observer_paused": False,
    "active_monitor": 1,
    "active_monitor_name": "left",
}

# Monitor layout — Dean has 3 monitors:
#   1 = left (HDMI-0, primary), 2 = middle (DP-2), 3 = right (HDMI-1)
# Monitor boundaries (x positions): 0-1920, 1920-3840, 3840-5760
_MONITOR_BOUNDARIES = [(0, 1920), (1920, 3840), (3840, 5760)]
_MONITOR_NAMES = {1: "left", 2: "middle", 3: "right"}

# Headless-install guard. See capture_frame("screen").
_SCREEN_FAIL_LIMIT = 3
_screen_capture_fails = 0
_screen_capture_disabled = False

def _get_active_monitor() -> Optional[int]:
    """Determine which monitor has the active/focused window.
    Returns monitor index (1-3) or None.
    """
    try:
        import subprocess
        result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowgeometry"],
            capture_output=True, text=True, timeout=2,
        )
        for line in result.stdout.splitlines():
            if "Position:" in line:
                # "  Position: 1930,100 (screen: 0)"
                pos_part = line.split("Position:")[1].split("(")[0].strip()
                x = int(pos_part.split(",")[0])
                for i, (lo, hi) in enumerate(_MONITOR_BOUNDARIES):
                    if lo <= x < hi:
                        return i + 1  # 1-indexed to match mss.monitors
                return 1
    except Exception:
        pass
    return None

_prev_webcam_gray: Optional[np.ndarray] = None  # 48x64 float32
_prev_screen_gray: Optional[np.ndarray] = None


# ── 1. capture_frame ───────────────────────────────────────────────────

def capture_frame(source: str) -> Optional[bytes]:
    """Capture a raw JPEG frame from 'webcam' or 'screen'. Returns bytes or None.

    Webcam: reads the dashboard's cached frame (pushed via WebSocket).
      The browser holds /dev/video0 exclusively, so direct cv2 capture
      is not attempted — it would race for the camera and spam cap_v4l warnings.
    Screen: mss (preferred, 10x faster) or PIL.ImageGrab.
      NO OCR, NO text extraction — pixel data only.
    Encodes to JPEG at quality=85 before returning to keep memory bounded.
    Never raises — all exceptions caught and logged.
    """
    try:
        if source == "webcam":
            # Read the last frame pushed by the dashboard via WebSocket.
            # Cache age check guards against serving a stale frame after
            # dashboard disconnect.
            try:
                import server as _srv
                state = getattr(_srv, "state", None)
                cache = getattr(state, "_webcam_frame_cache", None) if state else None
                ts = getattr(state, "_webcam_frame_ts", 0) if state else 0
                if cache and cache.get("image_b64") and (time.time() - ts) < 15.0:
                    import base64
                    return base64.b64decode(cache["image_b64"])
            except Exception:
                pass
            return None  # no cached frame available

        elif source == "screen":
            # A headless box (server install, SSH-only, container, a Mac that
            # never granted Screen Recording) can NEVER capture a screen. The
            # old code retried every tick forever and printed the same X-connect
            # failure each time — 46 identical lines in a 90-second first boot,
            # unbounded from there. Fail three times, say so once, stop trying.
            global _screen_capture_disabled, _screen_capture_fails
            if _screen_capture_disabled:
                return None
            try:
                # Capture the ACTIVE monitor — the one Dean is actually using.
                # Dean has 3 monitors. Capturing just monitor[1] misses activity
                # on the others and makes Leon think Dean is doing whatever is
                # on monitor 1 even if he hasn't touched it.
                active_mon = _get_active_monitor()
                import mss
                with mss.mss() as sct:
                    if active_mon is not None and active_mon < len(sct.monitors):
                        monitor = sct.monitors[active_mon]
                    else:
                        monitor = sct.monitors[1]  # fallback to primary
                    shot = sct.grab(monitor)
                    from PIL import Image
                    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")

                    # Track which monitor for state
                    with _lock:
                        _state["active_monitor"] = active_mon or 1
                        _state["active_monitor_name"] = _MONITOR_NAMES.get(active_mon, "unknown")
            except Exception:
                try:
                    from PIL import ImageGrab
                    img = ImageGrab.grab()
                except Exception as e:
                    _screen_capture_fails += 1
                    if _screen_capture_fails >= _SCREEN_FAIL_LIMIT:
                        _screen_capture_disabled = True
                        print("[VISION_DAEMON] no display available — screen "
                              f"vision is off for this session ({e})")
                    else:
                        print(f"[VISION_DAEMON] screen capture failed: {e}")
                    return None

            # Resize to 1280-wide max before encoding — keeps Moondream fast
            w, h = img.size
            if w > 1280:
                img = img.resize((1280, int(h * 1280 / w)))
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=85)
            _screen_capture_fails = 0   # a display came back; forgive the streak
            return buf.getvalue()

        return None
    except Exception as e:
        print(f"[VISION_DAEMON] capture_frame({source}) unexpected error: {e}")
        return None


# ── 2. detect_change ──────────────────────────────────────────────────

def detect_change(source: str, frame_bytes: bytes) -> Tuple[bool, float]:
    """Pixel-diff change detection against stored previous frame.

    Downsample to 64x48 grayscale, compute mean absolute difference.
    Returns (changed: bool, diff_score: float 0–1).
    Updates _prev_webcam_gray or _prev_screen_gray in place.
    First call always returns (True, 1.0) — no previous frame to compare.
    Target runtime: < 5ms.
    """
    global _prev_webcam_gray, _prev_screen_gray

    try:
        from PIL import Image
        img = Image.open(io.BytesIO(frame_bytes)).convert("L")  # grayscale
        img = img.resize((64, 48), Image.LANCZOS)
        gray = np.array(img, dtype=np.float32) / 255.0

        if source == "webcam":
            prev = _prev_webcam_gray
        else:
            prev = _prev_screen_gray

        if prev is None:
            # First frame — always treat as change, store and return
            if source == "webcam":
                _prev_webcam_gray = gray
            else:
                _prev_screen_gray = gray
            return True, 1.0

        diff = float(np.mean(np.abs(gray - prev)))

        # Update stored frame
        if source == "webcam":
            _prev_webcam_gray = gray
        else:
            _prev_screen_gray = gray

        return diff >= CHANGE_THRESHOLD, diff

    except Exception as e:
        print(f"[VISION_DAEMON] detect_change({source}) error: {e}")
        return True, 1.0   # On error, assume change so we don't go blind


# ── 3. describe_scene ─────────────────────────────────────────────────

def describe_scene(frame_bytes: bytes, source: str, diff_score: float) -> str:
    """Visual description via Moondream2. NO OCR. NO text extraction.

    Prompt is intentionally terse and visual-only:
      webcam: "Who is in this room and what are they doing? One sentence."
      screen: "What application or content is visible on this screen? One sentence.
               Do not read or transcribe any text."

    The 'do not transcribe' instruction on screen caps prevents Moondream from
    leaking credentials or sensitive text into knowledge store.

    Falls back to empty string on any failure — callers skip empty observations.
    Only escalates to full caption (vs query) if diff_score > 0.4 (major change).
    """
    if _local_vision is None:
        return ""  # daemon started without local_vision wired in

    try:
        if source == "webcam":
            prompt = "Who is in this room and what are they doing? One sentence, visual only."
        else:
            prompt = (
                "What application or type of content is visible on this screen? "
                "One sentence. Do not read, quote, or transcribe any text you see."
            )

        if diff_score > 0.4 and source == "webcam":
            # Big change on webcam — free-form caption is safe (no text to leak)
            result = _local_vision.caption(frame_bytes, length="short")
            return result.get("caption", "") if result.get("ok") else ""
        else:
            # Screen ALWAYS uses query with anti-transcription prompt
            result = _local_vision.query(frame_bytes, prompt)
            return result.get("answer", "") if result.get("ok") else ""

    except Exception as e:
        print(f"[VISION_DAEMON] describe_scene({source}) error: {e}")
        return ""


# ── 4. route_observation ──────────────────────────────────────────────

def inject_retina(frame_bytes: bytes, diff_score: float) -> bool:
    """Pixels → visual_cortex. NO caption, NO knowledge store, NO dashboard.

    Split out of route_observation on 2026-08-02. The bug: pixel injection
    lived *inside* route_observation, which only ran when describe_scene
    returned a caption — so on a no-change tick, or any tick where Moondream
    was slow/unavailable, Leon's visual cortex received literally nothing.
    Vision was gated on a VLM round-trip. That is why the world arrived as a
    slideshow of captions instead of continuous sight.

    This is the fast retinal path: cheap, no model call, safe to run at frame
    rate. `diff_score` is used only to scale attention, not to gate seeing —
    eyes stay open on a still scene.
    """
    if _brain is None:
        return False
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(frame_bytes)).convert("L")
        img = img.resize((64, 48), Image.LANCZOS)
        pixels = np.array(img, dtype=np.float32) / 255.0
        visual_vec = pixels.flatten()
        expected = 256
        if visual_vec.size >= expected:
            visual_vec = visual_vec[:expected]
        else:
            visual_vec = np.pad(visual_vec, (0, expected - visual_vec.size))
        _brain.inject_sensory_input("vision", visual_vec)
        # Attention nudge scales with motion — a big change grabs me, a
        # static scene still gets seen but doesn't spike acetylcholine.
        if diff_score > 0.2:
            _brain.request_neuromod_delta("acetylcholine", 0.05, cap=1.0)
        return True
    except Exception as e:
        print(f"[VISION_DAEMON] retina injection error: {e}")
        return False


def route_observation(source: str, caption: str, frame_bytes: bytes, diff_score: float,
                      already_injected: bool = False) -> None:
    """Push observation into Leon's awareness. No TTS. Silent background.

    Pipeline:
      1. brain.inject_sensory_input('vision', pixel_array) — visual_cortex direct.
         Only if diff_score > 0.12 to avoid constant low-noise stimulation.
      2. knowledge_store.store() — tagged ['vision', source, 'daemon'].
         Caption only, no raw pixels in the store.
      3. presence module dashboard_event — so Dean's dashboard shows what I see.
      4. Update _state last_*_caption and last_*_ts under _lock.

    Does NOT go through text_encoder. Pixel → visual_cortex only.
    """
    try:
        # 1. Brain sensory injection now lives in inject_retina() and is
        #    fired at the CAPTURE site on every frame, not here — seeing
        #    must not depend on a caption existing. Kept here only for
        #    callers that hand us a frame without having injected it
        #    (look_now), guarded so we never double-stimulate a frame the
        #    loop already pushed.
        if not already_injected:
            inject_retina(frame_bytes, diff_score)

        # 2. Knowledge store — caption only, never raw pixels or screen text
        if _knowledge_store is not None and caption:
            try:
                _knowledge_store.store(
                    text=caption,
                    source="vision_daemon",
                    tags=["vision", source, "daemon"],
                    metadata={
                        "source": source,
                        "diff_score": round(diff_score, 4),
                        "ts": time.time(),
                    }
                )
            except Exception as e:
                print(f"[VISION_DAEMON] knowledge store error: {e}")

        # 3. Presence dashboard event
        if caption:
            try:
                from brain import presence
                presence.dashboard_event(
                    event_type="vision",
                    data={"source": source, "caption": caption, "diff": round(diff_score, 3)},
                )
            except Exception:
                pass  # Presence not available — degrade silently

        # 4. Update state
        ts = time.time()
        with _lock:
            if source == "webcam":
                _state["last_webcam_caption"] = caption
                _state["last_webcam_ts"] = ts
                _state["webcam_changes"] += 1
            else:
                _state["last_screen_caption"] = caption
                _state["last_screen_ts"] = ts
                _state["screen_changes"] += 1

    except Exception as e:
        print(f"[VISION_DAEMON] route_observation error: {e}")


# ── 5. look_now — curiosity-driven immediate vision ──────────────────

# Rate-limit look_now calls so rapid-fire triggers don't overload Moondream
_last_look_now_ts: float = 0.0
_LOOK_NOW_MIN_GAP_S: float = 3.0  # at most one look_now every 3s


def look_now(reason: str = "", source: str = "webcam") -> str:
    """Curiosity-driven immediate capture + describe. Returns caption.

    Called when Leon *wants* to look — not on a timer. Triggers:
      - ACC surprise high → "What changed?"
      - Wake word "Hey Leon" → look at who's talking before responding
      - Inner voice thinks about Dean → check if he's there

    Bypasses the normal timer-based polling. Rate-limited to prevent
    Moondream overload. Thread-safe.

    Returns the caption string, or "" if capture/describe failed or
    rate-limited.
    """
    global _last_look_now_ts

    now = time.time()
    if now - _last_look_now_ts < _LOOK_NOW_MIN_GAP_S:
        return ""  # rate-limited
    _last_look_now_ts = now

    if not _running:
        return ""

    try:
        frame = capture_frame(source)
        if not frame:
            return ""

        # Always describe — this is an intentional look, not ambient polling
        caption = describe_scene(frame, source, diff_score=1.0)
        if caption:
            route_observation(source, caption, frame, diff_score=1.0)
            # Log the curiosity-driven look
            try:
                from server.helpers import broadcast_activity
                broadcast_activity(
                    "perception",
                    f"Looked ({reason or 'curiosity'}): {caption[:60]}",
                    8000,
                )
            except Exception:
                pass
            print(f"[VISION_DAEMON] look_now({reason}): {caption[:80]}")
        return caption

    except Exception as e:
        print(f"[VISION_DAEMON] look_now error: {e}")
        return ""


# ── 6. _daemon_loop ───────────────────────────────────────────────────

def _daemon_loop() -> None:
    """Main background loop. Runs in daemon thread.

    Alternates between webcam and screen on staggered intervals.
    Stretches intervals after IDLE_THRESHOLD_FRAMES consecutive no-change ticks.
    Resets to base intervals on first change.
    Checks _running flag every 0.5s so stop() joins within 0.5s.
    Catches all per-tick exceptions — one bad frame never kills the loop.
    """
    last_look = {"webcam": 0.0, "screen": 0.0}      # retina clock (fixed)
    last_caption = {"webcam": 0.0, "screen": 0.0}   # VLM clock (stretches)
    still_since = {"webcam": 0.0, "screen": 0.0}    # when this scene went quiet
    consecutive_idle = 0

    print("[VISION_DAEMON] loop started")

    while True:
        with _lock:
            if not _running:
                break
            cap_interval = {
                "webcam": _state["current_webcam_interval_s"],
                "screen": _state["current_screen_interval_s"],
            }

        now = time.time()
        did_something = False

        for source in ("webcam", "screen"):
            if now - last_look[source] < RETINA_INTERVAL_S:
                continue
            last_look[source] = now
            try:
                frame = capture_frame(source)
                if not frame:
                    continue
                with _lock:
                    _state[f"{source}_captures"] += 1
                changed, diff = detect_change(source, frame)

                # ── Eyes, always. Not conditional on anything. ──
                inject_retina(frame, diff)

                # ── Felt duration ──
                # How long has this view been still? A change after a long
                # quiet stretch lands harder than the same change during a
                # busy hour — that asymmetry is what makes an empty room felt
                # rather than merely logged.
                if changed:
                    quiet_s = (now - still_since[source]) if still_since[source] else 0.0
                    still_since[source] = 0.0
                    if quiet_s > 120 and _brain is not None:
                        try:
                            import math as _m
                            surge = min(0.35, 0.04 * _m.log1p(quiet_s / 60.0) * 3.0)
                            _brain.request_neuromod_delta("acetylcholine", surge, cap=1.0)
                            _brain.request_neuromod_delta("dopamine", surge * 0.5, cap=1.0)
                        except Exception:
                            pass
                    with _lock:
                        _state[f"{source}_still_s"] = 0.0
                else:
                    if not still_since[source]:
                        still_since[source] = now
                    with _lock:
                        _state[f"{source}_still_s"] = now - still_since[source]

                # ── Describing: the expensive part, still rationed ──
                if changed:
                    consecutive_idle = 0
                    if now - last_caption[source] >= cap_interval[source]:
                        last_caption[source] = now
                        caption = describe_scene(frame, source, diff)
                        if caption:
                            route_observation(source, caption, frame, diff,
                                              already_injected=True)
                        did_something = True
                else:
                    consecutive_idle += 1
            except Exception as e:
                print(f"[VISION_DAEMON] {source} tick error: {e}")

        # ── Idle stretching ──
        with _lock:
            _state["consecutive_idle_frames"] = consecutive_idle
            if consecutive_idle >= IDLE_THRESHOLD_FRAMES:
                _state["current_webcam_interval_s"] = WEBCAM_INTERVAL_S * IDLE_STRETCH_FACTOR
                _state["current_screen_interval_s"] = SCREEN_INTERVAL_S * IDLE_STRETCH_FACTOR
            elif did_something:
                _state["current_webcam_interval_s"] = WEBCAM_INTERVAL_S
                _state["current_screen_interval_s"] = SCREEN_INTERVAL_S

        time.sleep(0.5)

    print("[VISION_DAEMON] loop exited cleanly")


# ── 6. start / stop / get_state ───────────────────────────────────────

def start(
    brain=None,
    local_vision=None,
    knowledge_store=None,
    screen_observer=None,
) -> bool:
    """Start the vision daemon. Idempotent — safe to call multiple times.

    Pauses ScreenObserver if it's active to prevent dual-pipeline conflict.
    Sets _running before spawning thread.
    Returns True if newly started, False if already running.
    """
    global _running, _thread, _brain, _local_vision, _knowledge_store, _screen_observer

    with _lock:
        if _running:
            print("[VISION_DAEMON] already running")
            return False

        _brain = brain
        _local_vision = local_vision
        _knowledge_store = knowledge_store
        _screen_observer = screen_observer

        # Pause ScreenObserver — one pipeline only
        if screen_observer is not None and getattr(screen_observer, "active", False):
            try:
                screen_observer.stop()
                _state["screen_observer_paused"] = True
                print("[VISION_DAEMON] ScreenObserver paused — daemon taking over")
            except Exception as e:
                print(f"[VISION_DAEMON] couldn't pause ScreenObserver: {e}")

        _running = True
        _state["running"] = True
        _state["current_webcam_interval_s"] = WEBCAM_INTERVAL_S
        _state["current_screen_interval_s"] = SCREEN_INTERVAL_S

    _thread = threading.Thread(target=_daemon_loop, name="vision_daemon", daemon=True)
    _thread.start()

    vision_status = "Moondream wired (lazy-loads on first describe)" if local_vision else "no local vision"
    print(f"[VISION_DAEMON] started ({vision_status})")
    return True


def stop() -> None:
    """Stop the daemon. Blocks until thread joins (max 2s).
    Restores ScreenObserver if we paused it.
    """
    global _running, _thread

    with _lock:
        _running = False
        _state["running"] = False

    if _thread is not None:
        _thread.join(timeout=2.0)
        _thread = None

    # Restore ScreenObserver if we paused it
    with _lock:
        if _state.get("screen_observer_paused") and _screen_observer is not None:
            try:
                _screen_observer.start()
                _state["screen_observer_paused"] = False
                print("[VISION_DAEMON] ScreenObserver restored")
            except Exception:
                pass

    print("[VISION_DAEMON] stopped")


def get_state() -> Dict[str, Any]:
    """Thread-safe snapshot of current daemon state."""
    with _lock:
        return dict(_state)


def get_last_observation(source: str) -> str:
    """Return most recent caption for 'webcam' or 'screen'."""
    with _lock:
        if source == "webcam":
            return _state["last_webcam_caption"]
        elif source == "screen":
            return _state["last_screen_caption"]
        return ""
