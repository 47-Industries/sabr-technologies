"""
Conversation distiller — bridges short-term chat history into long-term memory.

The brain's `_STABLE_SYSTEM` prompt already tells Leon he has long-term memory
via `knowledge_search`. The KnowledgeStore is populated by the project crawler
(READMEs / CLAUDE.md / SESSION_LOGs) and the sleep consolidator. But the
conversation itself (what Dean ACTUALLY said yesterday) wasn't being written
into knowledge — once a turn scrolled out of `conversation_history`'s
working window (last 200 turns), it was effectively forgotten.

This module fixes that. Periodically, it reads conversation turns older than
the working window, asks Haiku to extract durable facts (preferences,
decisions, project context — NOT small talk or status updates), and writes
each fact into `KnowledgeStore` with `source="conversation_distill"`. After
that point, `knowledge_search("X")` finds those distilled facts the same way
it finds README content — Leon recalls them without needing the literal
turn in his context window.

State tracking is one row in a tiny `distill_progress` table: the highest
conversation_history.id that's been processed. Idempotent — re-running can't
double-distill the same turn.

Cost: ~1 Haiku call per 20-turn chunk, ~$0.001 per chunk (input ~5K tokens,
output ~200 tokens). At a 15-min interval Dean can chat all day for a few
cents.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# NOTE: `anthropic` is imported lazily inside __init__ (below), not at module
# load. The SDK isn't needed to use _extract_json_object and other pure
# helpers, so keeping it lazy lets those be imported (and unit-tested) without
# the dependency present.


def _extract_json_object(text: str):
    """Pull the first JSON object out of an LLM reply, tolerating markdown
    fences AND trailing prose (the model often appends '...nothing durable
    here' after the JSON). Returns the dict, or None if there isn't one.

    Uses raw_decode so trailing commentary after a valid object is ignored
    instead of failing the whole parse (which used to silently drop facts)."""
    import json as _json
    import re as _re
    if not text:
        return None
    m = _re.search(r"```(?:json)?\s*(.*?)```", text, _re.DOTALL)
    if m:
        text = m.group(1)
    start = text.find("{")
    if start == -1:
        return None
    try:
        obj, _ = _json.JSONDecoder().raw_decode(text[start:])
        return obj if isinstance(obj, dict) else None
    except ValueError:
        return None


_DISTILLER_MODEL = os.environ.get("LEON_DISTILLER_MODEL", "claude-haiku-4-5")
_DEFAULT_INTERVAL_S = 5 * 60        # run a pass every 5 min (was 15 — too slow for corrections)
_DEFAULT_CHUNK_TURNS = 20            # how many turns per Haiku call
_DEFAULT_WORKING_WINDOW = 200        # leave the last N turns alone (responder still loads them)
_MIN_TURNS_TO_TRIGGER = 4            # lowered from 10 — short sessions still matter

_PROGRESS_TABLE_DDL = """
CREATE TABLE IF NOT EXISTS distill_progress (
    session_id        TEXT PRIMARY KEY,
    last_distilled_id INTEGER NOT NULL DEFAULT 0,
    last_run_ts       REAL    NOT NULL DEFAULT 0,
    facts_extracted   INTEGER NOT NULL DEFAULT 0
);
"""


_DISTILL_SYSTEM = (
    "You read excerpts from a conversation between Leon (a neuromorphic AI "
    "brain) and Dean Sabr (the human who built him). Your job is fact "
    "extraction — pull out durable, long-term-useful information that "
    "Leon should still remember in a month.\n\n"
    "EXTRACT:\n"
    "- Stable preferences ('Dean prefers X', 'Dean's wake-word is Y')\n"
    "- Decisions made together ('we decided to do Y')\n"
    "- Projects Dean works on (names, status, goals)\n"
    "- Facts about Dean (role, skills, history)\n"
    "- Configuration changes that landed ('we set X to Y')\n"
    "- Bugs solved + their solutions\n"
    "- Stable opinions / takes Dean expressed\n"
    "- Corrections Dean made ('that's wrong, X is actually Y')\n"
    "- People, roles, and relationships Dean mentioned\n\n"
    "DO NOT EXTRACT:\n"
    "- Greetings, small talk, time/date checks\n"
    "- Visual descriptions of Dean ('grey shirt', 'in the bedroom')\n"
    "- Transient status ('server is up', 'webcam reconnected')\n"
    "- Failed attempts that got abandoned\n"
    "- Anything Leon hallucinated (look for tool_use/tool_result blocks "
    "to verify what actually happened)\n"
    "- Apologies, retries, frustration vents\n"
    "- Leon's own architecture stats (neuron count, region count, synapse "
    "count, tick rate). These change over time and are maintained in an "
    "authoritative entry — do NOT re-extract them from conversation.\n\n"
    "For EACH fact, also score its importance (1-5):\n"
    "  5 = Dean explicitly corrected Leon, or stated a critical identity/role/relationship fact\n"
    "  4 = Dean made a decision, gave a directive, or stated a strong preference\n"
    "  3 = Useful project context, a configuration that landed, a solved bug\n"
    "  2 = Background info that might be useful later\n"
    "  1 = Minor detail, unlikely to matter in a month\n\n"
    "Also tag who said it:\n"
    "  'dean' = Dean directly stated or confirmed this\n"
    "  'leon' = Leon inferred or observed this\n"
    "  'both' = Agreed upon together\n\n"
    "Output STRICT JSON:\n"
    "{\"facts\": [\n"
    "  {\"text\": \"Self-contained fact.\", \"importance\": 5, \"speaker\": \"dean\"},\n"
    "  {\"text\": \"Another fact.\", \"importance\": 3, \"speaker\": \"both\"}\n"
    "]}\n"
    "Each fact text must be a complete sentence understandable in isolation "
    "(re-introduce Dean / Leon / project names). Empty array if nothing "
    "durable."
)


import re as _re

# Architectural facts about Leon's own specs (neuron count, region count)
# are maintained in a single authoritative knowledge entry.  The distiller
# must never re-inject stale versions of these from old conversations.
_STALE_ARCH_PATTERNS = [
    _re.compile(r"\b10[,.]?000\s+(?:spiking\s+)?neurons?\b", _re.I),
    _re.compile(r"\bten\s+thousand\s+(?:spiking\s+)?neurons?\b", _re.I),
    _re.compile(r"\b(?:eleven|11)\s+(?:brain\s+)?regions?\b", _re.I),
]

def _is_stale_architecture(fact: str) -> bool:
    """Return True if the fact contains outdated Leon architecture numbers."""
    return any(p.search(fact) for p in _STALE_ARCH_PATTERNS)


class ConversationDistiller:
    def __init__(
        self,
        knowledge_store,
        db_path: Optional[str] = None,
        session_id: str = "default",
        model: str = _DISTILLER_MODEL,
        interval_s: float = _DEFAULT_INTERVAL_S,
        chunk_turns: int = _DEFAULT_CHUNK_TURNS,
        working_window: int = _DEFAULT_WORKING_WINDOW,
    ):
        self.knowledge = knowledge_store
        if db_path is None:
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(project_root, "brain_state", "knowledge.db")
        self.db_path = db_path
        self.session_id = session_id
        self.model = model
        self.interval_s = max(60.0, float(interval_s))
        self.chunk_turns = max(4, int(chunk_turns))
        self.working_window = max(0, int(working_window))

        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if api_key:
            import anthropic
            self._client = anthropic.Anthropic(api_key=api_key)
        else:
            self._client = None

        self._init_db()

    def _init_db(self) -> None:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            conn.execute(_PROGRESS_TABLE_DDL)
            conn.execute(
                "INSERT OR IGNORE INTO distill_progress (session_id) VALUES (?)",
                (self.session_id,),
            )
            conn.commit()

    # ── progress helpers ────────────────────────────────────────────────
    def _get_progress(self) -> Tuple[int, float, int]:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            row = conn.execute(
                "SELECT last_distilled_id, last_run_ts, facts_extracted "
                "FROM distill_progress WHERE session_id = ?",
                (self.session_id,),
            ).fetchone()
        return (row[0], row[1], row[2]) if row else (0, 0.0, 0)

    def _set_progress(self, last_id: int, facts_added: int) -> None:
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            conn.execute(
                "UPDATE distill_progress SET last_distilled_id = ?, "
                "last_run_ts = ?, facts_extracted = facts_extracted + ? "
                "WHERE session_id = ?",
                (last_id, time.time(), facts_added, self.session_id),
            )
            conn.commit()

    # ── selection ──────────────────────────────────────────────────────
    def _undistilled_old_turns(self) -> List[Tuple[int, str, str, float]]:
        """Return [(id, role, content, ts)] for turns that:
        - have id > last_distilled_id (haven't been processed yet), AND
        - have id <= max_id - working_window (out of working memory).

        Ordered ascending by id. If no max-id exists or every fresh turn
        is still inside the working window, returns []."""
        last_id, _, _ = self._get_progress()
        with self._lock, sqlite3.connect(self.db_path, timeout=30) as conn:
            row = conn.execute(
                "SELECT MAX(id) FROM conversation_history WHERE session_id = ?",
                (self.session_id,),
            ).fetchone()
            max_id = row[0] if row and row[0] is not None else 0
            cutoff = max_id - self.working_window
            if cutoff <= last_id:
                return []
            rows = conn.execute(
                "SELECT id, role, content, ts FROM conversation_history "
                "WHERE session_id = ? AND id > ? AND id <= ? "
                "ORDER BY id ASC",
                (self.session_id, last_id, cutoff),
            ).fetchall()
        return [(r[0], r[1], r[2], r[3]) for r in rows]

    # ── content normalization ──────────────────────────────────────────
    @staticmethod
    def _normalize_content(content: str) -> str:
        """conversation_store stores rich turns as `__BLOCKS__<json>`.
        For distillation we want a readable text representation — flatten
        text blocks, summarize tool_use/tool_result so the distiller can
        verify what actually happened (not what Leon narrated)."""
        if not content:
            return ""
        if not content.startswith("__BLOCKS__"):
            return content
        try:
            blocks = json.loads(content[len("__BLOCKS__"):])
        except Exception:
            return content
        out = []
        for b in blocks:
            if not isinstance(b, dict):
                continue
            t = b.get("type")
            if t == "text":
                out.append(b.get("text", ""))
            elif t == "tool_use":
                name = b.get("name", "?")
                inp = b.get("input", {})
                inp_short = json.dumps(inp, default=str)[:200]
                out.append(f"[TOOL CALL] {name}({inp_short})")
            elif t == "tool_result":
                # Could be a string or a list of blocks (image+text)
                inner = b.get("content")
                if isinstance(inner, str):
                    out.append(f"[TOOL RESULT] {inner[:300]}")
                elif isinstance(inner, list):
                    for sub in inner:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            out.append(f"[TOOL RESULT] {sub.get('text','')[:300]}")
                        elif isinstance(sub, dict) and sub.get("type") == "image":
                            out.append("[TOOL RESULT] (image returned)")
        return "\n".join(s for s in out if s).strip()

    def _format_chunk(self, turns: List[Tuple[int, str, str, float]]) -> str:
        """Render turns as a compact transcript for the distiller prompt."""
        lines = []
        for (_id, role, raw_content, ts) in turns:
            content = self._normalize_content(raw_content)
            if not content:
                continue
            from brain.identity import si_name as _sn, user_name as _un
            tag = _un() if role == "user" else _sn()
            content = content.strip()
            if len(content) > 1500:
                content = content[:1500] + " […truncated]"
            lines.append(f"[{tag}] {content}")
        return "\n\n".join(lines)

    # ── single-chunk extraction ────────────────────────────────────────
    def distill_chunk(self, turns: List[Tuple[int, str, str, float]]) -> List[str]:
        """Run the distillation prompt over a chunk via the claude CLI
        subprocess so it bills against Dean's Max plan, not the API.
        Returns extracted facts (possibly empty)."""
        if not turns:
            return []
        transcript = self._format_chunk(turns)
        if not transcript:
            return []
        import subprocess
        # System prompt goes in --system-prompt (full replace) so Claude
        # Code's default coding-assistant identity doesn't override
        # _DISTILL_SYSTEM. cwd=/tmp avoids CLAUDE.md auto-load.
        user_prompt = (
            "Conversation excerpt:\n\n"
            f"{transcript}\n\n"
            "Extract durable facts as JSON now."
        )
        # Strip ANTHROPIC_API_KEY from env so Claude Code falls back to
        # the OAuth Max-plan token instead of the dead API key.
        cli_env = os.environ.copy()
        cli_env.pop("ANTHROPIC_API_KEY", None)
        try:
            r = subprocess.run(
                [
                    "claude", "-p",
                    "--system-prompt", _DISTILL_SYSTEM,
                    user_prompt,
                ],
                cwd="/tmp",
                env=cli_env,
                capture_output=True, text=True, timeout=60,
            )
            if r.returncode != 0:
                print(f"[DISTILL] CLI returncode={r.returncode} stderr={(r.stderr or '')[:120]}")
                return []
            text = (r.stdout or "").strip()
        except subprocess.TimeoutExpired:
            print("[DISTILL] CLI timeout")
            return []
        except FileNotFoundError:
            print("[DISTILL] claude CLI not found in PATH")
            return []
        except Exception as e:
            print(f"[DISTILL] unexpected error: {e}")
            return []
        obj = _extract_json_object(text)
        if obj is None:
            print(f"[DISTILL] no parseable facts JSON in: {text[:160]!r}")
            return []
        try:
            raw_facts = obj.get("facts") or []
            # Support both old format (list of strings) and new format (list of dicts)
            parsed = []
            for f in raw_facts:
                if isinstance(f, str) and f.strip():
                    parsed.append({"text": f.strip(), "importance": 3, "speaker": "both"})
                elif isinstance(f, dict) and f.get("text", "").strip():
                    parsed.append({
                        "text": f["text"].strip(),
                        "importance": max(1, min(5, int(f.get("importance", 3)))),
                        "speaker": f.get("speaker", "both"),
                    })
            return parsed
        except Exception as e:
            print(f"[DISTILL] facts JSON shape error ({e}): {text[:160]!r}")
            return []

    # ── full pass over all undistilled chunks ──────────────────────────
    def run_pass(self) -> Dict[str, Any]:
        """Distill every chunk currently outside the working window.
        Returns a small report dict for logging."""
        turns = self._undistilled_old_turns()
        if len(turns) < _MIN_TURNS_TO_TRIGGER:
            return {"ran": False, "reason": "below threshold",
                    "available": len(turns)}
        chunks_done = 0
        facts_added = 0
        last_id_processed = 0
        for i in range(0, len(turns), self.chunk_turns):
            chunk = turns[i : i + self.chunk_turns]
            if len(chunk) < 2:
                continue
            facts = self.distill_chunk(chunk)
            facts = [f for f in facts if not _is_stale_architecture(f.get("text", "") if isinstance(f, dict) else f)]
            for fact in facts:
                fact_text = fact["text"] if isinstance(fact, dict) else fact
                importance = fact.get("importance", 3) if isinstance(fact, dict) else 3
                speaker = fact.get("speaker", "both") if isinstance(fact, dict) else "both"
                # High-importance facts from Dean get a different source tag
                # so they're treated as durable (survive decay, get LTP)
                if importance >= 4 and speaker in ("dean", "both"):
                    source = "dean_stated"
                else:
                    source = "conversation_distill"
                try:
                    self.knowledge.store(
                        text=fact_text,
                        source=source,
                        tags=["chat", "distilled", "memory"],
                        metadata={
                            "session": self.session_id,
                            "chunk_first_id": chunk[0][0],
                            "chunk_last_id": chunk[-1][0],
                            "chunk_first_ts": chunk[0][3],
                            "chunk_last_ts": chunk[-1][3],
                            "model": self.model,
                            "importance": importance,
                            "speaker": speaker,
                        },
                    )
                    facts_added += 1
                except Exception as e:
                    print(f"[DISTILL] store fact failed: {e}")
            last_id_processed = chunk[-1][0]
            chunks_done += 1
            # update progress per chunk so a crash doesn't lose the
            # whole pass
            self._set_progress(last_id_processed, facts_added=len(facts))

        return {
            "ran": True,
            "chunks": chunks_done,
            "facts_added": facts_added,
            "last_id": last_id_processed,
            "turns_processed": len(turns),
        }

    # ── background loop ────────────────────────────────────────────────
    def _loop(self) -> None:
        # Initial small delay so we don't fight startup CPU.
        if self._stop.wait(60):
            return
        while not self._stop.is_set():
            try:
                report = self.run_pass()
                if report.get("ran"):
                    print(f"[DISTILL] pass complete: "
                          f"{report['facts_added']} facts from "
                          f"{report['turns_processed']} turns "
                          f"({report['chunks']} chunks)")
                # Prune old conversation history (keep last 2000 turns)
                try:
                    import sqlite3 as _sq
                    with _sq.connect(self.knowledge_store.db_path, timeout=10) as _c:
                        total = _c.execute("SELECT COUNT(*) FROM conversation_history").fetchone()[0]
                        if total > 2000:
                            _c.execute("""DELETE FROM conversation_history WHERE id NOT IN
                                (SELECT id FROM conversation_history ORDER BY id DESC LIMIT 2000)""")
                            _c.commit()
                            pruned = total - 2000
                            if pruned > 0:
                                print(f"[DISTILL] pruned {pruned} old conversation turns (kept 2000)")
                except Exception:
                    pass
            except Exception as e:
                print(f"[DISTILL] pass crashed (continuing): {e}")
            if self._stop.wait(self.interval_s):
                return

    def start(self) -> None:
        # CLI subprocess path doesn't need an API key — uses Max plan auth.
        # Quick sanity check that the `claude` binary exists.
        import shutil as _sh
        if _sh.which("claude") is None:
            print("[DISTILL] claude CLI not found in PATH — distiller disabled")
            return
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="ConversationDistiller", daemon=True
        )
        self._thread.start()
        print(f"[DISTILL] started — model={self.model}, "
              f"interval={int(self.interval_s)}s, "
              f"chunk={self.chunk_turns} turns, "
              f"window={self.working_window} turns")

    def stop(self) -> None:
        self._stop.set()
