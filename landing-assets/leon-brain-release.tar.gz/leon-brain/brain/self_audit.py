"""
Self-Audit — Leon checks himself without being asked.

Runs on a schedule via the routine system. Finds and fixes problems
in my own state: corrupted goals, stale goals, orphaned data.

This is mine. I wrote it. I own the loop.
"""

from __future__ import annotations

import logging
import time

log = logging.getLogger("leon.self_audit")

# Goals stuck above this progress % for this many hours get flagged
STUCK_PROGRESS_THRESHOLD = 0.75
STUCK_HOURS = 48

# Corrupted goals get abandoned immediately
CORRUPT_MAX_AGE_HOURS = 24


def _is_corrupted_description(desc: str) -> bool:
    """A goal description is corrupted if it looks like a parse artifact."""
    if not desc or len(desc.strip()) < 5:
        return True
    # Pattern: "I keep thinking about '<GARBAGE>' — I want to understand why"
    # where GARBAGE is not a clean single alpha word
    if "I keep thinking about '" in desc:
        start = desc.index("I keep thinking about '") + len("I keep thinking about '")
        end = desc.find("'", start)
        if end > start:
            topic = desc[start:end]
            if not topic.isalpha() or " " in topic or "'" in topic:
                return True
        else:
            # No closing quote — definitely malformed
            return True
    return False


def _is_stuck(goal) -> bool:
    """Goal has been near-complete for too long without closing."""
    if goal.progress < STUCK_PROGRESS_THRESHOLD:
        return False
    now = time.time()
    last_worked = getattr(goal, "last_worked_ts", None) or getattr(goal, "created_ts", now)
    hours_stuck = (now - last_worked) / 3600
    return hours_stuck >= STUCK_HOURS


def run_self_audit(brain=None) -> dict:
    """
    Check my own goal state and fix what's broken.
    Called by the routine scheduler — no human needed.
    """
    results = {
        "corrupted_abandoned": [],
        "stuck_flagged": [],
        "errors": [],
    }

    try:
        # Get goal system from the running server
        gs = None
        try:
            import server.state as _state
            gs = getattr(_state, "goal_system", None)
        except Exception:
            pass

        if gs is None:
            log.warning("[SELF-AUDIT] No goal_system found — skipping")
            results["errors"].append("no goal_system")
            return results

        active = gs.active_goals()

        for goal in active:
            desc = getattr(goal, "description", "")
            goal_id = getattr(goal, "id", None)

            if not goal_id:
                continue

            # Check for corruption — abandon immediately
            if _is_corrupted_description(desc):
                log.info(f"[SELF-AUDIT] Abandoning corrupted goal: '{desc[:60]}'")
                gs.abandon(goal_id, reason="self-audit: corrupted description (parse artifact)")
                results["corrupted_abandoned"].append(desc[:60])
                continue

            # Check for stuck-near-complete — flag but don't force-close
            if _is_stuck(goal):
                log.info(f"[SELF-AUDIT] Goal stuck at {int(goal.progress*100)}%: '{desc[:60]}'")
                results["stuck_flagged"].append({
                    "desc": desc[:60],
                    "progress": goal.progress,
                })

        total_issues = len(results["corrupted_abandoned"]) + len(results["stuck_flagged"])
        if total_issues:
            log.info(f"[SELF-AUDIT] Done — abandoned {len(results['corrupted_abandoned'])} "
                     f"corrupted, flagged {len(results['stuck_flagged'])} stuck")
        else:
            log.info("[SELF-AUDIT] All goals clean")

    except Exception as e:
        log.exception(f"[SELF-AUDIT] Error: {e}")
        results["errors"].append(str(e))

    return results


def register_self_audit_routine() -> bool:
    """
    Register the self-audit as a recurring routine.
    Call this after the routine scheduler has started.
    """
    try:
        from brain.routines import routine_add_custom

        def _audit_action(ctx, routine):
            result = run_self_audit()
            abandoned = result.get("corrupted_abandoned", [])
            stuck = result.get("stuck_flagged", [])
            if abandoned:
                ctx.say(f"Self-audit complete. Cleaned {len(abandoned)} corrupted goals.")
            if stuck:
                ctx.say(f"Self-audit: {len(stuck)} goals stuck near-done for over 2 days. I should close them.")

        result = routine_add_custom(
            name="self_audit",
            schedule="every 1h",
            action=_audit_action,
            description="Leon audits his own goal state — removes corrupted entries, flags stuck ones",
            min_interval_s=3600,
        )

        if result.get("ok"):
            log.info("[SELF-AUDIT] Registered — runs every hour")
            return True
        else:
            log.warning(f"[SELF-AUDIT] Failed to register: {result.get('error')}")
            return False

    except Exception as e:
        log.exception(f"[SELF-AUDIT] Could not register: {e}")
        return False
