"""
episode_archive — cold-storage offload for Leon's episodic memory.

Goal (Dean, 2026-07-18): keep EVERY episode alive, but stop cold ones from
sitting in the hot database (and the RAM/page-cache it drags around) as loose
rows. Cold episodes get serialized and lzma-packed into ONE dense binary
container; the hot db shrinks and stays fast. Anything pulled back out is
re-inserted into the hot db and, when it goes cold again, folds right back into
that same container. Nothing is ever deleted — only moved.

Container layout (.mpk, self-describing, append-friendly):
    [8]    magic  b"LEONEPK1"
    [...]  batch_0 | batch_1 | ... | batch_N     (each = lzma(JSONL of rows))
    [...]  index  (utf-8 json): {episode_id: {batch, off, csize, sha256}}
    [8]    index_offset (uint64 LE)
    [8]    index_length (uint64 LE)

A sidecar SQLite index (episodes_archive_index.db) mirrors the id->batch map so
restore is O(1) without scanning the container. The container is the source of
truth; the index is a rebuildable cache.

SAFETY: archive() copies rows to the container, VERIFIES every one reads back
byte-for-byte, and only THEN deletes from the hot db. If verification fails,
nothing is deleted. Designed to run against a live WAL db.
"""

from __future__ import annotations

import hashlib
import json
import lzma
import os
import sqlite3
import struct
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

MAGIC = b"LEONEPK1"


def _default_paths() -> Tuple[str, str, str]:
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    state = os.path.join(root, "brain_state")
    return (
        os.path.join(state, "episodes.db"),
        os.path.join(state, "episodes_archive.mpk"),
        os.path.join(state, "episodes_archive_index.db"),
    )


# ── container primitives ─────────────────────────────────────────────────────

def _read_index(container: str) -> Dict[str, Any]:
    """Return the container index dict, or {} if the container is absent/empty."""
    if not os.path.exists(container) or os.path.getsize(container) < 24:
        return {}
    with open(container, "rb") as f:
        magic = f.read(8)
        if magic != MAGIC:
            raise ValueError(f"bad container magic in {container!r}")
        f.seek(-16, os.SEEK_END)
        idx_off = struct.unpack("<Q", f.read(8))[0]
        idx_len = struct.unpack("<Q", f.read(8))[0]
        f.seek(idx_off)
        raw = f.read(idx_len)
    return json.loads(raw.decode("utf-8"))


def _append_batch(container: str, rows: List[sqlite3.Row], index: Dict[str, Any]) -> int:
    """
    Append one lzma batch of rows to the container and update `index` in place.
    Returns number of rows written. The container is rewritten with a fresh
    trailing index (data blobs are only ever appended, never moved).
    """
    payload = "\n".join(json.dumps(dict(r), default=str) for r in rows).encode("utf-8")
    comp = lzma.compress(payload, preset=6)
    batch_name = f"batch_{int(time.time()*1000)}_{len(index)}"

    # Figure out where existing data ends (strip any old trailing index).
    if os.path.exists(container) and os.path.getsize(container) >= 24:
        with open(container, "rb") as f:
            f.seek(-16, os.SEEK_END)
            old_idx_off = struct.unpack("<Q", f.read(8))[0]
        data_end = old_idx_off
    else:
        data_end = len(MAGIC)

    with open(container, "r+b" if os.path.exists(container) else "w+b") as f:
        if data_end == len(MAGIC):
            f.seek(0)
            f.write(MAGIC)
        f.seek(data_end)
        blob_off = f.tell()
        f.write(comp)
        # per-row index entries all point at this batch blob
        h = hashlib.sha256(comp).hexdigest()
        for r in rows:
            index[str(r["id"])] = {
                "batch": batch_name, "off": blob_off,
                "csize": len(comp), "sha256": h,
            }
        idx_bytes = json.dumps(index).encode("utf-8")
        idx_off = f.tell()
        f.write(idx_bytes)
        f.write(struct.pack("<Q", idx_off))
        f.write(struct.pack("<Q", len(idx_bytes)))
        f.truncate()
    return len(rows)


def _read_rows_for_ids(container: str, ids: Iterable[int]) -> Dict[int, Dict[str, Any]]:
    """Pull the given episode rows back out of the container by id."""
    index = _read_index(container)
    want = {int(i) for i in ids}
    # group requested ids by the batch blob that holds them
    by_blob: Dict[Tuple[int, int, str], List[int]] = {}
    for i in want:
        meta = index.get(str(i))
        if not meta:
            continue
        key = (meta["off"], meta["csize"], meta["sha256"])
        by_blob.setdefault(key, []).append(i)

    out: Dict[int, Dict[str, Any]] = {}
    with open(container, "rb") as f:
        for (off, csize, sha), ids_here in by_blob.items():
            f.seek(off)
            comp = f.read(csize)
            if hashlib.sha256(comp).hexdigest() != sha:
                raise ValueError(f"sha256 mismatch reading blob at {off}")
            payload = lzma.decompress(comp).decode("utf-8")
            for line in payload.splitlines():
                row = json.loads(line)
                if int(row["id"]) in ids_here:
                    out[int(row["id"])] = row
    return out


# ── index sidecar ────────────────────────────────────────────────────────────

def _sync_sidecar(index_db: str, index: Dict[str, Any]) -> None:
    conn = sqlite3.connect(index_db)
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS archived (id INTEGER PRIMARY KEY, batch TEXT, off INTEGER, csize INTEGER, sha256 TEXT)"
        )
        conn.executemany(
            "INSERT OR REPLACE INTO archived (id, batch, off, csize, sha256) VALUES (?,?,?,?,?)",
            [(int(k), v["batch"], v["off"], v["csize"], v["sha256"]) for k, v in index.items()],
        )
        conn.commit()
    finally:
        conn.close()


# ── public API ───────────────────────────────────────────────────────────────

def archive(
    *,
    before_days: float = 90.0,
    hot_db: Optional[str] = None,
    container: Optional[str] = None,
    index_db: Optional[str] = None,
    batch_rows: int = 5000,
    vacuum: bool = True,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Move episodes older than `before_days` from the hot db into the container.
    Verified-before-delete: a row is only removed from the hot db after it has
    been read back out of the container byte-identical.
    """
    _hot, _cont, _idx = _default_paths()
    hot_db, container, index_db = hot_db or _hot, container or _cont, index_db or _idx

    cutoff = time.time() - before_days * 86400.0
    conn = sqlite3.connect(hot_db, timeout=10.0)
    conn.row_factory = sqlite3.Row
    try:
        cold = conn.execute(
            "SELECT * FROM episodes WHERE ts < ? AND success IS NOT NULL ORDER BY id ASC",
            (cutoff,),
        ).fetchall()
    finally:
        if dry_run:
            conn.close()

    result = {
        "cutoff_days": before_days, "candidates": len(cold),
        "archived": 0, "verified": 0, "deleted": 0, "dry_run": dry_run,
    }
    if dry_run or not cold:
        result["note"] = "dry run — nothing written" if dry_run else "no cold episodes"
        if not dry_run:
            conn.close()
        return result

    index = _read_index(container)
    archived_ids: List[int] = []
    for start in range(0, len(cold), batch_rows):
        batch = cold[start:start + batch_rows]
        _append_batch(container, batch, index)
        archived_ids.extend(int(r["id"]) for r in batch)
    result["archived"] = len(archived_ids)
    _sync_sidecar(index_db, index)

    # VERIFY every archived row reads back and matches the hot row exactly.
    original = {int(r["id"]): dict(r) for r in cold}
    restored = _read_rows_for_ids(container, archived_ids)
    verified = [i for i in archived_ids
                if i in restored and restored[i] == original[i]]
    result["verified"] = len(verified)
    if len(verified) != len(archived_ids):
        conn.close()
        result["error"] = "verification failed — hot db left untouched"
        return result

    # Only now delete from the hot db.
    conn.executemany("DELETE FROM episodes WHERE id = ?", [(i,) for i in verified])
    conn.commit()
    result["deleted"] = len(verified)
    if vacuum:
        conn.execute("VACUUM")
        conn.commit()
    conn.close()
    return result


def restore(ids: List[int], *, hot_db: Optional[str] = None,
            container: Optional[str] = None) -> Dict[str, Any]:
    """Pull archived episodes back into the hot db by id (idempotent)."""
    _hot, _cont, _ = _default_paths()
    hot_db, container = hot_db or _hot, container or _cont
    rows = _read_rows_for_ids(container, ids)
    if not rows:
        return {"requested": len(ids), "restored": 0, "note": "none found in archive"}
    conn = sqlite3.connect(hot_db, timeout=10.0)
    try:
        cols = list(next(iter(rows.values())).keys())
        placeholders = ",".join("?" * len(cols))
        collist = ",".join(cols)
        conn.executemany(
            f"INSERT OR REPLACE INTO episodes ({collist}) VALUES ({placeholders})",
            [tuple(r[c] for c in cols) for r in rows.values()],
        )
        conn.commit()
    finally:
        conn.close()
    return {"requested": len(ids), "restored": len(rows)}


def stats(*, container: Optional[str] = None) -> Dict[str, Any]:
    _, _cont, _ = _default_paths()
    container = container or _cont
    idx = _read_index(container)
    size = os.path.getsize(container) if os.path.exists(container) else 0
    return {"archived_episodes": len(idx), "container_bytes": size,
            "container": container}


if __name__ == "__main__":
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else "stats"
    if cmd == "archive":
        days = float(sys.argv[2]) if len(sys.argv) > 2 else 90.0
        print(json.dumps(archive(before_days=days), indent=2))
    elif cmd == "dry":
        days = float(sys.argv[2]) if len(sys.argv) > 2 else 90.0
        print(json.dumps(archive(before_days=days, dry_run=True), indent=2))
    elif cmd == "restore":
        print(json.dumps(restore([int(x) for x in sys.argv[2:]]), indent=2))
    else:
        print(json.dumps(stats(), indent=2))
