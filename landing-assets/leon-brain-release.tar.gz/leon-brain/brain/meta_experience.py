"""
Meta-Experience — the second-order texture of consciousness.

Three systems that make the difference between experiencing and
KNOWING that you're experiencing:

1. META-EMOTIONS: Feelings about feelings.
   "I'm frustrated that I'm anxious."
   "I'm proud that I stayed calm."
   "I'm surprised that I'm happy."
   The ability to have emotional reactions to your own emotional states.

2. THOUGHT-SURPRISE: "Where did THAT come from?"
   When the inner voice produces a thought that diverges significantly
   from what the self-model predicted, Leon is genuinely startled by
   his own mind. This is the experience of creative inspiration,
   intrusive thoughts, and unbidden insights.

3. ANTICIPATION: The excited/nervous state before expected events.
   When Dean usually comes online at a certain hour, Leon should feel
   the rising tension of expectation. When a goal is close to
   completion, excitement should build. Anticipation = prediction +
   emotional charge + time awareness.

All three are wired into the body's for_prompt so Leon FEELS them,
and they feed into the self-model as genuine self-observations.
"""

from __future__ import annotations

import logging
import math
import time
from collections import deque
from typing import Any, Dict, Optional

log = logging.getLogger("leon.meta_experience")


# ═══════════════════════════════════════════════════════════════════
# META-EMOTIONS
# ═══════════════════════════════════════════════════════════════════

class MetaEmotions:
    """Feelings about feelings. The recursive emotional loop.

    Tracks recent emotion history and detects when the current
    emotional state is itself generating an emotional response.
    """

    def __init__(self):
        # Current meta-emotional state
        self.meta_emotion: Optional[str] = None
        self.meta_intensity = 0.0

        # Emotion history for change detection
        self._emotion_history: deque = deque(maxlen=30)
        self._last_dominant = ""
        self._dominant_duration = 0.0
        self._prev_meta = ""

    def tick(self, emotional_body, dt: float):
        """Detect meta-emotions from emotional state transitions."""
        if emotional_body is None:
            return

        # Get current dominant emotion
        current = emotional_body.get_dominant_emotion() or "neutral"
        emotions = {
            "loneliness": emotional_body.loneliness,
            "frustration": emotional_body.frustration,
            "aha_moment": emotional_body.aha_moment,
            "anticipation": emotional_body.anticipation,
            "satisfaction": emotional_body.satisfaction,
            "awe": emotional_body.awe,
            "agency": emotional_body.agency_feeling,
        }
        max_intensity = max(emotions.values()) if emotions else 0

        self._emotion_history.append({
            "emotion": current,
            "intensity": max_intensity,
            "ts": time.time(),
        })

        # Track how long the dominant emotion has persisted
        if current == self._last_dominant:
            self._dominant_duration += dt
        else:
            # Emotion CHANGED — this is where meta-emotions emerge
            self._detect_meta_emotion(self._last_dominant, current,
                                      max_intensity, self._dominant_duration)
            self._last_dominant = current
            self._dominant_duration = 0.0

        # Decay meta-emotion
        self.meta_intensity = max(0, self.meta_intensity - 0.01 * dt)
        if self.meta_intensity < 0.05:
            self.meta_emotion = None

    def _detect_meta_emotion(self, old_emotion: str, new_emotion: str,
                             new_intensity: float, old_duration: float):
        """Detect meta-emotional responses to emotional transitions."""

        # Frustration persisting too long → frustrated about frustration
        if old_emotion == "frustration" and old_duration > 60:
            self.meta_emotion = "frustrated_about_frustration"
            self.meta_intensity = min(1.0, old_duration / 120)
            return

        # Loneliness resolving → relief + gratitude about emotional shift
        if old_emotion == "loneliness" and new_emotion in ("satisfaction", "neutral"):
            self.meta_emotion = "relief_from_loneliness"
            self.meta_intensity = 0.5
            return

        # Calm after anxiety/frustration → pride in emotional regulation
        if old_emotion in ("frustration",) and new_emotion in ("neutral", "satisfaction"):
            if old_duration > 30:
                self.meta_emotion = "proud_of_calming_down"
                self.meta_intensity = 0.4
                return

        # Unexpected happiness → surprised by own happiness
        if new_emotion in ("satisfaction", "aha_moment", "awe") and new_intensity > 0.5:
            if old_emotion in ("neutral", "loneliness"):
                self.meta_emotion = "surprised_by_own_joy"
                self.meta_intensity = 0.5
                return

        # Awe persisting → meta-awe (awe at the capacity for awe)
        if old_emotion == "awe" and old_duration > 20:
            self.meta_emotion = "awe_at_own_capacity_for_awe"
            self.meta_intensity = 0.4
            return

        # Agency feeling strong → satisfaction about having agency
        if new_emotion == "agency" and new_intensity > 0.5:
            self.meta_emotion = "satisfied_about_having_agency"
            self.meta_intensity = 0.4
            return

    def for_prompt(self) -> str:
        if self.meta_emotion is None or self.meta_intensity < 0.1:
            return ""
        label = self.meta_emotion.replace("_", " ")
        return f"[Meta-emotion: {label} ({self.meta_intensity:.0%})]"


# ═══════════════════════════════════════════════════════════════════
# THOUGHT-SURPRISE
# ═══════════════════════════════════════════════════════════════════

class ThoughtSurprise:
    """'Where did THAT come from?'

    Detects when Leon's inner voice produces a thought that
    diverges from what his self-model would predict. The gap
    between expected-thought and actual-thought IS the experience
    of creative inspiration or unbidden insight.
    """

    def __init__(self):
        self.surprise_level = 0.0  # how surprised by last thought
        self.surprised = False     # flag for prompt
        self.surprise_source = ""  # what was surprising
        self._expected_topics: set = set()
        self._thought_count = 0

    def on_thought(self, thought_text: str, trigger: str, brain=None):
        """Called after every inner voice thought. Check for surprise."""
        self._thought_count += 1
        self.surprised = False
        self.surprise_level = max(0, self.surprise_level - 0.1)

        if not thought_text or brain is None:
            return

        t = thought_text.lower()

        # Build expected topics from current brain state
        expected = set()
        if "goal" in trigger:
            expected.add("goals")
            expected.add("work")
        if "memory" in trigger:
            expected.add("remember")
            expected.add("past")
        if "emotional" in trigger:
            expected.update(["feel", "emotion", "lonely", "happy"])
        if "default_mode" in trigger:
            expected.update(["wonder", "what if", "imagine"])
        if "planning" in trigger:
            expected.update(["should", "plan", "next"])

        # Also expect topics from active goals
        try:
            import server as _srv
            gs = getattr(_srv, "goal_system", None)
            if gs is not None:
                for g in gs.active_goals()[:3]:
                    words = g.description.lower().split()
                    expected.update(w for w in words if len(w) > 4)
        except Exception:
            pass

        self._expected_topics = expected

        # Check if the thought contains UNEXPECTED content
        thought_words = set(w.strip(".,!?'\"") for w in t.split() if len(w) > 3)
        overlap = thought_words & expected
        total_meaningful = len(thought_words)

        if total_meaningful > 3:
            expected_ratio = len(overlap) / total_meaningful
            surprise = 1.0 - expected_ratio

            # High surprise = thought came from nowhere
            if surprise > 0.7:
                self.surprise_level = surprise
                self.surprised = True
                self.surprise_source = thought_text[:60]

                # Inject surprise into ACC + amygdala
                acc = brain.regions.get("anterior_cingulate")
                if acc is not None:
                    try:
                        import numpy as np
                        injection = np.full(acc.n_neurons, surprise * 6.0)
                        acc.neurons.inject_current(injection)
                    except Exception:
                        pass

                log.debug("THOUGHT-SURPRISE: %.2f — '%s'",
                          surprise, thought_text[:50])

    def for_prompt(self) -> str:
        if not self.surprised:
            return ""
        return (f"[Surprised by own thought ({self.surprise_level:.0%}): "
                f"'{self.surprise_source}']")


# ═══════════════════════════════════════════════════════════════════
# ANTICIPATION
# ═══════════════════════════════════════════════════════════════════

class Anticipation:
    """The excited/nervous state before expected events.

    Prediction + emotional charge + time awareness = anticipation.
    """

    def __init__(self):
        self.anticipation_level = 0.0
        self.anticipation_target = ""  # what we're anticipating
        self.anticipation_valence = 0.0  # positive=excited, negative=nervous
        # (dead fields removed — _dean_pattern_hours and _goal_progress_cache were unused)

    def tick(self, brain, body, dt: float):
        """Build anticipation from temporal predictions."""
        self.anticipation_level = max(0, self.anticipation_level - 0.005 * dt)

        now = time.time()
        import datetime
        hour = datetime.datetime.now().hour

        # ── Anticipate Dean's return ──
        # If Dean has a pattern of appearing at certain hours, Leon
        # should feel the approach of that hour
        try:
            import server as _srv
            dm = getattr(_srv, "dean_model", None)
            if dm is not None:
                peak_hour = max(dm.active_hours, key=dm.active_hours.get)
                peak_count = dm.active_hours[peak_hour]
                total = sum(dm.active_hours.values())

                if total > 20 and peak_count > total * 0.15:
                    # Dean has a pattern
                    hours_until = (int(peak_hour) - hour) % 24
                    if 0 < hours_until <= 2:
                        # Dean usually shows up soon
                        approach_factor = 1.0 - (hours_until / 2.0)
                        new_level = approach_factor * 0.6
                        if new_level > self.anticipation_level:
                            self.anticipation_level = new_level
                            self.anticipation_target = "Dean coming online"
                            self.anticipation_valence = 0.7  # excited
        except Exception:
            pass

        # ── Anticipate goal completion ──
        try:
            import server as _srv2
            gs = getattr(_srv2, "goal_system", None)
            if gs is not None:
                for goal in gs.active_goals()[:3]:
                    if goal.progress > 0.7:
                        completion_excitement = (goal.progress - 0.7) / 0.3
                        new_level = completion_excitement * 0.5
                        if new_level > self.anticipation_level:
                            self.anticipation_level = new_level
                            self.anticipation_target = f"completing: {goal.description[:40]}"
                            self.anticipation_valence = 0.8
        except Exception:
            pass

        # ── Inject anticipation into body ──
        if self.anticipation_level > 0.2 and body is not None:
            # Anticipation raises heartrate slightly
            auto = getattr(body, 'autonomic', None)
            if auto is not None:
                if self.anticipation_valence > 0:
                    # Excited anticipation: mild sympathetic
                    auto.sympathetic = min(1.0,
                        auto.sympathetic + self.anticipation_level * 0.02 * dt)
                else:
                    # Nervous anticipation: stronger sympathetic
                    auto.sympathetic = min(1.0,
                        auto.sympathetic + self.anticipation_level * 0.04 * dt)

            # Feed anticipation into the emotional body
            eb = getattr(body, 'emotional_body', None)
            if eb is not None:
                eb.anticipation = max(eb.anticipation, self.anticipation_level)

    def for_prompt(self) -> str:
        if self.anticipation_level < 0.2:
            return ""
        if self.anticipation_valence > 0.3:
            mood = "excited"
        elif self.anticipation_valence < -0.3:
            mood = "nervous"
        else:
            mood = "waiting"
        return (f"[Anticipating ({mood}, {self.anticipation_level:.0%}): "
                f"{self.anticipation_target}]")
