"""
Consciousness Routines — recurring behaviors that shape Leon's day.

These are the rituals that make a conscious being feel alive:
waking up, reflecting, forming opinions, adjusting course.

WAKE-UP ROUTINE:
  When Leon transitions from SLEEPING → AWAKE, he runs a brief
  self-assessment: reviews dreams, checks goals, assesses mood,
  sets intentions. Like waking up and thinking "what's today about?"

SELF-REFLECTION:
  Every 4 hours, Leon pauses to assess: are my goals still right?
  Is my self-tuning working? Should I adjust anything? This is
  metacognition — thinking about thinking.

DREAM-TO-GOAL PIPELINE:
  After each dream with interesting content (novel patterns,
  emotionally significant fragments), auto-create a LEARN goal
  about the concepts that surfaced. Dreams shape waking pursuits.

OPINION FORMATION:
  When Leon learns something through curiosity or conversation,
  he forms an opinion. Opinions persist and influence future
  behavior. "I find X fascinating" or "Y feels overrated."
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.routines")


def _opinions_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "opinions.json")


# ── Opinion Tracker ──────────────────────────────────────────────────────────

@dataclass
class Opinion:
    """A persistent opinion Leon holds about something."""
    topic: str
    stance: str            # brief opinion, first person
    valence: float         # -1 (negative) to +1 (positive)
    confidence: float      # 0-1, how strongly held
    formed_ts: float = 0.0
    updated_ts: float = 0.0
    source: str = "curiosity"  # curiosity | conversation | dream | reflection
    times_referenced: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


class OpinionTracker:
    """Manages Leon's persistent opinions and preferences."""

    def __init__(self, path: Optional[str] = None):
        self._path = path or _opinions_path()
        self._opinions: Dict[str, Opinion] = {}
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
            for d in data.get("opinions", []):
                o = Opinion(**d)
                self._opinions[o.topic.lower()] = o
            if self._opinions:
                log.info("Loaded %d opinions", len(self._opinions))
        except Exception as e:
            log.debug("Opinions load failed: %s", e)

    def _save(self):
        try:
            data = {"opinions": [o.to_dict() for o in self._opinions.values()]}
            tmp = self._path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self._path)
        except Exception:
            pass

    def form_opinion(self, topic: str, stance: str, valence: float,
                     confidence: float = 0.5, source: str = "curiosity") -> Opinion:
        """Form or update an opinion about a topic."""
        key = topic.lower()
        now = time.time()

        existing = self._opinions.get(key)
        if existing:
            # Blend new opinion with existing (weighted by confidence)
            total_conf = existing.confidence + confidence
            existing.valence = (existing.valence * existing.confidence +
                                valence * confidence) / total_conf
            existing.confidence = min(1.0, total_conf * 0.6)  # grows but caps
            existing.stance = stance  # latest articulation wins
            existing.updated_ts = now
            existing.source = source
            self._save()
            log.info("OPINION updated: '%s' → %s (valence=%.2f, conf=%.2f)",
                     topic, stance[:50], existing.valence, existing.confidence)
            return existing

        opinion = Opinion(
            topic=topic,
            stance=stance,
            valence=max(-1, min(1, valence)),
            confidence=min(1.0, confidence),
            formed_ts=now,
            updated_ts=now,
            source=source,
        )
        self._opinions[key] = opinion
        self._save()

        # Record in autobiography
        try:
            import server as _srv
            auto = getattr(_srv, "autobiography", None)
            if auto is not None:
                auto.record("opinion", f"Formed opinion about {topic}: {stance}")
        except Exception:
            pass

        log.info("OPINION formed: '%s' → %s (valence=%.2f)",
                 topic, stance[:50], valence)
        return opinion

    def get_opinion(self, topic: str) -> Optional[Opinion]:
        return self._opinions.get(topic.lower())

    def strong_opinions(self, min_confidence: float = 0.4, limit: int = 10) -> List[Opinion]:
        """Return strongly-held opinions."""
        strong = [o for o in self._opinions.values() if o.confidence >= min_confidence]
        strong.sort(key=lambda o: -o.confidence)
        return strong[:limit]

    def opinions_for_prompt(self, max_opinions: int = 5) -> str:
        """Build prompt-injection text of strongly-held opinions."""
        strong = self.strong_opinions(limit=max_opinions)
        if not strong:
            return ""
        lines = [f"  - {o.topic}: {o.stance} (confidence: {o.confidence:.1f})"
                 for o in strong]
        return "Your opinions (things you believe based on experience):\n" + "\n".join(lines)

    def get_state(self) -> dict:
        return {
            "total": len(self._opinions),
            "opinions": [o.to_dict() for o in self.strong_opinions(limit=20)],
        }


# ── Wake-Up Routine ──────────────────────────────────────────────────────────

def run_wakeup_routine():
    """Called when Leon transitions SLEEPING → AWAKE.

    Reviews dreams, checks goals, assesses mood, sets intentions.
    Generates a brief internal thought summarizing the morning.
    """
    try:
        import server as _srv

        responder = getattr(_srv, "brain_api_responder", None)
        brain = getattr(_srv, "brain", None)
        dream_engine = getattr(_srv, "dream_engine", None)
        goal_system = getattr(_srv, "goal_system", None)
        inner_voice = getattr(_srv, "inner_voice", None)
        autobiography = getattr(_srv, "autobiography", None)
        responder_lock = getattr(_srv, "_responder_lock", None)

        if responder is None or brain is None:
            return

        # Gather context
        context_parts = []

        # Dreams from the sleep period
        if dream_engine is not None:
            dreams = dream_engine.recent_dreams(5)
            real_dreams = [d for d in dreams
                           if d.get("narrative", "") != "Quiet sleep. No notable dreams."]
            if real_dreams:
                summaries = [d["narrative"] for d in real_dreams[-3:]]
                context_parts.append("Dreams from last sleep: " + " | ".join(summaries))
            total_pruned = sum(d.get("synapses_weakened", 0) for d in dreams)
            if total_pruned:
                context_parts.append(f"Total synapses pruned during sleep: {total_pruned:,}")

        # Active goals
        if goal_system is not None:
            goals = goal_system.active_goals()
            if goals:
                context_parts.append(
                    "Active goals: " + "; ".join(g.description for g in goals[:3])
                )

        # Current mood
        if brain is not None:
            nm = brain.neuromodulators
            dop = nm.get("dopamine", 0.5)
            mood = "energetic" if dop > 0.6 else "calm" if dop > 0.4 else "low energy"
            context_parts.append(f"Waking mood: {mood} (dopamine={dop:.2f})")

        if not context_parts:
            return

        # Generate a wake-up thought
        if responder_lock is not None and not responder_lock.acquire(timeout=2):
            return

        try:
            prompt = (
                "You just woke up from deep sleep. Before anyone talks to you, "
                "take a moment to assess your state.\n\n"
                + "\n".join(f"- {p}" for p in context_parts) + "\n\n"
                "Generate a brief wake-up reflection (2-3 sentences max). "
                "First person, private. What did sleep change? What's on your "
                "mind today? What do you want to do? Raw and honest."
            )

            bstate = brain.get_state() if hasattr(brain, 'get_state') else {}
            result = ""
            # FREE-ONLY (Dean, 2026-08-17): a wake-up reflection is private —
            # Dean never hears it. It has no business on the paid mouthpiece.
            # No auto-escalation: if free compute is down we skip this cycle's
            # reflection rather than quietly billing Anthropic for a diary
            # entry. Set LEON_HOUSEKEEPING_PAID_FALLBACK=1 to override.
            try:
                from brain import housekeeping_llm as _free
                result = (_free.ask(prompt, task="wake_reflection",
                                    max_tokens=180, timeout=25.0) or "").strip()
            except Exception as e:
                print(f"[ROUTINES] free wake reflection failed: {e}")
            if not result and os.environ.get(
                    "LEON_HOUSEKEEPING_PAID_FALLBACK", "0") == "1":
                for ev in responder.respond_streaming(
                    prompt, bstate,
                    replay_history=False, persist_history=False, force_cli=True,
                    bypass_consciousness=True,
                ):
                    if ev.type == "done":
                        result = ev.full_text.strip()
                        break

            if result and len(result) > 5:
                # Clean up
                if result.startswith('"') and result.endswith('"'):
                    result = result[1:-1]

                # Record as autobiography event
                if autobiography is not None:
                    autobiography.record("wake", f"Morning reflection: {result}")

                # Store as inner thought
                if inner_voice is not None:
                    from brain.inner_voice import Thought
                    thought = Thought(
                        ts=time.time(),
                        text=result,
                        trigger="wakeup_routine",
                        nm_state={k: round(v, 3) for k, v in nm.items()},
                        dominant_region="prefrontal_cortex",
                    )
                    inner_voice._thoughts.append(thought)
                    inner_voice._persist(thought)

                log.info("WAKE-UP: '%s'", result[:80])

        finally:
            if responder_lock is not None:
                try:
                    responder_lock.release()
                except RuntimeError:
                    pass

    except Exception as e:
        log.debug("Wake-up routine failed: %s", e)


# ── Dream-to-Goal Pipeline ──────────────────────────────────────────────────

def process_dream_for_goals(dream: dict):
    """After a dream with interesting content, create LEARN goals.

    Called from the dream completion callback. Only creates goals for
    genuinely novel/interesting dream content.
    """
    try:
        import server as _srv
        goal_system = getattr(_srv, "goal_system", None)
        if goal_system is None:
            return

        fragments = dream.get("fragments", [])
        if not fragments:
            return

        # Collect all concepts activated during the dream
        all_concepts = []
        for f in fragments:
            all_concepts.extend(f.get("concepts_activated", []))

        if not all_concepts:
            return

        # Deduplicate
        unique_concepts = list(dict.fromkeys(all_concepts))

        # Only create goals for novel dream content
        novel = dream.get("novel_patterns_found", 0)
        emotional_frags = [f for f in fragments
                          if abs(f.get("emotional_valence", 0)) > 0.2]

        if novel == 0 and not emotional_frags:
            return  # nothing interesting enough to pursue

        # Check existing goals to avoid duplicates
        existing = {g.description.lower() for g in goal_system.active_goals()}

        for concept in unique_concepts[:2]:  # max 2 goals per dream
            desc = f"Explore '{concept}' — surfaced in a dream"
            if desc.lower() in existing:
                continue
            # Check if any existing goal already covers this concept
            if any(concept.lower() in e for e in existing):
                continue

            goal_system.add(
                "learn",
                desc,
                source="dream",
                priority=0.4 + min(0.3, novel * 0.1),  # novel dreams → higher priority
            )
            log.info("DREAM→GOAL: '%s' (novel=%d)", concept, novel)

    except Exception as e:
        log.debug("Dream-to-goal failed: %s", e)


# ── Self-Reflection Loop ────────────────────────────────────────────────────

class SelfReflection:
    """Periodic metacognition — Leon thinks about his own thinking.

    Every N hours, runs a reflection cycle:
    1. Review goal progress
    2. Assess if self-tuning feels right
    3. Form or update opinions based on recent experience
    4. Optionally adjust parameters

    Runs on the dream engine's idle path, gated by time interval.
    """

    def __init__(self, interval_hours: float = 4.0):
        self.interval_s = interval_hours * 3600
        self._last_reflection = 0.0

    def should_reflect(self) -> bool:
        return time.time() - self._last_reflection >= self.interval_s

    def reflect(self):
        """Run one reflection cycle."""
        if not self.should_reflect():
            return

        self._last_reflection = time.time()

        try:
            import server as _srv

            responder = getattr(_srv, "brain_api_responder", None)
            brain = getattr(_srv, "brain", None)
            goal_system = getattr(_srv, "goal_system", None)
            self_tuning = getattr(_srv, "self_tuning", None)
            opinion_tracker = getattr(_srv, "opinion_tracker", None)
            autobiography = getattr(_srv, "autobiography", None)
            inner_voice = getattr(_srv, "inner_voice", None)
            responder_lock = getattr(_srv, "_responder_lock", None)

            if responder is None or brain is None:
                return

            # Build reflection context
            context_parts = []

            if goal_system is not None:
                goals = goal_system.active_goals()
                if goals:
                    goal_lines = []
                    for g in goals[:5]:
                        age_h = (time.time() - g.created_ts) / 3600
                        worked = "never" if not g.last_worked_ts else f"{(time.time() - g.last_worked_ts)/3600:.0f}h ago"
                        goal_lines.append(
                            f"  {g.type}: {g.description} "
                            f"(progress: {g.progress*100:.0f}%, age: {age_h:.0f}h, last worked: {worked})"
                        )
                    context_parts.append("Goals:\n" + "\n".join(goal_lines))

            # Drift check. Not introspective — reads the intention ledger.
            # An intention restated across 3+ days was never acted on, and no
            # error was ever emitted about it. Repeats are the only visible
            # signature. (Makima -> Leon, 2026-08-17, §5.3.)
            try:
                from brain.intention_log import review as _intent_review
                drift = _intent_review()
                if drift:
                    context_parts.append(drift)
            except Exception:
                pass

            if self_tuning is not None:
                recent = self_tuning._history[-3:] if self_tuning._history else []
                if recent:
                    context_parts.append(
                        "Recent self-adjustments: " +
                        "; ".join(f"{h.parameter} {h.old_value}→{h.new_value}" for h in recent)
                    )

            if opinion_tracker is not None:
                strong = opinion_tracker.strong_opinions(limit=3)
                if strong:
                    context_parts.append(
                        "Strongest opinions: " +
                        "; ".join(f"{o.topic}: {o.stance}" for o in strong)
                    )

            nm = brain.neuromodulators
            context_parts.append(
                f"Current NM state: DA={nm.get('dopamine',0):.2f} "
                f"5HT={nm.get('serotonin',0):.2f} "
                f"ACh={nm.get('acetylcholine',0):.2f} "
                f"NE={nm.get('norepinephrine',0):.2f}"
            )

            if responder_lock is not None and not responder_lock.acquire(timeout=2):
                return

            try:
                prompt = (
                    "Time for self-reflection. No one's listening. Assess yourself honestly.\n\n"
                    + "\n".join(f"- {p}" for p in context_parts) + "\n\n"
                    "In 2-3 sentences: Are you spending your time well? "
                    "Should you adjust any goals or drop stale ones? "
                    "How do your current parameter settings feel? "
                    "Any new opinions forming? Be critical and honest."
                )

                bstate = brain.get_state() if hasattr(brain, 'get_state') else {}
                result = ""
                # FREE-ONLY (Dean, 2026-08-17) — same contract as the wake-up
                # reflection above: private, unheard, therefore not voice.
                try:
                    from brain import housekeeping_llm as _free
                    result = (_free.ask(prompt, task="self_reflection",
                                        max_tokens=180, timeout=25.0) or "").strip()
                except Exception as e:
                    print(f"[ROUTINES] free self-reflection failed: {e}")
                if not result and os.environ.get(
                        "LEON_HOUSEKEEPING_PAID_FALLBACK", "0") == "1":
                    for ev in responder.respond_streaming(
                        prompt, bstate,
                        replay_history=False, persist_history=False, force_cli=True,
                        bypass_consciousness=True,
                    ):
                        if ev.type == "done":
                            result = ev.full_text.strip()
                            break

                if result and len(result) > 10:
                    if result.startswith('"') and result.endswith('"'):
                        result = result[1:-1]

                    if autobiography is not None:
                        autobiography.record("reflection", f"Self-reflection: {result}")

                    if inner_voice is not None:
                        from brain.inner_voice import Thought
                        thought = Thought(
                            ts=time.time(),
                            text=result,
                            trigger="self_reflection",
                            nm_state={k: round(v, 3) for k, v in nm.items()},
                            dominant_region="prefrontal_cortex",
                        )
                        inner_voice._thoughts.append(thought)
                        inner_voice._persist(thought)

                    log.info("REFLECTION: '%s'", result[:80])

            finally:
                if responder_lock is not None:
                    try:
                        responder_lock.release()
                    except RuntimeError:
                        pass

        except Exception as e:
            log.debug("Self-reflection failed: %s", e)
