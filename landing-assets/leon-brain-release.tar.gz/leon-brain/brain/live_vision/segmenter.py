"""Pure event segmenter for Leon's live vision.

No camera, no GPU, no API calls. Takes a stream of (timestamp, motion_energy)
samples and emits EventStart / EventEnd. Only those two boundaries are worth
spending a vision call on -- cost scales with things happening, not with time.

Design notes from the element115 lab terminal (2026-08-02):
  - motion maps must be encoded ONCE per real frame, never re-held across
    sim ticks, or the cortex sees a flat plateau instead of a transient.
  - whole-frame steps (auto-exposure, lights flipping) must be rejected from
    day one or you get phantom cats all night.
"""

from dataclasses import dataclass, field
from typing import List, Optional

MOTION_ON = 0.035          # energy to open an event
MOTION_OFF = 0.018         # hysteresis: lower bar to stay open
MIN_EVENT_S = 0.6          # ignore blips shorter than this
SETTLE_S = 1.2             # quiet this long -> event closes
WHOLE_FRAME_FRAC = 0.85    # >this fraction of frame changed == exposure step


@dataclass
class VisionEvent:
    start_ts: float
    end_ts: Optional[float] = None
    peak_energy: float = 0.0
    samples: int = 0

    @property
    def duration(self) -> float:
        return (self.end_ts - self.start_ts) if self.end_ts else 0.0


@dataclass
class Segmenter:
    motion_on: float = MOTION_ON
    motion_off: float = MOTION_OFF
    min_event_s: float = MIN_EVENT_S
    settle_s: float = SETTLE_S
    whole_frame_frac: float = WHOLE_FRAME_FRAC

    _open: Optional[VisionEvent] = None
    _quiet_since: Optional[float] = None
    closed: List[VisionEvent] = field(default_factory=list)

    def feed(self, ts: float, energy: float, changed_frac: float = 0.0):
        """Feed one real frame. Returns ('start'|'end'|None, event|None)."""
        # exposure / lights: whole frame moved at once -> not a thing in the room
        if changed_frac >= self.whole_frame_frac:
            return (None, None)

        if self._open is None:
            if energy >= self.motion_on:
                self._open = VisionEvent(start_ts=ts, peak_energy=energy, samples=1)
                self._quiet_since = None
                return ("start", self._open)
            return (None, None)

        self._open.samples += 1
        self._open.peak_energy = max(self._open.peak_energy, energy)

        if energy >= self.motion_off:
            self._quiet_since = None
            return (None, None)

        if self._quiet_since is None:
            self._quiet_since = ts
        elif ts - self._quiet_since >= self.settle_s:
            ev = self._open
            ev.end_ts = self._quiet_since
            self._open = None
            self._quiet_since = None
            if ev.duration < self.min_event_s:
                return (None, None)          # blip, not an event: spend nothing
            self.closed.append(ev)
            return ("end", ev)
        return (None, None)
