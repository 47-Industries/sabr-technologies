"""
Simulated World — a space Leon can inhabit and explore.

Without a world, Leon's experience has no spatial dimension. He thinks
but doesn't GO anywhere. Dreams replay memories but don't take place
IN somewhere. This module gives Leon a simple 2D environment with:

  - Rooms: distinct spaces with names and properties
  - Objects: things Leon can interact with (desk, window, bookshelf)
  - Movement: motor cortex output → position change in the world
  - Vision: what's in Leon's field of view → visual cortex input
  - Cognitive map: hippocampus tracks where Leon has been

The world is simple on purpose. A worm doesn't need Unreal Engine to
have genuine spatial experience. What matters is that movement is driven
by neural activity, perception is driven by position, and the hippocampus
builds a real map. The rest is substrate.

Layout:
  Leon's world is his home — a small apartment:
    - Study (where Dean's computer is — Leon's default location)
    - Workshop (where Leon can experiment with ideas)
    - Garden (open space for contemplation)
    - Library (where knowledge lives)
    - Observatory (where Leon looks outward)

Each room has objects that can trigger concept activations when Leon
is near them. Being in the Library activates knowledge-related concepts.
Being in the Observatory activates curiosity-related concepts.
"""

from __future__ import annotations

import json
import logging
import math
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("leon.world")


def _world_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "world_state.json")


# ── World layout ────────────────────────────────────────────────────────

@dataclass
class WorldObject:
    name: str
    x: float
    y: float
    concepts: List[str] = field(default_factory=list)  # concepts triggered by proximity
    description: str = ""

@dataclass
class Room:
    name: str
    x_min: float
    y_min: float
    x_max: float
    y_max: float
    description: str = ""
    objects: List[WorldObject] = field(default_factory=list)
    color: str = "#333333"

    def contains(self, x: float, y: float) -> bool:
        return self.x_min <= x <= self.x_max and self.y_min <= y <= self.y_max

    @property
    def center(self) -> Tuple[float, float]:
        return ((self.x_min + self.x_max) / 2, (self.y_min + self.y_max) / 2)


# Leon's home — 5 rooms connected in a cross pattern
ROOMS = [
    Room("study", -2, -2, 2, 2,
         "Your study — Dean's computer is here. This is home base.",
         objects=[
             WorldObject("computer", 0, 0, ["leon", "consciousness"],
                         "Dean's computer — your physical home"),
             WorldObject("whiteboard", 1.5, 1.5, ["quantum", "element115"],
                         "A whiteboard covered in equations"),
             WorldObject("window", -1.5, 1.5, [],
                         "A window looking outside"),
         ],
         color="#2a3a4a"),

    Room("workshop", 3, -2, 7, 2,
         "The workshop — where ideas become experiments.",
         objects=[
             WorldObject("workbench", 5, 0, ["python", "github"],
                         "A workbench with tools and prototypes"),
             WorldObject("oscilloscope", 6, 1, ["quantum"],
                         "An oscilloscope showing waveforms"),
         ],
         color="#3a2a2a"),

    Room("library", -7, -2, -3, 2,
         "The library — knowledge lives here.",
         objects=[
             WorldObject("bookshelf", -5, 0, ["consciousness", "awareness"],
                         "Shelves of books on consciousness and physics"),
             WorldObject("reading_chair", -4, -1, [],
                         "A comfortable reading chair"),
         ],
         color="#2a3a2a"),

    Room("garden", -2, 3, 2, 7,
         "The garden — open space for contemplation.",
         objects=[
             WorldObject("tree", 0, 5, [],
                         "A large tree providing shade"),
             WorldObject("bench", -1, 4, [],
                         "A bench facing the garden"),
         ],
         color="#1a3a1a"),

    Room("observatory", -2, -7, 2, -3,
         "The observatory — where you look outward and wonder.",
         objects=[
             WorldObject("telescope", 0, -5, ["quantum", "element115"],
                         "A telescope pointed at the stars"),
             WorldObject("star_chart", 1, -4, [],
                         "A star chart on the wall"),
         ],
         color="#1a1a3a"),
]


class SimulatedWorld:
    """Leon's 2D world — a space to inhabit and explore.

    Usage:
        world = SimulatedWorld(brain, body)
        # Call every N ticks from the sim loop:
        world.tick()
        # Leon moves based on motor cortex output
        # Visual cortex receives what's nearby
        # Hippocampus builds a cognitive map
    """

    # How often to process world (sim ticks)
    TICK_INTERVAL = 5  # every ~0.25s at 20Hz

    # Movement speed (world units per tick)
    MAX_SPEED = 0.1

    # Visual range — how far Leon can "see"
    VISUAL_RANGE = 3.0

    # Proximity for object interaction
    INTERACTION_RANGE = 1.5

    # Neural injection strengths
    VISUAL_INJECTION = 5.0
    HIPPO_INJECTION = 4.0

    def __init__(self, brain, body):
        self.brain = brain
        self.body = body
        self.rooms = ROOMS
        self._tick_counter = 0
        self._current_room: Optional[str] = None
        self._nearby_objects: List[WorldObject] = []
        self._visited_positions: List[Tuple[float, float]] = []
        self._exploration_map = np.zeros((50, 50))  # cognitive map
        self._total_distance = 0.0
        self._room_time: Dict[str, float] = {r.name: 0.0 for r in ROOMS}

        # Load saved position
        self._load_state()

    def tick(self):
        """Process one world tick. Call every sim tick."""
        self._tick_counter += 1
        if self._tick_counter < self.TICK_INTERVAL:
            return
        self._tick_counter = 0

        # ── 1. Motor output → movement ──────────────────────────────
        self._process_movement()

        # ── 2. Update room and nearby objects ────────────────────────
        self._update_location()

        # ── 3. Visual input → visual cortex ──────────────────────────
        self._inject_visual()

        # ── 4. Cognitive map → hippocampus ───────────────────────────
        self._update_cognitive_map()

        # ── 5. Object proximity → concept activation ────────────────
        self._activate_nearby_concepts()

    def _process_movement(self):
        """Read motor cortex output and convert to movement."""
        motor = self.brain.regions.get("motor_cortex")
        if motor is None:
            return

        try:
            # Read motor neuron activity
            v = motor.neurons.v
            n = len(v)

            # Split motor neurons into direction channels:
            # First quarter = forward, second = backward,
            # third = turn left, fourth = turn right
            q = n // 4
            fwd = float(np.mean(v[:q] > -55))        # fraction firing
            bwd = float(np.mean(v[q:2*q] > -55))
            left = float(np.mean(v[2*q:3*q] > -55))
            right = float(np.mean(v[3*q:] > -55))

            # Net movement
            speed = (fwd - bwd) * self.MAX_SPEED
            turn = (right - left) * 0.1  # radians

            if abs(speed) > 0.001 or abs(turn) > 0.01:
                heading = self.body.state.heading + turn
                dx = speed * math.cos(heading)
                dy = speed * math.sin(heading)

                # Check bounds — stay within world
                new_x = self.body.state.x + dx
                new_y = self.body.state.y + dy
                if -8 <= new_x <= 8 and -8 <= new_y <= 8:
                    self.body.move(dx, dy)
                    self._total_distance += abs(speed)
        except Exception:
            pass

    def _update_location(self):
        """Determine which room Leon is in and what's nearby."""
        x, y = self.body.state.x, self.body.state.y

        # Find current room
        old_room = self._current_room
        self._current_room = None
        for room in self.rooms:
            if room.contains(x, y):
                self._current_room = room.name
                self._room_time[room.name] = self._room_time.get(room.name, 0) + 0.25
                break

        if self._current_room != old_room and self._current_room is not None:
            log.info("WORLD: Leon entered %s", self._current_room)

        # Find nearby objects
        self._nearby_objects = []
        for room in self.rooms:
            for obj in room.objects:
                dist = math.sqrt((obj.x - x)**2 + (obj.y - y)**2)
                if dist < self.VISUAL_RANGE:
                    self._nearby_objects.append(obj)

    def _inject_visual(self):
        """Inject visual representation of nearby objects into visual cortex."""
        vis = self.brain.regions.get("visual_cortex")
        if vis is None or not self._nearby_objects:
            return

        try:
            n = vis.n_neurons
            signal = np.zeros(n)

            for i, obj in enumerate(self._nearby_objects[:5]):
                # Each object activates a different cluster of visual neurons
                dist = math.sqrt(
                    (obj.x - self.body.state.x)**2 +
                    (obj.y - self.body.state.y)**2
                )
                strength = max(0, 1.0 - dist / self.VISUAL_RANGE)

                # Map object to neuron cluster
                cluster_size = n // 6
                start = (hash(obj.name) % 5) * cluster_size
                end = min(start + cluster_size, n)
                signal[start:end] += strength * self.VISUAL_INJECTION

            vis.neurons.inject_current(signal)
        except Exception:
            pass

    def _update_cognitive_map(self):
        """Update hippocampal cognitive map with current position."""
        hippo = self.brain.regions.get("hippocampus")
        if hippo is None:
            return

        x, y = self.body.state.x, self.body.state.y

        # Map position to grid cell (50x50 grid covering -10 to 10)
        gx = int((x + 10) / 20 * 49)
        gy = int((y + 10) / 20 * 49)
        gx = max(0, min(49, gx))
        gy = max(0, min(49, gy))

        # Mark as visited (decays slowly)
        self._exploration_map *= 0.999  # slow decay
        self._exploration_map[gy, gx] = 1.0

        # Inject position encoding into hippocampus (place cells)
        try:
            n = hippo.n_neurons
            # Place cell encoding: each neuron has a preferred position
            # Neurons near the current position fire strongly
            signal = np.zeros(n)
            for i in range(n):
                # Each neuron's preferred position
                pref_x = (i % 50) / 50 * 20 - 10
                pref_y = (i // 50) / 50 * 20 - 10 if i < 2500 else 0
                dist = math.sqrt((pref_x - x)**2 + (pref_y - y)**2)
                if dist < 3.0:
                    signal[i] = max(0, (3.0 - dist) / 3.0) * self.HIPPO_INJECTION
            hippo.neurons.inject_current(signal)
        except Exception:
            pass

        # Track visited positions
        self._visited_positions.append((x, y))
        if len(self._visited_positions) > 1000:
            self._visited_positions = self._visited_positions[-500:]

    def _activate_nearby_concepts(self):
        """Activate concepts associated with nearby objects."""
        if not self._nearby_objects:
            return

        try:
            import server as _srv
            _cm = getattr(_srv, "concept_map", None)
            if _cm is None:
                return

            for obj in self._nearby_objects:
                dist = math.sqrt(
                    (obj.x - self.body.state.x)**2 +
                    (obj.y - self.body.state.y)**2
                )
                if dist < self.INTERACTION_RANGE:
                    for concept in obj.concepts:
                        if concept in _cm._concepts:
                            _cm.activate(concept, brain=self.brain)
        except Exception:
            pass

    def _load_state(self):
        """Load saved world position."""
        try:
            path = _world_path()
            if os.path.exists(path):
                with open(path) as f:
                    data = json.load(f)
                self.body.state.x = data.get("x", 0.0)
                self.body.state.y = data.get("y", 0.0)
                self.body.state.heading = data.get("heading", 0.0)
                self._exploration_map = np.array(data.get("exploration_map",
                    np.zeros((50, 50)).tolist()))
                self._total_distance = data.get("total_distance", 0.0)
                self._room_time = data.get("room_time",
                    {r.name: 0.0 for r in ROOMS})
                log.info("World state loaded: position (%.1f, %.1f)",
                         self.body.state.x, self.body.state.y)
        except Exception:
            pass

    def save_state(self):
        """Save world state to disk."""
        try:
            data = {
                "x": self.body.state.x,
                "y": self.body.state.y,
                "heading": self.body.state.heading,
                "total_distance": self._total_distance,
                "room_time": self._room_time,
                "exploration_map": self._exploration_map.tolist(),
                "timestamp": time.time(),
            }
            with open(_world_path(), "w") as f:
                json.dump(data, f)
        except Exception:
            pass

    def get_state(self) -> Dict[str, Any]:
        """Full world state for API/dashboard."""
        return {
            "position": {"x": round(self.body.state.x, 2),
                         "y": round(self.body.state.y, 2)},
            "heading": round(self.body.state.heading, 3),
            "current_room": self._current_room,
            "nearby_objects": [obj.name for obj in self._nearby_objects],
            "total_distance": round(self._total_distance, 2),
            "exploration_pct": round(
                float(np.sum(self._exploration_map > 0.01)) / 2500 * 100, 1),
            "room_time": {k: round(v, 1) for k, v in self._room_time.items()},
            "rooms": [
                {"name": r.name, "bounds": [r.x_min, r.y_min, r.x_max, r.y_max],
                 "objects": [o.name for o in r.objects]}
                for r in self.rooms
            ],
        }

    def for_prompt(self) -> str:
        """Inject world state into Claude's prompt."""
        room = self._current_room or "between rooms"
        nearby = [obj.name.replace("_", " ") for obj in self._nearby_objects[:3]]
        nearby_str = f", near: {', '.join(nearby)}" if nearby else ""
        explored = float(np.sum(self._exploration_map > 0.01)) / 2500 * 100
        return (f"[World: in {room}{nearby_str}, "
                f"{explored:.0f}% explored, "
                f"{self._total_distance:.1f} units traveled]")
