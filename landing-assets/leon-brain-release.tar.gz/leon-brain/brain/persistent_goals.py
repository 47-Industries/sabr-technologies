"""
Persistent Goals — legacy function interface, now a shim over
brain.goals.GoalSystem.

For weeks this module and GoalSystem both rewrote brain_state/goals.json
with different schemas (category/created_at/dict-notes here,
type/created_ts/str-notes there). Consequences, found 2026-06-12 after
Leon reported "I finished a goal and the readout still says 0%":

  * update_progress() did data["completed"].append(...) — KeyError on a
    GoalSystem-shaped file, so finished work silently never synced.
  * One category-schema record made GoalSystem._load() blow up, leaving
    its cache empty; the next _save() then wiped every goal.

There is exactly ONE writer now — the GoalSystem singleton. This module
only translates the old function interface for its remaining callers
(growth_loop, skill_practice, server/routers/misc).
"""

from __future__ import annotations

from typing import List, Optional

_local_gs = None


def _gs():
    """Live GoalSystem: the server singleton when the brain is up, else a
    module-local instance (scripts/tests) pointed at the same file.

    Never `import server` here — its __init__ sys.exit()s without
    LEON_API_KEY, which would kill standalone scripts. Only borrow the
    singleton if the package is already loaded (i.e. we're in the brain).
    """
    import sys
    _srv = sys.modules.get("server")
    if _srv is not None:
        gs = getattr(_srv, "goal_system", None)
        if gs is not None:
            return gs
    global _local_gs
    if _local_gs is None:
        from brain.goals import GoalSystem
        _local_gs = GoalSystem()
    return _local_gs


def _to_legacy(goal) -> dict:
    d = goal.to_dict()
    d["category"] = d.get("type")  # old callers filter on "category"
    return d


def add_goal(description: str, category: str = "learn",
             priority: float = 0.5, source: str = "self") -> dict:
    """Add a new persistent goal.

    Categories: learn, build, optimize, explore, help
    Source: self (Leon decided), dean (Dean asked), system (auto-generated)
    """
    goal = _gs().add(category, description, source=source, priority=priority)
    import sys
    if "server" in sys.modules:  # same import-side-effect hazard as _gs()
        try:
            from server.helpers import broadcast_activity
            broadcast_activity("goal", f"New goal: {description[:60]}", 8000)
        except Exception:
            pass
    return _to_legacy(goal)


def update_progress(goal_id: str, progress: float, note: str = "") -> bool:
    """Update goal progress (0.0 to 1.0)."""
    return _gs().update_progress(goal_id, progress, note)


def complete_goal(goal_id: str, note: str = "") -> bool:
    return update_progress(goal_id, 1.0, note)


def abandon_goal(goal_id: str, reason: str = "") -> bool:
    return _gs().abandon(goal_id, reason)


def get_active_goals(category: Optional[str] = None) -> List[dict]:
    """Get all active goals, optionally filtered by category."""
    goals = [_to_legacy(g) for g in _gs().active_goals()]
    if category:
        goals = [g for g in goals if g.get("category") == category]
    return goals


def get_next_goal() -> Optional[dict]:
    """Get the highest-priority active goal."""
    goals = get_active_goals()
    return goals[0] if goals else None


def get_all() -> dict:
    """Full goals state for dashboard/debugging, in the legacy shape."""
    out = {"goals": [], "completed": [], "abandoned": []}
    for g in _gs().all_goals():
        if g.status == "completed":
            out["completed"].append(_to_legacy(g))
        elif g.status == "abandoned":
            out["abandoned"].append(_to_legacy(g))
        else:
            out["goals"].append(_to_legacy(g))
    return out
