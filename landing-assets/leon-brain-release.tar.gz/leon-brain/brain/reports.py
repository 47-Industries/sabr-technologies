"""JARVIS-style synthesis reports — Leon's "tying it all together" layer.

Each tool composes data from the existing tool surface (memory_extras,
introspection, info_tools, browser_apps, routines, knowledge_store) into
a single human-readable summary. Used by:

  - the morning_briefing routine (vocalized by Piper at 7am)
  - Dean's "give me a status report" voice commands
  - the dashboard observation feed
  - end-of-day summaries

All tools are brain-local — they call sibling modules in-process rather
than going through the actuator socket. Output is plain text Markdown
which TTS handles cleanly.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from brain.timefmt import fmt as _timefmt


def _safe_call(fn, args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Wrap a tool call so a single failure doesn't tank the whole report."""
    try:
        out = fn(args or {})
        if isinstance(out, dict):
            return out
        return {"ok": True, "result": out}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _intro_tools():
    from brain.introspection import EXTRA_TOOLS
    return EXTRA_TOOLS


def _memory_tools():
    from brain.memory_extras import EXTRA_TOOLS
    return EXTRA_TOOLS


def _actuator_call(tool: str, args: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Call an actuator-side tool via the existing JSON-RPC bridge."""
    args = args or {}
    try:
        from brain.actuator_client import call
        return call(tool, args)
    except Exception as e:
        return {"ok": False, "error": f"actuator call failed: {type(e).__name__}: {e}"}


def _daily_briefing(args: Dict[str, Any]) -> Dict[str, Any]:
    """Compose Dean's morning briefing — vocalized at 7am by morning_briefing routine.

    Args:
      location: city for weather (default: 'Los Angeles')
      include_news: pull top HN stories (default: True)
      include_calendar: pull upcoming events (default: True; needs openclaw OAuth)
      max_news: how many news items (default: 3)
    """
    location = args.get("location", "Los Angeles")
    include_news = args.get("include_news", True)
    include_calendar = args.get("include_calendar", True)
    max_news = int(args.get("max_news", 3))

    lines: List[str] = []
    now = datetime.now()
    lines.append(f"# Morning briefing — {_timefmt(now, '%A, %B %d %Y, %-I:%M %p')}")
    lines.append("")

    # 1. Weather
    w = _actuator_call("info.weather_now", {"location": location})
    if w.get("ok"):
        r = w.get("result", w)
        temp = r.get("temp_f") or r.get("temperature_f")
        desc = r.get("description") or r.get("weather_desc")
        if temp is not None:
            lines.append(f"**Weather** — {location}: {temp}°F, {desc or 'clear'}.")
    else:
        lines.append(f"_(weather unavailable: {w.get('error','?')})_")

    # 2. Mood trend
    mem = _memory_tools()
    if "memory.mood_recent_trend" in mem:
        mood = _safe_call(mem["memory.mood_recent_trend"], {"days": 7})
        if mood.get("ok"):
            avg = mood.get("avg_valence") or mood.get("trend")
            if avg is not None:
                lines.append(f"**Mood (7d trend):** {avg}")

    # 3. Today's calendar — try openclaw MCP calendar endpoint via actuator? skip if not present
    if include_calendar:
        # Best-effort calendar via existing knowledge_store / openclaw if registered
        # (we don't depend on it — failure is silent)
        pass

    # 4. News
    if include_news:
        n = _actuator_call("info.news_hackernews_top", {"limit": max_news})
        if n.get("ok"):
            r = n.get("result", n)
            # Result can be either a list of story dicts OR a dict wrapping one
            if isinstance(r, list):
                stories = r
            elif isinstance(r, dict):
                stories = r.get("stories") or r.get("items") or r.get("result") or []
            else:
                stories = []
            if stories:
                lines.append("")
                lines.append(f"**Top {len(stories)} from Hacker News:**")
                for i, s in enumerate(stories[:max_news], 1):
                    if not isinstance(s, dict):
                        continue
                    title = s.get("title") or s.get("text", "?")
                    score = s.get("score") or s.get("points")
                    lines.append(f"  {i}. {title}" + (f" ({score})" if score else ""))

    # 5. Yesterday's Leon activity
    intro = _intro_tools()
    if "audit.postmortem_yesterday" in intro:
        pm = _safe_call(intro["audit.postmortem_yesterday"], {})
        if pm.get("ok"):
            summary = pm.get("summary") or pm.get("postmortem", {}).get("summary")
            if summary:
                lines.append("")
                lines.append(f"**Yesterday's Leon postmortem:** {summary}")

    # 6. Decisions pending review
    if "memory.decision_list_recent" in mem:
        dec = _safe_call(mem["memory.decision_list_recent"], {"limit": 3})
        if dec.get("ok"):
            inner = dec.get("result", dec)
            d = inner.get("decisions") if isinstance(inner, dict) else (inner if isinstance(inner, list) else [])
            if d:
                lines.append("")
                lines.append("**Recent decisions worth re-reading:**")
                for entry in d[:3]:
                    if not isinstance(entry, dict):
                        continue
                    topic = entry.get("topic", "?")
                    when = entry.get("date") or entry.get("created_at") or entry.get("ts", "")
                    lines.append(f"  - {topic} ({when})")

    text = "\n".join(lines)
    return {
        "ok": True,
        "report": text,
        "location": location,
        "generated_at": now.isoformat(),
        "byte_size": len(text),
    }


def _end_of_day(args: Dict[str, Any]) -> Dict[str, Any]:
    """Compose Dean's end-of-day summary — vocalized at 6pm.

    Pulls today's audit, episode log, decisions, mood entries.
    """
    lines: List[str] = []
    now = datetime.now()
    lines.append(f"# End-of-day — {_timefmt(now, '%A, %B %d %Y, %-I:%M %p')}")
    lines.append("")

    intro = _intro_tools()
    mem = _memory_tools()

    # 1. Today's high-level activity
    if "audit.today_overview" in intro:
        ov = _safe_call(intro["audit.today_overview"], {})
        if ov.get("ok"):
            inner = ov.get("result", ov)
            actuator = inner.get("actuator", {}) if isinstance(inner, dict) else {}
            tool_count = actuator.get("total_calls", 0)
            err = actuator.get("errors", 0)
            top_tools = actuator.get("top_tools", [])
            lines.append(f"**Activity:** {tool_count} tool calls today ({err} errors).")
            if top_tools:
                top_names = [t.get("tool") if isinstance(t, dict) else str(t) for t in top_tools[:5]]
                lines.append(f"  Top: {', '.join(filter(None, top_names))}")

    # Helper for memory tools that wrap their list in {result: {decisions: [...]}}
    def _unwrap_list(obj, *keys):
        if isinstance(obj, list):
            return obj
        if not isinstance(obj, dict):
            return []
        inner = obj.get("result", obj)
        if isinstance(inner, list):
            return inner
        if isinstance(inner, dict):
            for k in keys:
                if k in inner and isinstance(inner[k], list):
                    return inner[k]
        return []

    # 2. Today's episodes (memory)
    if "memory.episode_search" in mem:
        eps = _safe_call(mem["memory.episode_search"], {"keyword": ""})
        if eps.get("ok"):
            episodes = _unwrap_list(eps, "episodes", "items")
            today_unix = time.time() - 86400
            today_eps = [
                e for e in episodes
                if isinstance(e, dict) and (e.get("ts", 0) > today_unix)
            ]
            if today_eps:
                lines.append("")
                lines.append(f"**Episodes logged today ({len(today_eps)}):**")
                for e in today_eps[:5]:
                    desc = e.get("event") or e.get("description") or "?"
                    lines.append(f"  - {str(desc)[:100]}")

    # 3. Today's decisions
    if "memory.decision_list_recent" in mem:
        dec = _safe_call(mem["memory.decision_list_recent"], {"limit": 10})
        if dec.get("ok"):
            decisions = _unwrap_list(dec, "decisions", "items")
            today_unix = time.time() - 86400
            today_dec = [x for x in decisions if isinstance(x, dict) and x.get("ts", 0) > today_unix]
            if today_dec:
                lines.append("")
                lines.append(f"**Decisions logged today ({len(today_dec)}):**")
                for x in today_dec[:5]:
                    lines.append(f"  - {x.get('topic','?')}: {(x.get('decision') or '')[:80]}")

    # 4. Mood trajectory
    if "memory.mood_recent_trend" in mem:
        mood = _safe_call(mem["memory.mood_recent_trend"], {"days": 3})
        if mood.get("ok"):
            avg = mood.get("avg_valence") or mood.get("trend")
            if avg is not None:
                lines.append("")
                lines.append(f"**Mood trend (3d):** {avg}")

    # 5. Anomalies
    if "audit.anomaly_detector" in intro:
        an = _safe_call(intro["audit.anomaly_detector"], {})
        if an.get("ok"):
            anomalies = _unwrap_list(an, "anomalies", "items")
            if anomalies:
                lines.append("")
                lines.append(f"**Anomalies detected today ({len(anomalies)}):**")
                for a in anomalies[:3]:
                    if isinstance(a, dict):
                        tool = a.get("tool", "?")
                        kind = a.get("kind", "")
                        cnt = a.get("today_count", 0)
                        lines.append(f"  - `{tool}`: {cnt} calls ({kind})")

    text = "\n".join(lines)
    return {
        "ok": True,
        "report": text,
        "generated_at": now.isoformat(),
        "byte_size": len(text),
    }


def _capability_summary(args: Dict[str, Any]) -> Dict[str, Any]:
    """Produce a roll-up of Leon's current tool surface — what he can DO right
    now, grouped by category. Useful for 'what can you do?' queries.

    Args:
      group: 'category' | 'risk' (default: 'category')
    """
    group = args.get("group", "category")
    try:
        from brain.actuator_client import ANTHROPIC_TOOLS, TOOL_RISK
    except ImportError:
        return {"ok": False, "error": "actuator_client not importable"}

    categories: Dict[str, List[str]] = {}
    for t in ANTHROPIC_TOOLS:
        name = t.get("name", "")
        # category = prefix before first underscore (heuristic)
        if name.startswith("info_"):       cat = "info"
        elif name.startswith("memory_"):   cat = "memory"
        elif name.startswith("audit_"):    cat = "audit"
        elif name.startswith("browser_youtube_"): cat = "youtube"
        elif name.startswith("browser_gmail_"):   cat = "gmail"
        elif name.startswith("browser_"):  cat = "browser"
        elif name.startswith("window_"):   cat = "window"
        elif name.startswith("mouse_"):    cat = "mouse"
        elif name.startswith("keyboard_"): cat = "keyboard"
        elif name.startswith("file_"):     cat = "file"
        elif name.startswith("system_"):   cat = "system"
        elif name.startswith("process_"):  cat = "process"
        elif name.startswith("shell_"):    cat = "shell"
        elif name.startswith("spotify_"):  cat = "spotify"
        elif name.startswith("tentacle_"): cat = "tentacle"
        elif name.startswith("board_"):    cat = "agent_board"
        elif name.startswith("clipboard_"):cat = "clipboard"
        elif name.startswith("workspace_"):cat = "workspace"
        elif name.startswith("vscode_"):   cat = "vscode"
        elif name.startswith("undo_"):     cat = "undo"
        elif name.startswith("prompt_"):   cat = "prompt"
        elif name.startswith("routine_"):  cat = "routine"
        elif name.startswith("reminder_"): cat = "reminder"
        else:
            cat = "misc"
        categories.setdefault(cat, []).append(name)

    if group == "risk":
        risk_groups: Dict[str, int] = {}
        for t in ANTHROPIC_TOOLS:
            r = TOOL_RISK.get(t.get("name", ""), "medium")
            risk_groups[r] = risk_groups.get(r, 0) + 1
        return {
            "ok": True,
            "by_risk": risk_groups,
            "total": sum(risk_groups.values()),
        }

    summary = {cat: len(names) for cat, names in sorted(categories.items())}
    return {
        "ok": True,
        "by_category": summary,
        "total": sum(summary.values()),
        "category_count": len(summary),
        "sample_tools": {cat: names[:3] for cat, names in categories.items()},
    }


def _status_pulse(args: Dict[str, Any]) -> Dict[str, Any]:
    """One-line heartbeat: "Leon online — N tools, K routines firing, M tentacles
    active, last action: X". Designed for the dashboard heartbeat chip.
    """
    intro = _intro_tools()
    lines = []
    # Tool count
    try:
        from brain.actuator_client import ANTHROPIC_TOOLS
        n_tools = len(ANTHROPIC_TOOLS)
    except Exception:
        n_tools = 0

    # Tentacle count
    n_tentacles = 0
    try:
        from brain.tentacle_orchestration import _list_active
        r = _list_active({})
        n_tentacles = r.get("count", 0)
    except Exception:
        pass

    # Routines firing
    n_routines = 0
    try:
        from brain.routines import routine_list  # type: ignore
        rs = routine_list()
        n_routines = len([x for x in rs.get("routines", []) if x.get("enabled")])
    except Exception:
        pass

    # Last audit line
    last_action = None
    if "audit.today" in intro:
        a = _safe_call(intro["audit.today"], {"limit": 1})
        if a.get("ok"):
            entries = a.get("entries") or a.get("result", [])
            if entries:
                last = entries[-1] if isinstance(entries, list) else entries
                if isinstance(last, dict):
                    last_action = last.get("tool") or last.get("name")

    pulse = f"Leon online — {n_tools} tools, {n_routines} routines firing, {n_tentacles} tentacles active"
    if last_action:
        pulse += f", last action: {last_action}"
    return {
        "ok": True,
        "pulse": pulse,
        "tools": n_tools,
        "tentacles": n_tentacles,
        "routines": n_routines,
        "last_action": last_action,
        "timestamp": time.time(),
    }


def _project_status_roundup(args: Dict[str, Any]) -> Dict[str, Any]:
    """For each tentacle in the agent-board registry, peek at last activity and
    return a one-line status. Helps Dean answer "how are all my projects doing?"

    Args:
      include_dead: include tentacles with no recent activity (default: False)
    """
    include_dead = args.get("include_dead", False)
    try:
        from brain.tentacle_orchestration import _list_active, _peek_tail
    except ImportError:
        return {"ok": False, "error": "tentacle_orchestration not importable"}

    actives = _list_active({}).get("tentacles", [])
    rows = []
    for t in actives:
        nm = t.get("name", "?")
        if nm == "bash":
            continue
        peek = _peek_tail({"name": nm, "lines": 15})
        content = peek.get("content", "")
        last_non_empty = [l for l in content.split("\n") if l.strip()][-1:] if content else []
        rows.append({
            "tentacle": nm,
            "last_line": last_non_empty[0] if last_non_empty else "",
            "alive": bool(last_non_empty),
        })
    if not include_dead:
        rows = [r for r in rows if r["alive"]]

    return {
        "ok": True,
        "tentacles": rows,
        "count": len(rows),
    }


EXTRA_TOOLS = {
    "report.daily_briefing":        _daily_briefing,
    "report.end_of_day":            _end_of_day,
    "report.capability_summary":    _capability_summary,
    "report.status_pulse":          _status_pulse,
    "report.project_status_roundup":_project_status_roundup,
}
