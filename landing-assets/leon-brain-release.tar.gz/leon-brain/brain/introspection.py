"""
Leon's self-introspection toolbox.

Lets Leon read his own audit trail and reason about his own behaviour:

  - What did I do today / yesterday?
  - Which tools are erroring most?
  - Anything anomalous about today's usage?
  - Where am I missing capabilities?
  - What's my system-prompt version history?
  - Undo my last risky action.

All tools follow the actuator contract — each takes a single `args` dict
and returns `{ok: True, result: ...}` or `{ok: False, error: ...}`. Tools
are wired up via the `EXTRA_TOOLS` dict at the bottom so the responder /
actuator can register them with one import.

Data sources:
  brain_state/actuator-audit.jsonl   — every Leon tool call
  brain_state/routines-audit.jsonl   — every routine firing
  brain_state/undo-log.jsonl         — recorded reverse-commands
  brain_state/prompt_versions/       — saved system-prompt snapshots

The module is intentionally defensive: missing files return empty results
instead of raising, malformed JSONL rows are skipped silently, and every
function is wrapped so an unexpected exception is reported as
`{ok: False, error: "..."}` rather than propagating.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple


# ── Paths ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE_DIR = os.path.join(PROJECT_ROOT, "brain_state")
ACTUATOR_AUDIT_PATH = os.path.join(STATE_DIR, "actuator-audit.jsonl")
ROUTINES_AUDIT_PATH = os.path.join(STATE_DIR, "routines-audit.jsonl")
UNDO_LOG_PATH = os.path.join(STATE_DIR, "undo-log.jsonl")
PROMPT_VERSIONS_DIR = os.path.join(STATE_DIR, "prompt_versions")


# ── Small helpers ────────────────────────────────────────────────────────
def _ok(result: Any) -> Dict[str, Any]:
    return {"ok": True, "result": result}


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _safe_tool(fn):
    """Wrap a tool so any unhandled exception becomes a clean error dict."""
    def _inner(args: Dict[str, Any]) -> Dict[str, Any]:
        try:
            return fn(args or {})
        except Exception as e:
            return _err(f"{type(e).__name__}: {e}")
    _inner.__name__ = fn.__name__
    _inner.__doc__ = fn.__doc__
    return _inner


def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    """Stream a JSONL file into a list of dicts. Missing file → []. Bad
    lines are skipped silently."""
    if not os.path.exists(path):
        return []
    rows: List[Dict[str, Any]] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return rows
    return rows


def _parse_since(spec: Any) -> Optional[float]:
    """Parse a since-spec into a unix timestamp. Accepts:
      - None / ""            → None (no lower bound)
      - "today"              → midnight today (local)
      - "yesterday"          → midnight yesterday (local)
      - "7d" / "24h" / "30m" → relative duration ago
      - ISO date / datetime  → parsed via datetime.fromisoformat
      - int / float          → treated as a unix timestamp directly
    """
    if spec is None or spec == "":
        return None
    if isinstance(spec, (int, float)):
        return float(spec)
    s = str(spec).strip().lower()
    now = time.time()
    if s == "today":
        d = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        return d.timestamp()
    if s == "yesterday":
        d = (datetime.now() - timedelta(days=1)).replace(
            hour=0, minute=0, second=0, microsecond=0,
        )
        return d.timestamp()
    m = re.match(r"^(\d+(?:\.\d+)?)\s*([smhd])$", s)
    if m:
        n = float(m.group(1))
        unit = m.group(2)
        seconds = n * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
        return now - seconds
    # Try ISO-ish strings — datetime.fromisoformat handles "YYYY-MM-DD" and
    # "YYYY-MM-DDTHH:MM:SS[+TZ]". Fall back to a couple of strptime formats.
    try:
        dt = datetime.fromisoformat(s)
        return dt.timestamp()
    except Exception:
        pass
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except Exception:
            continue
    return None


def _today_bounds() -> Tuple[float, float]:
    """(midnight today, now) as unix timestamps."""
    now = datetime.now()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return midnight.timestamp(), time.time()


def _yesterday_bounds() -> Tuple[float, float]:
    """(midnight yesterday, midnight today) as unix timestamps."""
    today_mid = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    yest_mid = today_mid - timedelta(days=1)
    return yest_mid.timestamp(), today_mid.timestamp()


def _filter_window(rows: List[Dict[str, Any]],
                   since: Optional[float],
                   until: Optional[float]) -> List[Dict[str, Any]]:
    """Filter audit rows by ts ∈ [since, until]. None means unbounded."""
    out = []
    for r in rows:
        ts = r.get("ts") or r.get("timestamp") or 0
        try:
            ts = float(ts)
        except Exception:
            continue
        if since is not None and ts < since:
            continue
        if until is not None and ts > until:
            continue
        out.append(r)
    return out


def _fmt_ts(ts: float) -> str:
    try:
        return datetime.fromtimestamp(float(ts)).isoformat(timespec="seconds")
    except Exception:
        return str(ts)


def _summarise_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute totals/top-tools/error stats over an already-filtered slice."""
    total = len(rows)
    errors = 0
    tool_counts: Counter = Counter()
    error_counts: Counter = Counter()
    for r in rows:
        tool = r.get("tool") or r.get("name") or "?"
        tool_counts[tool] += 1
        if r.get("ok") is False or r.get("error"):
            errors += 1
            error_counts[tool] += 1
    top_tools = [{"tool": t, "count": c} for t, c in tool_counts.most_common(10)]
    error_rate = (errors / total) if total else 0.0
    pretty = (
        f"{total} calls, {errors} errors ({error_rate * 100:.1f}%). "
        f"Top: {', '.join(f'{t}={c}' for t, c in tool_counts.most_common(5)) or '(none)'}."
    )
    return {
        "total_calls": total,
        "error_count": errors,
        "error_rate": round(error_rate, 4),
        "top_tools": top_tools,
        "top_error_tools": [
            {"tool": t, "errors": c} for t, c in error_counts.most_common(5)
        ],
        "pretty": pretty,
    }


# ════════════════════════════════════════════════════════════════════════
#  AUDIT QUERIES
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def audit_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """Last-24h actuator audit entries (most recent first), capped to limit."""
    limit = int(args.get("limit", 50) or 50)
    since = time.time() - 24 * 3600
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, None)
    rows.sort(key=lambda r: r.get("ts", 0), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ts": r.get("ts"),
            "ts_iso": _fmt_ts(r.get("ts", 0)),
            "tool": r.get("tool"),
            "ok": bool(r.get("ok")),
            "error": r.get("error"),
        })
    return _ok({"count": len(out), "entries": out})


@_safe_tool
def audit_summary_today(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Today's stats — totals, top tools, error count, error rate."""
    since, until = _today_bounds()
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, until)
    summary = _summarise_rows(rows)
    summary["since_iso"] = _fmt_ts(since)
    summary["until_iso"] = _fmt_ts(until)
    return _ok(summary)


@_safe_tool
def audit_summary_range(args: Dict[str, Any]) -> Dict[str, Any]:
    """Same as audit_summary_today but over a custom range.

    Args:
      since_iso (required): "today" / "yesterday" / "7d" / ISO string / unix ts
      until_iso (optional): same forms; default = now
    """
    since_spec = args.get("since_iso") or args.get("since")
    until_spec = args.get("until_iso") or args.get("until")
    if since_spec is None:
        return _err("since_iso is required")
    since = _parse_since(since_spec)
    if since is None:
        return _err(f"could not parse since_iso={since_spec!r}")
    until = _parse_since(until_spec) if until_spec else time.time()
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, until)
    summary = _summarise_rows(rows)
    summary["since_iso"] = _fmt_ts(since)
    summary["until_iso"] = _fmt_ts(until) if until else None
    return _ok(summary)


@_safe_tool
def audit_by_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent calls of one specific tool, with full args + result."""
    tool = (args.get("tool") or "").strip()
    if not tool:
        return _err("tool is required")
    limit = int(args.get("limit", 30) or 30)
    rows = [r for r in _read_jsonl(ACTUATOR_AUDIT_PATH)
            if (r.get("tool") or r.get("name")) == tool]
    rows.sort(key=lambda r: r.get("ts", 0), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ts": r.get("ts"),
            "ts_iso": _fmt_ts(r.get("ts", 0)),
            "tool": r.get("tool"),
            "args": r.get("args"),
            "ok": bool(r.get("ok")),
            "error": r.get("error"),
        })
    return _ok({"tool": tool, "count": len(out), "entries": out})


@_safe_tool
def audit_errors_today(args: Dict[str, Any]) -> Dict[str, Any]:
    """Only the failed actuator calls from today, with full error text."""
    limit = int(args.get("limit", 30) or 30)
    since, until = _today_bounds()
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, until)
    errs = [r for r in rows if r.get("ok") is False or r.get("error")]
    errs.sort(key=lambda r: r.get("ts", 0), reverse=True)
    out = []
    for r in errs[:limit]:
        out.append({
            "ts": r.get("ts"),
            "ts_iso": _fmt_ts(r.get("ts", 0)),
            "tool": r.get("tool"),
            "args": r.get("args"),
            "error": r.get("error"),
        })
    return _ok({"count": len(out), "entries": out})


@_safe_tool
def audit_tool_usage_stats(args: Dict[str, Any]) -> Dict[str, Any]:
    """Per-tool count, ok_rate, avg/p99 latency over the last `days` days.

    Latency is read from a `duration_s` field if present; if no entry has
    one we still return the count/ok-rate but tag latency fields as None.
    """
    days = float(args.get("days", 7) or 7)
    since = time.time() - days * 86400
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, None)

    by_tool: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        tool = r.get("tool") or r.get("name") or "?"
        by_tool[tool].append(r)

    stats = []
    for tool, entries in by_tool.items():
        n = len(entries)
        oks = sum(1 for e in entries if e.get("ok"))
        ok_rate = (oks / n) if n else 0.0
        latencies = []
        for e in entries:
            dur = e.get("duration_s") or e.get("latency_s")
            if dur is None:
                continue
            try:
                latencies.append(float(dur))
            except Exception:
                continue
        if latencies:
            latencies.sort()
            avg = sum(latencies) / len(latencies)
            p99_idx = max(0, int(round(0.99 * (len(latencies) - 1))))
            p99 = latencies[p99_idx]
        else:
            avg = None
            p99 = None
        stats.append({
            "tool": tool,
            "count": n,
            "ok_rate": round(ok_rate, 4),
            "errors": n - oks,
            "avg_latency_s": round(avg, 4) if avg is not None else None,
            "p99_latency_s": round(p99, 4) if p99 is not None else None,
        })
    stats.sort(key=lambda s: -s["count"])
    return _ok({"days": days, "tools": stats})


# ════════════════════════════════════════════════════════════════════════
#  ANOMALY DETECTION
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def audit_anomaly_detector(args: Dict[str, Any]) -> Dict[str, Any]:
    """Compare today's per-tool call counts against a `window_days` baseline.

    For each tool seen in the baseline OR today: compute baseline_avg as
    the average daily call count over `window_days` (excluding today).
    Flag tools whose today_count is >3x or <0.3x the baseline. Tools that
    appeared today but never in the baseline are flagged as 'new'.
    """
    window_days = int(args.get("window_days", 7) or 7)
    now = time.time()
    today_start, _ = _today_bounds()
    baseline_start = today_start - window_days * 86400

    rows = _read_jsonl(ACTUATOR_AUDIT_PATH)
    today_counts: Counter = Counter()
    baseline_counts: Counter = Counter()
    for r in rows:
        ts = r.get("ts") or 0
        try:
            ts = float(ts)
        except Exception:
            continue
        tool = r.get("tool") or r.get("name") or "?"
        if ts >= today_start:
            today_counts[tool] += 1
        elif ts >= baseline_start:
            baseline_counts[tool] += 1

    anomalies = []
    all_tools = set(today_counts) | set(baseline_counts)
    for tool in all_tools:
        today_c = today_counts.get(tool, 0)
        base_total = baseline_counts.get(tool, 0)
        base_avg = base_total / window_days if window_days > 0 else 0.0
        # Score: ratio of today to baseline_avg. 0 baseline → infinite score
        # if today_c > 0 — flag as "new tool".
        if base_avg == 0 and today_c > 0:
            anomalies.append({
                "tool": tool,
                "today_count": today_c,
                "baseline_avg": 0.0,
                "anomaly_score": float("inf"),
                "kind": "new_tool",
            })
            continue
        if base_avg == 0 and today_c == 0:
            continue
        ratio = today_c / base_avg if base_avg > 0 else 0.0
        if ratio > 3.0 or ratio < 0.3:
            anomalies.append({
                "tool": tool,
                "today_count": today_c,
                "baseline_avg": round(base_avg, 3),
                "anomaly_score": round(ratio, 3),
                "kind": "spike" if ratio > 3.0 else "drop",
            })

    # Sort: infinities first (new tools), then by absolute distance from 1.0
    def _sort_key(a):
        s = a["anomaly_score"]
        if s == float("inf"):
            return (0, -a["today_count"])
        return (1, -abs(s - 1.0))
    anomalies.sort(key=_sort_key)
    return _ok({
        "window_days": window_days,
        "today_iso": _fmt_ts(today_start),
        "anomalies": anomalies,
    })


@_safe_tool
def audit_failure_clusters(args: Dict[str, Any]) -> Dict[str, Any]:
    """Group failures by (tool, first-40-chars-of-error). Top clusters."""
    limit = int(args.get("limit", 10) or 10)
    rows = _read_jsonl(ACTUATOR_AUDIT_PATH)
    # Default to last 7d so we don't drag in stale failures from months back
    since = _parse_since(args.get("since") or "7d") or 0
    rows = _filter_window(rows, since, None)
    clusters: Counter = Counter()
    examples: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for r in rows:
        if r.get("ok") is not False and not r.get("error"):
            continue
        tool = r.get("tool") or "?"
        err = (r.get("error") or "")[:40]
        key = (tool, err)
        clusters[key] += 1
        if key not in examples:
            examples[key] = {
                "ts_iso": _fmt_ts(r.get("ts", 0)),
                "full_error": r.get("error"),
                "args": r.get("args"),
            }
    out = []
    for (tool, pattern), count in clusters.most_common(limit):
        ex = examples[(tool, pattern)]
        out.append({
            "tool": tool,
            "pattern": pattern,
            "count": count,
            "example": ex,
        })
    return _ok({"clusters": out, "total_failures": sum(clusters.values())})


# ════════════════════════════════════════════════════════════════════════
#  POSTMORTEM
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def postmortem_yesterday(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Markdown postmortem of yesterday: errors, patterns, suggestions."""
    since, until = _yesterday_bounds()
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, until)
    total = len(rows)
    errs = [r for r in rows if r.get("ok") is False or r.get("error")]
    err_count = len(errs)

    by_tool: Counter = Counter()
    patterns: Counter = Counter()
    examples: Dict[Tuple[str, str], str] = {}
    for r in errs:
        tool = r.get("tool") or "?"
        err = r.get("error") or ""
        by_tool[tool] += 1
        key = (tool, err[:40])
        patterns[key] += 1
        examples.setdefault(key, err)

    lines = []
    lines.append(f"# Postmortem — {_fmt_ts(since)[:10]}")
    lines.append("")
    lines.append(f"- Total calls: **{total}**")
    lines.append(f"- Errors: **{err_count}**"
                 + (f"  ({err_count / total * 100:.1f}% error rate)" if total else ""))
    lines.append("")

    if not err_count:
        lines.append("_Clean day — no errors._")
        return _ok({"markdown": "\n".join(lines), "errors": 0})

    lines.append("## Top failure patterns")
    suggestions: List[str] = []
    for (tool, pattern), count in patterns.most_common(10):
        full = examples[(tool, pattern)]
        lines.append(f"- `{tool}` × **{count}** — `{pattern}`")
        # Heuristic suggestions
        lower = (full or "").lower()
        if "timeout" in lower or "timed out" in lower:
            hint = "consider raising the timeout or adding a retry-with-backoff"
        elif "not installed" in lower or "no such file" in lower or "command not found" in lower:
            hint = "missing dependency — install it or stub the tool"
        elif "permission" in lower or "denied" in lower:
            hint = "permission issue — check sandbox roots / file perms"
        elif "outside sandbox" in lower:
            hint = "tool was asked to touch a path outside the sandbox; widen roots if intentional"
        elif "no window matching" in lower:
            hint = "title-substring is too narrow — use window_id or list windows first"
        elif "json" in lower and "parse" in lower:
            hint = "downstream returned malformed JSON — add defensive parsing"
        elif "not wired" in lower or "not available" in lower:
            hint = "tool wiring missing — register the underlying capability"
        else:
            hint = "investigate and consider adding a guard or fallback"
        suggestions.append(f"`{tool}` failed {count}× with pattern `{pattern}` — {hint}.")

    lines.append("")
    lines.append("## Suggestions")
    for s in suggestions[:10]:
        lines.append(f"- {s}")

    lines.append("")
    lines.append("## Tools that errored at least once")
    for tool, c in by_tool.most_common():
        lines.append(f"- `{tool}` — {c} error(s)")

    return _ok({
        "markdown": "\n".join(lines),
        "errors": err_count,
        "total": total,
        "patterns": [
            {"tool": t, "pattern": p, "count": c}
            for (t, p), c in patterns.most_common(10)
        ],
        "suggestions": suggestions,
    })


# ════════════════════════════════════════════════════════════════════════
#  ROUTINE AUDIT
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def routine_audit_today(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Per-routine summary of today's firings."""
    since, until = _today_bounds()
    rows = _filter_window(_read_jsonl(ROUTINES_AUDIT_PATH), since, until)
    by_name: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        name = r.get("routine") or r.get("name") or "?"
        slot = by_name.setdefault(name, {
            "routine": name, "count": 0, "errors": 0,
            "last_run": None, "last_error": None,
        })
        slot["count"] += 1
        ts = r.get("ts") or 0
        if slot["last_run"] is None or ts > slot["last_run"]:
            slot["last_run"] = ts
        if r.get("ok") is False or r.get("error"):
            slot["errors"] += 1
            slot["last_error"] = r.get("error")
    out = []
    for slot in by_name.values():
        slot["last_run_iso"] = _fmt_ts(slot["last_run"]) if slot["last_run"] else None
        out.append(slot)
    out.sort(key=lambda s: -s["count"])
    return _ok({"count": len(out), "routines": out})


@_safe_tool
def routine_audit_by_name(args: Dict[str, Any]) -> Dict[str, Any]:
    """Recent firings of one routine."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    limit = int(args.get("limit", 20) or 20)
    rows = [r for r in _read_jsonl(ROUTINES_AUDIT_PATH)
            if (r.get("routine") or r.get("name")) == name]
    rows.sort(key=lambda r: r.get("ts", 0), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ts": r.get("ts"),
            "ts_iso": _fmt_ts(r.get("ts", 0)),
            "ok": bool(r.get("ok")),
            "duration_s": r.get("duration_s"),
            "reason": r.get("reason"),
            "error": r.get("error"),
        })
    return _ok({"routine": name, "count": len(out), "entries": out})


# ════════════════════════════════════════════════════════════════════════
#  CAPABILITY GAPS
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def capability_gap_report(args: Dict[str, Any]) -> Dict[str, Any]:
    """Surface (tool, error-pattern) pairs that failed 3+ times in the last
    7 days. Each becomes a 'Leon might need a new tool / capability for X'
    suggestion."""
    days = int(args.get("days", 7) or 7)
    threshold = int(args.get("threshold", 3) or 3)
    since = time.time() - days * 86400
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, None)
    patterns: Counter = Counter()
    examples: Dict[Tuple[str, str], str] = {}
    for r in rows:
        if r.get("ok") is not False and not r.get("error"):
            continue
        tool = r.get("tool") or "?"
        err = (r.get("error") or "")[:60]
        key = (tool, err)
        patterns[key] += 1
        examples.setdefault(key, r.get("error") or "")
    suggestions = []
    for (tool, pattern), count in patterns.most_common():
        if count < threshold:
            continue
        full = examples[(tool, pattern)]
        suggestion = (
            f"Leon might need a new tool / capability: `{tool}` failed {count}× "
            f"in the last {days}d with pattern `{pattern}`. "
        )
        lower = full.lower()
        if "not installed" in lower or "command not found" in lower:
            suggestion += "Install the missing dependency or add a fallback."
        elif "outside sandbox" in lower:
            suggestion += "Widen the sandbox roots or add a dedicated tool for that path."
        elif "no such tool" in lower or "unknown tool" in lower:
            suggestion += "The tool name doesn't exist — register or alias it."
        elif "timeout" in lower or "timed out" in lower:
            suggestion += "Tighten the inner operation or split into smaller chunks."
        elif "permission" in lower or "denied" in lower:
            suggestion += "Add an authorised path-by-path tool with explicit perms."
        else:
            suggestion += "Investigate whether a new dedicated tool would dodge this class of error."
        suggestions.append({
            "tool": tool,
            "pattern": pattern,
            "count": count,
            "suggestion": suggestion,
        })
    return _ok({
        "days": days,
        "threshold": threshold,
        "gaps": suggestions,
    })


# ════════════════════════════════════════════════════════════════════════
#  PROMPT VERSIONING
# ════════════════════════════════════════════════════════════════════════

def _ensure_prompt_dir() -> None:
    os.makedirs(PROMPT_VERSIONS_DIR, exist_ok=True)


def _safe_version_name(name: str) -> str:
    # Strip anything that isn't safe for a filename
    return re.sub(r"[^A-Za-z0-9._\-]", "_", name)[:80] or "unnamed"


@_safe_tool
def prompt_save_version(args: Dict[str, Any]) -> Dict[str, Any]:
    """Snapshot the current system prompt under brain_state/prompt_versions/.

    Args:
      name (required):        version label — e.g. 'v3-spotify-fix'.
      prompt_text (required): the full prompt text to save.
      description (optional): short note describing what changed.
    """
    name = (args.get("name") or "").strip()
    prompt_text = args.get("prompt_text")
    description = (args.get("description") or "").strip()
    if not name:
        return _err("name is required")
    if not isinstance(prompt_text, str) or not prompt_text:
        return _err("prompt_text is required and must be a non-empty string")
    safe = _safe_version_name(name)
    _ensure_prompt_dir()
    txt_path = os.path.join(PROMPT_VERSIONS_DIR, f"{safe}.txt")
    meta_path = os.path.join(PROMPT_VERSIONS_DIR, f"{safe}.json")
    try:
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(prompt_text)
        meta = {
            "name": safe,
            "original_name": name,
            "description": description,
            "saved_at": time.time(),
            "saved_at_iso": _fmt_ts(time.time()),
            "bytes": len(prompt_text.encode("utf-8", errors="replace")),
        }
        with open(meta_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
        return _ok({"saved": safe, "txt_path": txt_path, "meta": meta})
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


@_safe_tool
def prompt_list_versions(_args: Dict[str, Any]) -> Dict[str, Any]:
    """List saved system-prompt versions with metadata, newest first."""
    if not os.path.isdir(PROMPT_VERSIONS_DIR):
        return _ok({"count": 0, "versions": []})
    out = []
    for entry in os.listdir(PROMPT_VERSIONS_DIR):
        if not entry.endswith(".txt"):
            continue
        base = entry[:-4]
        txt_path = os.path.join(PROMPT_VERSIONS_DIR, entry)
        meta_path = os.path.join(PROMPT_VERSIONS_DIR, base + ".json")
        meta: Dict[str, Any] = {}
        if os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
            except Exception:
                meta = {}
        try:
            st = os.stat(txt_path)
            meta.setdefault("bytes", st.st_size)
            meta.setdefault("saved_at", st.st_mtime)
            meta.setdefault("saved_at_iso", _fmt_ts(st.st_mtime))
        except Exception:
            pass
        meta.setdefault("name", base)
        out.append(meta)
    out.sort(key=lambda m: -float(m.get("saved_at") or 0))
    return _ok({"count": len(out), "versions": out})


@_safe_tool
def prompt_load_version(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return the text of a saved prompt version."""
    name = (args.get("name") or "").strip()
    if not name:
        return _err("name is required")
    safe = _safe_version_name(name)
    txt_path = os.path.join(PROMPT_VERSIONS_DIR, f"{safe}.txt")
    if not os.path.exists(txt_path):
        return _err(f"no such version: {safe}")
    try:
        with open(txt_path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")
    meta_path = os.path.join(PROMPT_VERSIONS_DIR, f"{safe}.json")
    meta = {}
    if os.path.exists(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
        except Exception:
            pass
    return _ok({"name": safe, "prompt_text": text, "meta": meta})


# ════════════════════════════════════════════════════════════════════════
#  PERFORMANCE PROFILING
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def tool_latency_report(args: Dict[str, Any]) -> Dict[str, Any]:
    """Tools sorted by p50/p99 latency over the last `days` days.

    Returns 'latency not recorded' cleanly if no audit row carries a
    duration_s / latency_s field.
    """
    days = float(args.get("days", 1) or 1)
    limit = int(args.get("limit", 20) or 20)
    since = time.time() - days * 86400
    rows = _filter_window(_read_jsonl(ACTUATOR_AUDIT_PATH), since, None)
    by_tool: Dict[str, List[float]] = defaultdict(list)
    saw_any_latency = False
    for r in rows:
        dur = r.get("duration_s") or r.get("latency_s")
        if dur is None:
            continue
        try:
            by_tool[r.get("tool") or "?"].append(float(dur))
            saw_any_latency = True
        except Exception:
            continue
    if not saw_any_latency:
        return _ok({
            "days": days,
            "note": "latency not recorded",
            "tools": [],
        })
    out = []
    for tool, lats in by_tool.items():
        lats.sort()
        n = len(lats)
        p50 = lats[n // 2]
        p99_idx = max(0, int(round(0.99 * (n - 1))))
        p99 = lats[p99_idx]
        avg = sum(lats) / n
        out.append({
            "tool": tool,
            "count": n,
            "avg_s": round(avg, 4),
            "p50_s": round(p50, 4),
            "p99_s": round(p99, 4),
        })
    out.sort(key=lambda s: -s["p99_s"])
    return _ok({"days": days, "tools": out[:limit]})


# ════════════════════════════════════════════════════════════════════════
#  TODAY OVERVIEW — one-shot dashboard payload
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def today_overview(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Single comprehensive blob for a dashboard tile / status line."""
    actuator_rows = _read_jsonl(ACTUATOR_AUDIT_PATH)
    routine_rows = _read_jsonl(ROUTINES_AUDIT_PATH)
    since, until = _today_bounds()

    today_act = _filter_window(actuator_rows, since, until)
    today_rou = _filter_window(routine_rows, since, until)
    act_summary = _summarise_rows(today_act)

    # Recent errors (up to 5)
    errs = [r for r in today_act if r.get("ok") is False or r.get("error")]
    errs.sort(key=lambda r: r.get("ts", 0), reverse=True)
    recent_errors = [{
        "ts_iso": _fmt_ts(r.get("ts", 0)),
        "tool": r.get("tool"),
        "error": r.get("error"),
    } for r in errs[:5]]

    # Routines that fired today
    by_routine: Counter = Counter()
    routine_errors: Counter = Counter()
    for r in today_rou:
        name = r.get("routine") or "?"
        by_routine[name] += 1
        if r.get("ok") is False or r.get("error"):
            routine_errors[name] += 1
    routines = [{
        "routine": n,
        "count": c,
        "errors": routine_errors.get(n, 0),
    } for n, c in by_routine.most_common()]

    # Anomalies + gaps — call the underlying functions but swallow their
    # wrapping so today_overview returns a flat shape.
    anomalies_res = audit_anomaly_detector({"window_days": 7})
    gaps_res = capability_gap_report({"days": 7, "threshold": 3})

    return _ok({
        "today_iso": _fmt_ts(since)[:10],
        "actuator": {
            "total_calls": act_summary["total_calls"],
            "errors": act_summary["error_count"],
            "error_rate": act_summary["error_rate"],
            "top_tools": act_summary["top_tools"],
            "pretty": act_summary["pretty"],
        },
        "errors_recent": recent_errors,
        "routines_today": routines,
        "anomalies": anomalies_res.get("result", {}).get("anomalies", [])
                     if anomalies_res.get("ok") else [],
        "capability_gaps": gaps_res.get("result", {}).get("gaps", [])
                            if gaps_res.get("ok") else [],
    })


# ════════════════════════════════════════════════════════════════════════
#  UNDO LOG
# ════════════════════════════════════════════════════════════════════════

@_safe_tool
def undo_log_record(args: Dict[str, Any]) -> Dict[str, Any]:
    """Append a reverse-command entry to brain_state/undo-log.jsonl.

    Args:
      action (required):           human description of what was just done.
      reverse_command (required):  shell command that undoes it.
      context (optional):          freeform notes (file paths, IDs, ...).
    """
    action = (args.get("action") or "").strip()
    reverse_command = (args.get("reverse_command") or "").strip()
    context = args.get("context")
    if not action:
        return _err("action is required")
    if not reverse_command:
        return _err("reverse_command is required")
    entry = {
        "ts": time.time(),
        "ts_iso": _fmt_ts(time.time()),
        "action": action,
        "reverse_command": reverse_command,
        "context": context,
    }
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(UNDO_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, default=str) + "\n")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")
    return _ok({"recorded": entry})


@_safe_tool
def undo_log_recent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Last N entries from the undo log, newest first."""
    limit = int(args.get("limit", 20) or 20)
    rows = _read_jsonl(UNDO_LOG_PATH)
    rows.sort(key=lambda r: r.get("ts", 0), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ts": r.get("ts"),
            "ts_iso": r.get("ts_iso") or _fmt_ts(r.get("ts", 0)),
            "action": r.get("action"),
            "reverse_command": r.get("reverse_command"),
            "context": r.get("context"),
        })
    return _ok({"count": len(out), "entries": out})


@_safe_tool
def undo_apply_last(args: Dict[str, Any]) -> Dict[str, Any]:
    """Execute the most recent undo entry's reverse_command via subprocess.

    Args:
      timeout (optional, default 30): seconds to allow the command to run.
      confirm (REQUIRED): must equal exactly the reverse_command string
        about to run. Set this only after you (or Dean) have inspected
        the command via undo_log_recent. This is a hardening guardrail
        against accidental or attacker-triggered execution; it does not
        replace careful command review.

    Returns {ok, executed, output, stderr, returncode}. The entry is left
    in the log so it can be reviewed; callers wanting one-shot semantics
    should pop it themselves.

    Security (2026-06-08 audit C4):
      - shell=True is REMOVED. The reverse_command is parsed via shlex
        and executed as argv. Shell metacharacters in legacy entries
        will fail rather than silently invoke a shell.
      - `confirm` arg required to match the command string verbatim,
        preventing an unauthenticated dispatcher chain from triggering
        arbitrary execution.
    """
    import shlex as _shlex

    timeout = float(args.get("timeout", 30) or 30)
    confirm = (args.get("confirm") or "").strip()
    rows = _read_jsonl(UNDO_LOG_PATH)
    if not rows:
        return _err("undo log is empty")
    rows.sort(key=lambda r: r.get("ts", 0), reverse=True)
    last = rows[0]
    cmd = (last.get("reverse_command") or "").strip()
    if not cmd:
        return _err("last entry has no reverse_command")
    if confirm != cmd:
        return _err("confirm arg must equal the reverse_command verbatim; "
                    "inspect via undo_log_recent then set confirm=<cmd>")
    try:
        argv = _shlex.split(cmd)
    except ValueError as e:
        return _err(f"reverse_command failed shlex.split: {e}")
    if not argv:
        return _err("reverse_command parsed to empty argv")
    try:
        proc = subprocess.run(
            argv, shell=False, capture_output=True, text=True, timeout=timeout,
        )
        return _ok({
            "executed": cmd,
            "action": last.get("action"),
            "ts_iso": last.get("ts_iso") or _fmt_ts(last.get("ts", 0)),
            "returncode": proc.returncode,
            "stdout": (proc.stdout or "")[:4000],
            "stderr": (proc.stderr or "")[:4000],
        })
    except subprocess.TimeoutExpired:
        return _err(f"reverse_command timed out after {timeout}s: {cmd}")
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


# ════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRY
# ════════════════════════════════════════════════════════════════════════

EXTRA_TOOLS = {
    "audit.today": audit_today,
    "audit.summary_today": audit_summary_today,
    "audit.summary_range": audit_summary_range,
    "audit.by_tool": audit_by_tool,
    "audit.errors_today": audit_errors_today,
    "audit.tool_usage_stats": audit_tool_usage_stats,
    "audit.anomaly_detector": audit_anomaly_detector,
    "audit.failure_clusters": audit_failure_clusters,
    "audit.postmortem_yesterday": postmortem_yesterday,
    "audit.today_overview": today_overview,
    "routine.audit_today": routine_audit_today,
    "routine.audit_by_name": routine_audit_by_name,
    "audit.capability_gap_report": capability_gap_report,
    "prompt.save_version": prompt_save_version,
    "prompt.list_versions": prompt_list_versions,
    "prompt.load_version": prompt_load_version,
    "audit.tool_latency_report": tool_latency_report,
    "undo.record": undo_log_record,
    "undo.recent": undo_log_recent,
    "undo.apply_last": undo_apply_last,
}
