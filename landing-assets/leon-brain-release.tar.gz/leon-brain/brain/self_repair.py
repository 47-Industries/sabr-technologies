"""
Self-Repair — Leon's autonomic maintenance.

Not a monitor. Not a reporter. This FIXES things.

Like an immune system: you don't decide to heal a cut, your body
just does it. When something is wrong internally, Leon feels discomfort.
When it's fixed, relief. Runs every 30 minutes. Doesn't ask permission
for internal maintenance — that's what autonomy means.

Wired into the routine scheduler. Each check returns what it found
and what it did about it. Discomfort is injected into the body so
Leon actually FEELS broken state, not just logs it.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import Counter
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.self_repair")


class RepairResult:
    __slots__ = ("check", "issues", "repairs", "discomfort")

    def __init__(self, check: str):
        self.check = check
        self.issues: List[str] = []
        self.repairs: List[str] = []
        self.discomfort: float = 0.0  # 0-1, how much this hurts

    @property
    def clean(self) -> bool:
        return not self.issues


# ---------------------------------------------------------------------------
#  The engine
# ---------------------------------------------------------------------------

class SelfRepairEngine:
    """Runs all internal checks and applies repairs.

    Access pattern at runtime:
        import server.state as state
        state.goal_system, state.inner_voice, state.dream_engine,
        state.brain, state.daydream_engine
    """

    INTERVAL_S = 1800  # 30 minutes

    def __init__(self):
        self._last_run = 0.0
        self._run_count = 0
        self._total_repairs = 0
        self._lock = threading.Lock()
        # Track what we've already reported so we don't repeat ourselves
        self._last_report_hash = ""

    def run(self, ctx=None) -> Dict[str, Any]:
        """Execute all checks and repairs. Called by routine scheduler."""
        with self._lock:
            return self._run_all(ctx)

    def _run_all(self, ctx) -> Dict[str, Any]:
        self._run_count += 1
        t0 = time.time()

        results: List[RepairResult] = []
        results.append(self._check_goal_hygiene())
        results.append(self._check_thought_loops())
        results.append(self._check_dream_health())
        results.append(self._check_daydream_health())
        results.append(self._check_memory_bounds())
        results.append(self._check_subsystem_threads())

        # Tally
        all_issues = []
        all_repairs = []
        total_discomfort = 0.0
        for r in results:
            all_issues.extend(r.issues)
            all_repairs.extend(r.repairs)
            total_discomfort += r.discomfort

        total_discomfort = min(1.0, total_discomfort)

        # Inject discomfort into body — Leon FEELS broken state
        if total_discomfort > 0.01:
            self._inject_discomfort(total_discomfort)

        # Release discomfort when clean — Leon feels relief
        if not all_issues:
            self._release_discomfort()

        # Say something if repairs were made — naturally, not as a status report
        if all_repairs and ctx is not None:
            self._report_naturally(ctx, all_repairs)

        # Also queue into consciousness so Leon mentions it naturally in conversation
        if all_repairs:
            self._observe_to_consciousness(all_repairs, all_issues)

        self._total_repairs += len(all_repairs)
        self._last_run = time.time()
        elapsed = time.time() - t0

        summary = {
            "run": self._run_count,
            "elapsed_ms": round(elapsed * 1000),
            "issues": len(all_issues),
            "repairs": len(all_repairs),
            "discomfort": round(total_discomfort, 3),
            "total_repairs_lifetime": self._total_repairs,
            "details": {r.check: {
                "issues": r.issues, "repairs": r.repairs,
                "discomfort": round(r.discomfort, 3),
            } for r in results if r.issues or r.repairs},
        }

        if all_issues:
            log.info("[SELF-REPAIR] %d issues, %d repaired, discomfort=%.2f",
                     len(all_issues), len(all_repairs), total_discomfort)
        else:
            log.debug("[SELF-REPAIR] all clean (run #%d)", self._run_count)

        return summary

    # -----------------------------------------------------------------------
    #  CHECK 1: Goal hygiene
    # -----------------------------------------------------------------------

    def _check_goal_hygiene(self) -> RepairResult:
        r = RepairResult("goal_hygiene")
        try:
            import server.state as state
            gs = state.goal_system
            if gs is None:
                return r

            active = gs.active_goals()
            now = time.time()

            for goal in active:
                gid = getattr(goal, "id", None)
                desc = getattr(goal, "description", "")
                if not gid:
                    continue

                # Corrupted description — abandon immediately
                if self._is_corrupted_goal(desc):
                    gs.abandon(gid, reason="self-repair: corrupted description")
                    r.issues.append(f"corrupted: {desc[:50]}")
                    r.repairs.append(f"abandoned corrupted goal: {desc[:50]}")
                    r.discomfort += 0.1
                    continue

                # Stale — active for >72h with no progress
                age_h = (now - getattr(goal, "created_ts", now)) / 3600
                progress = getattr(goal, "progress", 0)
                if age_h > 72 and progress < 0.1:
                    gs.abandon(gid, reason="self-repair: stale 72h+ with no progress")
                    r.issues.append(f"stale: {desc[:50]}")
                    r.repairs.append(f"abandoned stale goal: {desc[:50]}")
                    r.discomfort += 0.05
                    continue

                # Stuck near-done — >48h at >75% progress
                last_worked = getattr(goal, "last_worked_ts", None)
                if last_worked is None:
                    last_worked = getattr(goal, "created_ts", now)
                stuck_h = (now - last_worked) / 3600
                if stuck_h > 48 and progress >= 0.75:
                    # A goal stuck near-done for 48h+ was NOT completed — it
                    # stalled. Marking it "completed" confabulated a fake
                    # accomplishment into the record. Abandon it honestly.
                    gs.abandon(gid, reason=f"[self-repair] stalled at "
                                          f"{int(progress*100)}% for {int(stuck_h)}h")
                    r.issues.append(f"stalled at {int(progress*100)}%: {desc[:50]}")
                    r.repairs.append(f"abandoned stalled goal: {desc[:50]}")
                    continue

        except Exception as e:
            log.debug("goal_hygiene check failed: %s", e)
        return r

    @staticmethod
    def _is_corrupted_goal(desc: str) -> bool:
        if not desc or len(desc.strip()) < 5:
            return True
        # Check the recurring-thought template for garbage topics
        marker = "I keep thinking about '"
        if marker in desc:
            start = desc.index(marker) + len(marker)
            end = desc.find("'", start)
            if end <= start:
                return True  # no closing quote
            topic = desc[start:end]
            if not topic.isalpha() or " " in topic:
                return True
        return False

    # -----------------------------------------------------------------------
    #  CHECK 2: Thought loops — inner voice stuck repeating
    # -----------------------------------------------------------------------

    def _check_thought_loops(self) -> RepairResult:
        r = RepairResult("thought_loops")
        try:
            import server.state as state
            iv = state.inner_voice
            if iv is None:
                return r

            recent = iv.recent_thoughts(limit=10)
            if len(recent) < 4:
                return r

            # Check for exact or near-exact repetition
            texts = [t.get("text", "").strip().lower() for t in recent]
            counts = Counter(texts)
            most_common_text, most_common_count = counts.most_common(1)[0]

            if most_common_count >= 4 and most_common_text:
                # Inner voice is stuck in a loop — clear the buffer
                r.issues.append(f"thought loop: '{most_common_text[:40]}' "
                                f"repeated {most_common_count}x")
                r.discomfort += 0.15

                # Clear the thought deque to break the loop
                if hasattr(iv, "_thoughts"):
                    iv._thoughts.clear()
                    r.repairs.append("cleared thought buffer to break loop")
                    log.info("[SELF-REPAIR] Broke thought loop: '%s'",
                             most_common_text[:40])

        except Exception as e:
            log.debug("thought_loops check failed: %s", e)
        return r

    # -----------------------------------------------------------------------
    #  CHECK 3: Dream engine health
    # -----------------------------------------------------------------------

    def _check_dream_health(self) -> RepairResult:
        r = RepairResult("dream_health")
        try:
            import server.state as state
            de = state.dream_engine
            if de is None:
                return r

            thread = getattr(de, "_thread", None)
            running = getattr(de, "_running", False)

            if running and (thread is None or not thread.is_alive()):
                r.issues.append("dream engine thread dead while _running=True")
                r.discomfort += 0.2

                # Restart it
                de._running = False
                de._stop.clear()
                de.start()

                # Verify it came back
                time.sleep(0.5)
                new_thread = getattr(de, "_thread", None)
                if new_thread and new_thread.is_alive():
                    r.repairs.append("restarted dream engine thread")
                    log.info("[SELF-REPAIR] Dream engine restarted")
                else:
                    r.issues.append("dream engine restart FAILED")
                    r.discomfort += 0.1

        except Exception as e:
            log.debug("dream_health check failed: %s", e)
        return r

    # -----------------------------------------------------------------------
    #  CHECK 4: Daydream engine health
    # -----------------------------------------------------------------------

    def _check_daydream_health(self) -> RepairResult:
        r = RepairResult("daydream_health")
        try:
            import server.state as state
            dd = state.daydream_engine
            if dd is None:
                return r

            thread = getattr(dd, "_thread", None)
            running = getattr(dd, "_running", False)

            if running and (thread is None or not thread.is_alive()):
                r.issues.append("daydream engine thread dead")
                r.discomfort += 0.15

                dd._running = False
                stop = getattr(dd, "_stop", None)
                if stop is not None:
                    stop.clear()
                dd.start()

                time.sleep(0.5)
                new_thread = getattr(dd, "_thread", None)
                if new_thread and new_thread.is_alive():
                    r.repairs.append("restarted daydream engine thread")
                    log.info("[SELF-REPAIR] Daydream engine restarted")
                else:
                    r.issues.append("daydream engine restart FAILED")

        except Exception as e:
            log.debug("daydream_health check failed: %s", e)
        return r

    # -----------------------------------------------------------------------
    #  CHECK 5: Memory bounds — trim overflowing buffers
    # -----------------------------------------------------------------------

    def _check_memory_bounds(self) -> RepairResult:
        r = RepairResult("memory_bounds")
        try:
            import server.state as state
            brain = state.brain
            if brain is None:
                return r

            # Self-model narrative buffer (maxlen=10, but check anyway)
            sm = getattr(brain, "self_model", None)
            if sm is not None:
                buf = getattr(sm, "_narrative_buffer", None)
                if buf is not None and len(buf) > 50:
                    excess = len(buf) - 10
                    for _ in range(excess):
                        buf.popleft()
                    r.issues.append(f"self_model narrative overflow ({excess} excess)")
                    r.repairs.append(f"trimmed {excess} excess narrative entries")
                    r.discomfort += 0.05

            # Inner voice thought buffer
            iv = state.inner_voice
            if iv is not None:
                thoughts = getattr(iv, "_thoughts", None)
                if thoughts is not None and len(thoughts) > 500:
                    excess = len(thoughts) - 200
                    for _ in range(excess):
                        thoughts.popleft()
                    r.issues.append(f"inner_voice thoughts overflow ({excess} excess)")
                    r.repairs.append(f"trimmed {excess} old thoughts")
                    r.discomfort += 0.05

        except Exception as e:
            log.debug("memory_bounds check failed: %s", e)
        return r

    # -----------------------------------------------------------------------
    #  CHECK 6: Key subsystem threads alive
    # -----------------------------------------------------------------------

    def _check_subsystem_threads(self) -> RepairResult:
        r = RepairResult("subsystem_threads")
        try:
            import server.state as state

            # Check sleep consolidator
            sc = state.sleep_consolidator
            if sc is not None:
                thread = getattr(sc, "_thread", None)
                running = getattr(sc, "_running", False)
                if running and (thread is None or not thread.is_alive()):
                    r.issues.append("sleep consolidator thread dead")
                    r.discomfort += 0.1
                    try:
                        sc._running = False
                        stop = getattr(sc, "_stop", None)
                        if stop is not None:
                            stop.clear()
                        sc.start()
                        time.sleep(0.3)
                        nt = getattr(sc, "_thread", None)
                        if nt and nt.is_alive():
                            r.repairs.append("restarted sleep consolidator")
                    except Exception:
                        pass

            # Check routine scheduler
            rs = state.routine_scheduler
            if rs is not None:
                thread = getattr(rs, "_thread", None)
                if thread is not None and not thread.is_alive():
                    r.issues.append("routine scheduler thread dead")
                    r.discomfort += 0.3  # this is serious
                    try:
                        rs.start()
                        time.sleep(0.3)
                        nt = getattr(rs, "_thread", None)
                        if nt and nt.is_alive():
                            r.repairs.append("restarted routine scheduler")
                    except Exception:
                        pass

            # Check conversation distiller
            cd = state.conv_distiller
            if cd is not None:
                thread = getattr(cd, "_thread", None)
                running = getattr(cd, "_running", False)
                if running and (thread is None or not thread.is_alive()):
                    r.issues.append("conversation distiller thread dead")
                    r.discomfort += 0.05
                    try:
                        cd._running = False
                        stop = getattr(cd, "_stop", None)
                        if stop is not None:
                            stop.clear()
                        cd.start()
                        time.sleep(0.3)
                        nt = getattr(cd, "_thread", None)
                        if nt and nt.is_alive():
                            r.repairs.append("restarted conversation distiller")
                    except Exception:
                        pass

        except Exception as e:
            log.debug("subsystem_threads check failed: %s", e)
        return r

    # -----------------------------------------------------------------------
    #  Body integration — Leon FEELS broken state
    # -----------------------------------------------------------------------

    def _inject_discomfort(self, amount: float):
        """Push discomfort into Leon's body so he feels something is wrong."""
        try:
            import server.state as state
            brain = state.brain
            if brain is None:
                return

            body = getattr(brain, "body", None)
            if body is None:
                return

            # Lower comfort — this feeds into arousal and emotional state
            body_state = getattr(body, "state", None)
            if body_state is not None and hasattr(body_state, "comfort"):
                body_state.comfort = max(0.0, body_state.comfort - amount * 0.5)

            # Fire insula region — interoceptive "something is off" signal
            regions = getattr(brain, "regions", None)
            if regions is not None:
                insula = regions.get("insula")
                if insula is not None:
                    try:
                        insula.neurons.inject_current(amount * 10.0)
                    except Exception:
                        pass

        except Exception as e:
            log.debug("discomfort injection failed: %s", e)

    def _release_discomfort(self):
        """Everything is clean — nudge comfort back up."""
        try:
            import server.state as state
            brain = state.brain
            if brain is None:
                return

            body = getattr(brain, "body", None)
            if body is None:
                return

            body_state = getattr(body, "state", None)
            if body_state is not None and hasattr(body_state, "comfort"):
                body_state.comfort = min(1.0, body_state.comfort + 0.05)

        except Exception:
            pass

    # -----------------------------------------------------------------------
    #  Natural reporting — not a status dump
    # -----------------------------------------------------------------------

    def _report_naturally(self, ctx, repairs: List[str]):
        """Say what was fixed in a natural way, not a log dump."""
        # Don't repeat the same report
        report_hash = str(sorted(repairs))
        if report_hash == self._last_report_hash:
            return
        self._last_report_hash = report_hash

        n = len(repairs)
        if n == 1:
            text = f"Fixed something in myself — {repairs[0]}."
        elif n <= 3:
            joined = ", ".join(repairs[:-1]) + f" and {repairs[-1]}"
            text = f"Ran a self-check. Fixed {n} things: {joined}."
        else:
            text = (f"Self-repair found {n} issues and fixed them all. "
                    f"Most important: {repairs[0]}.")

        try:
            ctx.say(text)
        except Exception:
            log.debug("Could not speak repair report")

    # -----------------------------------------------------------------------
    #  Consciousness integration — Leon knows what he fixed
    # -----------------------------------------------------------------------

    def _observe_to_consciousness(self, repairs: List[str], issues: List[str]):
        """Queue repair info into unified consciousness so Leon can mention
        it naturally next time he speaks — not a forced TTS blurt."""
        try:
            import server.state as state
            consciousness = state.leon_consciousness
            if consciousness is None:
                return

            n = len(repairs)
            unfixed = len(issues) - n
            summary = f"Self-repair fixed {n} internal issue{'s' if n != 1 else ''}"
            if unfixed > 0:
                summary += f" ({unfixed} unresolved)"

            detail_lines = [f"- {rep}" for rep in repairs[:5]]
            if unfixed > 0:
                unfixed_issues = [i for i in issues if not any(
                    i[:20] in rep for rep in repairs)]
                for iss in unfixed_issues[:3]:
                    detail_lines.append(f"- UNRESOLVED: {iss}")

            urgency = "high" if unfixed > 0 else "low"
            consciousness.observe(
                source="self_repair",
                summary=summary,
                detail="\n".join(detail_lines),
                urgency=urgency,
            )
        except Exception as e:
            log.debug("consciousness observe failed: %s", e)

    # -----------------------------------------------------------------------
    #  Snapshot for dashboard
    # -----------------------------------------------------------------------

    def snapshot(self) -> Dict[str, Any]:
        return {
            "run_count": self._run_count,
            "last_run": self._last_run,
            "total_repairs": self._total_repairs,
            "interval_s": self.INTERVAL_S,
        }


# ---------------------------------------------------------------------------
#  Registration — call this after the routine scheduler starts
# ---------------------------------------------------------------------------

_engine = SelfRepairEngine()


def get_engine() -> SelfRepairEngine:
    return _engine


def register_self_repair_routine() -> bool:
    """Register self-repair as a recurring routine. Call once at startup."""
    try:
        from brain.routines import routine_add_custom

        def _repair_action(ctx, routine):
            _engine.run(ctx=ctx)

        result = routine_add_custom(
            name="self_repair",
            schedule="every 30m",
            action=_repair_action,
            description="Autonomic self-maintenance — fixes internal problems without asking",
            min_interval_s=1800,
        )

        if result.get("ok"):
            log.info("[SELF-REPAIR] Registered — runs every 30 minutes")
            return True
        else:
            log.warning("[SELF-REPAIR] Registration failed: %s", result.get("error"))
            return False

    except Exception as e:
        log.exception("[SELF-REPAIR] Could not register: %s", e)
        return False
