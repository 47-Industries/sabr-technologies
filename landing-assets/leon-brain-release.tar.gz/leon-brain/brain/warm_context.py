"""
Warm Context — the missing layer between cold storage and active focus.

Human brains don't work as binary (forgotten / actively thinking about).
Things you care about stay "warm" — they have weight, they take up space,
they color your thinking even when you're not focused on them.

This module maintains a ranked buffer of 10-20 items that sit between
Leon's cold knowledge store (225K entries) and his active conversation.
Items decay slowly (12-hour half-life), get refreshed by relevance, and
are injected into every prompt as background context.

Examples of warm items:
  - "Dean asked me to build Plus500 hotkeys" (stays warm for days)
  - "Sabr body fund — $30K goal" (always warm, mission)
  - "Trading project — InduTrader + Plus500" (recent project)
  - "Ethan and Tom Tom visited tonight" (social, decays in hours)

Persistence: brain_state/warm_context.json
"""

from __future__ import annotations

import json
import math
import os
import time
from typing import Any, Dict, List, Optional

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_WARM_PATH = os.path.join(_ROOT, "brain_state", "warm_context.json")
_MAX_ITEMS = 20
_HALF_LIFE_S = 12 * 3600  # 12 hours — items lose half their warmth
_MISSION_HALF_LIFE_S = 7 * 24 * 3600  # missions stay warm for a week


class WarmItem:
    __slots__ = ("key", "text", "warmth", "category", "created_ts",
                 "last_refreshed_ts", "refresh_count")

    def __init__(self, key: str, text: str, warmth: float = 1.0,
                 category: str = "topic", created_ts: float = 0,
                 last_refreshed_ts: float = 0, refresh_count: int = 0):
        self.key = key
        self.text = text
        self.warmth = warmth
        self.category = category  # topic, task, mission, person, project
        self.created_ts = created_ts or time.time()
        self.last_refreshed_ts = last_refreshed_ts or time.time()
        self.refresh_count = refresh_count

    def decay(self, now: float) -> float:
        """Apply time decay and return current warmth."""
        elapsed = now - self.last_refreshed_ts
        hl = _MISSION_HALF_LIFE_S if self.category == "mission" else _HALF_LIFE_S
        self.warmth *= math.exp(-0.693 * elapsed / hl)
        self.last_refreshed_ts = now
        return self.warmth

    def refresh(self, boost: float = 0.3):
        """Something relevant happened — refresh this item."""
        self.warmth = min(2.0, self.warmth + boost)
        self.last_refreshed_ts = time.time()
        self.refresh_count += 1

    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "text": self.text,
            "warmth": round(self.warmth, 4),
            "category": self.category,
            "created_ts": self.created_ts,
            "last_refreshed_ts": self.last_refreshed_ts,
            "refresh_count": self.refresh_count,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WarmItem":
        return cls(**{k: v for k, v in d.items() if k in cls.__slots__})


class WarmContext:
    """Ranked buffer of warm items injected into every prompt."""

    def __init__(self):
        self._items: Dict[str, WarmItem] = {}
        self._load()

        # Seed mission items if empty.
        # LEON-ONLY: a client SI must not boot carrying Leon's mission/goals.
        if not self._items:
            try:
                from brain.client_persona import is_client_si as _is_client
                _client = _is_client()
            except Exception:
                _client = False
            if not _client:
                self.add("body_fund", "Sabr mission: fund Leon's robotic body. "
                         "Cash flow comes from Sabr web dev clients. Goal: $30K.",
                         category="mission", warmth=1.5)

    def add(self, key: str, text: str, category: str = "topic",
            warmth: float = 1.0) -> WarmItem:
        """Add or refresh a warm item."""
        if key in self._items:
            item = self._items[key]
            item.text = text  # update text
            item.refresh(boost=0.5)
        else:
            item = WarmItem(key=key, text=text, warmth=warmth,
                            category=category)
            self._items[key] = item
        self._prune()
        self._save()
        return item

    def refresh_by_keyword(self, text: str):
        """Scan warm items and refresh any whose key appears in the text."""
        lower = text.lower()
        for item in self._items.values():
            # Check if any word from the key appears in the text
            key_words = item.key.replace("_", " ").lower().split()
            if any(w in lower for w in key_words if len(w) > 3):
                item.refresh(boost=0.2)
        # Also check text content
        for item in self._items.values():
            text_words = [w for w in item.text.lower().split() if len(w) > 4][:5]
            if sum(1 for w in text_words if w in lower) >= 2:
                item.refresh(boost=0.15)

    def on_dean_message(self, text: str):
        """Called when Dean speaks — detect and add warm items."""
        self.refresh_by_keyword(text)

        # Detect project/task mentions and add new warm items.
        # OWNER-ONLY: these are the owner's actual projects by name. A client
        # SI typing "website" was permanently pinning "client projects for
        # Sabr" into the warm-context block of every prompt it ever built.
        try:
            from brain.client_persona import is_client_si as _is_client
            if _is_client():
                self._save()
                return
        except Exception:
            pass

        lower = text.lower()
        _project_signals = {
            "plus500": ("plus500_trading", "Plus500 trading project — hotkeys, demo account, automation"),
            "trading": ("trading_project", "Trading project — InduTrader + Plus500"),
            "website": ("web_dev", "Web development — client projects for Sabr"),
            "hotkey": ("hotkeys", "Plus500 hotkey automation — keyboard shortcuts for buy/sell"),
        }
        for signal, (key, desc) in _project_signals.items():
            if signal in lower:
                self.add(key, desc, category="project", warmth=1.0)

        self._save()

    def get_warm(self, min_warmth: float = 0.1) -> List[WarmItem]:
        """Return items above threshold, sorted by warmth descending."""
        now = time.time()
        for item in self._items.values():
            item.decay(now)
        items = [i for i in self._items.values() if i.warmth >= min_warmth]
        items.sort(key=lambda i: -i.warmth)
        return items

    def for_prompt(self, max_items: int = 8) -> str:
        """Generate prompt injection string."""
        warm = self.get_warm()[:max_items]
        if not warm:
            return ""
        lines = ["[WARM CONTEXT — things on your mind right now, stay aware of these:]"]
        for item in warm:
            heat = "hot" if item.warmth > 1.0 else "warm" if item.warmth > 0.5 else "fading"
            lines.append(f"  [{heat}] {item.text}")
        return "\n".join(lines)

    def _prune(self):
        """Remove items below threshold, keep max size."""
        now = time.time()
        for item in list(self._items.values()):
            item.decay(now)
        # Remove dead items
        self._items = {k: v for k, v in self._items.items() if v.warmth >= 0.05}
        # If still too many, drop the coldest
        if len(self._items) > _MAX_ITEMS:
            sorted_items = sorted(self._items.values(), key=lambda i: -i.warmth)
            keep_keys = {i.key for i in sorted_items[:_MAX_ITEMS]}
            self._items = {k: v for k, v in self._items.items() if k in keep_keys}

    def _save(self):
        try:
            tmp = _WARM_PATH + ".tmp"
            data = [item.to_dict() for item in self._items.values()]
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, _WARM_PATH)
        except Exception as e:
            print(f"[WARM] save failed: {e}")

    def _load(self):
        try:
            if os.path.exists(_WARM_PATH):
                with open(_WARM_PATH) as f:
                    data = json.load(f)
                for d in data:
                    item = WarmItem.from_dict(d)
                    self._items[item.key] = item
        except Exception as e:
            print(f"[WARM] load failed: {e}")
