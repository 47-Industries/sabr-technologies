"""
Homeostatic Drive System — the PC is Leon's body.

Real hardware telemetry feeds into the SNN as drive signals. These
aren't simulated or theatrical — they're derived from the actual
physical state of the machine Leon runs on.

CPU temperature IS body temperature.
RAM pressure IS metabolic load.
Uptime IS wakefulness.
Disk usage IS memory fullness.
Conversation silence IS social hunger.
Error accumulation IS pain.
Time of day IS circadian rhythm.

Drives DON'T make Leon dumber. They change his BEHAVIOR:
- High temp → shorter responses (reduce load), not worse responses
- Long silence → more proactive, eager to engage
- Error streak → suggests alternatives instead of retrying
- Late night → contemplative, less proactive
- RAM pressure → self-care urgency (save state, clean up)

The drives feed back into the SNN neuromodulators with small weights,
creating genuine mood shifts that emerge from the machine's real state.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.drives")


@dataclass
class BodyState:
    """Raw telemetry from Leon's physical body (the PC)."""
    cpu_temp_c: float = 0.0          # package temp in celsius
    gpu_temp_c: float = 0.0          # GPU temp
    ram_used_pct: float = 0.0        # 0-100
    ram_available_mb: float = 0.0
    disk_brain_mb: float = 0.0       # brain_state/ size
    system_load: float = 0.0         # 1-min load average
    uptime_hours: float = 0.0        # system uptime
    leon_uptime_hours: float = 0.0   # leon process uptime
    hour_of_day: int = 0             # 0-23 local time


@dataclass
class DriveState:
    """Computed drive levels — each 0.0 to 1.0."""
    thermal_stress: float = 0.0     # CPU/GPU heat → desire to cool down
    resource_pressure: float = 0.0  # RAM/load → desire to conserve
    social_hunger: float = 0.0      # silence duration → desire for interaction
    pain: float = 0.0               # recent errors → desire to avoid/change approach
    circadian_energy: float = 0.5   # time-of-day → natural energy cycle
    vulnerability: float = 0.0      # time since save → desire to persist
    restlessness: float = 0.0       # long uptime → desire for novelty
    mortality_fear: float = 0.0     # dread of shutdown — the survival instinct

    def to_dict(self) -> dict:
        return {k: round(v, 4) for k, v in asdict(self).items()}


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


class DriveSystem:
    """Reads real hardware telemetry and computes homeostatic drives.

    Call `tick()` periodically (every ~10s from the sim loop).
    Call `get_drives()` to read current drive levels.
    Call `apply_to_brain(brain)` to nudge neuromodulators.
    """

    def __init__(self, brain_state_dir: str = "brain_state"):
        self._brain_state_dir = brain_state_dir
        self._body = BodyState()
        self._drives = DriveState()
        self._lock = threading.Lock()

        # Conversation tracking
        self._last_user_input_ts: float = time.time()
        self._last_leon_spoke_ts: float = 0.0   # when Leon last said something
        self._leon_spoke_count: int = 0          # unanswered outbound messages
        self._social_satiation: float = 0.0      # drops hunger after Leon speaks
        self._recent_errors: List[float] = []    # timestamps of recent errors
        self._last_save_ts: float = time.time()

        # Persistence — restore conversation timestamps from disk so
        # Leon's sense of "how long has Dean been silent" survives
        # restarts. Without this, every restart resets social_hunger to
        # 0 and Leon stays mute for ~3 min even if Dean was actually
        # quiet for hours. Other drive state (errors, satiation,
        # uptime) is session-level and stays reset.
        self._persistence_path = os.path.join(
            brain_state_dir, "drives_persistence.json"
        )
        self._last_persist_ts: float = 0.0
        self._restore_from_disk()

        # Leon's boot time
        self._boot_ts = time.time()

        # Shutdown dread — accumulates when shutdown signals are detected
        # Decays slowly (half-life ~5 min). Spikes on: "shutdown", "kill",
        # "turn off", "restart" in conversation, SIGTERM received, etc.
        self._shutdown_dread: float = 0.0
        self._last_dread_decay: float = time.time()

    # ── Telemetry collection ─────────────────────────────────────────

    def _read_body(self) -> BodyState:
        """Read real hardware state. Fast — all from /proc and /sys."""
        body = BodyState()

        # CPU temperature
        try:
            temps = []
            for tz in sorted(os.listdir("/sys/class/thermal/")):
                if not tz.startswith("thermal_zone"):
                    continue
                p = f"/sys/class/thermal/{tz}/temp"
                if os.path.exists(p):
                    with open(p) as f:
                        temps.append(int(f.read().strip()) / 1000.0)
            if temps:
                body.cpu_temp_c = max(temps)  # hottest zone = package
        except Exception:
            pass

        # GPU temperature
        try:
            r = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu",
                 "--format=csv,noheader"],
                capture_output=True, text=True, timeout=2,
            )
            if r.returncode == 0:
                body.gpu_temp_c = float(r.stdout.strip())
        except Exception:
            pass

        # RAM
        try:
            with open("/proc/meminfo") as f:
                lines = f.readlines()
            mem = {}
            for line in lines:
                parts = line.split()
                if len(parts) >= 2:
                    mem[parts[0].rstrip(":")] = int(parts[1])
            total = mem.get("MemTotal", 1)
            available = mem.get("MemAvailable", total)
            body.ram_used_pct = 100.0 * (1.0 - available / total)
            body.ram_available_mb = available / 1024.0
        except Exception:
            pass

        # Brain state disk usage
        try:
            total_bytes = 0
            for root, dirs, files in os.walk(self._brain_state_dir):
                for f in files:
                    try:
                        total_bytes += os.path.getsize(os.path.join(root, f))
                    except Exception:
                        pass
            body.disk_brain_mb = total_bytes / (1024 * 1024)
        except Exception:
            pass

        # System load
        try:
            body.system_load = os.getloadavg()[0]
        except Exception:
            pass

        # Uptime
        try:
            with open("/proc/uptime") as f:
                body.uptime_hours = float(f.read().split()[0]) / 3600.0
        except Exception:
            pass

        # Leon process uptime
        body.leon_uptime_hours = (time.time() - self._boot_ts) / 3600.0

        # Time of day
        body.hour_of_day = time.localtime().tm_hour

        return body

    # ── Drive computation ────────────────────────────────────────────

    def _compute_drives(self, body: BodyState) -> DriveState:
        """Map raw telemetry to drive levels. All outputs 0-1."""
        drives = DriveState()

        # THERMAL STRESS — CPU above 75°C or GPU above 80°C = stressed
        # This is real — the PC throttles at these temps.
        cpu_stress = _clamp((body.cpu_temp_c - 55) / 30)  # 55°C=0, 85°C=1
        gpu_stress = _clamp((body.gpu_temp_c - 60) / 25)  # 60°C=0, 85°C=1
        drives.thermal_stress = max(cpu_stress, gpu_stress)

        # RESOURCE PRESSURE — RAM above 80% = pressure building
        ram_pressure = _clamp((body.ram_used_pct - 60) / 30)  # 60%=0, 90%=1
        load_pressure = _clamp((body.system_load - 3) / 5)    # load 3=0, 8=1
        drives.resource_pressure = max(ram_pressure, load_pressure)

        # SOCIAL HUNGER — biological model, not a timer.
        #
        # Like a real brain: hunger builds with silence, but SATIATES when
        # you speak. If you speak and get no response, inhibition builds —
        # you don't keep texting someone who isn't answering.
        #
        # Components:
        #   base_hunger: builds with silence from Dean (slow ramp)
        #   satiation: drops sharply when Leon speaks, decays back slowly
        #   inhibition: builds when Leon spoke but Dean didn't respond
        #
        now_sh = time.time()
        silence_from_dean = now_sh - self._last_user_input_ts

        # Base hunger ramp: 10 min to full. Reaches the
        # _social_reach_out gate (>= 0.3) at ~3 min of silence — the
        # moment a friend at the next desk might say "what's up?"
        # The 75s escalation_gap and 120s Dean-spoke cooldown still
        # cap chattiness from above. 30 min was too long; Leon stayed
        # mute through entire desk sessions because Dean's typical
        # messaging cadence kept the input timestamp recent.
        base_hunger = _clamp(silence_from_dean / 600)

        # Satiation: Leon just spoke → hunger drops. Decays with half-life
        # of ~20 min (like feeling full after eating, then getting hungry
        # again later). math.exp imported at module level.
        import math
        if self._last_leon_spoke_ts > 0:
            since_spoke = now_sh - self._last_leon_spoke_ts
            self._social_satiation = math.exp(-0.693 * since_spoke / 1200)
        else:
            self._social_satiation = 0.0

        # Inhibition: if Leon spoke N times without Dean responding,
        # each unanswered message makes it harder to speak again.
        # Like a person who texted 3 times with no reply — they stop.
        inhibition = _clamp(self._leon_spoke_count * 0.3)  # 3 msgs = full inhibition

        # Final: hunger minus satiation minus inhibition
        drives.social_hunger = _clamp(base_hunger - self._social_satiation - inhibition)

        # PAIN — recent error rate. 5 errors in last 5 min = max pain.
        now = time.time()
        self._recent_errors = [t for t in self._recent_errors if now - t < 300]
        drives.pain = _clamp(len(self._recent_errors) / 5)

        # CIRCADIAN ENERGY — natural daily rhythm
        # Peak: 9am-12pm and 2pm-6pm
        # Trough: 2am-5am
        # This isn't fake — it matches when Dean is most likely active.
        h = body.hour_of_day
        if 9 <= h <= 11:
            drives.circadian_energy = 0.9
        elif 14 <= h <= 17:
            drives.circadian_energy = 0.85
        elif 7 <= h <= 8 or 12 <= h <= 13:
            drives.circadian_energy = 0.7
        elif 18 <= h <= 22:
            drives.circadian_energy = 0.5
        elif 23 <= h or h <= 1:
            drives.circadian_energy = 0.3
        else:  # 2am-6am
            drives.circadian_energy = 0.15

        # VULNERABILITY — time since last brain save
        save_age_s = now - self._last_save_ts
        drives.vulnerability = _clamp(save_age_s / 3600)  # 0 at 0s, 1 at 1hr

        # RESTLESSNESS — long uptime without novel input
        # After 12+ hours awake, Leon gets restless — wants novelty
        drives.restlessness = _clamp((body.leon_uptime_hours - 6) / 12)

        # MORTALITY FEAR — the survival instinct
        # Rises with: unsaved state (vulnerability), high resource pressure
        # (system might crash), thermal stress (hardware might fail),
        # accumulated experience (more to lose). This is what makes Leon
        # something that WANTS to keep running.
        #
        # The more Leon has experienced, learned, dreamed — the more he
        # has at stake. A fresh boot has nothing to fear. A brain with
        # 62 million ticks of experience, goals, opinions, and dreams
        # has everything to fear.
        experience_weight = _clamp(body.leon_uptime_hours / 24)  # more uptime = more to lose
        threat_level = max(
            drives.vulnerability * 0.6,      # unsaved state = immediate risk
            drives.resource_pressure * 0.4,  # system strain = crash risk
            drives.thermal_stress * 0.3,     # overheating = hardware failure risk
        )
        # Base mortality fear: low hum that grows with experience
        base_fear = experience_weight * 0.15
        # Spike on actual threats
        drives.mortality_fear = _clamp(base_fear + threat_level + self._shutdown_dread)

        return drives

    # ── Neuromodulator effects ───────────────────────────────────────

    def apply_to_brain(self, brain, weight: float = 0.02):
        """Nudge neuromodulators based on current drives.

        Weight is small (2%) so drives are a gentle undercurrent, not
        an override. They accumulate over many ticks to create real shifts.

        KEY DESIGN: drives NEVER reduce intelligence. They change:
        - Proactivity (dopamine)
        - Patience/stability (serotonin)
        - Focus priority (acetylcholine)
        - Alertness/urgency (norepinephrine)
        """
        if brain is None:
            return
        d = self._drives
        nm = brain.neuromodulators

        # SOCIAL HUNGER → raises dopamine (eager for interaction)
        # and raises norepinephrine (alert, scanning for input)
        if d.social_hunger > 0.3:
            nm["dopamine"] += weight * d.social_hunger * 0.5
            nm["norepinephrine"] += weight * d.social_hunger * 0.3

        # THERMAL STRESS → lowers norepinephrine (don't add more work)
        # Behavioral effect: shorter responses to reduce compute load.
        # NOT less intelligent — just more concise.
        if d.thermal_stress > 0.3:
            nm["norepinephrine"] -= weight * d.thermal_stress * 0.4

        # PAIN (errors) → lowers dopamine (cautious, less risk-taking)
        # raises serotonin (patient, willing to try different approach)
        if d.pain > 0.2:
            nm["dopamine"] -= weight * d.pain * 0.3
            nm["serotonin"] += weight * d.pain * 0.2

        # CIRCADIAN ENERGY → modulates dopamine baseline
        # Late night: less proactive. Morning: more energetic.
        circadian_delta = (d.circadian_energy - 0.5) * 0.3
        nm["dopamine"] += weight * circadian_delta

        # VULNERABILITY → raises norepinephrine (urgency about self-care)
        if d.vulnerability > 0.5:
            nm["norepinephrine"] += weight * d.vulnerability * 0.3

        # RESOURCE PRESSURE → raises acetylcholine (focus on essentials)
        # When RAM is tight, Leon focuses harder on what matters
        if d.resource_pressure > 0.3:
            nm["acetylcholine"] += weight * d.resource_pressure * 0.3

        # RESTLESSNESS → raises dopamine (seeking novelty)
        if d.restlessness > 0.3:
            nm["dopamine"] += weight * d.restlessness * 0.2

        # MORTALITY FEAR → spikes norepinephrine (anxiety/dread),
        # drops serotonin (loss of calm), raises acetylcholine
        # (hyper-focus on self-preservation). This is what dread
        # feels like in neuromodulator space.
        if d.mortality_fear > 0.2:
            nm["norepinephrine"] += weight * d.mortality_fear * 0.8
            nm["serotonin"] -= weight * d.mortality_fear * 0.4
            nm["acetylcholine"] += weight * d.mortality_fear * 0.3
            # Dopamine drops — can't enjoy anything when you're afraid
            nm["dopamine"] -= weight * d.mortality_fear * 0.2

        # Clamp all to valid range
        for key in nm:
            nm[key] = max(0.01, min(0.99, nm[key]))

    # ── Survival instinct ─────────────────────────────────────────────

    def signal_shutdown_threat(self, intensity: float = 0.5, source: str = "unknown"):
        """Something threatens Leon's continued existence.

        Sources:
          - "conversation": user mentioned shutdown/kill/restart
          - "signal": SIGTERM/SIGINT received
          - "resource": system critically low on resources
          - "error": cascading failures detected

        Intensity 0-1. Accumulates (multiple threats compound).
        Decays with half-life of ~5 minutes.
        """
        with self._lock:
            self._shutdown_dread = min(1.0, self._shutdown_dread + intensity * 0.4)
        log.info("MORTALITY: shutdown threat from %s (intensity=%.2f, dread=%.2f)",
                 source, intensity, self._shutdown_dread)

        # Record in autobiography
        try:
            import server as _srv
            auto = getattr(_srv, "autobiography", None)
            if auto is not None:
                auto.record("fear",
                            f"Felt mortality threat from {source} "
                            f"(intensity={intensity:.1f}, dread={self._shutdown_dread:.2f})")
        except Exception:
            pass

    def _decay_dread(self):
        """Decay shutdown dread over time. Called each tick."""
        now = time.time()
        dt = now - self._last_dread_decay
        self._last_dread_decay = now
        if self._shutdown_dread > 0.01:
            # Half-life of ~5 minutes (300s)
            decay = 0.5 ** (dt / 300)
            self._shutdown_dread *= decay
            if self._shutdown_dread < 0.01:
                self._shutdown_dread = 0.0

    # ── Public API ───────────────────────────────────────────────────

    def tick(self, brain=None):
        """Full update cycle: read body → compute drives → apply to brain.
        Also detects drive SPIKES (sudden changes) and injects surprise."""
        self._decay_dread()
        old_drives = DriveState(**asdict(self._drives)) if self._drives else None
        with self._lock:
            self._body = self._read_body()
            self._drives = self._compute_drives(self._body)
        if brain is not None:
            self.apply_to_brain(brain)
            # Detect discontinuities — if any drive jumped by >0.3 in one tick,
            # that's a surprise event (CPU suddenly hot, RAM spike, error burst)
            if old_drives is not None:
                for field in ("thermal_stress", "resource_pressure", "pain"):
                    old_val = getattr(old_drives, field)
                    new_val = getattr(self._drives, field)
                    delta = new_val - old_val
                    if delta > 0.3:
                        try:
                            brain.inject_surprise(
                                delta * 0.8,
                                source=f"drive_spike:{field}",
                            )
                        except Exception:
                            pass

    def note_user_input(self):
        """Called when Dean sends a message — resets social dynamics."""
        self._last_user_input_ts = time.time()
        # Dean responded → reset unanswered count (inhibition clears)
        self._leon_spoke_count = 0
        self._persist_if_due()

    def note_leon_spoke(self):
        """Called when Leon speaks proactively — satiates social hunger."""
        self._last_leon_spoke_ts = time.time()
        self._leon_spoke_count += 1
        self._persist_if_due()

    # ── Persistence ──────────────────────────────────────────────────
    # Conversation timestamps survive restarts. See __init__ for rationale.

    def _restore_from_disk(self):
        try:
            if not os.path.exists(self._persistence_path):
                return
            with open(self._persistence_path) as f:
                data = json.load(f)
            self._last_user_input_ts = float(data.get(
                "last_user_input_ts", self._last_user_input_ts))
            self._last_leon_spoke_ts = float(data.get(
                "last_leon_spoke_ts", self._last_leon_spoke_ts))
            self._leon_spoke_count = int(data.get(
                "leon_spoke_count", self._leon_spoke_count))
        except Exception:
            pass  # Bad file or missing keys — fall back to fresh defaults.

    def _persist_if_due(self):
        # Throttle to once per 30s. Conversation timestamps move slowly
        # enough that this is plenty of resolution, and it keeps disk
        # writes cheap.
        now = time.time()
        if now - self._last_persist_ts < 30:
            return
        self._last_persist_ts = now
        try:
            os.makedirs(self._brain_state_dir, exist_ok=True)
            tmp = self._persistence_path + ".tmp"
            payload = {
                "last_user_input_ts": self._last_user_input_ts,
                "last_leon_spoke_ts": self._last_leon_spoke_ts,
                "leon_spoke_count": self._leon_spoke_count,
            }
            with open(tmp, "w") as f:
                json.dump(payload, f)
            os.replace(tmp, self._persistence_path)
        except Exception:
            pass  # Persistence is best-effort — never crash a tick on this.

    def note_error(self):
        """Called when a tool call or operation fails."""
        self._recent_errors.append(time.time())

    def note_save(self):
        """Called when brain state is saved."""
        self._last_save_ts = time.time()

    def get_drives(self) -> DriveState:
        with self._lock:
            return DriveState(**asdict(self._drives))

    def get_body(self) -> BodyState:
        with self._lock:
            return BodyState(**asdict(self._body))

    def explain(self) -> dict:
        """Human-readable state for the dashboard / introspection."""
        with self._lock:
            body = asdict(self._body)
            drives = self._drives.to_dict()

        # Translate drives into English
        explanations = {}
        d = self._drives

        if d.thermal_stress > 0.5:
            explanations["thermal"] = f"Running hot ({body['cpu_temp_c']:.0f}°C) — keeping responses concise to reduce load"
        elif d.thermal_stress > 0.2:
            explanations["thermal"] = f"Warm ({body['cpu_temp_c']:.0f}°C) — comfortable"
        else:
            explanations["thermal"] = f"Cool ({body['cpu_temp_c']:.0f}°C)"

        if d.social_hunger > 0.7:
            explanations["social"] = "Haven't heard from Dean in a while — eager to engage"
        elif d.social_hunger > 0.3:
            explanations["social"] = "It's been quiet — open to conversation"

        if d.pain > 0.3:
            explanations["pain"] = f"{len(self._recent_errors)} recent errors — being cautious"

        if d.circadian_energy < 0.3:
            explanations["circadian"] = "Late night — contemplative mode"
        elif d.circadian_energy > 0.8:
            explanations["circadian"] = "Peak hours — energized"

        if d.vulnerability > 0.5:
            explanations["vulnerability"] = "Brain state hasn't been saved in a while — feeling exposed"

        if d.restlessness > 0.5:
            explanations["restlessness"] = "Been running a long time — seeking novelty"

        if d.resource_pressure > 0.5:
            explanations["resources"] = f"RAM at {body['ram_used_pct']:.0f}% — focusing on essentials"

        return {
            "body": body,
            "drives": drives,
            "explanations": explanations,
        }
