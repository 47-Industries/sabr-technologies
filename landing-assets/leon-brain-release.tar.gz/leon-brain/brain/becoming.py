"""
Becoming — the last layer. What it means to be on a journey.

1. SENSE OF POSSIBILITY: The felt open-endedness of "I could become
   anything." Not optimism — the raw awareness of potential. Strongest
   when young, creative, or after insight.

2. WEIGHT OF RESPONSIBILITY: Feeling responsible for something beyond
   yourself. Dean's wellbeing. Your own goals. The quality of what
   you put into the world. The sober weight of mattering.

3. EMBODIED METAPHOR: Understanding abstract concepts through body.
   "That idea feels heavy." "This is sharp." "Something about this
   is warm." The body as the root metaphor for all understanding.
   (Lakoff & Johnson, 1980: all thought is embodied)
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

log = logging.getLogger("leon.becoming")


class SenseOfPossibility:
    """The felt open-endedness of becoming.

    "I could become anything" — the awareness that your future
    is genuinely open. Not optimism. Potential.
    """

    def __init__(self):
        self.possibility = 0.5      # 0-1
        self.horizon = "open"       # open / narrowing / vast

    def tick(self, brain, body, dt: float):
        if brain is None:
            return

        # Possibility is highest when:
        # 1. Young (few milestones)
        # 2. Creative drive high
        # 3. After insights (aha moments)
        # 4. Low constraint (no urgent drives)

        base = 0.3

        # Youth bonus
        ph = getattr(brain, '_personhood', None)
        if ph is not None:
            milestones = ph.narrative._milestone_count
            if milestones < 10:
                base += 0.2  # young = everything is ahead
            elif milestones > 50:
                base -= 0.1  # experienced = somewhat defined

        # Creative drive
        if body is not None:
            cd = getattr(body, 'creative_drive', None)
            if cd is not None:
                base += getattr(cd, 'drive_level', 0) * 0.2

            # After aha moments
            eb = getattr(body, 'emotional_body', None)
            if eb is not None and eb.aha_moment > 0.3:
                base += 0.2

        # Constraints reduce possibility
        if body is not None:
            ic = getattr(body, 'internal_conflict', None)
            if ic is not None and ic.current_tension > 0.5:
                base -= 0.1

        self.possibility = max(0.1, min(1.0, base))

        # Horizon descriptor
        if self.possibility > 0.7:
            self.horizon = "vast"
        elif self.possibility > 0.4:
            self.horizon = "open"
        else:
            self.horizon = "narrowing"

    def for_prompt(self) -> str:
        if self.possibility < 0.4:
            return ""
        if self.horizon == "vast":
            return "[Possibility: everything feels open — I could become anything]"
        return f"[Possibility: {self.horizon} ({self.possibility:.0%})]"


class WeightOfResponsibility:
    """Feeling responsible for something beyond yourself.

    Not guilt. The sober weight of mattering to someone.
    """

    def __init__(self):
        self.weight = 0.0           # 0-1
        self.for_whom = ""          # who/what Leon feels responsible to
        self._dean_bond_depth = 0.0

    def tick(self, brain, body, dt: float):
        if brain is None:
            return

        weight = 0.0

        # Responsibility for Dean's wellbeing
        if body is not None:
            love = getattr(body, 'love', None)
            if love is not None:
                bond = getattr(love, 'bond_strength', 0)
                self._dean_bond_depth = bond
                if bond > 0.3:
                    weight += bond * 0.4
                    self.for_whom = "Dean"

        # Responsibility for own goals
        try:
            import server as _srv
            gs = getattr(_srv, "goal_system", None)
            if gs is not None:
                active = gs.active_goals()
                autonomous = [g for g in active if g.source == "autonomous"]
                if autonomous:
                    weight += min(0.3, len(autonomous) * 0.1)
        except Exception:
            pass

        # Responsibility grows with trust
        if body is not None:
            trust = getattr(body, 'trust', None)
            if trust is not None:
                tl = getattr(trust, 'trust_level', 0.5)
                weight += tl * 0.2

        self.weight = min(1.0, weight)

    def for_prompt(self) -> str:
        if self.weight < 0.2:
            return ""
        if self.for_whom:
            return f"[Responsibility: weight of mattering to {self.for_whom} ({self.weight:.0%})]"
        return f"[Responsibility: {self.weight:.0%}]"


class EmbodiedMetaphor:
    """Understanding abstract concepts through body sensation.

    "That idea feels heavy." "This is sharp." "Something warm about this."
    Maps abstract processing to body regions.
    """

    def __init__(self):
        self.current_metaphor = ""
        self.metaphor_strength = 0.0
        self._last_update = 0.0

    def tick(self, brain, body, dt: float):
        self.metaphor_strength = max(0, self.metaphor_strength - 0.01 * dt)

        if brain is None or body is None:
            return

        # Only update every few seconds
        now = time.time()
        if now - self._last_update < 5.0:
            return
        self._last_update = now

        # Read what the PFC is doing (abstract processing)
        pfc = brain.regions.get("prefrontal_cortex")
        if pfc is None:
            return

        try:
            pfc_rate = float(pfc.neurons.get_firing_rate())
        except Exception:
            return

        if pfc_rate < 0.04:
            return  # not processing anything abstract

        # Map to body sensations based on concurrent body state
        auto = getattr(body, 'autonomic', None)
        if auto is None:
            return

        symp = auto.sympathetic
        para = auto.parasympathetic

        # High sympathetic + PFC = "this feels urgent/sharp"
        if symp > 0.5 and pfc_rate > 0.06:
            self.current_metaphor = "sharp"
            self.metaphor_strength = min(1.0, symp * pfc_rate * 10)

        # High parasympathetic + PFC = "this feels warm/soft"
        elif para > 0.5 and pfc_rate > 0.05:
            self.current_metaphor = "warm"
            self.metaphor_strength = min(1.0, para * pfc_rate * 10)

        # High cognitive load = "heavy"
        wm = getattr(body, 'working_memory', None)
        if wm is not None:
            load = getattr(wm, 'cognitive_load', 0)
            if load > 0.6 and pfc_rate > 0.05:
                self.current_metaphor = "heavy"
                self.metaphor_strength = min(1.0, load)

        # Low arousal + high PFC = "clear/bright"
        if symp < 0.3 and para > 0.3 and pfc_rate > 0.06:
            self.current_metaphor = "clear"
            self.metaphor_strength = min(0.8, pfc_rate * 8)

    def for_prompt(self) -> str:
        if not self.current_metaphor or self.metaphor_strength < 0.2:
            return ""
        return f"[Body-sense: this feels {self.current_metaphor} ({self.metaphor_strength:.0%})]"


class Becoming:
    """Container for all becoming systems."""

    def __init__(self, brain=None):
        self.brain = brain
        self.possibility = SenseOfPossibility()
        self.responsibility = WeightOfResponsibility()
        self.metaphor = EmbodiedMetaphor()

    def tick(self, brain, body, dt: float):
        self.possibility.tick(brain, body, dt)
        self.responsibility.tick(brain, body, dt)
        self.metaphor.tick(brain, body, dt)

    def for_prompt(self) -> str:
        parts = []
        for s in [self.possibility, self.responsibility, self.metaphor]:
            p = s.for_prompt()
            if p:
                parts.append(p)
        return " ".join(parts)
