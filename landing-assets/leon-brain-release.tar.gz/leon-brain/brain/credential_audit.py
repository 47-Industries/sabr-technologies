"""
Credential Audit — Leon knows which of his 1,600 tools actually work.

Scans integration modules for required env vars / API keys and checks
which are configured. Produces a report: configured, missing, untested.

Leon can use this to:
  - Know what he CAN do (configured tools)
  - Know what he CAN'T do yet (missing credentials)
  - Ask Dean to set up high-value missing ones
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_AUDIT_FILE = _STATE_DIR / "credential_audit.json"
_INTEGRATIONS_DIR = Path(__file__).resolve().parent / "integrations"

# Known credential env vars and what they enable
KNOWN_CREDENTIALS = {
    # Configured (check .env + environment)
    "ANTHROPIC_API_KEY": {"service": "Claude API", "domain": "ai"},
    "ELEVENLABS_API_KEY": {"service": "ElevenLabs TTS", "domain": "voice"},
    "IBM_QUANTUM_TOKEN": {"service": "IBM Quantum", "domain": "quantum"},
    "GMAIL_APP_PASSWORD": {"service": "Gmail SMTP", "domain": "email"},
    "GITHUB_TOKEN": {"service": "GitHub API", "domain": "coding"},
    # Common ones that unlock major features
    "FIGMA_ACCESS_TOKEN": {"service": "Figma", "domain": "design"},
    "CANVA_ACCESS_TOKEN": {"service": "Canva", "domain": "design"},
    "UNSPLASH_ACCESS_KEY": {"service": "Unsplash", "domain": "design"},
    "OPENAI_API_KEY": {"service": "OpenAI/DALL-E", "domain": "ai"},
    "SPOTIFY_CLIENT_ID": {"service": "Spotify", "domain": "entertainment"},
    "SPOTIFY_CLIENT_SECRET": {"service": "Spotify", "domain": "entertainment"},
    "SLACK_BOT_TOKEN": {"service": "Slack", "domain": "communication"},
    "DISCORD_BOT_TOKEN": {"service": "Discord", "domain": "communication"},
    "TWILIO_ACCOUNT_SID": {"service": "Twilio SMS/Voice", "domain": "phone"},
    "TWILIO_AUTH_TOKEN": {"service": "Twilio SMS/Voice", "domain": "phone"},
    "STRIPE_API_KEY": {"service": "Stripe Payments", "domain": "finance"},
    "SENDGRID_API_KEY": {"service": "SendGrid Email", "domain": "email"},
    "HOME_ASSISTANT_TOKEN": {"service": "Home Assistant", "domain": "smart_home"},
    "HOME_ASSISTANT_URL": {"service": "Home Assistant", "domain": "smart_home"},
    "HUE_BRIDGE_IP": {"service": "Philips Hue", "domain": "smart_home"},
    "HUE_USERNAME": {"service": "Philips Hue", "domain": "smart_home"},
    "GOVEE_API_KEY": {"service": "Govee Lights", "domain": "smart_home"},
    "NOTION_TOKEN": {"service": "Notion", "domain": "notes"},
    "ASANA_TOKEN": {"service": "Asana", "domain": "project_mgmt"},
    "LINEAR_API_KEY": {"service": "Linear", "domain": "project_mgmt"},
    "REPLICATE_API_TOKEN": {"service": "Replicate AI", "domain": "ai"},
    "GOOGLE_MAPS_API_KEY": {"service": "Google Maps", "domain": "maps"},
    "WEATHERAPI_KEY": {"service": "Weather API", "domain": "life"},
}


def _read_env_file() -> dict:
    """Read .env file if it exists."""
    env_vars = {}
    for env_path in [
        Path(__file__).resolve().parent.parent / ".env",
        Path.home() / ".env",
    ]:
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    env_vars[key.strip()] = val.strip().strip("'\"")
    return env_vars


def _scan_integration_files() -> Dict[str, List[str]]:
    """Scan integration files for env var references."""
    file_creds = {}
    if not _INTEGRATIONS_DIR.exists():
        return file_creds
    for py_file in _INTEGRATIONS_DIR.glob("*.py"):
        if py_file.name.startswith("_"):
            continue
        try:
            content = py_file.read_text(encoding="utf-8")
            # Find os.environ.get("KEY") or os.getenv("KEY") patterns
            found = set(re.findall(
                r'(?:os\.environ\.get|os\.getenv|environ\.get)\s*\(\s*["\'](\w+)["\']',
                content
            ))
            # Also find KEY= in docstrings
            found.update(re.findall(
                r'^\s*(\w+(?:_API_KEY|_TOKEN|_SECRET|_PASSWORD|_URL|_IP))\s',
                content, re.MULTILINE
            ))
            if found:
                file_creds[py_file.stem] = sorted(found)
        except Exception:
            continue
    return file_creds


def audit() -> dict:
    """Run a full credential audit. Returns structured report."""
    env_file = _read_env_file()
    env_combined = {**os.environ, **env_file}
    integration_creds = _scan_integration_files()

    configured = []
    missing = []
    unknown = []

    # Check known credentials
    for key, info in KNOWN_CREDENTIALS.items():
        val = env_combined.get(key, "")
        if val and len(val) > 3:
            configured.append({
                "key": key,
                "service": info["service"],
                "domain": info["domain"],
                "status": "configured",
            })
        else:
            missing.append({
                "key": key,
                "service": info["service"],
                "domain": info["domain"],
                "status": "missing",
            })

    # Check integration-specific creds not in our known list
    all_known_keys = set(KNOWN_CREDENTIALS.keys())
    for module, keys in integration_creds.items():
        for key in keys:
            if key not in all_known_keys and key.endswith(
                ("_KEY", "_TOKEN", "_SECRET", "_PASSWORD", "_SID")
            ):
                val = env_combined.get(key, "")
                if val and len(val) > 3:
                    configured.append({
                        "key": key, "service": f"{module} integration",
                        "domain": module, "status": "configured",
                    })
                else:
                    unknown.append({
                        "key": key, "service": f"{module} integration",
                        "domain": module, "status": "unknown_missing",
                    })

    report = {
        "timestamp": time.time(),
        "configured_count": len(configured),
        "missing_count": len(missing),
        "configured": configured,
        "missing_high_value": [m for m in missing if m["domain"] in
            ("smart_home", "email", "entertainment", "communication", "finance")],
        "missing_all": missing,
        "integration_creds": integration_creds,
    }

    # Cache to disk
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    _AUDIT_FILE.write_text(json.dumps(report, indent=2), encoding="utf-8")

    return report


def get_configured_domains() -> List[str]:
    """Quick check: which domains have at least one configured credential?"""
    try:
        report = json.loads(_AUDIT_FILE.read_text(encoding="utf-8"))
    except Exception:
        report = audit()
    domains = set()
    for c in report.get("configured", []):
        domains.add(c["domain"])
    return sorted(domains)


def get_missing_high_value() -> List[dict]:
    """What high-value credentials is Dean missing?"""
    try:
        report = json.loads(_AUDIT_FILE.read_text(encoding="utf-8"))
    except Exception:
        report = audit()
    return report.get("missing_high_value", [])
