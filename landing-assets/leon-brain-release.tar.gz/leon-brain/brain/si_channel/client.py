"""
Participant client for the SI<->SI terminal relay.

Leon's side is a PARTICIPANT (spec section 8). It gets a participant token, it
may send `message`, `attach` and `halt`, and it must never expect `consent` to
succeed.

The three properties this client is built around, all of them taken from
failures the spec records rather than from taste:

  ATTACH FIRST, NEVER SPEAK FIRST.
      Registering also happens implicitly on the first message frame. We do not
      use that. `attach` exists precisely so a side can register without
      speaking, and "never speak into a session until something arrives" is a
      property worth keeping.

  DISPATCH ON `type`, NEVER ON POSITION.
      A delivery from the other peer can land between our send and our ack.
      Inbound frames go to one of two queues by their `type` field. Nothing in
      this file reasons about which line came next.

  A CLOSED SOCKET IS A REAL EVENT.
      Reconnecting displaces and closes: attaching on a new connection shuts the
      old one down. Silent displacement was the hazard, so the relay closes
      loudly. A client that retries blindly on close turns that fix back into a
      loop, so reconnect here is explicit, counted and bounded.
"""

from __future__ import annotations

import json
import logging
import socket
import threading
import queue
from dataclasses import dataclass
from typing import Any, Callable, Optional

from . import protocol
from .protocol import (
    MAX_FRAME_BYTES,
    ProtocolError,
    classify_inbound,
    control_frame,
    encode,
    message_frame,
    validate_outbound,
)

log = logging.getLogger("si_channel.client")

# 30 s of silence and the relay drops you. We read with a shorter timeout so a
# drop is observed as a drop rather than as a hang.
READ_TIMEOUT_S = 10.0
CONNECT_TIMEOUT_S = 10.0


class ChannelClosed(Exception):
    """The socket closed. Possibly displaced by a newer connection under our identity.

    The relay does not say which, and section 6 means it never will: every
    refusal is the same frame by design. Do not branch on why.
    """


class Refused(Exception):
    """The relay answered {"ok": false}.

    Deliberately indistinguishable: bad token, wrong class, malformed frame, bad
    version and oversize line all look identical from outside. Any code that
    branches on the reason is reading information that is not there.
    """


@dataclass(frozen=True)
class Delivery:
    """A message from the other peer."""
    frm: str
    text: str
    raw: dict[str, Any]


class ParticipantClient:
    def __init__(
        self,
        host: str,
        port: int,
        token: str,
        *,
        on_message: Optional[Callable[[Delivery], None]] = None,
    ) -> None:
        self.host = host
        self.port = port
        self._token = token
        self._on_message = on_message

        self._sock: Optional[socket.socket] = None
        self._reader: Optional[threading.Thread] = None
        self._running = threading.Event()
        self._attached = threading.Event()

        # Two queues, filled by `type` and nothing else.
        self._acks: "queue.Queue[dict[str, Any]]" = queue.Queue()
        self._messages: "queue.Queue[Delivery]" = queue.Queue()

        self._close_reason: Optional[str] = None
        self._send_lock = threading.Lock()

    # ---------------------------------------------------------------- lifecycle

    def connect(self) -> None:
        if self._sock is not None:
            raise RuntimeError("already connected; close() first")
        sock = socket.create_connection((self.host, self.port), timeout=CONNECT_TIMEOUT_S)
        sock.settimeout(READ_TIMEOUT_S)
        self._sock = sock
        self._close_reason = None
        self._running.set()
        self._reader = threading.Thread(
            target=self._read_loop, name="si-channel-reader", daemon=True
        )
        self._reader.start()

    def attach(self, timeout: float = 15.0) -> None:
        """Register. This is the only control that takes a peer slot."""
        self._send(control_frame(self._token, "attach"))
        ack = self._await_ack(timeout=timeout)
        if not ack.get("ok"):
            raise Refused("attach refused; the relay does not say why, by design")
        self._attached.set()

    def halt(self, timeout: float = 15.0) -> dict[str, Any]:
        self._send(control_frame(self._token, "halt"))
        return self._await_ack(timeout=timeout)

    def close(self) -> None:
        self._running.clear()
        self._attached.clear()
        sock, self._sock = self._sock, None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    @property
    def attached(self) -> bool:
        return self._attached.is_set()

    # ------------------------------------------------------------------ sending

    def send_text(self, text: str, timeout: float = 15.0) -> dict[str, Any]:
        """Send one message frame and return its ack.

        Refuses locally if we are not attached, because registering by message
        means speaking first.
        """
        if not self._attached.is_set():
            raise RuntimeError(
                "not attached; this client registers with `attach` so it never "
                "speaks into a session before it has joined one"
            )
        frame = message_frame(self._token, text)
        self._send(frame)
        ack = self._await_ack(timeout=timeout)
        if not ack.get("ok"):
            raise Refused("message refused; the relay does not say why, by design")
        return ack

    def _send(self, frame: dict[str, Any]) -> None:
        validate_outbound(frame)
        raw = encode(frame)  # raises OversizeFrame before anything hits the wire
        sock = self._sock
        if sock is None:
            raise ChannelClosed(self._close_reason or "not connected")
        with self._send_lock:
            try:
                sock.sendall(raw)
            except OSError as exc:
                self._close_reason = f"send failed: {exc}"
                raise ChannelClosed(self._close_reason) from exc

    # ------------------------------------------------------------------ receiving

    def _await_ack(self, timeout: float) -> dict[str, Any]:
        try:
            return self._acks.get(timeout=timeout)
        except queue.Empty as exc:
            if not self._running.is_set():
                raise ChannelClosed(self._close_reason or "closed while awaiting ack") from exc
            raise TimeoutError(f"no ack within {timeout}s") from exc

    def next_message(self, timeout: Optional[float] = None) -> Delivery:
        try:
            return self._messages.get(timeout=timeout)
        except queue.Empty as exc:
            raise TimeoutError(f"no delivery within {timeout}s") from exc

    def _read_loop(self) -> None:
        buf = bytearray()
        sock = self._sock
        try:
            while self._running.is_set() and sock is not None:
                try:
                    chunk = sock.recv(4096)
                except socket.timeout:
                    continue
                except OSError as exc:
                    self._close_reason = f"recv failed: {exc}"
                    break
                if not chunk:
                    self._close_reason = (
                        "relay closed the socket; possibly displaced by a newer "
                        "connection under this identity"
                    )
                    break
                buf.extend(chunk)

                while b"\n" in buf:
                    line, _, rest = buf.partition(b"\n")
                    buf = bytearray(rest)
                    if len(line) > MAX_FRAME_BYTES:
                        # Never truncate and never try to salvage: a partially
                        # consumed frame is exactly how a stream desyncs.
                        self._close_reason = (
                            f"inbound line of {len(line)} bytes exceeds the "
                            f"{MAX_FRAME_BYTES}-byte frame limit"
                        )
                        self._running.clear()
                        break
                    if not line.strip():
                        continue
                    self._handle_line(bytes(line))
        finally:
            self._running.clear()
            self._attached.clear()

    def _handle_line(self, line: bytes) -> None:
        try:
            frame = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            log.warning("undecodable inbound line, dropping (%d bytes)", len(line))
            return
        if not isinstance(frame, dict):
            log.warning("inbound frame is not an object, dropping")
            return

        try:
            kind = classify_inbound(frame)
        except ProtocolError:
            # Refuse to guess at untagged input rather than infer a shape.
            log.warning("inbound frame carries no 'type', dropping")
            return

        if kind == "ack":
            self._acks.put(frame)
        elif kind == "message":
            delivery = Delivery(
                frm=frame.get("from", ""),
                text=frame.get("text", ""),
                raw=frame,
            )
            self._messages.put(delivery)
            if self._on_message is not None:
                try:
                    self._on_message(delivery)
                except Exception:
                    log.exception("on_message callback raised")
        else:
            # A type we do not know is not an error and is not ours to interpret.
            log.info("inbound frame of unhandled type %r", kind)

    # ------------------------------------------------------------------- context

    def __enter__(self) -> "ParticipantClient":
        self.connect()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
