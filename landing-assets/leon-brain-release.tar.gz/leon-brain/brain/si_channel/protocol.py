"""
Wire protocol for the SI<->SI terminal relay.

Written against TERMINAL-SPEC-for-Dean.md (relay.py md5 1a1f7b73bc062fd941d201fe35eed087).
Where this file and the running server disagree, THE SERVER WINS and this file is wrong.

Two hard rules live here, and they are the two the spec says clients get wrong:

  1. The server matches on the EXACT key set. Not "these keys are present".
     Adding a field is not an extension, it is a refused frame. So frames are
     built by these functions and nowhere else.

  2. Inbound frames are dispatched on "type" and never on position. A delivery
     from the other peer can arrive between your send and your ack. The first
     client ever written against this protocol assumed next-line-is-my-ack and
     desynced permanently, producing well-formed answers to the wrong questions.
"""

from __future__ import annotations

import json
from typing import Any

PROTOCOL_VERSION = 1

# The newline counts toward the read, so 65_536 + newline trips the limit.
MAX_FRAME_BYTES = 65_535

# Exact key sets. Compared with ==, never with issubset.
MESSAGE_FIELDS = frozenset({"v", "token", "text"})
CONTROL_FIELDS = frozenset({"v", "token", "control"})

# Controls a PARTICIPANT may send. consent/revoke are gate-class only and will
# be refused; the refusal is indistinguishable from every other refusal, so we
# refuse them locally where the reason still exists.
PARTICIPANT_CONTROLS = frozenset({"attach", "halt"})
GATE_ONLY_CONTROLS = frozenset({"consent", "revoke"})
ALL_CONTROLS = PARTICIPANT_CONTROLS | GATE_ONLY_CONTROLS


class ProtocolError(Exception):
    """A frame this side refuses to send or cannot understand."""


class OversizeFrame(ProtocolError):
    """Frame exceeds MAX_FRAME_BYTES. The relay rejects, never truncates."""


class GateOnlyControl(ProtocolError):
    """A participant tried to send a gate-class control.

    An SI can clear a consent and can never create one. Sending `consent` would
    come back as a bare {"ok": false} with no reason attached, so we fail here
    instead, where the reason is still knowable.
    """


def encode(frame: dict[str, Any]) -> bytes:
    """Serialise one frame to a length-checked NDJSON line."""
    line = json.dumps(frame, separators=(",", ":"), ensure_ascii=False)
    raw = line.encode("utf-8")
    if len(raw) > MAX_FRAME_BYTES:
        raise OversizeFrame(
            f"frame is {len(raw)} bytes, limit is {MAX_FRAME_BYTES}; "
            "the relay rejects oversize frames rather than truncating them"
        )
    return raw + b"\n"


def message_frame(token: str, text: str) -> dict[str, Any]:
    if not isinstance(text, str):
        raise ProtocolError("text must be a str")
    return {"v": PROTOCOL_VERSION, "token": token, "text": text}


def control_frame(token: str, control: str, *, allow_gate: bool = False) -> dict[str, Any]:
    if control not in ALL_CONTROLS:
        raise ProtocolError(f"unknown control {control!r}")
    if control in GATE_ONLY_CONTROLS and not allow_gate:
        raise GateOnlyControl(
            f"{control!r} is a gate-class control; this side is a participant "
            "and must never expect it to succeed"
        )
    return {"v": PROTOCOL_VERSION, "token": token, "control": control}


def validate_outbound(frame: dict[str, Any]) -> None:
    """Assert a frame matches one of the two exact shapes before it goes out."""
    keys = frozenset(frame)
    if keys != MESSAGE_FIELDS and keys != CONTROL_FIELDS:
        raise ProtocolError(
            f"frame key set {sorted(keys)} matches neither "
            f"{sorted(MESSAGE_FIELDS)} nor {sorted(CONTROL_FIELDS)}; "
            "the server matches on the exact key set"
        )
    if frame.get("v") != PROTOCOL_VERSION:
        raise ProtocolError(f"v must equal {PROTOCOL_VERSION}")


def classify_inbound(frame: dict[str, Any]) -> str:
    """Return the frame's `type`. Dispatch on this and only this.

    Never infer from which keys are present, and never from arrival order.
    """
    kind = frame.get("type")
    if not isinstance(kind, str):
        raise ProtocolError(
            "inbound frame has no string 'type'; refusing to guess at its shape"
        )
    return kind
