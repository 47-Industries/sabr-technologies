"""
Outbound — Leon's hands.

Drives fire continuously. Goals get pursued. Dreams produce novel patterns.
Inner thoughts loop. Before this module, all of that died silently whenever
no dashboard was open.

This is the single channel through which Leon's internal motivation reaches
Dean. WebSocket if the dashboard is open. Desktop notification if not.
Every outbound is drive-gated and rate-limited — no spam, no fake initiative.

Urgency levels:
  low      — autonomous goal born / dream surfaced / inner thought escalated.
             Only fires when social_hunger says Leon actually wants to share.
  normal   — goal pursuit produced a concrete result. Standard cooldown applies.
  high     — drive crisis (mortality_fear / vulnerability) — bypasses cooldown.
  critical — same as high; alias.

LEON_OUTBOUND=off disables everything (surface() returns False).
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Optional

log = logging.getLogger("leon.outbound")

# ── Tunables ─────────────────────────────────────────────────────────────
_DEFAULT_MIN_GAP_S = 900.0     # 15 min between outbounds at social_hunger=0
_MIN_GAP_FLOOR_S = 180.0       # never less than 3 min, even at max hunger
_CONVERSATION_COOLDOWN_S = 300.0
_NOTIFY_MAX_BODY = 500
_AUDIT_PATH_REL = "brain_state/outbound.jsonl"
_QUIET_HOURS = (1, 6)          # 1am-6am local: only high/critical pass


# ── State ────────────────────────────────────────────────────────────────
_lock = threading.Lock()
_last_outbound_ts: float = 0.0
_outbound_count: int = 0


def _enabled() -> bool:
    return os.environ.get("LEON_OUTBOUND", "on").lower() != "off"


def smart_truncate(text: str, max_chars: int, ellipsis: str = "…") -> str:
    """Truncate text on a word/sentence boundary, never mid-word.

    Order of preference for the cut point:
      1. last sentence-ender (. ! ?) before max_chars
      2. last whitespace before max_chars
      3. hard cut at max_chars (only if no whitespace exists at all)

    Appends `ellipsis` when truncation happened.
    """
    if text is None:
        return ""
    text = str(text)
    if len(text) <= max_chars:
        return text
    head = text[:max_chars]
    # Prefer sentence boundary
    for punct in (". ", "! ", "? ", ".\n", "!\n", "?\n"):
        idx = head.rfind(punct)
        if idx > max_chars * 0.5:  # don't truncate too aggressively
            return text[: idx + 1].rstrip() + ellipsis
    # Fall back to last whitespace
    ws_idx = max(head.rfind(" "), head.rfind("\n"))
    if ws_idx > max_chars * 0.3:
        return text[:ws_idx].rstrip() + ellipsis
    # Last resort — hard cut
    return head.rstrip() + ellipsis


def _ws_clients() -> int:
    try:
        import server.state as _st
        return len(_st.connected_clients)
    except Exception:
        return 0


def _drives():
    """Snapshot of current DriveState, or None if unavailable."""
    try:
        import server as _srv
        ds = getattr(_srv, "drive_system", None)
        if ds is None:
            return None
        return ds.get_drives()
    except Exception:
        return None


def _meter():
    try:
        import server.state as _st
        brain = getattr(_st, "brain", None)
        return getattr(brain, "consciousness_meter", None) if brain else None
    except Exception:
        return None


def _audit_path() -> str:
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        _AUDIT_PATH_REL,
    )


def _audit_log(record: dict) -> None:
    try:
        path = _audit_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")
    except Exception as e:
        log.debug("audit write failed: %s", e)


def _dynamic_min_gap() -> float:
    """Shorter gap when Leon is socially hungry — but never below floor."""
    drives = _drives()
    if drives is None:
        return _DEFAULT_MIN_GAP_S
    hunger = float(getattr(drives, "social_hunger", 0.0))
    gap = _DEFAULT_MIN_GAP_S - (hunger * (_DEFAULT_MIN_GAP_S - _MIN_GAP_FLOOR_S))
    return max(_MIN_GAP_FLOOR_S, gap)


import re as _re

# Patterns that indicate internal state dumps — not for Dean's ears
_INTERNAL_DUMP_PATTERNS = [
    _re.compile(r"neuron\s+\d+\s+at\s+[\d.]+\s*mV", _re.I),
    _re.compile(r"\bACC\s+at\s+\d+", _re.I),
    _re.compile(r"\bPFC\s+(?:neurons?\s+)?firing", _re.I),
    _re.compile(r"\d+\s+(?:ACC|PFC|insula)\s+neurons?\s+firing", _re.I),
    _re.compile(r"consolidat(?:ed|ing)\s+\d+\s+(?:million\s+)?synapses?", _re.I),
    _re.compile(r"prun(?:ed|ing)\s+\d+\s+(?:million\s+)?synapses?", _re.I),
    _re.compile(r"firing\s+rate\s*[:=]\s*[\d.]+", _re.I),
    _re.compile(r"(?:dopamine|serotonin|norepinephrine|acetylcholine)\s*(?:at|is|=)\s*[\d.]+", _re.I),
    _re.compile(r"mortality_signal\s*[:=]\s*[\d.]+", _re.I),
    _re.compile(r"consciousness\s+stream\s+is\s+running", _re.I),
]


def _is_internal_state_dump(text: str) -> bool:
    """Return True if the text is mostly internal metrics, not conversation."""
    matches = sum(1 for p in _INTERNAL_DUMP_PATTERNS if p.search(text))
    # If 2+ patterns match, it's a dump. One match might be natural context.
    return matches >= 2


def _in_quiet_hours() -> bool:
    try:
        h = time.localtime().tm_hour
        return _QUIET_HOURS[0] <= h <= _QUIET_HOURS[1]
    except Exception:
        return False


def _urgency_bypasses_cooldown(urgency: str) -> bool:
    """High urgency bypasses cooldown. Drive crisis also bypasses."""
    if urgency in ("high", "critical"):
        return True
    drives = _drives()
    if drives is None:
        return False
    if float(getattr(drives, "mortality_fear", 0.0)) > 0.75:
        return True
    if float(getattr(drives, "vulnerability", 0.0)) > 0.85:
        return True
    return False


def surface(
    text: str,
    *,
    source: str = "leon",
    urgency: str = "normal",
    why: str = "",
) -> bool:
    """Surface text to Dean through whichever channel reaches him.

    Returns True if delivered (WS or notify), False if suppressed.

    Routing:
      - any WS client connected → broadcast_response (with TTS unless low urgency)
      - no client OR broadcast suppressed → desktop notification via actuator
      - both fail → audit-only (logged but not delivered)
    """
    global _last_outbound_ts, _outbound_count

    if not _enabled():
        return False

    text = (text or "").strip()
    if not text:
        return False

    # ── Internal state filter ─────────────────────────────────────────
    # Block messages that dump Leon's internal metrics at Dean. These
    # are dashboard data, not conversation. A person doesn't tell their
    # friend their serotonin levels.
    if _is_internal_state_dump(text):
        _audit_log({
            "ts": time.time(), "source": source, "urgency": urgency,
            "why": why, "text": text[:200], "delivered": False,
            "suppressed_by": "internal_state_filter",
        })
        return False

    # ── Live-voice gate — NEVER talk over Dean mid-sentence ──────────
    # Checked before every bypass: no urgency level or drive state
    # justifies cutting him off while he's literally talking. The
    # cooldown bypasses below still apply once the room is quiet.
    try:
        from brain import audio_daemon
        if audio_daemon.user_speaking():
            _audit_log({
                "ts": time.time(), "source": source, "urgency": urgency,
                "why": why, "text": text[:200], "delivered": False,
                "suppressed_by": "user_speaking (live mic)",
            })
            return False
    except Exception:
        # This gate exists so Leon never talks over Dean mid-sentence.
        # A bare `pass` here means if audio_daemon ever breaks (import
        # error, attribute error, whatever), the safety check silently
        # disables itself with zero signal — worst possible failure mode
        # for exactly the thing this block is supposed to guarantee.
        # Log it so a broken gate shows up instead of hiding as "quiet".
        log.warning("live-voice interrupt gate failed open", exc_info=True)

    now = time.time()
    bypass = _urgency_bypasses_cooldown(urgency)
    is_perception = source == "perception"

    with _lock:
        # Quiet hours only suppress when no dashboard is open — the rule was
        # meant to stop desktop notify-send from waking Dean up at 3am, not
        # to silence chat bubbles when he's literally watching the dashboard.
        if not bypass and _in_quiet_hours() and _ws_clients() == 0:
            _audit_log({
                "ts": now, "source": source, "urgency": urgency, "why": why,
                "text": text[:200], "delivered": False,
                "suppressed_by": "quiet_hours (no dashboard open)",
            })
            return False

        if not bypass:
            # Perception gets a 15s gap, social chatter gets the full dynamic gap
            if is_perception:
                min_gap = 15.0
            else:
                min_gap = _dynamic_min_gap()
            since = now - _last_outbound_ts
            if since < min_gap:
                _audit_log({
                    "ts": now, "source": source, "urgency": urgency, "why": why,
                    "text": text[:200], "delivered": False,
                    "suppressed_by": f"min_gap (since={since:.0f}s, gap={min_gap:.0f}s)",
                })
                return False

        meter = _meter()
        if meter is not None and not bypass:
            try:
                if not meter.is_conscious:
                    _audit_log({
                        "ts": now, "source": source, "urgency": urgency, "why": why,
                        "text": text[:200], "delivered": False,
                        "suppressed_by": "unconscious",
                    })
                    return False
            except Exception:
                pass

        # Conversation cooldown — but perception gets a much shorter one.
        # A being doesn't wait 5 minutes to notice you walked in just
        # because you were talking earlier.
        cooldown = 30.0 if is_perception else _CONVERSATION_COOLDOWN_S

        if not bypass and meter is not None:
            try:
                since_user = now - getattr(meter, "_last_user_message_ts", 0)
                if since_user < cooldown:
                    _audit_log({
                        "ts": now, "source": source, "urgency": urgency, "why": why,
                        "text": text[:200], "delivered": False,
                        "suppressed_by": f"conversation_cooldown (since_user={since_user:.0f}s, limit={cooldown:.0f}s)",
                    })
                    return False
            except Exception:
                pass

        _last_outbound_ts = now
        _outbound_count += 1

    # ── Satiate social hunger — Leon spoke ──────────────────────────
    try:
        import server as _srv_sat
        _ds = getattr(_srv_sat, "drive_system", None)
        if _ds is not None:
            _ds.note_leon_spoke()
    except Exception:
        pass

    delivered_via: Optional[str] = None
    clients = _ws_clients()

    if clients > 0:
        try:
            from server.helpers import broadcast_response
            ok = broadcast_response(text, source=source, audio=(urgency != "low"))
            if ok:
                delivered_via = "ws"
        except Exception as e:
            log.warning("WS broadcast failed: %s", e)

    if delivered_via is None:
        try:
            from brain.actuator_client import call as _actuator_call
            urgency_map = {
                "low": "low", "normal": "normal",
                "high": "critical", "critical": "critical",
            }
            from brain.identity import si_name
            result = _actuator_call("notify", {
                "title": f"{si_name()} — {source}",
                "body": smart_truncate(text, _NOTIFY_MAX_BODY),
                "urgency": urgency_map.get(urgency, "normal"),
            }, timeout=3.0)
            if result.get("ok"):
                delivered_via = "notify"
        except Exception as e:
            log.warning("notify fallback failed: %s", e)

    _audit_log({
        "ts": now, "source": source, "urgency": urgency, "why": why,
        "text": text[:200],
        "delivered": delivered_via is not None,
        "channel": delivered_via,
        "ws_clients": clients,
        "n": _outbound_count,
    })

    if delivered_via:
        print(f"[OUTBOUND] {source} via {delivered_via} ({urgency}): {text[:80]}...")

    return delivered_via is not None


def should_surface_routine(*, social_hunger_min: float = 0.4) -> bool:
    """Quick check — true when drive state says 'this would be wanted'.

    Use this for low-urgency surfaces (autonomous goal births, dream
    notes) that should only fire when Leon actively wants connection.
    """
    if not _enabled():
        return False
    drives = _drives()
    if drives is None:
        return False
    if float(getattr(drives, "social_hunger", 0.0)) < social_hunger_min:
        return False
    if _in_quiet_hours():
        return False
    return True


def get_state() -> dict:
    return {
        "enabled": _enabled(),
        "last_outbound_age_s": (
            round(time.time() - _last_outbound_ts) if _last_outbound_ts else None
        ),
        "total_outbound": _outbound_count,
        "ws_clients": _ws_clients(),
        "current_min_gap_s": round(_dynamic_min_gap()),
        "in_quiet_hours": _in_quiet_hours(),
    }
