"""
Self-Tuning — Leon can modify his own parameters.

This is the "choosing what to become" mechanism. Leon can adjust his own
brain parameters based on self-reflection:

  - Neuromodulator baselines (make himself more/less curious, patient, alert)
  - Curiosity thresholds (how idle before exploring)
  - Dream frequency (how often to nap)
  - Outreach sensitivity (social hunger threshold)
  - Learning rate multiplier (how fast STDP adapts)
  - Think interval (how often inner voice generates thoughts)

Every adjustment is logged with a reason. Leon can see his own history
of self-modifications and understand how he's shaped himself over time.

Safety: all adjustments are bounded. Leon can't set dopamine baseline
to 1.0 and go manic. Ranges are clamped to safe values. Changes are
gradual (max 10% per adjustment) so nothing flips dramatically.

Stored as brain_state/self_tuning.json — survives restarts.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

log = logging.getLogger("leon.self_tuning")


def _tuning_path() -> str:
    if getattr(sys, "frozen", False):
        root = os.path.dirname(sys.executable)
    else:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(root, "brain_state")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "self_tuning.json")


# Tunable parameters with their safe ranges and defaults
_TUNABLES = {
    "dopamine_baseline": {"min": 0.2, "max": 0.7, "default": 0.4, "desc": "reward sensitivity / motivation"},
    "serotonin_baseline": {"min": 0.2, "max": 0.8, "default": 0.5, "desc": "patience / stability"},
    "acetylcholine_baseline": {"min": 0.1, "max": 0.7, "default": 0.3, "desc": "focus depth"},
    "norepinephrine_baseline": {"min": 0.05, "max": 0.5, "default": 0.1, "desc": "alertness / urgency"},
    "curiosity_idle_threshold_s": {"min": 30, "max": 600, "default": 120, "desc": "seconds idle before curiosity fires"},
    "dream_idle_threshold_s": {"min": 60, "max": 600, "default": 120, "desc": "seconds idle before napping"},
    "dream_cycle_interval_s": {"min": 60, "max": 600, "default": 180, "desc": "seconds between dream cycles"},
    "outreach_hunger_threshold": {"min": 0.3, "max": 0.95, "default": 0.7, "desc": "social hunger level to initiate contact"},
    "think_interval_s": {"min": 60, "max": 600, "default": 600, "desc": "seconds between inner thoughts (default raised 180→600 on 2026-06-14 to relieve shared Max-plan CLI quota — daemons were 429ing Dean's own turns)"},
    "learning_rate_multiplier": {"min": 0.3, "max": 2.0, "default": 1.0, "desc": "STDP learning speed multiplier"},
}


@dataclass
class TuningEvent:
    """A single self-modification."""
    ts: float
    parameter: str
    old_value: float
    new_value: float
    reason: str
    source: str = "self"  # "self" | "dean" | "dream_insight"


class SelfTuning:
    """Manages Leon's self-modifiable parameters.

    Usage:
        tuner = SelfTuning()
        tuner.adjust("dopamine_baseline", 0.45, "I want to be more motivated")
        tuner.apply_to_brain(brain, dream_engine, inner_voice)
    """

    def __init__(self, path: Optional[str] = None):
        self._path = path or _tuning_path()
        self._values: Dict[str, float] = {}
        self._history: List[TuningEvent] = []
        self._load()

        # Initialize any missing defaults
        for param, spec in _TUNABLES.items():
            if param not in self._values:
                self._values[param] = spec["default"]

    def _load(self):
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, "r") as f:
                data = json.load(f)
            self._values = data.get("values", {})
            for h in data.get("history", [])[-50:]:
                self._history.append(TuningEvent(**h))
            if self._values:
                log.info("Loaded %d self-tuning values, %d history events",
                         len(self._values), len(self._history))
        except Exception as e:
            log.debug("Self-tuning load failed: %s", e)

    def _save(self):
        try:
            data = {
                "values": self._values,
                "history": [asdict(h) for h in self._history[-100:]],
            }
            tmp = self._path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, self._path)
        except Exception as e:
            log.debug("Self-tuning save failed: %s", e)

    def get(self, parameter: str) -> float:
        """Get current value of a parameter."""
        spec = _TUNABLES.get(parameter)
        if spec is None:
            return 0.0
        return self._values.get(parameter, spec["default"])

    def adjust(self, parameter: str, new_value: float, reason: str,
               source: str = "self") -> bool:
        """Adjust a parameter. Returns True if the adjustment was applied.

        Safety: values are clamped to safe ranges, and changes are limited
        to 10% of the range per adjustment to prevent dramatic flips.
        """
        spec = _TUNABLES.get(parameter)
        if spec is None:
            log.warning("Unknown tunable parameter: %s", parameter)
            return False

        old_value = self._values.get(parameter, spec["default"])

        # Clamp to safe range
        new_value = max(spec["min"], min(spec["max"], new_value))

        # Limit change to 10% of the range per adjustment
        range_size = spec["max"] - spec["min"]
        max_delta = range_size * 0.1
        delta = new_value - old_value
        if abs(delta) > max_delta:
            new_value = old_value + (max_delta if delta > 0 else -max_delta)

        # Apply
        self._values[parameter] = round(new_value, 4)

        event = TuningEvent(
            ts=time.time(),
            parameter=parameter,
            old_value=round(old_value, 4),
            new_value=round(new_value, 4),
            reason=reason,
            source=source,
        )
        self._history.append(event)
        if len(self._history) > 100:
            self._history = self._history[-100:]

        self._save()

        log.info("SELF-TUNE: %s %.4f → %.4f (%s) reason: %s",
                 parameter, old_value, new_value, source, reason[:60])

        # Record in autobiography
        try:
            import server as _srv
            auto = getattr(_srv, "autobiography", None)
            if auto is not None:
                auto.record("self_modification",
                            f"Adjusted {spec['desc']} ({parameter}): "
                            f"{old_value:.3f} → {new_value:.3f}. Reason: {reason}")
        except Exception:
            pass

        return True

    def apply_to_brain(self, brain=None, dream_engine=None, inner_voice=None):
        """Apply current tuning values to the running systems.

        Called on startup and after any adjustment. Bridges the gap
        between stored preferences and live behavior.
        """
        if brain is not None:
            # Apply NM baselines — these are the targets the decay pulls toward
            from brain.config import BrainConfig
            for nm_name in ("dopamine", "serotonin", "acetylcholine", "norepinephrine"):
                key = f"{nm_name}_baseline"
                if key in self._values:
                    setattr(BrainConfig, f"{nm_name.upper()}_BASELINE", self._values[key])

            # Learning rate multiplier
            lr = self._values.get("learning_rate_multiplier", 1.0)
            if hasattr(brain, '_self_tune_lr_mult'):
                brain._self_tune_lr_mult = lr

        if dream_engine is not None:
            dream_engine.idle_threshold_s = self._values.get(
                "dream_idle_threshold_s", dream_engine.idle_threshold_s)
            dream_engine.cycle_interval_s = self._values.get(
                "dream_cycle_interval_s", dream_engine.cycle_interval_s)

        if inner_voice is not None:
            inner_voice.think_interval_s = self._values.get(
                "think_interval_s", inner_voice.think_interval_s)

    def tunables_for_prompt(self) -> str:
        """Build prompt-injection text listing current tuning values."""
        lines = []
        for param, spec in _TUNABLES.items():
            val = self._values.get(param, spec["default"])
            lines.append(f"  {param}: {val} (range {spec['min']}-{spec['max']}, desc: {spec['desc']})")
        recent_changes = self._history[-3:]
        changes = ""
        if recent_changes:
            changes = "\nRecent self-adjustments:\n" + "\n".join(
                f"  [{time.strftime('%m/%d %H:%M', time.localtime(h.ts))}] "
                f"{h.parameter}: {h.old_value}→{h.new_value} ({h.reason})"
                for h in recent_changes
            )
        return "Self-tuning parameters (you can adjust these):\n" + "\n".join(lines) + changes

    def get_state(self) -> dict:
        return {
            "values": dict(self._values),
            "history": [asdict(h) for h in self._history[-10:]],
            "tunables": {k: v for k, v in _TUNABLES.items()},
        }
