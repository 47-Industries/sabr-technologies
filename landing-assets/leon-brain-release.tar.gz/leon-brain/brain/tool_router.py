"""
Tool Router — selects the right ~30-50 tools per request from 1,500+.

Sending all 1,578 tools to Claude every call makes it default to familiar
ones (shell_exec, Bash). This module groups tools into semantic categories
and picks only the relevant ones based on the user's message.

Architecture:
  1. ALWAYS_TOOLS — always included (~15 core tools)
  2. CATEGORY_MAP — keyword → tool name prefixes
  3. route(user_text, all_tools) → filtered tool list

Called from claude_api_responder before building the Claude API request.
"""

from __future__ import annotations
import os
import re
from typing import Dict, List, Optional, Set


def _local_pick_categories(user_text: str, category_names: List[str]) -> List[str]:
    """Layer C — when keyword routing finds NO category, ask the local brain
    which tool categories the request needs. Cheap (~1s warm), only runs on the
    keyword-miss long tail, and returns [] on any failure so route() falls back
    to its generic set. Gated by LEON_LOCAL_TOOLROUTER=1.
    """
    if os.environ.get("LEON_LOCAL_TOOLROUTER") != "1":
        return []
    try:
        from brain import local_llm as _ll  # type: ignore
    except Exception:
        return []
    cats = ", ".join(category_names)
    prompt = (
        "A user said this to an AI assistant that controls a computer:\n"
        f'  "{user_text}"\n\n'
        "Which of these tool categories are needed to ACT on it? Pick only the "
        "clearly relevant ones. If it is small talk, a greeting, a question that "
        "needs no computer action, or you are unsure, reply exactly NONE.\n"
        f"Categories: {cats}\n\n"
        "Reply with ONLY the category names, comma-separated, or NONE."
    )
    raw = _ll.classify(prompt, num_predict=40, timeout=8.0)
    if not raw:
        return []
    low = raw.lower()
    return [c for c in category_names if c.lower() in low]


# -- AI provider tools (optional; must never be able to kill server boot) ----
#
# brain/integrations/ai_providers.py imports `requests` and is only useful
# when a customer has pasted API keys into .env. It is import-guarded here
# for exactly the reason the tmux/pty-backed helpers are guarded elsewhere:
# this ships to customers, including Windows boxes where an optional
# dependency may simply be absent. A missing/broken ai_providers must
# degrade to "those tools are not offered", never to a dead brain.
#
# Note the two independent layers of graceful degradation:
#   1. import fails  -> HAS_AI_PROVIDERS is False, names are not promoted.
#   2. import works but no API key is set -> each wrapper returns the
#      module's own _missing() dict at call time. It never raises.
HAS_AI_PROVIDERS = False
_AI_PROVIDERS = None
try:
    from brain.integrations import ai_providers as _AI_PROVIDERS  # type: ignore
    HAS_AI_PROVIDERS = True
except Exception:
    # ImportError, missing `requests`, or anything the module raises at
    # import time. Swallow it all -- boot continues without AI tools.
    _AI_PROVIDERS = None
    HAS_AI_PROVIDERS = False

# Public names as the live tool surface sees them. server/init_brain.py
# registers integration EXTRA_TOOLS keys with "." replaced by "_", so
# "ai.openai_chat" is dispatched as "ai_openai_chat".
AI_PROVIDER_TOOLS: Set[str] = {
    "ai_openai_chat",       # OpenAI chat completions (second opinion)
    "ai_gemini_chat",       # Google Gemini chat
    "ai_gemini_vision",     # Gemini multimodal image understanding
    "ai_image_generate",    # DALL-E 3 image generation via OpenAI
    "ai_transcribe",        # Whisper speech-to-text
    "ai_speak",             # OpenAI text-to-speech
    "ai_mistral_chat",      # Mistral chat
    "ai_together_chat",     # Together AI (Llama etc.)
    "ai_stability_image",   # Stability SD3 text-to-image
    "ai_translate",         # DeepL translation
}

# ── Always-included tools (Leon's essential toolkit) ──────────────────

ALWAYS_TOOLS: Set[str] = {
    # Observation
    "screen_capture", "vision_describe", "webcam_capture",
    # Core interaction
    "keyboard_type", "keyboard_hotkey", "mouse_click", "click_text",
    "click_element",
    # Browser basics + navigation primitives.
    # Without new_tab / list_tabs / switch_tab / execute_js / screenshot_full
    # in the always-set, Claude hallucinates names like browser.evaluate_js
    # or browser.navigate during autonomous turns (no keyword in user_text
    # to fire the "browser" category). Observed 2026-06-09 mid-task.
    "browser_open", "web_search", "browser_dom_state", "browser_dom_click",
    "browser_dom_extract", "browser_dom_fill",
    "browser_new_tab", "browser_list_tabs", "browser_switch_tab",
    "browser_close_tab", "browser_execute_js", "browser_screenshot_full",
    # Files
    "file_read", "file_write", "file_list", "code_edit",
    # System
    "shell_exec", "window_list", "window_focus", "app_launch", "notify",
    "clipboard_copy", "clipboard_paste",
    # Memory
    "knowledge_search", "correct_core_fact", "add_core_fact", "list_core_facts",
    # Tasks/reminders
    "reminder_set", "reminder_list", "task_add", "task_list",
    # HTTP
    "http_request",
    # Creative (image/video/music generation)
    "image_generate", "image_upscale", "image_remove_bg",
    "video_generate", "music_generate",
    # Sub-agents
    "agent_spawn", "agent_spawn_parallel",
    # Self
    "restart_self",
}

# Promote the AI provider tools into the always-available set, but only when
# the module actually imported. ALWAYS_TOOLS is a name filter applied against
# the live catalog, so an entry for a tool the brain never registered is inert
# -- gating on the flag simply keeps this set honest about what exists.
if HAS_AI_PROVIDERS:
    ALWAYS_TOOLS |= AI_PROVIDER_TOOLS

# ── Category definitions ──────────────────────────────────────────────
# Each category: (keywords_regex, tool_name_prefixes)
# Keywords are matched against the user's message (case-insensitive).
# Tool prefixes are matched against tool names.

CATEGORIES: List[dict] = [
    {
        "name": "audio_volume",
        "keywords": r"volume|loud|quiet|mute|unmute|sound|audio|speaker|headphone",
        "prefixes": ["sys_audio", "pc_audio", "keyboard_hotkey", "keyboard_press",
                      "pc_keyboard", "entertainment_spotify", "spotify"],
        "extra_tools": ["keyboard_hotkey"],
    },
    {
        "name": "window_management",
        "keywords": r"window|minimize|maximize|fullscreen|monitor|display|screen|snap|tile|workspace",
        "prefixes": ["window", "pc_window", "pc_workspace", "app_"],
    },
    {
        "name": "browser",
        "keywords": r"browser|tab|website|webpage|url|click.*button|fill.*form|login|navigate|wix|figma|web",
        "prefixes": ["browser", "web_"],
    },
    {
        "name": "email",
        "keywords": r"email|gmail|inbox|send.*mail|draft|reply|forward|unread",
        "prefixes": ["email", "comms_email"],
    },
    {
        "name": "calendar",
        "keywords": r"calendar|event|meeting|schedule|appointment|remind",
        "prefixes": ["calendar", "reminder"],
    },
    {
        "name": "smart_home",
        "keywords": r"light|lamp|bulb|smart.*home|hue|govee|kasa|brightness|color.*light|room.*light|led",
        "prefixes": ["home_", "smart_home"],
    },
    {
        "name": "file_management",
        "keywords": r"file|folder|directory|download|upload|rename|delete.*file|move.*file|copy.*file|path",
        "prefixes": ["file_", "cloud_storage", "code_"],
    },
    {
        "name": "coding",
        "keywords": r"code|program|script|python|javascript|debug|compile|build|test|git|github|repo|commit|push|pull request|pr ",
        "prefixes": ["coding", "github", "devtools"],
    },
    {
        "name": "design_cad",
        "keywords": r"design|figma|canva|cad|3d.*print|stl|model|sketch|logo|brand|color.*palette|font|icon|qr",
        "prefixes": ["design"],
    },
    {
        "name": "image_ai",
        "keywords": r"generate.*image|create.*image|stable.*diffusion|dall-e|midjourney|ai.*art|picture|photo.*edit",
        "prefixes": ["image_ai", "media_image"],
    },
    {
        "name": "business",
        "keywords": r"lead|leads|prospect|outreach|pipeline|client|sale|crm|sms|text.*them|call.*them|demo|cold.*email|business.*find|website.*audit|follow.*up|deal",
        "prefixes": ["business"],
    },
    {
        "name": "finance",
        "keywords": r"money|payment|invoice|stripe|bank|budget|expense|profit|revenue|accounting|tax|crypto|bitcoin",
        "prefixes": ["finance", "accounting", "crypto", "commerce"],
    },
    {
        "name": "research",
        "keywords": r"research|paper|arxiv|pubmed|scholar|journal|study|citation|science",
        "prefixes": ["research"],
    },
    {
        "name": "social_media",
        "keywords": r"twitter|reddit|linkedin|instagram|tiktok|youtube|social|post|tweet|follow",
        "prefixes": ["search_social", "video_production", "marketing"],
    },
    {
        "name": "notes_docs",
        "keywords": r"note|document|pdf|write.*doc|template|report|notion|obsidian",
        "prefixes": ["notes", "docgen", "productivity"],
    },
    {
        "name": "pc_control",
        "keywords": r"brightness|power|sleep|hibernate|lock|shutdown|restart.*computer|battery|cpu|ram|disk|process|kill.*process",
        "prefixes": ["pc_", "sys_", "net_"],
    },
    {
        "name": "mouse_keyboard",
        "keywords": r"mouse|cursor|click|drag|scroll|type|keyboard|hotkey|shortcut|key.*press",
        "prefixes": ["mouse", "keyboard", "pc_keyboard"],
    },
    {
        "name": "media_entertainment",
        "keywords": r"music|spotify|play|pause|next.*song|playlist|movie|video|stream|plex|netflix",
        "prefixes": ["entertainment", "media", "spotify"],
    },
    {
        "name": "communication",
        "keywords": r"slack|discord|message|call|phone|sms|text.*someone|teams",
        "prefixes": ["comms", "phone", "productivity"],
    },
    {
        "name": "security",
        "keywords": r"password|2fa|ssh|key|encrypt|vpn|firewall|port|scan",
        "prefixes": ["security", "secrets"],
    },
    {
        "name": "automation",
        "keywords": r"automate|zapier|ifttt|workflow|cron|schedule|trigger|webhook",
        "prefixes": ["automation", "workflow"],
    },
    {
        # Pulls in the full ai.* surface (compare_models, cheapest_chat,
        # embeddings, ollama_*, elevenlabs_*) on top of the always-on ten.
        "name": "ai_providers",
        "keywords": r"openai|chatgpt|gpt-?[0-9]|dall-?e|gemini|mistral|"
                    r"together ?ai|llama|ollama|stability|stable ?diffusion|"
                    r"deepl|elevenlabs|whisper|transcribe|transcription|"
                    r"translate|translation|text.*to.*speech|speech.*to.*text|"
                    r"tts|second opinion|another model|other model|"
                    r"different model|compare.*model|ask (gpt|gemini|mistral)",
        "prefixes": ["ai_"],
    },
    {
        "name": "project_management",
        "keywords": r"project|task|todo|jira|asana|trello|deadline|sprint|kanban|board",
        "prefixes": ["project_mgmt", "task_"],
    },
]


def route(user_text: str, all_tools: List[dict], max_tools: int = 80) -> List[dict]:
    """Select relevant tools for this request.

    Args:
        user_text: The user's message
        all_tools: Full list of Anthropic tool schemas
        max_tools: Maximum tools to return

    Returns:
        Filtered tool list (always includes ALWAYS_TOOLS + matched categories)
    """
    if not user_text or not all_tools:
        return all_tools  # fallback: send everything

    text_lower = user_text.lower()

    # Build set of tool names to include
    selected_names: Set[str] = set(ALWAYS_TOOLS)

    # Match categories
    matched_categories = []
    for cat in CATEGORIES:
        if re.search(cat["keywords"], text_lower):
            matched_categories.append(cat["name"])
            for prefix in cat.get("prefixes", []):
                # Add all tools starting with this prefix
                for tool in all_tools:
                    name = tool.get("name", "")
                    if name.startswith(prefix) or name == prefix:
                        selected_names.add(name)
            # Add explicit extra tools
            for extra in cat.get("extra_tools", []):
                selected_names.add(extra)

    # Layer C — keyword routing missed. Before falling back to the generic
    # grab-bag, ask the local brain which categories the request actually needs
    # (this is the long-tail action that would otherwise get the wrong tools and
    # make Leon improvise via shell). Only adds tools; never removes any.
    if not matched_categories:
        for picked in _local_pick_categories(user_text, [c["name"] for c in CATEGORIES]):
            for cat in CATEGORIES:
                if cat["name"] != picked:
                    continue
                matched_categories.append(cat["name"])
                for prefix in cat.get("prefixes", []):
                    for tool in all_tools:
                        if tool.get("name", "").startswith(prefix):
                            selected_names.add(tool["name"])
                for extra in cat.get("extra_tools", []):
                    selected_names.add(extra)

    # If still no categories matched, include a broader set (top ~60 most useful)
    if not matched_categories:
        # General-purpose fallback: core + browser + files + system
        for cat in CATEGORIES:
            if cat["name"] in ("browser", "file_management", "pc_control",
                               "mouse_keyboard", "notes_docs"):
                for prefix in cat.get("prefixes", []):
                    for tool in all_tools:
                        if tool.get("name", "").startswith(prefix):
                            selected_names.add(tool["name"])

    # Filter the tool list
    filtered = [t for t in all_tools if t.get("name", "") in selected_names]

    # Cap at max_tools (prefer ALWAYS_TOOLS first)
    if len(filtered) > max_tools:
        always = [t for t in filtered if t.get("name", "") in ALWAYS_TOOLS]
        rest = [t for t in filtered if t.get("name", "") not in ALWAYS_TOOLS]
        filtered = always + rest[:max_tools - len(always)]

    return filtered
