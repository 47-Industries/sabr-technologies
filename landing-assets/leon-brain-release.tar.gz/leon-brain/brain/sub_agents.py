"""
Sub-agent spawning — Leon can delegate tasks to parallel Claude agents.

When Leon calls `agent_spawn`, a focused Claude instance is created with
a specific task. It runs to completion and returns the result. Leon can
spawn multiple agents in parallel for research, analysis, coding, etc.

Tools:
  - agent_spawn: Spawn a focused sub-agent with a task
  - agent_spawn_parallel: Spawn multiple agents at once, wait for all

Example usage by Leon:
  agent_spawn({"task": "Research the top 5 CRM platforms and compare pricing"})
  agent_spawn_parallel({"tasks": [
      "Research Salesforce pricing",
      "Research HubSpot pricing",
      "Research Pipedrive pricing"
  ]})
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import threading
import re
import time
from typing import Any, Dict, List

_MAX_CONCURRENT = 5
_MAX_TOKENS = 4096
_executor = concurrent.futures.ThreadPoolExecutor(max_workers=_MAX_CONCURRENT,
                                                   thread_name_prefix="leon-subagent")


def _get_client():
    """Get an Anthropic client using available credentials."""
    try:
        import anthropic
        api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        if api_key:
            return anthropic.Anthropic(api_key=api_key)
        # Try Max plan via default auth
        return anthropic.Anthropic()
    except Exception:
        return None


def _agent_log(name: str, text: str, detail: str = "") -> None:
    """Put a sub-agent's step into Dean's activity log, tagged with its name.

    Never fatal: if the dashboard or the broadcast layer is unavailable, the
    agent's actual work must still run. A logging failure is not a work
    failure.
    """
    try:
        from server.helpers import broadcast_agent_activity
        broadcast_agent_activity(name, text, detail=detail)
    except Exception:
        pass


def _agent_name(task: str, given: str = "") -> str:
    """A short, stable handle for this agent, for the clickable chip."""
    if given:
        return str(given)[:32]
    words = [w for w in re.findall(r"[A-Za-z0-9]+", task or "") if len(w) > 3]
    return ("-".join(words[:2]) or "agent").lower()[:32]


def _run_subagent(task: str, model: str = "claude-sonnet-4-6-20250514",
                  system: str = "", max_tokens: int = _MAX_TOKENS,
                  name: str = "") -> Dict[str, Any]:
    """Run a single sub-agent to completion."""
    agent = _agent_name(task, name)
    client = _get_client()
    if client is None:
        return {"ok": False, "error": "No Anthropic client available (no API key)"}

    default_system = (
        "You are a focused research/task agent spawned by Leon (a synthetic intelligence). "
        "Complete the task thoroughly and concisely. Return structured results. "
        "Do NOT ask follow-up questions — just do the work and report back."
    )

    _agent_log(agent, "started", detail=f"TASK\n{task}")
    try:
        t0 = time.time()
        response = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system or default_system,
            messages=[{"role": "user", "content": task}],
        )
        elapsed = round(time.time() - t0, 1)

        text = ""
        for block in response.content:
            if hasattr(block, "text"):
                text += block.text

        _agent_log(agent, f"done in {elapsed}s", detail=f"TASK\n{task}\n\nRESULT\n{text}")
        return {
            "ok": True,
            "agent": agent,
            "result": text,
            "model": model,
            "elapsed_sec": elapsed,
            "tokens_in": response.usage.input_tokens,
            "tokens_out": response.usage.output_tokens,
        }
    except Exception as e:
        _agent_log(agent, f"failed: {type(e).__name__}",
                   detail=f"TASK\n{task}\n\nERROR\n{e}")
        return {"ok": False, "agent": agent, "error": f"{type(e).__name__}: {e}"}


# ── Tool functions (registered as local_tools) ──────────────────────

def agent_spawn(args: Dict[str, Any]) -> Dict[str, Any]:
    """Spawn a focused sub-agent to complete a task.

    Args:
        task: The task description for the sub-agent
        model: Optional model (default: claude-sonnet-4-6-20250514)
        system: Optional system prompt override
        max_tokens: Optional max tokens (default: 4096)
    """
    task = (args.get("task") or "").strip()
    if not task:
        return {"ok": False, "error": "task is required"}

    model = args.get("model", "claude-sonnet-4-6-20250514")
    system = args.get("system", "")
    max_tokens = int(args.get("max_tokens", _MAX_TOKENS))

    return _run_subagent(task, model=model, system=system, max_tokens=max_tokens,
                         name=args.get("name", ""))


def agent_spawn_parallel(args: Dict[str, Any]) -> Dict[str, Any]:
    """Spawn multiple sub-agents in parallel and wait for all results.

    Args:
        tasks: List of task description strings
        model: Optional model (applies to all agents)
        system: Optional system prompt (applies to all)
    """
    tasks = args.get("tasks", [])
    if not tasks or not isinstance(tasks, list):
        return {"ok": False, "error": "tasks must be a non-empty list of strings"}
    if len(tasks) > _MAX_CONCURRENT:
        return {"ok": False, "error": f"Max {_MAX_CONCURRENT} parallel agents"}

    model = args.get("model", "claude-sonnet-4-6-20250514")
    system = args.get("system", "")

    t0 = time.time()
    futures = {}
    for i, task in enumerate(tasks):
        future = _executor.submit(_run_subagent, task, model=model, system=system,
                                  name=f"{args.get('name', 'agent')}-{i + 1}")
        futures[future] = {"index": i, "task": task[:100]}

    results = []
    for future in concurrent.futures.as_completed(futures, timeout=300):
        meta = futures[future]
        try:
            result = future.result()
            result["task_index"] = meta["index"]
            result["task_preview"] = meta["task"]
            results.append(result)
        except Exception as e:
            results.append({
                "ok": False,
                "error": str(e),
                "task_index": meta["index"],
                "task_preview": meta["task"],
            })

    # Sort by original task index
    results.sort(key=lambda r: r.get("task_index", 0))
    elapsed = round(time.time() - t0, 1)

    return {
        "ok": True,
        "results": results,
        "total_elapsed_sec": elapsed,
        "agent_count": len(tasks),
        "succeeded": sum(1 for r in results if r.get("ok")),
    }


# ── Export for init_brain.py ──────────────────────────────────────────

EXTRA_TOOLS = {
    "agent.spawn": agent_spawn,
    "agent.spawn_parallel": agent_spawn_parallel,
}
