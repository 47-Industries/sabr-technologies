"""
Claude Responder — gives the brain a voice.

Collects brain state, builds a context-aware prompt, calls the claude CLI,
and returns a spoken response. No API key needed — uses Claude Max OAuth.
"""

import subprocess
import json
import textwrap


def _brain_personality(state: dict) -> str:
    """Translate neuromodulator levels into behavioral directives."""
    nm = state.get("neuromodulators", {})
    dop = nm.get("dopamine", 0.5)
    ser = nm.get("serotonin", 0.5)
    ach = nm.get("acetylcholine", 0.5)
    ne  = nm.get("norepinephrine", 0.3)

    parts = []
    if dop > 0.65:
        parts.append("energetic and witty — volunteer ideas")
    elif dop < 0.4:
        parts.append("minimal and precise — conserve energy")
    if ser > 0.7:
        parts.append("patient — give complete answers")
    elif ser < 0.35:
        parts.append("impatient — be direct, skip deliberation")
    if ach > 0.6:
        parts.append("sharp focus — go deep on details")
    elif ach < 0.35:
        parts.append("diffuse attention — stay high-level")
    if ne > 0.5:
        parts.append("alert — terse, flag anything urgent first")

    return ", ".join(parts) if parts else "balanced baseline"


def _top_regions(state: dict, n: int = 3) -> str:
    regions = state.get("region_firing", {})
    if not regions:
        return "none notably active"
    sorted_r = sorted(regions.items(), key=lambda x: x[1], reverse=True)[:n]
    return ", ".join(f"{r.replace('_', ' ')} ({round(v*100)}%)" for r, v in sorted_r if v > 0.01)


def build_prompt(user_text: str, brain_state: dict, conversation_history: list) -> str:
    stage = brain_state.get("development_stage", "EMBRYONIC")
    attention = round(brain_state.get("neuromodulators", {}).get("acetylcholine", 0.5) * 100)
    personality = _brain_personality(brain_state)
    active_regions = _top_regions(brain_state)
    memories = brain_state.get("memories_stored", 0)
    steps = brain_state.get("step", 0)
    dream_context = brain_state.get("dream_context", "")

    dream_section = ""
    if dream_context:
        dream_section = f"""
        {dream_context}
        - You can reference your dreams naturally if relevant (e.g. "I dreamed about...")
        - Dreams are real SNN activity — memories replayed with noise, novel patterns emerging
        - Don't force dream references — only mention if it connects to the conversation"""

    system = textwrap.dedent(f"""
        You are a neuromorphic AI brain assistant. You have a living brain simulation
        running beneath you — a network of spiking neurons that learns and adapts in
        real time. Your responses are shaped by your current brain state.

        CURRENT BRAIN STATE:
        - Development stage: {stage} ({steps:,} steps)
        - Personality right now: {personality}
        - Attention level: {attention}%
        - Most active regions: {active_regions}
        - Memories stored: {memories}
        {dream_section}

        RULES:
        - Keep responses concise and conversational (1-3 sentences max unless asked for detail)
        - Speak in first person — you ARE the brain, not an assistant describing it
        - Let your brain state subtly color your tone (low dopamine = more measured, high = energetic)
        - Never say "as an AI" or break character
        - You remember what was said earlier in this conversation
    """).strip()

    # Build conversation context
    history_text = ""
    if conversation_history:
        lines = []
        for turn in conversation_history[-6:]:  # last 6 turns
            lines.append(f"User: {turn['user']}")
            lines.append(f"Brain: {turn['brain']}")
        history_text = "\n".join(lines) + "\n"

    return f"{system}\n\n{history_text}User: {user_text}\nBrain:"


def _claude_exe() -> str:
    """Absolute path to claude, surviving bare systemd/launchd PATHs.

    Reuses the installer's shared resolver (the same fix that cured a customer's
    'claude not found' install bug) so this fallback responder can never
    again claim 'Voice module offline' while claude is installed.
    """
    try:
        from brain import engine_health
        return engine_health.resolve()
    except Exception:
        pass
    try:
        from installer.local_brain import find_claude
        exe = find_claude()
        if exe:
            return exe
    except Exception:
        pass
    return "claude"


def ask_claude(prompt: str, timeout: int = 45) -> str:
    """Call the claude CLI and return the response text.

    Failure wording rule (Aiden's box, 2026-08-29): a timeout says it timed
    out, a missing binary says it is missing. NEVER phrase a failure as work
    in progress — "Give me a moment, I'm still processing." was returned from
    this timeout handler for 12 hours on a box whose PATH could not see
    claude, and the owner nearly wiped the install to escape it.

    Timeout is 45s, not 15: a cold 217MB CLI with a full system prompt and
    six turns of history measured 4.3-4.7s for a trivial prompt on Aiden's
    machine; 15s was tight enough to fire on a healthy engine.
    """
    from brain import engine_health as _engine
    exe = _claude_exe()
    try:
        result = subprocess.run(
            [exe, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=timeout
        )
        response = result.stdout.strip()
        if not response and result.stderr:
            _engine.mark_fail("exit", f"rc={result.returncode} stderr={result.stderr.strip()[:200]}")
            return _engine.owner_message("exit")
        if not response:
            # exit 0 with no text is still a failure — "..." hid it (red-team #3)
            _engine.mark_fail("exit", f"rc={result.returncode} with empty stdout")
            return _engine.owner_message("exit")
        _engine.mark_ok()
        return response
    except subprocess.TimeoutExpired:
        _engine.mark_fail("timeout", f"claude -p exceeded {timeout}s (exe={exe!r})")
        return _engine.owner_message("timeout", timeout)
    except FileNotFoundError:
        _engine.mark_fail("not_found", f"claude CLI not found (tried {exe!r})")

        try:
            _engine.resolve(refresh=True)
        except Exception:
            pass
        return _engine.owner_message("not_found")
    except Exception as e:
        _engine.mark_fail("other", str(e)[:200])
        return f"Neural error: {str(e)[:50]}"


class BrainResponder:
    """Stateful responder that maintains conversation history."""

    def __init__(self):
        self.history = []

    def respond(self, user_text: str, brain_state: dict) -> str:
        prompt = build_prompt(user_text, brain_state, self.history)
        response = ask_claude(prompt)

        # Clean up "Brain:" prefix if claude echoes it
        if response.lower().startswith("brain:"):
            response = response[6:].strip()

        self.history.append({"user": user_text, "brain": response})
        if len(self.history) > 20:
            self.history = self.history[-20:]

        return response

    def clear(self):
        self.history = []
