"""Tentacle orchestration — Leon as the boss of his fleet.

Leon's 'tentacles' are Claude Code instances running in `tmux` windows
under the `agents` session. Each one is a separate Claude CLI focused on
a specific project (leon, ceomakeithappen, pc-helper, leon-ui).
This module gives Leon tools to:

  - delegate a task to a specific tentacle
  - peek at what a tentacle is doing right now
  - detect stuck or looping tentacles
  - broadcast to multiple tentacles
  - submit tasks to the legacy agent-board for async pickup
  - spawn an ephemeral tentacle for a one-shot job

All tools dispatch to local shell — they DO NOT go through the actuator
socket, so they're brain-side `local_tools`.

Pattern (matches memory_extras / introspection):

    EXTRA_TOOLS = {
        "tentacle.delegate_task": _delegate_task,
        ...
    }

Each callable takes a `dict` arg and returns `{"ok": bool, ...}`.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Paths ──────────────────────────────────────────────────────────────
_AGENT_BOARD = Path.home() / ".openclaw" / "agent-board"
_REQUESTS_DIR = _AGENT_BOARD / "requests"
_RESULTS_DIR = _AGENT_BOARD / "results"
_REGISTRY = _AGENT_BOARD / "registry.json"
_TMUX_SESSION = "agents"


def _run(cmd: List[str], timeout: float = 10.0, check: bool = False) -> subprocess.CompletedProcess:
    """Run a subprocess capturing stdout+stderr; safe defaults."""
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=check,
    )


# ── tmux helpers ───────────────────────────────────────────────────────
def _list_tmux_windows(session: str = _TMUX_SESSION) -> List[Dict[str, Any]]:
    """Return list of {index, name, active, panes} for a tmux session."""
    try:
        out = _run(
            ["tmux", "list-windows", "-t", session, "-F",
             "#{window_index}|#{window_name}|#{window_active}|#{window_panes}"]
        )
        if out.returncode != 0:
            return []
    except FileNotFoundError:
        return []
    except subprocess.TimeoutExpired:
        return []
    windows = []
    for line in out.stdout.strip().split("\n"):
        if not line:
            continue
        parts = line.split("|")
        if len(parts) < 4:
            continue
        windows.append({
            "index": int(parts[0]),
            "name": parts[1],
            "active": parts[2] == "1",
            "panes": int(parts[3]),
        })
    return windows


def _capture_pane(target: str, lines: int = 50) -> str:
    """Capture the last N lines of a tmux window/pane.

    target: 'session:window' (e.g. 'agents:leon')
    """
    try:
        out = _run(
            ["tmux", "capture-pane", "-t", target, "-p", "-S", f"-{lines}"],
            timeout=8.0,
        )
        if out.returncode != 0:
            return ""
        return out.stdout
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def _send_keys(target: str, text: str, press_enter: bool = True) -> bool:
    """Send literal text into a tmux window/pane. Returns success."""
    try:
        # ROUTED THROUGH THE GATE 2026-08-03, Leon's decision, no exemptions.
        # This was one of five doors into the same pane while only
        # terminal_loop.send() consulted may_autosubmit. Gating one door and
        # calling the room secure is the `grep -c secure/` shape: the check
        # tested one path, not the class.
        # Preconditions are cursor_x > prompt_prefix and may_autosubmit, and
        # nothing else. Painted text is never evidence (5/5 stale specimens).
        if press_enter:
            from brain.mission.terminal_loop import TerminalWatcher
            return TerminalWatcher().send(target.split(":")[-1].split(".")[0], text)
        # No Enter means no submission, so the gate does not apply — this
        # branch types into the box and leaves it there, which is exactly the
        # state the gate exists to REFUSE to act on, not to prevent.
        r = _run(["tmux", "send-keys", "-t", target, "-l", text], timeout=8.0)
        return r.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _resolve_target(name: str) -> Optional[str]:
    """Translate a tentacle short-name into 'session:window' for tmux.

    Accepts: 'leon', 'agents:leon', '1' (window index).
    """
    if ":" in name:
        return name  # already qualified
    wins = _list_tmux_windows()
    for w in wins:
        if w["name"] == name or str(w["index"]) == name:
            return f"{_TMUX_SESSION}:{w['index']}"
    return None


# ── Tools ──────────────────────────────────────────────────────────────
def _list_active(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all active tentacle windows in the `agents` tmux session."""
    wins = _list_tmux_windows()
    return {"ok": True, "session": _TMUX_SESSION, "tentacles": wins, "count": len(wins)}


def _peek_tail(args: Dict[str, Any]) -> Dict[str, Any]:
    """Capture the last N lines (default 30) from a tentacle's pane.

    Args:
      name: tentacle window name or index (required)
      lines: how many lines to capture (default 30, max 500)
    """
    name = args.get("name")
    lines = int(args.get("lines", 30))
    if not name:
        return {"ok": False, "error": "name is required"}
    if lines < 1 or lines > 500:
        return {"ok": False, "error": "lines must be 1..500"}
    target = _resolve_target(str(name))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{name}'"}
    content = _capture_pane(target, lines)
    return {
        "ok": True,
        "tentacle": name,
        "target": target,
        "lines": lines,
        "content": content,
        "byte_size": len(content.encode("utf-8")),
    }


def _delegate_task(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a task prompt into a tentacle's claude session.

    Args:
      name: tentacle window name or index (required)
      task: text to send to the tentacle's Claude (required)
      tag: optional short tag prefix Leon can search for later
    """
    name = args.get("name")
    task = args.get("task")
    tag = args.get("tag")
    if not name or not task:
        return {"ok": False, "error": "name and task are required"}
    target = _resolve_target(str(name))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{name}'"}
    text = task
    if tag:
        text = f"[{tag}] {task}"
    sent_at = time.time()
    ok = _send_keys(target, text, press_enter=True)
    return {
        "ok": bool(ok),
        "tentacle": name,
        "target": target,
        "task_preview": task[:140],
        "tag": tag,
        "sent_at": sent_at,
        "note": "Use tentacle.peek_tail after ~30s to read the response.",
    }


def _query_status(args: Dict[str, Any]) -> Dict[str, Any]:
    """Quick status: what's the tentacle doing right now?

    Returns the last 8 non-empty lines + a heuristic guess at state.

    Args:
      name: tentacle window name or index (required)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    target = _resolve_target(str(name))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{name}'"}
    content = _capture_pane(target, 50)
    lines = [l for l in content.split("\n") if l.strip()][-8:]
    # Heuristic state detection
    blob = "\n".join(lines).lower()
    if "esc to interrupt" in blob or "tokens" in blob or "thinking" in blob:
        state = "thinking"
    elif blob.endswith("$") or blob.endswith("> ") or "human:" in blob.split("\n")[-1].lower():
        state = "idle"
    elif "error" in blob or "traceback" in blob:
        state = "error"
    else:
        state = "active"
    return {
        "ok": True,
        "tentacle": name,
        "state": state,
        "recent_lines": lines,
    }


def _health(args: Dict[str, Any]) -> Dict[str, Any]:
    """Detect stuck/looping tentacles by comparing pane content over time.

    Captures pane twice with a delay; if content is byte-identical AND the
    tentacle is supposedly active, flags it stuck.

    Args:
      name: tentacle window name (required)
      wait_seconds: how long to wait between captures (default 10, max 60)
    """
    name = args.get("name")
    wait = min(60, max(2, int(args.get("wait_seconds", 10))))
    if not name:
        return {"ok": False, "error": "name is required"}
    target = _resolve_target(str(name))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{name}'"}
    first = _capture_pane(target, 30)
    time.sleep(wait)
    second = _capture_pane(target, 30)
    same = first == second
    return {
        "ok": True,
        "tentacle": name,
        "wait_seconds": wait,
        "identical_after_wait": same,
        "verdict": "stuck" if same and first.strip() else ("idle" if same else "active"),
        "byte_size_change": len(second) - len(first),
    }


def _broadcast(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send the same task to multiple tentacles.

    Args:
      names: list of tentacle names (required)
      task: text to send (required)
      tag: optional tag prefix
    """
    names = args.get("names")
    task = args.get("task")
    tag = args.get("tag")
    if not names or not isinstance(names, list):
        return {"ok": False, "error": "names (list) is required"}
    if not task:
        return {"ok": False, "error": "task is required"}
    delivered = []
    failed = []
    text = f"[{tag}] {task}" if tag else task
    for nm in names:
        target = _resolve_target(str(nm))
        if not target:
            failed.append({"name": nm, "reason": "no tmux match"})
            continue
        if _send_keys(target, text, press_enter=True):
            delivered.append(nm)
        else:
            failed.append({"name": nm, "reason": "send-keys failed"})
    return {
        "ok": len(delivered) > 0,
        "delivered": delivered,
        "failed": failed,
        "count_delivered": len(delivered),
    }


def _spawn_ephemeral(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a new tmux window for a one-shot tentacle task.

    Args:
      name: window name (default: 'leon-spawn-{uuid8}')
      cwd: working directory for the new window (default: ~/Desktop)
      cmd: initial command to run (default: leaves a bash shell)
    """
    name = args.get("name") or f"leon-spawn-{uuid.uuid4().hex[:6]}"
    cwd = args.get("cwd") or os.path.expanduser("~/Desktop")
    cmd = args.get("cmd")
    if not Path(cwd).exists():
        return {"ok": False, "error": f"cwd does not exist: {cwd}"}
    # check session exists
    sess = _run(["tmux", "has-session", "-t", _TMUX_SESSION])
    if sess.returncode != 0:
        # create the session detached
        _run(["tmux", "new-session", "-d", "-s", _TMUX_SESSION, "-n", "default"])
    # create window
    new_args = ["tmux", "new-window", "-t", _TMUX_SESSION, "-n", name, "-c", cwd]
    if cmd:
        new_args.append(cmd)
    r = _run(new_args, timeout=8.0)
    if r.returncode != 0:
        return {"ok": False, "error": f"tmux new-window failed: {r.stderr.strip()}"}
    return {
        "ok": True,
        "tentacle": name,
        "session": _TMUX_SESSION,
        "cwd": cwd,
        "initial_cmd": cmd,
    }


def _close_ephemeral(args: Dict[str, Any]) -> Dict[str, Any]:
    """Kill an ephemeral tmux window by name. Refuses to kill known long-running
    tentacles (leon, ceomakeithappen, pc-helper, leon-ui, oct-*).

    Args:
      name: tentacle name (required)
    """
    name = args.get("name")
    if not name:
        return {"ok": False, "error": "name is required"}
    protected = {"leon", "ceomakeithappen", "pc-helper", "leon-ui", "bash"}
    if name in protected or str(name).startswith("oct-"):
        return {"ok": False, "error": f"refusing to kill protected tentacle '{name}'"}
    target = _resolve_target(str(name))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{name}'"}
    r = _run(["tmux", "kill-window", "-t", target], timeout=6.0)
    return {"ok": r.returncode == 0, "tentacle": name, "target": target}


def _list_registry(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read the openclaw agent-board registry — all known tentacle projects."""
    if not _REGISTRY.exists():
        return {"ok": False, "error": f"registry not found at {_REGISTRY}"}
    try:
        data = json.loads(_REGISTRY.read_text())
    except Exception as e:
        return {"ok": False, "error": f"failed to parse registry: {e}"}
    return {"ok": True, "registry": data, "count": len(data) if isinstance(data, list) else 0}


def _handoff(args: Dict[str, Any]) -> Dict[str, Any]:
    """Hand off a multi-turn conversation to a specialized tentacle.

    Sends a structured intro message plus the original user query.

    Args:
      to_tentacle: target tentacle name (required)
      context: 1-3 sentences of context Leon thinks the tentacle needs (required)
      user_query: the question/task to forward (required)
    """
    to = args.get("to_tentacle")
    ctx = args.get("context")
    q = args.get("user_query")
    if not (to and ctx and q):
        return {"ok": False, "error": "to_tentacle, context, user_query all required"}
    target = _resolve_target(str(to))
    if not target:
        return {"ok": False, "error": f"no tmux window matches '{to}'"}
    text = (
        f"[Leon → {to}] Context: {ctx}\n"
        f"Dean asks: {q}\n"
        f"Please answer here. Leon will read your pane after ~30s."
    )
    ok = _send_keys(target, text, press_enter=True)
    return {
        "ok": bool(ok),
        "handed_off_to": to,
        "target": target,
        "note": "Use tentacle.peek_tail to collect the response.",
    }


# ── Agent-board integration ─────────────────────────────────────────────
def _board_submit_request(args: Dict[str, Any]) -> Dict[str, Any]:
    """Write a request file to ~/.openclaw/agent-board/requests/ for async
    pickup. Useful for tasks that need Dean's eyes or a tentacle Leon can't
    talk to directly.

    Args:
      description: clear description of what is needed (required)
      type: 'browser' | 'approval' | 'click' | 'info' | 'shell' (default: info)
      url: optional URL the task references
      from_label: name to put in 'from' field (default: 'leon')
    """
    desc = args.get("description")
    if not desc:
        return {"ok": False, "error": "description is required"}
    req_type = args.get("type", "info")
    url = args.get("url")
    from_label = args.get("from_label", "leon")
    if not _REQUESTS_DIR.exists():
        return {"ok": False, "error": f"requests dir missing: {_REQUESTS_DIR}"}
    req_id = f"leon-{int(time.time())}-{uuid.uuid4().hex[:4]}"
    payload = {
        "id": req_id,
        "from": from_label,
        "type": req_type,
        "description": desc,
        "url": url,
        "created": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "status": "pending",
    }
    fname = _REQUESTS_DIR / f"{int(time.time())}-{uuid.uuid4().hex[:4]}.json"
    try:
        fname.write_text(json.dumps(payload, indent=2))
    except Exception as e:
        return {"ok": False, "error": f"write failed: {e}"}
    return {"ok": True, "request_id": req_id, "path": str(fname), "payload": payload}


def _board_list_pending(args: Dict[str, Any]) -> Dict[str, Any]:
    """List all pending requests in the agent-board queue."""
    if not _REQUESTS_DIR.exists():
        return {"ok": False, "error": "requests dir missing"}
    pending = []
    for f in sorted(_REQUESTS_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text())
            pending.append({
                "id": data.get("id"),
                "type": data.get("type"),
                "description": (data.get("description") or "")[:160],
                "from": data.get("from"),
                "status": data.get("status"),
                "file": f.name,
            })
        except Exception:
            continue
    return {"ok": True, "pending": pending, "count": len(pending)}


def _board_read_result(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read a result file from the agent-board by id or filename.

    Args:
      id_or_file: request id or filename (required)
    """
    target = args.get("id_or_file")
    if not target:
        return {"ok": False, "error": "id_or_file is required"}
    if not _RESULTS_DIR.exists():
        return {"ok": False, "error": "results dir missing"}
    # try exact filename, then search by id
    p = _RESULTS_DIR / target
    if not p.exists():
        for f in _RESULTS_DIR.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                if data.get("id") == target or data.get("request_id") == target:
                    p = f
                    break
            except Exception:
                continue
    if not p.exists():
        return {"ok": False, "error": f"no result for '{target}'"}
    try:
        return {"ok": True, "result": json.loads(p.read_text()), "file": str(p)}
    except Exception as e:
        return {"ok": False, "error": f"failed to parse: {e}"}


# ── EXTRA_TOOLS export ──────────────────────────────────────────────────
EXTRA_TOOLS = {
    "tentacle.list_active":      _list_active,
    "tentacle.peek_tail":        _peek_tail,
    "tentacle.delegate_task":    _delegate_task,
    "tentacle.query_status":     _query_status,
    "tentacle.health":           _health,
    "tentacle.broadcast":        _broadcast,
    "tentacle.spawn_ephemeral":  _spawn_ephemeral,
    "tentacle.close_ephemeral":  _close_ephemeral,
    "tentacle.list_registry":    _list_registry,
    "tentacle.handoff":          _handoff,
    "board.submit_request":      _board_submit_request,
    "board.list_pending":        _board_list_pending,
    "board.read_result":         _board_read_result,
}
