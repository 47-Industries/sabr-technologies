"""
Licensing heartbeat — the installed SI's daily phone-home.

WHY THIS EXISTS (2026-08-25)
----------------------------
Install tokens fail closed at install time, but an ALREADY-INSTALLED SI
never phoned home again — so a revoked customer, or a 24-hour free trial
that ended, kept a fully working SI forever. The server now answers
GET /api/onboarding/heartbeat with an explicit verdict; this module asks
it once a day and records the answer on disk.

WHAT THIS MODULE WILL NEVER DO
------------------------------
It never kills a process, never deletes anything, and never locks on a
network problem. The one thing it produces is a small JSON state file
(brain_state/license_state.json) that other components may read. A dead
Wi-Fi router, a DNS hiccup, a proxy 502, or our own server having a bad
day must NEVER brick a paying customer's SI — those only ever increment
`consecutive_failures`.

GRACE RULES (the contract, in order of importance)
--------------------------------------------------
1. Only an EXPLICIT server verdict ("revoked" or "expired", spoken in a
   well-formed non-5xx JSON answer) counts against the customer.
   Timeouts, connection errors, 5xx, unparseable bodies and unknown
   status strings are all failures-to-determine, and fail OPEN.
2. Even an explicit denial does not lock on its own: it takes
   REQUIRED_DENIALS (2) consecutive explicit denials, on separate
   check-ins, before status flips to "locked". One flaky answer — a
   half-migrated registry, an admin mid-edit — is not a verdict.
3. An explicit "active" clears everything: failures, pending denials,
   and an existing lock. Re-subscribing un-bricks without a reinstall.
4. No token on this machine (a developer checkout) means there is
   nothing to check and nothing is ever written or locked.
"""

from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional, Tuple

#: Consecutive explicit revoked/expired answers required before locking.
REQUIRED_DENIALS = 2

#: How often the background loop checks in (seconds). Daily.
CHECK_INTERVAL = 24 * 3600

_DEFAULT_HEARTBEAT_URL = "https://sabrtechnologies.com/api/onboarding/heartbeat"


def _app_root() -> str:
    import sys
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _heartbeat_url() -> str:
    return (os.environ.get("SABR_HEARTBEAT_URL") or _DEFAULT_HEARTBEAT_URL).strip()


def _state_path() -> str:
    override = os.environ.get("SABR_LICENSE_STATE_PATH")
    if override:
        return override
    d = os.path.join(_app_root(), "brain_state")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return os.path.join(d, "license_state.json")


def _env_file_path() -> str:
    """The .env the installer wrote. Overridable so tests never read the
    developer's real .env and mistake this checkout for an install."""
    return os.environ.get("SABR_LICENSE_ENV_FILE") or os.path.join(_app_root(), ".env")


def _read_token() -> str:
    """The install's tenant token, from wherever the installer put it.

    Every installer writes BOTH names (see installer/sabr_installer.py's
    long apology about the two-name situation); accept either, env first
    because a live process trusts its own environment over a file that
    may have been edited since boot.
    """
    for key in ("SABR_TENANT_TOKEN", "LEON_TENANT_TOKEN"):
        v = (os.environ.get(key) or "").strip()
        if v:
            return v
    try:
        with open(_env_file_path(), "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                for key in ("SABR_TENANT_TOKEN", "LEON_TENANT_TOKEN"):
                    if line.startswith(key + "="):
                        v = line.split("=", 1)[1].strip()
                        if v:
                            return v
    except OSError:
        pass
    return ""


# ── State file ────────────────────────────────────────────────────────

def _default_state() -> Dict[str, Any]:
    return {
        "status": "unknown",          # unknown | active | locked
        "last_ok": None,              # ts of last explicit "active"
        "last_check": None,           # ts of last check-in attempt
        "consecutive_failures": 0,    # network/5xx/garbage — NEVER locks
        "explicit_denials": 0,        # consecutive explicit revoked/expired
        "server_status": "",          # last explicit verdict verbatim
        "lock_reason": None,          # "revoked" | "expired" once locked
    }


def load_state() -> Dict[str, Any]:
    """The persisted state merged over defaults. Corruption is not fatal —
    a truncated file (power loss mid-write shouldn't happen given the
    atomic replace below, but disks lie) reads as a fresh unknown state,
    which can never lock anyone by itself."""
    state = _default_state()
    try:
        with open(_state_path(), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            state.update(data)
    except Exception:
        pass
    return state


def _save_state(state: Dict[str, Any]) -> None:
    path = _state_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(state, fh, indent=2)
        os.replace(tmp, path)
    except Exception as e:
        # Being unable to persist licensing state must not break anything.
        print(f"[LICENSE] could not write state file: {e}")


def is_locked() -> bool:
    """Other components read the verdict through this, never by killing
    or being killed — enforcement is their decision, not ours."""
    return load_state().get("status") == "locked"


# ── Talking to the server ─────────────────────────────────────────────

def _classify(status_code: int, body: str) -> Tuple[str, str]:
    """(kind, detail) where kind is "explicit" or "failure".

    Only a non-5xx, well-formed JSON answer whose status is one of the
    three words the contract defines counts as the server actually
    SPEAKING. Everything else — 5xx even with a plausible-looking body
    (a proxy's error page can echo anything), garbage JSON, a status
    string from some future protocol — is a failure to determine, and
    per grace rule 1 fails open.
    """
    if status_code >= 500:
        return ("failure", f"http_{status_code}")
    try:
        data = json.loads(body)
    except Exception:
        return ("failure", "unparseable_body")
    if not isinstance(data, dict):
        return ("failure", "unparseable_body")
    status = str(data.get("status") or "").strip().lower()
    if status in ("active", "revoked", "expired"):
        return ("explicit", status)
    return ("failure", f"unknown_status:{status[:32] or '(missing)'}")


def _fetch(token: str, timeout: float = 10.0) -> Tuple[str, str]:
    """One heartbeat call. Never raises."""
    url = _heartbeat_url() + "?token=" + urllib.parse.quote(token)
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return _classify(resp.getcode() or 200,
                             resp.read(65536).decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        try:
            body = e.read(65536).decode("utf-8", "replace")
        except Exception:
            body = ""
        return _classify(e.code, body)
    except Exception as e:
        return ("failure", type(e).__name__)


# ── The check-in ──────────────────────────────────────────────────────

def check_in(now: Optional[float] = None) -> Dict[str, Any]:
    """One heartbeat: ask the server, apply the grace rules, persist.

    Returns the resulting state dict. Never raises, never exits, never
    touches any process — the strongest thing it can do is write
    status="locked" into the state file.
    """
    now = time.time() if now is None else now
    token = _read_token()
    if not token:
        # A developer checkout or a pre-token install. Nothing to check,
        # and writing state for it would be inventing a license question
        # nobody asked.
        return {"status": "no-token", "last_check": now}

    state = load_state()
    state["last_check"] = now
    try:
        kind, detail = _fetch(token)
    except Exception as e:  # _fetch shouldn't raise; belt and braces
        kind, detail = ("failure", type(e).__name__)

    if kind == "failure":
        # Grace rule 1: a blip is a blip. Count it, change nothing else.
        state["consecutive_failures"] = int(state.get("consecutive_failures") or 0) + 1
        state["last_failure"] = detail
    elif detail == "active":
        # Grace rule 3: an explicit all-clear resets everything, including
        # an existing lock — re-subscribing must not require a reinstall.
        state.update(
            status="active",
            last_ok=now,
            consecutive_failures=0,
            explicit_denials=0,
            server_status="active",
            lock_reason=None,
        )
    else:
        # Explicit revoked/expired. The server SPOKE, so the failure
        # streak ends here — but grace rule 2 demands a second, separate
        # confirmation before anything locks.
        state["consecutive_failures"] = 0
        state["explicit_denials"] = int(state.get("explicit_denials") or 0) + 1
        state["server_status"] = detail
        if state["explicit_denials"] >= REQUIRED_DENIALS:
            state["status"] = "locked"
            state["lock_reason"] = detail
            print(f"[LICENSE] entitlement {detail} — confirmed twice; "
                  f"state file marked locked (no process was touched)")
        else:
            print(f"[LICENSE] server says {detail} — awaiting a second "
                  f"confirmation before anything changes")

    _save_state(state)
    return state


# ── Background loop ───────────────────────────────────────────────────

_loop_lock = threading.Lock()
_loop_started = False


def ensure_started(interval: float = CHECK_INTERVAL) -> bool:
    """Arm the daily heartbeat thread. Idempotent; returns True only the
    first time. Daemon thread — it must never keep the process alive."""
    global _loop_started
    with _loop_lock:
        if _loop_started:
            return False
        _loop_started = True

    def _loop():
        while True:
            try:
                check_in()
            except Exception as e:
                print(f"[LICENSE] heartbeat check failed harmlessly: {e}")
            time.sleep(interval)

    threading.Thread(target=_loop, daemon=True, name="license-heartbeat").start()
    return True
