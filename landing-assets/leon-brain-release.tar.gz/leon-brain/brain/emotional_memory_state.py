"""
Emotional Carry-Over State — neuromodulator baseline shifts that persist.

A bad day yesterday makes today harder. Serotonin deficit persists across
hours. Dopamine exhaustion from overstimulation takes time to recover.

This module tracks a *baseline shift* for each neuromodulator. The shift
drifts slowly based on sustained highs/lows, and recovers toward zero at
~0.001 per minute. State is saved to disk so it survives restarts.

Architecture:
  - Each neuromodulator has a baseline_shift (starts at 0.0)
  - When a neuromodulator stays below a low threshold for >5 min,
    the baseline shifts down slightly each tick
  - When a neuromodulator stays above a high threshold repeatedly,
    an exhaustion effect builds (effective ceiling drops)
  - Recovery toward neutral is slow: 0.001 per minute
  - State is persisted to brain_state/emotional_carry.json

Does NOT modify brain.py neuromodulator logic — only layers on top.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Optional

# ── Config ──────────────────────────────────────────────────────────

_NEUROMODULATORS = ("dopamine", "serotonin", "norepinephrine", "acetylcholine")

# Thresholds for sustained low / high detection
_LOW_THRESHOLD = 0.3
_HIGH_THRESHOLD = 0.8

# How long (seconds) a neuromodulator must stay below _LOW_THRESHOLD
# before the baseline starts shifting down
_SUSTAINED_LOW_DURATION = 300.0  # 5 minutes

# Per-tick baseline shift when sustained low is detected
_SHIFT_PER_TICK_LOW = -0.01

# Per-tick exhaustion buildup when above high threshold
_EXHAUSTION_PER_TICK_HIGH = 0.005

# Maximum absolute baseline shift (prevents runaway)
_MAX_SHIFT = 0.15

# Maximum exhaustion (ceiling drop)
_MAX_EXHAUSTION = 0.15

# Recovery rate: shift drifts back toward 0 at this rate per minute
_RECOVERY_PER_MINUTE = 0.001

# How strongly the shift nudges current neuromodulator levels per tick
_NUDGE_STRENGTH = 0.002

# Save interval (seconds) — don't write to disk every tick
_SAVE_INTERVAL = 30.0

# ── State file path ─────────────────────────────────────────────────

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_STATE_FILE = _STATE_DIR / "emotional_carry.json"


class EmotionalCarryState:
    """Tracks neuromodulator baseline shifts that persist across ticks and restarts."""

    def __init__(self) -> None:
        # baseline_shift: how far the "resting level" has moved from neutral
        # Negative = depleted, positive = elevated
        self.baseline_shift: dict[str, float] = {nm: 0.0 for nm in _NEUROMODULATORS}

        # exhaustion: how much the effective ceiling has dropped
        # (only builds from sustained highs)
        self.exhaustion: dict[str, float] = {nm: 0.0 for nm in _NEUROMODULATORS}

        # Track how long each neuromodulator has been below low threshold
        self._low_duration: dict[str, float] = {nm: 0.0 for nm in _NEUROMODULATORS}

        # Track how long each has been above high threshold
        self._high_duration: dict[str, float] = {nm: 0.0 for nm in _NEUROMODULATORS}

        self._last_tick_time: float = time.time()
        self._last_save_time: float = time.time()

        # Load persisted state
        self._load()

    # ── Persistence ─────────────────────────────────────────────────

    def _load(self) -> None:
        """Load baseline shifts and exhaustion from disk."""
        try:
            if _STATE_FILE.exists():
                data = json.loads(_STATE_FILE.read_text())
                for nm in _NEUROMODULATORS:
                    self.baseline_shift[nm] = float(data.get("baseline_shift", {}).get(nm, 0.0))
                    self.exhaustion[nm] = float(data.get("exhaustion", {}).get(nm, 0.0))
                    self._low_duration[nm] = float(data.get("low_duration", {}).get(nm, 0.0))
                    self._high_duration[nm] = float(data.get("high_duration", {}).get(nm, 0.0))
                self._last_tick_time = float(data.get("timestamp", time.time()))
                # Account for time spent offline — recovery happens while off too
                offline_minutes = (time.time() - self._last_tick_time) / 60.0
                if offline_minutes > 1.0:
                    self._apply_offline_recovery(offline_minutes)
        except Exception:
            pass  # Start fresh if anything is wrong

    def _apply_offline_recovery(self, minutes: float) -> None:
        """While Leon was off, baseline shifts recover toward neutral."""
        recovery = _RECOVERY_PER_MINUTE * minutes
        for nm in _NEUROMODULATORS:
            if self.baseline_shift[nm] > 0:
                self.baseline_shift[nm] = max(0.0, self.baseline_shift[nm] - recovery)
            elif self.baseline_shift[nm] < 0:
                self.baseline_shift[nm] = min(0.0, self.baseline_shift[nm] + recovery)
            # Exhaustion also recovers
            self.exhaustion[nm] = max(0.0, self.exhaustion[nm] - recovery)
            # Low/high duration resets after offline
            self._low_duration[nm] = 0.0
            self._high_duration[nm] = 0.0

    def _save(self) -> None:
        """Persist state to disk."""
        try:
            _STATE_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "baseline_shift": dict(self.baseline_shift),
                "exhaustion": dict(self.exhaustion),
                "low_duration": dict(self._low_duration),
                "high_duration": dict(self._high_duration),
                "timestamp": time.time(),
            }
            _STATE_FILE.write_text(json.dumps(data, indent=2))
        except Exception:
            pass

    # ── Tick ────────────────────────────────────────────────────────

    def tick(self, brain: Any) -> None:
        """Called each perception tick. Reads neuromodulators, updates shifts, nudges levels."""
        now = time.time()
        dt = now - self._last_tick_time
        self._last_tick_time = now

        # Clamp dt to avoid huge jumps if tick was delayed
        dt = min(dt, 5.0)
        if dt <= 0:
            return

        nm_levels = getattr(brain, "neuromodulators", None)
        if nm_levels is None:
            return

        dt_minutes = dt / 60.0

        for nm in _NEUROMODULATORS:
            level = nm_levels.get(nm, 0.5)

            # ── Track sustained lows ──
            if level < _LOW_THRESHOLD:
                self._low_duration[nm] += dt
            else:
                # Reset when above threshold
                self._low_duration[nm] = max(0.0, self._low_duration[nm] - dt * 0.5)

            # ── Track sustained highs ──
            if level > _HIGH_THRESHOLD:
                self._high_duration[nm] += dt
            else:
                self._high_duration[nm] = max(0.0, self._high_duration[nm] - dt * 0.5)

            # ── Shift baseline down if sustained low ──
            if self._low_duration[nm] >= _SUSTAINED_LOW_DURATION:
                self.baseline_shift[nm] = max(
                    -_MAX_SHIFT,
                    self.baseline_shift[nm] + _SHIFT_PER_TICK_LOW * dt,
                )

            # ── Build exhaustion if sustained high ──
            if self._high_duration[nm] > 60.0:  # Must be high for >1 min
                self.exhaustion[nm] = min(
                    _MAX_EXHAUSTION,
                    self.exhaustion[nm] + _EXHAUSTION_PER_TICK_HIGH * dt,
                )

            # ── Slow recovery toward neutral ──
            recovery = _RECOVERY_PER_MINUTE * dt_minutes
            if self.baseline_shift[nm] > 0:
                self.baseline_shift[nm] = max(0.0, self.baseline_shift[nm] - recovery)
            elif self.baseline_shift[nm] < 0:
                self.baseline_shift[nm] = min(0.0, self.baseline_shift[nm] + recovery)
            self.exhaustion[nm] = max(0.0, self.exhaustion[nm] - recovery)

            # ── Apply the shift: nudge current level toward shifted baseline ──
            # The "target" is the brain's natural baseline + our shift
            import numpy as np
            effective_ceiling = 1.0 - self.exhaustion[nm]
            nudge = self.baseline_shift[nm] * _NUDGE_STRENGTH
            new_level = np.clip(level + nudge, 0.05, effective_ceiling)
            nm_levels[nm] = float(new_level)

        # Periodic save
        if now - self._last_save_time >= _SAVE_INTERVAL:
            self._save()
            self._last_save_time = now

    # ── Prompt output ───────────────────────────────────────────────

    def for_prompt(self) -> str:
        """Return a human-readable string about significant emotional undertow.

        Only returns text when shifts are significant (|shift| > 0.03 or
        exhaustion > 0.03). Otherwise returns empty string.
        """
        lines: list[str] = []

        _LABELS = {
            "dopamine": ("motivation", "reward-drive"),
            "serotonin": ("mood stability", "contentment"),
            "norepinephrine": ("alertness", "arousal"),
            "acetylcholine": ("focus", "attention"),
        }

        for nm in _NEUROMODULATORS:
            shift = self.baseline_shift[nm]
            exh = self.exhaustion[nm]
            label_low, label_high = _LABELS[nm]

            if shift < -0.03:
                severity = "deep" if shift < -0.08 else "mild"
                lines.append(f"{nm} baseline depressed ({severity}) — reduced {label_low} from extended strain")
            elif shift > 0.03:
                severity = "strong" if shift > 0.08 else "mild"
                lines.append(f"{nm} baseline elevated ({severity}) — sustained {label_high} momentum")

            if exh > 0.03:
                severity = "significant" if exh > 0.08 else "mild"
                lines.append(f"{nm} exhaustion ({severity}) — ceiling lowered from overstimulation")

        if not lines:
            return ""

        return "EMOTIONAL UNDERTOW — " + "; ".join(lines)

    # ── Summary for debugging ───────────────────────────────────────

    def summary(self) -> dict:
        """Return current state as a dict for debugging."""
        return {
            "baseline_shift": dict(self.baseline_shift),
            "exhaustion": dict(self.exhaustion),
            "low_duration": {nm: round(v, 1) for nm, v in self._low_duration.items()},
            "high_duration": {nm: round(v, 1) for nm, v in self._high_duration.items()},
        }
