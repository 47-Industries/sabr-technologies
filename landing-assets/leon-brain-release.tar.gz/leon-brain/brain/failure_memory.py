"""
Failure Memory — Leon remembers what doesn't work so he never repeats mistakes.

Stores failed tool calls with context. Before any tool call, check if
this exact pattern has failed before. If so, skip it and try alternatives.

Persists across restarts in brain_state/failure_memory.json.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"
_FAILURE_FILE = _STATE_DIR / "failure_memory.json"
_LOCK = threading.Lock()
_CACHE: Optional[Dict] = None
_CACHE_TS: float = 0
_CACHE_TTL: float = 10.0  # reload from disk every 10s max


def _load() -> dict:
    global _CACHE, _CACHE_TS
    if _CACHE is not None and time.time() - _CACHE_TS < _CACHE_TTL:
        return _CACHE
    try:
        _CACHE = json.loads(_FAILURE_FILE.read_text(encoding="utf-8"))
    except Exception:
        _CACHE = {"failures": {}, "permanent_blocks": []}
    _CACHE_TS = time.time()
    return _CACHE


def _save(data: dict) -> None:
    global _CACHE, _CACHE_TS
    _STATE_DIR.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        _FAILURE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        _CACHE = data
        _CACHE_TS = time.time()


def record_failure(tool: str, error: str, context: str = "") -> None:
    """Record a tool failure. After 3 failures with same error, it becomes a known issue."""
    data = _load()
    failures = data.setdefault("failures", {})
    key = f"{tool}::{error[:100]}"
    entry = failures.get(key, {"tool": tool, "error": error[:200],
                                "count": 0, "first_seen": time.time(),
                                "context": context[:200]})
    entry["count"] += 1
    entry["last_seen"] = time.time()
    failures[key] = entry

    # Auto-block after 3 identical failures
    if entry["count"] >= 3:
        blocks = data.setdefault("permanent_blocks", [])
        block_key = f"{tool}::{error[:50]}"
        if block_key not in blocks:
            blocks.append(block_key)
            try:
                from server.helpers import broadcast_activity
                broadcast_activity("inner",
                    f"Learned: {tool} fails with '{error[:60]}' — won't try again", 10000)
            except Exception:
                pass

    # Cap total entries
    if len(failures) > 500:
        sorted_keys = sorted(failures, key=lambda k: failures[k].get("last_seen", 0))
        for old_key in sorted_keys[:100]:
            del failures[old_key]

    _save(data)


def is_known_failure(tool: str, context: str = "") -> Optional[str]:
    """Check if this tool is known to fail. Returns the error message or None."""
    data = _load()
    blocks = data.get("permanent_blocks", [])
    for block in blocks:
        if block.startswith(f"{tool}::"):
            return block.split("::", 1)[1]
    return None


def get_failures_for_tool(tool: str) -> List[dict]:
    """Get all recorded failures for a tool."""
    data = _load()
    return [v for k, v in data.get("failures", {}).items()
            if v.get("tool") == tool]


def get_all_blocked() -> List[str]:
    """Get list of permanently blocked tool+error combos."""
    return _load().get("permanent_blocks", [])


def get_summary() -> dict:
    """Summary stats for the dashboard/debugging."""
    data = _load()
    failures = data.get("failures", {})
    blocks = data.get("permanent_blocks", [])
    return {
        "total_failure_patterns": len(failures),
        "permanent_blocks": len(blocks),
        "top_failures": sorted(
            failures.values(),
            key=lambda x: x.get("count", 0),
            reverse=True,
        )[:10],
    }
