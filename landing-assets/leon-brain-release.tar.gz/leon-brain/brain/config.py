"""
Leon Configuration

Phase-0 region rebuild (2026-05-11): replaced the original 11 regions with
18 anatomically-named regions. The previous mix (sensory_cortex, feature_layer,
concept_layer, predictive, reflex_arc, ...) bundled real anatomy with ML
abstractions that aren't actual brain regions. New layout is fully
anatomical — every region is a real part of a real brain.

Sources/justifications for each region's role are documented in
brain/regions.py docstrings.
"""

import numpy as np


class BrainConfig:
    # --- Scale ---
    TOTAL_NEURONS = 10_000  # 10K — same architecture, 100x fewer synapses, no lag
    SYNAPSES_PER_NEURON = 1200  # Average connections per neuron

    # --- Region proportions (must sum to 1.0) ---
    # Distribution: bigger areas (cortex, cerebellum) get more neurons; small
    # specialty nuclei (insula, ACC) get less. Sums to 1.000.
    REGION_PROPORTIONS = {
        # Primary sensory cortices (split from old "sensory_cortex")
        "visual_cortex":          0.060,   # V1-V5, occipital lobe
        "auditory_cortex":        0.040,   # A1, superior temporal gyrus
        "somatosensory_cortex":   0.030,   # S1, postcentral gyrus

        # Primary motor + coordination
        "motor_cortex":           0.030,   # M1, precentral gyrus
        "cerebellum":             0.080,   # Motor coordination + emerging cognitive role

        # Association cortex (split from old "association")
        "parietal_association":   0.070,   # Multimodal integration
        "temporal_association":   0.070,   # Object/face recognition, semantic memory

        # Executive — EXPANDED for agency and planning
        "prefrontal_cortex":      0.120,   # Planning, decisions, working memory, agency
        "anterior_cingulate":     0.040,   # Error/conflict monitoring, self-model
        "insula":                 0.020,   # Interoception, subjective state

        # Language — EXPANDED for SNN-driven language (Path 2 foundation)
        "broca":                  0.080,   # Speech/language production — future word generation
        "wernicke":               0.080,   # Language comprehension — future word recognition

        # Memory + emotion (limbic system)
        "hippocampus":            0.060,   # Episodic memory consolidation + concept map
        "amygdala":               0.030,   # Salience, threat, reward weighting

        # Subcortical relays + action selection
        "thalamus":               0.050,   # Sensory relay + attention gating
        "basal_ganglia":          0.040,   # Action selection, habit formation

        # Brainstem trunk
        "brainstem":              0.030,   # Arousal + life functions

        # Mind-wandering substrate
        "default_mode_network":   0.070,   # Self-referential thought, idle resting state, daydreaming
    }
    # Sanity check at import time — fail loudly if proportions drift
    assert abs(sum(REGION_PROPORTIONS.values()) - 1.0) < 1e-6, \
        f"REGION_PROPORTIONS sum to {sum(REGION_PROPORTIONS.values())}, must be 1.0"

    # --- Izhikevich neuron parameters by region ---
    # (a, b, c, d) - different firing patterns per region. Patterns chosen
    # to roughly match the biologically-observed regimes:
    #   RS  (regular spiking)         - pyramidal cortical neurons
    #   IB  (intrinsically bursting)  - deep cortical layers, prefrontal
    #   CH  (chattering)              - some cortical layers, hippocampus
    #   FS  (fast spiking)            - inhibitory interneurons, thalamic relay
    #   LTS (low-threshold spiking)   - some brainstem neurons, modulators
    _RS  = {"a": 0.02, "b": 0.20, "c": -65, "d": 8}
    _IB  = {"a": 0.02, "b": 0.20, "c": -55, "d": 4}
    _CH  = {"a": 0.02, "b": 0.20, "c": -50, "d": 2}
    _FS  = {"a": 0.10, "b": 0.20, "c": -65, "d": 2}
    _LTS = {"a": 0.02, "b": 0.25, "c": -65, "d": 0.05}

    NEURON_PARAMS = {
        "visual_cortex":         _RS,
        "auditory_cortex":       _RS,
        "somatosensory_cortex":  _RS,
        "motor_cortex":          _RS,
        "cerebellum":            _FS,
        "parietal_association":  _CH,
        "temporal_association":  _CH,
        "prefrontal_cortex":     _IB,
        "anterior_cingulate":    _FS,    # rapid error detection
        "insula":                _IB,
        "broca":                 _RS,
        "wernicke":              _CH,
        "hippocampus":           _CH,
        "amygdala":              _IB,
        "thalamus":              _FS,    # high-throughput relay
        "basal_ganglia":         _FS,    # inhibitory gating
        "brainstem":             _LTS,
        "default_mode_network":  _IB,
    }

    # --- Connectivity matrix (source -> target probability) ---
    # Anatomically-motivated. Major pathways:
    #   sensory → thalamus → cortex → association → prefrontal
    #   prefrontal → basal_ganglia → thalamus → motor (action loop)
    #   motor → cerebellum → brainstem
    #   amygdala → prefrontal, hippocampus, insula (emotion routing)
    #   wernicke → broca → motor (language production)
    #   default_mode ↔ prefrontal, parietal, temporal (resting state)
    CONNECTIVITY = {
        # Sensory afferents → thalamus (relay station)
        ("visual_cortex",        "thalamus"):              0.08,
        ("auditory_cortex",      "thalamus"):              0.08,
        ("somatosensory_cortex", "thalamus"):              0.08,

        # Thalamus → cortex (every sense goes through it both ways)
        ("thalamus", "visual_cortex"):         0.12,
        ("thalamus", "auditory_cortex"):       0.12,
        ("thalamus", "somatosensory_cortex"):  0.12,
        ("thalamus", "motor_cortex"):          0.10,
        ("thalamus", "prefrontal_cortex"):     0.08,

        # Sensory → association (skip and direct paths)
        ("visual_cortex",        "temporal_association"):  0.10,
        ("auditory_cortex",      "temporal_association"):  0.12,
        ("somatosensory_cortex", "parietal_association"):  0.12,
        ("visual_cortex",        "parietal_association"):  0.08,

        # Association ↔ prefrontal (executive integration)
        ("parietal_association", "prefrontal_cortex"):     0.10,
        ("temporal_association", "prefrontal_cortex"):     0.10,
        ("prefrontal_cortex",    "parietal_association"):  0.06,
        ("prefrontal_cortex",    "temporal_association"):  0.06,

        # Hippocampus loop (memory)
        ("parietal_association", "hippocampus"):           0.10,
        ("temporal_association", "hippocampus"):           0.12,
        ("hippocampus",          "parietal_association"):  0.08,
        ("hippocampus",          "temporal_association"):  0.10,
        ("hippocampus",          "prefrontal_cortex"):     0.08,

        # Limbic (emotion)
        ("amygdala", "prefrontal_cortex"):     0.10,
        ("amygdala", "hippocampus"):           0.08,
        ("amygdala", "insula"):                0.06,
        ("amygdala", "anterior_cingulate"):    0.08,
        ("prefrontal_cortex", "amygdala"):     0.05,   # top-down regulation

        # Error/conflict monitoring
        ("anterior_cingulate", "prefrontal_cortex"):       0.10,
        ("prefrontal_cortex",  "anterior_cingulate"):      0.08,
        ("anterior_cingulate", "basal_ganglia"):           0.06,

        # Insula (self-state)
        ("insula", "prefrontal_cortex"):       0.06,
        ("insula", "anterior_cingulate"):      0.05,

        # Language loop
        ("wernicke", "broca"):                 0.15,
        ("wernicke", "temporal_association"):  0.10,
        ("broca",    "motor_cortex"):          0.12,
        ("temporal_association", "wernicke"):  0.08,

        # Action selection (cortico-basal-thalamic loop)
        ("prefrontal_cortex", "basal_ganglia"):            0.10,
        ("basal_ganglia",     "thalamus"):                 0.10,   # gating motor commands

        # Motor → cerebellum → brainstem
        ("motor_cortex", "cerebellum"):        0.12,
        ("motor_cortex", "brainstem"):         0.08,
        ("cerebellum",   "motor_cortex"):      0.10,
        ("cerebellum",   "brainstem"):         0.05,

        # Brainstem modulatory output (broad cortical projections)
        ("brainstem", "thalamus"):             0.05,
        ("brainstem", "prefrontal_cortex"):    0.03,

        # Default Mode Network (resting state)
        ("default_mode_network", "prefrontal_cortex"):     0.08,
        ("default_mode_network", "parietal_association"):  0.08,
        ("default_mode_network", "temporal_association"):  0.06,
        ("prefrontal_cortex",    "default_mode_network"):  0.05,
        ("parietal_association", "default_mode_network"):  0.05,
    }

    # --- STDP Learning ---
    STDP_TAU_PLUS = 20.0     # ms, LTP time constant
    STDP_TAU_MINUS = 20.0    # ms, LTD time constant
    STDP_A_PLUS = 0.01       # LTP amplitude
    STDP_A_MINUS = 0.012     # LTD amplitude (slightly stronger for stability)
    STDP_W_MAX = 1.0         # Maximum synapse weight
    STDP_W_MIN = 0.0         # Minimum synapse weight

    # --- Neuromodulators ---
    DOPAMINE_BASELINE = 0.5
    ACETYLCHOLINE_BASELINE = 0.5
    NOREPINEPHRINE_BASELINE = 0.5   # resting alertness; Leon reads his own gauge,
                                    # so 0.3 still felt "low" — 0.5 reads as present
    SEROTONIN_BASELINE = 0.5

    # --- Simulation ---
    DT = 1.0                 # Timestep in ms
    STEPS_PER_UPDATE = 10    # Steps per WebSocket update
    THALAMIC_NOISE = 5.0     # Background noise amplitude

    # --- Safety kernel ---
    SAFETY_FORCE_LIMIT = 100.0
    SAFETY_VELOCITY_LIMIT = 50.0
    SAFETY_COLLISION_MARGIN = 0.1

    # --- Development stages ---
    STAGES = {
        "EMBRYONIC":    (0, 100_000),
        "JUVENILE":     (100_000, 2_000_000),
        "ADOLESCENT":   (2_000_000, 10_000_000),
        "MATURE":       (10_000_000, float("inf")),
    }

    # --- Server ---
    HOST = "0.0.0.0"
    PORT = 8000
    WS_UPDATE_RATE = 30  # Hz
