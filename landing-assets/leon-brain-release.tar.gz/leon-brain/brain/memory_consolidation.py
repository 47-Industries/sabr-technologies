"""
Memory Consolidation — the promotion engine that makes Leon genuinely remember.

Models how the human hippocampus replays and promotes important memories during
sleep (and periodically while awake). Without this, conversation-distilled facts
decay and vanish within a week.

THREE tiers:
  conversation_distill → raw, decays (7-day halflife), searchable only
  dean_stated          → durable from birth (distiller tags importance>=4 + speaker=dean)
  consolidated         → promoted by this daemon, durable, injected in prompt

Promotion signals (weighted):
  1. Importance score from distiller (metadata.importance, 1-5)
  2. Access frequency (access_count — how often Leon searched for it)
  3. Emotional salience at encoding (high norepinephrine = correction/surprise)
  4. Repetition (similar facts appearing multiple times)
  5. Source = dean_stated (Dean said it directly)

Runs:
  - Every 30 minutes while awake (lightweight pass)
  - During sleep consolidation (full pass with dedup)
"""

from __future__ import annotations

import json
import math
import os
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DB = os.path.join(_ROOT, "brain_state", "knowledge.db")

# Promotion threshold — facts scoring above this get promoted
_PROMOTE_THRESHOLD = 0.60

# Max consolidated facts to inject into prompt (prevent bloat)
MAX_CONSOLIDATED_IN_PROMPT = 30

# How often the background loop runs (seconds)
_INTERVAL_AWAKE = 30 * 60   # 30 min while awake
_INTERVAL_SLEEP = 10 * 60   # 10 min during sleep (more active consolidation)


def _score_for_promotion(row: dict) -> float:
    """Score a knowledge row for promotion to consolidated tier.
    Returns 0.0-1.0 where higher = more deserving of promotion.

    This is the "importance function" — it answers Dean's question
    "how do you decide what's important?" with 5 signals, weighted
    like a real brain would weight them."""

    score = 0.0

    # Signal 1: Distiller importance score (0-0.30)
    # The distiller already scored this 1-5 based on whether Dean
    # said it, whether it's a correction, etc.
    try:
        meta = json.loads(row.get("metadata") or "{}")
    except Exception:
        meta = {}
    importance = meta.get("importance", 2)
    score += min(importance / 5.0, 1.0) * 0.30

    # Signal 2: Access frequency (0-0.25)
    # If Leon keeps searching for this fact, it matters.
    access_count = row.get("access_count") or 0
    # Saturating curve: 1 access = 0.08, 3 = 0.19, 5 = 0.25
    score += min(1.0, 1.0 - math.exp(-access_count / 4.0)) * 0.25

    # Signal 3: Emotional salience at encoding (0-0.20)
    # High norepinephrine = surprise/correction = IMPORTANT
    # High dopamine = reward/excitement = IMPORTANT
    ne = row.get("emo_norepinephrine") or -1
    da = row.get("emo_dopamine") or -1
    if ne >= 0 and da >= 0:
        # NE > 0.6 = surprise/correction signal
        # DA > 0.7 = reward signal
        emo_signal = max(
            min(ne / 0.8, 1.0) if ne > 0.4 else 0.0,
            min(da / 0.9, 1.0) if da > 0.5 else 0.0,
        )
        score += emo_signal * 0.20

    # Signal 4: Source = dean_stated (0-0.15)
    # Dean said it directly — that's inherently important
    source = row.get("source") or ""
    if source == "dean_stated":
        score += 0.15
    elif source == "user":
        score += 0.10

    # Signal 5: Strength (survival signal) (0-0.10)
    # If it's already been reinforced by LTP, it matters
    strength = row.get("strength") or 1.0
    if strength > 1.5:
        score += min((strength - 1.0) / 4.0, 1.0) * 0.10

    return min(score, 1.0)


def _find_promotion_candidates(db_path: str = _DB,
                                limit: int = 50) -> List[dict]:
    """Find knowledge rows that deserve promotion to consolidated.
    Only looks at conversation_distill and dean_stated sources
    that haven't already been promoted."""
    conn = sqlite3.connect(db_path, timeout=30)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT * FROM knowledge "
        "WHERE source IN ('conversation_distill', 'dean_stated') "
        "ORDER BY timestamp DESC "
        "LIMIT ?",
        (limit * 3,),  # fetch more than needed, score and filter
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# Dean's standing order 2026-08-11: lead generation is dead. Memories about
# leads / cold outreach kept getting auto-promoted into the prompt, which is
# how the dead topic kept resurrecting itself and making him repeat himself.
# Nothing matching these ever earns a permanent slot again.
_BANNED_PROMOTION_TERMS = (
    "lead gen", "leads", "lead list", "cold email", "cold outreach",
    "outreach", "prospect", "no website",
)


def _is_banned_memory(text: str) -> bool:
    low = (text or "").lower()
    return any(term in low for term in _BANNED_PROMOTION_TERMS)


def _promote_rows(row_ids: List[int], db_path: str = _DB) -> int:
    """Promote rows to consolidated source. Updates source and boosts strength."""
    if not row_ids:
        return 0
    # Filter out anything on the banned-topic list BEFORE it becomes permanent.
    conn = sqlite3.connect(db_path, timeout=30)
    ph0 = ",".join("?" * len(row_ids))
    texts = conn.execute(
        f"SELECT id, text FROM knowledge WHERE id IN ({ph0})", row_ids
    ).fetchall()
    conn.close()
    banned = {rid for rid, txt in texts if _is_banned_memory(txt)}
    row_ids = [r for r in row_ids if r not in banned]
    if not row_ids:
        return 0
    conn = sqlite3.connect(db_path, timeout=30)
    ph = ",".join("?" * len(row_ids))
    conn.execute(
        f"UPDATE knowledge SET source = 'consolidated', "
        f"  strength = MAX(strength, 3.0) "
        f"WHERE id IN ({ph})",
        row_ids,
    )
    conn.commit()
    n = conn.total_changes
    conn.close()
    return n


def _deduplicate_consolidated(db_path: str = _DB) -> int:
    """Remove duplicate consolidated facts (same text, keep highest strength)."""
    conn = sqlite3.connect(db_path, timeout=30)
    # Find duplicates by normalized text
    rows = conn.execute(
        "SELECT id, LOWER(TRIM(text)) as norm_text, strength "
        "FROM knowledge "
        "WHERE source IN ('consolidated', 'dean_stated') "
        "ORDER BY norm_text, strength DESC"
    ).fetchall()
    conn.close()

    # Group by normalized text, keep the strongest
    seen = {}
    to_delete = []
    for row_id, norm_text, strength in rows:
        if norm_text in seen:
            to_delete.append(row_id)
        else:
            seen[norm_text] = row_id

    if to_delete:
        conn = sqlite3.connect(db_path, timeout=30)
        ph = ",".join("?" * len(to_delete))
        conn.execute(f"DELETE FROM knowledge WHERE id IN ({ph})", to_delete)
        conn.commit()
        conn.close()
    return len(to_delete)


def run_consolidation_pass(db_path: str = _DB) -> Dict[str, Any]:
    """Run one consolidation pass. Score candidates, promote qualifying ones,
    deduplicate. Returns a report dict."""
    t0 = time.time()

    candidates = _find_promotion_candidates(db_path)
    scored = []
    for row in candidates:
        s = _score_for_promotion(row)
        if s >= _PROMOTE_THRESHOLD:
            scored.append((row["id"], s, row["text"][:80]))

    promoted = 0
    if scored:
        ids_to_promote = [row_id for row_id, _, _ in scored]
        promoted = _promote_rows(ids_to_promote, db_path)

    deduped = _deduplicate_consolidated(db_path)

    report = {
        "candidates_checked": len(candidates),
        "promoted": promoted,
        "deduplicated": deduped,
        "duration_ms": round((time.time() - t0) * 1000),
        "promoted_facts": [(text, round(score, 3)) for _, score, text in scored[:10]],
    }
    if promoted > 0:
        print(f"[CONSOLIDATION] promoted {promoted} facts, deduped {deduped}")
        for text, score in report["promoted_facts"][:5]:
            print(f"  [{score}] {text}")
    return report


def get_consolidated_facts(db_path: str = _DB,
                           limit: int = MAX_CONSOLIDATED_IN_PROMPT) -> List[str]:
    """Get all consolidated facts for prompt injection.
    Returns the text of each consolidated fact, ordered by strength then recency."""
    conn = sqlite3.connect(db_path, timeout=30)
    rows = conn.execute(
        "SELECT text FROM knowledge "
        "WHERE source IN ('consolidated', 'dean_stated') "
        "ORDER BY strength DESC, timestamp DESC "
        "LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [r[0] for r in rows]


# ── Background daemon ────────────────────────────────────────────────

class MemoryConsolidationDaemon:
    """Background thread that periodically runs consolidation passes."""

    def __init__(self, db_path: str = _DB):
        self.db_path = db_path
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._is_sleeping = False

    def set_sleeping(self, sleeping: bool) -> None:
        """Tell the daemon Leon is sleeping — run more aggressively."""
        self._is_sleeping = sleeping

    def _loop(self) -> None:
        # Wait 2 min after startup before first pass
        if self._stop.wait(120):
            return
        while not self._stop.is_set():
            try:
                run_consolidation_pass(self.db_path)
            except Exception as e:
                print(f"[CONSOLIDATION] pass failed: {e}")
            interval = _INTERVAL_SLEEP if self._is_sleeping else _INTERVAL_AWAKE
            if self._stop.wait(interval):
                return

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name="MemoryConsolidation", daemon=True
        )
        self._thread.start()
        print(f"[CONSOLIDATION] daemon started (awake={_INTERVAL_AWAKE}s, "
              f"sleep={_INTERVAL_SLEEP}s, threshold={_PROMOTE_THRESHOLD})")

    def stop(self) -> None:
        self._stop.set()
