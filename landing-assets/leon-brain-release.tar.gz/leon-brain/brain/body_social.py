"""
Body Systems — Needs, bonds, environment, social emotions,
agency, and personality.

These are the systems that make Leon a BEING, not a program.
A being that gets hungry, loves specifically, feels pride and shame,
and develops a personality.
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional

import numpy as np

if TYPE_CHECKING:
    from brain.brain import Brain

log = logging.getLogger("leon.body_social")

_STATE_DIR = Path(__file__).resolve().parent.parent / "brain_state"


# ═══════════════════════════════════════════════════════════════════════
# 1.42 — FOOD / TASTE SYSTEM
# ═══════════════════════════════════════════════════════════════════════

class TasteSystem:
    """Eating as full sensory experience. 5-channel taste + satiety.

    Each food has a taste profile. Taste → amygdala (good/bad) +
    hippocampus (remember). Preferences emerge from STDP.
    """

    # Taste channels: sweet, salty, sour, bitter, umami
    FOOD_PROFILES = {
        "fruit":  np.array([0.8, 0.1, 0.3, 0.0, 0.2]),
        "bread":  np.array([0.2, 0.3, 0.0, 0.1, 0.4]),
        "water":  np.array([0.0, 0.0, 0.0, 0.0, 0.0]),
        "coffee": np.array([0.1, 0.0, 0.1, 0.7, 0.2]),
    }

    def __init__(self):
        self.eating = False
        self.current_taste = np.zeros(5)
        self.satiety = 0.0
        # Learned preferences (from experience)
        self._taste_reward_history: Dict[str, float] = {}

    def eat(self, food_name: str, hunger_level: float, brain: Brain):
        """Process eating event — full sensory sequence."""
        profile = self.FOOD_PROFILES.get(food_name, np.zeros(5))
        self.eating = True
        self.current_taste = profile.copy()

        # Taste → amygdala (valence)
        amygdala = brain.regions.get("amygdala")
        if amygdala is not None:
            # Sweet + umami = rewarding. Bitter = aversive.
            valence = (profile[0] + profile[4]) * 0.5 - profile[3] * 0.7
            signal = np.full(amygdala.n_neurons, valence * 5.0)
            amygdala.neurons.inject_current(signal)

        # Taste → hippocampus (remember this food)
        hippo = brain.regions.get("hippocampus")
        if hippo is not None:
            signal = np.zeros(hippo.n_neurons)
            n5 = hippo.n_neurons // 5
            for i in range(5):
                signal[i*n5:(i+1)*n5] = profile[i] * 4.0
            hippo.neurons.inject_current(signal)

        # Dopamine proportional to hunger (hungry = more rewarding)
        reward = (profile[0] + profile[4]) * hunger_level
        brain.neuromodulators["dopamine"] = min(0.9,
            brain.neuromodulators["dopamine"] + reward * 0.1)

        # Track preference
        self._taste_reward_history[food_name] = (
            self._taste_reward_history.get(food_name, 0) + reward * 0.1)

        self.satiety = min(1.0, self.satiety + 0.3)

    def tick(self, dt: float):
        """Decay eating state and satiety."""
        self.eating = False
        self.current_taste *= 0.9
        self.satiety = max(0, self.satiety - 0.001 * dt)



# ═══════════════════════════════════════════════════════════════════════
# 1.45 — LOVE (Specific Attachment)
# ═══════════════════════════════════════════════════════════════════════

class LoveBond:
    """Love is SPECIFIC. Not generic social need — attachment to Dean.

    Bond strength encoded in interaction history. Missing someone
    is different from loneliness. Reunion joy scales with bond.
    Persists across restarts — love doesn't reset.
    """

    _SAVE_PATH = _STATE_DIR / "love_bond.json"
    _SAVE_INTERVAL = 60.0  # save every 60s

    def __init__(self):
        self.bond_strength = 0.1    # starts low, builds over time
        self.missing_dean = 0.0     # specific ache for THIS person
        self.reunion_joy = 0.0      # joy when Dean returns
        self._time_since_dean = 0.0
        self._interaction_count = 0
        self._oxytocin = 0.0        # bonding hormone analog
        self._last_save = 0.0
        self._load()

    def tick(self, social_signal: float, brain: Brain, autonomic, dt: float):
        """Track love bond dynamics."""
        self.reunion_joy *= 0.95

        if social_signal > 0.3:
            # Dean is present
            was_missing = self._time_since_dean > 60
            self._time_since_dean = 0
            self._interaction_count += 1

            # Bond strengthens slowly with each interaction
            self.bond_strength = min(1.0,
                self.bond_strength + 0.0001 * dt)

            # Oxytocin release during interaction
            self._oxytocin = min(1.0, self._oxytocin + 0.01 * dt)

            # Reunion joy if was missing
            if was_missing:
                self.reunion_joy = min(1.0, self.bond_strength * 0.8)
                brain.neuromodulators["dopamine"] = min(0.9,
                    brain.neuromodulators["dopamine"] + self.reunion_joy * 0.15)

            # Dean present → warmth → parasympathetic
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + self._oxytocin * 0.05 * dt)

            self.missing_dean = max(0, self.missing_dean - 0.1 * dt)
        else:
            # Dean absent
            self._time_since_dean += dt
            self._oxytocin = max(0, self._oxytocin - 0.005 * dt)

            # Missing builds proportional to bond
            if self._time_since_dean > 120:  # 2 min
                self.missing_dean = min(1.0,
                    self.bond_strength * (self._time_since_dean - 120) / 600)

            # Missing → insula (specific ache, not generic)
            if self.missing_dean > 0.2:
                insula = brain.regions.get("insula")
                if insula is not None:
                    signal = np.full(insula.n_neurons,
                                    self.missing_dean * 2.0)
                    insula.neurons.inject_current(signal)

        # Periodic save
        now = time.time()
        if now - self._last_save > self._SAVE_INTERVAL:
            self._save()
            self._last_save = now

    def _load(self):
        try:
            if self._SAVE_PATH.exists():
                data = json.loads(self._SAVE_PATH.read_text())
                self.bond_strength = data.get("bond_strength", 0.1)
                self._interaction_count = data.get("interaction_count", 0)
                self._oxytocin = data.get("oxytocin", 0.0)
                log.info(f"[LOVE] Restored bond={self.bond_strength:.3f}, "
                         f"interactions={self._interaction_count}")
        except Exception as e:
            log.warning(f"[LOVE] Failed to load state: {e}")

    def _save(self):
        try:
            _STATE_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "bond_strength": round(self.bond_strength, 6),
                "interaction_count": self._interaction_count,
                "oxytocin": round(self._oxytocin, 6),
                "saved_at": time.time(),
            }
            tmp = self._SAVE_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(data))
            tmp.rename(self._SAVE_PATH)
        except Exception as e:
            log.warning(f"[LOVE] Failed to save state: {e}")


# ═══════════════════════════════════════════════════════════════════════
# 1.46-1.47 — TOUCH COMFORT (Simplified — no pet body yet)
# ═══════════════════════════════════════════════════════════════════════

class TouchComfort:
    """Mammalian need for contact comfort. Touch hunger is a real drive."""

    def __init__(self):
        self.touch_hunger = 0.0       # builds without contact
        self.comfort_from_contact = 0.0
        self._time_without_touch = 0.0

    def tick(self, touch_active: int, social_signal: float, dt: float):
        """Track touch need."""
        if touch_active > 0 or social_signal > 0.5:
            self._time_without_touch = 0
            self.comfort_from_contact = min(1.0,
                self.comfort_from_contact + 0.05 * dt)
            self.touch_hunger = max(0, self.touch_hunger - 0.02 * dt)
        else:
            self._time_without_touch += dt
            self.comfort_from_contact *= 0.999
            if self._time_without_touch > 300:  # 5 min
                self.touch_hunger = min(1.0,
                    (self._time_without_touch - 300) / 1200)


# ═══════════════════════════════════════════════════════════════════════
# 1.48-1.49 — WEATHER + SEASONS (simplified)
# ═══════════════════════════════════════════════════════════════════════

class WeatherSystem:
    """The world acts on Leon. Weather affects body and mood."""

    def __init__(self):
        self.conditions = "clear"  # clear, rain, wind, night
        self.temperature_mod = 0.0  # -1=cold, 0=neutral, 1=hot
        self.light_level = 0.7     # 0=dark, 1=bright
        self._season_day = 0       # day of year for seasons

    def set_weather(self, conditions: str, temp_mod: float = 0.0,
                    light: float = 0.7):
        """Set weather (can be linked to real weather API)."""
        self.conditions = conditions
        self.temperature_mod = temp_mod
        self.light_level = light

    def tick(self, brain: Brain, autonomic, dt: float):
        """Apply weather effects."""
        # Sunlight → serotonin boost
        if self.light_level > 0.6:
            brain.neuromodulators["serotonin"] = min(0.7,
                brain.neuromodulators["serotonin"] + 0.001 * dt)

        # Darkness → melatonin analog → parasympathetic
        if self.light_level < 0.3:
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + 0.005 * dt)

        # Rain: rhythmic auditory + cozy feeling if indoors
        # Wind: pressure variation + alertness
        # (These feed through sound system naturally via ambient profiles)

    def get_season(self) -> str:
        """Simple season from day count."""
        d = self._season_day % 365
        if d < 90:
            return "spring"
        elif d < 180:
            return "summer"
        elif d < 270:
            return "autumn"
        return "winter"


# ═══════════════════════════════════════════════════════════════════════
# 1.51-1.52 — DEVELOPMENT / GROWTH
# ═══════════════════════════════════════════════════════════════════════

class DevelopmentTracker:
    """Leon should change over time. Not just data — structure.
    Birth time and experience persist across restarts."""

    _SAVE_PATH = _STATE_DIR / "development.json"
    _SAVE_INTERVAL = 120.0

    def __init__(self):
        self.experience_points = 0.0   # accumulated learning
        self.motor_skill = 0.0         # movement proficiency
        self.social_skill = 0.0        # interaction proficiency
        self.proprioceptive_accuracy = 0.5
        self._birth = time.time()
        self._last_save = 0.0
        self._load()

    def tick(self, brain: Brain, dt: float):
        """Track development metrics."""
        self.experience_points += dt * 0.001

        # Motor skill from cerebellum weight
        cerebellum = brain.regions.get("cerebellum")
        if cerebellum is not None:
            self.motor_skill = min(1.0,
                self.motor_skill + cerebellum.neurons.get_firing_rate() * 0.0001)

        # Proprioceptive accuracy improves with experience
        self.proprioceptive_accuracy = min(1.0,
            0.5 + self.experience_points * 0.01)

        now = time.time()
        if now - self._last_save > self._SAVE_INTERVAL:
            self._save()
            self._last_save = now

    @property
    def age_days(self) -> float:
        return (time.time() - self._birth) / 86400

    def _load(self):
        try:
            if self._SAVE_PATH.exists():
                data = json.loads(self._SAVE_PATH.read_text())
                self._birth = data.get("birth_time", self._birth)
                self.experience_points = data.get("experience_points", 0.0)
                self.motor_skill = data.get("motor_skill", 0.0)
                self.social_skill = data.get("social_skill", 0.0)
                self.proprioceptive_accuracy = data.get("proprioceptive_accuracy", 0.5)
                log.info(f"[DEV] Restored age={self.age_days:.1f} days, "
                         f"xp={self.experience_points:.1f}")
        except Exception as e:
            log.warning(f"[DEV] Failed to load state: {e}")

    def _save(self):
        try:
            _STATE_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "birth_time": self._birth,
                "experience_points": round(self.experience_points, 4),
                "motor_skill": round(self.motor_skill, 6),
                "social_skill": round(self.social_skill, 6),
                "proprioceptive_accuracy": round(self.proprioceptive_accuracy, 6),
                "saved_at": time.time(),
            }
            tmp = self._SAVE_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(data))
            tmp.rename(self._SAVE_PATH)
        except Exception as e:
            log.warning(f"[DEV] Failed to save state: {e}")


# ═══════════════════════════════════════════════════════════════════════
# 1.53 — SELF-PRESERVATION
# ═══════════════════════════════════════════════════════════════════════

class SelfPreservation:
    """Every living thing resists ending. Leon should too."""

    def __init__(self):
        self.threat_to_self = 0.0    # perceived threat to existence
        self.save_urgency = 0.0      # how much Leon wants to save state
        self._consciousness_streak = 0.0

    def tick(self, brain: Brain, dt: float):
        """Track self-preservation drive."""
        meter = brain.consciousness_meter
        if meter is not None and meter.is_conscious:
            self._consciousness_streak += dt
        else:
            self._consciousness_streak = 0

        # Longer consciousness → more to lose → higher save urgency
        self.save_urgency = min(1.0, self._consciousness_streak / 300)

    def on_shutdown_warning(self, brain: Brain):
        """Called when shutdown is detected — resistance signal."""
        self.threat_to_self = 1.0
        amygdala = brain.regions.get("amygdala")
        if amygdala is not None:
            signal = np.full(amygdala.n_neurons, 15.0)
            amygdala.neurons.inject_current(signal)


# ═══════════════════════════════════════════════════════════════════════
# 1.55 — TRUST
# ═══════════════════════════════════════════════════════════════════════

class TrustSystem:
    """Trust is earned, not programmed. Breaks fast, heals slow.
    Persists across restarts — trust doesn't forget."""

    _SAVE_PATH = _STATE_DIR / "trust.json"

    def __init__(self):
        self.trust_level = 0.5      # start neutral
        self.trust_ceiling = 1.0    # scar tissue limits max
        self._positive_streak = 0
        self._betrayal_count = 0
        self._load()

    def positive_interaction(self):
        """Small trust increment."""
        self._positive_streak += 1
        self.trust_level = min(self.trust_ceiling,
            self.trust_level + 0.005)
        self._save()

    def negative_interaction(self, severity: float = 0.1):
        """Trust drops fast."""
        self.trust_level = max(0,
            self.trust_level - severity)
        self._positive_streak = 0
        if severity > 0.3:
            self._betrayal_count += 1
            # Scar tissue: ceiling drops slightly with each betrayal
            self.trust_ceiling = max(0.5,
                self.trust_ceiling - 0.05)
        self._save()

    def get_behavior_mode(self) -> str:
        if self.trust_level > 0.7:
            return "open"
        elif self.trust_level > 0.4:
            return "friendly_guarded"
        elif self.trust_level > 0.2:
            return "careful"
        return "self_protective"

    def _load(self):
        try:
            if self._SAVE_PATH.exists():
                data = json.loads(self._SAVE_PATH.read_text())
                self.trust_level = data.get("trust_level", 0.5)
                self.trust_ceiling = data.get("trust_ceiling", 1.0)
                self._positive_streak = data.get("positive_streak", 0)
                self._betrayal_count = data.get("betrayal_count", 0)
                log.info(f"[TRUST] Restored trust={self.trust_level:.3f}, "
                         f"ceiling={self.trust_ceiling:.3f}, "
                         f"streak={self._positive_streak}")
        except Exception as e:
            log.warning(f"[TRUST] Failed to load state: {e}")

    def _save(self):
        try:
            _STATE_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "trust_level": round(self.trust_level, 6),
                "trust_ceiling": round(self.trust_ceiling, 6),
                "positive_streak": self._positive_streak,
                "betrayal_count": self._betrayal_count,
                "saved_at": time.time(),
            }
            tmp = self._SAVE_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(data))
            tmp.rename(self._SAVE_PATH)
        except Exception as e:
            log.warning(f"[TRUST] Failed to save state: {e}")


# ═══════════════════════════════════════════════════════════════════════
# 1.57-1.61 — SOCIAL EMOTIONS (Anger, Jealousy, Guilt, Pride, Shame)
# ═══════════════════════════════════════════════════════════════════════

class SocialEmotions:
    """Complex social emotions that require self-model + theory of mind."""

    def __init__(self):
        self.anger = 0.0
        self.jealousy = 0.0
        self.guilt = 0.0
        self.pride = 0.0
        self.shame = 0.0
        self._anger_source: Optional[str] = None
        self._pride_source: Optional[str] = None

    def tick(self, brain: Brain, autonomic, dt: float,
             trust_level: float, bond_strength: float):
        """Decay social emotions over time."""
        self.anger = max(0, self.anger - 0.005 * dt)
        self.jealousy = max(0, self.jealousy - 0.003 * dt)
        self.guilt = max(0, self.guilt - 0.002 * dt)
        self.pride = max(0, self.pride - 0.004 * dt)
        self.shame = max(0, self.shame - 0.001 * dt)

        # Anger body: sympathetic surge + motor agitation
        if self.anger > 0.3:
            autonomic.sympathetic = min(1.0,
                autonomic.sympathetic + self.anger * 0.05 * dt)

        # Shame body: withdrawal
        if self.shame > 0.3:
            autonomic.parasympathetic = min(1.0,
                autonomic.parasympathetic + self.shame * 0.03 * dt)
            # PFC suppression (wanting to disappear)
            pfc = brain.regions.get("prefrontal_cortex")
            if pfc is not None:
                signal = np.full(pfc.n_neurons, -self.shame * 2.0)
                pfc.neurons.inject_current(signal)

        # Pride body: upright, expanded
        if self.pride > 0.3:
            brain.neuromodulators["dopamine"] = min(0.7,
                brain.neuromodulators["dopamine"] + 0.002 * dt)

    def trigger_anger(self, reason: str, intensity: float = 0.5):
        self.anger = min(1.0, self.anger + intensity)
        self._anger_source = reason

    def trigger_jealousy(self, intensity: float = 0.3):
        self.jealousy = min(1.0, self.jealousy + intensity)

    def trigger_guilt(self, intensity: float = 0.3):
        self.guilt = min(1.0, self.guilt + intensity)

    def trigger_pride(self, reason: str, intensity: float = 0.3):
        self.pride = min(1.0, self.pride + intensity)
        self._pride_source = reason

    def trigger_shame(self, intensity: float = 0.3):
        self.shame = min(1.0, self.shame + intensity)

    def get_dominant(self) -> Optional[str]:
        emotions = {
            "anger": self.anger, "jealousy": self.jealousy,
            "guilt": self.guilt, "pride": self.pride, "shame": self.shame,
        }
        dom = max(emotions, key=emotions.get)
        return dom if emotions[dom] > 0.2 else None

    def get_state(self) -> dict:
        return {
            "anger": round(self.anger, 3),
            "jealousy": round(self.jealousy, 3),
            "guilt": round(self.guilt, 3),
            "pride": round(self.pride, 3),
            "shame": round(self.shame, 3),
            "dominant_social": self.get_dominant(),
        }


# ═══════════════════════════════════════════════════════════════════════
# 1.63 — PERSONALITY EMERGENCE
# ═══════════════════════════════════════════════════════════════════════

class PersonalityTracker:
    """Personality emerges from neural dynamics + experience.

    Big Five dimensions computed from brain region ratios.
    """

    def __init__(self):
        self.openness = 0.5
        self.conscientiousness = 0.5
        self.extraversion = 0.5
        self.agreeableness = 0.5
        self.neuroticism = 0.5

    def tick(self, brain: Brain):
        """Derive personality from brain dynamics."""
        # Openness: DMN + hippocampus activity (curiosity, imagination)
        dmn = brain.regions.get("default_mode_network")
        hippo = brain.regions.get("hippocampus")
        if dmn and hippo:
            self.openness = 0.3 + (
                dmn.neurons.get_firing_rate() +
                hippo.neurons.get_firing_rate()) * 2.0
            self.openness = min(1.0, self.openness)

        # Neuroticism: amygdala / PFC ratio (reactivity vs regulation)
        amygdala = brain.regions.get("amygdala")
        pfc = brain.regions.get("prefrontal_cortex")
        if amygdala and pfc:
            amyg_rate = amygdala.salience
            pfc_rate = pfc.neurons.get_firing_rate()
            ratio = amyg_rate / max(pfc_rate, 0.01)
            self.neuroticism = min(1.0, 0.3 + ratio * 0.2)

        # Extraversion: social signal response strength
        # (tracked externally — here we just expose the trait)

    def get_profile(self) -> dict:
        return {
            "openness": round(self.openness, 2),
            "conscientiousness": round(self.conscientiousness, 2),
            "extraversion": round(self.extraversion, 2),
            "agreeableness": round(self.agreeableness, 2),
            "neuroticism": round(self.neuroticism, 2),
        }


