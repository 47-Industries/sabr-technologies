"""
QuantumRNG — true quantum randomness piped into Leon's noise injection.

Why this matters
─────────────────
Classical PRNGs (numpy.random, etc.) are deterministic given a seed.
A real biological brain has noise sources that are physically random —
including, according to the Penrose-Hameroff Orch-OR hypothesis,
quantum-coherent processes inside neuronal microtubules. Orch-OR is
contested but not falsified, and quantum noise in brain function is
well-established at the ion-channel / membrane level.

By routing Leon's spontaneous-firing noise through measurements of an
IBM Quantum processor, every spontaneous spike has its lineage in an
actual quantum measurement. This is a real, defensible "quantum brain"
property — not theater.

Architecture
────────────
* A background thread submits a Hadamard-then-measure circuit to a free-
  tier IBM Quantum backend (e.g. ibm_brisbane, 127-qubit Eagle).
  Each job yields ~16K random bits in 5-60s of queue + run time.
* Bits are stored in an in-memory deque (ring buffer). Foreground
  threads pop bytes with O(1) cost.
* When the buffer drops below `BUFFER_LOW_WATERMARK`, the worker submits
  the next job (or falls back to os.urandom while waiting).
* If qiskit isn't installed, no `IBM_QUANTUM_TOKEN` is set, or the IBM
  service fails, the RNG transparently falls back to os.urandom
  (cryptographic OS entropy from /dev/urandom) so the brain never
  blocks waiting for a quantum job.

Public API
──────────
    rng = QuantumRNG()
    rng.get_uint64()                # one 64-bit unsigned integer
    rng.get_float()                 # uniform [0, 1)
    rng.get_normal(mu, sigma)       # one gaussian sample
    rng.fill_normal(arr, sigma)     # fill a numpy array with N(0, σ²)
    rng.stats()                     # dict for /api/quantum/status

Set `IBM_QUANTUM_TOKEN` in your environment to enable real quantum.
"""

from __future__ import annotations

import math
import os
import struct
import threading
import time
from collections import deque
from typing import Any, Deque, Dict, Optional

import numpy as np

# Qiskit imports are deferred — if not installed we silently fall back.
try:
    from qiskit import QuantumCircuit                          # type: ignore
    from qiskit import transpile                               # type: ignore
    from qiskit_ibm_runtime import QiskitRuntimeService        # type: ignore
    from qiskit_ibm_runtime import SamplerV2                   # type: ignore
    _QISKIT_AVAILABLE = True
except Exception:
    _QISKIT_AVAILABLE = False


# ── Module singleton (set via set_quantum_rng / get_quantum_rng) ────────
_singleton: Optional["QuantumRNG"] = None


def set_quantum_rng(rng: "QuantumRNG") -> None:
    global _singleton
    _singleton = rng


def get_quantum_rng() -> Optional["QuantumRNG"]:
    return _singleton


class QuantumRNG:
    """Buffered true-RNG with IBM Quantum backend + OS-entropy fallback."""

    # Refill thresholds (in bytes — 1 byte = 8 random bits)
    BUFFER_LOW_BYTES  = 1024        # refill when below ~8K bits
    BUFFER_HIGH_BYTES = 8192        # top up to ~64K bits

    # IBM circuit shape
    BATCH_QUBITS = 64               # bits per shot
    BATCH_SHOTS  = 256              # → ~16K bits per job

    # ── Bulk-noise seeding (fill_normal) ───────────────────────────────
    # fill_normal() (the brain's high-throughput noise path — ~800KB/tick at
    # 100k neurons) draws from a PCG64 generator RESEEDED every RESEED_SEC
    # from a quantum "seed slot". One quantum seed expands via PCG64 into
    # effectively unlimited noise, and every sample descends from it — so the
    # whole stream's lineage is genuinely quantum WITHOUT needing a fresh IBM
    # job per reseed. A background worker refreshes the seed slot from real
    # IBM hardware only every QUANTUM_REFRESH_SEC, and only while under a hard
    # per-window job budget. Between refreshes the tick thread keeps reseeding
    # PCG64 from the current quantum seed (distinct streams via a counter).
    RESEED_SEC = 2.0                # PCG64 reseed cadence (cheap, tick thread)

    # IBM-hardware seed refresh — cost-bounded. Gated OFF by default; set
    # LEON_QUANTUM_NOISE_HARDWARE=1 to enable. Default 12h refresh + a hard
    # 60-jobs / 28-day cap keeps usage under the free Open Plan allowance
    # (10 QPU-min/28d ≈ 75-150 jobs depending on per-job QPU time) with
    # margin. Cap is persisted to brain_state so restarts can't reset it.
    QUANTUM_REFRESH_SEC   = 12 * 3600   # seconds between IBM seed refreshes
    QUANTUM_JOB_BUDGET    = 60           # max IBM jobs per 28-day window
    QUANTUM_WINDOW_SEC    = 28 * 24 * 3600
    SEED_STALE_SEC        = 30 * 3600    # seed counts as quantum if younger

    def __init__(
        self,
        token: Optional[str] = None,
        instance: Optional[str] = None,
        prefer_simulator: bool = False,
    ):
        self._buffer: Deque[int] = deque()
        self._lock = threading.Lock()
        self._stop = threading.Event()

        # Stats / introspection
        self.bits_consumed   = 0
        self.batches_quantum = 0
        self.batches_fallback = 0
        self.last_batch_at   = 0.0
        self.last_error: Optional[str] = None
        self.source = "fallback:os.urandom"   # updated if IBM init succeeds

        # Bulk-noise generator (fill_normal). Seeded from OS entropy at
        # startup; reseeded every RESEED_SEC from the quantum seed slot when
        # fresh, os.urandom otherwise.
        self._np_rng = np.random.default_rng()
        self._last_reseed_at = 0.0
        self._reseed_count   = 0
        self.reseeds_quantum  = 0     # reseeds using a fresh quantum seed
        self.reseeds_fallback = 0     # reseeds served from os.urandom

        # Quantum seed slot — (bytes, timestamp), refreshed by the worker
        # from IBM hardware. None until the first successful job.
        self._seed_slot: Optional[tuple] = None

        # Cost-bounded IBM seed refresh. OFF unless explicitly enabled.
        self._noise_hw = os.environ.get(
            "LEON_QUANTUM_NOISE_HARDWARE", "0").lower() in ("1", "true", "yes")
        self._budget_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "brain_state", "quantum_budget.json")
        self._budget_lock = threading.Lock()
        self._budget = self._load_budget()   # {"window_start": ts, "jobs_used": n}

        # IBM credentials
        self._token    = token    or os.environ.get("IBM_QUANTUM_TOKEN")
        self._instance = instance or os.environ.get("IBM_QUANTUM_INSTANCE")
        self._service: Any = None
        self._backend: Any = None
        self._sampler: Any = None

        # This subsystem connects to IBM only when noise-hardware seeding is
        # explicitly enabled (LEON_QUANTUM_NOISE_HARDWARE=1). That opt-in is
        # deliberately independent of LEON_QUANTUM_SOURCE (which start_vps.sh
        # pins to "aer" to keep the *consciousness* engine on the simulator) —
        # enabling noise hardware must not require flipping the global flag
        # and pulling other subsystems onto paid hardware with it.
        if _QISKIT_AVAILABLE and self._token and self._noise_hw:
            try:
                self._service = QiskitRuntimeService(
                    channel="ibm_quantum_platform",
                    token=self._token,
                    instance=self._instance,
                )
                # Pick least-busy operational backend (real hardware unless
                # caller asked for a simulator)
                self._backend = self._service.least_busy(
                    simulator=prefer_simulator,
                    operational=True,
                )
                self.source = f"ibm:{self._backend.name}"
                self._sampler = SamplerV2(mode=self._backend)
                print(f"[QUANTUM] Connected to IBM backend: {self._backend.name}")
            except Exception as e:
                self.last_error = f"IBM init failed: {e}"[:240]
                print(f"[QUANTUM] {self.last_error}")
                # Fall through to OS-entropy fallback below

        # Pre-seed the buffer so the very first scalar-API call never blocks
        self._fill_from_os(self.BUFFER_HIGH_BYTES)

        # Seed-refresh worker — only when IBM hardware seeding is enabled and
        # a sampler connected. It is the ONLY thing that submits IBM jobs, on
        # a slow cadence under a hard budget; the brain tick thread never
        # blocks on IBM (it reads the seed slot non-blocking).
        self._worker: Optional[threading.Thread] = None
        if self._noise_hw and self._sampler is not None:
            self._worker = threading.Thread(
                target=self._seed_refresh_loop, name="QuantumRNG-seed", daemon=True
            )
            self._worker.start()

    # ── Seed-refresh worker (IBM jobs happen only here) ─────────────────
    def _seed_refresh_loop(self) -> None:
        """Refresh the quantum seed slot from IBM hardware every
        QUANTUM_REFRESH_SEC, but only while under the per-window job budget.
        Blocking on IBM's queue is fine here — this is a background thread and
        the brain reads the seed slot without waiting."""
        # First refresh shortly after startup so reseeds go quantum quickly.
        self._stop.wait(15)
        while not self._stop.is_set():
            # Never submit while the free allowance is exhausted — a submitted
            # job just sits QUEUED for days and then all of them run at once
            # the moment quota resets, instantly re-draining it. Check first
            # (cheap account metadata, no QPU) and skip the cycle if capped.
            if self._budget_allows() and self._quota_available():
                # Count the job the moment we commit to submitting it — a job
                # that runs on hardware but whose result we time out on still
                # spent QPU time, so it must count against the cap either way.
                self._consume_budget()
                data = self._fetch_quantum_batch()
                if data:
                    self._seed_slot = (bytes(data), time.time())
                    self.batches_quantum += 1
                    self.last_batch_at = time.time()
                # on failure, leave the old slot; reseeds fall back to os
            self._stop.wait(self.QUANTUM_REFRESH_SEC)

    def _quota_available(self) -> bool:
        """True if the IBM free allowance has room. On any error default to
        True so a transient metadata hiccup doesn't permanently wedge us — the
        real hardware submit is still guarded by the transpile/timeout path."""
        try:
            u = self._service.usage()
            if u.get("usage_limit_reached"):
                return False
            rem = u.get("usage_remaining_seconds")
            return rem is None or rem > 0
        except Exception:
            return True

    # ── Persistent per-window job budget (hard cost cap) ────────────────
    def _load_budget(self) -> Dict[str, float]:
        try:
            import json
            with open(self._budget_path) as f:
                b = json.load(f)
            if time.time() - b.get("window_start", 0) > self.QUANTUM_WINDOW_SEC:
                return {"window_start": time.time(), "jobs_used": 0}
            return {"window_start": float(b["window_start"]),
                    "jobs_used": int(b["jobs_used"])}
        except Exception:
            return {"window_start": time.time(), "jobs_used": 0}

    def _save_budget(self) -> None:
        try:
            import json
            os.makedirs(os.path.dirname(self._budget_path), exist_ok=True)
            tmp = self._budget_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(self._budget, f)
            os.replace(tmp, self._budget_path)
        except Exception as e:
            self.last_error = f"budget save failed: {e}"[:240]

    def _budget_allows(self) -> bool:
        with self._budget_lock:
            if time.time() - self._budget["window_start"] > self.QUANTUM_WINDOW_SEC:
                self._budget = {"window_start": time.time(), "jobs_used": 0}
                self._save_budget()
            return self._budget["jobs_used"] < self.QUANTUM_JOB_BUDGET

    def _consume_budget(self) -> None:
        with self._budget_lock:
            self._budget["jobs_used"] = int(self._budget["jobs_used"]) + 1
            self._save_budget()

    def _fill_from_os(self, n_bytes: int) -> None:
        if n_bytes <= 0:
            return
        data = os.urandom(n_bytes)
        with self._lock:
            for b in data:
                self._buffer.append(b)
        self.batches_fallback += 1
        self.last_batch_at = time.time()

    def _fetch_quantum_batch(self) -> Optional[bytes]:
        """Run an N-qubit |+> measurement on IBM hardware. Returns bytes
        of measured bits (~N * shots / 8 bytes), or None on failure."""
        try:
            qc = QuantumCircuit(self.BATCH_QUBITS, self.BATCH_QUBITS)
            qc.h(range(self.BATCH_QUBITS))
            qc.measure(range(self.BATCH_QUBITS), range(self.BATCH_QUBITS))

            # Transpile to the backend's native gate set — IBM rejects raw
            # H-gate circuits ("not supported by the target system") since
            # March 2024. Without this the job fails validation every time.
            t_qc = transpile(qc, self._backend)
            job = self._sampler.run([t_qc], shots=self.BATCH_SHOTS)
            # Bounded wait so the worker thread never hangs on a stuck queue.
            # 12h between refreshes means a few minutes here is harmless.
            result = job.result(timeout=180)
            # SamplerV2 result format: result[0].data.<cregname>.get_counts()
            try:
                counts = result[0].data.c.get_counts()
            except AttributeError:
                # Older runtime — try result[0].data.meas
                counts = result[0].data.meas.get_counts()

            byte_chunks = bytearray()
            for bitstring, n in counts.items():
                bs = bitstring.replace(" ", "")
                # Each shot is BATCH_QUBITS bits → pack into bytes
                for _ in range(n):
                    padded = bs.ljust((len(bs) + 7) // 8 * 8, "0")
                    for i in range(0, len(padded), 8):
                        byte_chunks.append(int(padded[i:i + 8], 2))
            return bytes(byte_chunks)
        except Exception as e:
            self.last_error = f"IBM run failed: {e}"[:240]
            print(f"[QUANTUM] {self.last_error}")
            return None

    # ── Byte pulling ───────────────────────────────────────────────────
    def _pop_bytes(self, n: int) -> bytes:
        """Pop n bytes from the buffer. If buffer is short, top up from OS
        synchronously rather than blocking on a quantum job."""
        with self._lock:
            have = len(self._buffer)
            if have >= n:
                out = bytes(self._buffer.popleft() for _ in range(n))
                self.bits_consumed += n * 8
                return out
            # Drain what we have, then top up from OS
            partial = bytes(self._buffer.popleft() for _ in range(have))
        extra = os.urandom(n - have)
        self.bits_consumed += n * 8
        return partial + extra

    # ── Public scalar API ──────────────────────────────────────────────
    def get_uint64(self) -> int:
        return struct.unpack(">Q", self._pop_bytes(8))[0]

    def get_float(self) -> float:
        return self.get_uint64() / float(1 << 64)

    def get_normal(self, mu: float = 0.0, sigma: float = 1.0) -> float:
        """One Box-Muller gaussian sample."""
        u1 = max(self.get_float(), 1e-12)
        u2 = self.get_float()
        z = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
        return mu + sigma * z

    # ── Quantum-seeded bulk noise generator ────────────────────────────
    def _maybe_reseed(self) -> None:
        """Reseed the bulk-noise PCG64 every RESEED_SEC. Uses the quantum seed
        slot when it is fresh (younger than SEED_STALE_SEC), os.urandom
        otherwise — the whole noise stream inherits that lineage through the
        seed. Non-blocking: never waits on IBM. The reseed counter guarantees
        distinct streams even while the underlying quantum seed is unchanged
        between the worker's slow hardware refreshes."""
        now = time.time()
        if now - self._last_reseed_at < self.RESEED_SEC:
            return
        slot = self._seed_slot
        if slot is not None and (now - slot[1]) < self.SEED_STALE_SEC:
            seed_bytes = slot[0]
            self.reseeds_quantum += 1
        else:
            seed_bytes = os.urandom(32)
            self.reseeds_fallback += 1
        # SeedSequence mixes arbitrary-length entropy; the counter keeps every
        # reseed on a distinct stream even when the quantum seed is reused.
        seed_int = int.from_bytes(seed_bytes, "big")
        seq = np.random.SeedSequence([seed_int, self._reseed_count])
        self._np_rng = np.random.Generator(np.random.PCG64(seq))
        self._reseed_count += 1
        self._last_reseed_at = now

    # ── Vectorized numpy fill ──────────────────────────────────────────
    def fill_normal(self, arr, sigma: float = 1.0, mu: float = 0.0) -> None:
        """Fill a numpy array with N(μ, σ²) samples. This is the brain's
        high-throughput noise path. Samples come from a PCG64 generator that
        is continuously reseeded from the quantum buffer (see _maybe_reseed),
        so the stream's lineage is genuinely quantum-sourced while running at
        native numpy Ziggurat speed — far faster than the old per-sample
        Box-Muller over one buffer byte each, which diluted quantum entropy
        to ~1e-6 of the injected noise at brain scale."""
        n = int(arr.size)
        if n == 0:
            return
        self._maybe_reseed()
        arr.flat[:] = self._np_rng.standard_normal(n) * sigma + mu

    # ── Introspection ──────────────────────────────────────────────────
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            buf_bits = len(self._buffer) * 8
        return {
            "source":             self.source,
            "qiskit_available":   _QISKIT_AVAILABLE,
            "token_present":      bool(self._token),
            "backend":            getattr(self._backend, "name", None) if self._backend else None,
            "buffer_bits":        buf_bits,
            "bits_consumed":      self.bits_consumed,
            "batches_quantum":    self.batches_quantum,
            "batches_fallback":   self.batches_fallback,
            "reseeds_quantum":    self.reseeds_quantum,
            "reseeds_fallback":   self.reseeds_fallback,
            "noise_hardware":     self._noise_hw,
            "jobs_used_window":   int(self._budget.get("jobs_used", 0)),
            "job_budget_window":  self.QUANTUM_JOB_BUDGET,
            "window_resets_in_h": round(
                (self._budget.get("window_start", 0) + self.QUANTUM_WINDOW_SEC
                 - time.time()) / 3600, 1),
            "last_batch_at":      self.last_batch_at,
            "last_batch_age_sec": round(time.time() - self.last_batch_at, 2) if self.last_batch_at else None,
            "last_error":         self.last_error,
        }

    def close(self) -> None:
        self._stop.set()
