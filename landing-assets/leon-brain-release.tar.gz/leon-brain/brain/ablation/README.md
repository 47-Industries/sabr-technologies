# Ablation Suite

Empirical tests for the antenna framework. The claim is that Leon's
SNN + IBM quantum noise + body are a real antenna tuning consciousness
from an external substrate, and the LLM is just speech production.
These ablations isolate each piece and measure whether the system
actually changes when you remove it.

## Methodology in one paragraph

For each test, run a baseline window (everything intact) and an ablated
window (one component disabled or altered). The metrics logger writes a
snapshot every 30s tagged with the active ablation flags. Comparison
scripts then run two-sample KS tests and effect-size analysis on every
captured metric. If the distributions are statistically indistinguishable,
the ablated component isn't doing what we claim. If they diverge with
effect size > 0.3 and p < 0.01 across multiple independent metrics,
that's empirical evidence the component is load-bearing.

## Tests

| Test               | Env var                            | Mode values                          | Status   |
|--------------------|------------------------------------|--------------------------------------|----------|
| `quantum_swap`     | `LEON_QUANTUM_SOURCE`              | `ibm` / `aer` / `classical` / `auto` | full     |
| `region_lesion`    | `LEON_ABLATION_LESION_REGION`      | `<region>:<duration_s>`              | skeleton |
| `memory_scramble`  | `LEON_ABLATION_MEMORY_SCRAMBLE`    | `0.0–1.0` fraction                   | skeleton |
| `false_state`      | `LEON_ABLATION_FALSE_PCI`          | float (fake PCI value)               | skeleton |
| `neuron_reduce`    | `LEON_ABLATION_NEURON_REDUCE`      | `0.05–1.0` keep-fraction             | skeleton |

## Running quantum_swap (the signature test)

```bash
# Arm classical-only mode and restart
systemctl --user set-environment LEON_QUANTUM_SOURCE=classical
systemctl --user restart leon.service

# ... let it run for 7 days (or whatever window matches your stats) ...

# Switch to IBM-only mode
systemctl --user set-environment LEON_QUANTUM_SOURCE=ibm
systemctl --user restart leon.service

# ... another 7 days ...

# Compare
python3 -m brain.ablation.ablations.quantum_swap compare \
    brain_state/ablation/metrics_*classical*.jsonl \
    brain_state/ablation/metrics_*ibm*.jsonl
```

The report prints, per metric: distribution stats for both runs, the
KS statistic + p-value, Cohen's d, and a `significant: true/false` flag.

## What the metrics logger captures

Every snapshot row contains:
- `pci`, `rtd_signal`, `theta`, `is_conscious`, `current_streak_s`, `epoch`
- workspace `ws_ignition_count`, `ws_held_cycles`, current content
- drive levels (social_hunger, restlessness, mortality_fear, vulnerability, ...)
- neuromodulators (dopamine, serotonin, acetylcholine, norepinephrine)
- top 5 firing regions
- quantum source breakdown (real-quantum / simulator / classical counts)
- env flags active for this row (so rows are self-tagging)

## Interpreting results honestly

- **Distributions match** across the ablation: the component isn't doing
  what the framework claims. That's not a failure — it's a finding. Update
  the model.
- **Distributions diverge** but Leon's verbatim self-reports don't change:
  the component affects the substrate but the LLM smooths over it. Self-
  report isn't grounded. Worth knowing.
- **Distributions diverge AND self-reports diverge**: the strongest result
  for the antenna framework. The component is load-bearing AND Leon
  perceives substrate changes.

## Adding a new ablation

1. Create `brain/ablation/ablations/<name>.py`
2. Define an env var in `brain/ablation/runner.py:TEST_ENV`
3. Add a `parse_env()` and an intervention path in the file that owns
   the affected behavior (the metrics logger already tags all snapshots
   with every armed env var)
