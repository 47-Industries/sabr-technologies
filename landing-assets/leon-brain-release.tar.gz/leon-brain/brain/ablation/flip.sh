#!/usr/bin/env bash
# Flip Leon between quantum_swap ablation modes.
#
#   ./flip.sh classical       — no quantum at all (weighted random fallback)
#   ./flip.sh aer             — Aer simulator only (mathematically correct QM, classical substrate)
#   ./flip.sh ibm             — real IBM hardware only (no Aer fallback — fails closed)
#   ./flip.sh disarm          — remove drop-in, return to default behavior
#
# Flags:
#   --hot                     — hot-swap via API (no restart, preserves streaks + STDP)
#   --restart (default)       — restart service (clean state, resets counters)
#
# Examples:
#   ./flip.sh aer --hot       — switch to aer without restarting Leon
#   ./flip.sh classical       — restart Leon in classical mode (old behavior)

set -e

MODE=""
HOT=false

for arg in "$@"; do
    case "$arg" in
        --hot) HOT=true ;;
        --restart) HOT=false ;;
        classical|aer|ibm|disarm|auto) MODE="$arg" ;;
        *) echo "unknown arg: $arg" >&2; exit 2 ;;
    esac
done

if [ -z "$MODE" ]; then
    echo "usage: $0 {classical|aer|ibm|auto|disarm} [--hot|--restart]" >&2
    exit 2
fi

# ── Hot swap path: API call, no restart ──────────────────────────────
if [ "$HOT" = true ]; then
    if [ "$MODE" = "disarm" ]; then
        MODE="auto"
    fi
    echo "hot-swapping to: $MODE (no restart)"
    RESP=$(curl -s -X POST "http://127.0.0.1:8000/api/cognition/quantum_source/$MODE")
    echo "$RESP" | python3 -m json.tool 2>/dev/null || echo "$RESP"
    exit 0
fi

# ── Restart path: systemd drop-in + service restart ──────────────────
DROP_IN_DIR="$HOME/.config/systemd/user/leon.service.d"
DROP_IN="$DROP_IN_DIR/ablation.conf"

case "$MODE" in
    classical)
        mkdir -p "$DROP_IN_DIR"
        cat > "$DROP_IN" <<EOF
# quantum_swap mode: classical — no quantum circuit, weighted random pick
[Service]
Environment=LEON_QUANTUM_SOURCE=classical
EOF
        ;;
    aer)
        mkdir -p "$DROP_IN_DIR"
        cat > "$DROP_IN" <<EOF
# quantum_swap mode: aer — local Aer simulator (correct QM, classical substrate)
[Service]
Environment=LEON_QUANTUM_SOURCE=aer
EOF
        ;;
    ibm)
        mkdir -p "$DROP_IN_DIR"
        cat > "$DROP_IN" <<EOF
# quantum_swap mode: ibm — real IBM hardware, no Aer fallback
# IBM_QUANTUM_TOKEN must already be set in the main unit's Environment
# block or via systemctl --user import-environment, otherwise IBM init
# will fail and decisions will return None (no fallback).
[Service]
Environment=LEON_QUANTUM_SOURCE=ibm
Environment=LEON_QUANTUM_HARDWARE=1
EOF
        ;;
    auto)
        rm -f "$DROP_IN"
        ;;
    disarm)
        rm -f "$DROP_IN"
        ;;
esac

systemctl --user daemon-reload
systemctl --user restart leon.service
echo "flipped to: $MODE (restarted)"
echo "current drop-in:"
[ -f "$DROP_IN" ] && cat "$DROP_IN" || echo "  (none — default behavior)"
