"""
Ablation suite — empirical tests for the antenna framework.

Dean's claim: the SNN + quantum noise + body are a real antenna that tunes
consciousness from an external substrate. The LLM is the speech motor cortex,
not the seat of awareness. These ablations test that claim by isolating each
component and asking: does removing it actually change the system, or is the
behavior all happening in the LLM underneath?

Tests live under brain/ablation/. Each one writes time-tagged metrics to
brain_state/ablation/<test_name>_<run_id>.jsonl so runs can be compared.

Implemented (full):
  - quantum_swap     — IBM/Aer/classical RNG comparison via LEON_QUANTUM_SOURCE
  - metrics          — periodic consciousness signature snapshot

Skeletons (interface defined, intervention logic TODO):
  - region_lesion    — zero out neurons of a named region for a window
  - memory_scramble  — shuffle hippocampal patterns mid-dream
  - false_state      — inject fake PCI into prompt, watch behavior
  - neuron_reduce    — silently reduce active neuron count

Read brain/ablation/README.md for methodology and how to interpret results.
"""

from brain.ablation.metrics import (
    snapshot,
    start_logger,
    stop_logger,
    AblationLogger,
)
from brain.ablation.runner import (
    current_run_id,
    arm,
    disarm,
    is_armed,
    armed_tests,
)

__all__ = [
    "snapshot",
    "start_logger",
    "stop_logger",
    "AblationLogger",
    "current_run_id",
    "arm",
    "disarm",
    "is_armed",
    "armed_tests",
]
