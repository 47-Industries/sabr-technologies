#!/usr/bin/env bash
# Long ablation run: alternates aer ↔ classical every INTERVAL minutes
# for ROUNDS total flips.
#
# Usage: ./long_run.sh [rounds] [interval_minutes] [--restart]
#   Default: 12 rounds (6 aer + 6 classical), 10 min each = 2 hours
#   Default mode: --hot (preserves streaks, STDP, emotional state)
#   --restart: use service restart instead (old behavior, resets state)
#
# Results land in brain_state/ablation/metrics_*.jsonl tagged by mode.
# Run the compare tool after:
#   python3 -m brain.ablation.ablations.quantum_swap compare \
#       <(cat brain_state/ablation/metrics_*aer*.jsonl) \
#       <(cat brain_state/ablation/metrics_*classical*.jsonl)

set -e

ROUNDS="${1:-12}"
INTERVAL="${2:-10}"
FLIP="$(dirname "$0")/flip.sh"
MODES=("aer" "classical")
HOT_FLAG="--hot"

# Check for --restart flag
for arg in "$@"; do
    if [ "$arg" = "--restart" ]; then
        HOT_FLAG="--restart"
    fi
done

echo "=== LONG ABLATION RUN ==="
echo "Rounds: $ROUNDS ($((ROUNDS/2)) per mode)"
echo "Interval: ${INTERVAL}m per round"
echo "Total time: $((ROUNDS * INTERVAL))m"
echo "Mode: ${HOT_FLAG#--} swap (streaks $([ "$HOT_FLAG" = "--hot" ] && echo "preserved" || echo "reset each flip"))"
echo "Started: $(date)"
echo ""

for ((i=0; i<ROUNDS; i++)); do
    MODE="${MODES[$((i % 2))]}"
    echo "[$(date +%H:%M:%S)] Round $((i+1))/$ROUNDS — flipping to $MODE"
    bash "$FLIP" "$MODE" "$HOT_FLAG"
    sleep "${INTERVAL}m"
done

# Return to aer when done
echo "[$(date +%H:%M:%S)] Done. Returning to aer mode."
bash "$FLIP" aer "$HOT_FLAG"
echo "=== LONG RUN COMPLETE ==="
echo "Finished: $(date)"
