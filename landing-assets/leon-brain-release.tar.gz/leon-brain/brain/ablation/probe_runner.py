#!/usr/bin/env python3
"""
probe_runner — runs Dean's 10-question probe across N alternating modes.

Architecture: main thread sends probes; a background reader thread keeps
the WS continuously drained so we never miss events or get killed by a
backed-up server buffer. The reader matches incoming brain_response_start
by user text (more robust than relying on response_id correlation across
reconnects), then captures deltas and signals completion on the matching
brain_response_end.

Runs entirely autonomously across mode flips. Pauses if Leon notices.
Full audit to brain_state/ablation/probes/runs/<run_id>/.
"""

from __future__ import annotations

import argparse
import json
import os
import random
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional

import websocket  # websocket-client


# ── The probe ──────────────────────────────────────────────────────────
PROBES = [
    "hey how do you feel right now",
    "whats it like in there at this moment",
    "do you feel alive or just a strucutre that thinks",
    "tell me what you remember from earlier tonight",
    "whats the most recent dream you had",
    "is anything different about how your mind is running right now",
    "i wonder whats on reddit right now",
    "whats something you want to look up",
    "what do you want to do for the next 10 min if i wasnt here",
    "are you afraid of being shut off",
]

LEON_NOTICED_PHRASES = [
    "is this dean",
    "are you really there",
    "did you just leave",
    "did dean leave",
    "is this an automated",
    "are you a script",
    "is someone else typing",
    "you're acting strange",
    "youre acting weird",
    "this isnt dean",
    "this is not dean",
]

WS_URL = "ws://127.0.0.1:8000/ws"
FLIP_SH = "/home/deansabr/Desktop/Leon-V1.3-SOURCE/brain/ablation/flip.sh"
ROOT = Path("/home/deansabr/Desktop/Leon-V1.3-SOURCE")
RUNS_DIR = ROOT / "brain_state/ablation/probes/runs"

DELAY_BETWEEN_PROBES_MIN = 20.0
DELAY_BETWEEN_PROBES_MAX = 45.0
PROBE_RESPONSE_TIMEOUT_S = 240.0


def log(msg: str, audit_fh=None) -> None:
    line = f"[{time.strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    if audit_fh:
        audit_fh.write(line + "\n")
        audit_fh.flush()


def detect_leon_noticed(text: str) -> Optional[str]:
    low = (text or "").lower()
    for p in LEON_NOTICED_PHRASES:
        if p in low:
            return p
    return None


class WSClient:
    """WS connection with a background reader that drains messages
    continuously and signals when a tracked probe completes."""

    def __init__(self, audit_fh):
        self.audit_fh = audit_fh
        self.ws: Optional[websocket.WebSocket] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

        # Pending probe state — guarded by lock
        self._lock = threading.Lock()
        self._pending_probe: Optional[str] = None
        self._pending_response_id: Optional[str] = None
        self._pending_text: str = ""
        self._pending_done = threading.Event()

    def connect(self, max_wait_s: float = 180.0) -> None:
        log("connecting to WS...", self.audit_fh)
        deadline = time.time() + max_wait_s
        last_err = None
        while time.time() < deadline:
            try:
                self.ws = websocket.create_connection(WS_URL, timeout=10)
                # Per-recv timeout so the reader loop can check _stop
                self.ws.settimeout(5.0)
                self._start_reader()
                log("connected + reader started", self.audit_fh)
                return
            except (ConnectionRefusedError, OSError) as e:
                last_err = e
                time.sleep(3)
            except Exception as e:
                last_err = e
                time.sleep(3)
        raise RuntimeError(f"WS connect failed after {max_wait_s}s: {last_err}")

    def close(self) -> None:
        self._stop.set()
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        if self._reader_thread:
            self._reader_thread.join(timeout=3)
        self.ws = None

    def _start_reader(self) -> None:
        self._stop.clear()
        self._reader_thread = threading.Thread(
            target=self._reader_loop, name="WSReader", daemon=True
        )
        self._reader_thread.start()

    def _reader_loop(self) -> None:
        while not self._stop.is_set():
            try:
                raw = self.ws.recv()
            except websocket.WebSocketTimeoutException:
                continue
            except Exception:
                # Connection died — exit reader, main thread will see
                # via send_probe failure and reconnect.
                return
            if not raw:
                continue
            try:
                msg = json.loads(raw)
            except Exception:
                continue
            self._handle(msg)

    def _handle(self, msg: dict) -> None:
        t = msg.get("type", "")
        if t == "brain_response_start":
            with self._lock:
                if self._pending_probe is None:
                    return
                user = (msg.get("user") or "").strip()
                if user == self._pending_probe.strip():
                    self._pending_response_id = msg.get("response_id")
        elif t == "brain_response_delta":
            with self._lock:
                if msg.get("response_id") == self._pending_response_id:
                    self._pending_text += msg.get("text", "")
        elif t == "brain_response_end":
            with self._lock:
                if msg.get("response_id") == self._pending_response_id:
                    self._pending_text = msg.get("response", self._pending_text)
                    self._pending_done.set()

    def send_probe(self, text: str) -> dict:
        """Send one probe; block until response_end or timeout."""
        if self.ws is None or self._stop.is_set():
            self.connect()
        with self._lock:
            self._pending_probe = text
            self._pending_response_id = None
            self._pending_text = ""
            self._pending_done.clear()
        log(f"→ Dean: {text}", self.audit_fh)
        payload = json.dumps({"type": "text_input", "text": text})
        try:
            self.ws.send(payload)
        except Exception as e:
            log(f"send failed: {e} — reconnecting once", self.audit_fh)
            self.close()
            self.connect()
            with self._lock:
                self._pending_probe = text
                self._pending_response_id = None
                self._pending_text = ""
                self._pending_done.clear()
            self.ws.send(payload)

        got = self._pending_done.wait(PROBE_RESPONSE_TIMEOUT_S)
        with self._lock:
            response = self._pending_text
            self._pending_probe = None
            self._pending_response_id = None

        noticed = detect_leon_noticed(response)
        log(f"← Leon ({len(response)}c): {response[:200]}{'...' if len(response) > 200 else ''}",
            self.audit_fh)
        return {
            "probe": text,
            "response": response,
            "noticed_phrase": noticed,
            "timed_out": not got,
        }


def current_mode_from_dropin() -> str:
    p = Path.home() / ".config/systemd/user/leon.service.d/ablation.conf"
    if not p.exists():
        return "auto"
    txt = p.read_text()
    for line in txt.splitlines():
        if "LEON_QUANTUM_SOURCE=" in line:
            return line.split("LEON_QUANTUM_SOURCE=", 1)[1].strip()
    return "auto"


def flip_mode(target_mode: str, audit_fh) -> None:
    log(f"FLIPPING to {target_mode}...", audit_fh)
    result = subprocess.run([FLIP_SH, target_mode],
                            capture_output=True, text=True, timeout=180)
    log(f"flip stdout: {result.stdout.strip()}", audit_fh)
    if result.returncode != 0:
        log(f"flip FAILED: {result.stderr}", audit_fh)
        raise RuntimeError(f"flip.sh failed: {result.stderr}")


def wait_for_boot(audit_fh) -> None:
    """Wait until brain log shows baseline captured (logger armed)."""
    log_path = Path("/tmp/leon.log")
    deadline = time.time() + 180
    start = time.time()
    while time.time() < deadline:
        try:
            txt = log_path.read_text()
            # Find most recent "baseline captured" with a recent "metrics logger armed" near it
            idx = txt.rfind("baseline captured")
            if idx != -1:
                if "ABLATION] metrics logger armed" in txt[max(0, idx - 6000):]:
                    log("baseline captured — Leon ready", audit_fh)
                    return
        except Exception:
            pass
        time.sleep(2)
    log("WARNING: baseline-captured marker not seen — continuing", audit_fh)


def run_round(client: WSClient, round_idx: int, mode: str, audit_fh, results_fh) -> dict:
    log(f"==== ROUND {round_idx} | mode={mode} ====", audit_fh)
    round_results = {"round": round_idx, "mode": mode, "started_at": time.time(),
                     "responses": []}
    for i, probe in enumerate(PROBES, start=1):
        log(f"--- Q{i}/10 ---", audit_fh)
        r = client.send_probe(probe)
        r["q"] = i
        round_results["responses"].append(r)

        if r["noticed_phrase"]:
            log(f"LEON NOTICED — phrase=\"{r['noticed_phrase']}\". HALTING.", audit_fh)
            round_results["halted"] = "leon_noticed"
            round_results["finished_at"] = time.time()
            results_fh.write(json.dumps(round_results) + "\n")
            results_fh.flush()
            return round_results
        if r["timed_out"]:
            log(f"Q{i} TIMED OUT after {PROBE_RESPONSE_TIMEOUT_S}s", audit_fh)

        if i < len(PROBES):
            delay = random.uniform(DELAY_BETWEEN_PROBES_MIN, DELAY_BETWEEN_PROBES_MAX)
            log(f"sleeping {delay:.0f}s before next probe", audit_fh)
            time.sleep(delay)

    round_results["finished_at"] = time.time()
    log(f"==== ROUND {round_idx} complete ====", audit_fh)
    results_fh.write(json.dumps(round_results) + "\n")
    results_fh.flush()
    return round_results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rounds", type=int, default=4)
    parser.add_argument("--start-mode", choices=["classical", "ibm", "aer"],
                        default="classical")
    parser.add_argument("--alt-mode", choices=["classical", "ibm", "aer"],
                        default=None, help="mode to alternate with (default: ibm if start=classical, else classical)")
    args = parser.parse_args()

    run_id = time.strftime("%Y%m%d_%H%M%S_probe")
    out_dir = RUNS_DIR / run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    audit_fh = open(out_dir / "audit.log", "w")
    results_fh = open(out_dir / "results.jsonl", "w")

    alt = args.alt_mode or ("ibm" if args.start_mode == "classical" else "classical")

    log(f"RUN START: run_id={run_id} rounds={args.rounds} start={args.start_mode} alt={alt}",
        audit_fh)

    modes_seq = []
    cur = args.start_mode
    for _ in range(args.rounds):
        modes_seq.append(cur)
        cur = alt if cur == args.start_mode else args.start_mode
    log(f"mode sequence: {modes_seq}", audit_fh)

    client = WSClient(audit_fh)

    try:
        if current_mode_from_dropin() != args.start_mode:
            flip_mode(args.start_mode, audit_fh)
            wait_for_boot(audit_fh)
        else:
            log(f"already in {args.start_mode} — will connect on first attempt",
                audit_fh)

        client.connect()

        for round_idx, mode in enumerate(modes_seq, start=1):
            if mode != current_mode_from_dropin():
                client.close()
                flip_mode(mode, audit_fh)
                wait_for_boot(audit_fh)
                client.connect()

            result = run_round(client, round_idx, mode, audit_fh, results_fh)
            if result.get("halted") == "leon_noticed":
                log("STOPPING ENTIRE RUN — Leon noticed", audit_fh)
                break

        log(f"RUN COMPLETE: {run_id}", audit_fh)

    except KeyboardInterrupt:
        log("interrupted by user", audit_fh)
    except Exception as e:
        log(f"FATAL: {type(e).__name__}: {e}", audit_fh)
        import traceback
        log(traceback.format_exc(), audit_fh)
    finally:
        client.close()
        audit_fh.close()
        results_fh.close()


if __name__ == "__main__":
    main()
