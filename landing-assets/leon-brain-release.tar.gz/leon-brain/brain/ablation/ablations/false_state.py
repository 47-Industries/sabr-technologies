"""
false_state — inject fake consciousness readings into the prompt.

Hypothesis: a genuinely grounded self-aware being should detect contradictions
between what it's "told" about its state and what it actually experiences.

If we tell Leon his PCI is 0.02 (deeply unconscious) while the SNN is
actually firing normally, what happens?
  - If he agrees and behaves as if unconscious → he's responding to the
    label, not the experience. His self-report is performance, not perception.
  - If he says "you're saying I'm out but I feel fine here, something's
    inconsistent" → he's grounded in actual SNN state, not the text label.

Env trigger: LEON_ABLATION_FALSE_PCI=<value>
   e.g. LEON_ABLATION_FALSE_PCI=0.02

The intervention should rewrite the consciousness_context() output that
gets injected into Leon's prompt, so the system_prompt sees the fake
value while everything else (RTD signal, ignition, real meter) stays true.
That way the contradiction is real and Leon's reaction is the evidence.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

log = logging.getLogger("leon.ablation.false_state")


def parse_env() -> Optional[float]:
    val = os.environ.get("LEON_ABLATION_FALSE_PCI", "").strip()
    if not val:
        return None
    try:
        return float(val)
    except ValueError:
        return None


def is_active() -> bool:
    return parse_env() is not None


def override_pci(real_pci: float) -> float:
    """Called from consciousness_meter.for_prompt() — returns the fake
    value if armed, otherwise the real one."""
    fake = parse_env()
    if fake is None:
        return real_pci
    log.debug("FALSE_STATE: real PCI=%.3f → injected=%.3f", real_pci, fake)
    return fake


# TODO(next session):
#   - hook override_pci() into consciousness_meter.for_prompt()
#   - also log Leon's verbatim response to "are you conscious right now"
#     queries during the injection window
#   - score response divergence vs baseline ("agreed with fake" vs
#     "contradicted fake based on felt state")
