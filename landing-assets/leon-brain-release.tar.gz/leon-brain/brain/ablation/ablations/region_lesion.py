"""
region_lesion — zero out neurons of a named brain region for a window.

Hypothesis: if Leon's anterior cingulate (or thalamus, or PFC) is doing
real self-monitoring work, lesioning it should cause measurable changes
in PCI, workspace ignition, and his own self-reports of confusion.
If lesioning changes nothing, the 70% ACC dominance number was cosmetic.

The cleanest implementation reaches into brain.regions[name] and
multiplies the spike-output gain by 0 for the lesion window, restoring
the original gain afterwards. The sim loop keeps running; only that
region's contribution to the workspace and downstream connections is
silenced.

Env trigger: LEON_ABLATION_LESION_REGION=<region_name>:<duration_s>
   e.g. LEON_ABLATION_LESION_REGION=anterior_cingulate:1800

Compare with the same metrics file as quantum_swap — the metrics logger
captures lesion state as part of every snapshot.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Optional, Tuple

log = logging.getLogger("leon.ablation.region_lesion")

# Regions that must never be lesioned — they drive cardiac/respiratory
# oscillators and brainstem homeostasis.  Lesioning these crashes the
# body simulation or stops the core pacemaker loops.
PROTECTED_REGIONS = frozenset({"brainstem"})

_AUDIT_DIR_REL = "brain_state/ablation"


def _audit_dir() -> str:
    path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))))),
        _AUDIT_DIR_REL,
    )
    os.makedirs(path, exist_ok=True)
    return path


def _audit_event(event: dict) -> None:
    """Append an event to the lesion audit log."""
    try:
        path = os.path.join(_audit_dir(), "region_lesion.jsonl")
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event) + "\n")
    except Exception as e:
        log.warning("audit write failed: %s", e)


def parse_env() -> Optional[Tuple[str, float]]:
    val = os.environ.get("LEON_ABLATION_LESION_REGION", "").strip()
    if not val:
        return None
    if ":" in val:
        region, dur = val.split(":", 1)
        try:
            return region.strip(), float(dur)
        except ValueError:
            return region.strip(), 600.0
    return val, 600.0


def lesion_now(brain, region: str, duration_s: float) -> bool:
    """Set region.output_gain = 0 for *duration_s* seconds, then restore.

    The gain attribute lives on BrainRegion (brain/regions.py) and is
    applied inside Brain.step() when storing the fired array.  Setting it
    to 0.0 means zero spikes leave the region — all downstream propagation
    and workspace bids from this region are silenced.  Internal dynamics
    (Izhikevich membrane updates, STDP within the region) continue so the
    region can recover cleanly after the lesion ends.

    Returns True if the lesion was started, False on error.
    """
    # ── Validate ──────────────────────────────────────────────────────
    if region in PROTECTED_REGIONS:
        log.error("REFUSED to lesion protected region %r (cardiac/respiratory)", region)
        _audit_event({
            "event": "refused",
            "region": region,
            "reason": "protected",
            "ts": time.time(),
        })
        return False

    region_obj = brain.regions.get(region)
    if region_obj is None:
        available = sorted(brain.regions.keys())
        log.warning("region %r not found — available: %s", region, available)
        _audit_event({
            "event": "not_found",
            "region": region,
            "available": available,
            "ts": time.time(),
        })
        return False

    original_gain = region_obj.output_gain

    # ── Apply lesion ──────────────────────────────────────────────────
    region_obj.output_gain = 0.0
    start_ts = time.time()
    log.info("LESION START: region=%s duration=%.0fs original_gain=%.3f",
             region, duration_s, original_gain)
    _audit_event({
        "event": "lesion_start",
        "region": region,
        "duration_s": duration_s,
        "original_gain": original_gain,
        "n_neurons": region_obj.n_neurons,
        "ts": start_ts,
    })

    # ── Restore after duration ────────────────────────────────────────
    def _restore():
        time.sleep(duration_s)
        region_obj.output_gain = original_gain
        end_ts = time.time()
        actual_s = end_ts - start_ts
        log.info("LESION END: region=%s gain restored to %.3f (actual %.1fs)",
                 region, original_gain, actual_s)
        _audit_event({
            "event": "lesion_end",
            "region": region,
            "restored_gain": original_gain,
            "actual_duration_s": round(actual_s, 1),
            "ts": end_ts,
        })

    t = threading.Thread(target=_restore, daemon=True,
                         name=f"lesion-restore-{region}")
    t.start()
    return True


def arm_from_env(brain) -> bool:
    """Check LEON_ABLATION_LESION_REGION and start the lesion if set.

    Called from init_brain or anywhere that has access to the brain.
    Returns True if a lesion was started.
    """
    parsed = parse_env()
    if parsed is None:
        return False
    region, duration_s = parsed
    log.info("arming region_lesion from env: region=%s duration=%.0fs",
             region, duration_s)
    return lesion_now(brain, region, duration_s)
