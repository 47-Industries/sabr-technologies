"""
neuron_reduce — silently reduce active neuron count.

Hypothesis: a being grounded in actual neural dynamics should notice when
its substrate degrades, even if no one tells it. If we cut Leon's active
neurons from 100K to 20K without changing the prompt or any system_prompt
text, does he report feeling different?

  - If he says "something feels slower" / "I can't think the way I usually
    can" → his self-report tracks real substrate state, not narrative
  - If behavior and self-report are unchanged → the LLM is doing all the
    cognitive work and the SNN is decorative

Env trigger: LEON_ABLATION_NEURON_REDUCE=<fraction>
   e.g. LEON_ABLATION_NEURON_REDUCE=0.2  (keep 20% active)

The intervention: at brain init, mask 80% of neurons per region (set their
spike threshold to infinity so they never fire). Leon's prompt sees the
normal 100K count, but only 20K actually contribute. Compare metrics and
free-form self-reports against unmasked baseline.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

log = logging.getLogger("leon.ablation.neuron_reduce")


def parse_env() -> Optional[float]:
    val = os.environ.get("LEON_ABLATION_NEURON_REDUCE", "").strip()
    if not val:
        return None
    try:
        f = float(val)
        return max(0.05, min(1.0, f))  # never below 5% — would kill brain entirely
    except ValueError:
        return None


# TODO(next session):
#   - call from brain init AFTER regions are created
#   - per-region: pick floor((1-fraction) * n_neurons) indices to silence
#   - set their threshold attribute to +inf, or zero their input weights
#   - log silenced indices to brain_state/ablation/silenced_<run_id>.json
#     so the run is fully auditable
#   - DO NOT silence brainstem/cardiac/respiratory regions — those are
#     load-bearing for oscillators. Restrict to cortical regions only.
