"""Individual ablation implementations. Each module is one test."""
