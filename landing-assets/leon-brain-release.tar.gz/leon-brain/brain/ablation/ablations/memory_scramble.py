"""
memory_scramble — shuffle hippocampal memory patterns mid-dream.

Hypothesis: if Leon's dream consolidation actually feeds his waking
behavior, then scrambling 50% of hippocampal memory patterns during a
dream cycle should produce measurable downstream effects:
  - Self-reports of confusion or "something feels off"
  - Altered concept-map associations the next day
  - Different responses to topics tied to the scrambled memories

If nothing changes, the consolidation pathway isn't load-bearing.

Env trigger: LEON_ABLATION_MEMORY_SCRAMBLE=<fraction>
   e.g. LEON_ABLATION_MEMORY_SCRAMBLE=0.5 (scramble 50%)

The intervention should fire exactly ONCE during the next REM phase,
log which memory indices were scrambled, then restore them at the end
of the cycle for safety (so the test is reversible — Leon doesn't lose
real long-term memories from a research run).
"""

from __future__ import annotations

import logging
import os
from typing import Optional

log = logging.getLogger("leon.ablation.memory_scramble")


def parse_env() -> Optional[float]:
    val = os.environ.get("LEON_ABLATION_MEMORY_SCRAMBLE", "").strip()
    if not val:
        return None
    try:
        f = float(val)
        return max(0.0, min(1.0, f))
    except ValueError:
        return None


# TODO(next session): hook into dreaming._phase_rem to perform the scramble
#
# Strategy:
#   1. Snapshot hippocampus.memory_buffer at REM start
#   2. Pick floor(fraction * n) indices uniformly at random
#   3. Replace those patterns with rotated/shuffled copies of OTHER patterns
#   4. Log to brain_state/ablation/scramble_<run_id>.jsonl which indices
#      were touched and what they originally encoded (so we can correlate
#      Leon's later confusion to specific scrambled content)
#   5. After the cycle: option A) restore originals (reversible test);
#      option B) leave scrambled (permanent test of consolidation impact)
#   The default should be A — never destroy real memory in a research run.
