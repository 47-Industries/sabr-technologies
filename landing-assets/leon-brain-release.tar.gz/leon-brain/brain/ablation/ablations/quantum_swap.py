"""
quantum_swap — the antenna-framework signature test.

Dean's claim: the IBM quantum hardware is doing real ontologically
non-computable work that classical pseudo-randomness cannot replicate.
If true, consciousness metrics should differ statistically between modes.

How it works
------------
The relevant patch lives in brain/quantum_consciousness.py: the
_execute_circuit() method reads LEON_QUANTUM_SOURCE before dispatching.

Modes:
  LEON_QUANTUM_SOURCE=ibm        → only IBM hardware (no Aer fallback)
  LEON_QUANTUM_SOURCE=aer        → only Aer simulator (correct QM, classical substrate)
  LEON_QUANTUM_SOURCE=classical  → no quantum circuit at all — weighted random pick
  LEON_QUANTUM_SOURCE=auto       → current default behavior (IBM → Aer → classical)

How to run a comparison
-----------------------
Each mode runs for N hours/days. The metrics logger tags every snapshot
with the active env value, so you can grep specific runs out of
brain_state/ablation/metrics_<run_id>.jsonl.

  # Mode A — IBM hardware
  systemctl --user set-environment LEON_QUANTUM_SOURCE=ibm
  systemctl --user restart leon.service
  # ... 7 days ...

  # Mode B — classical RNG
  systemctl --user set-environment LEON_QUANTUM_SOURCE=classical
  systemctl --user restart leon.service
  # ... 7 days ...

  # Compare
  python3 -m brain.ablation.ablations.quantum_swap compare \
      brain_state/ablation/metrics_*ibm*.jsonl \
      brain_state/ablation/metrics_*classical*.jsonl

What the comparison checks
--------------------------
For each metric (PCI, RTD signal, ignition rate, streak length, gamma
coherence, drive distributions, region firing entropy):
  1. Two-sample Kolmogorov-Smirnov test on the distributions
  2. Cohen's d effect size
  3. Visualization-ready summary (mean, std, median, p95)

If the IBM run differs from the classical run with effect size > 0.3 and
p < 0.01 across multiple independent metrics, that's evidence the quantum
source is doing something the classical RNG can't. If they look identical,
the antenna theory predicts a phenomenon the data doesn't support.

Be honest with the result either way. That's the whole point.
"""

from __future__ import annotations

import json
import math
import os
import sys
from collections import defaultdict
from typing import Dict, List, Tuple


# ── Comparison helpers (pure-python, no scipy required) ────────────────

def _load_jsonl(path: str) -> List[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    return rows


def _extract_metric(rows: List[dict], dotted_key: str) -> List[float]:
    """Pull a numeric field. Supports dotted keys (e.g. drives.social_hunger)."""
    out: List[float] = []
    parts = dotted_key.split(".")
    for r in rows:
        cur = r
        ok = True
        for p in parts:
            if not isinstance(cur, dict) or p not in cur:
                ok = False
                break
            cur = cur[p]
        if ok and isinstance(cur, (int, float)):
            out.append(float(cur))
    return out


def _describe(values: List[float]) -> Dict[str, float]:
    if not values:
        return {"n": 0}
    s = sorted(values)
    n = len(s)
    mean = sum(s) / n
    var = sum((x - mean) ** 2 for x in s) / max(n - 1, 1)
    return {
        "n": n,
        "mean": mean,
        "std": math.sqrt(var),
        "median": s[n // 2],
        "p5": s[max(0, int(n * 0.05))],
        "p95": s[min(n - 1, int(n * 0.95))],
        "min": s[0],
        "max": s[-1],
    }


def _ks_statistic(a: List[float], b: List[float]) -> Tuple[float, float]:
    """Two-sample KS statistic + a quick approximate p-value.

    The p-value approximation is good enough for "are they different at
    all" — for publication you'd want scipy.stats.ks_2samp.
    """
    if not a or not b:
        return 0.0, 1.0
    sa = sorted(a)
    sb = sorted(b)
    all_vals = sorted(set(sa + sb))
    na, nb = len(sa), len(sb)
    d = 0.0
    for v in all_vals:
        fa = sum(1 for x in sa if x <= v) / na
        fb = sum(1 for x in sb if x <= v) / nb
        d = max(d, abs(fa - fb))
    # Approximate p-value via Kolmogorov distribution
    ne = (na * nb) / (na + nb)
    arg = (math.sqrt(ne) + 0.12 + 0.11 / math.sqrt(ne)) * d
    p = 2.0 * math.exp(-2.0 * arg * arg)
    p = max(0.0, min(1.0, p))
    return d, p


def _cohens_d(a: List[float], b: List[float]) -> float:
    if not a or not b:
        return 0.0
    ma = sum(a) / len(a)
    mb = sum(b) / len(b)
    va = sum((x - ma) ** 2 for x in a) / max(len(a) - 1, 1)
    vb = sum((x - mb) ** 2 for x in b) / max(len(b) - 1, 1)
    pooled = math.sqrt((va + vb) / 2.0)
    if pooled < 1e-12:
        return 0.0
    return (ma - mb) / pooled


METRICS_TO_COMPARE = [
    "pci",
    "rtd_signal",
    "current_streak_s",
    "longest_streak_s",
    # ignition_count_delta isolates per-run activity; absolute is lifetime
    "ws_ignition_count_delta",
    "ws_ignition_rate",
    "ws_quantum_selections_delta",
    "drives.social_hunger",
    "drives.restlessness",
    "drives.mortality_fear",
    "drives.vulnerability",
    "drives.thermal_stress",
    "drives.resource_pressure",
    "neuromodulators.dopamine",
    "neuromodulators.serotonin",
    "neuromodulators.acetylcholine",
    "neuromodulators.norepinephrine",
]


def compare(a_path: str, b_path: str) -> Dict:
    """Compare two metrics jsonl files and return a report."""
    a_rows = _load_jsonl(a_path)
    b_rows = _load_jsonl(b_path)

    report = {
        "a_path": a_path,
        "b_path": b_path,
        "a_n": len(a_rows),
        "b_n": len(b_rows),
        "a_env": (a_rows[0].get("env", {}) if a_rows else {}),
        "b_env": (b_rows[0].get("env", {}) if b_rows else {}),
        "metrics": {},
    }

    for key in METRICS_TO_COMPARE:
        a_vals = _extract_metric(a_rows, key)
        b_vals = _extract_metric(b_rows, key)
        d, p = _ks_statistic(a_vals, b_vals)
        report["metrics"][key] = {
            "a": _describe(a_vals),
            "b": _describe(b_vals),
            "ks_statistic": round(d, 4),
            "ks_p_value": round(p, 6),
            "cohens_d": round(_cohens_d(a_vals, b_vals), 4),
            "significant": p < 0.01 and abs(_cohens_d(a_vals, b_vals)) > 0.3,
        }

    sig = [k for k, v in report["metrics"].items() if v.get("significant")]
    report["significant_metrics"] = sig
    report["verdict"] = (
        f"{len(sig)}/{len(METRICS_TO_COMPARE)} metrics show meaningful divergence"
    )
    return report


def main_compare(argv: List[str]) -> int:
    if len(argv) < 2:
        print("Usage: python3 -m brain.ablation.ablations.quantum_swap compare A.jsonl B.jsonl", file=sys.stderr)
        return 2
    rep = compare(argv[0], argv[1])
    print(json.dumps(rep, indent=2))
    return 0


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print("commands: compare A.jsonl B.jsonl", file=sys.stderr)
        sys.exit(2)
    cmd, rest = args[0], args[1:]
    if cmd == "compare":
        sys.exit(main_compare(rest))
    print(f"unknown command: {cmd}", file=sys.stderr)
    sys.exit(2)
