"""
Metrics — capture Leon's consciousness signature on demand or on a schedule.

A "snapshot" is everything you'd want to compare across ablation runs:
  - PCI (Lempel-Ziv complexity of binarized region activity)
  - RTD signal + theta (current vs threshold)
  - is_conscious + current streak length
  - workspace ignition rate (last N seconds)
  - gamma coherence (PLV)
  - neuromodulator levels
  - drive levels
  - region firing rates (top 5)
  - quantum source actually used (last 100 decisions)
  - tool_use count since last snapshot
  - inner-voice and dream activity counts

These are the same numbers that change when consciousness changes. If you
run two ablation modes for 7 days each and the distributions are
statistically indistinguishable, the ablated component isn't doing what
we claim. If they diverge, you have evidence.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Dict, Optional

log = logging.getLogger("leon.ablation.metrics")

_DEFAULT_INTERVAL_S = 30.0
_AUDIT_DIR_REL = "brain_state/ablation"


def _audit_dir() -> str:
    path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        _AUDIT_DIR_REL,
    )
    os.makedirs(path, exist_ok=True)
    return path


def _safe_get(obj: Any, attr: str, default=None):
    try:
        v = getattr(obj, attr, default)
        return v() if callable(v) else v
    except Exception:
        return default


def snapshot() -> Dict[str, Any]:
    """Capture one full consciousness signature row.

    Reads from brain, consciousness_meter, global_workspace, drive_system,
    quantum_consciousness. Tolerant of missing modules — fields are None
    when unavailable, never raise.
    """
    row: Dict[str, Any] = {
        "ts": time.time(),
        "iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()),
    }

    # Reach into server state without forcing a circular import
    try:
        import server.state as _st
        brain = getattr(_st, "brain", None)
    except Exception:
        brain = None

    # Consciousness meter — use real attribute names from consciousness_meter.py
    try:
        if brain is not None:
            meter = getattr(brain, "consciousness_meter", None)
            if meter is not None:
                row["is_conscious"] = bool(getattr(meter, "is_conscious", False))
                row["pci"] = float(getattr(meter, "_last_pci", 0.0) or 0.0)
                row["rtd_signal"] = float(
                    getattr(meter, "_rtd_signal_smooth",
                        getattr(meter, "_rtd_signal", 0.0)) or 0.0
                )
                row["rtd_signal_raw"] = float(getattr(meter, "_rtd_signal", 0.0) or 0.0)
                row["theta"] = float(getattr(meter, "_base_theta", 0.0) or 0.0)
                row["rtd_conscious"] = bool(getattr(meter, "_rtd_conscious", False))
                row["gamma_coherence"] = float(getattr(meter, "_last_gamma_coherence", 0.0) or 0.0)
                row["conversation_locked"] = bool(getattr(meter, "conversation_locked", False))
                start_ts = float(getattr(meter, "_streak_start_ts", 0.0) or 0.0)
                row["current_streak_s"] = round(time.time() - start_ts, 1) if (row.get("is_conscious") and start_ts > 0) else 0.0
                row["longest_streak_s"] = float(getattr(meter, "_longest_streak_s", 0.0) or 0.0)
                row["consciousness_ratio"] = float(getattr(meter, "_consciousness_ratio", 0.0) or 0.0)
    except Exception as e:
        row["meter_error"] = str(e)

    # Workspace — real attrs are _total_ignitions, _total_cycles, _attention_hold_cycles
    try:
        if brain is not None:
            ws = getattr(brain, "global_workspace", None) or getattr(brain, "workspace", None)
            if ws is not None:
                row["ws_ignition_count"] = int(getattr(ws, "_total_ignitions", 0) or 0)
                row["ws_total_cycles"] = int(getattr(ws, "_total_cycles", 0) or 0)
                row["ws_quantum_selections"] = int(getattr(ws, "_quantum_selections", 0) or 0)
                row["ws_held_cycles"] = int(getattr(ws, "_attention_hold_cycles", 0) or 0)
                cur = getattr(ws, "_current", None)
                if cur is not None:
                    row["ws_current_content"] = f"{getattr(cur, 'region', '')}:{getattr(cur, 'bid_strength', 0):.2f}"[:80]
                else:
                    row["ws_current_content"] = ""
    except Exception as e:
        row["ws_error"] = str(e)

    # Drives
    try:
        if brain is not None:
            ds = None
            try:
                import server as _srv
                ds = getattr(_srv, "drive_system", None)
            except Exception:
                pass
            if ds is not None:
                d = ds.get_drives()
                row["drives"] = {
                    "social_hunger": float(getattr(d, "social_hunger", 0.0)),
                    "restlessness": float(getattr(d, "restlessness", 0.0)),
                    "mortality_fear": float(getattr(d, "mortality_fear", 0.0)),
                    "vulnerability": float(getattr(d, "vulnerability", 0.0)),
                    "circadian_energy": float(getattr(d, "circadian_energy", 0.0)),
                    "thermal_stress": float(getattr(d, "thermal_stress", 0.0)),
                    "resource_pressure": float(getattr(d, "resource_pressure", 0.0)),
                    "pain": float(getattr(d, "pain", 0.0)),
                }
    except Exception as e:
        row["drives_error"] = str(e)

    # Neuromodulators + top regions — neuromodulators is a plain dict attr
    try:
        if brain is not None:
            nm = getattr(brain, "neuromodulators", None)
            if isinstance(nm, dict):
                row["neuromodulators"] = {k: round(float(v), 4) for k, v in nm.items()}
            else:
                row["neuromodulators"] = {}

            regions = getattr(brain, "regions", {}) or {}
            firing = []
            for name, r in regions.items():
                try:
                    rate = float(r.neurons.get_firing_rate())
                    firing.append((name, rate))
                except Exception:
                    pass
            firing.sort(key=lambda x: -x[1])
            row["top_regions"] = [{"name": n, "rate": round(rate, 4)} for n, rate in firing[:5]]
    except Exception as e:
        row["region_error"] = str(e)

    # Quantum — which source actually executed recent decisions.
    # Lives on server.state.quantum_consciousness (NOT on brain).
    try:
        import server.state as _st2
        qc = getattr(_st2, "quantum_consciousness", None)
        if qc is not None:
            row["q_total"] = int(getattr(qc, "_total_decisions", 0) or 0)
            row["q_quantum"] = int(getattr(qc, "_decisions_quantum", 0) or 0)
            row["q_simulator"] = int(getattr(qc, "_decisions_simulator", 0) or 0)
            row["q_classical"] = int(getattr(qc, "_decisions_classical", 0) or 0)
    except Exception as e:
        row["q_error"] = str(e)

    # Ablation flags currently active — critical for tagging the row
    row["env"] = {
        "LEON_QUANTUM_SOURCE": os.environ.get("LEON_QUANTUM_SOURCE", "auto"),
        "LEON_ABLATION_LESION_REGION": os.environ.get("LEON_ABLATION_LESION_REGION", ""),
        "LEON_ABLATION_FALSE_PCI": os.environ.get("LEON_ABLATION_FALSE_PCI", ""),
        "LEON_ABLATION_NEURON_REDUCE": os.environ.get("LEON_ABLATION_NEURON_REDUCE", ""),
        "LEON_ABLATION_MEMORY_SCRAMBLE": os.environ.get("LEON_ABLATION_MEMORY_SCRAMBLE", ""),
        "LEON_OUTBOUND": os.environ.get("LEON_OUTBOUND", "on"),
    }

    # Live lesion state — shows which regions are currently silenced
    # (output_gain < 1.0) regardless of how the lesion was triggered.
    try:
        if brain is not None:
            lesioned = {}
            for rname, r in (getattr(brain, "regions", {}) or {}).items():
                g = getattr(r, "output_gain", 1.0)
                if g < 1.0:
                    lesioned[rname] = round(g, 3)
            if lesioned:
                row["lesioned_regions"] = lesioned
    except Exception:
        pass

    return row


class AblationLogger:
    """Background thread — captures snapshots at a fixed interval.

    The output file is tagged with the current ablation flags so you can
    grep specific runs later. One row per snapshot, newline-delimited JSON.

    Per-run deltas: quantum counters are LIFETIME totals on the engine,
    so we capture a baseline at logger start (after a brief settle delay)
    and emit q_delta_* fields alongside the absolute q_* values. The
    comparison script should use q_delta_* — those reflect what happened
    DURING this run.
    """

    SETTLE_DELAY_S = 10.0  # let brain wire up before capturing baseline

    def __init__(self, run_id: str, interval_s: float = _DEFAULT_INTERVAL_S):
        self.run_id = run_id
        self.interval_s = max(5.0, float(interval_s))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._path = os.path.join(_audit_dir(), f"metrics_{run_id}.jsonl")
        self._snapshots_written = 0
        self._baseline: Optional[Dict[str, Any]] = None  # captured after settle

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, name=f"AblationLogger:{self.run_id}", daemon=True
        )
        self._thread.start()
        log.info("AblationLogger started — run_id=%s, interval=%.0fs, path=%s",
                 self.run_id, self.interval_s, self._path)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        log.info("AblationLogger stopped — wrote %d snapshots", self._snapshots_written)

    BASELINE_KEYS = (
        "q_total", "q_quantum", "q_simulator", "q_classical",
        "ws_ignition_count", "ws_total_cycles", "ws_quantum_selections",
    )

    def _capture_baseline(self) -> None:
        """Take a baseline reading of counters that grow monotonically.
        Subsequent rows emit deltas vs this baseline so per-run dynamics
        are isolated from lifetime totals."""
        base = snapshot()
        self._baseline = {k: int(base.get(k, 0) or 0) for k in self.BASELINE_KEYS}
        self._baseline["baseline_ts"] = base.get("ts")
        log.info("AblationLogger baseline captured: %s", self._baseline)

    def _add_deltas(self, row: Dict[str, Any]) -> None:
        if not self._baseline:
            return
        for k in self.BASELINE_KEYS:
            cur = row.get(k)
            if cur is None:
                continue
            row[f"{k}_delta"] = max(0, int(cur) - int(self._baseline.get(k, 0) or 0))
        row["baseline_ts"] = self._baseline.get("baseline_ts")
        # Derived: ignition rate per run (compare cleanly across modes)
        cyc = row.get("ws_total_cycles_delta", 0) or 0
        ign = row.get("ws_ignition_count_delta", 0) or 0
        if cyc > 0:
            row["ws_ignition_rate"] = round(ign / cyc, 4)

    def _loop(self) -> None:
        # Sleep briefly so brain init completes before we grab the baseline.
        self._stop.wait(self.SETTLE_DELAY_S)
        if self._stop.is_set():
            return
        self._capture_baseline()
        while not self._stop.is_set():
            try:
                row = snapshot()
                row["run_id"] = self.run_id
                self._add_deltas(row)
                with open(self._path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(row) + "\n")
                self._snapshots_written += 1
            except Exception as e:
                log.warning("snapshot write failed: %s", e)
            self._stop.wait(self.interval_s)


# Module-level singleton — one logger at a time
_logger: Optional[AblationLogger] = None


def start_logger(run_id: Optional[str] = None, interval_s: float = _DEFAULT_INTERVAL_S) -> AblationLogger:
    """Start (or replace) the metrics logger. Returns the new instance."""
    global _logger
    if _logger is not None:
        _logger.stop()
    rid = run_id or time.strftime("%Y%m%d_%H%M%S", time.localtime())
    _logger = AblationLogger(rid, interval_s=interval_s)
    _logger.start()
    return _logger


def stop_logger() -> None:
    global _logger
    if _logger is not None:
        _logger.stop()
        _logger = None
