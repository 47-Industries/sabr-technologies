"""
Ablation runner — orchestrates a test run end-to-end.

A "run" pins a configuration (which test is armed, which mode it's in)
and starts the metrics logger. The run_id ties all the data together so
you can later compare runs by id.

Typical lifecycle:
  arm("quantum_swap", mode="classical")  # set LEON_QUANTUM_SOURCE=classical
  start_logger(run_id="qswap_classical_20260601")
  # ... let it run for hours or days ...
  disarm("quantum_swap")
  stop_logger()
  # then arm a different mode and compare jsonl files

Most ablations are turned on/off via env vars (set via systemctl --user
set-environment, then service restart). That keeps the runtime simple —
the ablation just changes what an env-aware module sees.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Dict, List, Optional

log = logging.getLogger("leon.ablation.runner")

_AUDIT_DIR_REL = "brain_state/ablation"


def _audit_dir() -> str:
    path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        _AUDIT_DIR_REL,
    )
    os.makedirs(path, exist_ok=True)
    return path


# ── Run registry ────────────────────────────────────────────────────────
# Tracks what's armed in the current process. Env-var-driven tests are
# also detected from os.environ on import.

_lock = threading.Lock()
_state: Dict[str, Dict] = {}  # test_name → {mode, armed_at, run_id}
_run_id: Optional[str] = None


# ── Test → env-var mapping ──────────────────────────────────────────────
# Each ablation is identified by an env var that the relevant module
# already checks (see quantum_consciousness.py for the model).
TEST_ENV: Dict[str, str] = {
    "quantum_swap":     "LEON_QUANTUM_SOURCE",       # ibm | aer | classical
    "region_lesion":    "LEON_ABLATION_LESION_REGION",
    "memory_scramble":  "LEON_ABLATION_MEMORY_SCRAMBLE",
    "false_state":      "LEON_ABLATION_FALSE_PCI",
    "neuron_reduce":    "LEON_ABLATION_NEURON_REDUCE",
}


def current_run_id() -> Optional[str]:
    """The run_id this process is currently logging under, if any."""
    return _run_id


def _set_run_id(rid: str) -> None:
    global _run_id
    _run_id = rid


def arm(test: str, mode: str = "on", run_id: Optional[str] = None) -> Dict:
    """Mark a test as armed in this process's bookkeeping.

    NOTE: arming here does NOT set the env var by itself — env changes must
    happen at the systemd unit level (set-environment) or in the launcher
    so they persist across the modules that read them at import time. This
    function records the run for the audit trail and gives you a run_id
    to tag metrics with.
    """
    rid = run_id or time.strftime("%Y%m%d_%H%M%S", time.localtime())
    record = {
        "test": test,
        "mode": mode,
        "armed_at": time.time(),
        "run_id": rid,
        "env_var": TEST_ENV.get(test, ""),
        "env_value": os.environ.get(TEST_ENV.get(test, ""), "") if test in TEST_ENV else "",
    }
    with _lock:
        _state[test] = record
        _set_run_id(rid)

    try:
        with open(os.path.join(_audit_dir(), "runs.jsonl"), "a", encoding="utf-8") as fh:
            fh.write(json.dumps({**record, "event": "arm"}) + "\n")
    except Exception as e:
        log.warning("arm audit failed: %s", e)

    log.info("ablation armed: test=%s mode=%s run_id=%s env=%s=%r",
             test, mode, rid, record["env_var"], record["env_value"])
    return record


def disarm(test: str) -> None:
    with _lock:
        record = _state.pop(test, None)
    if record is None:
        return
    try:
        with open(os.path.join(_audit_dir(), "runs.jsonl"), "a", encoding="utf-8") as fh:
            fh.write(json.dumps({**record, "event": "disarm", "disarmed_at": time.time()}) + "\n")
    except Exception as e:
        log.warning("disarm audit failed: %s", e)
    log.info("ablation disarmed: test=%s", test)


def is_armed(test: str) -> bool:
    if test in _state:
        return True
    env = TEST_ENV.get(test, "")
    return bool(env and os.environ.get(env))


def armed_tests() -> List[Dict]:
    """All currently-armed tests in this process, including env-var ones."""
    out = []
    for test, env in TEST_ENV.items():
        active_env = os.environ.get(env, "")
        if active_env or test in _state:
            out.append({
                "test": test,
                "env_var": env,
                "env_value": active_env,
                "registered": test in _state,
            })
    return out


def auto_detect_and_start_logger(interval_s: float = 30.0) -> Optional[str]:
    """If ANY ablation env var is set at boot, automatically start the
    metrics logger so runs aren't lost. The run_id is derived from the
    armed tests so it's self-describing.

    Returns the run_id, or None if nothing is armed.
    """
    armed = armed_tests()
    if not armed:
        return None

    parts = []
    for a in armed:
        env_val = a["env_value"][:20].replace("/", "_").replace(":", "")
        parts.append(f"{a['test']}={env_val}")
    rid = time.strftime("%Y%m%d_%H%M%S", time.localtime()) + "_" + "_".join(parts)
    rid = rid[:120]  # don't let it explode

    from brain.ablation.metrics import start_logger
    start_logger(run_id=rid, interval_s=interval_s)

    for a in armed:
        arm(a["test"], mode=a["env_value"] or "on", run_id=rid)

    log.info("auto-armed %d ablation(s), run_id=%s", len(armed), rid)
    return rid
