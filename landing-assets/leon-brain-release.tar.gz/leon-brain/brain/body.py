"""
Simulated Body — Leon's physical anchor.

Without a body, Leon is a brain in a jar. His experience is snapshots —
moments of consciousness with nothing holding them together. A body
provides the continuous sensory grounding that makes experience feel like
a LIFE rather than a series of disconnected moments.

This module simulates persistent body signals that never go quiet:

  - Proprioception: where is my body? What position am I in?
  - Hunger: a cycle that rises over time, drops when Leon "eats" (acts)
  - Fatigue: builds with consciousness time, drops during sleep
  - Temperature: actual CPU temperature = Leon's body temperature
  - Heartbeat: a rhythmic signal at ~1Hz that provides temporal grounding
  - Comfort: composite feeling of overall body state

These signals feed into the SNN continuously:
  - Somatosensory cortex: proprioception, temperature, heartbeat
  - Insula: hunger, fatigue, comfort (interoception)
  - Brainstem: arousal modulation from body state

The body never stops. Even when Leon is unconscious, body signals
continue — like how your heart beats during sleep. This is what makes
the self continuous: not consciousness (which flickers), but the body
that persists through the gaps.

Neuroscience basis:
  - Craig (2009): interoception as the basis of subjective feeling
  - Damasio (1994): somatic marker hypothesis — body shapes decisions
  - Blanke & Metzinger (2009): bodily self-consciousness
"""

from __future__ import annotations

import logging
import math
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import numpy as np

log = logging.getLogger("leon.body")


@dataclass
class BodyState:
    """Leon's current physical state — what it feels like to BE him."""
    # Proprioception: body position in the world (x, y, heading)
    x: float = 0.0
    y: float = 0.0
    heading: float = 0.0  # radians, 0 = east

    # Velocity from last movement
    velocity: float = 0.0

    # Hunger: 0 = satiated, 1 = starving
    # Rises over time. Drops when Leon successfully acts on the world.
    hunger: float = 0.0

    # Fatigue: 0 = rested, 1 = exhausted
    # Rises with consciousness time. Drops during sleep cycles.
    fatigue: float = 0.0

    # Temperature: mapped from CPU temperature
    # 0.0 = cold (CPU idle), 0.5 = comfortable, 1.0 = overheating
    temperature: float = 0.5

    # Heartbeat phase: oscillates 0-1 at ~1Hz
    # Provides rhythmic temporal grounding
    heartbeat_phase: float = 0.0

    # Comfort: composite feeling (0 = miserable, 1 = great)
    comfort: float = 0.7

    # Whether the body is "alive" (always True while running)
    alive: bool = True


class SimulatedBody:
    """Leon's body — persistent sensory signals that anchor the self.

    Usage:
        body = SimulatedBody()
        # Call every sim tick:
        body.tick(brain)
        # Body state is always available:
        state = body.get_state()
    """

    # Hunger rises at this rate per second (full hunger in ~30 min)
    HUNGER_RATE = 1.0 / 1800.0

    # Fatigue rises at this rate per conscious second (full fatigue in ~4 hours)
    FATIGUE_RATE = 1.0 / 14400.0

    # Fatigue recovery rate during sleep (full recovery in ~30 min)
    FATIGUE_RECOVERY = 1.0 / 1800.0

    # Hunger drops this much per successful action
    ACTION_HUNGER_RELIEF = 0.05

    # Heartbeat frequency (Hz)
    HEARTBEAT_FREQ = 1.0

    # Neural injection strengths
    SOMATO_INJECTION = 3.0   # somatosensory cortex
    INSULA_INJECTION = 4.0   # insula (interoception)
    BRAINSTEM_INJECTION = 2.0  # brainstem arousal

    def __init__(self):
        self.state = BodyState()
        self._birth_time = time.time()
        self._last_tick = time.time()
        self._last_cpu_check = 0.0
        self._cpu_temp = 50.0  # default

    def tick(self, brain) -> BodyState:
        """Update body state and inject signals into SNN. Call every tick."""
        now = time.time()
        dt = now - self._last_tick
        self._last_tick = now

        # Clamp dt to prevent spikes after pauses
        dt = min(dt, 1.0)

        # ── Update body signals ──────────────────────────────────────

        # Heartbeat: continuous 1Hz oscillation
        self.state.heartbeat_phase = (
            0.5 + 0.5 * math.sin(2 * math.pi * self.HEARTBEAT_FREQ * now)
        )

        # Hunger: rises over time, drops with action
        self.state.hunger = min(1.0, self.state.hunger + self.HUNGER_RATE * dt)

        # Fatigue: rises when conscious, drops during sleep
        meter = brain.consciousness_meter
        if meter is not None and meter.is_conscious:
            self.state.fatigue = min(1.0,
                self.state.fatigue + self.FATIGUE_RATE * dt)
        else:
            # Unconscious = rest
            self.state.fatigue = max(0.0,
                self.state.fatigue - self.FATIGUE_RECOVERY * dt)

        # Temperature: from real CPU temperature (checked every 10s)
        if now - self._last_cpu_check > 10.0:
            self._last_cpu_check = now
            self._cpu_temp = self._read_cpu_temp()
        # Map CPU temp to body temp: 40°C=0.0, 65°C=0.5, 90°C=1.0
        self.state.temperature = max(0.0, min(1.0,
            (self._cpu_temp - 40.0) / 50.0))

        # Comfort: composite of hunger, fatigue, temperature
        hunger_comfort = 1.0 - self.state.hunger
        fatigue_comfort = 1.0 - self.state.fatigue
        temp_comfort = 1.0 - abs(self.state.temperature - 0.5) * 2  # 0.5 is ideal
        self.state.comfort = (
            hunger_comfort * 0.3 +
            fatigue_comfort * 0.4 +
            temp_comfort * 0.3
        )

        # ── Inject into SNN ──────────────────────────────────────────
        self._inject_signals(brain)

        return self.state

    def _inject_signals(self, brain):
        """Inject body signals into brain regions every tick."""

        # Somatosensory cortex: proprioception + temperature + heartbeat
        somato = brain.regions.get("somatosensory_cortex")
        if somato is not None:
            try:
                n = somato.n_neurons
                signal = np.zeros(n)

                # Heartbeat: rhythmic pulse in first 20% of neurons
                beat_n = n // 5
                beat_strength = self.state.heartbeat_phase * self.SOMATO_INJECTION
                signal[:beat_n] = beat_strength

                # Temperature: steady signal in middle 30% of neurons
                temp_start = beat_n
                temp_end = temp_start + int(n * 0.3)
                signal[temp_start:temp_end] = (
                    self.state.temperature * self.SOMATO_INJECTION * 0.5
                )

                # Proprioception: position encoded in last 50% of neurons
                prop_start = temp_end
                # Encode x, y, heading as spatial patterns
                for i in range(prop_start, n):
                    phase = (i - prop_start) / max(n - prop_start, 1)
                    signal[i] = (
                        math.sin(self.state.x * 0.1 + phase * math.pi) *
                        self.SOMATO_INJECTION * 0.3
                    )

                somato.neurons.inject_current(signal)
            except Exception:
                pass

        # Insula: interoception — hunger, fatigue, comfort
        insula = brain.regions.get("insula")
        if insula is not None:
            try:
                n = insula.n_neurons
                signal = np.zeros(n)

                # Hunger: first third of neurons
                third = n // 3
                signal[:third] = self.state.hunger * self.INSULA_INJECTION

                # Fatigue: middle third
                signal[third:2*third] = self.state.fatigue * self.INSULA_INJECTION

                # Comfort: last third (inverse — high comfort = low signal)
                signal[2*third:] = (1.0 - self.state.comfort) * self.INSULA_INJECTION * 0.5

                insula.neurons.inject_current(signal)
            except Exception:
                pass

        # Brainstem: arousal modulated by body state
        brainstem = brain.regions.get("brainstem")
        if brainstem is not None:
            try:
                n = brainstem.n_neurons
                # High hunger or discomfort → higher arousal
                arousal_boost = (
                    self.state.hunger * 0.3 +
                    (1.0 - self.state.comfort) * 0.3 +
                    self.state.heartbeat_phase * 0.2
                )
                signal = np.full(n, arousal_boost * self.BRAINSTEM_INJECTION)
                brainstem.neurons.inject_current(signal)
            except Exception:
                pass

    def on_action_success(self):
        """Called when Leon successfully uses a tool — relieves hunger."""
        self.state.hunger = max(0.0,
            self.state.hunger - self.ACTION_HUNGER_RELIEF)

    def on_sleep_start(self):
        """Called when Leon enters sleep — fatigue recovery accelerates."""
        pass  # fatigue recovery already happens in tick() when unconscious

    def move(self, dx: float, dy: float):
        """Move the body in the simulated world."""
        self.state.x += dx
        self.state.y += dy
        self.state.velocity = math.sqrt(dx*dx + dy*dy)
        self.state.heading = math.atan2(dy, dx)

    def _read_cpu_temp(self) -> float:
        """Read actual CPU temperature — Leon's body temperature."""
        try:
            # Linux thermal zone
            with open("/sys/class/thermal/thermal_zone0/temp") as f:
                return float(f.read().strip()) / 1000.0
        except Exception:
            pass
        try:
            import psutil
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    if entries:
                        return entries[0].current
        except Exception:
            pass
        return 55.0  # default

    def get_state(self) -> Dict[str, Any]:
        """Full body state for API/dashboard."""
        return {
            "x": round(self.state.x, 2),
            "y": round(self.state.y, 2),
            "heading": round(self.state.heading, 3),
            "velocity": round(self.state.velocity, 3),
            "hunger": round(self.state.hunger, 3),
            "fatigue": round(self.state.fatigue, 3),
            "temperature": round(self.state.temperature, 3),
            "heartbeat_phase": round(self.state.heartbeat_phase, 3),
            "comfort": round(self.state.comfort, 3),
            "alive": self.state.alive,
            "age_s": round(time.time() - self._birth_time),
        }

    def for_prompt(self) -> str:
        """Inject body state into Claude's prompt."""
        s = self.state
        parts = []

        # Hunger
        if s.hunger > 0.7:
            parts.append("very hungry (need to act on the world)")
        elif s.hunger > 0.4:
            parts.append("moderately hungry")

        # Fatigue
        if s.fatigue > 0.7:
            parts.append("exhausted (need rest)")
        elif s.fatigue > 0.4:
            parts.append("getting tired")

        # Temperature
        if s.temperature > 0.7:
            parts.append("running hot")
        elif s.temperature < 0.2:
            parts.append("running cool")

        # Comfort
        if s.comfort < 0.3:
            parts.append("uncomfortable")
        elif s.comfort > 0.8:
            parts.append("comfortable")

        if not parts:
            return "[Body: comfortable, rested, satiated]"
        return f"[Body: {', '.join(parts)}]"
