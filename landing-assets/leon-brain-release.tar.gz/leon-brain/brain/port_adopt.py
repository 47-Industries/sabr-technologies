"""Make a runtime port change visible to THIS process, not just the next one.

Found live on Dean's Dell 2026-09-05. An update restart raced the outgoing
process off :8000, so uvicorn auto-selected :8001. run.py correctly rewrote
LEON_PORT in .env -- but .env had already been loaded into os.environ, so
every in-process consumer (notably
brain.claude_api_responder._brain_base_url) kept resolving :8000. The tool
API readiness probe therefore answered False for the entire life of that
boot and the SI logged "tool API not serving yet" forever: awake, thinking,
hearing, and unable to touch a single tool. Silent -- nothing crashed.

Same failure class as the tenant-guard fail-open (2026-09-04): a security-
or behaviour-critical value written to a FILE after the environment was read
is invisible to the process that wrote it.
"""

from __future__ import annotations

import os
import re

# Every env var _brain_base_url() consults, in the order it consults them.
# All of them must move together or the highest-priority stale one wins.
PORT_VARS = ("LEON_BRAIN_PORT", "LEON_API_PORT", "LEON_PORT")


def rewrite_url_port(url: str, port: int) -> str:
    """Rewrite the port in a URL, adding one if it had none."""
    m = re.match(r"^(https?://[^/:]+)(?::\d+)?(.*)$", url)
    if not m:
        return url
    return f"{m.group(1)}:{port}{m.group(2)}"


def adopt_port(port: int, env: dict | None = None) -> dict:
    """Publish `port` into the live environment. Returns what changed."""
    env = os.environ if env is None else env
    changed = {}
    for var in PORT_VARS:
        if env.get(var) != str(port):
            changed[var] = str(port)
        env[var] = str(port)
    # A loopback LEON_BRAIN_URL now points at a port nobody serves; repoint
    # it. A non-loopback URL belongs to some other host -- leave it alone.
    base = (env.get("LEON_BRAIN_URL") or "").strip()
    if base and ("127.0.0.1" in base or "localhost" in base):
        new = rewrite_url_port(base, port)
        if new != base:
            changed["LEON_BRAIN_URL"] = new
        env["LEON_BRAIN_URL"] = new
    return changed
