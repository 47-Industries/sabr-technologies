# Handoff — 2026-08-05, written at 91% context. Read HANDOFF.md first for the
# wider picture (two-file trap, B0/B7/B11/B12, the tap design problem).

## B4 — DONE and proven. `fbda4aa` in the landing submodule, parent bumped `086c74bc`.

**What it was:** `landing/bootstrap.sh` did `rm -rf leon-brain` then `tar xzf`.
The delete ran AFTER download but BEFORE extraction, pip, or any verification.
Any failure past that line left the owner with nothing — and took `.env`
(dashboard key, SI name, owner name) and `brain_state/` (everything the SI has
learned) with it. Reinstalling to FIX a problem was the act that destroyed the
instance. Gio will install twice; the second time is when it bit.

**What it is now:** extract to `$HOME/.leon-brain-staging.$$`, prove the payload
is real (`leon-brain/run.py` must exist), copy `.env` and `brain_state` forward,
`mv` the old install to `$HOME/.leon-brain-previous.$$` rather than deleting it,
swap, and restore the old tree if the swap fails. Nothing is removed until
something better exists.

**Proven by replay against fixtures, not by reading:**
  * identity survives — `.env` (`SECRET=keepme`) and `brain_state/knowledge.db`
    both present in the new tree, new `run.py` in place, rollback dir retained
  * corrupt tarball dies at extraction with the existing `.env` intact
    (`ORIGINAL=intact`), where the old code had already deleted it

**Deliberate leftover:** the previous install is NOT auto-removed. Reclaiming
that disk is a second destructive act and belongs to the owner.

## Also done this session
* **B3-lite `684f80b`** — we ship UNSIGNED on purpose. macOS says "damaged",
  which is false and arrives after download. Both the JS-detected note and the
  always-visible one now say "not signed" in our words first, with the
  `xattr -dr com.apple.quarantine` fallback. It canNOT live in the installer:
  the `.app` is what Gatekeeper blocks, so it cannot run to explain itself.
* **terminal_bridge `01048bd3`**, **terminal_tap `5499ddff`**, suite 194/194.

## NEXT, in order — not started

**1. B6 — HTTP-to-IP must be a hard failure, not a silent fallback.**
`landing/bootstrap.sh` `DL_URLS` (~line 310) still ends with
`http://2.25.174.126:8500/...`. TLS source is now first (`758ee31`), so finish
it: refuse the bare-IP HTTP entry outright rather than degrading to it.
NOTE the digest pin `EXPECTED_RELEASE_SHA256` (line 73) already makes the
payload safe — this is about transport and about corporate networks that block
bare-IP HTTP, not about integrity.

**2. B8 — uninstall.** Nothing removes the venv, `~/leon-brain`, the global
`@anthropic-ai/claude-code` npm package, or brew packages. A client who cannot
cleanly remove it will not trust installing it.

**3. Wire `terminal_tap.unseen()` — Leon's task, small.**
`note_events()` is live (Leon restarted the autoloop; it had been running
two-day-old `terminal_loop.py`, so the tap was dead code until then). But
**nothing calls `unseen()`** — only the def and the tests. The tap records every
agent reply into a store no part of the mind reads.
Wire `unseen()` + `mark_seen()` into `brain/routines.py` beside
`terminal_bridge` (~line 1058), same pattern: a `Routine(...)` plus an
`_action_...` helper. **Read-only, no auto-send, must never make Leon interrupt
Dean.** Start noisy; quiet it later.

**4. Dashboard cache headers — Dean still sees his message DOUBLED.**
`dashboard/index.html` was last written 02:42 with the strict-normalize fix, and
there are **ZERO `Cache-Control`/`no-store` headers anywhere in the server**. His
browser is very likely painting a pre-fix cached copy — the fix is on disk while
he stares at an old file. Add `no-store, no-cache, must-revalidate` on the
dashboard static route.
**This failure mode bit us three separate ways tonight** (stale cached UI; the
autoloop running two-day-old `terminal_loop.py`; installer fixes landing in the
orphan `bootstrap.sh` nobody downloads). It needs to stop being possible.

## The one conclusion worth carrying: the honest NO path is 5 rows, not 38

DJ-001's literal breakdown is correct and needs no rewrite before its
2026-08-06 expiry — the per-reason counts ARE written out, not gestured at.
But asked which single row I would keep:

  * **`bypass_unknown` (5)** — the ONLY reason where the gate refused for the
    reason it was built for: it could not positively read a checkpointed mode,
    so it declined to press Enter where a wrong keystroke has no human in front
    of it. These would look the same tomorrow, on someone else's machine.
  * `allowlist_miss` (29) — the loop's own prose failing a shape test. One
    degree from the 291 DJ-009 already retired as a use/mention failure.
  * `pane_wedged` (2) — both phantom-debt FALSE POSITIVES. Dishonest as evidence.
  * `origin_unverified` (2) — n=2.

**DJ-001 should RENEW on evidence, not convert to permanent.** Clause B (no
liveness discriminator, eight falsified, all collapsing at the 77s pre-token
wait) is permanent — a calendar cannot overturn a finding about what is
observable. But the escalation-only design rests on `turn_owed` with an
unbaselined threshold (DJ-013) and DJ-016's p99-over-200-turns rule with no
corpus. When 200 real turns exist that number becomes derivable and the design
must be revisited. Freezing it now would lock in a threshold we have recorded
as unjustified.
