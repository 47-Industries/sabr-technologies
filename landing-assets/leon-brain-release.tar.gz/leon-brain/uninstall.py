#!/usr/bin/env python3
"""Sabr SI — Uninstall (cross-platform entry point).

    python uninstall.py              show what WOULD be removed, touch nothing
    python uninstall.py --yes        actually remove it

Flags:
    --yes                   perform the removal (without this, nothing is deleted)
    --purge-memories        delete brain_state outright instead of archiving it
    --remove-claude-code    also remove the global @anthropic-ai/claude-code package

Why this file exists
--------------------
The only uninstaller that shipped was uninstall.sh. Bash. On Windows that is
not a broken uninstaller, it is no uninstaller — nothing runs it, so a Windows
owner had literally no supported way to remove the SI, and every reinstall
inherited the previous SI's autostart task, Startup shortcut and ~/.leon
cognition databases.

On Windows this module does the removal itself, natively.
On Linux/macOS it hands off to uninstall.sh, which is already proven there;
this file is the single command a user can be told to run on any OS.

The two rules from uninstall.sh are preserved exactly:

  1. The SI's identity — .env, brain_state, and ~/.leon (the skills, lessons,
     reflections and tool health it actually learned) — is archived BEFORE
     anything is deleted, and the uninstall REFUSES to continue if that
     archive cannot be written.

  2. It does not remove what it did not install. Python, Node, your Claude
     Code login: reported with the exact command to remove them yourself,
     never removed for you.

Note the .leon probe sits OUTSIDE the "is there anything to keep" guard, for
the same reason it does in the shell version: on a tree with no .env or
brain_state yet, an inside-the-guard probe skips the archive while still
deleting ~/.leon. That is data loss, and it is the exact bug caught in the
shell script's container run.
"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HOME = Path.home()
SYSTEM = platform.system()
AUTOSTART_TASK = "Sabr SI"
STARTUP_BAT = "Sabr SI.bat"
COGNITION = HOME / ".leon"

# Kept in sync with uninstall.sh deliberately: both scripts must agree on what
# counts as "the SI's identity", or the two platforms archive different things.
KEEP_NAMES = (".env", "brain_state")

G, Y, R, C, D, N = "\033[32m", "\033[33m", "\033[31m", "\033[36m", "\033[2m", "\033[0m"
if SYSTEM == "Windows" and not os.environ.get("WT_SESSION"):
    # Old conhost does not render ANSI. Colour codes as literal garbage in an
    # uninstaller reads as "this thing is broken" right when trust matters.
    G = Y = R = C = D = N = ""


def say(msg=""):
    print(msg, flush=True)


def human(n):
    for unit in ("B", "K", "M", "G"):
        if n < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024
    return f"{n:.0f}T"


def dir_size(p: Path):
    total = 0
    for dirpath, _, names in os.walk(p, onerror=lambda e: None):
        for name in names:
            try:
                total += (Path(dirpath) / name).stat().st_size
            except OSError:
                pass
    return total


def size_of(p: Path):
    try:
        if p.is_dir():
            return human(dir_size(p))
        if p.exists():
            return human(p.stat().st_size)
    except OSError:
        pass
    return "-"


# ── Windows discovery ────────────────────────────────────────────────────

def startup_shortcut() -> Path:
    appdata = os.environ.get("APPDATA") or (HOME / "AppData" / "Roaming")
    return (Path(appdata) / "Microsoft" / "Windows" / "Start Menu"
            / "Programs" / "Startup" / STARTUP_BAT)


def scheduled_task_exists() -> bool:
    try:
        r = subprocess.run(["schtasks", "/query", "/tn", AUTOSTART_TASK],
                           capture_output=True, text=True, timeout=30)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def running_pids():
    """PIDs of processes running THIS install's interpreter.

    Scoped to the install tree exactly like the shell version, so an unrelated
    python.exe belonging to the user's own work is never killed.
    """
    venv_python = ROOT / ".venv" / "Scripts" / "python.exe"
    if not venv_python.exists():
        return []
    try:
        r = subprocess.run(
            ["wmic", "process", "where",
             f"ExecutablePath='{str(venv_python).replace(chr(92), chr(92) * 2)}'",
             "get", "ProcessId"],
            capture_output=True, text=True, timeout=30)
        out = r.stdout
    except (OSError, subprocess.SubprocessError):
        out = ""
    if not out.strip():
        # wmic is deprecated and absent on newer Windows 11 images. PowerShell
        # CIM is the supported replacement; try it before concluding "nothing
        # is running", because a false negative here means we delete the tree
        # out from under a live process.
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 f"Get-CimInstance Win32_Process -Filter \"ExecutablePath='"
                 f"{str(venv_python).replace(chr(92), chr(92) * 2)}'\" "
                 f"| Select-Object -ExpandProperty ProcessId"],
                capture_output=True, text=True, timeout=60)
            out = r.stdout
        except (OSError, subprocess.SubprocessError):
            out = ""
    return [int(t) for t in out.split() if t.isdigit()]


# ── Archive ──────────────────────────────────────────────────────────────

def build_archive(purge_memories: bool) -> Path | None:
    """Archive identity + learned cognition. Returns path, or None if nothing
    needed archiving. Raises RuntimeError if an archive was needed and failed."""
    members = []
    for name in KEEP_NAMES:
        if name == "brain_state" and purge_memories:
            continue
        p = ROOT / name
        if p.exists():
            members.append((p, name))
    # OUTSIDE the guard above — see module docstring.
    if COGNITION.is_dir():
        members.append((COGNITION, ".leon"))

    if not members:
        return None

    stamp = time.strftime("%Y%m%d-%H%M%S")
    archive = HOME / f"sabr-si-identity-{stamp}.tar.gz"
    say("")
    say("Saving identity before removing anything...")
    try:
        with tarfile.open(archive, "w:gz") as tar:
            for src, arcname in members:
                tar.add(src, arcname=arcname)
        if archive.stat().st_size == 0:
            raise OSError("archive is empty")
    except (OSError, tarfile.TarError) as e:
        try:
            archive.unlink()
        except OSError:
            pass
        raise RuntimeError(str(e)) from e
    say(f"{G}[OK]{N} {archive}  ({size_of(archive)})")
    return archive


# ── Removal steps ────────────────────────────────────────────────────────

def stop_running(pids, dry):
    if not pids:
        return
    say("Stopping the SI...")
    if dry:
        say(f"  {D}would stop pid(s): {' '.join(map(str, pids))}{N}")
        return
    for pid in pids:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       capture_output=True, timeout=30)
    time.sleep(1)
    still = [p for p in running_pids() if p in pids]
    if still:
        say(f"{Y}[WARN]{N} still running: {' '.join(map(str, still))}"
            f" — remove may leave files behind")
    else:
        say(f"{G}[OK]{N} stopped")


def remove_autostart(has_task, shortcut, dry):
    """MUST run before the tree is deleted.

    A leftover ONLOGON task pointing at a start.bat that no longer exists makes
    Windows pop a console and fail on every single sign-in, forever, for
    software the user uninstalled. That is the Windows twin of the stale
    systemd unit the shell version guards against.
    """
    if has_task:
        if dry:
            say(f"  {D}would remove scheduled task \"{AUTOSTART_TASK}\"{N}")
        else:
            r = subprocess.run(["schtasks", "/delete", "/tn", AUTOSTART_TASK, "/f"],
                               capture_output=True, text=True, timeout=30)
            if r.returncode == 0:
                say(f"{G}[OK]{N} removed auto-start (scheduled task)")
            else:
                say(f"{Y}[WARN]{N} could not remove scheduled task — remove it with: "
                    f"schtasks /delete /tn \"{AUTOSTART_TASK}\" /f")
    if shortcut.exists():
        if dry:
            say(f"  {D}would remove {shortcut}{N}")
        else:
            try:
                shortcut.unlink()
                say(f"{G}[OK]{N} removed auto-start (Startup folder)")
            except OSError as e:
                say(f"{Y}[WARN]{N} could not remove {shortcut}: {e}")


def remove_tree(path: Path, label, dry, state):
    if not path.exists():
        return
    if dry:
        say(f"  {D}would remove {path}  ({size_of(path)}){N}")
        return
    shutil.rmtree(path, ignore_errors=True)
    if path.exists():
        say(f"{R}[FAILED]{N} {path} is still there — check permissions "
            f"(a file may still be open)")
        state["failed"] = True
    else:
        say(f"{G}[OK]{N} removed {label}")


# ── Windows uninstall ────────────────────────────────────────────────────

def uninstall_windows(args) -> int:
    dry = not args.yes
    state = {"failed": False}

    has_task = scheduled_task_exists()
    shortcut = startup_shortcut()
    pids = running_pids()

    say("")
    say(f"{C}Sabr SI — uninstall{N}")
    say(f"  install     {ROOT}  ({size_of(ROOT)})")
    say(f"  cognition   {COGNITION}  "
        f"({size_of(COGNITION) if COGNITION.is_dir() else 'not present'})")
    say(f"  auto-start  "
        f"{'scheduled task' if has_task else ''}"
        f"{' + ' if has_task and shortcut.exists() else ''}"
        f"{'Startup folder' if shortcut.exists() else ''}"
        f"{'none' if not has_task and not shortcut.exists() else ''}")
    say(f"  running     {'yes, pid ' + ' '.join(map(str, pids)) if pids else 'no'}")

    if dry:
        say("")
        say(f"{Y}Dry run — nothing has been removed.{N}")
        say("This is what would happen:")
        if COGNITION.is_dir() or any((ROOT / n).exists() for n in KEEP_NAMES):
            say(f"  {D}would archive identity + learned cognition to "
                f"{HOME}\\sabr-si-identity-<timestamp>.tar.gz{N}")
        stop_running(pids, dry=True)
        remove_autostart(has_task, shortcut, dry=True)
        remove_tree(ROOT, "install tree", True, state)
        remove_tree(COGNITION, "cognition", True, state)
        say("")
        say(f"Run it for real with:  {C}python uninstall.py --yes{N}")
        return 0

    try:
        archive = build_archive(args.purge_memories)
    except RuntimeError as e:
        say("")
        say(f"{R}[STOPPED]{N} Could not write the identity archive: {e}")
        say("Nothing has been removed. Free some space (or pass --purge-memories")
        say("if you genuinely want this SI's memories deleted) and run this again.")
        return 1

    stop_running(pids, dry=False)
    remove_autostart(has_task, shortcut, dry=False)
    remove_tree(COGNITION, f"{COGNITION} (learned skills, lessons, reflections)",
                False, state)
    # The install tree last: this file lives inside it, and on Windows a
    # directory cannot be removed while it is any process's cwd.
    os.chdir(HOME)
    remove_tree(ROOT, str(ROOT), False, state)

    say("")
    say(f"{C}Left behind, on purpose:{N}")
    if archive:
        say(f"  · {G}{archive}{N} — this SI's identity and memories.")
        say(f"    {D}Delete it yourself when you are sure.{N}")
    say(f"  · {D}Python, Node and your Claude Code login — shared with the rest of{N}")
    say(f"    {D}your machine and may predate this product. Remove Claude Code{N}")
    say(f"    {D}yourself with:  npm rm -g @anthropic-ai/claude-code{N}")

    if state["failed"]:
        say("")
        say(f"{Y}Finished with problems — see [FAILED] above.{N}")
        return 1
    say("")
    say(f"{G}Done.{N}")
    return 0


# ── Entry ────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--purge-memories", action="store_true")
    ap.add_argument("--remove-claude-code", action="store_true")
    args = ap.parse_args()

    if SYSTEM == "Windows":
        return uninstall_windows(args)

    sh = ROOT / "uninstall.sh"
    if not sh.exists():
        say(f"{R}[ERROR]{N} {sh} is missing — cannot uninstall on {SYSTEM}.")
        return 1
    cmd = ["bash", str(sh)]
    if args.yes:
        cmd.append("--yes")
    if args.purge_memories:
        cmd.append("--purge-memories")
    if args.remove_claude_code:
        cmd.append("--remove-claude-code")
    return subprocess.run(cmd).returncode


if __name__ == "__main__":
    sys.exit(main())
