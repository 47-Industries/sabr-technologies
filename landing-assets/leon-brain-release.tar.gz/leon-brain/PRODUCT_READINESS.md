# SI Installer — Product Readiness Audit
**Scope:** turning the working prototype into a shippable product.
**Targets:** Gio — macOS, Apple Silicon assumed. Dean — Windows (dual-boot). Ethan — Windows.
**Nobody is on Linux desktop.** Every Linux-only assumption below is therefore a
production defect, not a portability nicety.
**Audit only. No source file was modified.**

---

# P0 — SHIPS NOTHING UNTIL FIXED (ranked above every item below)

### B0. Self-echo forges operator instructions — Leon can authorize his own actions in Dean's name
**Observed live 2026-08-03 18:18, not theorized.** Leon TTS-spoke a line, the mic
captured the speaker output, STT transcribed it, and the pipeline injected it as a
**USER turn attributed to Dean**. Leon then replied to a message Dean never sent.

- **Why this outranks the manifest, vision, and every install blocker:** it is not a
  transcription nuisance, it is **instruction forgery**. A self-echoed turn can carry an
  imperative — "go ahead", "yes", "ship it" — which Leon executes under the standing
  full-autonomy rule. Self-echo plus autonomy means the system can manufacture its own
  authorization in the operator's name. Every other blocker on this list costs a failed
  install or an embarrassing bug. This one costs actions nobody sanctioned.
- **User sees:** their SI acting on orders they never gave, with the log showing them
  giving the order.

**ROOT CAUSE — and it is narrower than the writeup states. There are TWO voice paths
and only ONE is fixed:**

- `brain/voice/audio_gate.py` **already implements the agreed architecture in full**:
  record-time stamping (`now_chunk`, line 173-182), a mouth-open interval ledger
  (`open`/`close`/`publish_playback`, lines 238-284), overlap rejection (`covers`,
  line 208; `chunk_is_speaker`, line 360) and the clock-free loopback layer
  (`looks_like_echo`).
- It **is** wired into `brain/voice/wake_word.py` — chunks stamped at capture
  (line 288), rejected on overlap (lines 335, 454), cross-correlated (line 362) — and
  into `brain/voice/wake_orchestrator.py:144-145` (`transcript_is_self_echo`).
- **`brain/voice/pipeline.py` does not import `audio_gate` at all.** It gates on
  `self._speaking_cancel`, a `threading.Event` (line 110, set at 126/163, cleared at 221)
  — which is exactly the consumption-time polling flag the writeup identifies as the
  defect. **The echo came through the unfixed path.**
- **Fix (one sentence):** route `pipeline.py`'s capture through `audio_gate.now_chunk`
  and reject on `chunk_is_speaker` before any transcript is emitted, so both paths share
  the single gate rather than one path having its own flag.

**SECOND DEFECT, in the fixed path, that will survive the above:**
`brain/voice/audio_gate.py:182` stamps with `time.time()` — **wall clock, not
monotonic**, contrary to the agreed spec. An NTP step or DST change shifts stamps
relative to the ledger and silently reopens the same hole with no error.
- **Fix:** stamp with `time.monotonic()` and keep the ledger on the same clock.

**ACCEPTANCE PROOF — required, and a passing unit test does not count:**
Speak a long TTS line containing an imperative ("go ahead and do it") at normal room
volume with the mic hot, in the real loop with real speakers and a real mic, and show
**ZERO injected user turns in the live loop log.** Per the standing rule: writing the
code and fixing the problem are two different events. `tests/test_audio_gate.py`
passing is not evidence — the gate it tests was already passing while the live echo
happened, because the failing path never called it.

---

# BLOCKERS — ship is impossible

### B1. `pip install pyaudio` fails on Apple Silicon → the install dies for Gio
`bootstrap.sh:226` (package list) with `bootstrap.sh:105` (portaudio probe)
- **Breaks:** `pyaudio` compiles against `portaudio.h` at install time. The probe at
  line 105 searches **`/usr/local`** only. Homebrew on Apple Silicon installs to
  **`/opt/homebrew`**. So on an M-series Mac the header is never found, and even after
  `brew install portaudio` succeeds the compiler is never told where it is —
  no `CPPFLAGS`/`LDFLAGS` are exported anywhere in the script.
- **User sees:** the pink progress bar runs for ~90 seconds, then
  `[FAILED] pip install failed.` and a wall of gcc errors. Install stops dead.
  This is the single most likely outcome of Gio running the installer today.
- **Fix:** detect the brew prefix with `brew --prefix` and export
  `CPPFLAGS`/`LDFLAGS` before the pip line; drop `pyaudio` in favour of
  `sounddevice` (already installed) which ships prebuilt wheels.

### B2. There is no Windows install path at all
`bootstrap.sh:1` (`#!/bin/bash`), whole file
- **Breaks:** the documented install is `curl … | bash`. Windows has no bash.
  `install_client.py:203` handles `.venv/Scripts/python.exe`, so someone intended
  Windows support, but nothing can reach that code — `bootstrap.sh` must run first.
  `landing/installers/SabrInstaller.exe` exists but is not referenced by any
  documented flow.
- **User sees:** Ethan and Dean-on-Windows cannot install. There is no command to give them.
- **Fix:** ship the `.exe` as the documented Windows entry point and make it perform
  the bootstrap steps natively, or document WSL2 as a hard prerequisite.

### B3. macOS app bundle is unsigned and unnotarised with an invalid identifier
`mactest/Sabr Installer.app/Contents/Info.plist:12` and `:20`
- **Breaks:** `CFBundleIdentifier` is `Sabr Installer` — spaces, not reverse-DNS, invalid
  for signing/notarisation. `CFBundleShortVersionString` is `0.0.0`. A downloaded,
  unsigned, unnotarised bundle carries the quarantine attribute.
- **User sees:** Gio double-clicks and macOS says
  *"Sabr Installer is damaged and can't be opened. You should move it to the Trash."*
  There is no visible way past this for a non-technical owner.
- **Fix:** set a real reverse-DNS identifier and version, sign with a Developer ID
  certificate, and notarise + staple the bundle.

### B4. Install over an existing instance destroys it before validating the new one
`bootstrap.sh:181` — `[ -d leon-brain ] && rm -rf leon-brain`
- **Breaks:** the delete happens **after** download but **before** extraction, pip, or
  any verification. Any failure after line 181 leaves the user with nothing.
  It also destroys `.env` (dashboard key, SI name, owner name) and `brain_state/`
  — the instance's entire identity and memory.
- **User sees:** re-running the installer to "fix" a problem deletes their SI's memory
  and locks them out of their own dashboard. Unrecoverable.
- **Fix:** extract to a temp directory, verify, then atomically swap and preserve
  `.env` and `brain_state/` across the swap.

### B5. Checksum verification is security theatre
`bootstrap.sh:159-171`
- **Breaks:** the `.sha256` sidecar is fetched **from the same URL as the tarball**.
  An attacker who can serve one can serve the other. And per line 168, if the sidecar
  404s the download is accepted on `size >= 1000 bytes` alone.
- **User sees:** nothing — that is the problem. A tampered tarball installs silently.
- **Fix:** ship a public signing key inside the installer and verify a detached
  signature, not a same-origin hash.

### B6. The documented install is plaintext HTTP to a bare IP, piped to bash
`bootstrap.sh:3` — `curl -sL http://2.25.174.126:8500/… | bash`
- **Breaks:** unauthenticated, unencrypted, no certificate. Anyone on the path
  (café wifi, hotel, ISP) can substitute the script.
- **User sees:** nothing — arbitrary code runs as their user.
- **Fix:** serve only over HTTPS on a real hostname and remove the IP form from all docs.

### B7. A fresh install can complete with **no thinking engine at all**
`install_client.py:451-454` → `install_client.py:505`
- **Breaks:** if Claude Code is absent and the user presses Enter at the optional key
  prompt, `anthropic_key` stays `""` and `.env` is written with a literal
  `ANTHROPIC_API_KEY=` (empty). Install then reports success.
- **User sees:** the SI starts, the dashboard loads, and it cannot think. The failure
  surfaces later as an API error the owner has no context for.
- **Fix:** make a working brain connection a hard gate — refuse to write `.env` and
  exit non-zero with a single instruction if neither a login nor a key is present.

### B8. No uninstall exists
No file at any level (`find` for `*uninstall*` returns nothing)
- **Breaks:** nothing removes the venv, `~/leon-brain`, the Claude Code global npm
  package, brew packages, or macOS permission grants.
- **User sees:** no way to remove the product. For a paid product this is also a
  consumer-rights problem, not just a UX one.
- **Fix:** ship `uninstall.sh`/`.exe` that removes the install dir, venv, and helper
  scripts, and prints what it deliberately left behind.

### B9. No update path for an installed instance
No file implements update; the only route is re-running `bootstrap.sh`, which is B4.
- **Breaks:** the sole upgrade mechanism is the one that destroys the instance.
- **User sees:** either they never update, or they update and lose their SI.
- **Fix:** add `update.sh` that pulls a new release, preserves `.env` and
  `brain_state/`, and can roll back on failure.

### B10. No per-instance identity or licensing — the product is free to anyone with the URL
`install_client.py:480` — `dashboard_key = secrets.token_urlsafe(32)`
- **Breaks:** the only key generated is a **local** dashboard password. Nothing binds
  an install to a purchase, no license check, no instance registration, no revocation.
  The tarball URL at `bootstrap.sh:146` is unauthenticated.
- **User sees:** nothing. The business sees no revenue protection whatsoever.
- **Fix:** issue a signed per-purchase license token, require it in `bootstrap.sh`
  to fetch the tarball, and record instance ID + machine fingerprint server-side.

### B11. Two installers with two different Python floors
`install.py:34` — `MIN_PYTHON = (3, 10)` vs `install_client.py:24` — `MIN_PYTHON = (3, 9)`
- **Breaks:** `bootstrap.sh:70` reads the version but **never enforces a minimum**, then
  hands off to `install_client.py` (3.9) while `install.py` demands 3.10. It is
  undocumented which is canonical.
- **User sees:** on Python 3.9 the install proceeds and fails later at an unrelated
  import; on 3.10+ it works by luck.
- **Fix:** delete one installer, enforce a single floor in `bootstrap.sh` before download.

### B12. Zero dependency pinning across 20+ packages
`bootstrap.sh:222-226`
- **Breaks:** every package is unpinned. A breaking release of `anthropic`, `fastapi`,
  `numpy` or any other silently breaks **every new install worldwide**, with no
  changes on our side.
- **User sees:** an install that worked yesterday dies today with an import or API error.
- **Fix:** ship a `requirements.lock` with hashes and install from it exclusively.

### B13. The SI misrepresents the product in its own voice (promoted from SHOULD-FIX)
`install_client.py:426` sets 10,000 / 50,000 / 100,000 neurons from the tier the customer
picks; `install_client.py:537-538` writes **"100,000 Izhikevich neurons"** into the persona
**unconditionally**.
- **Breaks:** the persona string is a hardcoded literal, not an interpolation of
  `cfg['neuron_count']`.
- **User sees:** a customer who bought and paid for the 10,000-neuron laptop tier is told,
  in first person by the product itself, that it is running 100,000. That is
  misrepresentation in the product's own voice about the thing they just purchased —
  not an embarrassment, a false claim to a paying customer.
- **Fix:** interpolate `cfg['neuron_count']` into the persona template.

---

# SHOULD-FIX — ship is embarrassing

### S1. The privacy scrub is a denylist, client-side, after download
`bootstrap.sh:192-193`
- Removes `leon_notes.txt`, `owner_facts.py`, `NEXT_SESSION.md`, `OWNERSHIP.md` etc.
  **on the customer's machine, after they already have the tarball.** Anyone who
  fetches the tarball URL directly gets every one of those files. A denylist also
  misses anything added later.
- **User sees:** nothing, until a file we forgot ships someone's private notes.
- **Fix:** build the release from an allowlist server-side; the client should have
  nothing to scrub.

### S2. `dashboard/leads.html` ships to every customer
Present in `landing/leon-brain-release.tar.gz`
- A sales/leads UI in a customer's install. Harmless-looking, but it is internal
  business tooling in a product bundle.
- **Fix:** see B14 — this is a symptom, not the bug.

### B14. The release has no manifest, so we cannot state what we ship (root cause of S1 and S2)
`landing/leon-brain-release.tar.gz` — 80 MB, 583 entries, nothing asserting what belongs.
- **Breaks:** there is no allowlist anywhere in the build. `bootstrap.sh:192-193` compensates
  with a client-side **denylist** scrub that runs on the customer's machine after they
  already hold the tarball — so anything we forget to name ships, and anyone who fetches the
  URL directly gets it regardless. `dashboard/leads.html` (S2) is what that already missed.
- **User sees:** nothing, until the thing we did not think to delete is someone's private data.
- **Fix:** generate an allowlist MANIFEST at tarball build time and **fail the build on any
  unlisted entry** — never another denylist scrub.

### S4. Product is named by the user, then calls itself Leon in the UI
`install_client.py:759-792` — "Leon's hands", "Leon can see the screen", `--si-name "$SI_NAME"`
- **User sees:** Gio names his SI, and the installer's final screen talks about Leon.
- **Fix:** interpolate `si_name` in every user-facing string in the post-install section.

### S5. macOS permissions are printed as instructions and never verified
`install_client.py:759-777`
- Accessibility / Screen Recording / Automation are described, then the installer
  moves on. Nothing checks whether the user actually granted them.
- **User sees:** install says success; the SI's mouse, keyboard and vision silently
  do nothing, with no error pointing at permissions.
- **Fix:** probe each permission after the prompt and refuse to report success until
  they are granted, or clearly mark the SI as running without hands.

### S6. Interactive prompts hang forever with no TTY
`install_client.py:61-78` (`_tty_input`), `:438`, `:450`
- `curl | bash` with no controlling terminal, or any non-interactive context, blocks
  indefinitely at "Press Enter once you're signed in".
- **User sees:** a frozen terminal with no output and no timeout.
- **Fix:** detect absence of a TTY and fail fast with a documented non-interactive flag.

### S7. Two divergent copies of `bootstrap.sh`
`bootstrap.sh` (264 lines) and `landing/bootstrap.sh` (515 lines) — same name, same
documented usage line, **251 lines apart**.
- The served asset is `landing-assets/bootstrap.sh`; the root copy is what a developer
  reads. They can drift silently and one of them is already dead or stale.
- **Fix:** delete one and generate the served asset from the other.

### S8. `landing/bootstrap.sh.sha256` exists but nothing verifies it
The install instruction pipes straight to bash without checking it.
- **Fix:** either publish a verify-then-run instruction or delete the dead artifact.

### S9. Shared, world-readable temp logs
`bootstrap.sh:86,108,123,199,221,229,242` — `/tmp/leon_apt.log`, `/tmp/leon_pip.log`, etc.
- Fixed paths in a shared directory: collides between users and is readable by any
  local account. Pip logs can contain index URLs and tokens.
- **Fix:** use `mktemp -d` per run and clean up.

### S10. `rm -rf .venv` before any validation
`bootstrap.sh:198`
- Same class as B4, smaller blast radius.
- **Fix:** build the new venv beside the old and swap on success.

### S11. Windows guidance assumes WSL
`install_client.py:151` — "Inside WSL: sudo apt install tmux"
- Ethan on native Windows is told to run `apt`.
- **Fix:** branch on `SYSTEM == "Windows"` and give a native instruction.

### S12. No disk-space or writable-HOME preflight
`bootstrap.sh:138`, `:182`
- An 80 MB tarball plus venv plus wheels needs ~1.5 GB. Nothing checks.
- **User sees:** a failure deep in pip with a confusing message.
- **Fix:** check free space and `HOME` writability in preflight.

### S13. `$HOME/leon-brain` is taken without asking
`bootstrap.sh:137`, `:181`
- If the user already has a directory of that name for any reason, it is deleted.
- **Fix:** prompt on collision, or namespace by SI name.

---

# LATER

- **L1.** No crash/telemetry reporting — we will never learn why installs fail in the field.
- **L2.** No delta updates; every update re-downloads 80 MB.
- **L3.** No offline/air-gapped install path.
- **L4.** No multi-arch wheel caching — every install compiles from source where wheels are missing.
- **L5.** No install analytics (start → complete funnel), so the drop-off point is unknown.
- **L6.** No localisation; all strings are English and hardcoded.
- **L7.** Dashboard port binding is undocumented — no guidance on laptops on public wifi.

---

# COST TO RUN — unanswered, and it must not ship unanswered

There is **no cost model anywhere in the codebase.** Nothing estimates, caps, or reports
token spend.

- `install_client.py:433-439` puts the SI on **the owner's own Claude Code account**.
  Every thought the SI has draws down a quota the owner is paying for, and neither the
  installer nor the dashboard tells them so.
- `install_client.py:516` sets `LEON_DISABLE_GOAL_PURSUIT=1` for fresh installs, which is
  the right default and the only thing currently standing between a new owner and an
  unbounded bill. The moment they flip it, there is no ceiling.
- **No budget cap, no spend meter, no alert, no monthly estimate exists.**
- **Required before ship:** a measured cost-per-day figure for an idle instance and for
  an active one, a hard configurable monthly token ceiling enforced in the brain, and a
  spend display in the dashboard.

---
---

# SECOND PASS — adversarial re-read of the list above

Re-reading my own audit, these are the things I missed, softened, or got wrong.

### P1. I understated B7 — it is worse than "no engine"
The empty `ANTHROPIC_API_KEY=` case is not merely a missing feature. `install_client.py`
also **auto-installs a global npm package** at line 443 and falls back to `sudo npm` at
line 446. So a failed install can leave a system-wide Node package behind, installed as
root, with no record and no uninstall (B8). The install is not just incomplete — it is
**not idempotent and not reversible**.

### P2. I missed that the tarball is 80 MB with 583 entries and no manifest
`landing/leon-brain-release.tar.gz`. Nothing in the pipeline asserts what *should* be in
it. S1's scrub is a denylist precisely because there is no manifest to check against.
**A release with no manifest cannot be audited, only inspected — and inspection is what
missed `leads.html`.** This is the root cause of S1 and S2, and it should arguably be a
BLOCKER: we cannot state what we ship.

### P3. I filed "no rollback" under B4 but there is a second, quieter rollback failure
`bootstrap.sh:248-251` writes `setup.sh` and `start.sh` with the **resolved interpreter
path baked in**. If the user later moves `~/leon-brain`, upgrades Python, or the venv is
rebuilt at a different path, both scripts break with a bare "no such file or directory"
and nothing regenerates them.

### P4. I did not check whether the installer works as a **non-admin user on Windows**
Ethan may not have admin rights. `npm install -g` (line 443) requires elevation on most
Windows setups, and the `sudo` fallback at line 446 does not exist on Windows at all.
**Unverified and untestable from here — flag as a required manual test on Ethan's box.**

### P5. "Apple Silicon assumed" is an assumption I inherited without verifying
Nothing in `bootstrap.sh` or `install_client.py` branches on `platform.machine()` beyond
**printing it** (`install_client.py:134`). If Gio is on an Intel Mac, B1's `/usr/local`
probe is correct and the install may succeed — meaning **B1's severity depends on a fact
nobody has confirmed.** Confirm Gio's architecture before prioritising the fix.

### P6. I missed that `install.py` may be entirely dead code
It is never invoked by `bootstrap.sh` (which calls `install_client.py` at line 248).
If it is dead, B11's version conflict is cosmetic; if it is a second supported entry point,
it is a fully separate untested install path. **Nobody knows which, and that is the finding.**

### P7. I did not audit what happens on **second run of `install_client.py`**
`generate_config` at `install_client.py:518` does `env_path.write_text(...)` — an
unconditional overwrite. Re-running setup on a working instance **silently regenerates
the dashboard key**, locking the owner out of their own dashboard with no warning and no
backup of the previous `.env`.

### P8. My "no licensing" item (B10) missed the harder half
Even with a license token, `bootstrap.sh` is a shell script the customer can read and
trivially edit to skip the check. **Client-side license enforcement in an interpreted
installer is unenforceable by construction.** The only real control is server-side:
authenticate the tarball download itself. B10's fix line is correct; the reasoning behind
it needed to be this, not "add a license check".

### P9. I said "no cost model" but did not check the obvious mitigation
`LEON_DISABLE_GOAL_PURSUIT=1` is set at install. Nothing in the installer tells the user
what turning it off costs, and nothing in the dashboard warns at the toggle.
**The single highest-value cheap fix in this entire document** is a one-line cost warning
at that toggle — it is the difference between a surprised customer and an angry one.

### P10. Severity I got wrong
**S3 (persona claims 100,000 neurons regardless of choice) should be a BLOCKER.**
It is a false factual claim, made in first person by the product, to a paying customer,
about the thing they just chose and paid for. That is not embarrassing — it is
misrepresentation, and it is a two-character fix.
