// Auth bootstrap — included by all dashboard pages so fetch+WebSocket
// carry the LEON_API_KEY token automatically. Sourced from URL fragment
// (#key=XXX), then cached in sessionStorage.
(function() {
    var hashMatch = location.hash.match(/[#&]key=([^&]+)/);
    if (hashMatch) {
        sessionStorage.setItem("leon_key", hashMatch[1]);
        history.replaceState(null, "", location.pathname + location.search);
    }
    var TOKEN = sessionStorage.getItem("leon_key") || "";
    window.__LEON_KEY = TOKEN;
    if (!TOKEN) {
        var k = prompt("Leon API key required. Paste it below:");
        if (k) {
            sessionStorage.setItem("leon_key", k.trim());
            window.__LEON_KEY = k.trim();
        }
    }

    var _origFetch = window.fetch;
    window.fetch = function(input, init) {
        init = init || {};
        init.headers = new Headers(init.headers || {});
        if (window.__LEON_KEY && !init.headers.has("Authorization")) {
            init.headers.set("Authorization", "Bearer " + window.__LEON_KEY);
        }
        return _origFetch.call(this, input, init).then(function(r) {
            if (r.status === 401) {
                sessionStorage.removeItem("leon_key");
                var k = prompt("Leon API key invalid. Paste a fresh one:");
                if (k) {
                    sessionStorage.setItem("leon_key", k.trim());
                    window.__LEON_KEY = k.trim();
                    init.headers.set("Authorization", "Bearer " + window.__LEON_KEY);
                    return _origFetch.call(this, input, init);
                }
            }
            return r;
        });
    };

    window.wsURL = function(path) {
        var proto = location.protocol === "https:" ? "wss" : "ws";
        var sep = path.indexOf("?") >= 0 ? "&" : "?";
        return proto + "://" + location.host + path + sep + "key=" + encodeURIComponent(window.__LEON_KEY || "");
    };
})();
