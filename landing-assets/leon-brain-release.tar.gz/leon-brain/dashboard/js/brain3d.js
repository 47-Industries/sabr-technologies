/**
 * Brain3D v3 — "Neural Field"
 *
 * Rewritten 2026-08-16 (second pass, same day). v2 was a labelled anatomy
 * diagram: 18 named nodes, a legend box, a pathway toggle, a text label per
 * region. Dean's note was that nobody talking to an SI wants to read a
 * diagram — they want to look at a mind. Closer to a living network of
 * interconnecting light than a textbook figure.
 *
 * So v3 deletes every piece of chrome and puts the neurons back in charge:
 *
 *   1. NO labels, NO legend, NO region box, NO buttons. All prior DOM from
 *      v1/v2 is actively removed on construct so a cached page can't leave
 *      a ghost box behind.
 *   2. The 100k neurons are the subject again — but on a GPU shader, so
 *      brightness is per-neuron and firing is expressed as INDIVIDUAL cells
 *      flashing, not as one region-wide blob of alpha. When a region is hot,
 *      more of its neurons spike per second and you see the area light up
 *      because the density of flashes rises. That's real information.
 *   3. Point SIZE is fixed. v1's glob came from scaling size by firing; a
 *      shader can raise brightness to infinity without ever making a sprite
 *      wide enough to swallow its neighbours.
 *   4. ~2,600 synaptic filaments woven through the cloud — short local ones
 *      inside each region, long ones following the REAL connectome. This is
 *      what makes it read as a network instead of a nebula.
 *   5. Colour is still per-region (18 distinct hues) so structure is legible
 *      by eye without a single word on screen.
 *
 * Public API unchanged: new Brain3D(container), .initNeurons(positions),
 * .updateState(state), .animate(dt), .scene, .time
 */
import * as THREE from 'three';
import { OrbitControls   } from 'three/addons/controls/OrbitControls.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { EffectComposer  } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass      } from 'three/addons/postprocessing/RenderPass.js';

// ── 18 regions, 18 hues. No lobe grouping any more — grouping only existed
//    to keep a legend short, and there is no legend. Hues are spread around
//    the wheel and kept apart in luminance so neighbours never read as one.
const REGIONS = {
    prefrontal_cortex:    { pos: [-0.52,  1.00,  0.24], color: 0xff3d6e },
    anterior_cingulate:   { pos: [ 0.14,  0.72, -0.02], color: 0xff6a3d },
    motor_cortex:         { pos: [ 0.52,  0.92,  0.22], color: 0xffa62c },
    broca:                { pos: [-0.86,  0.48,  0.34], color: 0xffe14d },

    parietal_association: { pos: [ 0.34,  0.22,  0.52], color: 0x9dff4d },
    somatosensory_cortex: { pos: [ 0.68,  0.46,  0.50], color: 0x4dff86 },

    temporal_association: { pos: [-1.02, -0.06, -0.02], color: 0x2fffc4 },
    auditory_cortex:      { pos: [ 1.02, -0.06,  0.04], color: 0x2fe6ff },
    wernicke:             { pos: [-0.74, -0.40,  0.34], color: 0x3daaff },

    visual_cortex:        { pos: [ 0.04, -0.92,  0.18], color: 0x5a7bff },

    hippocampus:          { pos: [-0.44, -0.36, -0.12], color: 0x9d6bff },
    amygdala:             { pos: [ 0.38, -0.12, -0.34], color: 0xd14dff },
    insula:               { pos: [ 0.56,  0.10, -0.30], color: 0xff4dd8 },

    thalamus:             { pos: [ 0.04,  0.06,  0.00], color: 0xf2f6ff },
    basal_ganglia:        { pos: [ 0.26,  0.28, -0.14], color: 0xc9a0ff },
    default_mode_network: { pos: [-0.14,  0.32,  0.16], color: 0x7fd4ff },

    cerebellum:           { pos: [ 0.10, -0.80, -0.46], color: 0x00d1a0 },
    brainstem:            { pos: [ 0.00, -0.58, -0.62], color: 0xff8a5c },
};

const REGION_NAMES  = Object.keys(REGIONS);
const REGION_LAYOUT = {};
const REGION_COLORS = {};
REGION_NAMES.forEach((k) => {
    REGION_LAYOUT[k] = { x: REGIONS[k].pos[0], y: REGIONS[k].pos[1], z: REGIONS[k].pos[2] };
    REGION_COLORS[k] = REGIONS[k].color;
});

// ── The REAL 48 edges, verbatim from BrainConfig.CONNECTIVITY.
const CONNECTIONS = [
    ['visual_cortex', 'thalamus'],
    ['auditory_cortex', 'thalamus'],
    ['somatosensory_cortex', 'thalamus'],
    ['thalamus', 'visual_cortex'],
    ['thalamus', 'auditory_cortex'],
    ['thalamus', 'somatosensory_cortex'],
    ['thalamus', 'motor_cortex'],
    ['thalamus', 'prefrontal_cortex'],
    ['visual_cortex', 'temporal_association'],
    ['auditory_cortex', 'temporal_association'],
    ['somatosensory_cortex', 'parietal_association'],
    ['visual_cortex', 'parietal_association'],
    ['parietal_association', 'prefrontal_cortex'],
    ['temporal_association', 'prefrontal_cortex'],
    ['prefrontal_cortex', 'parietal_association'],
    ['prefrontal_cortex', 'temporal_association'],
    ['parietal_association', 'hippocampus'],
    ['temporal_association', 'hippocampus'],
    ['hippocampus', 'parietal_association'],
    ['hippocampus', 'temporal_association'],
    ['hippocampus', 'prefrontal_cortex'],
    ['amygdala', 'prefrontal_cortex'],
    ['amygdala', 'hippocampus'],
    ['amygdala', 'insula'],
    ['amygdala', 'anterior_cingulate'],
    ['prefrontal_cortex', 'amygdala'],
    ['anterior_cingulate', 'prefrontal_cortex'],
    ['prefrontal_cortex', 'anterior_cingulate'],
    ['anterior_cingulate', 'basal_ganglia'],
    ['insula', 'prefrontal_cortex'],
    ['insula', 'anterior_cingulate'],
    ['wernicke', 'broca'],
    ['wernicke', 'temporal_association'],
    ['broca', 'motor_cortex'],
    ['temporal_association', 'wernicke'],
    ['prefrontal_cortex', 'basal_ganglia'],
    ['basal_ganglia', 'thalamus'],
    ['motor_cortex', 'cerebellum'],
    ['motor_cortex', 'brainstem'],
    ['cerebellum', 'motor_cortex'],
    ['cerebellum', 'brainstem'],
    ['brainstem', 'thalamus'],
    ['brainstem', 'prefrontal_cortex'],
    ['default_mode_network', 'prefrontal_cortex'],
    ['default_mode_network', 'parietal_association'],
    ['default_mode_network', 'temporal_association'],
    ['prefrontal_cortex', 'default_mode_network'],
    ['parietal_association', 'default_mode_network'],
];

const EDGE_SEGMENTS   = 24;
const MAX_PULSES      = 300;
const LOCAL_FILAMENTS = 70;   // per region
const LONG_FILAMENTS  = 34;   // per connectome edge

// ─────────────────────────────────────────────────────────────────────────
// Shaders. The whole point of moving to GLSL: firing raises BRIGHTNESS and
// spike PROBABILITY, never geometry size. A region can go to 100% and still
// occupy exactly the pixels it occupied at rest — it just burns hotter and
// more of its cells flash. That is structurally incapable of becoming a glob.
// ─────────────────────────────────────────────────────────────────────────

const NEURON_VERT = `
    attribute float aFire;     // 0..1, this neuron's region activity
    attribute float aSeed;     // per-neuron random, fixes flash phase
    attribute vec3  aColor;
    uniform float uTime;
    uniform float uSize;
    uniform float uDpr;
    varying vec3  vCol;
    varying float vAlpha;

    void main() {
        // Each neuron owns a private oscillator. Firing lowers the threshold
        // it has to cross to flash, so a hot region flashes far more often
        // per second — density of flashes IS the readout.
        float ph     = fract(aSeed * 13.137 + uTime * (0.28 + aSeed * 1.15));
        float thresh = 1.0 - clamp(aFire * 1.9, 0.0, 0.88);
        float spike  = smoothstep(thresh, 1.0, ph);
        spike        = spike * spike;

        float base = 0.10 + aFire * 0.30;
        vCol   = aColor * (base + spike * (0.55 + aFire * 2.1));
        vAlpha = clamp(0.055 + aFire * 0.20 + spike * 0.80, 0.0, 1.0);

        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        // Size is CONSTANT in world terms; only a flash nudges it, and only
        // by a bounded amount. No path from firing to an unbounded sprite.
        gl_PointSize = uSize * uDpr * (1.0 + spike * 0.9) / max(0.05, -mv.z);
        gl_Position  = projectionMatrix * mv;
    }
`;

const NEURON_FRAG = `
    precision mediump float;
    varying vec3  vCol;
    varying float vAlpha;
    void main() {
        vec2 d = gl_PointCoord - vec2(0.5);
        float r2 = dot(d, d);
        if (r2 > 0.25) discard;
        float a = smoothstep(0.25, 0.0, r2);
        gl_FragColor = vec4(vCol, vAlpha * a * a);
    }
`;

const FIL_VERT = `
    attribute float aFire;
    attribute float aSeed;
    attribute vec3  aColor;
    uniform float uTime;
    varying vec3  vCol;
    varying float vAlpha;
    void main() {
        // Filaments shimmer — a slow travelling brightness so the web looks
        // like it's conducting rather than sitting there as static wire.
        float w = 0.5 + 0.5 * sin(uTime * 1.3 + aSeed * 24.0);
        float b = 0.20 + aFire * 1.5 + w * (0.06 + aFire * 0.55);
        vCol   = aColor * b;
        vAlpha = clamp(0.020 + aFire * 0.34 + w * aFire * 0.30, 0.0, 1.0);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
`;

const FIL_FRAG = `
    precision mediump float;
    varying vec3  vCol;
    varying float vAlpha;
    void main() { gl_FragColor = vec4(vCol, vAlpha); }
`;

function radialTexture(inner, mid) {
    const size = 64;
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const ctx = c.getContext('2d');
    const h = size / 2;
    const g = ctx.createRadialGradient(h, h, 0, h, h, h);
    g.addColorStop(0,    `rgba(255,255,255,${inner})`);
    g.addColorStop(0.25, `rgba(255,255,255,${mid})`);
    g.addColorStop(0.6,  'rgba(255,255,255,0.06)');
    g.addColorStop(1,    'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    const t = new THREE.CanvasTexture(c);
    t.needsUpdate = true;
    return t;
}

export class Brain3D {
    constructor(container) {
        this.container    = container;
        this.time         = 0;
        this.regionMeshes = {};   // kept non-null for API compat with index.html
        this.regionGlows  = {};
        this.regionData   = {};
        this.labels       = {};   // permanently empty — no labels in v3
        this.nodes        = {};
        this.lastState    = null;
        this.graphView    = true;
        this.regionFiring = {};
        this.smoothFiring = {};
        this.edgeFlow     = {};
        this.selected     = null;
        this.neuronPoints = null;
        this.filaments    = null;
        this._ranges      = {};   // region → [start, end) vertex range

        REGION_NAMES.forEach((n) => { this.regionFiring[n] = 0; this.smoothFiring[n] = 0; });

        // Kill any chrome a cached v1/v2 left in the DOM. Dean specifically
        // called out the box in the corner — this guarantees it cannot come
        // back from a stale module instance or a hot reload.
        this._purgeLegacyChrome();

        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x02040a);
        this.scene.fog = new THREE.FogExp2(0x02040a, 0.09);

        this.camera = new THREE.PerspectiveCamera(
            50, window.innerWidth / window.innerHeight, 0.01, 100);
        this.camera.position.set(0.3, 0.25, 3.4);

        this.renderer = new THREE.WebGLRenderer({
            antialias: true, alpha: true, powerPreference: 'high-performance',
            failIfMajorPerformanceCaveat: false,
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.05;
        container.appendChild(this.renderer.domElement);

        const canvas = this.renderer.domElement;
        this._contextLost = false;
        canvas.addEventListener('webglcontextlost', (e) => {
            e.preventDefault();
            console.warn('[Brain3D] WebGL context lost');
            this._contextLost = true;
        });
        canvas.addEventListener('webglcontextrestored', () => {
            console.log('[Brain3D] WebGL context restored');
            this._contextLost = false;
            this.renderer.setSize(window.innerWidth, window.innerHeight);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
            this.renderer.toneMappingExposure = 1.05;
        });

        this.composer = new EffectComposer(this.renderer);
        this.composer.addPass(new RenderPass(this.scene, this.camera));
        // Strength up, radius tight, threshold high: only actual spikes bloom.
        this.bloomPass = new UnrealBloomPass(
            new THREE.Vector2(window.innerWidth, window.innerHeight),
            0.85, 0.42, 0.62);
        this.composer.addPass(this.bloomPass);

        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping   = true;
        this.controls.dampingFactor   = 0.06;
        this.controls.rotateSpeed     = 0.62;
        this.controls.zoomSpeed       = 0.75;
        this.controls.autoRotate      = true;
        this.controls.autoRotateSpeed = 0.22;
        this.controls.target.set(0, 0.05, 0);
        this.controls.minDistance = 1.2;
        this.controls.maxDistance = 12;
        this.controls.addEventListener('start', () => {
            this.controls.autoRotate = false;
            clearTimeout(this._spinTimer);
        });
        this.controls.addEventListener('end', () => {
            clearTimeout(this._spinTimer);
            this._spinTimer = setTimeout(() => { this.controls.autoRotate = true; }, 6000);
        });

        this.pulseTex = radialTexture(1.0, 0.55);

        this._buildEdges();
        this._initPulses();
        this._buildSeedCloud();   // placeholder until real neurons arrive

        window.addEventListener('resize', () => this._onResize());
    }

    // Remove every DOM element older versions bolted onto <body>.
    _purgeLegacyChrome() {
        ['region-labels', 'lobe-legend', 'graph-view-btn', 'brain-legend',
         'region-info-panel'].forEach((id) => {
            const el = document.getElementById(id);
            if (el && el.parentNode) el.parentNode.removeChild(el);
        });
        document.querySelectorAll('.region-label-3d').forEach((el) => {
            if (el.parentNode) el.parentNode.removeChild(el);
        });
    }

    // ===================== NEURON FIELD =====================

    _makeNeuronMaterial() {
        return new THREE.ShaderMaterial({
            uniforms: {
                uTime: { value: 0 },
                uSize: { value: 2.1 },
                uDpr:  { value: Math.min(window.devicePixelRatio, 2) },
            },
            vertexShader:   NEURON_VERT,
            fragmentShader: NEURON_FRAG,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            depthTest: true,
        });
    }

    // Before the socket delivers real neuron positions, show a synthetic
    // cloud with the same shape so the screen is never an empty void.
    _buildSeedCloud() {
        const per = 900;
        const total = REGION_NAMES.length * per;
        const pos = new Float32Array(total * 3);
        const col = new Float32Array(total * 3);
        const fir = new Float32Array(total);
        const sed = new Float32Array(total);
        let i = 0;
        const c = new THREE.Color();
        for (const name of REGION_NAMES) {
            const l = REGION_LAYOUT[name];
            c.set(REGION_COLORS[name]);
            const start = i;
            for (let k = 0; k < per; k++, i++) {
                const r = 0.20 * Math.cbrt(Math.random());
                const th = Math.random() * Math.PI * 2;
                const ph = Math.acos(2 * Math.random() - 1);
                pos[i * 3]     = l.x + r * Math.sin(ph) * Math.cos(th);
                pos[i * 3 + 1] = l.y + r * Math.sin(ph) * Math.sin(th);
                pos[i * 3 + 2] = l.z + r * Math.cos(ph);
                col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
                sed[i] = Math.random();
            }
            this._ranges[name] = [start, i];
        }
        this._installNeurons(pos, col, fir, sed);
        this._buildFilaments();
    }

    _installNeurons(pos, col, fir, sed) {
        if (this.neuronPoints) {
            this.scene.remove(this.neuronPoints);
            this.neuronPoints.geometry.dispose();
            this.neuronPoints.material.dispose();
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        geo.setAttribute('aColor',   new THREE.BufferAttribute(col, 3));
        geo.setAttribute('aFire',    new THREE.BufferAttribute(fir, 1));
        geo.setAttribute('aSeed',    new THREE.BufferAttribute(sed, 1));
        this.neuronPoints = new THREE.Points(geo, this._makeNeuronMaterial());
        this.neuronPoints.frustumCulled = false;
        this.scene.add(this.neuronPoints);
        this._fireAttr = geo.attributes.aFire;
    }

    // ===================== SYNAPTIC FILAMENTS =====================
    // The thing that makes it read as a network. Local segments inside each
    // region (short, dense) plus long-range segments that follow the real
    // connectome, drawn between ACTUAL neuron endpoints so the web is woven
    // through the cloud rather than floating over it.

    _buildFilaments() {
        if (this.filaments) {
            this.scene.remove(this.filaments);
            this.filaments.geometry.dispose();
            this.filaments.material.dispose();
        }
        const npos = this.neuronPoints.geometry.attributes.position.array;
        const segs = [];

        const pick = (name) => {
            const r = this._ranges[name];
            if (!r || r[1] <= r[0]) return -1;
            return r[0] + ((Math.random() * (r[1] - r[0])) | 0);
        };

        for (const name of REGION_NAMES) {
            for (let k = 0; k < LOCAL_FILAMENTS; k++) {
                const a = pick(name), b = pick(name);
                if (a < 0 || b < 0 || a === b) continue;
                segs.push([a, b, name, name]);
            }
        }
        for (const [ra, rb] of CONNECTIONS) {
            if (!REGIONS[ra] || !REGIONS[rb]) continue;
            for (let k = 0; k < LONG_FILAMENTS; k++) {
                const a = pick(ra), b = pick(rb);
                if (a < 0 || b < 0) continue;
                segs.push([a, b, ra, rb]);
            }
        }

        const n = segs.length * 2;
        const pos = new Float32Array(n * 3);
        const col = new Float32Array(n * 3);
        const fir = new Float32Array(n);
        const sed = new Float32Array(n);
        const ca = new THREE.Color(), cb = new THREE.Color();
        this._filRegions = new Array(n);

        segs.forEach((s, i) => {
            const [a, b, na, nb] = s;
            const seed = Math.random();
            ca.set(REGION_COLORS[na]);
            cb.set(REGION_COLORS[nb]);
            for (let e = 0; e < 2; e++) {
                const v = i * 2 + e;
                const src = e === 0 ? a : b;
                pos[v * 3]     = npos[src * 3];
                pos[v * 3 + 1] = npos[src * 3 + 1];
                pos[v * 3 + 2] = npos[src * 3 + 2];
                const c = e === 0 ? ca : cb;
                col[v * 3] = c.r; col[v * 3 + 1] = c.g; col[v * 3 + 2] = c.b;
                sed[v] = seed;
                this._filRegions[v] = e === 0 ? na : nb;
            }
        });

        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        geo.setAttribute('aColor',   new THREE.BufferAttribute(col, 3));
        geo.setAttribute('aFire',    new THREE.BufferAttribute(fir, 1));
        geo.setAttribute('aSeed',    new THREE.BufferAttribute(sed, 1));

        this.filaments = new THREE.LineSegments(geo, new THREE.ShaderMaterial({
            uniforms: { uTime: { value: 0 } },
            vertexShader: FIL_VERT,
            fragmentShader: FIL_FRAG,
            transparent: true,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
        }));
        this.filaments.frustumCulled = false;
        this.scene.add(this.filaments);
        this._filFireAttr = geo.attributes.aFire;

        // Vertex index lists per region, so a firing update is a handful of
        // array writes instead of a scan over every filament vertex.
        this._filIndex = {};
        for (const name of REGION_NAMES) this._filIndex[name] = [];
        this._filRegions.forEach((name, v) => {
            if (this._filIndex[name]) this._filIndex[name].push(v);
        });
    }

    // ===================== CONNECTOME CURVES + PULSES =====================
    // Kept because the travelling pulses ride them, and a pulse you see is a
    // spike that actually crossed that connection (real edge_flow). The wires
    // themselves are barely visible — the filaments carry the network look.

    _buildEdges() {
        this.edgeGroup = new THREE.Group();
        this.scene.add(this.edgeGroup);
        this.edges = [];

        for (const [a, b] of CONNECTIONS) {
            const ra = REGIONS[a], rb = REGIONS[b];
            if (!ra || !rb) continue;
            const va = new THREE.Vector3(...ra.pos);
            const vb = new THREE.Vector3(...rb.pos);

            const mid = va.clone().add(vb).multiplyScalar(0.5);
            const span = va.distanceTo(vb);
            const bow = mid.clone().normalize().multiplyScalar(0.10 + span * 0.14);
            mid.add(bow);

            // Reciprocal pairs get opposite perpendicular offsets, otherwise
            // both directions land on one curve and half the traffic hides.
            const sign = a < b ? 1 : -1;
            const perp = vb.clone().sub(va).cross(mid.clone().normalize());
            if (perp.lengthSq() > 1e-8) {
                mid.add(perp.normalize().multiplyScalar(sign * (0.045 + span * 0.05)));
            }

            const curve = new THREE.QuadraticBezierCurve3(va, mid, vb);
            const geo = new THREE.BufferGeometry().setFromPoints(curve.getPoints(EDGE_SEGMENTS));
            const blend = new THREE.Color(ra.color).lerp(new THREE.Color(rb.color), 0.5);
            const line = new THREE.Line(geo, new THREE.LineBasicMaterial({
                color: blend, transparent: true, opacity: 0.035,
                blending: THREE.AdditiveBlending, depthWrite: false,
            }));
            this.edgeGroup.add(line);
            this.edges.push({ a, b, curve, line, base: blend, flow: 0, accum: 0 });
        }
    }

    _initPulses() {
        const geo = new THREE.BufferGeometry();
        const pos = new Float32Array(MAX_PULSES * 3);
        const col = new Float32Array(MAX_PULSES * 3);
        for (let i = 0; i < MAX_PULSES; i++) pos[i * 3 + 1] = -999;
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        geo.setAttribute('color',    new THREE.BufferAttribute(col, 3));

        this.pulseMesh = new THREE.Points(geo, new THREE.PointsMaterial({
            size: 0.030, map: this.pulseTex, vertexColors: true,
            transparent: true, opacity: 0.95,
            blending: THREE.AdditiveBlending, depthWrite: false,
            sizeAttenuation: true,
        }));
        this.pulseMesh.frustumCulled = false;
        this.scene.add(this.pulseMesh);

        this.pulses = [];
        for (let i = 0; i < MAX_PULSES; i++) {
            this.pulses.push({ active: false, edge: null, t: 0, speed: 0, color: new THREE.Color() });
        }
    }

    _spawnPulse(edge) {
        for (const p of this.pulses) {
            if (p.active) continue;
            p.active = true; p.edge = edge; p.t = 0;
            p.speed = 0.6 + Math.random() * 0.9;
            p.color.copy(edge.base);
            return;
        }
    }

    _updatePulses(dt) {
        const pos = this.pulseMesh.geometry.attributes.position.array;
        const col = this.pulseMesh.geometry.attributes.color.array;
        const v = this._tmpVec || (this._tmpVec = new THREE.Vector3());
        for (let i = 0; i < MAX_PULSES; i++) {
            const p = this.pulses[i];
            if (!p.active) { pos[i * 3 + 1] = -999; continue; }
            p.t += dt * p.speed;
            if (p.t >= 1) { p.active = false; pos[i * 3 + 1] = -999; continue; }
            p.edge.curve.getPoint(p.t, v);
            pos[i * 3] = v.x; pos[i * 3 + 1] = v.y; pos[i * 3 + 2] = v.z;
            const k = Math.sin(p.t * Math.PI);
            col[i * 3] = p.color.r * k;
            col[i * 3 + 1] = p.color.g * k;
            col[i * 3 + 2] = p.color.b * k;
        }
        this.pulseMesh.geometry.attributes.position.needsUpdate = true;
        this.pulseMesh.geometry.attributes.color.needsUpdate = true;
    }

    // ===================== REAL NEURONS =====================

    initNeurons(positions) {
        this.regionData = positions;

        let total = 0;
        const order = [];
        for (const name of Object.keys(positions)) {
            const info = positions[name];
            const pts = info && info.positions;
            if (!pts) continue;
            const n = (pts instanceof Float32Array) ? (pts.length / 3) | 0 : pts.length;
            if (!n) continue;
            order.push([name, info, n]);
            total += n;
        }
        if (!total) return;

        const pos = new Float32Array(total * 3);
        const col = new Float32Array(total * 3);
        const fir = new Float32Array(total);
        const sed = new Float32Array(total);
        const c = new THREE.Color();
        this._ranges = {};

        let i = 0;
        for (const [name, info, n] of order) {
            const layout = REGION_LAYOUT[name] || { x: 0, y: 0, z: 0 };
            const center = info.center || [0, 0, 0];
            const pts = info.positions;
            c.set(REGION_COLORS[name] || 0xffffff);
            const start = i;
            for (let k = 0; k < n; k++, i++) {
                let x, y, z;
                if (pts instanceof Float32Array) {
                    x = pts[k * 3]; y = pts[k * 3 + 1]; z = pts[k * 3 + 2];
                } else {
                    x = pts[k][0]; y = pts[k][1]; z = pts[k][2];
                }
                pos[i * 3]     = (x - center[0]) * 0.95 + layout.x;
                pos[i * 3 + 1] = (y - center[1]) * 0.95 + layout.y;
                pos[i * 3 + 2] = (z - center[2]) * 0.95 + layout.z;
                col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
                sed[i] = Math.random();
            }
            this._ranges[name] = [start, i];
        }

        this._installNeurons(pos, col, fir, sed);
        this._buildFilaments();

        // Denser cloud → smaller dots, so total emitted light stays roughly
        // constant instead of scaling with neuron count. This is the other
        // half of glob prevention: a 100k build must not be 100x brighter
        // than a 1k build.
        const size = Math.max(1.1, Math.min(2.6, 2.6 * Math.sqrt(20000 / total)));
        this.neuronPoints.material.uniforms.uSize.value = size;

        console.log(`[Brain3D v3] ${total} neurons, ${Object.keys(this._ranges).length} regions, ` +
                    `${this._filRegions.length / 2} filaments, ${this.edges.length} pathways, ` +
                    `point size ${size.toFixed(2)}`);
    }

    // ===================== STATE =====================

    // brain.py ships region_firing as a PERCENT (get_firing_rate() * 100),
    // measured live median 1.63 / max 99.3. v1 read it as a 0..1 fraction,
    // which pinned every region at maximum and blew point size to 2 WORLD
    // UNITS. Normalise once, here, so nothing downstream repeats that.
    _norm(v) { return Math.max(0, Math.min(1, (v || 0) / 100)); }

    updateState(state) {
        if (!state) return;
        this.lastState = state;

        const raw = state.region_firing || {};
        for (const name of REGION_NAMES) this.regionFiring[name] = this._norm(raw[name]);
        this.rawFiring = raw;
        this.edgeFlow  = state.edge_flow || {};

        // edge_flow is an unbounded current magnitude, not a rate — measured
        // 0.019 to 786.8, four orders of magnitude. Log-compress and normalise
        // to the frame's own peak, or any multiplier that reveals the quiet
        // edges pins the other 47 and you get a glob made of lines.
        const haveFlow = Object.keys(this.edgeFlow).length > 0;
        const lg = (v) => Math.log10(1 + Math.max(0, v));
        let peak = 0;
        if (haveFlow) {
            for (const e of this.edges) {
                const v = this.edgeFlow[`${e.a}>${e.b}`] ?? 0;
                if (v > peak) peak = v;
            }
        }
        const peakL = lg(peak) || 1;

        for (const e of this.edges) {
            if (haveFlow) {
                // Directed lookup only. Falling back to the reverse key would
                // make a silent edge mirror its partner's traffic.
                const v = this.edgeFlow[`${e.a}>${e.b}`] ?? 0;
                e.flow = Math.min(1, lg(v) / peakL);
            } else {
                const fa = this.regionFiring[e.a] || 0;
                const fb = this.regionFiring[e.b] || 0;
                e.flow = Math.min(1, ((fa + fb) / 2) * 6);
            }
        }
    }

    // ===================== ANIMATE =====================

    animate(dt) {
        this.time += dt;
        const asleep = !!(typeof window !== 'undefined' && window.__leonAsleep);

        if (this.neuronPoints) this.neuronPoints.material.uniforms.uTime.value = this.time;
        if (this.filaments)    this.filaments.material.uniforms.uTime.value    = this.time;

        // Smooth firing toward target, then push it into the GPU attributes.
        // Region ranges are contiguous, so this is 18 typed-array fills — the
        // cost does not grow with neuron count.
        const k = Math.min(1, dt * 5.5);
        let changed = false;
        for (const name of REGION_NAMES) {
            const target = asleep ? 0.012 : (this.regionFiring[name] || 0);
            const cur = this.smoothFiring[name] || 0;
            const nv = cur + (target - cur) * k;
            if (Math.abs(nv - cur) > 0.0004) {
                this.smoothFiring[name] = nv;
                changed = true;
                const r = this._ranges[name];
                if (r && this._fireAttr) this._fireAttr.array.fill(nv, r[0], r[1]);
                const idx = this._filIndex && this._filIndex[name];
                if (idx && this._filFireAttr) {
                    const arr = this._filFireAttr.array;
                    for (let i = 0; i < idx.length; i++) arr[idx[i]] = nv;
                }
            }
        }
        if (changed) {
            if (this._fireAttr) this._fireAttr.needsUpdate = true;
            if (this._filFireAttr) this._filFireAttr.needsUpdate = true;
        }

        for (const e of this.edges) {
            const f = asleep ? 0 : e.flow;
            e.line.material.opacity = 0.025 + f * 0.10;
            e.accum += f * dt * 8;
            while (e.accum >= 1) { e.accum -= 1; this._spawnPulse(e); }
        }
        this._updatePulses(dt);

        this.controls.update();
        if (this._contextLost) return;
        this.composer.render();
    }

    _onResize() {
        const w = window.innerWidth, h = window.innerHeight;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
        this.composer.setSize(w, h);
        if (this.neuronPoints) {
            this.neuronPoints.material.uniforms.uDpr.value =
                Math.min(window.devicePixelRatio, 2);
        }
    }
}
