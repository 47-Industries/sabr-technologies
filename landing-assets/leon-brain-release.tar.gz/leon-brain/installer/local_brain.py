"""Local (offline) brain provisioning — shared by BOTH installer front ends.

WHY THIS FILE EXISTS
--------------------
On 2026-08-12 the ollama-provisioning fix landed inside SabrInstaller as a
method, and `provision_local_llm` was called from exactly ONE line in the whole
tree: the graphical installer. But a customer who follows the documented path —
`curl … bootstrap.sh | bash` — never touches the GUI. bootstrap hands off to
setup.sh, which execs install_client.py, which had no idea this code existed
and still carried a comment telling the reader that "Ollama is not installed by
this installer, install it yourself".

So the fix was real and the bug was still shipping: a terminal-path customer
with no cloud brain finished a clean install, saw "ready", and owned an SI with
nothing behind it. Proven on a virgin container the same morning — install
completed, `command -v ollama` returned nothing.

Two doors into the same house, and we had only locked one. Hence: the logic
lives here, in one place, and both front ends call it. Adding a third front end
later means importing this, not re-deriving it.

The front ends differ in how they talk to a human (a GUI label vs. a terminal
line) and in where their .env lives, so those two things are injected. Nothing
else about the policy is allowed to diverge.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.request

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"
IS_LINUX = platform.system() == "Linux"

DEFAULT_MODEL = "llama3.2:3b"
OLLAMA_PORT = 11434

# Keys that mean "this machine can reach a cloud brain". If ANY of these
# carries a value, the local model is a backup and failing to get it is a
# warning. If NONE does, the local model IS the brain and a failure here is a
# failed install that has to say so.
CLOUD_BRAIN_KEYS = ("ANTHROPIC_API_KEY", "CLAUDE_API_KEY",
                    "LEON_ANTHROPIC_API_KEY", "OPENAI_API_KEY")


# ── finding the `claude` CLI when PATH is lying ───────────────────────
#
# THE BUG THIS SECTION KILLS (Gio's Mac, 2026-08-23): the customer was signed
# in to Claude Code, the install still said he had no cloud brain, and he had
# to finish the install blind and "log in later in a claude terminal" to make
# his SI think. Root cause: `shutil.which("claude")` — a frozen GUI app
# launched from Finder gets launchd's bare PATH (/usr/bin:/bin:/usr/sbin:
# /sbin). Homebrew's /opt/homebrew/bin and npm's ~/.local/bin are not in it,
# so a claude that works in every terminal is INVISIBLE to the installer.
# The same blindness hits the RUNNING SI when it autostarts under launchd or
# systemd --user: nine call sites across the tree trust which("claude"), and
# every one of them goes dark in a service context.
#
# bootstrap.sh learned this lesson long ago (it searches an explicit list of
# known homes). This is that lesson, shared, so the GUI installer, the
# terminal installer, and the runtime all look in the same places. Cross-OS:
# the Windows homes are npm's %APPDATA%\npm and the native installer's
# ~/.local/bin; claude may be claude.cmd or claude.exe there.

def _claude_candidate_dirs() -> list:
    home = os.path.expanduser("~")
    if IS_WINDOWS:
        dirs = [
            os.path.join(os.environ.get("APPDATA", ""), "npm"),
            os.path.join(home, ".local", "bin"),
            os.path.join(home, ".claude", "local"),
        ]
    else:
        dirs = [
            os.path.join(home, ".local", "bin"),
            os.path.join(home, ".claude", "local"),
            "/usr/local/bin",
            "/opt/homebrew/bin",
        ]
    return [d for d in dirs if d and os.path.isdir(d)]


def find_claude():
    """Absolute path to a runnable `claude`, or None. Never raises."""
    exe = shutil.which("claude")
    if exe:
        return exe
    names = ("claude.cmd", "claude.exe", "claude") if IS_WINDOWS else ("claude",)
    for d in _claude_candidate_dirs():
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


def augment_path() -> None:
    """Prepend the known claude/npm homes to this process's PATH.

    One call at process start fixes every `shutil.which("claude")` in that
    process — installer, server routes, and the brain's own chat path — for
    the launchd/systemd/Finder contexts where PATH arrives bare. Idempotent,
    never raises, never removes anything.
    """
    try:
        current = os.environ.get("PATH", "").split(os.pathsep)
        extra = [d for d in _claude_candidate_dirs() if d not in current]
        if extra:
            os.environ["PATH"] = os.pathsep.join(
                extra + ([os.environ["PATH"]] if os.environ.get("PATH") else []))
    except Exception:
        pass


def claude_logged_in(exe=None, timeout: int = 90) -> bool:
    """True only if `claude` can actually COMPLETE A TURN on this machine.

    Ported from install_client.py's honest check (see its history: the
    credentials-file presence check passed a dead stub token and shipped a
    mute SI). The SI talks by shelling out to `claude`, so the only honest
    test is to shell out to `claude` and watch a turn come back. Shared here
    2026-08-23 so the GUI installer stops being the one front end that never
    checks — that gap is why Gio's signed-in Mac was told to go add an API
    key.
    """
    exe = exe or find_claude()
    if not exe:
        return False
    try:
        proc = subprocess.run(
            [exe, "-p", "Reply with the single word: OK"],
            capture_output=True, text=True, timeout=timeout,
            stdin=subprocess.DEVNULL,
            # Windows decodes with the locale codec by default; Claude Code
            # prints box-drawing chars, the decode raises, and a logged-in
            # machine reads as logged-out. Explicit codec, never raise.
            encoding="utf-8", errors="replace",
        )
    except Exception:
        # Timeout or spawn failure: a brain call that never returns is mute
        # in exactly the way a rejected one is.
        return False
    if proc.returncode != 0:
        return False
    out = ((proc.stdout or "") + (proc.stderr or "")).lower()
    # Claude Code exits 0 on some auth failures and prints the reason instead.
    for bad in ("not logged in", "please run /login", "invalid api key",
                "authentication_error", "unauthorized", "credit balance",
                "please run `claude login`"):
        if bad in out:
            return False
    return bool((proc.stdout or "").strip())


def _port_busy(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def has_cloud_brain(dest: str, cfg: dict | None = None) -> bool:
    """True if this machine can already reach a cloud brain."""
    cfg = cfg or {}
    # Hosted mode: the thinking happens on our server, not on this box.
    if cfg.get("brain_mode") == "hosted":
        return True
    svc = cfg.get("service_keys") or {}
    if any(svc.get(k) for k in CLOUD_BRAIN_KEYS):
        return True
    # A key already in the environment or in a prior .env counts too — an
    # update must not decide the owner lost their brain overnight.
    if any(os.environ.get(k) for k in CLOUD_BRAIN_KEYS):
        return True
    try:
        with open(os.path.join(dest, ".env"), "r", encoding="utf-8") as fh:
            for ln in fh:
                k, _, v = ln.partition("=")
                if k.strip() in CLOUD_BRAIN_KEYS and v.strip():
                    return True
    except OSError:
        pass
    # The `claude` CLI logged in on this machine is also a real brain — it is
    # how Dean's own box thinks, and it carries no API key at all. find_claude,
    # not which(): a Finder-launched installer has a bare PATH and which() is
    # blind there (Gio's Mac, 2026-08-23).
    if find_claude():
        return True
    return False


def set_env_key(dest: str, key: str, value: str) -> None:
    """Rewrite one key in the installed .env, in place."""
    path = os.path.join(dest, ".env")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
    except OSError:
        return
    hit = False
    for i, ln in enumerate(lines):
        if ln.split("=", 1)[0].strip() == key:
            lines[i] = f"{key}={value}\n"
            hit = True
    if not hit:
        lines.append(f"{key}={value}\n")
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.writelines(lines)
    except OSError:
        pass


def _ensure_linux_prereqs(say) -> None:
    """Install what ollama's own install script needs but does not install.

    Found on a stock ubuntu:22.04 box 2026-08-12: the official script now
    extracts a zstd-compressed payload and ABORTS with
    "ERROR: This version requires zstd for extraction" on any machine without
    it — which is most fresh Linux installs. For a customer with no cloud
    engine, that single missing package is the difference between an SI that
    thinks and one that does not, and our only report was a generic
    "install script failed".

    Best-effort and silent-on-success: if we cannot install it, let the real
    script run anyway and report its own error rather than pre-judging.
    """
    if shutil.which("zstd"):
        return
    if os.geteuid() == 0:
        sudo = []
    elif shutil.which("sudo"):
        sudo = ["sudo"]
    else:
        say("zstd is missing and cannot be installed without root — the "
            "local brain download may fail.")
        return
    for probe, cmd in (("apt-get", ["apt-get", "install", "-y", "zstd"]),
                       ("dnf", ["dnf", "install", "-y", "zstd"]),
                       ("pacman", ["pacman", "-S", "--noconfirm", "zstd"]),
                       ("zypper", ["zypper", "install", "-y", "zstd"])):
        if not shutil.which(probe):
            continue
        try:
            if probe == "apt-get":
                subprocess.run(sudo + ["apt-get", "update", "-qq"],
                               timeout=600, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            subprocess.run(sudo + cmd, timeout=600,
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except Exception:
            pass
        break


MAC_OLLAMA_LABEL = "com.sabr.ollama"


def _mac_autostart_ollama(exe: str | None, say) -> None:
    """Make the local brain survive a reboot on macOS.

    THE ASYMMETRY THIS FIXES (found 2026-08-12): on Linux, ollama's official
    script writes /etc/systemd/system/ollama.service and enables it, so the
    server comes back after a restart. On Windows, its Inno installer registers
    its own startup entry. On macOS we unzip Ollama.app and start `ollama serve`
    exactly once, from the installer process — and register NOTHING. The app
    only becomes a login item if a human double-clicks it, which our own code
    deliberately avoids asking them to do.

    Net effect for a Mac owner with no cloud key: install succeeds, the SI
    thinks, they reboot, and the brain is silently gone. No error, no prompt —
    just an SI that stopped being able to answer. That is the single worst
    failure shape we ship, because it looks like the product broke itself.

    So we write our own LaunchAgent. KeepAlive restarts it if it dies mid-session
    too, which the install-time Popen never could.
    """
    if not IS_MAC:
        return
    exe = exe or shutil.which("ollama") or "/usr/local/bin/ollama"
    try:
        agents = os.path.expanduser("~/Library/LaunchAgents")
        os.makedirs(agents, exist_ok=True)
        path = os.path.join(agents, f"{MAC_OLLAMA_LABEL}.plist")
        import plistlib
        with open(path, "wb") as fh:
            plistlib.dump({
                "Label": MAC_OLLAMA_LABEL,
                "ProgramArguments": [exe, "serve"],
                "RunAtLoad": True,
                "KeepAlive": True,
                "StandardOutPath": "/dev/null",
                "StandardErrorPath": "/dev/null",
            }, fh)
        # unload first so a re-run/update replaces cleanly instead of erroring.
        subprocess.run(["launchctl", "unload", path], timeout=30,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        r = subprocess.run(["launchctl", "load", "-w", path], timeout=30,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if r.returncode != 0:
            say("Local brain installed, but macOS would not register it to "
                "start at login — it may need starting again after a restart.")
    except Exception as e:
        # Never fatal: the model still works for THIS session.
        say(f"Could not set the local brain to start at login ({e}).")


def _mac_ensure_on_path(directory: str, say) -> None:
    """Make `directory` visible to the owner's OWN future terminals.

    Symlinking into a directory does not put it on PATH — PATH is read from
    shell startup files, which this process does not control and cannot make
    the CURRENT shell re-read anyway. zsh has been the default login shell
    since Catalina and Terminal.app starts one, so .zprofile is read on every
    new window; .bash_profile covers an owner who switched back to bash.
    Idempotent — checked by substring before writing, so re-running install
    does not pile up duplicate lines.
    """
    home = os.path.expanduser("~")
    export_line = f'export PATH="{directory}:$PATH"\n'
    for rc in (os.path.join(home, ".zprofile"), os.path.join(home, ".bash_profile")):
        try:
            existing = ""
            if os.path.exists(rc):
                with open(rc, "r", encoding="utf-8", errors="replace") as fh:
                    existing = fh.read()
            if directory in existing:
                continue
            with open(rc, "a", encoding="utf-8") as fh:
                fh.write(
                    "\n# Added by the Sabr installer so `ollama` works in "
                    f"new terminals\n{export_line}")
        except OSError as e:
            say(f"Could not add {directory} to your PATH in {rc} ({e}).")


def _mac_link_ollama_cli(inner: str, say) -> None:
    """Symlink the CLI ollama.app bundles somewhere the owner can run it.

    THE GAP THIS CLOSES (found 2026-08-12): the fallback target,
    ~/.local/bin, is not on PATH in a fresh Terminal.app window on stock
    macOS — nothing about the OS or a login shell puts it there. The primary
    target, /usr/local/bin, needs root to CREATE if it does not already
    exist: its parent, /usr, is root-owned and mode 755 with no admin-group
    exception, unlike the Homebrew-era Intel default where /usr/local was
    pre-created group-writable. On a non-sudo account — common on managed or
    freshly-set-up Apple Silicon Macs — os.makedirs("/usr/local/bin") raises
    PermissionError every time, so the ~/.local/bin fallback is not a rare
    edge case, it is the common case on exactly the machines that have no
    sudo to fall back on themselves. Before this fix, the symlink still got
    created there, but `command -v ollama` in a brand-new terminal came back
    empty regardless — the one thing this whole mechanism exists to give the
    owner (running `ollama` themselves, instead of double-clicking
    Ollama.app) silently did not happen.
    """
    for d in ("/usr/local/bin", os.path.expanduser("~/.local/bin")):
        try:
            os.makedirs(d, exist_ok=True)
            link = os.path.join(d, "ollama")
            if not os.path.exists(link):
                os.symlink(inner, link)
            if d != "/usr/local/bin":
                _mac_ensure_on_path(d, say)
            return
        except OSError:
            continue


def install_ollama(say) -> str | None:
    """Install ollama for this platform. Returns the exe path, or None.

    Verified live 2026-08-12: all three URLs answer 200, and the Windows
    installer is Inno Setup (so /VERYSILENT is the correct silent flag — an
    NSIS /S here would open a GUI mid-install and hang the run).
    """
    try:
        if IS_LINUX:
            _ensure_linux_prereqs(say)
            r = subprocess.run(
                ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                timeout=1800, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT)
            if r.returncode != 0:
                out = (r.stdout or b"").decode("utf-8", "replace").strip()
                # Surface the script's OWN last words. Swallowing them is how
                # "Ollama install script failed." became the entire diagnosis
                # for a customer whose real problem was one missing package.
                tail = out.rsplit("\n", 4)[-1] if out else "no output"
                say(f"Ollama install script failed: {tail}")
                return None
        elif IS_MAC:
            import zipfile
            zpath = os.path.join(tempfile.gettempdir(), "Ollama-darwin.zip")
            urllib.request.urlretrieve(
                "https://ollama.com/download/Ollama-darwin.zip", zpath)
            with zipfile.ZipFile(zpath) as zf:
                zf.extractall("/Applications")
            try:
                os.remove(zpath)
            except OSError:
                pass
            # The .app bundles the CLI; it is not on PATH until the app has
            # been opened once, so link it ourselves rather than telling the
            # owner to go double-click something.
            inner = "/Applications/Ollama.app/Contents/Resources/ollama"
            if os.path.exists(inner):
                os.chmod(inner, 0o755)
                _mac_link_ollama_cli(inner, say)
            _mac_autostart_ollama(inner if os.path.exists(inner) else None, say)
        elif IS_WINDOWS:
            epath = os.path.join(tempfile.gettempdir(), "OllamaSetup.exe")
            urllib.request.urlretrieve(
                "https://ollama.com/download/OllamaSetup.exe", epath)
            r = subprocess.run(
                [epath, "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART"],
                timeout=1800, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT)
            try:
                os.remove(epath)
            except OSError:
                pass
            if r.returncode != 0:
                say("Ollama installer returned an error.")
                return None
        else:
            return None
    except Exception as e:
        say(f"Could not install the local brain ({e}).")
        return None

    # PATH in THIS process predates the install, so look in the known install
    # locations too before reporting a failure that did not happen.
    found = shutil.which("ollama")
    if found:
        return found
    for cand in (
        "/usr/local/bin/ollama", "/usr/bin/ollama",
        os.path.expanduser("~/.local/bin/ollama"),
        "/Applications/Ollama.app/Contents/Resources/ollama",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
        os.path.expandvars(r"%ProgramFiles%\Ollama\ollama.exe"),
    ):
        if cand and os.path.exists(cand):
            return cand
    say("Ollama installed but its command could not be located.")
    return None


# The uninstall receipt. Written ONLY when install_ollama() actually put
# Ollama on this machine, and read by the uninstaller as the sole basis for
# deciding whether it may remove it.
#
# Without it there is no honest choice available. Remove Ollama always, and an
# uninstall silently deletes software the owner installed themselves and uses
# for their own work -- several GB of their model weights with it. Remove it
# never, and every uninstall leaves behind an Ollama.app, a LaunchAgent that
# keeps restarting a server for software that is gone, and a ~/.ollama that
# nobody will ever explain to them. The receipt is what makes the difference
# knowable, and the one moment it is knowable is the moment we install.
OLLAMA_RECEIPT = "ollama-receipt.json"


def _ollama_receipt_path(dest: str) -> str:
    return os.path.join(dest, OLLAMA_RECEIPT)


def _write_ollama_receipt(dest: str, exe: str | None) -> str | None:
    """Record that WE installed Ollama here. Never raises."""
    try:
        os.makedirs(dest, exist_ok=True)
        data = {
            "installed_by": "sabr-installer",
            "component": "ollama",
            "exe": exe or "",
            "platform": platform.system(),
            # Everything the uninstaller may delete, enumerated HERE rather
            # than re-derived there. A path we did not create must never end
            # up in this list, because this list is a delete list.
            "paths": _ollama_owned_paths(exe),
        }
        path = _ollama_receipt_path(dest)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
        return path
    except OSError:
        # A missing receipt costs a customer some leftover disk. A raised
        # exception here costs them the install itself, after the multi-GB
        # download already succeeded. Never trade the second for the first.
        return None


def _ollama_owned_paths(exe: str | None) -> list[str]:
    """The files this installer creates when it installs Ollama itself."""
    home = os.path.expanduser("~")
    paths = []
    if IS_MAC:
        paths += ["/Applications/Ollama.app",
                  "/usr/local/bin/ollama",
                  os.path.join(home, ".local", "bin", "ollama"),
                  os.path.join(home, "Library", "LaunchAgents",
                               MAC_OLLAMA_LABEL + ".plist")]
    elif IS_LINUX:
        paths += ["/usr/local/bin/ollama", "/usr/bin/ollama",
                  "/etc/systemd/system/ollama.service"]
    if exe:
        paths.append(exe)
    # Model weights last: biggest, and the one worth being sure about.
    paths.append(os.path.join(home, ".ollama"))
    # Dedupe, preserve order, drop empties.
    seen, out = set(), []
    for p in paths:
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def installed_ollama_ourselves(dest: str) -> dict | None:
    """The receipt, or None if we did not install Ollama on this machine."""
    try:
        with open(_ollama_receipt_path(dest), "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("installed_by") != "sabr-installer":
        return None
    return data


def remove_ollama_if_ours(dest: str, say=print) -> list[str]:
    """Remove Ollama, but ONLY if the receipt says this installer put it here.

    MUST be called before the install directory is deleted -- the receipt
    lives inside it, and reading it afterwards is reading a file that no
    longer exists, which is indistinguishable from "the owner installed it
    themselves" and therefore silently reverts to leaving GB behind.
    """
    receipt = installed_ollama_ourselves(dest)
    if not receipt:
        return []
    say("Removing the offline brain this installer added…")
    removed = []

    # Stop it first. Deleting a running server's files leaves a live process
    # holding deleted inodes, and on macOS a KeepAlive job respawns it forever.
    if IS_MAC:
        plist = os.path.join(os.path.expanduser("~"), "Library",
                             "LaunchAgents", MAC_OLLAMA_LABEL + ".plist")
        subprocess.run(["launchctl", "unload", "-w", plist],
                       check=False, capture_output=True, timeout=60)
    elif IS_LINUX:
        for argv in (["systemctl", "stop", "ollama"],
                     ["systemctl", "disable", "ollama"]):
            subprocess.run(argv, check=False, capture_output=True, timeout=60)
    elif IS_WINDOWS:
        # Inno Setup leaves its own uninstaller; use it rather than deleting
        # a Program Files tree out from under the registry.
        local = os.environ.get("LOCALAPPDATA", "")
        for cand in (os.path.join(local, "Programs", "Ollama", "unins000.exe"),
                     os.path.join(local, "Ollama", "unins000.exe")):
            if os.path.exists(cand):
                subprocess.run([cand, "/VERYSILENT", "/SUPPRESSMSGBOXES",
                                "/NORESTART"], check=False,
                               capture_output=True, timeout=1800)
                removed.append(cand)
                break

    for path in receipt.get("paths") or []:
        if not isinstance(path, str) or not path:
            continue
        try:
            if os.path.islink(path) or os.path.isfile(path):
                os.remove(path)
                removed.append(path)
            elif os.path.isdir(path):
                shutil.rmtree(path, ignore_errors=True)
                if not os.path.isdir(path):
                    removed.append(path)
        except OSError:
            # One unremovable path must not abort the sweep of the others.
            continue

    if IS_LINUX:
        subprocess.run(["systemctl", "daemon-reload"],
                       check=False, capture_output=True, timeout=60)
    return removed


def provision(dest: str, cfg: dict | None = None, say=print,
              model: str = DEFAULT_MODEL) -> bool:
    """Arm the local model, or say plainly that it isn't armed.

    Returns False ONLY in the one case the caller must not paper over: there
    is no cloud brain AND no local brain, i.e. the SI has nothing to think
    with. Every other outcome returns True — an offline BACKUP that fails is a
    warning, never a failed install.
    """
    required = not has_cloud_brain(dest, cfg)
    exe = shutil.which("ollama")
    if not exe:
        if required:
            say("No cloud brain configured, so your SI needs a local one. "
                "Installing it now — this is a large download.")
        else:
            say("Setting up the offline backup brain "
                "(large download, runs once).")
        exe = install_ollama(say)
        if exe:
            # Uninstall receipt. The uninstaller cannot otherwise tell an
            # Ollama WE dropped on the machine from one the owner already had
            # and uses for their own work -- so before this it removed
            # neither, and every uninstall left several GB of Ollama.app plus
            # model weights behind forever. Deleting unconditionally would be
            # worse: that is erasing somebody else's software. The receipt is
            # the only honest basis for the choice, so it is written at the
            # one moment we know the answer.
            _write_ollama_receipt(dest, exe)
    if not exe:
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        if required:
            say("Could not install a local brain, and there is no cloud brain "
                "configured — your SI will start but it will not be able to "
                "think until one of the two is in place.")
            return False
        say("No local backup model on this machine — your SI uses the cloud "
            "brain.")
        return True

    # Also runs when ollama was ALREADY installed — otherwise a Mac owner who
    # happened to have it stays in the reboot-and-it's-gone case forever,
    # because install_ollama (where this normally fires) was never called.
    _mac_autostart_ollama(exe, say)
    if IS_MAC:
        # `launchctl load` returns when launchd ACCEPTS the job, not when the
        # child has bound 11434. Reading the port immediately therefore says
        # "free" on a machine where launchd is a beat away from taking it, and
        # the block below spawns a second `ollama serve`. That one wins the
        # bind, and launchd's copy -- KeepAlive: true -- then respawns and
        # fails forever, a crash loop left behind on the customer's Mac after
        # the installer has exited. Give launchd its beat first.
        for _ in range(20):
            if _port_busy(OLLAMA_PORT):
                break
            time.sleep(0.5)

    try:
        if not _port_busy(OLLAMA_PORT):
            # Detached: `ollama serve` does not return.
            kw = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
            if IS_WINDOWS:
                kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            else:
                kw["start_new_session"] = True
            subprocess.Popen([exe, "serve"], **kw)
            for _ in range(20):
                if _port_busy(OLLAMA_PORT):
                    break
                time.sleep(0.5)
        if not _port_busy(OLLAMA_PORT):
            say("Ollama is installed but wouldn't start — the local model "
                "stays off for now.")
            set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
            return not required
        say("Pulling the small offline model…")
        r = subprocess.run([exe, "pull", model], timeout=900,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if r.returncode == 0:
            if required:
                # THE BUG AIDEN HIT (2026-08-12). The installer writes
                # LEON_LOCAL_LLM_MODE=fallback by default, and brain/local_llm.py
                # `_should_use_local()` hard-returns False for any mode that
                # isn't "chat" — that gate exists because DEAN has a Claude
                # subscription and wants full-quality conversation always. But
                # `required` means the exact opposite situation: there is NO
                # cloud brain on this machine. So the customer's only brain sat
                # loaded, armed, and structurally forbidden from ever answering.
                # The chat path fell through to shelling out to a `claude` CLI
                # that a customer has no reason to own, and the owner got the
                # canned "Voice module offline." — or nothing at all — while
                # this same install printed "Local brain is armed." and
                # "Iris is ready." Promote the mode to match reality: when the
                # local model is the ONLY brain, it is the conversation.
                # "only", not "chat": "chat" still runs the escalate-to-Claude
                # gates (>20 words, tool-sounding words, "why"/"explain"), and
                # every one of those escalations lands on a Claude that isn't
                # on this machine. "only" skips them.
                set_env_key(dest, "LEON_LOCAL_LLM_MODE", "only")
                say("Local brain is armed — and it's this SI's primary mind, "
                    "since no cloud brain is configured.")
            else:
                say("Local brain is armed.")
            return True
        say("Couldn't fetch the model.")
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        return not required
    except Exception as e:
        # NEVER fail an install over an OPTIONAL backup path. But if this was
        # the only brain, the caller still has to hear about it.
        say(f"Local model setup did not complete ({e}).")
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        return not required
