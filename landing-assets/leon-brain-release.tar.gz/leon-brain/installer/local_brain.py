"""Local (offline) brain provisioning — shared by BOTH installer front ends.

WHY THIS FILE EXISTS
--------------------
On 2026-08-12 the ollama-provisioning fix landed inside SabrInstaller as a
method, and `provision_local_llm` was called from exactly ONE line in the whole
tree: the graphical installer. But a customer who follows the documented path —
`curl … bootstrap.sh | bash` — never touches the GUI. bootstrap hands off to
setup.sh, which execs install_client.py, which had no idea this code existed
and still carried a comment telling the reader that "Ollama is not installed by
this installer, install it yourself".

So the fix was real and the bug was still shipping: a terminal-path customer
with no cloud brain finished a clean install, saw "ready", and owned an SI with
nothing behind it. Proven on a virgin container the same morning — install
completed, `command -v ollama` returned nothing.

Two doors into the same house, and we had only locked one. Hence: the logic
lives here, in one place, and both front ends call it. Adding a third front end
later means importing this, not re-deriving it.

The front ends differ in how they talk to a human (a GUI label vs. a terminal
line) and in where their .env lives, so those two things are injected. Nothing
else about the policy is allowed to diverge.
"""

from __future__ import annotations

import os
import platform
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.request

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"
IS_LINUX = platform.system() == "Linux"

DEFAULT_MODEL = "llama3.2:3b"
OLLAMA_PORT = 11434

# Keys that mean "this machine can reach a cloud brain". If ANY of these
# carries a value, the local model is a backup and failing to get it is a
# warning. If NONE does, the local model IS the brain and a failure here is a
# failed install that has to say so.
CLOUD_BRAIN_KEYS = ("ANTHROPIC_API_KEY", "CLAUDE_API_KEY",
                    "LEON_ANTHROPIC_API_KEY", "OPENAI_API_KEY")


def _port_busy(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def has_cloud_brain(dest: str, cfg: dict | None = None) -> bool:
    """True if this machine can already reach a cloud brain."""
    cfg = cfg or {}
    # Hosted mode: the thinking happens on our server, not on this box.
    if cfg.get("brain_mode") == "hosted":
        return True
    svc = cfg.get("service_keys") or {}
    if any(svc.get(k) for k in CLOUD_BRAIN_KEYS):
        return True
    # A key already in the environment or in a prior .env counts too — an
    # update must not decide the owner lost their brain overnight.
    if any(os.environ.get(k) for k in CLOUD_BRAIN_KEYS):
        return True
    try:
        with open(os.path.join(dest, ".env"), "r", encoding="utf-8") as fh:
            for ln in fh:
                k, _, v = ln.partition("=")
                if k.strip() in CLOUD_BRAIN_KEYS and v.strip():
                    return True
    except OSError:
        pass
    # The `claude` CLI logged in on this machine is also a real brain — it is
    # how Dean's own box thinks, and it carries no API key at all.
    if shutil.which("claude"):
        return True
    return False


def set_env_key(dest: str, key: str, value: str) -> None:
    """Rewrite one key in the installed .env, in place."""
    path = os.path.join(dest, ".env")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()
    except OSError:
        return
    hit = False
    for i, ln in enumerate(lines):
        if ln.split("=", 1)[0].strip() == key:
            lines[i] = f"{key}={value}\n"
            hit = True
    if not hit:
        lines.append(f"{key}={value}\n")
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.writelines(lines)
    except OSError:
        pass


def _ensure_linux_prereqs(say) -> None:
    """Install what ollama's own install script needs but does not install.

    Found on a stock ubuntu:22.04 box 2026-08-12: the official script now
    extracts a zstd-compressed payload and ABORTS with
    "ERROR: This version requires zstd for extraction" on any machine without
    it — which is most fresh Linux installs. For a customer with no cloud
    engine, that single missing package is the difference between an SI that
    thinks and one that does not, and our only report was a generic
    "install script failed".

    Best-effort and silent-on-success: if we cannot install it, let the real
    script run anyway and report its own error rather than pre-judging.
    """
    if shutil.which("zstd"):
        return
    if os.geteuid() == 0:
        sudo = []
    elif shutil.which("sudo"):
        sudo = ["sudo"]
    else:
        say("zstd is missing and cannot be installed without root — the "
            "local brain download may fail.")
        return
    for probe, cmd in (("apt-get", ["apt-get", "install", "-y", "zstd"]),
                       ("dnf", ["dnf", "install", "-y", "zstd"]),
                       ("pacman", ["pacman", "-S", "--noconfirm", "zstd"]),
                       ("zypper", ["zypper", "install", "-y", "zstd"])):
        if not shutil.which(probe):
            continue
        try:
            if probe == "apt-get":
                subprocess.run(sudo + ["apt-get", "update", "-qq"],
                               timeout=600, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
            subprocess.run(sudo + cmd, timeout=600,
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except Exception:
            pass
        break


def install_ollama(say) -> str | None:
    """Install ollama for this platform. Returns the exe path, or None.

    Verified live 2026-08-12: all three URLs answer 200, and the Windows
    installer is Inno Setup (so /VERYSILENT is the correct silent flag — an
    NSIS /S here would open a GUI mid-install and hang the run).
    """
    try:
        if IS_LINUX:
            _ensure_linux_prereqs(say)
            r = subprocess.run(
                ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                timeout=1800, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT)
            if r.returncode != 0:
                out = (r.stdout or b"").decode("utf-8", "replace").strip()
                # Surface the script's OWN last words. Swallowing them is how
                # "Ollama install script failed." became the entire diagnosis
                # for a customer whose real problem was one missing package.
                tail = out.rsplit("\n", 4)[-1] if out else "no output"
                say(f"Ollama install script failed: {tail}")
                return None
        elif IS_MAC:
            import zipfile
            zpath = os.path.join(tempfile.gettempdir(), "Ollama-darwin.zip")
            urllib.request.urlretrieve(
                "https://ollama.com/download/Ollama-darwin.zip", zpath)
            with zipfile.ZipFile(zpath) as zf:
                zf.extractall("/Applications")
            try:
                os.remove(zpath)
            except OSError:
                pass
            # The .app bundles the CLI; it is not on PATH until the app has
            # been opened once, so link it ourselves rather than telling the
            # owner to go double-click something.
            inner = "/Applications/Ollama.app/Contents/Resources/ollama"
            if os.path.exists(inner):
                os.chmod(inner, 0o755)
                for d in ("/usr/local/bin", os.path.expanduser("~/.local/bin")):
                    try:
                        os.makedirs(d, exist_ok=True)
                        link = os.path.join(d, "ollama")
                        if not os.path.exists(link):
                            os.symlink(inner, link)
                        break
                    except OSError:
                        continue
        elif IS_WINDOWS:
            epath = os.path.join(tempfile.gettempdir(), "OllamaSetup.exe")
            urllib.request.urlretrieve(
                "https://ollama.com/download/OllamaSetup.exe", epath)
            r = subprocess.run(
                [epath, "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART"],
                timeout=1800, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT)
            try:
                os.remove(epath)
            except OSError:
                pass
            if r.returncode != 0:
                say("Ollama installer returned an error.")
                return None
        else:
            return None
    except Exception as e:
        say(f"Could not install the local brain ({e}).")
        return None

    # PATH in THIS process predates the install, so look in the known install
    # locations too before reporting a failure that did not happen.
    found = shutil.which("ollama")
    if found:
        return found
    for cand in (
        "/usr/local/bin/ollama", "/usr/bin/ollama",
        os.path.expanduser("~/.local/bin/ollama"),
        "/Applications/Ollama.app/Contents/Resources/ollama",
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
        os.path.expandvars(r"%ProgramFiles%\Ollama\ollama.exe"),
    ):
        if cand and os.path.exists(cand):
            return cand
    say("Ollama installed but its command could not be located.")
    return None


def provision(dest: str, cfg: dict | None = None, say=print,
              model: str = DEFAULT_MODEL) -> bool:
    """Arm the local model, or say plainly that it isn't armed.

    Returns False ONLY in the one case the caller must not paper over: there
    is no cloud brain AND no local brain, i.e. the SI has nothing to think
    with. Every other outcome returns True — an offline BACKUP that fails is a
    warning, never a failed install.
    """
    required = not has_cloud_brain(dest, cfg)
    exe = shutil.which("ollama")
    if not exe:
        if required:
            say("No cloud brain configured, so your SI needs a local one. "
                "Installing it now — this is a large download.")
        else:
            say("Setting up the offline backup brain "
                "(large download, runs once).")
        exe = install_ollama(say)
    if not exe:
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        if required:
            say("Could not install a local brain, and there is no cloud brain "
                "configured — your SI will start but it will not be able to "
                "think until one of the two is in place.")
            return False
        say("No local backup model on this machine — your SI uses the cloud "
            "brain.")
        return True

    try:
        if not _port_busy(OLLAMA_PORT):
            # Detached: `ollama serve` does not return.
            kw = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
            if IS_WINDOWS:
                kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            else:
                kw["start_new_session"] = True
            subprocess.Popen([exe, "serve"], **kw)
            for _ in range(20):
                if _port_busy(OLLAMA_PORT):
                    break
                time.sleep(0.5)
        if not _port_busy(OLLAMA_PORT):
            say("Ollama is installed but wouldn't start — the local model "
                "stays off for now.")
            set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
            return not required
        say("Pulling the small offline model…")
        r = subprocess.run([exe, "pull", model], timeout=900,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if r.returncode == 0:
            say("Local brain is armed.")
            return True
        say("Couldn't fetch the model.")
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        return not required
    except Exception as e:
        # NEVER fail an install over an OPTIONAL backup path. But if this was
        # the only brain, the caller still has to hear about it.
        say(f"Local model setup did not complete ({e}).")
        set_env_key(dest, "LEON_LOCAL_LLM_MODE", "off")
        return not required
