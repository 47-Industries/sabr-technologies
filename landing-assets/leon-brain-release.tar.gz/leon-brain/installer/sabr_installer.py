#!/usr/bin/env python3
"""Sabr SI — installer bootstrapper.

ONE generic installer for every customer and every OS. It carries no
per-customer data: the user pastes the install token from the web
onboarding wizard (sabrtechnologies.com/onboard), and everything
specific — SI name, owner, local-vs-hosted brain, service keys — comes
from the server's install-config contract (v1). The one exception: the
customer may name their SI right here at install time, and that local
choice wins over the server's. Their OWN name is never asked for — the
SI learns who its owner is the way anyone does, by being introduced.

Stdlib only (tkinter + urllib + venv), so PyInstaller can freeze it into
a double-clickable app per OS with nothing to pip-install first.

    python3 sabr_installer.py                      # GUI wizard
    python3 sabr_installer.py --token T --no-gui   # headless
    ... --dry-run    # everything except deps/services/launch
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import plistlib
import secrets
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import tempfile
import urllib.error
import urllib.parse
import urllib.request

ONBOARDING_URL = os.environ.get("SABR_ONBOARDING_URL", "https://sabrtechnologies.com")

# ── install log ────────────────────────────────────────────────────────
# Opened before ANY step can fail, so a failure always has a paper trail
# on the customer's disk. A frozen GUI has no console: without this, the
# only evidence of a broken install is one truncated line in a tk label.
_LOG_FH = None
_LOG_PATH = None


def _timestamp() -> str:
    import time
    return time.strftime("%Y%m%d-%H%M%S")


def _log_open(dest: str) -> str:
    """Open the install log. Never raises — logging must not break installs."""
    global _LOG_FH, _LOG_PATH
    for candidate in (dest, tempfile.gettempdir()):
        try:
            os.makedirs(candidate, exist_ok=True)
            path = os.path.join(candidate, "sabr-install.log")
            fh = open(path, "a", encoding="utf-8", errors="replace")
            _LOG_FH, _LOG_PATH = fh, path
            fh.write(f"\n===== install start | {sys.platform} | "
                     f"frozen={getattr(sys, 'frozen', False)} | dest={dest} =====\n")
            fh.flush()
            return path
        except Exception:
            continue
    return ""


def _log(msg: str) -> None:
    if _LOG_FH is None:
        return
    try:
        _LOG_FH.write(str(msg).rstrip() + "\n")
        _LOG_FH.flush()
    except Exception:
        pass


def _log_hint() -> str:
    return f" Full log: {_LOG_PATH}" if _LOG_PATH else ""


#: Loader variables PyInstaller points at its own unpack dir so OUR bundled
#: libraries win inside the frozen process. They must never reach a shelled-out
#: system interpreter.
_LOADER_VARS = ("LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH", "DYLD_INSERT_LIBRARIES")


def _clean_env() -> dict:
    """The environment a child process should get: ours, minus the bundle.

    The frozen binary runs with LD_LIBRARY_PATH (DYLD_* on macOS) pointing at
    its PyInstaller unpack dir. Every subprocess inherited that, so the system
    python we shell out to loaded OUR OpenSSL instead of its own. On any
    machine whose OpenSSL is newer than the build runner's, that makes
    `import ssl` fail with

        ImportError: .../libcrypto.so.3: version `OPENSSL_3.3.0' not found
                     (required by .../_ssl.cpython-3xx.so)

    and with no ssl the venv build, ensurepip, get-pip and `pip install` all
    die in a row — the whole install, on a machine with nothing wrong with it.
    Ubuntu 24.04 matches the runner, which is exactly why this survived
    testing. PyInstaller stashes the caller's real values as <VAR>_ORIG for
    this purpose, so put those back where they exist and drop the var where
    they do not.
    """
    env = os.environ.copy()
    # Children get UTF-8 mode too: pip, venv and the SI all do text I/O
    # on a machine whose codepage we do not control.
    env["PYTHONUTF8"] = "1"
    for var in _LOADER_VARS:
        original = env.pop(var + "_ORIG", None)
        if original:
            env[var] = original
        else:
            env.pop(var, None)
    return env


def _run(argv, what: str, check: bool = True, timeout: int = 1800):
    """Run a subprocess, log everything, and fail with a READABLE message.

    subprocess.CalledProcessError stringifies to "Command [...] returned
    non-zero exit status 2" and throws the stderr away — which is exactly
    the useless error a customer pasted back to us. Never again: the real
    stderr goes in the message and in the log."""
    _log(f"$ {' '.join(str(a) for a in argv)}")
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace",
                           env=_clean_env())
    except FileNotFoundError:
        raise InstallError(f"{what} failed: {argv[0]} not found on this machine."
                           + _log_hint())
    except subprocess.TimeoutExpired:
        raise InstallError(f"{what} timed out after {timeout // 60} minutes."
                           + _log_hint())
    if r.stdout:
        _log(r.stdout[-4000:])
    if r.stderr:
        _log("stderr: " + r.stderr[-4000:])
    _log(f"-> exit {r.returncode}")
    if check and r.returncode != 0:
        detail = (r.stderr or r.stdout or "").strip().splitlines()
        tail = " | ".join(detail[-3:])[:400] or f"exit status {r.returncode}"
        raise InstallError(f"{what} failed: {tail}" + _log_hint())
    return r


def _is_pip_cache_permission_error(stdout: str, stderr: str) -> bool:
    """True when pip died because its wheel cache is unreadable/unwritable.

    Module level so the regression test can hit it with the exact stderr a
    real customer produced, without spinning up a venv.
    """
    blob = ((stderr or "") + (stdout or "")).lower()
    if "permission denied" not in blob and "errno 13" not in blob:
        return False
    return ("pip\\cache" in blob or "pip/cache" in blob
            or "\\wheels\\" in blob or "/wheels/" in blob)


def _ssl_context():
    """TLS context that works inside a PyInstaller-frozen binary.

    Frozen Python doesn't inherit the build machine's CA paths, so the
    default context fails cert verification on many customer machines.
    certifi is bundled by the packaging CI; fall back to the system
    default when running from source without it."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _urlopen(url, timeout: float):
    """url may be a str or a urllib.request.Request (for auth headers)."""
    return urllib.request.urlopen(url, timeout=timeout, context=_ssl_context())


def _safe_extractall(tar, dest: str) -> None:
    """extractall for interpreters with no tarfile filter support.

    Mirrors what filter="data" enforces: every member must land strictly
    inside dest, and no links (a symlink pointing at /etc/passwd followed by
    a write through it escapes just as effectively as a ../ path).
    """
    dest_real = os.path.realpath(dest)
    for m in tar.getmembers():
        if m.issym() or m.islnk():
            raise InstallError("The SI archive contains a link entry and was "
                               "rejected. Nothing was installed.")
        target = os.path.realpath(os.path.join(dest_real, m.name))
        if target != dest_real and not target.startswith(dest_real + os.sep):
            raise InstallError("The SI archive tried to write outside the "
                               "install folder and was rejected. Nothing was "
                               "installed.")
    tar.extractall(dest)


def _ensure_writable_dir(path: str) -> None:
    """Create the install directory, or fail with something a customer can act
    on. os.makedirs raised OSError straight out of download_release, past
    main()'s `except InstallError`, so --no-gui printed a raw traceback and a
    PyInstaller "Failed to execute script" line. (The GUI caught it as
    "Unexpected error", so this only ever bit the CLI path.)"""
    try:
        os.makedirs(path, exist_ok=True)
    except OSError as e:
        raise InstallError(
            f"Can't create the install folder at {path} ({e.strerror}). "
            f"Choose a folder you own with --dest, or free up the permissions "
            f"on that path, then run this again." + _log_hint())
    if not os.access(path, os.W_OK):
        raise InstallError(
            f"The install folder {path} isn't writable by this account. "
            f"Choose a folder you own with --dest, then run this again."
            + _log_hint())


def _find_system_python() -> str:
    """A REAL python interpreter to build the body's venv with.

    When we're a frozen PyInstaller binary, sys.executable is this .exe — not
    a Python — so `sys.executable -m venv` cannot work. Find a genuine system
    Python instead. Running from source, sys.executable already is one."""
    if not getattr(sys, "frozen", False):
        return sys.executable
    import shutil
    # PREFER A PYTHON THE WHEEL ECOSYSTEM HAS CAUGHT UP TO (2026-08-10).
    #
    # `py -3` and a bare `python3` both mean "the NEWEST Python installed".
    # On a real customer box that resolved to 3.14, and 3.14 is far enough
    # ahead of the ecosystem that pyaudio, webrtcvad and friends ship no
    # wheels for it — so pip fell back to compiling C, hit the missing MSVC
    # toolchain, and took the whole install down. There was a version FLOOR
    # and no CEILING, so the installer was actively seeking out the most
    # bleeding-edge interpreter on the machine: the worst possible choice.
    #
    # So: ask for known-good versions NEWEST-FIRST, and only fall back to
    # "whatever's newest" if none of them exist. Same trap waits on macOS,
    # where `brew install python` also tracks the newest release — which is
    # why the preference list is applied on every OS, not just Windows.
    candidates = []
    if IS_WINDOWS:
        candidates += [["py", f"-3.{m}"] for m in PY_PREFERRED]
        candidates += [["py", "-3"], ["python"], ["python3"]]
    else:
        candidates += [[f"python3.{m}"] for m in PY_PREFERRED]
        candidates += [["python3"], ["python"]]
    rejected = []
    for cand in candidates:
        exe = shutil.which(cand[0])
        if not exe:
            rejected.append(f"{cand[0]}: not on PATH")
            continue
        argv = [exe] + cand[1:]
        try:
            r = subprocess.run(
                argv + ["-c", "import venv,sys;print(sys.executable);"
                              "print('%d.%d' % sys.version_info[:2])"],
                capture_output=True, text=True, timeout=25,
                encoding="utf-8", errors="replace", env=_clean_env())
        except Exception as e:
            rejected.append(f"{cand[0]}: {e}")
            continue
        out = (r.stdout or "").strip().splitlines()
        if r.returncode != 0 or len(out) < 2:
            why = (r.stderr or "no output").strip().splitlines()
            rejected.append(f"{cand[0]}: {why[-1][:120] if why else 'no venv module'}")
            continue
        resolved, ver = out[0].strip(), out[1].strip()
        # The Microsoft Store stub in WindowsApps answers -c fine but cannot
        # build a usable venv in LOCALAPPDATA (redirected, sandboxed writes).
        if "WindowsApps" in resolved:
            rejected.append(f"{cand[0]}: Microsoft Store stub ({resolved})")
            continue
        try:
            major, minor = (int(x) for x in ver.split(".")[:2])
        except Exception:
            major, minor = 3, 0
        if (major, minor) < PY_FLOOR:
            rejected.append(f"{cand[0]}: Python {ver} is too old "
                            f"(need {PY_FLOOR[0]}.{PY_FLOOR[1]}+)")
            continue
        _log(f"system python: {resolved} (v{ver}) via {' '.join(cand)}")
        return resolved
    _log("no usable python: " + "; ".join(rejected))
    floor = f"{PY_FLOOR[0]}.{PY_FLOOR[1]}"
    if IS_WINDOWS:
        how = (f"Install Python {floor}+ from python.org (tick “Add python.exe "
               f"to PATH”, and don't use the Microsoft Store version)")
    elif IS_MAC:
        how = f"Install Python {floor}+ from python.org, or `brew install python`"
    else:
        how = (f"Install Python {floor}+ with your package manager "
               f"(e.g. sudo apt install python3 python3-venv)")
    raise InstallError(
        f"No usable Python 3 found on this machine. {how}, then run this "
        "installer again. Checked: " + "; ".join(rejected)[:300] + _log_hint())
CONTRACT_VERSION = 1

#: The gate enforced 3.9 while the rejection message told people to install
#: 3.11+ — so a 3.10 machine sailed past the check and died later inside pip,
#: with an error naming neither Python nor the version. One number now, and it
#: is the one bootstrap.sh already derived from numpy/scipy Requires-Python.
PY_FLOOR = (3, 11)

#: Minor versions to prefer, NEWEST FIRST, before falling back to "whatever
#: the newest installed Python is". These are the versions the binary-wheel
#: ecosystem actually covers. Bump the front of this list only once wheels
#: for that version exist for the C-extension deps (sounddevice, soundfile,
#: onnxruntime, vosk, webrtcvad-wheels) — NOT when the version merely ships.
#: Verify before bumping:
#:   pip download --only-binary=:all: --python-version 3.X <pkg>
PY_PREFERRED = (13, 12, 11)

IS_LINUX = sys.platform.startswith("linux")
IS_MAC = sys.platform == "darwin"
IS_WINDOWS = sys.platform.startswith("win")


def _write_constraints(req_path: str, dest: str):
    """A pip constraints file distilled from requirements.txt.

    Constraints are stricter than requirements about syntax: extras
    (`uvicorn[standard]`) are rejected outright, and a bare name with no
    version constrains nothing, so both are dropped. Environment markers are
    kept — a marker'd pin still has to hold on the platform it applies to.

    Returns the path, or None if there was nothing worth constraining or the
    file could not be written. A missing constraints file must never fail an
    install: worst case we are back to the old unpinned behaviour.
    """
    lines = []
    try:
        for spec in _parse_requirements(req_path):
            spec = spec.strip()
            if not spec or spec.startswith("-"):
                continue
            head, sep, marker = spec.partition(";")
            if "[" in head:                       # extras are illegal here
                head = head[:head.index("[")] + head[head.index("]") + 1:]
            if not any(op in head for op in ("==", ">=", "<=", "~=", ">", "<")):
                continue                           # unversioned: no constraint
            lines.append(head.strip() + (sep + marker if sep else ""))
        if not lines:
            return None
        path = os.path.join(dest, ".pip-constraints.txt")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("# Generated by the installer. Makes requirements.txt's\n"
                     "# pins binding during package-by-package recovery.\n")
            fh.write("\n".join(lines) + "\n")
        return path
    except OSError as e:
        _log(f"constraints file skipped ({e}) — install continues unpinned")
        return None


def _os_account_name() -> str:
    """The human's name on this machine, for LEON_USER_NAME's last resort.

    Never raises and never returns the empty string — an empty owner name is
    the exact defect this exists to stop. "friend" is a deliberate choice
    over "" or "user": the SI says this word out loud.
    """
    for var in ("USERNAME", "USER", "LOGNAME"):
        val = (os.environ.get(var) or "").strip()
        if val and val.lower() not in {"root", "administrator", "system"}:
            return val
    try:
        import getpass
        val = (getpass.getuser() or "").strip()
        if val and val.lower() not in {"root", "administrator", "system"}:
            return val
    except Exception:
        pass
    return "friend"


def _req_name(spec: str) -> str:
    """Bare distribution name from a requirement line, for display + dedupe."""
    spec = spec.split(";", 1)[0].strip()          # drop environment marker
    for sep in ("===", "==", ">=", "<=", "~=", "!=", ">", "<", "["):
        spec = spec.split(sep, 1)[0]
    return spec.strip().lower().replace("_", "-")


def _parse_requirements(path: str) -> list:
    """Requirement lines that apply to THIS machine, in file order.

    Environment markers are honoured (`; sys_platform == "linux"`), because
    the one-at-a-time retry installs each line directly — and pip applied to
    a bare spec ignores the marker it was given on the line. Without this,
    the Windows retry would try to install evdev, a Linux-only package that
    cannot build there, and report a scary failure for something that was
    never meant to be installed in the first place.
    """
    out = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        return out
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line or line.startswith("-"):
            continue
        if ";" in line:
            spec, marker = line.split(";", 1)
            try:
                # Same evaluator pip uses; if it's unavailable, keep the line
                # rather than silently dropping a real dependency.
                from packaging.markers import Marker
                if not Marker(marker.strip()).evaluate():
                    continue
            except ImportError:
                pass
            except Exception:
                continue
            line = spec.strip()
        if line:
            out.append(line)
    return out


def default_install_dir() -> str:
    home = os.path.expanduser("~")
    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
        return os.path.join(base, "SabrSI")
    return os.path.join(home, "SabrSI")


def fetch_config(base_url: str, token: str) -> dict:
    """Redeem the install token for this customer's config."""
    # Token rides in a header so it stays out of server access logs. The
    # query param is transitional — drop it once the VPS wizard reads the
    # header (it's single-use, so the exposure window is one redemption).
    url = f"{base_url.rstrip('/')}/api/onboarding/install-config?token={urllib.parse.quote(token)}"
    req = urllib.request.Request(url, headers={"X-Install-Token": token})
    try:
        with _urlopen(req, timeout=20) as r:
            cfg = json.load(r)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise InstallError("That token wasn't recognized. Copy it again from the "
                               "onboarding page — it starts after 'token:'.")
        raise InstallError(f"Server error ({e.code}). Try again in a minute.")
    except Exception as e:
        raise InstallError(f"Couldn't reach {base_url} — check your internet. ({e})")
    if not cfg.get("ok"):
        raise InstallError(cfg.get("error", "Invalid config response"))
    if cfg.get("version", 0) > CONTRACT_VERSION:
        raise InstallError("This installer is out of date — download the latest "
                           f"from {base_url}.")
    return cfg


class InstallError(Exception):
    """User-facing failure with a plain-English message."""


class Installer:
    def __init__(self, cfg: dict, dest: str, base_url: str,
                 progress=print, dry_run: bool = False):
        self.cfg = cfg
        self.dest = dest
        self.base_url = base_url.rstrip("/")
        self.say = progress
        self.dry = dry_run

    # ── steps ──────────────────────────────────────────────────────
    def run(self):
        name = self.cfg.get("si_name", "your SI")
        self.say(f"Installing {name}…")
        self.download_release()
        self._repair_windows_acls()
        self.write_env()
        if not self.dry:
            self.install_deps()
            self.register_autostart()
            self.launch()
            # DO NOT SAY "READY" WITHOUT LOOKING. Added 2026-08-11.
            #
            # This line used to print unconditionally, one statement after a
            # bare Popen with no poll and no returncode. Nothing between the
            # launch and the word "ready" could ever have observed a dead SI,
            # so every way an install can come up broken — deps that failed
            # to wheel, a runner script that never got written, a crash-loop
            # restarting every five seconds forever — ended with a green
            # "ready" and a customer who believes the problem is on their end.
            # That is the same shape as the missing entry point: succeed
            # loudly, fail silently.
            #
            # A failure here is NOT an InstallError. The files are on disk and
            # autostart is registered; a reboot may well fix it. Say what is
            # actually true and point at the log.
            if not self._wait_until_answering():
                self.say(f"{name} is installed, but it has not started "
                         f"answering yet.")
                self.say(f"Give it a minute, or restart this computer. If it "
                         f"still does not come up, the reason is in "
                         f"{os.path.join(self.dest, 'sabr-si.log')} — send us "
                         f"that file.")
                return
        self.say(f"{name} is ready.")

    def _wait_until_answering(self, timeout: float = 90.0) -> bool:
        """Poll the SI's own port until it responds, or give up.

        Local mode serves HTTP on 8000. Hosted mode runs the body, which
        listens on nothing — there is no port to poll, so we cannot prove
        liveness this way and must not claim failure we did not observe.
        """
        if self.cfg.get("brain_mode") != "local":
            return True
        port = 8000
        deadline = time.monotonic() + timeout
        told = False
        while time.monotonic() < deadline:
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=2):
                    return True
            except OSError:
                pass
            if not told and time.monotonic() > deadline - timeout + 12:
                # First boot builds the neural state; silence for a while is
                # normal. Say so, or the wait reads as a hang.
                self.say("Still waking up — first boot takes a moment…")
                told = True
            time.sleep(2)
        return False

    def download_release(self):
        _ensure_writable_dir(self.dest)
        rel = self.cfg.get("artifacts", {}).get("release_tarball", "/download")
        url = rel if rel.startswith("http") else self.base_url + rel
        # No silent TLS downgrade. Once the digest below is the thing standing
        # between a customer and a tampered payload, plaintext transport would
        # make it the ONLY thing instead of the second layer.
        if not url.lower().startswith("https://"):
            raise InstallError("Refusing to download your SI over an insecure "
                               "connection. Contact support.")
        expected_sha = (self.cfg.get("artifacts", {})
                        .get("release_tarball_sha256", "") or "").strip().lower()
        self.say("Downloading your SI…")
        tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
        # Extract into a private empty dir, not self.dest: the "unwrap one
        # top-level dir" check must only ever see the tarball's own entries.
        # Anything already in dest (.env from a dry run, .venv from a retry)
        # would defeat the len==1 check and leave everything nested.
        extract_dir = tempfile.mkdtemp(prefix=".sabr-extract-", dir=self.dest)
        try:
            try:
                with _urlopen(url, timeout=120) as r:
                    total = 0
                    try:
                        total = int(r.headers.get("Content-Length") or 0)
                    except Exception:
                        total = 0
                    got, last_pct = 0, -5
                    hasher = hashlib.sha256()
                    _log(f"downloading {url} ({total} bytes)")
                    while chunk := r.read(1 << 20):
                        tmp.write(chunk)
                        hasher.update(chunk)
                        got += len(chunk)
                        # Silence for 350MB reads as a hang. Report progress.
                        if total:
                            pct = int(got * 100 / total)
                            if pct >= last_pct + 2:
                                last_pct = pct
                                self.say(f"Downloading your SI… {pct}% "
                                         f"({got >> 20} of {total >> 20} MB)")
                        elif got >> 20 != last_pct:
                            last_pct = got >> 20
                            self.say(f"Downloading your SI… {last_pct} MB")
                    _log(f"downloaded {got} bytes")
            finally:
                tmp.close()  # Windows can't unlink an open handle

            # A connection that dies mid-stream looks exactly like success to
            # the loop above — it just stops yielding chunks. Catch it here so
            # the customer gets "your connection dropped, try again" instead of
            # a baffling corrupt-archive traceback.
            if total and got != total:
                raise InstallError(
                    f"The download stopped early ({got >> 20} of {total >> 20} MB). "
                    "Your connection dropped — nothing was installed. Try again.")

            if not expected_sha:
                raise InstallError("The server did not send a fingerprint for "
                                   "your SI, so it can't be verified. Nothing "
                                   "was installed. Contact support.")
            actual_sha = hasher.hexdigest()
            _log(f"sha256 expected={expected_sha} actual={actual_sha}")
            if actual_sha != expected_sha:
                raise InstallError(
                    "The downloaded SI doesn't match its fingerprint, so it was "
                    "discarded and nothing was installed. This is usually a "
                    "corrupted download — try again. If it keeps happening, "
                    "stop and contact support.")

            with tarfile.open(tmp.name, "r:gz") as tar:
                # Python ≥3.12 (and backports) require an explicit filter.
                # Where it's missing, fail closed rather than silently doing an
                # unfiltered extractall — an archive with ../ or absolute paths
                # would otherwise write outside extract_dir. Customer machines
                # run whatever Python they have, so this is not hypothetical.
                if hasattr(tarfile, "data_filter"):
                    tar.extractall(extract_dir, filter="data")
                else:
                    _safe_extractall(tar, extract_dir)
            entries = os.listdir(extract_dir)
            root = extract_dir
            if len(entries) == 1 and os.path.isdir(os.path.join(extract_dir, entries[0])):
                root = os.path.join(extract_dir, entries[0])
            for item in os.listdir(root):
                # A customer's whole life is in brain_state, and their identity
                # and keys are in .env. Today these survive an update only
                # because build_release.sh excludes them from the tarball — a
                # build-time invariant enforced in a different file. The day one
                # bad build includes brain_state, the sha256 check would VERIFY
                # that build as authentic and the rmtree below would delete
                # everything they've accumulated, silently, on a routine update.
                # Refuse to touch them here regardless of what the archive says.
                if item in ("brain_state", ".env", ".venv"):
                    _log(f"refusing to replace {item} from release archive")
                    continue
                target = os.path.join(self.dest, item)
                if os.path.lexists(target):
                    if os.path.isdir(target) and not os.path.islink(target):
                        shutil.rmtree(target)  # stale copy from a prior run
                    else:
                        os.remove(target)
                os.replace(os.path.join(root, item), target)
            # Stamp what we just verified. bootstrap.sh has always written this
            # (landing/bootstrap.sh:915); this installer never did — so every
            # customer who installed via the downloaded EXE/app was permanently
            # update-blind. auto_update.installed_release() reads exactly this
            # key, gets "" for an unstamped install, and returns silently, so
            # nothing ever told them a newer release existed and nothing could
            # answer "what version are you running?" during support.
            # The digest is verified by this point, so this records a fact.
            if expected_sha:
                try:
                    with open(os.path.join(self.dest, ".sabr-release"), "w",
                              encoding="utf-8") as fh:
                        fh.write(f"release_sha256={expected_sha}\n")
                        fh.write("installed_at=" + time.strftime(
                            "%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + "\n")
                except OSError:
                    pass  # a missing stamp must never fail a good install
        except InstallError:
            raise
        except Exception as e:
            raise InstallError(f"Download failed: {e}")
        finally:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass  # never mask the real error with a cleanup failure
            shutil.rmtree(extract_dir, ignore_errors=True)

    def _repair_windows_acls(self):
        """Make the freshly-extracted tree readable by the human who will run it.

        On Windows, a process running ELEVATED creates files owned by
        BUILTIN\\Administrators, and the default ACL that lands on them has an
        OWNER RIGHTS entry, SYSTEM, and Administrators — and NO entry for the
        actual user account. That tree is unreadable from the owner's ordinary
        desktop session.

        The failure mode is vicious because nothing reports it. The install
        finishes green. Autostart registers fine. Then at every logon the
        supervisor launches, python opens run.py, and gets:

            can't open file '...\\SabrSI\\run.py': [Errno 13] Permission denied

        ...forever, in a retry loop, with the only evidence buried in a log
        the customer has no reason to open. It reads as "the product just
        doesn't work on my machine."

        Observed for real on 2026-08-11: an install placed by an elevated
        session left the whole tree owned by Administrators and the SI could
        not start from the owner's own session until ownership and an explicit
        user ACE were restored across 53,494 files.

        So: never assume the installer was launched unelevated. Repair
        unconditionally, right after extraction and before anything tries to
        run. Best-effort — a failure here must never fail an otherwise good
        install, because on an unelevated install this is already correct and
        the repair is a no-op.
        """
        if not IS_WINDOWS or self.dry:
            return
        user = os.environ.get("USERNAME") or ""
        if not user:
            return
        computer = os.environ.get("COMPUTERNAME") or ""
        account = f"{computer}\\{user}" if computer else user
        try:
            # takeown first: if the tree is owned by Administrators, the
            # OWNER RIGHTS ACE grants THEM, not the human, and a grant alone
            # can be refused. /D Y answers the "take ownership?" prompt.
            subprocess.run(["takeown", "/F", self.dest, "/R", "/D", "Y"],
                           check=False, capture_output=True, timeout=900,
                           env=_clean_env())
            subprocess.run(["icacls", self.dest,
                            "/grant", f"{account}:(OI)(CI)F",
                            "/T", "/C", "/Q"],
                           check=False, capture_output=True, timeout=900,
                           env=_clean_env())
            _log(f"ACL repair applied for {account} on {self.dest}")
        except (OSError, subprocess.SubprocessError) as e:
            _log(f"ACL repair skipped ({e}) — install continues")

    def write_env(self):
        self.say("Writing your configuration…")
        cfg = self.cfg
        # Read the existing .env FIRST. Several decisions below have to defer
        # to what is already installed on this machine, and they cannot do
        # that if the file is read after the new one is composed.
        env_path = os.path.join(self.dest, ".env")
        prior = {}
        try:
            with open(env_path, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, _, v = line.partition("=")
                        prior[k.strip()] = v.strip()
        except OSError:
            pass          # fresh box, or unreadable — everything below mints new.

        # AN EXISTING INSTALL'S BRAIN MODE WINS. Fixed 2026-08-11; this was the
        # worst bug in the update path and it was completely silent.
        #
        # This line used to be cfg.get('brain_mode', 'hosted'). If the server's
        # onboarding config omitted brain_mode for a tenant, an UPDATE of a
        # working LOCAL install rewrote it to hosted. Mode decides the entry
        # point (_entry_cmd), so autostart got repointed from run.py to
        # run_body.py against a remote brain — and the local brain_state on
        # that machine, the SI's entire accumulated life, became a directory
        # nothing opens. On the box this was found on that was 270,805 steps.
        # No error, no prompt. The SI comes back up, answers, and remembers
        # nothing, and there is no way for the owner to know why.
        #
        # The carry-forward loop further down could never save it either:
        # LEON_BRAIN_MODE is in `_ours`, so the prior value was explicitly
        # skipped. It needs the same rescue LEON_API_KEY already gets.
        brain_mode = (cfg.get("brain_mode")
                      or prior.get("LEON_BRAIN_MODE")
                      or "hosted")
        cfg["brain_mode"] = brain_mode
        lines = [
            f"# Sabr SI — {cfg.get('si_name','')} for {cfg.get('user_name','')}",
            # Identity, with a floor under it. An empty LEON_USER_NAME is not
            # cosmetic: the SI addresses its owner as "" and its STT prompt
            # loses the one proper noun it hears most. Dean's own box shipped
            # with LEON_USER_NAME= because the tenant record carried no
            # user_name. Prefer the server, then whatever is already
            # installed, then the actual account name on this machine.
            f"LEON_SI_NAME={cfg.get('si_name') or prior.get('LEON_SI_NAME') or 'Leon'}",
            f"LEON_USER_NAME={cfg.get('user_name') or prior.get('LEON_USER_NAME') or _os_account_name()}",
            f"LEON_TENANT_TOKEN={cfg.get('_token','')}",
            # The SAME token under the name the entitlement gate actually
            # reads. brain/cognition_gate.py and brain/tenant.py look for
            # SABR_TENANT_TOKEN; every installer except bootstrap.sh wrote
            # only LEON_TENANT_TOKEN, so the gate saw an unlicensed machine
            # on every GUI install. Two names for one value is the bug, but
            # renaming a key read in the field breaks live installs — write
            # both, and let the reader be wrong quietly instead of the
            # customer being locked out loudly.
            f"SABR_TENANT_TOKEN={cfg.get('_token','')}",
            f"LEON_BRAIN_MODE={brain_mode}",
        ]
        # The dashboard login key. This MUST be written here, in every mode,
        # and MUST be the value we show the owner at the end of the install.
        #
        # It used to be written only in hosted mode. In local mode run.py's
        # first boot generated one itself and appended it to .env — so the
        # key the owner was told to paste was a value that had never existed,
        # and the login screen said "dashboard key invalid" on a completely
        # healthy install. Generating it up here means there is exactly one
        # key, we know it, and run.py's auto-generate branch never fires.
        #
        # AND ON A REINSTALL, REUSE THE KEY THAT IS ALREADY THERE. Fixed
        # 2026-08-11, the same defect one layer over from the one above. This
        # branch minted a fresh token on EVERY run and then rewrote .env from
        # scratch, so choosing UPDATE / REINSTALL — the thing an owner does
        # when something looks wrong — silently invalidated the key they had
        # already saved, and the login screen said "dashboard key invalid" on
        # an install that was otherwise perfectly healthy. Same user-visible
        # symptom as the bug above, opposite cause, so fixing one looked like
        # fixing both. It did not.
        api_key = ((cfg.get("hosted", {}) or {}).get("api_key")
                   or prior.get("LEON_API_KEY") or "")
        if not api_key:
            api_key = secrets.token_urlsafe(32)
        cfg["dashboard_key"] = api_key
        lines.append(f"LEON_API_KEY={api_key}")
        if cfg.get("brain_mode") == "hosted":
            hosted = cfg.get("hosted", {})
            lines.append(f"LEON_BRAIN_URL={hosted.get('brain_url','')}")
        # Bind loopback only. The brain's own default is 0.0.0.0, which is
        # right for a firewalled server and wrong for someone's personal
        # machine: it makes Windows Defender raise a "allow python.exe on
        # public networks" prompt on first launch, and a careful owner
        # clicks Block — which firewalls the SI off from its own dashboard.
        lines.append("LEON_HOST=127.0.0.1")
        if cfg.get("elevenlabs_voice_id"):
            lines.append(f"ELEVENLABS_VOICE_ID={cfg['elevenlabs_voice_id']}")
        for key, val in (cfg.get("service_keys") or {}).items():
            if val and key.replace("_", "").isalnum():
                lines.append(f"{key}={val}")
        # ── RUNTIME DEFAULTS: think, hear, speak ─────────────────────────
        # Added 2026-08-12 after Dean's own Windows box. Everything above
        # this line is identity and auth — which is ALL this installer used
        # to write. The generated .env had no model settings, no speech
        # settings and no STT settings whatsoever, and the failure is not a
        # crash: the responder falls back to the cheapest model, every turn
        # spawns a cold process, and the SI answers in two-word fragments
        # while the dashboard spins with no error frame. Looks brain-damaged,
        # reads as "the product is bad."
        #
        # install_client.py has emitted this block for a while and there is a
        # regression test pinning it (tests/test_install_env_completeness.py)
        # — but that test reads install_client.py, and THIS is the installer
        # customers actually run. One guarded path, one unguarded path, and
        # the shipping one was the unguarded one. The test now covers both.
        #
        # prior wins on every key: an owner who tuned a value in the
        # dashboard keeps it through an update. These are floors, not policy.
        for key, val in (
            # Thinking. Absent -> cheapest model -> fragment replies.
            ("LEON_MODEL", "claude-opus-4-7"),
            ("LEON_CLI_MODEL", "opus"),
            ("LEON_CLI_DAEMON_MODEL", "sonnet"),
            ("LEON_CLI_CHITCHAT_MODEL", "opus"),
            ("LEON_DISTILL_WINDOW", "40"),
            # Absent -> cold process per turn -> the forever-spinner.
            ("LEON_PERSISTENT_CLAUDE", "1"),
            # Local model is a BACKUP, never the voice of a real
            # conversation. Inert until ollama is present; provision_local_llm
            # arms it during install.
            ("LEON_LOCAL_LLM_MODE", "fallback"),
            ("LEON_LOCAL_MODEL", "llama3.2:3b"),
            # Hearing. faster-whisper ships in requirements.txt, so it works
            # offline on a stock box; preferring a cloud backend with no key
            # makes every boot initialise something that cannot work.
            ("LEON_STT_PREFER", "faster-whisper"),
            # Bias the transcriber toward the two proper nouns it hears more
            # than any other words. Without it "Leon" comes back as "Leanne".
            ("LEON_STT_INITIAL_PROMPT",
             f"{cfg.get('si_name') or 'Leon'}, "
             f"{cfg.get('user_name') or _os_account_name()}, dashboard, "
             f"neural, synapse, restart."),
            # Boot calm. A fresh SI with goal pursuit on starts driving tools
            # and terminals before its owner has configured anything. Flip
            # this to 0 in .env once you want it acting on its own — the same
            # default install_client.py has shipped for months.
            ("LEON_DISABLE_GOAL_PURSUIT", "1"),
            # Speech. Piper is bundled and free; ElevenLabs only when the
            # owner actually supplied a key, otherwise the ladder tries a
            # locked door first on every single utterance.
            ("LEON_TTS_PREFER",
             "elevenlabs" if (cfg.get("service_keys") or {}).get(
                 "ELEVENLABS_API_KEY") else "piper"),
        ):
            if key not in prior:
                lines.append(f"{key}={val}")
        # Carry forward anything the OWNER added by hand or through the
        # dashboard's Integrations panel. The wizard never asks for these a
        # second time, so rewriting the file without them is a silent delete
        # of credentials the installer did not put there and cannot restore.
        #
        # THIS MUST RUN LAST. It used to run before LEON_HOST / LEON_BRAIN_URL
        # / ELEVENLABS_VOICE_ID / service_keys were appended, so those keys
        # were not yet in `_ours`. On a reinstall the prior value was carried
        # forward as if the owner had typed it, and then the installer appended
        # its own copy — a duplicate that grew by one line on EVERY reinstall.
        # Found on Dean's Windows box 2026-08-11: two LEON_HOST lines after one
        # UPDATE / REINSTALL. Harmless while the values agree; a silent
        # last-line-wins conflict the moment they don't.
        _ours = {ln.split("=", 1)[0] for ln in lines if "=" in ln}
        for k, v in prior.items():
            if k not in _ours and k.replace("_", "").isalnum() and v:
                lines.append(f"{k}={v}")
        # env_path was resolved above, where the previous file is read.
        # utf-8 pinned: these lines carry si_name/user_name from the
        # server, so an accented name written under a Windows locale
        # produces bytes python-dotenv cannot read.
        with open(env_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        if not IS_WINDOWS:
            os.chmod(env_path, 0o600)

    def _venv_python(self, venv_dir: str) -> str:
        exe = "python.exe" if IS_WINDOWS else "python"
        return os.path.join(venv_dir, "Scripts" if IS_WINDOWS else "bin", exe)

    def _build_venv(self, py: str, venv_dir: str) -> str:
        """Create the venv, and if the normal way fails, try the ways that
        survive the machines where it fails. Returns the venv's python."""
        # A half-built venv from a previous failed attempt poisons retries.
        # Presence of python.exe is NOT proof the env works: a venv whose
        # pyvenv.cfg "home=" points at an interpreter the customer has since
        # uninstalled or upgraded keeps its python.exe stub, and every single
        # invocation of it fails. Presence-only checks reused that corpse and
        # reported a successful install on top of it. Run it before trusting it.
        if os.path.isdir(venv_dir):
            vpy = self._venv_python(venv_dir)
            dead = not os.path.exists(vpy)
            if not dead:
                try:
                    r = subprocess.run(
                        [vpy, "-c", "import sys, pip"],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        timeout=60,
                    )
                    dead = r.returncode != 0
                    if dead:
                        _log("existing venv interpreter is broken: "
                             + r.stdout.decode("utf-8", "replace")[-400:])
                except Exception as e:
                    dead = True
                    _log(f"existing venv interpreter did not run: {e}")
            if dead:
                _log(f"removing unusable venv at {venv_dir}")
                shutil.rmtree(venv_dir, ignore_errors=True)
        attempts = [
            (["-m", "venv", venv_dir], "Creating the Python environment"),
            # --copies: symlink creation needs Developer Mode or admin on
            # Windows, and fails on some network/OneDrive-backed profiles.
            (["-m", "venv", "--copies", venv_dir], "Creating the Python environment (copy mode)"),
            # No ensurepip on Debian/Ubuntu without python3-venv installed —
            # build the bare env, then bootstrap pip by hand.
            (["-m", "venv", "--without-pip", "--copies", venv_dir],
             "Creating the Python environment (minimal)"),
        ]
        last = None
        for argv, what in attempts:
            self.say(what + "…")
            try:
                _run([py] + argv, what)
            except InstallError as e:
                last = e
                _log(f"attempt failed, trying next: {e}")
                shutil.rmtree(venv_dir, ignore_errors=True)
                continue
            vpy = self._venv_python(venv_dir)
            if not os.path.exists(vpy):
                last = InstallError(f"{what} reported success but produced no "
                                    f"interpreter at {vpy}." + _log_hint())
                shutil.rmtree(venv_dir, ignore_errors=True)
                continue
            if "--without-pip" in argv:
                self.say("Bootstrapping the package installer…")
                try:
                    _run([vpy, "-m", "ensurepip", "--upgrade"], "Bootstrapping pip")
                except InstallError:
                    self._get_pip(vpy)
            return vpy
        raise last or InstallError("Could not create the Python environment."
                                   + _log_hint())

    def _get_pip(self, vpy: str) -> None:
        """Last-resort pip bootstrap for envs with no ensurepip."""
        tmp = os.path.join(tempfile.gettempdir(), "get-pip.py")
        with _urlopen("https://bootstrap.pypa.io/get-pip.py", timeout=60) as r, \
                open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
        _run([vpy, tmp], "Bootstrapping pip")

    def install_deps(self):
        self.say("Setting up Python environment (this takes a few minutes)…")
        venv_dir = os.path.join(self.dest, ".venv")
        py = _find_system_python()  # a real interpreter, not our frozen exe
        vpy = self._build_venv(py, venv_dir)
        # Always drive pip through the venv's own interpreter: the Scripts/pip
        # shim is absent in --without-pip envs and breaks if the path moves.
        pip = [vpy, "-m", "pip"]

        # PIP'S WHEEL CACHE CAN BE POISONED, AND IT KILLS THE WHOLE INSTALL
        # (2026-08-11, hit on a real Windows 10 box, user "Mr. Sabr").
        #
        # pip caches built wheels under %LOCALAPPDATA%\pip\cache\wheels. If a
        # single file in there is unreadable/unwritable — left over from an
        # install run under a different account, an interrupted write, or an
        # antivirus lock — pip does NOT skip it. It aborts the entire run with
        #   OSError: [Errno 13] Permission denied: '...\\pyautogui-...whl'
        # and every retry hits the same poisoned file, so the batch retry and
        # the per-package retry all die on the identical error. From the
        # customer's side the installer just refuses to work, forever, with a
        # message about a path they've never heard of.
        #
        # The cache is a speed optimisation and nothing else. So: when we see
        # a cache-permission failure, permanently switch this run to
        # --no-cache-dir and try again. Slower, always correct, and it cannot
        # be poisoned because it never touches the cache.
        cache_disabled = [False]

        def _pip_run(args, what, check=True):
            """pip, with automatic fallback off a poisoned wheel cache."""
            flags = ["--no-cache-dir"] if cache_disabled[0] else []
            res = _run(pip + args[:1] + flags + args[1:], what, check=False)
            if res.returncode != 0 and not cache_disabled[0] and \
                    _is_pip_cache_permission_error(res.stdout, res.stderr):
                cache_disabled[0] = True
                _log("pip wheel cache is unusable — retrying with --no-cache-dir")
                self.say("Working around a damaged package cache…")
                res = _run(pip + args[:1] + ["--no-cache-dir"] + args[1:],
                           what, check=check)
            elif check and res.returncode != 0:
                detail = (res.stderr or res.stdout or "").strip().splitlines()
                tail = " | ".join(detail[-3:])[:400] or f"exit {res.returncode}"
                raise InstallError(f"{what} failed: {tail}" + _log_hint())
            return res

        _pip_run(["install", "--upgrade", "pip", "wheel", "setuptools"],
                 "Updating the package installer", check=False)
        req = os.path.join(self.dest, "requirements.txt")
        self.say("Installing packages (a few minutes)…")
        r = _pip_run(["install", "-r", req], "Installing packages", check=False)
        if r.returncode != 0:
            # WHY THIS IS NOT A BATCH RETRY (2026-08-10, measured on a real
            # Windows 10 box running Python 3.14):
            #
            # `pip install -r` is all-or-nothing. pyaudio and webrtcvad ship
            # no cp314 wheels, so pip tried to compile them from C, hit
            # "Microsoft Visual C++ 14.0 or greater is required", and aborted
            # the WHOLE run. The old fallback then installed a bare 12-package
            # core — which silently dropped piper-tts, pyttsx3, onnxruntime,
            # sounddevice, soundfile, elevenlabs, deepgram-sdk, vosk,
            # webrtcvad and aiohttp. Every one of those installs fine.
            #
            # Result: a "successful" install with no voice, no wake word and
            # no audio at all, reported to the owner as "some optional
            # packages failed". Two bad packages took ten good ones with them.
            #
            # So: core first (it must succeed), then every remaining
            # requirement ONE AT A TIME so a single unbuildable package can
            # only ever cost you that one package — and we name the casualties
            # instead of hiding them behind the word "optional".
            self.say("Batch install failed — retrying package by package…")
            core = ["numpy", "scipy", "fastapi", "uvicorn[standard]", "websockets",
                    "python-multipart", "python-dotenv", "Pillow", "mss", "psutil",
                    "pyautogui", "anthropic"]
            # EVERY one-at-a-time install is constrained by the full
            # requirements set. Found on Dean's box 2026-08-12: he had
            # transformers 5.15.0 installed even though requirements.txt
            # pins transformers>=4.40,<5 — because `pip install -r` never
            # completed, and in THIS loop each package resolves alone, so a
            # later package that merely tolerates transformers 5 happily
            # upgraded past the pin behind us. The pin held on paper and lost
            # on disk. Symptom on his machine: "[VISION] load failed:
            # cannot import name 'AutoModelForCausalLM'" — the SI came up
            # blind, and the pin's whole reason for existing (moondream2's
            # remote code dies on 5.x) was documented three feet away in the
            # requirements file. A constraints file makes the pin binding no
            # matter what order packages land in.
            cons = _write_constraints(req, self.dest)
            cflag = ["-c", cons] if cons else []
            _pip_run(["install", *cflag, *core], "Installing the core packages")
            rest = [p for p in _parse_requirements(req)
                    if _req_name(p) not in {_req_name(c) for c in core}]
            failed = []
            for spec in rest:
                rr = _pip_run(["install", *cflag, spec],
                              f"Installing {_req_name(spec)}", check=False)
                if rr.returncode != 0:
                    failed.append(_req_name(spec))
            if failed:
                self.say("Could not install: " + ", ".join(failed)
                         + " — everything else is in. Your SI runs; these "
                           "specific features stay off until they're fixed.")
            else:
                self.say("All packages installed on the second pass.")
        self.venv_python = vpy

    # ── what actually runs on this machine ────────────────────────
    def _entry_cmd(self) -> list:
        # Whatever interpreter install_deps actually produced — a guessed
        # path here writes an autostart entry that can never run.
        py = getattr(self, "venv_python", None) or \
            self._venv_python(os.path.join(self.dest, ".venv"))
        if self.cfg.get("brain_mode") == "local":
            script = os.path.join(self.dest, "run.py")
            cmd = [py, script, "--port", "8000"]
        else:
            # Hosted: this machine runs the BODY (senses + hands) against the
            # hosted brain named in .env (LEON_BRAIN_URL).
            script = os.path.join(self.dest, "run_body.py")
            cmd = [py, script]
        # Found 2026-08-11: run_body.py existed only in the repo CI used to
        # build from, never in the tarball this installs. A hosted tenant got
        # autostart pointed at a file that was never on disk — the install
        # reported success, the machine registered a boot entry, and nothing
        # ever ran. Silent, and invisible until someone asked why their SI was
        # dead. An entry point that isn't there is an install failure, not a
        # detail: fail here, where the message can still reach a person.
        if not os.path.exists(script):
            raise InstallError(
                f"Your SI installed, but the program that runs it "
                f"({os.path.basename(script)}) is missing from this release, "
                f"so it could not be started or set to start with this "
                f"machine.\n\nNothing is broken on your computer — this is our "
                f"packaging error. Please contact support and mention "
                f"'{os.path.basename(script)} missing'.")
        return cmd

    def register_autostart(self):
        self.say("Registering your SI to start with this machine…")
        cmd = self._entry_cmd()
        if IS_LINUX:
            unit_dir = os.path.expanduser("~/.config/systemd/user")
            os.makedirs(unit_dir, exist_ok=True)
            # No [Install]/enable: the XDG autostart entry below is the ONE
            # trigger. Wanting graphical-session.target raced it on GNOME/
            # Plasma — the target started the unit before the entry imported
            # DISPLAY, buying a crash loop at every login until the restart
            # cycle picked up the imported env. (And on Cinnamon/XFCE/MATE/
            # LXQt the target never activates at all, so it couldn't be the
            # trigger anyway.) systemd still owns the process and Restart=;
            # PartOf stops it with the session where the target exists.
            # self.dest and cmd (which embeds the venv python path) both live
            # under the user's home dir — an open() with no encoding= falls
            # back to the locale's preferred codec, and a non-ASCII home
            # directory on a non-UTF-8 locale would raise here mid-install.
            with open(os.path.join(unit_dir, "sabr-si.service"), "w",
                     encoding="utf-8") as f:
                f.write("[Unit]\nDescription=Sabr SI\n"
                        "After=graphical-session.target\n"
                        "PartOf=graphical-session.target\n\n"
                        "[Service]\n"
                        # PEP 540: every locale-default open() in the SI
                        # becomes UTF-8, whatever the machine's codepage.
                        "Environment=PYTHONUTF8=1\n"
                        # QUOTING IS NOT COSMETIC AND THE TWO KEYS DIFFER.
                        # Measured with `systemd-analyze verify`, 2026-08-12:
                        #
                        #   ExecStart IS word-split. A bare ' '.join(cmd) with
                        #   a home dir like "/home/mr. sabr/leon brain" became
                        #   the command "/home/mr." -> "Command /home/mr. is
                        #   not executable", and boot persistence died while
                        #   the installer still said the SI would come back at
                        #   login. Quote EACH word; systemd strips the quotes.
                        #
                        #   WorkingDirectory is NOT word-split -- the rest of
                        #   the line is the path, spaces and all. Quoting it
                        #   makes systemd read the leading " as part of the
                        #   path and refuse to load the unit at all. It stays
                        #   bare. Do not "make these consistent".
                        #
                        # install_client.py:534 carries the same pair, and
                        # tests/test_autostart.py now asserts both files.
                        f"WorkingDirectory={self.dest}\n"
                        "ExecStart="
                        + " ".join('"%s"' % str(c).replace('"', r'\"')
                                   for c in cmd) + "\n"
                        "Restart=on-failure\nRestartSec=5\n")
            subprocess.run(["systemctl", "--user", "daemon-reload"],
                           check=False, env=_clean_env())
            # Start it now the same way the autostart entry will at every
            # login: import the session's display env into the user manager
            # first (the installer itself runs inside the session, so the
            # values are in our environment).
            subprocess.run(["systemctl", "--user", "import-environment",
                            "DISPLAY", "XAUTHORITY", "WAYLAND_DISPLAY"],
                           check=False, env=_clean_env())
            started = subprocess.run(
                ["systemctl", "--user", "start", "sabr-si.service"],
                check=False, capture_output=True, text=True, env=_clean_env())
            if started.returncode != 0:
                # Never silent: the unit and the autostart entry are written,
                # so it WILL come up at the next login — but saying "ready"
                # while nothing runs is how a broken install looks finished.
                why = (started.stderr or "").strip().splitlines()
                _log(f"systemctl start failed: {why[-1] if why else started.returncode}")
                self.say("Registered — your SI starts at your next login.")
            # XDG autostart is honored by every DE and runs after the session
            # env exists; it imports that env and starts the unit.
            autostart = os.path.expanduser("~/.config/autostart")
            os.makedirs(autostart, exist_ok=True)
            with open(os.path.join(autostart, "sabr-si.desktop"), "w",
                     encoding="utf-8") as f:
                f.write("[Desktop Entry]\n"
                        "Type=Application\n"
                        "Name=Sabr SI\n"
                        "Comment=Starts your SI with your desktop session\n"
                        "Exec=sh -c 'systemctl --user import-environment "
                        "DISPLAY XAUTHORITY WAYLAND_DISPLAY 2>/dev/null; "
                        "systemctl --user start sabr-si.service'\n"
                        "X-GNOME-Autostart-enabled=true\n"
                        "NoDisplay=true\n")
        elif IS_MAC:
            agents = os.path.expanduser("~/Library/LaunchAgents")
            os.makedirs(agents, exist_ok=True)
            plist = {
                "Label": "com.sabr.si",
                "ProgramArguments": cmd,
                "WorkingDirectory": self.dest,
                "RunAtLoad": True,
                "EnvironmentVariables": {"PYTHONUTF8": "1"},
                "KeepAlive": {"SuccessfulExit": False},
            }
            path = os.path.join(agents, "com.sabr.si.plist")
            with open(path, "wb") as f:
                plistlib.dump(plist, f)
            subprocess.run(["launchctl", "load", "-w", path],
                           check=False, env=_clean_env())
        elif IS_WINDOWS:
            # systemd gets Restart=, launchd gets KeepAlive — Windows gets a
            # restart loop in the runner script, or a top-level crash means
            # the SI is dead until reboot.
            # self.dest / quoted embed a path under the user's Windows
            # profile — open() with no encoding= falls back to the console's
            # locale codec (cp1252 etc.), not UTF-8, so a non-ASCII Windows
            # username (accented Latin, Cyrillic, CJK) raised
            # UnicodeEncodeError right here. And cmd.exe itself reads a .bat
            # file in the console's ACTIVE codepage, not UTF-8 — writing
            # UTF-8 bytes without also telling cmd.exe to read them as UTF-8
            # trades the write-time crash for a run-time one, the moment
            # this same runner is launched below. `chcp 65001` as the first
            # executed line covers that half; both .bat files launch (this
            # one immediately, in launch() a few lines down — see SabrSI.bat
            # below, which only fires at next login but hits the same path).
            quoted = " ".join(f'"{c}"' if " " in c else c for c in cmd)
            runner = self._windows_runner_path()
            # Redirect into a log. Without this the SI runs windowless via
            # the Startup folder and every line it prints — including the
            # traceback from a subsystem that failed to come up — goes
            # nowhere. That is how an install shipped with a dead language
            # layer and a perfectly healthy-looking dashboard: the failure
            # printed a warning into a console that does not exist, the
            # brain kept serving, and the SI silently could not speak.
            # A silent failure mode is worse than a loud crash.
            logfile = os.path.join(self.dest, "sabr-si.log")
            # Two hazards this supervisor used to have, both only visible on a
            # machine left running for weeks:
            #
            #   1. The log was append-only and never rotated. A subsystem that
            #      prints a traceback every tick writes gigabytes into one file
            #      and eventually fills the customer's disk. Rotate at 32MB,
            #      keeping exactly one previous file, before each launch.
            #
            #   2. The retry delay was a flat 5 seconds forever. A crash that
            #      happens at import time — bad .env, missing DLL, corrupt
            #      state file — restarts 17,000 times a day, each one writing
            #      a fresh traceback into the log above. Back off instead:
            #      5s, then 15, 30, 60, capping at 300s. A healthy SI that has
            #      been up a while and exits normally still comes back fast,
            #      because the counter resets whenever the run lasted a while.
            logmax = 32 * 1024 * 1024
            with open(runner, "w", encoding="utf-8") as f:
                f.write("@echo off\n"
                        "chcp 65001 >nul\n"
                        "setlocal enabledelayedexpansion\n"
                        "set PYTHONUTF8=1\n"
                        f"cd /d \"{self.dest}\"\n"
                        "set DELAY=5\n"
                        ":loop\n"
                        # rotate an oversized log before we append to it again
                        f"for %%A in (\"{logfile}\") do if %%~zA GTR {logmax} ("
                        f"move /y \"{logfile}\" \"{logfile}.1\" >nul 2>&1)\n"
                        # remember when this attempt started, in seconds
                        "set T0=%TIME%\n"
                        f"{quoted} >> \"{logfile}\" 2>&1\n"
                        # ran longer than a minute? treat as healthy, reset backoff
                        "call :elapsed RAN \"%T0%\" \"%TIME%\"\n"
                        "if !RAN! GEQ 60 (set DELAY=5) else ("
                        "set /a DELAY=!DELAY!*2 & "
                        "if !DELAY! GTR 300 set DELAY=300)\n"
                        # NOT `timeout /t` — timeout requires a console input
                        # handle and exits IMMEDIATELY with "Input redirection
                        # is not supported" when it doesn't have one (any
                        # non-interactive launch context). That silently turns
                        # the backoff below into a zero-delay spin, which is
                        # the exact failure the backoff exists to prevent.
                        # Measured on a real Windows box, 2026-08-11.
                        # `ping -n` sleeps without touching stdin.
                        "set /a _P=!DELAY!+1\n"
                        "ping -n !_P! 127.0.0.1 >nul 2>&1\n"
                        "goto loop\n"
                        "\n"
                        ":elapsed\n"
                        "set S=%~2\n"
                        "set E=%~3\n"
                        "for /f \"tokens=1-3 delims=:.\" %%a in (\"%S%\") do "
                        "set /a _S=(1%%a-100)*3600+(1%%b-100)*60+(1%%c-100)\n"
                        "for /f \"tokens=1-3 delims=:.\" %%a in (\"%E%\") do "
                        "set /a _E=(1%%a-100)*3600+(1%%b-100)*60+(1%%c-100)\n"
                        "set /a _D=_E-_S\n"
                        "if !_D! LSS 0 set /a _D=_D+86400\n"
                        "set %~1=!_D!\n"
                        "goto :eof\n")
            startup = os.path.join(
                os.environ.get("APPDATA", os.path.expanduser("~")),
                "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
            os.makedirs(startup, exist_ok=True)
            with open(os.path.join(startup, "SabrSI.bat"), "w",
                     encoding="utf-8") as f:
                f.write("@echo off\nchcp 65001 >nul\n"
                        f"start \"\" /min \"{runner}\"\n")

    def _windows_runner_path(self) -> str:
        return os.path.join(self.dest, "sabr_si_run.bat")

    def launch(self):
        self.say("Waking your SI…")
        if IS_LINUX:
            return  # register_autostart already import-env'd + started the unit
        if IS_WINDOWS:
            # Launch through the restart-loop runner so the first boot is
            # supervised the same way every later boot is.
            subprocess.Popen(
                ["cmd", "/c", "start", "", "/min", self._windows_runner_path()],
                cwd=self.dest, env=_clean_env())
            return
        subprocess.Popen(self._entry_cmd(), cwd=self.dest,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, env=_clean_env())
        if IS_MAC:
            self._mac_privacy_preflight()

    def _mac_privacy_preflight(self):
        """Make the Mac blindness LOUD instead of silent.

        macOS is the mirror of the Windows session-zero problem, and it is
        worse because it fails quietly. A LaunchAgent DOES run in the user's
        GUI session, so unlike Windows there is a screen to grab -- but
        without the Screen Recording and Accessibility grants, `screencapture`
        still exits 0 and hands back an image of the desktop wallpaper, and
        every mouse/keyboard call is refused. The SI reports itself healthy
        and is functionally blind and handless, forever, and the owner is
        never told there is a checkbox to tick.

        leon_mac.tcc_preflight() has existed this whole time and nothing ever
        called it. Running it here is also what POPS the system permission
        dialogs -- the probes perform the real operation, which is the only
        way macOS will prompt. So this both diagnoses and fixes, at the one
        moment the owner is sitting in front of the installer paying
        attention.
        """
        try:
            sys.path.insert(0, os.path.join(self.dest, "landing"))
            import leon_mac  # type: ignore
            result = leon_mac.tcc_preflight()
        except Exception as e:
            # Never fail an otherwise-good install over a permission probe.
            _log(f"[warn] mac privacy preflight unavailable: {e}")
            return
        if result.get("screen_recording") and result.get("accessibility"):
            self.say("Screen and input permissions granted — your SI can see.")
            return
        missing = []
        if not result.get("screen_recording"):
            missing.append("Screen Recording")
        if not result.get("accessibility"):
            missing.append("Accessibility")
        self.say("")
        self.say("ONE MORE STEP — macOS is holding your SI's eyes back.")
        self.say("Open System Settings > Privacy & Security and switch ON:")
        for item in missing:
            self.say(f"    - {item}")
        self.say("Then quit and reopen your SI. Until you do, it can hear")
        self.say("and speak, but it cannot see your screen or move anything.")
        _log(f"[mac] tcc preflight: {result.get('detail', '')}")


# Every ONLOGON task name this product (or a hand-registered recovery task)
# has ever used. Uninstall deletes all of them; only the first is created.
_WINDOWS_TASK_NAMES = ("Sabr SI", "SabrSI", "Sabr_SI", "SabrSI Autostart")


def _autostart_paths(dest: str) -> list:
    """Everything register_autostart() creates, per platform."""
    home = os.path.expanduser("~")
    if IS_LINUX:
        return [os.path.join(home, ".config", "systemd", "user", "sabr-si.service"),
                os.path.join(home, ".config", "autostart", "sabr-si.desktop")]
    if IS_MAC:
        return [os.path.join(home, "Library", "LaunchAgents", "com.sabr.si.plist")]
    if IS_WINDOWS:
        startup = os.path.join(os.environ.get("APPDATA", home), "Microsoft",
                               "Windows", "Start Menu", "Programs", "Startup")
        # "Sabr SI.bat" is the OTHER installer's name for the same thing
        # (install_client.py's Startup fallback). Two installers write two
        # differently-named shortcuts into one folder; an uninstaller that
        # only knows its own name leaves a boot entry pointing at a deleted
        # tree, which is a failed console on every sign-in forever.
        return [os.path.join(startup, "SabrSI.bat"),
                os.path.join(startup, "Sabr SI.bat"),
                os.path.join(dest, "sabr_si_run.bat")]
    return []


def _stop_windows_si(dest: str) -> None:
    """Kill the SI itself, scoped to THIS install's interpreter.

    The previous code ran `taskkill /F /IM SabrInstaller.exe`, which kills the
    installer window the user is standing in and leaves the SI running. The
    tree then cannot be deleted (Windows holds open files), so the uninstall
    reports leftovers for a reason that looks like a permissions problem and
    is not. Matching on ExecutablePath keeps an unrelated python.exe safe.
    """
    venv_python = os.path.join(dest, ".venv", "Scripts", "python.exe")
    if not os.path.exists(venv_python):
        return
    escaped = venv_python.replace("\\", "\\\\").replace("'", "''")
    pids = ""
    # wmic is gone on current Windows 11 images; CIM is the supported path.
    # A false "nothing is running" here means deleting the tree out from
    # under a live process, so try both before believing it.
    for argv in (
        ["wmic", "process", "where", f"ExecutablePath='{escaped}'",
         "get", "ProcessId"],
        ["powershell", "-NoProfile", "-Command",
         f"Get-CimInstance Win32_Process -Filter \"ExecutablePath='{escaped}'\""
         f" | Select-Object -ExpandProperty ProcessId"],
    ):
        try:
            r = subprocess.run(argv, check=False, capture_output=True,
                               text=True, timeout=60, env=_clean_env())
            pids = r.stdout or ""
        except (OSError, subprocess.SubprocessError):
            pids = ""
        if pids.strip():
            break
    for tok in pids.split():
        if tok.isdigit():
            subprocess.run(["taskkill", "/PID", tok, "/T", "/F"],
                           check=False, capture_output=True, env=_clean_env())

    # ALSO kill the supervisor shell — it is not an interpreter, so the scan
    # above cannot see it (2026-08-10, measured on Windows 10).
    #
    # register_autostart() writes sabr_si_run.bat as a `:loop / python run.py
    # / sleep / goto loop` restart supervisor (the sleep is a `ping -n`, not
    # `timeout` — see the comment at its write site for why), and Startup
    # launches it under
    # cmd.exe. Killing only the interpreter leaves that cmd.exe alive with
    # `cd /d <dest>` still in effect — and on Windows a process whose CURRENT
    # DIRECTORY is a folder blocks that folder's removal outright, no open
    # file required. So the uninstall killed the SI, deleted everything it
    # could, and then failed the final rmtree with WinError 32 pointing at
    # whatever file happened to be last. It reads as a permissions problem or
    # a stuck process; it is neither. It is our own supervisor.
    #
    # Worse: while that loop lives it keeps trying to relaunch a deleted SI
    # (starting ~5s apart, then backing off). Same shape as the pythonw-vs-python miss — the uninstaller
    # knew about only one of the two process kinds the installer creates.
    # TWO different installers write TWO different supervisor batch files, and
    # this only ever hunted for one of them. install_client.py (the tarball /
    # bootstrap.sh flow) writes start.bat, whose first line is `cd /d "%~dp0"`
    # — exactly the cwd-lock described above. So an install that arrived via
    # bootstrap and is then updated or uninstalled by THIS installer left a
    # live cmd.exe holding the folder, and the rmtree failed with WinError 32.
    # Hunt every supervisor name we have ever shipped, not just our own.
    runners = [os.path.join(dest, name)
               for name in ("sabr_si_run.bat", "start.bat")]
    argvs = []
    for runner in runners:
        escaped_runner = runner.replace("\\", "\\\\").replace("'", "''")
        base = os.path.basename(runner)
        argvs.append(
            ["wmic", "process", "where",
             f"Name='cmd.exe' and CommandLine like '%{escaped_runner}%'",
             "get", "ProcessId"])
        argvs.append(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | "
             f"Where-Object {{ $_.CommandLine -like '*{base}*' }} | "
             "Select-Object -ExpandProperty ProcessId"])
    for argv in argvs:
        try:
            r = subprocess.run(argv, check=False, capture_output=True,
                               text=True, timeout=60, env=_clean_env())
            out = r.stdout or ""
        except (OSError, subprocess.SubprocessError):
            out = ""
        for tok in out.split():
            if tok.isdigit():
                subprocess.run(["taskkill", "/PID", tok, "/T", "/F"],
                               check=False, capture_output=True,
                               env=_clean_env())
    # Windows releases handles asynchronously after a kill; deleting the tree
    # in the same breath can still lose the race.
    time.sleep(2)


def run_uninstall(dest: str, purge: bool = False, progress=print) -> int:
    """Stop the SI, remove its autostart registration, and delete the install.

    Identity is archived FIRST unless --purge is given. brain_state is
    everything the SI has learned and .env is its name and its owner's; a
    product that can erase that on one command is not one to trust with it.
    If the archive cannot be written we stop rather than delete.
    """
    # LOG TO TEMP, NEVER INTO dest (2026-08-10, measured on Windows 10).
    #
    # _log_open() prefers dest, so the uninstall wrote sabr-install.log INTO
    # the very folder it was about to delete, and kept the handle open for the
    # whole run. On Windows an open handle blocks directory removal outright,
    # so the final rmtree left exactly one file behind and the uninstall
    # reported "could not be removed" — looking like a permissions or
    # still-running-process problem when it was purely self-inflicted.
    #
    # Pointing it at a temp directory keeps the log (and _log_hint's pointer
    # to it) fully intact for support — it just no longer pins open the one
    # directory this function exists to delete.
    _log_open(os.path.join(tempfile.gettempdir(), "sabr-uninstall-log"))
    dest = os.path.abspath(dest)
    progress("Stopping your SI…")
    if IS_LINUX:
        for argv in (["systemctl", "--user", "stop", "sabr-si.service"],
                     ["systemctl", "--user", "disable", "sabr-si.service"]):
            subprocess.run(argv, check=False, capture_output=True, env=_clean_env())
    elif IS_MAC:
        plist = _autostart_paths(dest)[0]
        if os.path.exists(plist):
            subprocess.run(["launchctl", "unload", "-w", plist],
                           check=False, capture_output=True, env=_clean_env())
    elif IS_WINDOWS:
        _stop_windows_si(dest)
        # The other installer registers an ONLOGON scheduled task rather than a
        # Startup shortcut. Deleting the tree without deleting the task leaves
        # Windows failing it at every sign-in for software that is gone.
        #
        # Sweep EVERY spelling, not just ours. Found on Dean's box 2026-08-12:
        # a live ONLOGON task named "SabrSI" (no space) was starting the SI,
        # while every uninstall path in this product only ever deletes
        # "Sabr SI" (with the space). One character apart, and the difference
        # is a boot entry that survives uninstall forever. A ghost task is the
        # single most visible way this product can fail AFTER the customer has
        # already decided to leave -- so the sweep is deliberately wider than
        # the set we create.
        for _task in _WINDOWS_TASK_NAMES:
            subprocess.run(["schtasks", "/delete", "/tn", _task, "/f"],
                           check=False, capture_output=True, env=_clean_env())

    removed, left = [], []
    for path in _autostart_paths(dest):
        if os.path.lexists(path):
            try:
                os.remove(path)
                removed.append(path)
            except OSError as e:
                left.append(f"{path} ({e.strerror})")
    if IS_LINUX and removed:
        subprocess.run(["systemctl", "--user", "daemon-reload"],
                       check=False, capture_output=True, env=_clean_env())

    # ~/.leon holds skills.db, lessons.db, reflection.db, self_repair.db and
    # tool_health.db — everything the SI actually learned — and it lives
    # OUTSIDE the install tree, so deleting dest never touched it. Two things
    # were true at once: the archive labelled "your SI's identity" did not
    # contain the learned cognition, and the next install silently inherited a
    # dead SI's skills and tool health.
    cognition = os.path.join(os.path.expanduser("~"), ".leon")

    archive = ""
    if not purge:
        keep = []
        if os.path.isdir(dest):
            keep = [n for n in (".env", "brain_state")
                    if os.path.lexists(os.path.join(dest, n))]
        # The cognition probe sits OUTSIDE the `keep` guard deliberately. With
        # it inside, a tree that has no .env or brain_state yet skips the whole
        # archive block while ~/.leon still gets deleted below — data loss.
        have_cognition = os.path.isdir(cognition)
        if keep or have_cognition:
            progress("Saving your SI's identity before removing anything…")
            stamp = _timestamp()
            archive = os.path.join(os.path.dirname(dest) or ".",
                                   f"sabr-si-backup-{stamp}.tar.gz")
            try:
                with tarfile.open(archive, "w:gz") as tar:
                    for name in keep:
                        tar.add(os.path.join(dest, name), arcname=name)
                    if have_cognition:
                        tar.add(cognition, arcname=".leon")
                if os.path.getsize(archive) <= 0:
                    raise OSError("empty archive")
            except Exception as e:
                try:
                    os.unlink(archive)
                except OSError:
                    pass
                raise InstallError(
                    f"Couldn't save your SI's memories to {archive} ({e}). "
                    f"Nothing has been removed. Free some space, or pass "
                    f"--purge if you really want them deleted." + _log_hint())

    if os.path.isdir(dest):
        progress("Removing the install…")
        shutil.rmtree(dest, ignore_errors=True)
        if os.path.isdir(dest):
            left.append(f"{dest} (could not be removed)")
        else:
            removed.append(dest)

    # Only now that it is safely inside the archive above.
    if os.path.isdir(cognition):
        shutil.rmtree(cognition, ignore_errors=True)
        if os.path.isdir(cognition):
            left.append(f"{cognition} (could not be removed)")
        else:
            removed.append(f"{cognition} (learned skills, lessons, reflections)")

    for path in removed:
        progress(f"Removed {path}")
    if archive:
        progress(f"Kept your SI's identity at {archive} — delete it yourself "
                 f"when you are sure.")
    for path in left:
        progress(f"Could not remove {path}")
    progress("Uninstalled." if not left else "Uninstalled, with leftovers above.")
    return 1 if left else 0


#: What the onboarding server sends when a Stripe buyer never chose a name.
#: It must never survive into the .env or the "is alive" line.
_SERVER_PLACEHOLDER_SI_NAME = "Sabr customer"


def _installed_si_name(dest: str) -> str:
    """The name the SI on this machine already answers to, if any."""
    try:
        with open(os.path.join(dest or "", ".env"),
                  encoding="utf-8", errors="replace") as fh:
            for line in fh:
                k, sep, v = line.strip().partition("=")
                if sep and k.strip() == "LEON_SI_NAME":
                    return v.strip()
    except OSError:
        pass
    return ""


def resolve_identity(cfg: dict, si_name: str = "", dest: str = "") -> dict:
    """Settle the SI's name before anything is written.

    The choice made locally at install time wins over whatever the server
    sent; a blank local choice falls back to the server value; and the
    server's Stripe-buyer placeholder ("Sabr customer") degrades to
    "your SI" so no customer ever meets a mind that introduces itself
    by a placeholder. user_name is deliberately NOT settled here: the
    owner introduces themselves out loud and the SI learns who they are —
    typing your own name into a form is the least alive version of an
    introduction, so the server value passes through untouched.

    AN EXISTING INSTALL'S NAME BEATS THE PLACEHOLDER. Added 2026-08-12,
    same shape as the LEON_BRAIN_MODE bug documented in write_env. A Stripe
    buyer's tenant record carries si_name="Sabr customer", so on every
    UPDATE / REINSTALL this function used to hand write_env the string
    "your SI" — which is in `_ours`, so the carry-forward loop could not
    rescue it either. The owner names their mind, runs an update three weeks
    later because something looks off, and it comes back calling itself
    "your SI". write_env's own `prior` fallback cannot help: cfg["si_name"]
    is always truthy by the time it runs. The rescue has to be here.
    """
    chosen = (si_name or "").strip() or (cfg.get("si_name") or "").strip()
    if not chosen or chosen == _SERVER_PLACEHOLDER_SI_NAME:
        chosen = _installed_si_name(dest).strip() or "your SI"
    cfg["si_name"] = chosen
    return cfg


def _stop_si_before_overwrite(dest: str, progress=print) -> None:
    """Stop a running SI before we start replacing the files it has open.

    Added 2026-08-11. run_uninstall has always stopped the SI first — with a
    comment explaining that Windows holds open files and the delete then fails
    for a reason that looks like a permissions problem and is not. The UPDATE /
    REINSTALL path never got the same treatment: it went straight from the
    button to download_release(), which rmtree/replace()s top-level items on
    top of a live install. On Windows that raises PermissionError, surfaces as
    a bare "Download failed", and the customer has no idea their own running SI
    is what blocked it. Worse when it half-succeeds: some DLLs are replaced and
    some are not, the import probe passes against the OLD ones still loaded on
    disk, and the installer reports a successful upgrade that never happened.

    Best-effort by design — a machine where nothing is running must still
    install. Every call is check=False; failure to stop is not failure to
    install.
    """
    if not os.path.isdir(dest):
        return
    progress("Stopping your SI before updating its files…")
    try:
        if IS_LINUX:
            subprocess.run(["systemctl", "--user", "stop", "sabr-si.service"],
                           check=False, capture_output=True, env=_clean_env())
        elif IS_MAC:
            plist = _autostart_paths(dest)[0]
            if os.path.exists(plist):
                subprocess.run(["launchctl", "unload", "-w", plist],
                               check=False, capture_output=True, env=_clean_env())
        elif IS_WINDOWS:
            # End the scheduled task FIRST — otherwise Task Scheduler can
            # relaunch the SI in the gap between the kill and the overwrite.
            # ...and end EVERY spelling. If the live install was registered
            # under a different task name than the one we create (it was, on
            # Dean's box), ending only ours leaves Task Scheduler free to
            # relaunch the SI in the middle of the file overwrite -- a half
            # updated tree with a live process reading it.
            for _task in _WINDOWS_TASK_NAMES:
                subprocess.run(["schtasks", "/end", "/tn", _task],
                               check=False, capture_output=True,
                               env=_clean_env())
            _stop_windows_si(dest)
    except (OSError, subprocess.SubprocessError) as e:
        _log(f"[warn] could not stop a running SI before update: {e}")


def run_install(token: str, dest: str, base_url: str,
                progress=print, dry_run: bool = False,
                si_name: str = "") -> dict:
    _log_open(dest)  # before anything can fail

    # Capture the CALLER's callback under its own name before the closure is
    # defined. `progress` is a parameter, so it is a local of run_install, and
    # a closure over it reads whatever that name points at when it RUNS — not
    # what it pointed at when the closure was defined. So `progress = _say`
    # below used to make _say call itself: the first status message recursed
    # ~1000 frames and died with RecursionError before a single step printed,
    # on every install, on all four platforms. The separate name is the fix —
    # _report can never be rebound to _say.
    _report = progress

    def _say(msg):
        _log(f"[step] {msg}")
        _report(msg)

    progress = _say
    cfg = fetch_config(base_url, token)
    cfg["_token"] = token
    resolve_identity(cfg, si_name, dest)
    # Nothing is overwritten in a dry run, so nothing needs stopping.
    if not dry_run:
        _stop_si_before_overwrite(dest, progress)
    Installer(cfg, dest, base_url, progress=progress, dry_run=dry_run).run()
    return cfg


# ── GUI (tkinter — stdlib, themed to the Sabr aesthetic) ───────────────

def existing_install(dest: str = "") -> str:
    """Return the path of an existing install, or "" if this is a fresh box.

    Judged by artifacts the installer itself writes, not by the folder merely
    existing — a customer who made an empty ~/SabrSI by hand should still get
    the plain install flow, not a scary "already installed" screen.
    """
    dest = os.path.abspath(dest or default_install_dir())
    if not os.path.isdir(dest):
        return ""
    for marker in ("run.py", ".env", "brain_state", "brain"):
        if os.path.exists(os.path.join(dest, marker)):
            return dest
    return ""


def _choose_mode_gui(dest: str) -> str:
    """First screen when an install is already present: Update / Uninstall /
    Wipe / Cancel. Returns "install", "uninstall", "wipe", or "" (customer
    closed the window).

    WIPE exists because UNINSTALL alone was a privacy trap: by default it
    archives .env and brain_state to a tar.gz sitting right next to the
    install folder rather than deleting them — correct for "I want to
    reinstall later and keep what it learned," silently wrong for "I am
    selling or giving away this computer." --purge already did the right
    thing but only existed as a CLI flag nobody running the GUI would ever
    type. This puts the choice where the customer who needs it will
    actually see it, worded for what THEY are doing, not for what the code
    calls it.
    """
    import tkinter as tk

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    root.configure(bg=BG)
    root.geometry("520x430")
    root.resizable(False, False)
    choice = {"mode": ""}

    def label(text, size=11, fg=FG, pady=(0, 0)):
        tk.Label(root, text=text, bg=BG, fg=fg, font=("Helvetica", size),
                 wraplength=460, justify="center").pack(pady=pady)

    label("S A B R", 10, DIM, (28, 2))
    label("Your SI is already installed.", 18, FG, (8, 4))
    label(dest, 9, DIM, (0, 6))
    label("Update reinstalls the latest version and keeps everything your SI "
          "has learned. Uninstall archives its memory first, then removes it "
          "— pick this if you might reinstall later. Wipe removes it AND "
          "deletes that memory outright — pick this if you're selling or "
          "giving away this computer.",
          10, DIM, (0, 16))

    def pick(mode):
        choice["mode"] = mode
        root.destroy()

    def button(text, mode, fg=FG, bg="#1a1a1a"):
        tk.Button(root, text=text, command=lambda: pick(mode), bg=bg, fg=fg,
                  activebackground="#2a2a2a", activeforeground=fg, relief="flat",
                  font=("Helvetica", 11, "bold"), padx=24, pady=8,
                  cursor="hand2", width=30).pack(pady=4)

    button("UPDATE / REINSTALL", "install")
    button("UNINSTALL (keep a backup)", "uninstall", fg="#ff6b6b")
    button("WIPE — SELLING / GIVING AWAY THIS COMPUTER", "wipe", fg="#ff3b3b")
    button("CANCEL", "")
    root.mainloop()
    return choice["mode"]


def _run_uninstall_gui(dest: str, purge: bool = False):
    """Uninstall with a progress window, so the customer sees it working.

    purge=True is the WIPE path from _choose_mode_gui: no identity archive
    is written at all, so there is nothing left on disk for a future owner
    of this machine to find. purge=False keeps the archive (a deliberate
    reinstall-later convenience) — its own message now says exactly where
    that archive landed rather than "archived next to the install folder,"
    because a customer who can't find something can't judge whether it's
    safe to leave behind.
    """
    import tkinter as tk
    from tkinter import ttk
    import threading

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    root.configure(bg=BG)
    root.geometry("520x320")
    root.resizable(False, False)

    def label(text, size=11, fg=FG, pady=(0, 0)):
        l = tk.Label(root, text=text, bg=BG, fg=fg, font=("Helvetica", size),
                     wraplength=460, justify="center")
        l.pack(pady=pady)
        return l

    label("S A B R", 10, DIM, (28, 2))
    title = label("Wiping your SI…" if purge else "Removing your SI…", 18, FG, (8, 4))
    status = label("", 10, DIM, (14, 4))
    bar = ttk.Progressbar(root, length=380, mode="indeterminate")
    bar.pack(pady=(8, 0))
    bar.start(12)

    def set_status(text):
        root.after(0, lambda: status.config(text=str(text)))

    def work():
        try:
            archive_dir = os.path.dirname(os.path.abspath(dest)) or dest
            run_uninstall(dest, purge=purge, progress=set_status)
            if purge:
                ok, msg = True, ("Nothing was kept. Safe to hand off this "
                                 "computer — no memory or credentials remain.")
            else:
                ok, msg = True, (
                    f"Its memory was archived to {archive_dir} (not encrypted). "
                    f"Delete that file yourself once you're sure, or if you're "
                    f"selling or giving away this computer, run Uninstall "
                    f"again and choose Wipe instead.")
        except Exception as e:
            _log("[uninstall-crash] " + repr(e))
            ok, msg = False, f"{e}{_log_hint()}"

        def done():
            bar.stop(); bar.pack_forget()
            if ok:
                title.config(text="Wiped." if purge else "Uninstalled.")
            else:
                title.config(text="Wipe failed." if purge else "Uninstall failed.")
            status.config(text=msg, fg=DIM if ok else "#ff6b6b")
            tk.Button(root, text="CLOSE", command=root.destroy, bg="#1a1a1a",
                      fg=FG, activebackground="#2a2a2a", activeforeground=FG,
                      relief="flat", font=("Helvetica", 11, "bold"),
                      padx=28, pady=8, cursor="hand2").pack(pady=(16, 0))
        root.after(0, done)

    threading.Thread(target=work, daemon=True).start()
    root.mainloop()


#: Apple ships no python3.11+ on a stock Mac (nothing at all, or an old stub
#: below our floor) — this is where we send someone who hit that wall.
PYTHON_DOWNLOAD_URL_MAC = "https://www.python.org/downloads/macos/"


def _augment_missing_python_error(err: "InstallError") -> "InstallError":
    """On macOS, a 'no usable Python' failure gets the download page opened
    for the customer instead of leaving a bare URL sitting in a text label
    they have to retype into a browser by hand."""
    if not IS_MAC or "No usable Python 3 found" not in str(err):
        return err
    opened = False
    try:
        import webbrowser
        opened = bool(webbrowser.open(PYTHON_DOWNLOAD_URL_MAC))
    except Exception:
        opened = False
    suffix = (" Opening the Python download page for you — install it, "
              "then come back and click INSTALL again."
              if opened else
              f" Install it from {PYTHON_DOWNLOAD_URL_MAC}, then click "
              f"INSTALL again.")
    return InstallError(str(err) + suffix)


def run_gui(base_url: str):
    # One program, four verbs — install, update, uninstall, wipe — chosen
    # here instead of by a command-line flag the customer will never type.
    found = existing_install()
    if found:
        mode = _choose_mode_gui(found)
        if mode == "uninstall":
            _run_uninstall_gui(found, purge=False)
            return
        if mode == "wipe":
            _run_uninstall_gui(found, purge=True)
            return
        if not mode:
            return
    import tkinter as tk
    from tkinter import ttk
    import threading

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    root.configure(bg=BG)
    root.geometry("520x420")
    root.resizable(False, False)

    def label(text, size=11, fg=FG, pady=(0, 0)):
        l = tk.Label(root, text=text, bg=BG, fg=fg,
                     font=("Helvetica", size), wraplength=460, justify="center")
        l.pack(pady=pady)
        return l

    label("S A B R", 10, DIM, (28, 2))
    title = label("Bring your SI to life.", 18, FG, (8, 4))
    sub = label("Paste the install token from your onboarding page.", 10, DIM, (0, 16))

    token_var = tk.StringVar()
    entry = tk.Entry(root, textvariable=token_var, width=42, justify="center",
                     bg="#111111", fg=FG, insertbackground=FG, relief="flat",
                     font=("Courier", 11))
    entry.pack(ipady=8)
    entry.focus()

    def placeholder_entry(caption, hint):
        """A captioned entry whose grey hint text is never mistaken for
        input: value() returns "" while the hint is showing."""
        label(caption, 9, DIM, (10, 2))
        var = tk.StringVar(value=hint)
        ent = tk.Entry(root, textvariable=var, width=42, justify="center",
                       bg="#111111", fg=DIM, insertbackground=FG, relief="flat",
                       font=("Helvetica", 10))
        ent.pack(ipady=6)
        showing_hint = [True]

        def focus_in(_event):
            if showing_hint[0]:
                showing_hint[0] = False
                var.set("")
                ent.config(fg=FG)

        def focus_out(_event):
            if not var.get().strip():
                showing_hint[0] = True
                var.set(hint)
                ent.config(fg=DIM)

        ent.bind("<FocusIn>", focus_in)
        ent.bind("<FocusOut>", focus_out)

        def value():
            return "" if showing_hint[0] else var.get().strip()
        return ent, value

    si_entry, si_value = placeholder_entry(
        "Name your SI (optional)", "e.g. Atlas")

    status = label("", 10, DIM, (14, 4))
    bar = ttk.Progressbar(root, length=380, mode="indeterminate")

    def set_status(text):
        root.after(0, lambda: status.config(text=text))

    def finish(cfg=None, error=None):
        def _done():
            bar.stop(); bar.pack_forget()
            if error:
                status.config(text=str(error), fg="#ff6b6b")
                btn.config(state="normal")
                for e in (entry, si_entry):
                    e.config(state="normal")
            else:
                # cfg comes back from run_install with the names already
                # resolved (local choice > server > "your SI"), so this is
                # the customer's chosen name — the first thing their mind
                # ever says to them.
                title.config(text=f"{cfg.get('si_name', 'your SI')} is alive.")
                sub.config(text="")
                url = ("http://localhost:8000" if cfg.get("brain_mode") == "local"
                       else cfg.get("hosted", {}).get("brain_url", ONBOARDING_URL))
                # The dashboard's login screen asks for a key and says
                # "paste the key shown during setup". Nothing here ever
                # showed one, so that instruction pointed at a value the
                # owner had no way to obtain and the install read as broken
                # at the very last step. Show it, and put it on the
                # clipboard so the next screen is a paste, not a retype.
                key = cfg.get("dashboard_key", "")
                if key:
                    keybox = tk.Entry(root, font=("TkFixedFont", 10),
                                      justify="center", relief="flat",
                                      readonlybackground=root["bg"], fg=FG,
                                      width=46)
                    keybox.insert(0, key)
                    keybox.config(state="readonly")
                    keybox.pack(pady=(6, 0))
                    try:
                        root.clipboard_clear(); root.clipboard_append(key)
                    except Exception:
                        pass  # a clipboard we cannot reach must not fail the install
                    status.config(
                        text="Dashboard key above (already copied) — "
                             f"paste it at {url}", fg=DIM)
                else:
                    status.config(text=f"Opening your dashboard — {url}", fg=DIM)
                import webbrowser; webbrowser.open(url)
        root.after(0, _done)

    def go():
        token = token_var.get().strip()
        if not token:
            status.config(text="Paste your token first.", fg="#ff6b6b")
            return
        # Read the tk var on the main thread, before the worker starts.
        chosen_si = si_value()
        btn.config(state="disabled")
        for e in (entry, si_entry):
            e.config(state="disabled")
        status.config(fg=DIM)
        bar.pack(pady=(4, 0)); bar.start(12)
        def work():
            try:
                cfg = run_install(token, default_install_dir(), base_url,
                                  progress=set_status, si_name=chosen_si)
                finish(cfg=cfg)
            except InstallError as e:
                _log(f"[fail] {e}")
                # A fresh Mac has no python3.11+ on its own — stock macOS ships
                # either nothing or a stub well below our floor. The website
                # promises "double-click it, nothing to install first," so a
                # dead-end error naming a URL the customer has to go type in
                # themselves breaks that promise twice over. This can't
                # silently self-heal (no controlling terminal to run brew/
                # Xcode CLT non-interactively from inside a frozen GUI app,
                # and no sudo prompt to drive), so the fix that fits the
                # constraint is: put the download page in front of them
                # instead of a URL in a text label, and tell them they can
                # come straight back to THIS window when it's done.
                e = _augment_missing_python_error(e)
                finish(error=e)
            except Exception as e:
                import traceback
                _log("[crash] " + traceback.format_exc())
                finish(error=f"Unexpected error: {e}{_log_hint()}")
        threading.Thread(target=work, daemon=True).start()

    btn = tk.Button(root, text="INSTALL", command=go, bg="#1a1a1a", fg=FG,
                    activebackground="#2a2a2a", activeforeground=FG,
                    relief="flat", font=("Helvetica", 11, "bold"),
                    padx=28, pady=8, cursor="hand2")
    btn.pack(pady=(16, 0))
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description="Sabr SI installer")
    ap.add_argument("--token", help="install token from the onboarding wizard")
    ap.add_argument("--si-name", default="",
                    help="name your SI (optional; overrides the server's choice)")
    ap.add_argument("--url", default=ONBOARDING_URL, help="onboarding server")
    ap.add_argument("--dest", default=default_install_dir())
    ap.add_argument("--no-gui", action="store_true")
    ap.add_argument("--dry-run", action="store_true",
                    help="download + config only; no deps/services/launch")
    ap.add_argument("--uninstall", action="store_true",
                    help="stop the SI, remove autostart + the install folder")
    ap.add_argument("--purge", action="store_true",
                    help="with --uninstall: delete brain_state/.env instead of "
                         "archiving them first")
    args = ap.parse_args()

    if args.uninstall:
        try:
            sys.exit(run_uninstall(args.dest, purge=args.purge))
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"ERROR: Unexpected error: {e}{_log_hint()}", file=sys.stderr)
            sys.exit(1)

    if args.no_gui or args.dry_run:
        if not args.token:
            ap.error("--token is required with --no-gui/--dry-run")
        try:
            run_install(args.token, args.dest, args.url, dry_run=args.dry_run,
                        si_name=args.si_name)
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            # Matches what the GUI has always shown. Anything unhandled used
            # to reach the customer as a Python traceback plus a PyInstaller
            # "Failed to execute script" line.
            print(f"ERROR: Unexpected error: {e}{_log_hint()}", file=sys.stderr)
            sys.exit(1)
        return
    run_gui(args.url)


if __name__ == "__main__":
    main()
