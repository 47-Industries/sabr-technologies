#!/usr/bin/env python3
"""Sabr SI — installer bootstrapper.

ONE generic installer for every customer and every OS. It carries no
per-customer data: the user pastes the install token from the web
onboarding wizard (sabrtechnologies.com/onboard), and everything
specific — SI name, owner, local-vs-hosted brain, service keys — comes
from the server's install-config contract (v1). The one exception: the
customer may name their SI right here at install time, and that local
choice wins over the server's. Their OWN name is never asked for — the
SI learns who its owner is the way anyone does, by being introduced.

Stdlib only (tkinter + urllib + venv), so PyInstaller can freeze it into
a double-clickable app per OS with nothing to pip-install first.

    python3 sabr_installer.py                      # GUI wizard
    python3 sabr_installer.py --token T --no-gui   # headless
    ... --dry-run    # everything except deps/services/launch
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import platform
import plistlib
import secrets
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:  # installed layout: this file sits inside the installer/ package
    from . import local_brain
except ImportError:  # run directly as a script
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import local_brain

ONBOARDING_URL = os.environ.get("SABR_ONBOARDING_URL", "https://sabrtechnologies.com")

# ── brand icon ─────────────────────────────────────────────────────────
# The Sabr mark (sharp angular white S, chamfered black tile), embedded as
# base64 so the frozen --onefile/--windowed binaries need no data files
# and no runtime path guessing. Windows/macOS get their native icon via
# the pyinstaller --icon flag at freeze time; this covers the tkinter
# window/taskbar on all three OSes, including bare `python3` runs.
_SABR_ICON_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAAT7ElEQVR4nO3d3W9U550H8O8Zj8eG"
    "GDAkNjF4bDwzmBgZVVYxCWlIINrE4sWmgLEvtxftdVWpSnqz3ewdvWv7F3Sl7kXCJgWM2SRAuipv26YKb1FQEs+Mx2PsNmCDgmIb"
    "x+PZi8TImDMvnjkzv99zzvcjRY1Khb8q/L5+nvOcZ2xBmUCg+q10Ov3v0jmInGZZ1m9mZ2d+JZ1jsQrpAItx+MnlXvL7K1ekUnPn"
    "pIMsUFMAHH7yCFUloKIAOPzkMWpKQLwAOPzkUSpKQLQAOPzkceIlIFYAHH4iAMIlIFIAHH6ix4iVQNkLgMNPZEukBMpaABx+oqzK"
    "XgJlKwAOP1FeyloCZSkADj/RspStBEpeABx+ooKUpQRKWgAcfqKilLwESlYAHH4iR5S0BEpSABx+IkeVrAQcLwAOP1FJlKQEHC0A"
    "Dj9RSTleAo4VAIefqCwcLQFHCoDDT1RWjpVA0QXA4ScS4UgJFFUAHH4iUUWXQMEFwOEnUqGoEiioADj8RKoUXALLLgAOP5FKBZXA"
    "sgqAw0+k2rJLIO8C4PATGWFZJZBXAXD4iYySdwnkLAAOP5GR8ioBK9svcviL87Of/RS1tbXSMUiJO3fu4A9/+M+yfs1cP5A0YwFw"
    "+IvT2NiIaPRLWFbWjiUP+fDDszhwoLvsXzdbCfjs/ksOf/H6+/s4/PSYaDQq8nXT6fSbgUD1Mbtfe6IAOPzOOHq0VzoCKROLxcS+"
    "dqYSeKwAOPzOaGlpQUdHh3QMUmZoSGYFsMCuBB4VAIffOVz+kx3JFcCCpSXgAzj8TuPyn5aan5/H8PCwdAwAj5eAn8PvrNbWVmzb"
    "tk06Bilz+/ZtTE9PS8d45PsSgI/D76z+/j7pCKSQ9P7fTjqdftP2GJAK19t7RDoCKaRh/2+HBeCg9vZ2tLW1SccghVgAHsCHf5SJ"
    "xi0AwAJwFAuAMpF6CzAXFoBDOjo6EIlEpGOQUvF4XDqCLRaAQ/jdnzIZH/8HHjx4IB3DFgvAAZZlsQAoI60PAAEWgCM6O7ejublZ"
    "OgYppXX/D7AAHHH06FHpCKQYVwAuZlkWDh8+JB2DFNN6BAiwAIr24os7EQwGpWOQYlwBuBiX/5SL5mcAVmVlVVo6hKl8Ph/i8Sga"
    "Ghqko5BSExOTaGjYIB0jI64AivDyy7s4/JSV5u/+AAugKFz+Uy7R6JB0hKxYAAXy+/04ePCgdAxSTvMJAMACKNiePbtRX18nHYOU"
    "03oHYAELoEB9ffzkH8pN+zMAngIUoLKyEslkAuvWrZOOQso1Ngbx1Vd3pGNkxBVAAV5//TUOP+X09ddfqx5+gAVQED79p3xoX/4D"
    "LIBlq66uxv79+6RjkAFYAC7U1dWFNWvWSMcgA0Sjeu8ALGABLFNfHz/4g/Kj+RLQAhbAMqxcuRJ79+6VjkGG4BbAZfbt24eamhrp"
    "GGQI7W8BAiyAZeHyn/I1PT2N8fFx6Rg5sQDytGrVKnR1dUnHIEPEYjGk0/rfsWMB5OnAgf1YsWKFdAwyhAn7fwDwSwcwhfaP/R4Z"
    "GcGXX+q+euq0QCCAXbteko5hy4QjQIAFkJfa2lq89tpr0jGy+uUv38CJEyekY5RVe3s7Pvnk79IxbJmyAuAWIA89Pd2oqqqSjpHR"
    "gwcP8MEHH0jHKLtwOCwdISMWgItof/f/9OnTmJ6elo5RdpGI3gIw4QgQYAHktHbtWuzZs1s6RlbvvPPf0hFEhEIh6Qi2ZmdnMTo6"
    "Kh0jLyyAHA4fPoRAICAdI6P79+/j3Llz0jFEaN0CDA8PI5VKScfICwsgB+3L/1OnBvDw4UPpGCK0bgFMWf4DLICs6uqewcsv75KO"
    "kdXx48elI4ioqqrCxo0bpWPYMuUBIMACyOrIkSPw+/WelN67dw9//vP/SscQsWnTJlRUVEjHsGXCLcAFLIAstC//33vvT5idnZWO"
    "IULr8h/gCsAVGhqexY9+9KJ0jKy8uvwH9D4ABMx5CxBgAWR09OhR+Hx6/++5c+cu/vKXC9IxxGg9AkylUkgkEtIx8qb3b7gw7cv/"
    "d999F3Nzc9IxxGhdAYyMjBi1LWMB2GhsbMSOHZ3SMbLy8vIfAMJhnSsAk44AARaArf7+PliWJR0jo/Hxf+Dy5SvSMcRUVFSgqalJ"
    "OoYtk04AABaALe1Xf48fP27Mm2al0NzcrPbtTBaA4VpaWtDR0SEdIyuvL/81HwFyC2A47cv/0dFR/O1vH0vHEKX1BAAw6x0AgAXw"
    "BO3L/7fffseIz5orJa0FkE6n1f848KVYAIu0trZi27Zt0jGyOn7cm1d/F9O6BRgbGzPucxlYAIv09/dJR8gqHo/j6tWr0jHEaX0H"
    "wLT9P8ACeExv7xHpCFlx+Q/4fD5s2rRJOoYt0/b/AAvgkfb2drS1tUnHyIrLf2Djxo1qP57dtCNAgJ8K/Ij27/5ffPEFbt68KR1D"
    "3Pj4OH74w06Ew2GEwyGEw2GEQiFEImE0NjaK3t8wcQvAAvheX5/ud//ffvsd6QgqzM3N4ebNm7ZlWFlZicbGRoRCLWhp+e6fhX9v"
    "a2sr+crBxC2AVVlZ5e1NJYCOjg789a+6X639wQ86cOvWLekYxvL7/QgGg7blsGXLFjz11FNFf42nn67DgwcPHEhbPlwBQP/Z/6ef"
    "fsrhL9Lc3Bzi8XjGc/q1a9eipaUFW7e2oa2t7VE5RCIRrF69Oufv/89/fmXc8AMsAFiWpb4A+PCv9O7du4d79+7hk08+eeLXFsph"
    "8aph69at2Lq1DbW1tQDMXP4DLAB0dm5Hc3OzdIysWACyspXDM888jVAopPbzCXPxfAFo/+CPq1evYmjIWz/00yR3707g7t0J6RgF"
    "8/R7AJZl4fDhQ9IxsuJ3fyolTxfAiy/uRDAYlI6RUTqdZgFQSXm6ALQv/z/++O9GfcAkmcezBeDz+XDo0I+lY2Tl9Q/+oNLzbAG8"
    "8srLaGhokI6RUTqdxnvv/Uk6BrmcZwtA+/L/8uUrSCaT0jHI5Tz5KrDf78fwcBz19XXSUchgv/3t7/DGG29KxyiKJ1cAr766h8NP"
    "RRsYGJCOUDRPFoD25T/pNzExiStX/k86RtE8VwCVlZXo7j4gHYMMNzAw4Iofzea5Anj99dewbt066RhkuFOnzF/+Ax4sAC7/qVhT"
    "U1P46KOPpGM4wlMFUF1djf3790nHIMN9+OGHmJqako7hCE8VQFdXF9asWSMdgwznluU/4LEC6OvT/cEfpF8qlcL7778vHcMxnimA"
    "lStXYu/evdIxyHAXLlw0+v7/Up4pgH379qGmpkY6BhnODS//LOaZAuDyn5wwMHBaOoKjPHEXYNWqVRgdHVH7E2XIDNeuXcOOHS9I"
    "x3CUJ1YA+/fv5/BT0dz23R/wSAH09/PlHyreyZOnpCM4zvVbgNraWiSTCVRVVUlHIYMlEgls3rxFOobjXL8C6Onp5vBT0U6cOCkd"
    "oSRcXwB895+c4LbjvwWu3gKsXbsWyWQCgUBAOgoZbGJiEsFgkyuu/y7l6hXA4cOHOPxUtMHBQVcOP+DyAuDyn5zgxqf/C1y7Bair"
    "ewaJxDD8fs//+EMqwtTUFDZsaHTN9d+lXLsC6O3t5fBT0c6ePeva4QdcXABc/pMT3HT3344rtwANDc8iHo/B53Ntv1EZpFIpBINN"
    "rrr+u5QrJ6S3t5fDT0W7ePGSq4cfcGkB9PX1SUcgFzh1yr1P/xe4bgvQ2NiIaPRLWJYlHYUM19r6HIaHh6VjlJTrVgD9/X0cfira"
    "tWvXXD/8gAsL4OhRfvIPFc+Nd//tuKoAWlpa0NHRIR2DXMDNb/8t5qoC4PKfnJBIJHDjxg3pGGXhqgLg8p+c4Na7/3ZcUwCtra3Y"
    "tm2bdAxyAbfe/bfjmgLo7+fZPxVvYmISly9fkY5RNq4pgN7eI9IRyAVOnz7t2rv/dlxRAO3t7Whra5OOQS7g9ss/S7miAPjwj5ww"
    "NTWF8+fPS8coK1e8ChyJRLB69WrpGJTDvn178etf/5t0jIwGBgZw5Ii3rpG74hMzhoaGpCNQHn7xi59LR8jKS8d/C1yxAiD9Kisr"
    "cft2ErW1tdJRbHnh7r8dVzwDIP327NmtdvgBb9z9t8MCoLLo7u6WjpCVl17+WYxbACo5y7IQiw1h48aN0lEy8sLdfztcAVDJdXZu"
    "Vz38169f9+TwAywAKgPty3+vvfyzGAuASu7gwR7pCFmxAIhKJBKJ4LnnnpOOkdHIyIhn7v7bYQFQSR069GPpCFmdOHES6bR3n4Oz"
    "AKiktO//vXr8t4DHgFQy69fXI5EYVvtDWiYmJhEMNnnq+u9SOv9kyBV6enrUDj8ADA4Oenr4ARYAlZD25b+Xn/4v4BaASqKmpgZj"
    "Y6Oorq6WjmJrenoaGzY04ptvvpGOIoorACqJvXv3qh1+ADh79qznhx9gAVCJ9PQckI6QFZf/3+EWgBzHu//mMPITgXbufAGpVAqx"
    "WIx/iArt3v2K2uEHgEuXLvPvzfeMLIBjx45h584XAAAzMzOIx+P47LPPEIvFEY9/908sFkcikcD8/LxwWu/p6dH+7r83fu5fPozc"
    "AoyOJlFfX5fzf/fw4UOMjY09KoZbt249KoqRkRGkUqkypPUW3v03i3EFsGrVKkxM3Cn695mdncXt27efWDUsrCZmZmYcSOs9O3Z0"
    "4uLFC9IxMrp+/To6O5+XjqGGcVuAcDjsyO8TCATQ0tKClpaWJ35tbm4OyWTSthw+//xzHh9lwZd/zGJcAYRCoZJ/Db/fn7Ec5ufn"
    "MTo6iqGhKGKxGKLRKKLR7/7z1q1bnn+1tKdHdwEMDJyWjqCKcQWweXNE9Ov7fD40NTWhqakJr76657FfC4UiGB0dFUomLxKJqP4R"
    "bSMjI7h+/bp0DFWMexGoHCuAQszMzGBsbEw6hije/TePcQXg1DMAp8ViMc8fOWrf/3v97r8d4wogEtFZANFoVDqCqPXr67FjR6d0"
    "jIwmJiZx6dJl6RjqGFUAK1aswLPPPisdw9bQkLcLgHf/zaT3T8xGKBRS+5csFotJRxClffnP4z97OqcpA637f8DbBVBTU4Pdu1+R"
    "jpHR9PQ0zp8/Lx1DJaMKQOv+H/D2FkD73f9z587x5a0MjCoArUeA3377LZLJpHQMMbz7by4WgAOGh4c9+4CpsrISXV1d0jEySqVS"
    "OHPmjHQMtYwqAK1bgGjUu/t/E+7+37lzVzqGWsYUQCAQQDAYlI5hy8vvAGh/+s+Xf7IzpgA2bdqEiooK6Ri2vHoCYFkWuru5/zeZ"
    "MQUQDuvc/wPeXQFs375d9Qd/3LhxA/F4XDqGagYVgM79P+DdI0Dt3/1PnuRHf+ViTAFoPQGYn59HIpGQjiHi4EHdn/3Hu/+5GVMA"
    "WlcAyWQSDx8+lI5RduFwmHf/XcCYAtB6BOjV5b/2u/8nT57i3f88GFEAFRUVaG5ulo5hy6sPAHn85w5GFEAwGEQgEJCOYcuLR4Dr"
    "19fj+ed3SMfIaHJyEhcvXpKOYQQjCkDr8h/w5hagu7tb7bVsABgcPOPZV7OXS++f4iJaHwAC3twCaF/+8+Wf/BnxqcBajwAB4Pe/"
    "/x1mZ2elY5TVrl0vSUfIaHp6GufOnZOOYQwjCkDzFkDzMHgR7/4vD7cA5Cpc/i+P+p8NaFkW7t+fxIoVK6SjkHKpVApNTc28/rsM"
    "6lcAGzZs4PBTXnj3f/nUF4Dm/T/pwpd/lk99AXD/T/ni/n/51BeA5iNA0oN3/wujvgA0fxAI6cG7/4UxoAC4BaDcePe/MOqPAe/e"
    "/QqrV6+WjkGKjYyMYPPmLbz+WwDVK4D16+s5/JQT7/4XTnUBcPlP+eDxX+FUFwBPACgX3v0vDguAjMa7/8VRXQB8C5By4cs/xVFd"
    "AHwGQNnw7n/xWABkrPPnz/Puf5HUFkBtbS3WrVsnHYMU4/K/eGoLIBKJSEcgxVKpFAYHB6VjGE9tAXD5T9lcvnyFd/8doLgAeARI"
    "mfHlH2coLgCuACgz3v5zBguAjHPz5k3e/XeI2gLgW4CUCb/7O0dlAdTU1GD9+nrpGKQU7/47R2UBhMNhWJYlHYMUSiaTuHbtmnQM"
    "11BbAER2ePffWSoLgJeAKBMe/zlLZQHwASDZmZycxIULF6VjuAoLgIxx5sz/8O6/w3zpdPpX0iGW4haA7PDyj7PS6fRbFgD4/YE3"
    "Lcs6Jh0IAKqrq3H//iR8PpWLExIyPT2NDRsaef3XIel0+q25udn/8AHA3Nzsb7SsBEKhEIefnsC7/85ZGH5g0TMALSXA/T/Z4fLf"
    "GYuHH1jyEFBDCXD/T0vx7r8zlg4/YHMKIF0CXAHQUrz7Xzy74QcyHANKlgDfAqSl+PJPcTINPwBkfeFe4nTgJz/5V9TV1ZXzS5Jy"
    "f/zjf2F8fFw6hpGyDT+QowAAXUeERJS/XMMPABW5fpP5+dQln69ixrKsf3EuGhGVUj7DD+RRAABLgMgk+Q4/kGcBACwBIhMsZ/iB"
    "ZRQAwBIg0my5ww8sswAAlgCRRoUMP1BAAQAsASJNCh1+oMACAFgCRBoUM/xAEQUAsASIJBU7/ECRBQCwBIgkODH8gAMFALAEiMrJ"
    "qeEHHCoAgCVAVA5ODj/gYAEALAGiUnJ6+AGHCwBgCRCVQimGHyhBAQAsASInlWr4gRIVAMASIHJCKYcfKGEBACwBomKUeviBEhcA"
    "wBIgKkQ5hh8oQwEALAGi5SjX8ANlKgCAJUCUj3IOP1DGAgBYAkTZlHv4gTIXAMASILIjMfyAQAEALAGixaSGHxAqAIAlQATIDj8g"
    "WAAAS4C8TXr4AeECAFgC5E0ahh9QUAAAS4C8RcvwA0oKAGAJkDdoGn5AUQEALAFyN23DDwD/D17IOwI6dEWhAAAAAElFTkSuQmCC"
)


def _apply_brand_icon(root) -> None:
    """Set the Sabr mark as the window icon. Never fatal: a missing or
    broken icon must not cost anyone an install."""
    try:
        import tkinter as tk

        img = tk.PhotoImage(data=_SABR_ICON_B64)
        root.iconphoto(True, img)
        root._sabr_icon_ref = img  # keep a ref or tk garbage-collects it
    except Exception:
        pass


# The Sabr Technologies wordmark (sharp angular SABR mark, white-on-black),
# embedded as base64 so the frozen binaries need no external image file.
# Shown above the install title in place of a plain text caption.
_SABR_WORDMARK_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAXwAAABkCAYAAACFFYuIAABY20lEQVR42u19eZxsV1F/Lff2zLw9"
    "GwnZSAgE/YUAEkUkCGEzC2QlCRpABPyBoD9kByWSh7IICLj8WERWf7IYIJCICwgkCAhi2DQoEuBB"
    "gCzk5e0z093nVNXvj3vO7XNv39vdM++9mUno8z79eTM93Xc5t06dqm9VfQtgOqZjOqZjOqZjOqZj"
    "OqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZj"
    "OqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqZjOqbjzj3wrnZDZrbi97R161ZMfoatW7eW"
    "P6/FsXXrVnjFK16hq/h86EAcChF1jcof3ZWVxnXXXYdnnHGGHsz5v6vOIyLKdNs5cELC01mYjum4"
    "6xpX0znbv5HdhSaSEFG2bds2u2XLllkzs/TvhxxyiCVeDQIA7Nq1C7Zs2QK7d+/GzZs3w+7duxER"
    "cdOmTbh3717cuHGjAQDs27ePNgDgPgDYsGGD7du3DxERAQDXr19f8ZQWFhZw3bp1trCwgADrEGAB"
    "Br8DICLOzc3B4uJi/JVmZ2cBAKDb7cLs7KwBAHa7XQIAmJ2dhW63iwMDAaPlk1o/NjMzo71eD2Zm"
    "ZhgAuN/vVwTLOcd5nisidlR1YXZ29r8QEWrTdFAFHRHt2muvzR760Ic+RkQYgIW5nDsN94RZlon3"
    "vrx+AUAGABEhZgYAIBH59uzs7LficdfCQkZE2759+6YNGzY8CgCQgT0wKIgAMJuIYLh+S2QGk/vS"
    "8Ioylcoshd81/G9hcggY6rLN4aXF9JXfgzjHyfmjxcm180ry+XjNJCKcZVnmnPsaIn4nrLsDZukb"
    "GCKgmdnGXq/3SGYu5yqDTD14zbLMAAC89/H6OJkTk+INy7LMvPdWQzMwuUcTEGBgA4Cs+BFERICZ"
    "NcsyH+SQsiwD7z3V5qN66dVzlCM8dwKAeUT85IGes58qSMfMKGhC9T1/CTD8MQCsK3ZSBMTywVh4"
    "zpTctxX6EzDZeePiQjODoEzK7yBgUJGGtYUTVTKYWvnh1jm38u84qeAEpRKvl+IvqbCDAQMCggEC"
    "IgIUl2tqluUZiciic+782dnZT4UNRFdCGQIAIaL0+/0P5nn+hP09pnPuqk6n83gz47XgJptZhoi+"
    "2+0+f2Zm5g13dUtVRG52zp0+Nzf3/QP5DMwsAwDp9/tP7nQ6772rzVuv5y6fne28KsrL1MJfIoQT"
    "Bc0592rO+PdW9gJatkwq1SxEnWxW1fTllmFWPY5ZsUNFyxsxxf8GphZisDGs/Ez0ahDQAMEMzBAQ"
    "AU04zzJV3dnv989bt27d51fYymBE9M65N2ZZ9gQR6YdnV/Ew4v0hojW7vggAJszMiHh8+MxawfEF"
    "AICZLwEAUVFvECBGMzSs7v5mBkRkYMUujYBgaACWiElqpyAZFrIRDZHyOBhkIRgiQEiDo2LYcFNZ"
    "CYZMlLAgfwZVMURAAwC01H9AQDAz5YyPBoCPbN++/RGIuOcAypMionnvH1/MozhAzMAADA1Mw0zi"
    "YH6iEYaAoKY4tF6S+SoWYiFfOLipKHMDd9MG5ynex2JGgzeJ0UlIjhufcfV8xZOIcj0zk7+y1+vd"
    "gojvWg2lj3diZZ8hot+3b99Rc3Nzbyeic0XEV93QFo2cvI0NvlkiGBNNoNV+RogPebDIDZrPV1cC"
    "w+ccXGwp6BZXqJVnKJVGPPrghJ6ZOyLy416vd8H69euvX0lBi+fq9/u/l+f5q1W1DwBZVOjlfFQ2"
    "vZGSqUTEInLbwsLCKZs3b75jtWGdqOx6vd4pWZZ91cxyTPd4qAjG0L0lj3Q5J68onbqRcDCMmyBn"
    "nplzVf1HIroAAHzwmG0/5hGD4r27iHyLiDapqg7NjFWMnIFyXeq92ARasGlN1t+b4NmFOTMANEQA"
    "7evj8rn8n1Za6d/pouBmhsE69G5x8ZFzc3NfJKJzVdSBFdglFo8j/BdgE0sgGASMkIwNYJnyVVjF"
    "WP3OBC9L/7fh95vOZ8krSG6El8ILk88amln4vFXeD4Z99R6DslfVbzHzw1dR2T87KHsXvEqEOhCK"
    "bWaIVUErAFJVI6LDZ2dnj10jhgsBABDRpUTUQQDfai602B8T3YE1HCw9S5visxHHm1Q9Y80wAchU"
    "tE9EZ3vv3xuse97PoCSbGfb7/bOZeZOq+saZafB6R06z1b+Ok0vNkLJveA8nncLSLSfq0JXz8/M/"
    "j4g+wFhThd8C4VjAgp9Pnc4nieiEYNlnkBg6Nu7BDdneA9fLRmz99SCnNQlVYgEsx8cdZ7FUvQKt"
    "WonRE7BS2X+l2+0+ChG/uxrK3jl3fpZlb1ZVb2YMxYad6HGbzO3EAaQAgEJETET3WAMKHwFACtmk"
    "C4Io0JCewZFzNV45j9Pk1rBzDASi9auWGOTYdH5rE0AEAMjFi8uy7FdF5JVBtvYnU04R0Zj5vLEb"
    "kg1b0PXpaFvGFZlDmGzubb8WA8R/AECmqkS0cWZm5uqdO3eeiIj+yiuvXJEMwzsNhh8ViN1uG/VQ"
    "fSsRPVFUVUQEAbj1IY510RJrwbDd0gzfqytjbLLQUgskWdSt321yDWu4fnpMa9jIDGrudsa5qn52"
    "7969F23ZsmVH9IpWcGP2zrlHEtH7zUyj11KHLirIdvib1Wcp+U6AvSwoq5NWW+HH7LB+v//gPM/v"
    "qyIKBjQyFF+Th4pcYPt3Gv8WZQMbYKMJYIeKosSlgL4BtERkFXXE9DLv/Y8Q8W3LMSwCnKNmdpSq"
    "Prx4zi0GaQMk02Q4tOKtrfMRQBdsDh8ZLBE+anoOxQMn773PsuzojRs3XrNr166HbdmyZedKxNXo"
    "TqDoMQpQr9c7RQ/VfyGiJ6qoC8YJ2ZIeADYrm3FqA7HZ4m9SWjaB1W7NHvrwZ1IMf5JbLLBVAPgQ"
    "EZ0VlD2tVCZLDKT3+/3TiOijiLguBJMnljUc9UZihjLySWtFThHxsiCLMgr/HsROcXKZtUReasrZ"
    "RmHRqas7SpljYrXj0p6PFaFUVlXPzG/tdruPXyZMwWaGInIWEW3RwmvH4UQ3HMgAjoIC6/c2fq2l"
    "Bt2Q12U1D8jiBmEjJ6rx+sNGKSKOme+7bt26q8ysE/XdT63CT1Iuvff+sk6WfZ6IHiAizsCygF0P"
    "u8fWsmhGuHaTudXWiBcNeRc4gduO1feGoKIUwsDqBoFDC7PMPY2BtHcj4qWI2F3JbJyo7M3sWGa+"
    "OgTdPADQELyAw/ODNW9lhG7C8J17RShgtYyRcL9ziHROuaZSfK0Gr2BQkWU6jo2ADTDZ4NAAG9xC"
    "rOwk9clKg/xW3TBabfbha54A1kAzQ1XVPM/f3ev1Tg1KfykwhYaA74VVz9Vq63pC8y5VzHXZs9He"
    "15AxiA3rLuZdDzKfmyGzIeTB0iNnIuLyPD/DOfeusE7pYCp9WsPKnhFRYSugiLyBmd9niFsiXo9N"
    "QhiURj1pYRjca5oIrAmGNewZifvcGn0bvqZWAYoxHBv8HSewcq3mHoTosgRl/2ZmfpqZ0QorewrK"
    "726q+ndEdEx4VtxqfiXeECI2u+X1qTWDJHvuRDPrBChgNWAdAgDwvvtwZjpBRaVxTaVuvWFZfmHQ"
    "YqFabRfAkGNQt9atDlkM3igNiOjVGlbFFidQli3BSWsWTTIzJaKNzPwxMzs2yANNKDtq83Y0AJyh"
    "qoZxHq0CVSb3PTYtZhkwVYtBVYcarcn7b1r70OAlYH1vjkr/ic651wZPnH+qFH6AcGTfvn1315fr"
    "3xPR80XEhxQtbnf363h2zdJp0/hRf1YeHFYUOFrdPbNGq72CF1rFPGi2orCuzJst/iGryyoaQZk5"
    "A4DfY+bfCYvMVlLZF//ZelX9WPTCmgS3cl8IS89OKZ4lhuMcvbi4eOTqS2x2WWmlptdpS1A21qZA"
    "cCxcgVgHmwe5+W2poEt4tmONJRtcCouIZ+Z7isg1ZrZxws2YzAxlRs5h5k1m5m1QH1CeABGryniS"
    "AHNt8hrXFVb/1rhGG5fh6AC5YQ1dMBs6dnBaMhV1WZa9uN/vP2cZ3tGdV+GH3d73+/1fnpub+1ci"
    "Oku8xJRLHOX9pjupmVUyEMpngqPNlAKyseHgTgPmNxRssxH4oTW4iiOEqhXjLQN9QaYQjZgyEXkp"
    "Iv5xEBRbqbz0tEJZVa8kol8SL33AWkIANtxX6m6DtVr/DQscVVWZeUOWZcevhixHOGfnzp1bCOlX"
    "gqJgqxgR1uzuL2mHW8KnSyWPtTlvmNMJrGMEbA4o2zDcM9BryOLFMfPPqep7A5Y/TuEXcA4GOCfK"
    "FI6Cnawx6Dr21to2YhgTV7FEP5SbrCXhj2FvKHpUhs0eEyYGooGxinpmfpNz7qLgHR1wpb+msnSi"
    "a9fv95/BzH9ORDMi4oaUh1Uj5pWCJWxXrBGpsfjAUmXe4Ma2RuXbCjewARK0pVmy8ZxlFWprkQcq"
    "IhABIQA8M8uyt690EUdKmSAi7yKic8SLM7AcFMp7aN+8Rpi82OI5Dd6LeOe9AOALsPKZOgwAfuO6"
    "dWcS05Ei4gOtRbLgccTclY6nFslLRbpqo6azpJwv8TRtOJ8pNVfDV7CSZmwlrG+JArRU4+GQcrUU"
    "5sTRz604DEIRvD5hnCYu4RyzE1T14apqgEiNaw1rwlD1AAyIFFRLiygtTKxb+Gi1StnGfSOZt6pi"
    "H8yIldlKAGbUdDyE0c56BNsMTJk4E5H7TAY+3YkVfoQFdu/efZ8sy/4SEUFUfVFWbcmzKUrQMXng"
    "E2c81L1jHPVkquXRzbig1Vx3q+QVWLQGDIcVmKWLZ1hJhMVvabn2oB4MlJgyQOiLyJMyzD60Stwc"
    "jIheRP6EiJ4ag+npvGFj4coELk7DZ2tOVFH9k2WrlakTUoX4iVWlXNPoMCjD1ygPMIgzRda0tTBU"
    "BKwIgGOk98A05bMhi6euVJNNiInoL5KMHV9WV1e9TzIzE5ELmXl9gAKzUsFjrSS+mWUKmLOC2IxW"
    "D7QQLxI2sCVJkcUsY8RcRBb27dv3vvhI7soWPiKiOie/gYhWVM5ankIjGoG9CQJPlSDPYPI0dets"
    "YNlYqHgurNYYJBtxnoCU1tyJKr8NRcugsHRrUVksCUtshJmLWPVgDEA5o1xVd6vopXmef3I1lH1S"
    "RftiInpB4MfJKy7zmFz09L2KxVnylNQ/OkjJSxbVScvCQQ4AnLNv376jEPGh4flQHR6w6oKub35G"
    "iKSi3zOw7YjIcZMovKL42LG0XwcELhVwxqgQbKzNr5kZleq6iOcYjGITQfg5BMzAQAGM6oYuIg75"
    "FXULGgGUmFlVbyaiq6IuHOEhKiKaiJxT8fuCcacVDxGbZMigcDF3IuL/EBCrKQdmG4XEyUzIEAFC"
    "Gmj4THn5g0SHwlzX4ksK1Qxpioh8IBwyAOhwxg8QEZnYp68aBUJEuYhcd+ihh950sBIu1oTCNzNE"
    "Qtm1a9ehiPYUUAADywa4S4q2BPkfw6FhUKHgkBDUvFPx5bfcY1xM5zPz9aup7L33v87MrxUNmVOI"
    "FSghCrW1YqRJjQEOlzwObdrVNFYK/590sKyhcXDO7OzseUR0iHjvDZGH7qAMsDdmfaABeGK6ABH/"
    "c43I22UA8L6ilhEKatZoaVtLFtWwAo6JFe9ExN1lwWQSuE1+jpldJ6rqQ1S1rNco7SbAVpgvaAcJ"
    "dSevCzEsZORlb/77QxkuIn/EzJcnSn94HVvN6IuTZhYthg/HubkrW/gMBn7dunVPZOa7ixcPCNya"
    "5lCLkA9NaMXCMsdZ1lHVrxHR+0UkTqQxs4QHBeH3PgB4EVEu+MuBmV3xEQFmLqiTRQi4IM5mYAvb"
    "iIiIAQAys/PeKxTc7uC9hyzLCm5y7xWyTILVQ957zIrfDQDEOVf+DACS5zkFLvvIaZ4T0TZE/OFK"
    "Vs/Wlb1z7nHM/C5VFbABfXQ9llJCXLXknDKA3lb2j+3ZEuH7ER44zsw2BcbGlSJR07AhXVbZrOrV"
    "0SXb4oBQr0ApSIgpU9WvAsANSeqiJccbaY0Ha7T1Ardu3Ypbt25dQogWCBHf781vZuY/FxEs6bgN"
    "q1W97RrfADET0XlmeucEGzGFdXMxM68TEQc2oEgZT6aHBmCZqvaI6CNhI2EzkxZlbrUNB0Z9rnKX"
    "VxjB1sozstpzQET8AzObYaIXiQ5SdKub1iAx0wY3acyYici+Xq/3yYNpwKwJtsz4AETky8x8mogI"
    "mDGMi5qPiPeFmIxj5o6CfpmAHoeIt8NdZKxGE4UExvlFZv4UFH0HCqusrYS9GX+vYPw2ARrTwDJg"
    "gEhm0Pfe3W92dvZ/VmJO4jm63e7P5Hn+dTPrtAbWa/TVyd89Z5yLyIuzLHv9anGj15QfQhGTcWb2"
    "EQC4SLz3gMhjn8rAyPLElKvqh5j50iuvvJIvvfRSGaFkERFNvPwrMT14KPA9ZCAMQbbRc78WER8Z"
    "44BtSrvhnidS9ul3xvwdEVFF5N+I6EHee0FEwsKCH/ZkB3IinHHmnLum0+mcfzDlmNaA4uIwib+M"
    "iKcFK5ktzcBpytxDa0gzS/LwB+RhnyagMxHx9htuuKFjZtmYVx5f119/ffy5/Pu1116bmRmHVzbB"
    "i5fxSs/VdKzVUPYcGnz8DDN/jIg2WMHcRpVy9zaOkvjngVWq9WrjsZaJVYsPCqiOOjMzM0evoAET"
    "mTEfT0QzAOCHCikwycke9jwNETJQ7THzx1YBjhpScGH9GRSB1VkRObnqJsMQ3FZ1uUqaAwo8/28F"
    "ALjkkktGKdKYnfOzgPBAETEwYwObKCRjVWH6cHLMJackx+/sr3cY7mcLANw9TViIcTysE0XE6aNS"
    "1/3Nwe7luxYgHQvW/e8yMwb8i7GGqaUFF/Xfq2ljAAjgiLkDAJ8ionMTioH+Uqye0047DcZZCwfT"
    "6jrjjDMmsj5WyJuQ+fn5Y/I8/zgRHTWA3SrabPBsKlgrJkkeCACgzMwq4gGBLM0XTCpFMclyqfQX"
    "QABTK8IDBCAiJwLAtSuk8MXMWEQuLjeAWrFNY8rfQHaVmTNV/QIj3ria7e7qCnjr1q22devWU4no"
    "vuLF0nsbPI+mwGnhoBNRpqrXI+JnY2B7Ajjn3NCvwcWMPEsqUtPSAqvGdQyJMhHZx8wfb9s4myzz"
    "SaGd+tob83kK3u4vEdFxlarratJFddoUYh3NbfPz85+cmZmxNkjqTm/hJ+7xvRHxbBVtJNnCJp6L"
    "Og34oDDCB2X/9wBwwf7yyayFfqmr/YyK/2zD7OzsVUR0koh4xCpDqZWpszSs5KoP0XORxfEBQPwr"
    "YiYE9NHINBimohh0DErhcRx0H0I8eSW9UefcAxDxVFVVKCgsksK6mtAmqS7pPRHRB8etwUAciCtB"
    "G3HjjTdmr3jFKxQAHhxSMX302Iby2ZvwuWBsE9HbIzf+GEvah03hgipKhxBlYRj9GMB/aKBEhAj4"
    "OURszWoZZbkv1aof81lGRFWFhweZ1TLRrMb1UtsrBQBATf/h0EMP3Z0gHnc9hR/Pz8xPI6K5Qsiq"
    "XYLSTOZh3pAEr8egTLIsV9UPAcCFiDi/HGW/Py7eanelPwieBiIiqMgHAy7pAIAH9na9n4A1euQ4"
    "UPa5qn6ciJ5sZl8Owj7IarEaBt5E+T44X0R67r1C0AgGeb2UiIrgYCj3L7eqMkJrZR3GgOLGjJAy"
    "EdkDAB8fd83JhmYH+TlnJ598cs/MTgCA30yzZUoPDa2lVZsVHluWsareCgAfip7QGEPPAOABAPAL"
    "KqrjqkqtpCXAShIYMX1ktXVZiMH0zezeAPqEyAU04MCvdiKrpbvGwO4HV0J30CorEwkZFk8CAFO1"
    "YZ6cNgZFrOD1AAAuKJOPENGvBguCV9Jdjg9sfx/cuMDRcq5rmd+NVbRvIebHiohDxKyKoyZplU0Q"
    "RoR6CvrcXFU+TUQXI6Iw83fDdyliPpH8DmGYQ6bKhDrIykeEEyOf+sF8tiG9cMbMLhisHyyVIkEV"
    "g8CavKqZIiEg4rWIeEukwVgtDzPIBYWsqzNU9QsAcL9C4SMNUYm38emHYi0CeB8i7prASiUAAFW9"
    "kIjYwCQtOByUwqfJXtWdkwo4Zy8A/NO4DWYl5s/MzlXVLxDRCRY3zErDvWHrHgsOLPbeb8t+lP1L"
    "mLO7LB8+h4KLxzPzsUVEOwB3VlvkdVfSrJ6xUQRoAT74ta997dfCJwkANHWLkxe1vL+cVzwWJeel"
    "2t+X/IK2NorNn53IY1mG1SIi8koi+i0tKyAHFny9YUxTi5awA0bP60tE/HgA6JsZLi4u3qQi84jI"
    "gGBY0kAnBOTJ86dKGuegBM/MjgGAww6yh0UAAM65BzHzvSU2Okn4ctJ2jelsY8wjDUqMiK5MvKfV"
    "isvE7nHqvX8eEf0zER2toh5HEc7Uj1MoLlbVPhC9C6DZPmuKg5jZuZU4iOGgsrfpQAPKZA1B0M8g"
    "4o8Tj2G15u/lAHANIh7hvZeyWi4pkUMY0DDEDqQGFpX71Xgidg82nAOwukFbMTMSkWeWO3ii1Evc"
    "sLHrTyV5QIk5V4UPMuOvTVg4cSAndVxawZ0uBlAWy3j7XSB4mYo6a6E5Hi6th3q8MsI4/05Ejw3F"
    "OJE3/zZVvTXEBQYVx9ZMOGU1NQMGqKKKiIcBwLEAsB1G567vv5XCfEm4Km8lx9NwAoEN8c1gtEp3"
    "MPM/D/bC8Vb+pFDTEo4TrdJNAPCXAPCrKiriRQaBeGjgcaoVAhZrzRFTR1U/jYj/NQ5CTZ79/RHx"
    "VGnrEFaDc5pYMs3so2H+MjNzKwlFI6LfvXv3YRs2bHg7EV0Ukk0G3upQLQEmU1lGv1hVNcuy963U"
    "hWerpFAYANQ595A8zx8UHnoz8RSOSLgvOGU4UPI+zcxmgyVmAAA333wzHn300Sl9GTUsDNq5cyce"
    "csghAAC8d+9e3rhxowDsBoDNcY+m5BXZ/0JKIuDCwoKtW7cOAYAWFxcRAGxubi4KPcfPlefvdgFm"
    "Z8Od9rDXA5iZmaFer0czMzNWs+qbfi8Br36/z51O5xsHqqNVUkX7a8DwpyrqDWzAVDqUZ181x7Da"
    "0i123/qPoOx3JLz5hIhd7/2PoKBHsAE1US0ib7Vq2+juExZZL8QZANwDAL4OByFTJ2l0sl5Ezgu3"
    "Sg2uTQOfa1mPVuRko/1DUg+yWtk5amYPUNX3ENH9EyrrFjrHRMFXtjBzXCRIKBG9Pnotk2xOqnoe"
    "EbH3fgATYksr0DolBXEmqjv27NnzsUMPPVRWAc5RM7sfKLwfCE4RERfWTXXXH9WNy0A5Yw7Fd1+d"
    "IKvpzm3hBzjnWWEq/BAjZsNMDZluCBTItu+rqtcDAFOB5BAA4FFHHYWqGisGMbEk0vgPbt68GVUU"
    "AYHXrVtHqioAGwFAkQA00BkyglGV7KX4/uzsrKkoAALOzMxEfNKC8BKYUaA+K/qs5DmgaoAfMsgy"
    "QPFCeZ5DCJhF4A/L/q0AVG2xa8LMeUbZewHgadFyOhDK3jn3aER8r6oWDSzQKqRBKWhCLWalmUlW"
    "wDg/CKmxt9eukaDgUdkGAA+Htn5GdW8Nh7jNY1rvQWtoft1117GZiff+UVmW3SNYwjSR/5iKb0H3"
    "dquZPTD8xSWfpqB04/NnGI5TIwCgcwB5Xm4WNDBA+grQqX3WQZ7nmij0HgA8SEXfREzrRaQPAHnp"
    "rVWI/prZJK1YUEJFncu3VPVZeZ5fN2ErzZjWemGQKBpY8S2FSbXTIyGg2o2HrD/kxH6/z3mea7/f"
    "l06nE+dzNtyvxnsDAJ/MFTjnMM9zc8UHhsTOOQdmpp1OJ30G1O/3tdPp3B9U/xSItkSyt7TaesCP"
    "OJIpVgGAxclHeJY1EswddL27CtZ9TMU8OVQqzkJLZq81VWyWkM2gyo8zxhW8/qHNBwGHYg2DcIPV"
    "7sdSepn4fayoLxwJmBb9fhCRgLbPL87ff8OGDbfubz53VMa9Xu+BWZZ9BgA2lYVVNgFVdHVSJOSa"
    "byOisxDx2/UNKfEkXszMry3K6i0rd5SklL9F79Qho79g5uccjKrVeO0i8n4i+rWS0XHyA5RCgYXp"
    "AVqkJlkRu0AzA4qZHYGHHuuFaTi82ZVNQQwMTK2WrlysDzUtLJ4icGxMhGYGof0kV4CGEf12I3cN"
    "IhIREQC8BwCeFwK1Y+UvgXNOU9UvF+EPxRjoLsW7qYMUDukFJUQurCo2KCKlGkDgHBFJTS3QoYAG"
    "eptY2Y01qKrmj5UbmyUpY+E5ITNFZgCPIWNtqSKFiAYGvu/6952bm/vOStVjrIaFT1AU3jyTiObi"
    "4qnvhlZHJmtdadInJF40LJzy4VV+Ts2kkg3Tkg4FNegopTBu5HRvbJALKV1y3RsZEG80eCuY5O9h"
    "cp1JzKJ2SiGijoi8Lij7/bLu4/fn5+ePzbLsKiLaLF48IvJY2oPh9Oyo7G91zp0zOzv77Zbrs4CJ"
    "/3dpCCS7pSUKbhSdfhK4PSipmQmcczcROStkCvGSOkmlcl2kEUBI40EL6ZuImHRttULZqGG9HqHY"
    "EAaFCWWXpsh7o0kcDCv9YC3+npB7cbpAEEc3MbfB5toFgBcj4l+k8jOpgamq5xMRiY/FVikCgiOj"
    "X0kBH2t584IIkEWc39QsbHLgvY/5X0WyWIiTauDNTx9j6fSjNTS1CHNcmz8b7Y3Ubr7k6HdENOOc"
    "u24llf2KK/yYirljx47NIXXSEJCaGhU0rezhqr9kJsHQWrJ7miL9kLaAw+reXrYmwxqTo0F784dS"
    "MVvcwhstPWtIM7UmMKOln2jASzuq+l/M/JaQpbM/ln3E1DeHWMg9pKiA5ZhH3rh7NfGdqAlzlgHA"
    "ThF53Ozs7LdGWNzxiD9QVUFEsiT7ChML1kZz88RKyhMCPbM7wCRqDAWh3lnMfEjJLzOJsm+xCzDQ"
    "Hjd5TVGpDBUaVZhDEVMYpFabUGWZbG7DmcQfGvDmJggH0DjjXFW/QUT/GxH/PcbilmBsiJllqnpB"
    "hONbmETLDatNL1gqLMWX1AZuAjYx6lrZt3TQYMgq69uqSSNJxXSstA1LlYbC5DjJszdDQCWmGVX9"
    "nIg8Y5IsuwNtba/kYES0TZs2PSGmgBkYNU1YxZJvIE5q1LgN2TklB8uY/qKIVddubPPjhgbF5eYw"
    "pj0hjMKpxxnUgZNDVZ+PiIuwH6l9CcXwOlW9mohOKwN4VvWwxjV1UDMl5gwQdjjnzul0Ol+xop+B"
    "tFSMxmu+Fcx2MTMWvQFs4ClhQ6Pvcumk/pEBmB0NAHc7GAG6MO+XVGRgIss+lQ9Ld6dC+dhw2m2U"
    "n2htp/Men311HWClFWH5M6aAYTgWVfPasQwtVHVn7RZ9lmXEGTOo/ikRnR6UfYaIMqnsJSmHDwSA"
    "U0SkgAuxtg4S0rnGTQtqrnK8h+pcljMzrC9q8xlx93RzSOd9wOmFdci2PSBrTX9SRMTAkvrW//7v"
    "/3703Nzc92AFe0+vBqQTAzbPCpVz2LYrIuJkineEQh006pmsFwFM2qkmoe8tg1yWdEgYj8M3XvcY"
    "rBrATKiAS67K8/wT+wPlJHngIiJ/TUQPr2RMjJrv4Q58WmSg4D7n3AWdTudL44JQiaLYbgA/AoDD"
    "CkadlHGqbVIqKXqookpMm6BIzfxxMGT2O+MhutoLCwvHA8AZhVIgspasIWgL1OFA7dgEXkHp8WIV"
    "ix8r/9YgaNhsVwyMm9hfoq4uC3s5ZFndJiL/J8uyDyXKe6lxEgIAUa8XUUYk4h0gZlVoc5BRgQ1z"
    "W+uO0biesAESNmjwcmxgVFQMmoaUyop3VSUIbdFPtfKqou9Brqo9EfntLMvemRRtrWim1opZ+OUO"
    "7+EMZn5AkQkTYIM6ta7ZGGGGOvNi88Kp4yaTHBcmWUwNnkdLdeiQXIzIEh+z3xgSkaru6ff7LwoK"
    "e39gixiIfBMRPV7qyr6lgfQwpo+aEWIoQLm40+l8btLAaayERsQbSze9XOjVcvTB8671cSUEJBRE"
    "jCRqk9rfE6+PTqfzWCLaoKrOzDDKqNV7lVk1dlSXGxu38afWZT1m1fC0h3IgW37BBly8RBENh1DK"
    "ouGVGSJ7APhUt9t9SJYVbTSXkz4YZNXfYDd0jOD8cE1UziE0zGGDp2yjvChsZOMY2u3qcG19o21C"
    "t6zezGEC1y6tQwnK/iYR+ZWg7LOwka94Wu5KWvhF+hzKc7hIDLCKJV/HwlsebLW9ZvMu34w3Dxdu"
    "LKUF35BXaKNTyOrdmqzqSiSWDLZh09X3AmQiIm+Ym5v73v5ko0Ss23t/ORE9V1WDtTWam37oniy0"
    "6SFWE7kseB1N19VWGBTf3zaw+m04UG0wFEvBJHUwMPIDMx/o/rYRznl85XrTJNWmIps01NrWxAMb"
    "5LDayQmG1keNLdYm8L7KTWPipiKFYHKWAaj+BIAumZub2xVlZlIFX+9bi4jS7/cfzDndJ/S7oMa1"
    "Pqbfcdu01ZZWQ8/oavvRSjFXXM82aFgzPj7T7o4n6LAFZf9xInoGM9+ymr0PVszCT1Ix74OIZwaW"
    "QZ7Iwm4g0Koo+kQKhnbiWqslS62yidziBo1l1oznNzR3bubxRxjIGY49fbg1RSJW0e8z85sC9r5k"
    "Kyu8orJ/KjP/UbBaRyt7SwWmFBkjImViBoCnRAswCvNSKA7IbNvI+ce6oip6nVrNdVfVey3Rbxsr"
    "s2Z2bzM7PfRpoEbNZM1zNUQLUsdV6hg/Tnbx2Gjet8iPLREWjTifFwWiY1X1PVdccUVJUzKJjLWd"
    "jZkvCPiRJuXILYUczZtjS+hseO9AGMX9M5yRVAli2AhXYZSHXqZ9CjNTwQrrX8XM50bupNVU9isJ"
    "6SAAQJ7nTyeiGQ0sg2Hvh0kXe+nxgzW6WoOoesVEGlhOtaDX0HmxXZEP9DwuIaYwCh6pmyfNEmUD"
    "5YrE9DJE3AvLD9RmIYvlMYj4l6GwiqMb3waRpUyJJRd5kS2UAcizEPH9119/fT5CmG3ksmb+TviN"
    "ygbyTY8k6XuAMBxDM4MTU8v8QKwNAXk8M89CUSSFQ4A4QpXzZ7j8vyqrjR6tVSuKG7K2rC3xYIwo"
    "Lgf4C5soiYgjovMvv/zyPwkwzkhGyxE0xN7MZgDgseENqjzYypxZxUyGCaDQugfQFKqthnRHbCzx"
    "Qzh6kms96xODEjwzZwqw03t/MXN+eeS8WolK2lWHdJI85s0i8iRVNSwawrdbPO0C1fh76V2lUEDN"
    "2sZR/RAbXbUWl20pwdhRG8uQW2gtO0SR6qiq1xHRBxoKmHCSRQeD9nW/qKofhaL2QSHpjdoYuArX"
    "E/uxhusVYs5F5A+yLHtbsOxd3aWfwMqP1/pjVRUkZDBTG6RXDDWMKIOildrfMvnlBDNbh4gL+5Oa"
    "GdOHr7322gwVf7XgxCzSh1OIsPL4GhR5ZVOylrzSlIoiKTJDqNEYVJ4Npm7tCBhjgnU1KB1pWm4s"
    "Ii7Lsud5729HxNeMgyTqc57I64MQ8eSR3Dn12ob21OQhYu6mJWaTrNMGOofS2x3RprLuDRc96UEC"
    "hPMl59xTx6Ql3zUVPgzymC9h5rsHit3R1Wk2IdY45I3ZcBPtxNKaoGw7CRLWCbEMWhunj9wIhjsf"
    "lZW5iMPnrTnkCICq6ojohUGJLhU/HZChmR0HAB8hovUiUlZZjiNHLJs4FOeO/DivyrLslU0CXedx"
    "H6H4y9RMM9vJzIeLSGtMpikvOyy8WMB0JAAcGWICtXq70T1J69Z9MFJ+TlVPDSmEXOraqFdrVOcG"
    "jVk6Un3PSpbf4WCqlc8iEAsVqduAzfnh0AheD3RUVa4IUtZBtFI0tS3ttkiWYRV1zPxq7/2PEfGv"
    "l6jEYrHVRUQEYCAVGpUhBdxazV2hDq4XVNZx90HGXMisghBsHwHzxAMbWoPVX55Uy9MONn8zsCwU"
    "pb2LiH57dna2u9aU/Uop/GiNPh2KND2JIBkOZdMmO2tVyYzdpYuUtwE+Z4lriE1BnxEqqFoQkxa+"
    "1JRaWQ2LpWJHRDbVoexCqMiNwUSVmmZKGWeq+leI+JXlpGFGvN/MNqroR4jpGO+9x7Q5dX31tMcn"
    "YqXlG5n58pBtMPH11JVt8vtORL4JAA4PRT71RrCBEhuHg/dRfakpM886545JFP5+QZCqejERUcmX"
    "0gTVJWl61qA4Q5PtVR+mBmqqRXVvWXlaMV7rTLM22BpIRYWZ/8rMfhBaGI5VZtFTuummm+bA4NwS"
    "zmkKIrfE9WPzFWam5ULQKhIsIRrKrKpvxikEXOf3MQRg5kZYSwH6APB8Zn5zEgNaU8r+oCv8qKAW"
    "FxfPZOYHL2sBENy5hhlI2j+zRjLZavk3HImJCVRvJ6JXxFaDS1Gq0aq9EaBzkurVxPQLIuIIKWtM"
    "NWvjg4DQJzjLOqr+r5nzFwTsXxLohscp2Rb3hItNQ78DQA8MqWrUwos9WGBmZbOUIuO24P0honsC"
    "wOeHQKnJIKa00clsJPgaSGFLbiS0IoCiqp8GgD1xYyQgUNA4XwoAQkBZeM+gIPtSAOhCQaGBqpoB"
    "ABKQKSiCAVtoDxCutx+OH79r5fELACUDgLOJaL2qCaI1Mn1aW+FiwfGjqpoT0VVmdgYi/ucEeeSF"
    "p+Tc6cB0UpGKrTQw5LAax2irTkVEFf0RMX1FVWcHwU/zZkBYAOqRrFAJCICUVOOGBY9CImpi80w9"
    "qnrtT42qxcAMVfSLgHAHAHgwUygMJxWRN3Kn8/mk+ljXono62NaHAQDkeX6Eev0AEPQihwURKQwo"
    "hqF016iIH0Z0kwiseHCkhfNZDcMQkCqoEVHBkqEavq8ARAXvgKpAcb6oNMvjEJGpqhGRV1UkIgi/"
    "o6oiAfjwXVRVIAAJT5KJgFXBCECBqAcAXlWfgczHW5HV0ZZQVKbuteUpGoACQSZiWzPEifhyGpR9"
    "7Fj1TiJ6hIj0ETA3sKXFFww8ZdxR1Q8TZU+NdA416Ga51owHAPDmvw4AlyYLt+phYJUXPdURZZih"
    "uJaTJosIjTQxBAAeEhqdDJpR18p+DGpFUgP2O+WMWUS+ycxnrQ07xM4DgKsCKjgeKA3PIE3QUlUh"
    "okNV9WNm9igA+MEksRIlurAo6QYFQKq65VVPEocR3ZAcAL+PiP9vWQLm/YuI6HUq6gytsbCwPcZX"
    "vh+bz/+QmZ8wysBdy/boQVX4cZfLsuxvAOBv4C4+zOyPAfEoE9GifSkOEKmhItwGHHawwCIB2VeD"
    "G93KlxMt14ZFx4joReR1RPRE8QUNrqE142OpQq3elOcsy0H1H4josrbzeu8vA4DNwCwgAgzAUqbj"
    "AQCwgohJ4eVFxZqLSAYAgoqnFbycSFjDYmN+NKUKCFvo+VXvkTgUyw7cBjgHEAru/irujdX90Wrx"
    "GSiaeCPi34WNt9MCfbXt9xMZUkuJoyHiNWb2DCJ6p4hoglg0V5TWuO/DM2cV6RHzPUHhL5Dx3DbP"
    "M0nWmFORs8OzpNSyHpDB4VBKapKdlonITmb+RDhXKyN3CzRHiPh6ETmDmM5JY1dLwfcCQ4Bn5kvN"
    "7EZEvDxkHkVDx9a6sl8pDL+0NsdhptBePtW2GGyChWJjzrUchRB1TIaIi2Z2XwB4LwA80AYpL7Xw"
    "gw2IOssok9XI3Er3seAiU30hM7txvXkbgrQFiZj3lwPRi1S1j4RZmdo3hNEPCKUGxyw6+gXL/jNE"
    "dEkQ7hjQjM80ehBPS4DrEqupAdpD76WQaAyODrncIx6UDbIoMKy6e1Y8xhHzNEJJbVHVC8Kj5ApX"
    "N9pw8nc9FwCBgzX8kbAxulV28SXIxLvM7HBmfnVs0FQtDrdJBL9IVzX57Ji1Fz2lBxPziUWx1SA7"
    "pySFSxMGhqnQJdA6fxoRf7KcIKgVAwHgfwcD6ggVUWvSRw00DbVcf1IRR8wvM293IOKb1mJgdtUV"
    "flhoMuHG0Lo4x2VaNGG0DcpwvxuMJ3DJopmdFyLzh0m97yu2NBCy1BpMhKugDyuse9F/yPP82qW6"
    "iTFF0sx+FQD+KOFux+EttQLb1C09H7oZfZaILgipjpwq+wAXvZmInlY00kAsSHirPQNii88yy6gZ"
    "UKAA6I3fvodYUzGtzz02Sc2cKO6RyEVsdPLoLMvu7r33CIEiOu1LOzLDF4WIMlX9NwD4xsFurr4U"
    "ZCNg7q8Tkacz88kpXDWh1WOImKnq7m63+75JDKYyOwdAW5vGtGSsRszdzK5a7roNxXOMiDc7555J"
    "RB8DQFcstVrmDo51GRAAWESEmd/onLsRET9+Z1L6az4kWt8ERllp8e/pa6nKvOn76e+xYXJQfC8D"
    "gKsR8TAplEPS43S4PVzdkhmkYZeKXwERVbVHTL/fxpfTJvwxmGVmDwOAd2q0qqrciU34ZIVcPij7"
    "XEW/BADnIeLehEYZYcDD8xoienZoXpIDWBb+xiELqPjfIAMDDlk9mYFlYJCFjSi+CMf5cbW/Y51Y"
    "q/CQjgCAw5crbohoRHRx8TNZWbBnWI0rNGiIQkkVcSYi+nCQH14jSwlDtfvPAsDxSWe1pRxCiAgB"
    "4O82bNhwS5vnmbaEDLGD0bqmqRTHSjjnDmb+ZJhLXeaNi5lleZ5frapvIKbczCQhFJrYrbdBBpcS"
    "0Xt7vd4pYc3xVOEfROW/n97Gst4PO7ma2QYRuRIAXikiUvC5ExvYaGCqAURKu2JBERhiAHgzIn4j"
    "KExdgrIXMzsVAK42s3WxYrIGLI00rZImF98kpnMRcU9CM4C12MBLVcQVyhtH51TXOXHG0QJUm6dO"
    "IhukqsLMG5xzx0f5TqmZx8hPVFLHmNlZRXLBYBFX4a4KnpTqjGgBdwHg6jZoabXWuplhlmVnEdGs"
    "mXlI8/Jbko8qyhiBQkLDO8bMZZS505n5+GrgezRYawOvUBDRmPkfEfGOcbDmhLAWE9FLVPTzzJwD"
    "ggDi6PuHRiqtOA+HZll2je2zu8c+zVOFvx/KvR50mzS1bqlKfxJsN7ptvV7vvgBwHRFdEpoXE4TW"
    "dNZEjTghj0mIMLKI3EFErw33qW1eSF3ZBYE7GgA+CgBbivZ1g36hQ4U+zU5rLKr6FhGdjYjbawst"
    "ehBXENGLVMRpbEvYVrbexig6ztxrYn40a+BWSlv9FfOVU37vCsqezFmT4k9jTCJyJjNvtqL9Hw5t"
    "lE0MB1iwdgKAUtFS7/OIeONq0N+O814Q4ewqAjUGzqg23mEA+CYAfGHCzeyi4FXq4PlZO8FbTabD"
    "2a86gGveEFGcd7+pqvtCfECHqpOtSn1SZ7WIvaoD9cQ9dU6vNLO5A2WU/tQo/Loya1LEB7CT0aQb"
    "D4XzejM7r9PpXAsAp4lI39LmxVDNwRzqiFjjVhmyGhCViIiZX4uIPwkYuU5wfQHNsI2qeg0AnOS9"
    "D5kIVrmu4XLw1LQvmqKr6vcA4BxE/GEaP0h60D4PALaKiDcAxrYa9pRltFLMY62LPKilZirqtg3T"
    "sD7FoFiSqME4eUrh5vCZi4e8k8rpbCiWkG6qAc7527W0vkLAVszsKDB4cAHnII0nLrSh+TGiDwa8"
    "mtvibOFcG0TksRGdKSkhWipp065TZmacMavqzQDwmf2Bc5rw/NnZ2f8xs/9DRFykirbIV0WGG6BE"
    "g0y89Inooar6jrBeeS0r/TVp4S8Hf1/uOUadJ7FuUUT+JEAlh4sXDwB5K2VJAwdMhbMjZXoM7iYi"
    "s6p+GwD+fNK2hUnw1FT1r4notNDEhNtoN5t0MoAJZ1lsOv4riLitRdk/h5nfKCK+jA0MlfnXjfJa"
    "YBiGF07TXLU8tAlRZ6qkZo7yIJM5VDM7GQAeWWHGtDrGjG0wkxEXmHMC58gaUPYxiH+cqn4QiTYW"
    "RWqGQwH8ljabGKAqEekxdP92jHVPAAAe4BHMfOyACtnaO7tVekkgEFKct2sQcXfSLetArHsxsyzL"
    "sveo6ruJqUr613aWtKF8WqCFkIsXR0SXicir4ma4VhV+toKCN7YScxTWsJ+fa/pOGgzWloXizexu"
    "qvpeIjorpJYhYPMDtQZVWpWZ4X66YRMQKoqsXo6IvQnxyhRP/wsiuiAWVjXx97RCSSHnHwBi0/Hv"
    "1miO4zw8DQD+LOQxU6WEGNo5hYb5hobnBpf5hIfqBspOfVphzZwgHx8DnHMuM8+ID5lNrRS7UIG/"
    "S8eiyGX9LCLevtpwTtLRzDvnzgGAtxPRMeK9VKgea52fyuKnNBsKQLnIPPoXxMmabpPqeRCzc+Lm"
    "2UTOl3SPq28aqnrVQbKWxczojjvueO6WLVt+iZl/RlWLwGsj6llNW7YSmiqpX7KQo//73vsfIuLb"
    "1mrmTraCgrfWihKs5oZazWr2ZvZLAPBeIrq3eB+UALYKRKOJj01QdKmoDBGFmWdA9aNZlv3tpDSq"
    "MSPHe/9yIvqdIi0yKKk2FVprIWlmGlIId4nI+YHdL4cihS/WGTgzf6mqviNkNtBYIH6pLR5blECb"
    "ZxKhoZjDPegTG2mS7Xgz24CI+5riQA1zKWaGqnph+AyWPliAIsqipNiIvv0er0piArpKyj56Z+a9"
    "fykzvzp4qQ5qLSyHbiPeX1JRZmXHQXtnopDbs3Nusw1i8ivlZ8eRFqaFawW0ySLyg5/85CdfOOaY"
    "YyzQZhxQ797M6PDDD99jZpep6r9CQUthdaSz3SSp9rwt9jj1yPxm52wbIn5iLSp9PMiCV1oC5v3T"
    "gfnUUJBiWvAlcNzNi1xdJVWIiwXLTYmoA4FfAQBmEn4RNjPEgU8YX7EiL/KPlOdQVYbQvCOkpkFg"
    "ovxGJAMLAvGbqvpmIuokuezDSmeoaegwwVdael/0fsDIGojMzKD6diB6DhSc61anSGhjv/TeP52Z"
    "3yHe+2C1Yd2jMLMq8eeAtkAQkYloAQDOQsTPR2UfPpojYt85dw4RXRMsLkREHKvAG9+zyXsGw3B3"
    "rbZj1dgpjZDITHvEfAoifnecNZpkIN1PVb9iZjyw3tpWSWRhLJ+vIiGb2R1E9L8AYAeMYXA/uGgl"
    "ut27dx+2acOGdwLR+d77QIMRiMtKRWXtz2zQUl6JiM1sGxHddxT1dJIpdiYA/FPpDdYLkhvYZ5P1"
    "EhMH3oqIzz6YdAXJOno2M795aJ2XTdWxSsjY/nCVGVGV9hDBGUGnrCm6hewgKvv48FlV/xyInj1Q"
    "7IP/6/AftUUVan8gmjz8kHRpqnwvbDKfA4D/MrMOIvbNjM3s9QDwPDNT7700NvYe4AdDmGcKOUAU"
    "FKt8xnPGkejqecj8p03KPbqzNQ8kC276Wcz8tiIbB6i690Q+2aJ7T8JjD1TQPSgiEhH1vPcX53le"
    "V/ZZUPaPzLLsb0UFwcDGKfsBY6lVlHJpgTdW+dZ+TuesxUOIdQsDT2nAU6uqwhnPAMDxAPDdCYya"
    "QLekFxNRpiJOATJMUkitiVEOUxoAU0JiM/twCLivNm7/cwDwPgD42WrhnbVjZfXnGPvyFj2HGc3+"
    "Nij7SazWC0tILeanV7yx2glT2pEB3PSRFdgZfbift3jvH83MF1aVPiYtNqqbozU0qUZEUgEhhi2q"
    "etW+fftOx4IHa81ka+FBEriI+x6lqu8hojPDRJYfwaoFGy0lG1BNBxqCQLZWUapWp6OxSEZmBjV+"
    "lQZmvkDBC8S0AAAPAoDvhc3pOAB4FwA8uqiyBBqq7U873tcY0RChQpHQYIECIjgi7qjqzUT0tOj6"
    "Rc+iwUW2hk3050DhM2KyOWKkWEOXRijmgrsZwRPRRYj49zVlz4jo+/3+g5n5HwFgk5mVdMppZs1A"
    "kVuFez39fUDY0sLCHBWqJizIo7I3q7GPpk9EC/GZiPj2cb1YY22Bqn6NiO4r4qXsvNWwWKzZY9Gi"
    "eQt8jIj+TURiSz8uQgNgzEAhGGxQkE8oMJuIIDNr+B8D5UE8naZTxfHzwCAsBjJITAIADDQVG0Tk"
    "Ocy8OcB8+UjIrG3jrsJfjogeiIj/1aa8kqY3G0Xkv8qAbZRNqxAOtUFiyswsKt9j4lMQsTsu/rI/"
    "fEnRwws/Hqqq/46IJ6iqIAC1NVPBisKHIVVkYJIVSRBfIKJHQ0GdbCudYbgiFn6i7E8VlY8y8Uni"
    "fYkdIiKYWpgwbGhakPxmY7pOWdVasFgnWoHXrcITEuTOE1MOAC9BxBvDdT9EVT9ARMeHTJes2W0b"
    "boKccm6UyQjYCDsLFXQF/9Lr9Z68bt26m2rKdghrbFD29wSAjwPBFhAoMwKsCWYKF2SDptoFLoZk"
    "Xv2lzPz3qUKMcYF+v/9QZv4EEa0Lh+0cdElMHLagGJsVfaCzGdHMxgL8dPISvNCfA4BTCi4fpEao"
    "wwAUEySiKpdkosZZdgEAXFCnTI+/NlGpx/fq/7eN8nPArbkgTAQhOJs3mnaN6WUDaQ/KHsDME3On"
    "CNa2K/tyDgzUe396lmVJdk7abB1HWp7Ftg+MgFcHZT/WmxgHf05g5Ufqhe39vj0xz+G6gVtn2OAL"
    "lcq+bd8iJBYRx8ynq+p7mfkJZpaZmay20s8OoKIvg53OubNV9X1MfEgZKCqD2pbwyFg17jk2UDIu"
    "CFjN8cY6BXFxDUJFvvm/8ABKeRYAvImIZsQP+OIrHYyShV9vkGKGw81NwuZCSGBgigBABYzzDgD4"
    "nXXr1vWCZe/HCWxSWLVFVa8ioqMLjwmzNh7xdCFT4nQEq/NJOedXhz60Lnl+urCwcBwzvw4AdojI"
    "zcHij5Nb5IsWpO4lZ3300qBKdqhFDAVQAShcgEZPuaAyAS2WlhkUikQB4DAAPHxo28QG3VQaDWmT"
    "mtL2OrYZuxieocD3gqG2IMMWsxdrBRbVvuoIwaLVunDW6iAKATHFGv1w9FAjjBdlZ5IVAFBllOai"
    "0Uj9QtvjKEPAlZVcSkZEb2rikm9ANE2Eziu9DhwU/g2RpDXkPiAimxkQ0UcmeHYjlf8Svydhc/lX"
    "7/0fMfMfehFHgJmNWF+WeJsl3TmVUGMWlP6lzrlvI+If1Nf7nRbSSTJx1Hv/bET8c0RkVfUYWsNN"
    "cIzhnrVlK8BhYU03jHqADyHtioZVew3BmNh6AKfMANwCAG8EgN8sKGPLwonGGYoPH0cUjwwt0ECG"
    "FgT6BYj4xnS+JiSMwxtvvDE/6aST/o6IHiORzqDW3B3bYQhLsh+elmXZe9qgjlAxyD/84Q/luOOO"
    "q0+pJfY4AtwKAEfVdV9F4dcC8PEYlHwGoMhXJwBwIvJEZn7vMI2tDdpORpzfUi6isqBNqCCf+yJn"
    "/JBIoNYGl5lZR0W/QUw/U2F0TAPDTQvFqt2R2lVxWofQUpOA1qIBhy1JG7ec65WsScs+bNVag7hI"
    "mJNYhPcDInpmgB1brfvBXN62QeXwG4jpHlq4adR033VK5HBtSkwsIt9i5vsDgFtJazhp4mNaUIH/"
    "ioj4uAm1Nd8b4a0UEDWCEFHe7/efOjMz857VztzJDsBElYIgYm8igueKiAb3JVGeVu0TOzRJzRhI"
    "U0AUa3+r78LWElZFACHiXER+e4Z5DxSdke6nog4A2CJ3CjYjtzgm3bHOElkEZ7McAG5H738T8/ya"
    "ekeccfgkDOgM/hoAHpPCY8lGAa29bhGtuG/KAeC3Rin7cKzFVQo0RgV8Y5hTqgL+WI/jDAXUijmI"
    "QT873sw2BuI3bAGRiubahD9TgSASi63VKqr3ToaGeOhQjQK2BElpGM7EepNyhLF9oMEa4RoEHNnD"
    "OYl1qZlBiIF8lIiehYi3TZBpEuby0DOI6R7lXMbjJi1Am1qOBv9CgwN6VUieWFFrOMieBiPsSar6"
    "NUY8WkInNWttIzFs5FloFGxoCFZQZWdZ9g7n3I8R8Z9XU+nTfi5SRkTdsWPHZhG5mgieq4PgLFWV"
    "UJuyt6pdOKJCtJXA3lpszOpqiFDOPzHzdwDgawBwv4IiwTJoZROx0fhnIyaKBlaSkH0ZAB4SlH0W"
    "SaEmnOJYWPXHAHCpiPQhxBawrdx72MVVIsrFye8j4l/GystxynelXwAQ/79VVReJiQZ7to3Anoeh"
    "6CB3h0PR0HzkU1PViwJerWlvAlzaQhg2UkbK4wjDJsSGyvzi4Wzb5fnrYw5hBfEcF71j5eWIeNGE"
    "yj4JuWYpnDO8QVqVgqLEgYrHzKpqzrmrlwPnHCClH/H821X16VZw7Qx4mBrm05rIlapeFpoaEBAR"
    "0fsWFxfvGQw4ulMp/Ki8FhYW7rF58+ZPEtG54qWvNqw8sUmP1i17HKHR69AFDCxas6Zc4low2EK3"
    "HtVdRHRb4Jw5KmQO5UPHGcZyBq7vuL4pBRWIccZ5CAI/EhG/U9/Vx7E4JsHv3yKil4iIi/TLBq2B"
    "4dQqNSgs+0xE/iDrZK+Z1LJoook+2K8Iu9x88823AcBPKjGBGgxSaURttQpmAFRRJeYZ59zRjSI4"
    "6Fu7DgAuCN+lCsIyzpq2ulVtzcYHVg/a6omlvRqtDVmfAEeAEcZT+1r2kVoDAM5EzP7IzGiSIsAK"
    "d47JmeHaB9w5dZsvrVYd/K/ETGb2n1/4whe+Go+5Khj3gEr5E2b2h0SUmZmM3DPHkAIiIYmJENER"
    "nU7nY3v27DkibC50p1D4UXH0+/3TZ2ZmPk9EDxIRhwh5k6XZtDNW1GYTF2nKjGjVjJ00aFqh2sUG"
    "rwGSvOJigT8FAGa895JCWlQiAc3kZum5y4vGqnOKgMIZU2AVfAkzX4aI8/UO9uPKxRNlfyEAvEVF"
    "JUBOOLhGG+HZGwTu8hxAtmZZ9sqY+rmaAaMWyz51qfGYY45ZAIAfl/eZKFdDqyr7GqSTvFdkI+X5"
    "MW1yb2bovX80EZ1YxAuMWgutmmwBTCGbgbRUFFol8oEDg6FOxdi0BpZg3yJg8zHGOwaGiBF2/DQR"
    "nZ5ADpM24o4uyMOY+XjVstiqfS5xyCON8OZHH/GIR6woF03LWoxUyltV9RMB4pL6ZlWPQaaAQKVQ"
    "vKjvZBV1RHTq+vXrPxyy83ClidZoGQuWQybO45n5n4noWB+KFZbig43tvhAVecAvsMHNxknd27IA"
    "CDsiIiG+0MwTHzYbS5D71mOX3aARAMwTUwYAOxHxPER8XbCSltTxKGlicpqq/o2qliUwg4nD9qrV"
    "4u+emHJVfSNi9oq2PP9VsJ7GsaFSWP4/CB9QQAv1DQPoagLApVhhIq0NzUOjkwsruB02WMajoqUG"
    "rRY4IjYr3srvTY1yYHhTg9EbUL0oaEINIlSMHABeBx/60JmIGJuaLBVfNlU9L6wxHcy4jYeWgvct"
    "Kuq9/1i6AayUTLa8ZwAAi4uLT1XVW5iZI8VD7LKWev5Vo7PWZmDwtywQrT3Me/9/gxfDa1LhJzTB"
    "4r1/PjN/GMxmRcRjtJTTbBGbqD/m5KFvaGPNtaV8wxAQLaQJtlpLOKK1bkP7wrJDlOrX+/3+w0Lz"
    "6mgl2aRCl6RfnqCqVxHSukD/QPVAUbuux3gtb2DmF4QgsayFoo+JUWiCG9O3yva/9WDfGBplNbxP"
    "/S8JBHEIAJxV9q2FKhbWhJG1ufLNhshwxtmo60UYHY+BlsyxJu/Dxk+yZ+YMEXcAwJMQ8SVwySU6"
    "KY9TE5xjZmcX1bkh8aEA6SYJJSgREQJ+pdPp/MdaaQkZroE2bNhwi6r+RqCCsQp2h22PxNrmq1D6"
    "Ii7Lsmd4718cq33XlMJPaYKdc29l5jeYmQSHm4dgj3oKZZoHnFReDilds8l19zDAXz1OFDir5wQa"
    "DqgGhn34EZxnNW8huMSAMYXtyh07djxsZmbmhia8fhJlDwBmt9kGVf0IER3vxfuKJ4KjBQoBXLDs"
    "/5KZX5hkBK0pZT8BLfW3hnRnU0i9xeUrFSbBSQ0WI5sZisjjiOiokDqMQxZy6aLbWCil1RBJqkut"
    "JYNmFGo0bGDgsLE0kTlfQqBFXKeQ1y/2er2HIOL7gsJZjqKNa/+XCzhHB3BOBZq19mUc4TeiqyKf"
    "/BqS04jnfxIU/rBglUWHaZQHJ23/Xp03FfXM/Frv/a+tpNLPJlT2YmabVPV9WZY9TkVDZksSlTED"
    "JBrCt7CAsIwANLQFwrj1I5EVTa8DhlvrvVoGdlLMPlI61eHOwd8j07clKVPVpM0IiagVSQKRCwvR"
    "Grjqi+MaVvKZzcwCtkfe+9flef6SFJIZ5zbWlP1g2R4O7yeiB4pIH9NKyfHDc1EVeSURPXutKvtJ"
    "nDhVvYmZBQoaCIPisVSKrppoGgYxXTMA8GB2lJmtD3EUTIPDZnY2AHgEcPU8C8TK7jGkhkvIZVDz"
    "NbiepDdwUfGGlern+HMlhTdU7iEVTd4xsfRtcNIK5IiNsN6I3EszjfKqqm+56aabXnDiiSd200rv"
    "5dIUqOq5ROQBsA8AeRpqHi4uwwE1RrGWUVX7RPT3Kw3nTDgkKONXqOqDmelM8aJIZaYNTRJyqSfV"
    "mRmBggDAu/sL/e8j4hdXgmhtouBht9u9z8xM/n6AUhFlTVYrxnLEYkWogSEhZaH9211uqOouM/ut"
    "SGsMI/gykjxzrG8CcZ5F5C+J6BmtHCijlX3MCnoyDIJgdyZln87RsQDwwwN02BMR8fsJJKlmdk9V"
    "/U5oyP1TM4K8/naWZe+PxkldwU4qM7H+Zu9eu9vcnGxj5nXL1qgi/8HMDzjQMru/PDv1e52fnz9m"
    "dnb23WD28ECRAuJFAMywsF6XKk/KxKymP+r3+w+bm5vbdrCVfjZO2ZvZo1T1gwB0uIj2AaBQ9tX0"
    "MytcMzMwJCrK9zk8zC4q3qCqnweAzwHATjPrJue3PM/ROUcQ6IEBAJP3KGqBoFCz8D0KhFOhYtNb"
    "uJ0QlM0ZwBMMKJgtOWcs4y8YD7LMvPcU/pYhIoUiDAzveWYWEcmiy8rM6Jz7amiXxhNy2DdRHeeI"
    "6Lz3Ly6VffFeFbaowGRWxhrMzAXL/uPMfFnThnInHD9R1dcR0SGquggKGChPKVijlMiuC69MVYkI"
    "gCiTAC90iWi+bv465w7P8/wtANBT1RwSOu2oAAsKb0AiyBSAAz13twZlDBtvqgYEoApYZDoqgioC"
    "kRFQFqi64z0wFDywBACmAKagTEASPjMb7zNQimvxcV2XXENa/RzlHINcpT/vIaLfR8QbEu9vvxXL"
    "hg2wSRXfE6nGVRWIKKxJ8kQAgcqcqOAkr3PpbwCAfwpLnOEAZpIdwC5ZGtbujwHgV3q93ikZ4qUA"
    "8ATO+D7xKYiKCwVnNAkVOCKSqnpiOjbvdP5u165dvwwAu1aUXTNk4hAAQK/X+w0R65mZeeed9169"
    "8+q9FxFx3vu+995bbXjvvysif+O9f7KZ3euubDVZpH9d3nez8P/5ZiYi0hPvxXuvrpjnwcu5yu/i"
    "Rb33fSu++Lnbb799Y8ydvpPPJ96Zj39Xk9dR9SI/bXOZ6sbw+6yZnSsifysiexP9p94558Narqxb"
    "8a3r2Hv/qWuvvTYLFO0HZW6xyXUJlvkriehlBYNgaQ0rGCBnnNVcspsB4Muqeh0A/Gue5zfUS/SD"
    "crszWp3DE3/ddQBnnAGQUCQsZ+EhovT7/Qflef4pVV0fvBgajwMiYGD8VNV/2b2bzjv0UNy9lni3"
    "D8DiysbAjjYBLGmQZCgliwihITj4la98BU477bRxZGsWPounnXZa/VqGfr/uuuvwjDPOGAfMNVXz"
    "2YSfgzHzU/FuliofEyie+lwudY1Hz13vRLIZkYc0MeMEALhQVS8GgF+KcGGRxVjQqo0JsTtm7njv"
    "35bn+bMOOv1C3Pm3bds22+/3PxB2nEXvfF9VKxa8eL/be/9Z59xW59wjd+zYsbnpeGG3IpiOJoEB"
    "W1w8wYu/Ocy187Xdv8nCr1n2X7n99ts3pse8i1pV46qSJ6FuqCiwcZbrEmkhln0vSz3mcs89yXUc"
    "iOu/K8nchJ/jutdkZr8oIm8XkdsGOlNMAiLSvL69eC/R0n9hhHsPqrK/7bbbjhLxn26AaHre+2+I"
    "yFuccxfO2/wxTccInM/00+42T+IWmtmMiHypgMuca1X01ZcXkW5Q9t+an58/dn9hpbuCwl+qYhq3"
    "uJezuRxIpb+UY6ykwm+y/O/Kin+pRlzQf+W97927927e+6eLyKdT6Ns75733TkRSyEfEixcplH6v"
    "13tizdM9sJjm3r17T+33+7cFBd8X77/lnHuv9/4p3W735Ab4B8MN8lTBL2mhxWD23wRvqVdY7imu"
    "N6ToRcLuH5T9fy4sLBwPAHDllVfygbimES9cgsDv93EarimrvXiJxyi9zFQZhb/RpFZevL8GJTe0"
    "0CdUtlnLaznzhPup8NueGS3xeFR/VsuQo6We90DJXOMxlrO+UllJ3rufc+613vvvxXWsqiYi/WDI"
    "ifdevPNeRLyIdBcWFh52wA06M8vm5+fP6/f7N/b7/c/Mz8//7q5du37hhhtu6IyYlKmCX95c50HZ"
    "vyrxnIYseUkVvQwUvff+Ju/9C8xsTcE4B1Ie1iI0NcrSX66Ht9bgxf19tvuZvLBqnsHBfB5NG7KZ"
    "rTez8733V3vvF5O17QtDW0S8eFU17/3t3W733gdS6ePXvva1Y4499thfYOavHnrooTc1PMSYqmZ3"
    "8lS/1V5YGSJ67/1vMPO7VbVvBhmWLAHVbE0ElNCGEVT1h2b2Z8z8LkTcGRfq/gS6YoroLbfcsv6w"
    "ww67HxTpsQwA4FzBnpzn+Uy32/3+3Nzc90Z044pZsyc7547M89yBK/IkC9lxkOf5DAB8AxF3jsqN"
    "jn/btWvXoZs3bz7VOaeQ5wpFei7meW7OucVOp3P9JPdmZscAwP8CgK8j4u3J+zkAPBgA7git+8bm"
    "a3et+7MzMHMUFD0UPAwCuOsA4OcB4CZE3DbJ/YWfHwwAM1CkIapzjsL8fxkRF8cdJ/x4tPf+lF6v"
    "9x8bNmy4dal55/Hzi4uL92TmY/I8dwBA4CCDHGa63e735ubmvjtpX9m9e/ceuWFm5j4uzE9IrcY8"
    "zzsAsA0Rv9eSmlymEvf7/V/M8xwQ4cttvKXlc9y37+6u0zkZAFw8F4Sm9Ig4473fNkp209Hv938+"
    "z/P1AOCdcxZkrSMo+Ww2+9lxlOITbqyVQG+3271PlmWPB4DLmPmU+H4I9AoxzXjvv7l3797TDznk"
    "kD2wvGroiXCoKQ5/YJV9VKSPEpGu9955730IwFagG++cS6CbH3jvX2xmh9W8LDxA14T9bv+vbMRY"
    "XFx8ZJuFkVhmG0VkW9sxxMv2eA9t1x5lLgS8Wo/lnHvrOIsnWmze+0+Fe7hnjJuYGXnvLw1W1TNG"
    "4aQJ/HOIiNxU+85MWJxbw3WdMeq6Eshjo4hc2TpXIu8aZ3nHv4nI1WZm3W73Z5bqHSVz9OtmRep1"
    "Q+zuxzY/f/Qo6zsexzl3vpnd2nZbvV7vgW3XGN/rdrv3Due9esxcFvfv5aOjZLff7//8iHPG5zHn"
    "eu6tI45xeVNg9gBY/eU1XX/99blz7jEi8k7v/R3JuumGa/jHmABzQPTylVdeOYVpDrLLbGb39N5v"
    "D00efBKdV+ecxMybsOhv9t6/bNeuXYemHsKBfkZmRt1u93He+0u8908Wkd3e+Zuccxc4585fXFx8"
    "zDivpVio7uJw3X/qnDvLOXehc+5M59z53vsn9Pv908bBA3EBipdvicjtZnaOc+5sMzvTOXeOc+7c"
    "nveXmNkR4zaOaD2ZmYrIB+uf8d5/XkT2mNnmMcfKQjexpySY6/fNbHNYfOtF5FYR+Y9xME+cK+/9"
    "C8Njfqlz7rHe+0ucc+d57y8Pnv1Vkyi7BVs4zsx6IvKJ5Sh7M8Nut3vvAB180pw91jl3sZmd55y7"
    "yHu5LeSWHz0K1ko2xL0i8mNz9ngzd6aZPcY59xgze4yZnTpunsPc/F7YPB89wsiI6+l4EemLyGfN"
    "7Czn3MXOuYt6vd4l3vtL+/3+L08iu977Z5iZidkfmrMznXPnmtnjwho462DrhrqxMT8/f7Tv++d6"
    "7/+ttvH81YE0+Kbj4D1QNLMN3vuvxAI28VKkV4pUg7FebvXe/8Fes7sdTEXfNHq93gPNTPv9/hXL"
    "sBKvEZF+v99/2J49e44ws7ub2XGTYsFxYff7/Z8PG8cf7g90Fq7pcjOTfr//osXFxXt1u937LC7a"
    "iUEBmYgsxVO4VkR2e++/HSzQlwSr9qLw6H53lKeQbmje+//x3n+vYRN6aTjWw8Yo/CzM1e+Ga3nS"
    "uHOPmSMzs1+s/f3kUAj4tkmuxXv/hKCUfgcAYMeOHZv37dt3lJndzcyODgVKozZDDIR23xSRm6P3"
    "1NYYKJzz2UFeX7p3794jbd6OjpvTOJlLPNMZ7/3XRWR7t9s9eY/Z4WZ25Pz8/DH79u27+4GOT01g"
    "9Vfm2S26M1y//x7v/a3BU33dWo1zTZV9ErARkWsG2U+i3g1l3dzqvb9i3759R8XvX3vtyih6M+uY"
    "Gfb7/Q+Ymi3a4r3CdXcmUYaLi4v38s4vDEMv/odmtmmSzJoE8npHSEm7b/jeTJr1EdzakQVMMQNG"
    "RL7RDFOIBEVx+iSWdLfbPVlEVETebmYPD8/rll27dh0iIh83s978fJGm3LYQkw3tYeH7rw5zvC7M"
    "8zrv/Y9E5FvjLLjEE/q6mO3YtWvXIQk8MTbwmSi7We/9D733/2NmebiOOTNjEfm/NUiEx0BLnzaz"
    "RTM7cu9eO9L7ouo0WOC9Xq/3gBHQCgMALCwsnB6s+9eOg9nMLI8GVA06nF9cXDwhysuoOQj/H+e9"
    "l/pxYt2RH6RG8grrjcq179u376h+v/8M7/2X5ufnL1prgf/pSARWRF4flX0otU6zbu4QkddFa2Kl"
    "XbYkJfdu3su8d/7zk1oQiaX5srC432BmTzFvT/Xe/++FhVKhjjzWFVdcQQAAe/bsOdx7v+i9/9z+"
    "xkrM7PQi49V/yHv/6977p3vvn9Lv938nZEbdYHZ9PkaxZmETek1QRGcHy/LT4X4/JiIL3vt/mgBz"
    "jxva+0VEul27Tzr/zrlHBHl40RhlV9xf3wpPyORN+xFPelw453PTa9m2bdusiPzEi/8qjOjIlG6I"
    "BdTlPgAAYHvtSDN7Ur/ff56Zqff+usk2Q/fusNmfOgLOidd+Rrj2a8zsyd77p5vZ05xzj1jGPDzC"
    "e/+UXq/3G77vn+G9f7L3/kvhmT9mpRV+/Rrr5969e/d9VpI/fzqW5jI/KUm/TBX9DhF59cLCwnEr"
    "Dd00Xefi4uIzw2KbCB5IG487577pvb9jx44d9wgWeCfcyzozO3KSdo5hrp5lZr7b7T7PbPum3bt3"
    "H7bTdm4JePkWM1u/hEX89hDM/NmapXT/APO8cJwVGZWU9/57IvLDW265ZX3whB4SeKQkPMvLgmLM"
    "RinGHTt23ENE5p1zXzCzTQH6OtLMjojB18XFxXtNohydc683s3632z1n586dW8x2H2Zmm3fs2LHZ"
    "krjPKJhRvP+YiPT6/f5pO3fu3HL77bcfvcvsEO/9M8N9/fYkm49z7lVm5nq93pOCt3EEAGAMjPd6"
    "vae2HSfO8/bt2zc553Y65740BorhAD++2czc4uLimdFbMbPObbfdtmF+fv6YSRX0tm3bZm+55Zb1"
    "V145YAX49re/fYT3/kfOuf9eKUhnOVb/dKwdZR/d99MLC1C6RVfFUtG/3syOXw2LvmXxs3Pu2977"
    "+UDANgkswMG6O68l00QDJPCOCXDyuIivClaVeC9OpHz1vPeu3++Pw7Yxur/hOP8W7qUToaF+v3+t"
    "mVmCz9KY+7soKK0/jvAXAIDv+w+H57k9dM4aq6S63e7ZyfyUGVoRPnDO/cWYa8Jg4R3mnNsTjuPE"
    "F/9MZDEEqd8wwkKOcM6c9+77iefpRcRExIdiwC+GDWmS7JxYLS7OeYnPPhz7m2Z26Iiq5Whw/FaQ"
    "l2eO2xzM7Ki+c70UeqllcX0lwpSjrnt+fv7B/X7/J23ZOQsLC7+2mtb9OK98uWO6axxgBYqIsn37"
    "9mOR6P1ENAdQ8JB779/tnPuzdevW/SARJD3YDQ9GCQ4i6m233bZhy5YtHxCRG4444oi9E+Zyx1zy"
    "vvf+NQCgoMAa+sARkSppx8w+mH5+1LH6/f7Lieg/VTUjgswKwm0BAjWzxVtvvfXfAYouRG34PQAY"
    "M2/w3r/BzK4KOfcSOxeJyOcA4EMbNmy4ZUwrvXi9Pe/9q1T1HWGhqZnh7t27X7p+/fr/UdX/zLJs"
    "ZG1BvN6ZmZlPOueei4hHQ2y+piAiLkPmb+Z5/v8mmftOp7NZVd/qfb9HkBEQkKqSGoB6n/d6vXe2"
    "zXmYD0LExYWFhV/Pc3gMEQEU1NLRY9s+MzPz55s2bepNcj1m9jxVPdsAQNUyVUEqGiEtdLvdt23a"
    "tGnHiOPEvg0/8d6/ptfrfTS8P/SMt27digBg3W53Q5Zlf+K913Ddlhyr473/XJ7n/difou3ZZll2"
    "EiK+x/f7XSAqlLqqKUDeX+h/YuMhGz8TWziuJR0zrYVaQztvdJeDdWne++3B/b7HWrDoD7b1cGd6"
    "VmvtWGtt7u+q9zVdC9NxQAXEOfcBEek65/54cXHxhFTRxwDlGrz2bDmuawN3Sv1FB+pYS8U72zJC"
    "lnKfbTw5V1xxBS1nzgJOnC2XH6h2f/vFxTNmvvEAPTfcn3le5v3TAbhunmq06RgnPLxv374nd7vd"
    "v4rEZmvdop+O6ZiO6ZiOZYybbrpp7gc/+MFJNat5mis7HdMxHWtm/H+h5Iag3ukTtgAAAABJRU5E"
    "rkJggg=="
)


def _apply_wordmark(root, bg: str, pady=(28, 2)):
    """Show the real Sabr Technologies wordmark image above the install
    title, in place of a plain 'S A B R' text caption. Never fatal: a
    missing/broken image must not cost anyone an install — falls back to
    the old text label so the wizard still renders."""
    import tkinter as tk
    try:
        img = tk.PhotoImage(data=_SABR_WORDMARK_B64)
        lbl = tk.Label(root, image=img, bg=bg)
        lbl.image = img  # keep a ref on the widget too
        root._sabr_wordmark_ref = img  # and on root, or tk garbage-collects it
        lbl.pack(pady=pady)
        return lbl
    except Exception:
        lbl = tk.Label(root, text="S A B R", bg=bg, fg="#888888",
                        font=("Helvetica", 10))
        lbl.pack(pady=pady)
        return lbl


# ── themed buttons ────────────────────────────────────────────────────
# macOS Tk's "aqua" theme renders tk.Button (and ttk.Button in the default
# ttk theme) as a native NSButton — a light system-gray pill — and ignores
# bg=/activebackground= entirely. fg= is honored, so every dark-on-dark
# Sabr button (bg="#1a1a1a", fg="#ffffff" or a red verb color) rendered as
# near-white text on the OS's native light button face: unreadable.
# Windows and Linux Tk builds have no such native override — bg/fg apply
# literally there, which is why this shipped invisibly for months of
# Windows/Linux installs and only broke on Kyle's Mac (2026-08-25).
#
# Fix: stop using the native Button widget for anything in the Sabr theme.
# tk.Label has no aqua "native control" substitution on any platform —
# bg/fg always apply as given — so it is used here as the button, with
# click/hover/disabled behaviour wired up by hand. This runs on every
# platform (not just IS_MAC) so there is exactly one code path to keep
# correct, and it reproduces the same colors Windows/Linux already had
# (Label honors the identical bg/fg tk.Button was asked for), so the
# all-black Sabr theme there is pixel-identical, not just "close enough."
#
# Built as a factory FUNCTION, not a module-level class: every tkinter
# import in this file is lazy (`import tkinter as tk` inside each GUI
# function) so the installer can run --no-gui / headless on a box with no
# Tk libs at all. A module-level `class _ClickButton(tk.Label)` would
# resolve `tk` at module-import time and crash headless runs immediately.
def _mk_click_button(parent, text, command=None, bg="#1a1a1a", fg="#ffffff",
                      activebackground=None, activeforeground=None,
                      font=("Helvetica", 11, "bold"), padx=24, pady=8,
                      width=None, cursor="hand2"):
    """A button-shaped, clickable Label — the macOS-safe replacement for
    tk.Button in this installer. Supports the subset of the Button API the
    installer actually uses: bg/fg/activebackground/activeforeground/font/
    padx/pady/width/cursor, plus .config(state="normal"|"disabled")."""
    import tkinter as tk

    class _ClickButton(tk.Label):
        def __init__(self):
            self._bg = bg
            self._fg = fg
            self._activebg = activebackground or bg
            self._activefg = activeforeground or fg
            self._disabled_bg = "#0d0d0d"
            self._disabled_fg = "#555555"
            self._normal_cursor = cursor
            self._command = command
            self._tk_state = "normal"
            kwargs = dict(text=text, bg=bg, fg=fg, font=font, padx=padx,
                          pady=pady, cursor=cursor, relief="flat", bd=0)
            if width is not None:
                kwargs["width"] = width
            super().__init__(parent, **kwargs)
            self.bind("<Button-1>", self._on_click)
            self.bind("<Enter>", self._on_enter)
            self.bind("<Leave>", self._on_leave)

        def _on_click(self, _evt=None):
            if self._tk_state == "disabled":
                return
            if self._command:
                self._command()

        def _on_enter(self, _evt=None):
            if self._tk_state == "disabled":
                return
            tk.Label.configure(self, bg=self._activebg, fg=self._activefg)

        def _on_leave(self, _evt=None):
            if self._tk_state == "disabled":
                return
            tk.Label.configure(self, bg=self._bg, fg=self._fg)

        def config(self, **kwargs):
            if "state" in kwargs:
                self._tk_state = kwargs.pop("state")
                if self._tk_state == "disabled":
                    tk.Label.configure(self, bg=self._disabled_bg,
                                        fg=self._disabled_fg, cursor="arrow")
                else:
                    tk.Label.configure(self, bg=self._bg, fg=self._fg,
                                        cursor=self._normal_cursor)
            if kwargs:
                tk.Label.configure(self, **kwargs)

        configure = config

    return _ClickButton()


# ── install log ────────────────────────────────────────────────────────
# Opened before ANY step can fail, so a failure always has a paper trail
# on the customer's disk. A frozen GUI has no console: without this, the
# only evidence of a broken install is one truncated line in a tk label.
_LOG_FH = None
_LOG_PATH = None


def _timestamp() -> str:
    import time
    return time.strftime("%Y%m%d-%H%M%S")


def _log_open(dest: str) -> str:
    """Open the install log. Never raises — logging must not break installs."""
    global _LOG_FH, _LOG_PATH
    for candidate in (dest, tempfile.gettempdir()):
        try:
            os.makedirs(candidate, exist_ok=True)
            path = os.path.join(candidate, "sabr-install.log")
            fh = open(path, "a", encoding="utf-8", errors="replace")
            _LOG_FH, _LOG_PATH = fh, path
            fh.write(f"\n===== install start | {sys.platform} | "
                     f"frozen={getattr(sys, 'frozen', False)} | dest={dest} =====\n")
            fh.flush()
            return path
        except Exception:
            continue
    return ""


def _log(msg: str) -> None:
    _stream_push(msg)
    if _LOG_FH is None:
        return
    try:
        _LOG_FH.write(str(msg).rstrip() + "\n")
        _LOG_FH.flush()
    except Exception:
        pass


# ── live install streaming (opt-in) ────────────────────────────────────
# The same lines that go to sabr-install.log, mirrored to the server so a
# failed install on someone else's machine is READABLE instead of being a
# screenshot request. Off unless the customer turns it on.
#
# Deliberate non-features: this opens no port, accepts nothing back, and runs
# no code from the server. It is one-way append-only text. If every upload
# fails the install proceeds identically — _stream_push cannot raise, and the
# worker thread is a daemon so it can never hold the process open.
_STREAM_ON = False
_STREAM_ID = ""
_STREAM_Q: "list" = []
_STREAM_LOCK = threading.Lock()
_STREAM_META: dict = {}


def _stream_enable(si_name: str = "", version: str = "") -> str:
    """Turn on live streaming and return the install id to show the customer."""
    global _STREAM_ON, _STREAM_ID
    if _STREAM_ON:
        return _STREAM_ID
    _STREAM_ID = "%s-%s" % (_timestamp(), os.urandom(3).hex())
    _STREAM_META.update({"platform": "%s %s" % (platform.system(), platform.release()),
                         "si_name": si_name, "version": version})
    _STREAM_ON = True
    t = threading.Thread(target=_stream_worker, daemon=True)
    t.start()
    import atexit
    atexit.register(_stream_flush)
    return _STREAM_ID


def _stream_push(msg) -> None:
    if not _STREAM_ON:
        return
    try:
        with _STREAM_LOCK:
            if len(_STREAM_Q) < 5000:      # bounded: never grow without limit
                _STREAM_Q.append(str(msg).rstrip())
    except Exception:
        pass


def _stream_worker() -> None:
    import urllib.request
    url = ONBOARDING_URL.rstrip("/") + "/api/onboarding/install-log"
    first = True
    while True:
        time.sleep(2.0)
        with _STREAM_LOCK:
            batch, _STREAM_Q[:] = list(_STREAM_Q), []
        if not batch:
            continue
        body = {"install_id": _STREAM_ID, "lines": batch}
        if first:
            body.update(_STREAM_META)
        try:
            req = urllib.request.Request(
                url, data=json.dumps(body).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=10).read()
            first = False
        except Exception:
            pass                            # a dropped batch is not an error


def _stream_flush() -> None:
    """Push whatever is still queued, right now, synchronously.

    The worker sleeps 2s between batches, so a process that dies quickly —
    which is EXACTLY what a failing install does — took its last and most
    diagnostic lines to the grave. Registered with atexit so the tail of a
    crash always reaches the viewer. Silent by construction: a support
    feature must never be the thing that breaks the install.
    """
    if not _STREAM_ON:
        return
    import urllib.request
    with _STREAM_LOCK:
        batch, _STREAM_Q[:] = list(_STREAM_Q), []
    if not batch:
        return
    body = {"install_id": _STREAM_ID, "lines": batch}
    body.update(_STREAM_META)
    try:
        req = urllib.request.Request(
            ONBOARDING_URL.rstrip("/") + "/api/onboarding/install-log",
            data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=10).read()
    except Exception:
        pass


# ── install telemetry (per-step phone home) ────────────────────────────
#
# WHAT AND WHY. Six steps, three outcomes, one tiny POST each. The live
# stream above answers "what went wrong on THIS machine" for one customer a
# support engineer is already talking to. This answers the question nobody
# can currently answer at all: which step fails, on which platform, on which
# build, across every install — the difference between "a few people said it
# didn't work" and "the venv step fails on 40% of Windows 11 boxes since
# build 214". Free text cannot be counted; six enum values can.
#
# THE RULES, in the order they matter:
#
#   1. IT MUST NEVER BLOCK. telemetry_event() appends to a bounded list and
#      returns. All network I/O happens on a daemon thread with a 3s
#      timeout. A server that is down, slow, black-holing packets, or
#      returning 500s costs the install exactly nothing — measured, not
#      asserted: tests/test_install_telemetry_client.py hangs the transport
#      for 30 seconds and pins that the caller returns in milliseconds.
#
#   2. IT MUST NEVER FAIL AN INSTALL. Every function here swallows every
#      exception, and _telemetry_step.__exit__ returns False so it can never
#      absorb an InstallError on its way out.
#
#   3. NO PII. platform, arch, python major.minor, installer build, step,
#      status, exception CLASS name, duration, crash verdict. That is all,
#      and _telemetry_payload builds it field by field from an allowlist
#      rather than passing a caller's dict through. str(exception) is
#      unreachable from here on purpose: our exception messages routinely
#      embed the customer's home directory (_log_hint literally appends a
#      path to them).
#
# The run id is random per PROCESS and never written to disk, so it groups
# one run's six steps and identifies nothing and nobody. Deliberately NOT
# _STREAM_ID, which is timestamp-prefixed and is shown to the customer to
# quote at support — reusing it would tie an anonymous aggregate row to a
# support conversation.

TELEMETRY_URL = os.environ.get(
    "SABR_TELEMETRY_URL",
    ONBOARDING_URL.rstrip("/") + "/api/telemetry/install-event")

#: The contract. server/routers/install_telemetry_routes.py holds the same
#: tuple and rejects anything outside it; a test pins the two together.
TELEMETRY_STEPS = ("download", "extract", "venv", "deps",
                   "service_setup", "first_boot")
TELEMETRY_STATUSES = ("ok", "fail")

#: Short on purpose. Three seconds is longer than a healthy POST of ~200
#: bytes ever takes and shorter than a customer notices, and it is a
#: ceiling on a DAEMON thread that nothing waits for anyway.
_TELEMETRY_TIMEOUT = 3.0

#: Six steps make six events. A queue an order of magnitude larger than the
#: protocol can produce means a wedged worker drops events instead of
#: growing a list forever on a box that is already having a bad day.
_TELEMETRY_MAX_QUEUE = 64

#: Total seconds atexit may spend pushing the tail. An install ends with
#: first_boot, which is the single most valuable event and the one most
#: likely to be still in flight when the process exits — but a customer
#: closing the window must not wait on our analytics, so this is a hard
#: ceiling, not a "flush until done".
_TELEMETRY_EXIT_BUDGET = 2.0

_TELEM_Q: "list" = []
_TELEM_LOCK = threading.Lock()
_TELEM_STARTED = False
_TELEM_RUN_ID = ""
#: Test seam and log line: how many events actually reached the transport.
_TELEM_SENT = 0


def _telemetry_enabled() -> bool:
    """Off with SABR_TELEMETRY=0, and off if the endpoint was blanked.

    Same shape of opt-out as SABR_STREAM_INSTALL=0 above, so there is one
    thing to tell a customer who objects to either.
    """
    if (os.environ.get("SABR_TELEMETRY") or "").strip() == "0":
        return False
    return bool(TELEMETRY_URL.strip())


def _telemetry_run_id() -> str:
    """Anonymous, per-process, never persisted."""
    global _TELEM_RUN_ID
    if not _TELEM_RUN_ID:
        _TELEM_RUN_ID = os.urandom(8).hex()
    return _TELEM_RUN_ID


def _error_class(error) -> str:
    """An exception CLASS name, or "". Never a message.

    Accepts an exception, a class, or a string. The identifier check is not
    decoration: it is the last line of defence if a caller ever hands this a
    formatted message, and a message will contain a path.
    """
    if error is None:
        return ""
    if isinstance(error, BaseException):
        name = type(error).__name__
    elif isinstance(error, type):
        name = error.__name__
    else:
        name = str(error)
    name = name.strip()
    if not name or len(name) > 64:
        return ""
    if not (name[0].isalpha() or name[0] == "_"):
        return ""
    return name if all(c.isalnum() or c in "_." for c in name) else ""


def _telemetry_payload(step: str, status: str, error_class: str = "",
                       duration_ms: int = 0, crash=None) -> dict:
    """Build one event. Field by field — no caller dict is ever forwarded.

    This function IS the privacy boundary. Adding a parameter here is the
    only way to add a field to what leaves a customer's machine, which is
    exactly the friction that should exist.
    """
    body = {
        "schema": 1,
        "run_id": _telemetry_run_id(),
        "step": str(step),
        "status": str(status),
        "error_class": _error_class(error_class),
        # platform.system()/release() only: "Windows 11", "Darwin 23.5.0".
        # NOT platform.node(), which is the machine's name and on a Mac is
        # routinely the owner's full name.
        "platform": ("%s %s" % (platform.system(), platform.release()))[:64],
        "arch": str(platform.machine())[:32],
        # Major.minor. The patch level narrows a population to a handful of
        # machines and diagnoses nothing that "3.12" does not.
        "py": "%d.%d" % (sys.version_info[0], sys.version_info[1]),
        "version": str(INSTALLER_BUILD)[:40],
        "duration_ms": int(max(0, duration_ms)),
    }
    if isinstance(crash, dict) and crash.get("verdict"):
        body["crash"] = crash
    return body


def _telemetry_post(body: dict) -> None:
    """The transport, and nothing else.

    Its own function so tests can replace it with something that hangs, or
    raises, and prove neither reaches the install.
    """
    req = urllib.request.Request(
        TELEMETRY_URL, data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    urllib.request.urlopen(req, timeout=_TELEMETRY_TIMEOUT).read()


def _telemetry_drain() -> int:
    """Send everything queued right now. Returns how many were sent.

    Each event is posted independently: one failure must not discard the
    five events behind it, and the failing one is dropped rather than
    retried — a retry loop against an unreachable server is how a
    best-effort feature turns into a hang.
    """
    global _TELEM_SENT
    with _TELEM_LOCK:
        batch, _TELEM_Q[:] = list(_TELEM_Q), []
    sent = 0
    for body in batch:
        try:
            _telemetry_post(body)
            sent += 1
            _TELEM_SENT += 1
        except Exception:
            pass
    return sent


def _telemetry_worker() -> None:
    while True:
        time.sleep(1.0)
        try:
            _telemetry_drain()
        except Exception:
            pass


def _telemetry_start() -> None:
    global _TELEM_STARTED
    if _TELEM_STARTED:
        return
    _TELEM_STARTED = True
    try:
        threading.Thread(target=_telemetry_worker, daemon=True).start()
        import atexit
        atexit.register(_telemetry_flush)
    except Exception:
        pass


def _telemetry_flush(budget: float = _TELEMETRY_EXIT_BUDGET) -> None:
    """Push the tail at exit, inside a hard time budget.

    Runs after the install is finished by definition (atexit), so this is
    the one place a moment of waiting is acceptable — and even here it is
    capped, and every failure is silent.
    """
    deadline = time.time() + max(0.0, budget)
    try:
        while time.time() < deadline:
            with _TELEM_LOCK:
                pending = len(_TELEM_Q)
            if not pending:
                return
            if not _telemetry_drain():
                return          # transport is down; do not spend the budget
    except Exception:
        pass


def telemetry_event(step: str, status: str, error=None, error_class: str = "",
                    duration_ms: int = 0, crash=None) -> None:
    """Record one install step. Returns immediately. Cannot raise.

    `error` takes an exception object; only its class name is kept.
    """
    try:
        if not _telemetry_enabled():
            return
        if step not in TELEMETRY_STEPS or status not in TELEMETRY_STATUSES:
            return
        body = _telemetry_payload(
            step, status,
            error_class=error_class or _error_class(error),
            duration_ms=duration_ms, crash=crash)
        with _TELEM_LOCK:
            if len(_TELEM_Q) >= _TELEMETRY_MAX_QUEUE:
                return
            _TELEM_Q.append(body)
        _telemetry_start()
    except Exception:
        pass                    # telemetry NEVER surfaces to the caller


class _telemetry_step:
    """Context manager: time a step and report ok / fail.

    Deliberately never swallows: __exit__ returns False, so an InstallError
    passing through is re-raised untouched and the customer-facing failure
    path is exactly what it was before telemetry existed.
    """

    def __init__(self, step: str, crash=None):
        self.step = step
        self.crash = crash
        self.t0 = 0.0
        self._forced = ""

    def fail(self, error_class: str) -> None:
        """Mark a failure that is NOT an exception — e.g. the SI simply
        never started answering, which Installer.run() reports by returning,
        not by raising."""
        self._forced = error_class

    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, exc_type, exc, tb):
        ms = int((time.time() - self.t0) * 1000)
        if exc is not None:
            telemetry_event(self.step, "fail", error=exc,
                            duration_ms=ms, crash=self.crash)
        elif self._forced:
            telemetry_event(self.step, "fail", error_class=self._forced,
                            duration_ms=ms, crash=self.crash)
        else:
            telemetry_event(self.step, "ok", duration_ms=ms, crash=self.crash)
        return False


# ── crash signal from an install already on this machine ───────────────

#: Written by brain/crash_watch.py on the INSTALLED SI. Read here as pure
#: JSON data — the frozen installer imports no module from the payload it
#: downloaded, the same rule the live streamer states about the server.
_WATCHDOG_REL = ("brain_state", "boot-watchdog.json")

_CRASH_VERDICTS = ("healthy", "restart_loop", "fatal_boot_error", "unknown")


def _crash_signal(dest: str):
    """The crash verdict for the install at `dest`, or None.

    None on a fresh box (no payload, so nothing has crashed), on an install
    running a payload older than crash_watch, and on anything unreadable.
    None is not "healthy" — an install we cannot see is not an install we
    can vouch for.

    Re-validated here rather than trusted: this file sits in a directory the
    customer can write to, and its contents are about to be posted to our
    server. Only known verdicts and bounded integers survive.
    """
    try:
        path = os.path.join(dest, *_WATCHDOG_REL)
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        sig = data.get("signal") if isinstance(data, dict) else None
        if not isinstance(sig, dict):
            return None
        if sig.get("verdict") not in _CRASH_VERDICTS:
            return None
        out = {"verdict": sig["verdict"]}
        for key in ("boots_in_window", "failed_boots", "restarts"):
            val = sig.get(key)
            if isinstance(val, int) and not isinstance(val, bool) and 0 <= val <= 100000:
                out[key] = val
        cls = _error_class(sig.get("last_error_class") or "")
        if cls:
            out["last_error_class"] = cls
        return out
    except Exception:
        return None


def _log_hint() -> str:
    return f" Full log: {_LOG_PATH}" if _LOG_PATH else ""


#: Loader variables PyInstaller points at its own unpack dir so OUR bundled
#: libraries win inside the frozen process. They must never reach a shelled-out
#: system interpreter.
_LOADER_VARS = ("LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH", "DYLD_INSERT_LIBRARIES")


def _clean_env() -> dict:
    """The environment a child process should get: ours, minus the bundle.

    The frozen binary runs with LD_LIBRARY_PATH (DYLD_* on macOS) pointing at
    its PyInstaller unpack dir. Every subprocess inherited that, so the system
    python we shell out to loaded OUR OpenSSL instead of its own. On any
    machine whose OpenSSL is newer than the build runner's, that makes
    `import ssl` fail with

        ImportError: .../libcrypto.so.3: version `OPENSSL_3.3.0' not found
                     (required by .../_ssl.cpython-3xx.so)

    and with no ssl the venv build, ensurepip, get-pip and `pip install` all
    die in a row — the whole install, on a machine with nothing wrong with it.
    Ubuntu 24.04 matches the runner, which is exactly why this survived
    testing. PyInstaller stashes the caller's real values as <VAR>_ORIG for
    this purpose, so put those back where they exist and drop the var where
    they do not.
    """
    env = os.environ.copy()
    # Children get UTF-8 mode too: pip, venv and the SI all do text I/O
    # on a machine whose codepage we do not control.
    env["PYTHONUTF8"] = "1"
    for var in _LOADER_VARS:
        original = env.pop(var + "_ORIG", None)
        if original:
            env[var] = original
        else:
            env.pop(var, None)
    return env


def _run(argv, what: str, check: bool = True, timeout: int = 1800):
    """Run a subprocess, log everything, and fail with a READABLE message.

    subprocess.CalledProcessError stringifies to "Command [...] returned
    non-zero exit status 2" and throws the stderr away — which is exactly
    the useless error a customer pasted back to us. Never again: the real
    stderr goes in the message and in the log."""
    _log(f"$ {' '.join(str(a) for a in argv)}")
    try:
        r = subprocess.run(argv, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace",
                           env=_clean_env())
    except FileNotFoundError:
        raise InstallError(f"{what} failed: {argv[0]} not found on this machine."
                           + _log_hint())
    except subprocess.TimeoutExpired:
        raise InstallError(f"{what} timed out after {timeout // 60} minutes."
                           + _log_hint())
    if r.stdout:
        _log(r.stdout[-4000:])
    if r.stderr:
        _log("stderr: " + r.stderr[-4000:])
    _log(f"-> exit {r.returncode}")
    if check and r.returncode != 0:
        detail = (r.stderr or r.stdout or "").strip().splitlines()
        tail = " | ".join(detail[-3:])[:400] or f"exit status {r.returncode}"
        raise InstallError(f"{what} failed: {tail}" + _log_hint())
    return r


def _run_best_effort(argv, what: str, timeout: int = 120) -> bool:
    """Run a command that may not exist on this machine. Never raises.

    check=False IS NOT ENOUGH, and the difference has bitten us.
    check=False suppresses a non-zero EXIT CODE — it says nothing about a
    binary that is not there at all. subprocess.run raises FileNotFoundError
    (an OSError) before the child ever exists, straight past check=False.

    Found 2026-08-26 by the Linux virgin-test agent: run_uninstall() called

        subprocess.run(["systemctl", "--user", "stop", ...], check=False)

    with nothing around it, so on any box without systemd — a non-systemd
    distro, a minimal container, a chroot — UNINSTALL DIED with an uncaught
    FileNotFoundError. Not "could not stop the service": the whole function
    aborted at its second statement, before _stop_linux_si's executable-
    scoped kill, before autostart removal, before the archive, before the
    rmtree. The customer could not remove us at all, and the traceback
    named systemctl, which is not a thing they have or want.

    The UPDATE path (_stop_si_before_overwrite) already wrapped its
    equivalent calls in `except (OSError, subprocess.SubprocessError)` and
    degraded correctly. This is that same guard, factored out so the two
    paths cannot drift apart again.

    Returns True if the command ran at all (whatever it exited with), False
    if it could not be run — so a caller can fall through to another
    mechanism instead of assuming the stop worked.
    """
    try:
        subprocess.run(argv, check=False, capture_output=True,
                       timeout=timeout, env=_clean_env())
        return True
    except (OSError, subprocess.SubprocessError) as e:
        # Not progress() — an absent systemctl is expected on a machine that
        # never had one, and telling a customer about it during an uninstall
        # that is otherwise working would be noise dressed as a problem.
        _log(f"[warn] {what}: {type(e).__name__}: {e}")
        return False


def _is_pip_cache_permission_error(stdout: str, stderr: str) -> bool:
    """True when pip died because its wheel cache is unreadable/unwritable.

    Module level so the regression test can hit it with the exact stderr a
    real customer produced, without spinning up a venv.
    """
    blob = ((stderr or "") + (stdout or "")).lower()
    if "permission denied" not in blob and "errno 13" not in blob:
        return False
    return ("pip\\cache" in blob or "pip/cache" in blob
            or "\\wheels\\" in blob or "/wheels/" in blob)


def _ssl_context():
    """TLS context that works inside a PyInstaller-frozen binary.

    Frozen Python doesn't inherit the build machine's CA paths, so the
    default context fails cert verification on many customer machines.
    certifi is bundled by the packaging CI; fall back to the system
    default when running from source without it."""
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _urlopen(url, timeout: float):
    """url may be a str or a urllib.request.Request (for auth headers)."""
    return urllib.request.urlopen(url, timeout=timeout, context=_ssl_context())


def _safe_extractall(tar, dest: str) -> None:
    """extractall for interpreters with no tarfile filter support.

    Mirrors what filter="data" enforces: every member must land strictly
    inside dest, and no links (a symlink pointing at /etc/passwd followed by
    a write through it escapes just as effectively as a ../ path).
    """
    dest_real = os.path.realpath(dest)
    for m in tar.getmembers():
        if m.issym() or m.islnk():
            raise InstallError("The SI archive contains a link entry and was "
                               "rejected. Nothing was installed.")
        target = os.path.realpath(os.path.join(dest_real, m.name))
        if target != dest_real and not target.startswith(dest_real + os.sep):
            raise InstallError("The SI archive tried to write outside the "
                               "install folder and was rejected. Nothing was "
                               "installed.")
    tar.extractall(dest)


def _replace_with_retries(src: str, dst: str, what: str,
                          attempts: int = 5) -> None:
    """os.replace that rides out the locks a wait can actually fix.

    Windows is the reason this exists: antivirus real-time scanning holds a
    handle on freshly-extracted files for a moment, Search indexing does the
    same to anything new, and a process that was just killed releases its
    handles asynchronously. All of those clear within seconds — so a rename
    that fails with a sharing violation (WinError 32) or access denied
    (WinError 5) gets a few patient retries before it is believed.

    Everything else (missing source, cross-device, bad path) raises
    immediately — waiting cannot fix those, and pretending it might just
    buries the real error under ten seconds of sleep.

    On final failure this raises InstallError with the one instruction that
    actually helps (close the program / reboot, run the update again), and
    the caller (_swap_payload) rolls the tree back — so the message's claim
    that nothing was lost is kept true by construction.
    """
    delay = 0.5
    last = None
    for attempt in range(attempts):
        try:
            os.replace(src, dst)
            return
        except PermissionError as e:
            last = e
        except OSError as e:
            if getattr(e, "winerror", None) not in (5, 32, 33):
                raise
            last = e
        if attempt < attempts - 1:
            _log(f"{what}: locked ({last}); retrying in {delay:.1f}s")
            time.sleep(delay)
            delay = min(delay * 2, 4.0)
    raise InstallError(
        f"{what} was blocked: another program is holding those files open "
        f"(usually your SI still running, an antivirus scan, or a file "
        f"open in another window). Your existing install has been left in "
        f"place, unchanged. Close other programs — or restart this "
        f"computer — and run the update again. ({last})" + _log_hint())


def _ensure_writable_dir(path: str) -> None:
    """Create the install directory, or fail with something a customer can act
    on. os.makedirs raised OSError straight out of download_release, past
    main()'s `except InstallError`, so --no-gui printed a raw traceback and a
    PyInstaller "Failed to execute script" line. (The GUI caught it as
    "Unexpected error", so this only ever bit the CLI path.)"""
    try:
        os.makedirs(path, exist_ok=True)
    except OSError as e:
        raise InstallError(
            f"Can't create the install folder at {path} ({e.strerror}). "
            f"Choose a folder you own with --dest, or free up the permissions "
            f"on that path, then run this again." + _log_hint())
    if not os.access(path, os.W_OK):
        raise InstallError(
            f"The install folder {path} isn't writable by this account. "
            f"Choose a folder you own with --dest, then run this again."
            + _log_hint())


def _find_system_python(progress=None) -> str:
    """A REAL python interpreter to build the body's venv with.

    When we're a frozen PyInstaller binary, sys.executable is this .exe — not
    a Python — so `sys.executable -m venv` cannot work. Find a genuine system
    Python instead. Running from source, sys.executable already is one.

    NO PYTHON IS NOT A DEAD END ANY MORE (2026-08-12). This used to raise and
    tell the customer to go install Python from python.org themselves —
    measured on Aiden's Windows box, which is a completely stock machine and
    therefore the EXACT machine this product has to work on. A person who
    just paid for a mind should never be handed a homework assignment. So
    when nothing usable is found we now fetch and install a known-good
    Python ourselves, then probe again. The old message survives only as the
    last resort after our own attempt also fails."""
    if not getattr(sys, "frozen", False):
        return sys.executable
    say = progress or (lambda *_a, **_k: None)
    found, rejected = _probe_system_python()
    if found:
        return found
    _log("no usable python: " + "; ".join(rejected))
    if _autoinstall_python(say):
        found, rejected2 = _probe_system_python()
        if found:
            _log("python autoinstall succeeded")
            return found
        rejected = rejected + ["after auto-install: " + "; ".join(rejected2)]
        _log("python autoinstall ran but probe still failed")
    raise _no_python_error(rejected)


def _current_user_sid() -> str:
    """This account's SID, e.g. S-1-5-21-...-1003, or "" if unavailable.

    Granting by NAME is unsafe on Windows: on a machine whose COMPUTERNAME
    equals the USERNAME (the default when someone names their PC after
    themselves), a name can resolve to the machine account SID with no RID.
    icacls then reports "Successfully processed N files" having granted
    rights to a principal the user is not a member of, and nothing errors.
    """
    if not IS_WINDOWS:
        return ""
    try:
        r = subprocess.run(["whoami", "/user", "/fo", "csv", "/nh"],
                           capture_output=True, text=True, timeout=30,
                           encoding="utf-8", errors="replace",
                           env=_clean_env())
        parts = (r.stdout or "").strip().strip('"').split('","')
        sid = parts[-1].strip('"').strip() if parts else ""
        return "*" + sid if sid.startswith("S-1-") else ""
    except Exception as e:
        _log(f"could not read current user SID: {e}")
        return ""


def _registry_pythons() -> list:
    """PEP 514 registrations, newest first, across both WOW64 views.

    This is the canonical place a python.org install registers itself, and
    it is how you find one where the user unticked "Add python.exe to PATH"
    — far and away the most common Python-on-Windows support ticket there is.
    """
    if not IS_WINDOWS:
        return []
    try:
        import winreg
    except ImportError:
        return []
    found = []
    views = ((winreg.HKEY_CURRENT_USER, 0),
             (winreg.HKEY_LOCAL_MACHINE, getattr(winreg, "KEY_WOW64_64KEY", 0)),
             (winreg.HKEY_LOCAL_MACHINE, getattr(winreg, "KEY_WOW64_32KEY", 0)))
    for hive, flag in views:
        try:
            root = winreg.OpenKey(hive, r"Software\Python\PythonCore", 0,
                                  winreg.KEY_READ | flag)
        except OSError:
            continue
        with root:
            try:
                count = winreg.QueryInfoKey(root)[0]
            except OSError:
                continue
            for i in range(count):
                try:
                    tag = winreg.EnumKey(root, i)
                    with winreg.OpenKey(root, tag + r"\InstallPath") as k:
                        path, _ = winreg.QueryValueEx(k, None)
                    exe = os.path.join(path, "python.exe")
                    if os.path.isfile(exe):
                        found.append((tag, exe))
                except OSError:
                    continue

    # ORDER BY PY_PREFERRED, NOT BY NEWEST. Sorting newest-first here reopens
    # the exact outage PY_PREFERRED exists to prevent: caught in test on
    # 2026-08-12, this returned 3.14 ahead of 3.12 on a machine that had
    # both, and 3.14 has no wheels for pyaudio/webrtcvad — pip falls back to
    # compiling C, hits the missing MSVC toolchain, and the install dies far
    # away from the real cause. Anything outside the known-good set sorts
    # last: usable as a last resort, never the first pick.
    def rank(item):
        try:
            parts = tuple(int(x) for x in item[0].split("-")[0].split("."))
        except Exception:
            return (2, (0,))
        minor = parts[1] if len(parts) > 1 else 0
        if minor in PY_PREFERRED:
            return (0, PY_PREFERRED.index(minor))
        return (1, -minor)

    found.sort(key=rank)
    return [[exe] for _, exe in found]


def _uv_pythons() -> list:
    """Interpreters uv manages. uv installs REAL Pythons and no py launcher,
    so a uv-only machine looks empty to a PATH-name search while holding
    three perfectly good interpreters."""
    uv = shutil.which("uv")
    if not uv:
        return []
    out = []
    for m in PY_PREFERRED:
        try:
            r = subprocess.run([uv, "python", "find", f"3.{m}"],
                               capture_output=True, text=True, timeout=25,
                               encoding="utf-8", errors="replace",
                               env=_clean_env())
            p = (r.stdout or "").strip()
            if r.returncode == 0 and p and os.path.isfile(p):
                out.append([p])
        except Exception:
            continue
    return out


def _probe_system_python():
    """Look for a usable interpreter. Returns (path_or_empty, reasons)."""
    import shutil
    # PREFER A PYTHON THE WHEEL ECOSYSTEM HAS CAUGHT UP TO (2026-08-10).
    #
    # `py -3` and a bare `python3` both mean "the NEWEST Python installed".
    # On a real customer box that resolved to 3.14, and 3.14 is far enough
    # ahead of the ecosystem that pyaudio, webrtcvad and friends ship no
    # wheels for it — so pip fell back to compiling C, hit the missing MSVC
    # toolchain, and took the whole install down. There was a version FLOOR
    # and no CEILING, so the installer was actively seeking out the most
    # bleeding-edge interpreter on the machine: the worst possible choice.
    #
    # So: ask for known-good versions NEWEST-FIRST, and only fall back to
    # "whatever's newest" if none of them exist. Same trap waits on macOS,
    # where `brew install python` also tracks the newest release — which is
    # why the preference list is applied on every OS, not just Windows.
    candidates = []
    if IS_WINDOWS:
        # The py launcher ships with python.org installs ONLY. Probing it and
        # two bare names was the whole Windows search, so a machine with uv /
        # pyenv-win / conda / Scoop interpreters reported "no Python" while
        # holding four working ones (measured on Aiden's box 2026-08-12,
        # where the identical "py: not on PATH" line appeared four times
        # because all four py candidates collapse to one PATH lookup).
        if shutil.which("py"):
            candidates += [["py", f"-3.{m}"] for m in PY_PREFERRED]
            candidates += [["py", "-3"]]
        # Versioned names on PATH. POSIX always did this; Windows never did,
        # and uv's own shim is named exactly python3.12.exe.
        candidates += [[f"python3.{m}"] for m in PY_PREFERRED]
        candidates += [["python"], ["python3"]]
        candidates += _registry_pythons()
        candidates += _uv_pythons()
        # A python.org install we just performed ourselves is NOT on this
        # process's PATH — Windows hands a process its environment at spawn
        # and never updates it. Without these absolute paths the auto-install
        # would succeed and the very next probe would still say "not on
        # PATH", which is the most infuriating possible failure: we fixed it
        # and then told the customer we hadn't.
        for root in (os.environ.get("LOCALAPPDATA", ""),
                     os.environ.get("ProgramFiles", "")):
            if not root:
                continue
            for m in PY_PREFERRED:
                candidates.append([os.path.join(
                    root, "Programs", "Python", f"Python3{m}", "python.exe")])
                candidates.append([os.path.join(
                    root, f"Python3{m}", "python.exe")])
    else:
        candidates += [[f"python3.{m}"] for m in PY_PREFERRED]
        bare = [["python3"], ["python"]]
        if IS_MAC:
            # /usr/bin/python3 on a Mac WITHOUT the Xcode Command Line Tools
            # is Apple's xcrun stub, and the probe below EXECUTES its
            # candidates — running the stub from a GUI app makes macOS pop
            # its own modal "install the command line developer tools?"
            # dialog in the middle of the install, an Apple quiz inside a
            # product sold as double-click-and-done. The versioned python3.X
            # names above are only ever real installs (brew / python.org),
            # so when xcode-select says there is no CLT, skip just the bare
            # names; the standalone-interpreter path already covers a Mac
            # with no Python at all.
            try:
                r = subprocess.run(["xcode-select", "-p"],
                                   capture_output=True, timeout=10,
                                   env=_clean_env())
                clt_missing = r.returncode != 0
            except Exception:
                clt_missing = True
            if clt_missing:
                _log("mac: no Xcode CLT — skipping bare python3/python "
                     "probes (executing the xcrun stub would pop Apple's "
                     "developer-tools dialog)")
                bare = []
        candidates += bare
    # Our own private interpreter, if a previous run (or the auto-install we
    # just performed) put one there. It is deliberately LAST: a Python the
    # owner already has is always the better choice, and this only exists so
    # that the auto-install step cannot succeed and then be told it failed.
    # It is also deliberately present on the FIRST probe, not just the
    # re-probe, so a customer who reruns the installer doesn't download 25MB
    # of CPython a second time.
    candidates.append([_standalone_python_exe()])
    rejected = []
    for cand in candidates:
        if os.path.isabs(cand[0]):
            # Absolute probe paths are guesses at standard install locations;
            # a miss is expected and must not spam the customer's error text.
            exe = cand[0] if os.path.isfile(cand[0]) else ""
            if not exe:
                continue
        else:
            exe = shutil.which(cand[0])
            if not exe:
                rejected.append(f"{cand[0]}: not on PATH")
                continue
        argv = [exe] + cand[1:]
        try:
            r = subprocess.run(
                argv + ["-c", "import venv,sys;print(sys.executable);"
                              "print('%d.%d' % sys.version_info[:2])"],
                capture_output=True, text=True, timeout=25,
                encoding="utf-8", errors="replace", env=_clean_env())
        except Exception as e:
            rejected.append(f"{cand[0]}: {e}")
            continue
        out = (r.stdout or "").strip().splitlines()
        if r.returncode != 0 or len(out) < 2:
            why = (r.stderr or "no output").strip().splitlines()
            rejected.append(f"{cand[0]}: {why[-1][:120] if why else 'no venv module'}")
            continue
        resolved, ver = out[0].strip(), out[1].strip()
        # The Microsoft Store stub in WindowsApps answers -c fine but cannot
        # build a usable venv in LOCALAPPDATA (redirected, sandboxed writes).
        if "WindowsApps" in resolved:
            rejected.append(f"{cand[0]}: Microsoft Store stub ({resolved})")
            continue
        try:
            major, minor = (int(x) for x in ver.split(".")[:2])
        except Exception:
            major, minor = 3, 0
        if (major, minor) < PY_FLOOR:
            rejected.append(f"{cand[0]}: Python {ver} is too old "
                            f"(need {PY_FLOOR[0]}.{PY_FLOOR[1]}+)")
            continue
        _log(f"system python: {resolved} (v{ver}) via {' '.join(cand)}")
        return resolved, rejected
    # Order-preserving dedup: four py candidates collapse to one PATH lookup,
    # so the customer used to read "py: not on PATH" four times in a row and
    # reasonably conclude the software was broken as well as unhelpful.
    return "", list(dict.fromkeys(rejected))


def _no_python_error(rejected) -> "InstallError":
    floor = f"{PY_FLOOR[0]}.{PY_FLOOR[1]}"
    if IS_WINDOWS:
        how = (f"Install Python {floor}+ from python.org (tick “Add python.exe "
               f"to PATH”, and don't use the Microsoft Store version)")
    elif IS_MAC:
        how = f"Install Python {floor}+ from python.org, or `brew install python`"
    else:
        how = (f"Install Python {floor}+ with your package manager "
               f"(e.g. sudo apt install python3 python3-venv)")
    return InstallError(
        f"No usable Python 3 found on this machine, and installing one "
        f"automatically didn't work either. {how}, then run this "
        "installer again. Checked: " + "; ".join(rejected)[:300] + _log_hint())


#: The exact interpreter we install when a machine has none. Pinned, not
#: "latest": `py -3` means NEWEST, and newest is routinely too far ahead of
#: the wheel ecosystem for pyaudio/webrtcvad — the same trap PY_PREFERRED
#: exists to dodge. 3.12 has wheels for everything the body needs.
PY_AUTO_VERSION = "3.12.10"
PY_AUTO_URL_WIN = (
    f"https://www.python.org/ftp/python/{PY_AUTO_VERSION}/"
    f"python-{PY_AUTO_VERSION}-amd64.exe")
PY_AUTO_URL_MAC = (
    f"https://www.python.org/ftp/python/{PY_AUTO_VERSION}/"
    f"python-{PY_AUTO_VERSION}-macos11.pkg")


def _autoinstall_python(say) -> bool:
    """Put a usable Python on this machine ourselves. True if we tried and
    the installer program reported success.

    Windows: the official python.org installer, run silently, PER-USER —
    InstallAllUsers=0 means no UAC prompt and no admin rights needed, which
    matters because most people running this are not administrators of their
    own machine and a silent install that needs elevation just fails with a
    number. PrependPath=1 fixes the PATH for next time; this run doesn't
    depend on it because the probe also looks in the known install dir.

    macOS: prefer Homebrew if it's already there (no password), otherwise
    the .pkg needs admin and we fall back to opening the download page.

    Linux: only apt/dnf with PASSWORDLESS sudo. We never prompt for a root
    password from a GUI that has nowhere to type it.
    """
    try:
        if IS_WINDOWS:
            if _autoinstall_python_windows(say):
                return True
            # The python.org silent install is still preferred on Windows --
            # it puts Python on PATH for everything else the owner ever does.
            # But it can be blocked (locked-down machine, AV, an existing
            # broken registration), and when it is, the no-privileges
            # tarball is a working answer instead of a download page.
            return _autoinstall_python_standalone(say)
        if IS_MAC:
            return _autoinstall_python_mac(say)
        return _autoinstall_python_linux(say)
    except Exception as e:  # never let the helper mask the real error
        _log(f"python autoinstall failed: {e}")
        return False


def _autoinstall_python_windows(say) -> bool:
    say(f"No Python on this machine — installing Python {PY_AUTO_VERSION} "
        f"for you (about a minute)…")
    dst = os.path.join(tempfile.gettempdir(),
                       f"python-{PY_AUTO_VERSION}-amd64.exe")
    _log(f"downloading {PY_AUTO_URL_WIN}")
    with _urlopen(PY_AUTO_URL_WIN, timeout=180) as r, open(dst, "wb") as f:
        shutil.copyfileobj(r, f)
    size = os.path.getsize(dst)
    if size < 5_000_000:  # a real one is ~25MB; anything smaller is an error page
        _log(f"python installer download looks wrong ({size} bytes)")
        return False
    argv = [dst, "/quiet", "InstallAllUsers=0", "PrependPath=1",
            "Include_pip=1", "Include_launcher=1", "AssociateFiles=0",
            "Shortcuts=0", "Include_test=0"]
    say("Installing Python…")
    r = subprocess.run(argv, capture_output=True, text=True, timeout=900,
                       encoding="utf-8", errors="replace")
    _log(f"python installer rc={r.returncode} out={(r.stdout or '')[:200]} "
         f"err={(r.stderr or '')[:200]}")
    try:
        os.remove(dst)
    except OSError:
        pass
    # rc 3010 = success, reboot requested. Not our problem: a per-user Python
    # is usable immediately, and treating it as failure would send a customer
    # who is actually fine back to python.org.
    return r.returncode in (0, 3010)


def _autoinstall_python_mac(say) -> bool:
    brew = shutil.which("brew")
    if brew:
        say(f"No Python on this machine — installing it with Homebrew…")
        r = subprocess.run([brew, "install", "python@3.12"],
                           capture_output=True, text=True, timeout=1800,
                           encoding="utf-8", errors="replace")
        _log(f"brew install python rc={r.returncode} "
             f"err={(r.stderr or '')[:200]}")
        if r.returncode == 0:
            return True
    # NO HOMEBREW IS THE COMMON CASE, NOT THE EDGE CASE (2026-08-12).
    #
    # The previous version of this function returned False right here, and a
    # comment further down the file justified it: "this can't silently
    # self-heal (no controlling terminal to run brew/Xcode CLT
    # non-interactively from inside a frozen GUI app, and no sudo prompt to
    # drive)". That reasoning is sound about brew and about the python.org
    # .pkg -- both DO need admin -- but it silently assumed those were the
    # only two ways to get a Python onto a Mac. They are not.
    #
    # A person who bought an SI is overwhelmingly not a developer, and a
    # non-developer's Mac has no Homebrew. So the "fallback" path was in
    # practice the ONLY path, and it dead-ended into "here's a download page,
    # go do it yourself" -- the exact homework assignment Aiden's Windows box
    # already proved is unacceptable. Mac was one release behind Windows on
    # the same bug.
    return _autoinstall_python_standalone(say)


#: A redistributable, relocatable CPython that installs by UNTARRING. No
#: admin, no sudo, no Homebrew, no Xcode Command Line Tools, no package
#: manager, no PATH surgery, and no dialog for anyone to click. This is what
#: uv uses to provision interpreters, which is a strong signal it holds up on
#: strangers' machines. Pinned to an exact release tag so the same installer
#: build always fetches the same bytes.
STANDALONE_PY_TAG = "20260807"
STANDALONE_PY_VERSION = "3.12.13"
STANDALONE_PY_BASE = ("https://github.com/astral-sh/python-build-standalone/"
                      "releases/download")


def _standalone_python_triple() -> str:
    """The build-standalone target triple for THIS machine, or "" if the
    project doesn't publish one (in which case we fail honestly rather than
    download a tarball that cannot run here)."""
    m = (platform.machine() or "").lower()
    if IS_MAC:
        if m in ("arm64", "aarch64"):
            return "aarch64-apple-darwin"
        if m in ("x86_64", "amd64"):
            return "x86_64-apple-darwin"
        return ""
    if IS_WINDOWS:
        if m in ("amd64", "x86_64"):
            return "x86_64-pc-windows-msvc"
        if m in ("arm64", "aarch64"):
            return "aarch64-pc-windows-msvc"
        return ""
    # Linux. Deliberately the BASELINE x86_64 build, not v2/v3/v4: those are
    # compiled for newer instruction sets and fault with an illegal
    # instruction on older CPUs instead of failing to start, which would be a
    # far worse bug to debug from a customer's log.
    if m in ("x86_64", "amd64"):
        return "x86_64-unknown-linux-gnu"
    if m in ("arm64", "aarch64"):
        return "aarch64-unknown-linux-gnu"
    return ""


def _standalone_python_root() -> str:
    """Where our private interpreter lives. Under the user's own home, so no
    elevation is ever required to write it."""
    return os.path.join(os.path.expanduser("~"), ".sabr", "python")


def _standalone_python_exe() -> str:
    """Absolute path to the interpreter the tarball unpacks, whether or not
    it exists yet. The archive always has a single top-level `python/`."""
    root = os.path.join(_standalone_python_root(), "python")
    if IS_WINDOWS:
        return os.path.join(root, "python.exe")
    return os.path.join(root, "bin", "python3.12")


def _autoinstall_python_standalone(say) -> bool:
    """Last-resort Python provisioning that needs no privileges at all."""
    triple = _standalone_python_triple()
    if not triple:
        _log(f"standalone python: no build for {sys.platform}/"
             f"{platform.machine()}")
        return False
    if os.path.isfile(_standalone_python_exe()):
        _log("standalone python already present")
        return True
    # _stripped, NOT the plain build. Measured on a cold home directory:
    # the unstripped archive unpacks to 767MB, almost all of it debug
    # symbols in a 214MB libpython and a 100MB interpreter binary. Nobody
    # buying an SI is going to debug CPython, and three quarters of a
    # gigabyte of symbols on a laptop that is already short on space is a
    # real cost for zero benefit. Same interpreter, same version.
    name = (f"cpython-{STANDALONE_PY_VERSION}+{STANDALONE_PY_TAG}-{triple}"
            f"-install_only_stripped.tar.gz")
    url = f"{STANDALONE_PY_BASE}/{STANDALONE_PY_TAG}/{name}"
    say(f"No Python on this machine — installing a private copy just for "
        f"your SI (about a minute)…")
    tmp = os.path.join(tempfile.gettempdir(), name)
    try:
        _log(f"downloading {url}")
        with _urlopen(url, timeout=300) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
        size = os.path.getsize(tmp)
        # A real one is ~25MB. A GitHub 404 is an HTML page of a few KB, and
        # extracting that would raise something unhelpful three frames away
        # from the actual problem.
        if size < 5_000_000:
            _log(f"standalone python download looks wrong ({size} bytes)")
            return False
        root = _standalone_python_root()
        os.makedirs(root, exist_ok=True)
        say("Unpacking Python…")
        with tarfile.open(tmp, "r:gz") as tf:
            try:
                tf.extractall(root, filter="data")
            except TypeError:
                # `filter=` landed in 3.12; the frozen installer could in
                # principle be built on something older.
                tf.extractall(root)
    except Exception as e:
        _log(f"standalone python install failed: {e}")
        return False
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    exe = _standalone_python_exe()
    if not os.path.isfile(exe):
        _log(f"standalone python extracted but {exe} is missing")
        return False
    if not IS_WINDOWS:
        try:
            os.chmod(exe, 0o755)
        except OSError:
            pass
    # DO NOT return True on "the files are on disk". That is the same
    # mistake as an exit code of zero: it proves the copy happened, not that
    # the interpreter runs. A Gatekeeper quarantine, a bad arch, or a
    # truncated archive all leave a file sitting exactly where we expect one.
    try:
        r = subprocess.run([exe, "-c", "import sys,ssl,sqlite3;"
                                       "print(sys.version_info[:2])"],
                           capture_output=True, text=True, timeout=120,
                           encoding="utf-8", errors="replace")
    except Exception as e:
        _log(f"standalone python will not execute: {e}")
        return False
    if r.returncode != 0:
        _log(f"standalone python smoke test rc={r.returncode} "
             f"err={(r.stderr or '')[:300]}")
        return False
    _log(f"standalone python ready at {exe} -> {(r.stdout or '').strip()}")
    return True


def _autoinstall_python_linux(say) -> bool:
    if _autoinstall_python_linux_pkg(say):
        return True
    # Same reasoning as macOS: a desktop Linux user without passwordless
    # sudo, or on a distro that is neither apt nor dnf, used to get a dead
    # end. The tarball needs neither.
    return _autoinstall_python_standalone(say)


def _autoinstall_python_linux_pkg(say) -> bool:
    sudo = shutil.which("sudo")
    if not sudo:
        return False
    # -n: fail immediately rather than block forever on a password prompt
    # that a windowed installer gives nobody anywhere to type into.
    probe = subprocess.run([sudo, "-n", "true"], capture_output=True,
                           timeout=15)
    if probe.returncode != 0:
        _log("linux python autoinstall: no passwordless sudo")
        return False
    if shutil.which("apt-get"):
        cmds = [[sudo, "-n", "apt-get", "update", "-qq"],
                [sudo, "-n", "apt-get", "install", "-y",
                 "python3", "python3-venv", "python3-pip"]]
    elif shutil.which("dnf"):
        cmds = [[sudo, "-n", "dnf", "install", "-y", "python3", "python3-pip"]]
    else:
        return False
    say("No Python on this machine — installing it for you…")
    for c in cmds:
        r = subprocess.run(c, capture_output=True, text=True, timeout=1800,
                           encoding="utf-8", errors="replace")
        _log(f"{' '.join(c[2:4])} rc={r.returncode} err={(r.stderr or '')[:200]}")
        if r.returncode != 0:
            return False
    return True


CONTRACT_VERSION = 1

#: WHICH BINARY IS THE CUSTOMER ACTUALLY RUNNING? (2026-08-12)
#:
#: Aiden re-ran v15's payload with v14's SabrInstaller.exe — the .exe already
#: sitting in his Downloads folder — and his install log gave no way to tell.
#: The tarball hash matched the new release, every step looked right, and the
#: hands-provisioning step that v15 added simply never appeared. It took
#: reading the log line-by-line and noticing an ABSENCE to work out that the
#: binary was stale, which is not a diagnosis method that survives having more
#: than one beta tester.
#:
#: The `version` that used to be streamed was report_version(dest) — the
#: version of the PAYLOAD ON DISK, which on an update is whatever was there
#: BEFORE this run. Exactly the wrong number, and it rendered as
#: "vSabr SI at C:\Users\..." in the header because it is prose, not a
#: version. Both numbers matter and they answer different questions, so log
#: both, distinctly.
#:
#: CI rewrites this line from the release tag (see .github/workflows/
#: build-installer.yml). "dev" means someone ran the .py directly, which is
#: itself worth seeing in a log.
INSTALLER_BUILD = "dev"

#: The gate enforced 3.9 while the rejection message told people to install
#: 3.11+ — so a 3.10 machine sailed past the check and died later inside pip,
#: with an error naming neither Python nor the version. One number now, and it
#: is the one bootstrap.sh already derived from numpy/scipy Requires-Python.
PY_FLOOR = (3, 11)

#: Minor versions to prefer, NEWEST FIRST, before falling back to "whatever
#: the newest installed Python is". These are the versions the binary-wheel
#: ecosystem actually covers. Bump the front of this list only once wheels
#: for that version exist for the C-extension deps (sounddevice, soundfile,
#: onnxruntime, vosk, webrtcvad-wheels) — NOT when the version merely ships.
#: Verify before bumping:
#:   pip download --only-binary=:all: --python-version 3.X <pkg>
PY_PREFERRED = (13, 12, 11)

IS_LINUX = sys.platform.startswith("linux")
IS_MAC = sys.platform == "darwin"
IS_WINDOWS = sys.platform.startswith("win")

# ── no console windows on Windows, ever ───────────────────────────────────
# --windowed means WE have no console. It does NOT mean our CHILDREN don't:
# every subprocess (takeown, icacls, py, pip, venv, whoami, sc, schtasks —
# 31 call sites) spawns its own console window. During an install that's a
# black box popping up over the installer again and again, sometimes stealing
# focus, for several minutes. Reported by Aiden's install 2026-08-12: "a big
# black box pops up and covers the install box and follows it."
#
# Patched once, here, rather than at 31 call sites — the next person to add a
# subprocess call gets it for free instead of reintroducing the flicker.
if IS_WINDOWS:
    _CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    def _hidden_startupinfo():
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0          # SW_HIDE
        return si

    def _quiet(kw: dict) -> dict:
        kw["creationflags"] = kw.get("creationflags", 0) | _CREATE_NO_WINDOW
        if "startupinfo" not in kw:
            kw["startupinfo"] = _hidden_startupinfo()
        return kw

    _real_run, _real_popen = subprocess.run, subprocess.Popen

    def _quiet_run(*a, **kw):
        return _real_run(*a, **_quiet(kw))

    class _QuietPopen(_real_popen):
        def __init__(self, *a, **kw):
            super().__init__(*a, **_quiet(kw))

    subprocess.run = _quiet_run
    subprocess.Popen = _QuietPopen


def _write_constraints(req_path: str, dest: str):
    """A pip constraints file distilled from requirements.txt.

    Constraints are stricter than requirements about syntax: extras
    (`uvicorn[standard]`) are rejected outright, and a bare name with no
    version constrains nothing, so both are dropped. Environment markers are
    kept — a marker'd pin still has to hold on the platform it applies to.

    Returns the path, or None if there was nothing worth constraining or the
    file could not be written. A missing constraints file must never fail an
    install: worst case we are back to the old unpinned behaviour.
    """
    lines = []
    try:
        for spec in _parse_requirements(req_path):
            spec = spec.strip()
            if not spec or spec.startswith("-"):
                continue
            head, sep, marker = spec.partition(";")
            if "[" in head:                       # extras are illegal here
                head = head[:head.index("[")] + head[head.index("]") + 1:]
            if not any(op in head for op in ("==", ">=", "<=", "~=", ">", "<")):
                continue                           # unversioned: no constraint
            lines.append(head.strip() + (sep + marker if sep else ""))
        if not lines:
            return None
        path = os.path.join(dest, ".pip-constraints.txt")
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("# Generated by the installer. Makes requirements.txt's\n"
                     "# pins binding during package-by-package recovery.\n")
            fh.write("\n".join(lines) + "\n")
        return path
    except OSError as e:
        _log(f"constraints file skipped ({e}) — install continues unpinned")
        return None


def _os_account_name() -> str:
    """The human's name on this machine, for LEON_USER_NAME's last resort.

    Never raises and never returns the empty string — an empty owner name is
    the exact defect this exists to stop. "friend" is a deliberate choice
    over "" or "user": the SI says this word out loud.
    """
    for var in ("USERNAME", "USER", "LOGNAME"):
        val = (os.environ.get(var) or "").strip()
        if val and val.lower() not in {"root", "administrator", "system"}:
            return val
    try:
        import getpass
        val = (getpass.getuser() or "").strip()
        if val and val.lower() not in {"root", "administrator", "system"}:
            return val
    except Exception:
        pass
    return "friend"


def _req_name(spec: str) -> str:
    """Bare distribution name from a requirement line, for display + dedupe."""
    spec = spec.split(";", 1)[0].strip()          # drop environment marker
    for sep in ("===", "==", ">=", "<=", "~=", "!=", ">", "<", "["):
        spec = spec.split(sep, 1)[0]
    return spec.strip().lower().replace("_", "-")


def _parse_requirements(path: str) -> list:
    """Requirement lines that apply to THIS machine, in file order.

    Environment markers are honoured (`; sys_platform == "linux"`), because
    the one-at-a-time retry installs each line directly — and pip applied to
    a bare spec ignores the marker it was given on the line. Without this,
    the Windows retry would try to install evdev, a Linux-only package that
    cannot build there, and report a scary failure for something that was
    never meant to be installed in the first place.
    """
    out = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        return out
    for raw in lines:
        line = raw.split("#", 1)[0].strip()
        if not line or line.startswith("-"):
            continue
        if ";" in line:
            spec, marker = line.split(";", 1)
            try:
                # Same evaluator pip uses; if it's unavailable, keep the line
                # rather than silently dropping a real dependency.
                from packaging.markers import Marker
                if not Marker(marker.strip()).evaluate():
                    continue
            except ImportError:
                pass
            except Exception:
                continue
            line = spec.strip()
        if line:
            out.append(line)
    return out


def default_install_dir() -> str:
    home = os.path.expanduser("~")
    if IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(home, "AppData", "Local")
        return os.path.join(base, "SabrSI")
    return os.path.join(home, "SabrSI")


def fetch_config(base_url: str, token: str) -> dict:
    """Redeem the install token for this customer's config."""
    # Token rides in a header so it stays out of server access logs. The
    # query param is transitional — drop it once the VPS wizard reads the
    # header (it's single-use, so the exposure window is one redemption).
    url = f"{base_url.rstrip('/')}/api/onboarding/install-config?token={urllib.parse.quote(token)}"
    req = urllib.request.Request(url, headers={"X-Install-Token": token})
    try:
        with _urlopen(req, timeout=20) as r:
            cfg = json.load(r)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise InstallError("That token wasn't recognized. Copy it again from the "
                               "onboarding page — it starts after 'token:'.")
        if e.code == 403:
            # The server refused this token ON PURPOSE — a revoked account
            # or an expired 24-hour trial — and its body says which, in
            # plain English. Show that sentence. "Try again in a minute"
            # would be a lie here: retrying a licence refusal can't fix it,
            # and a trial customer deserves to hear "your trial ended,
            # here's how to keep your SI" instead of a fake server error.
            detail = ""
            try:
                detail = json.loads(e.read().decode("utf-8", "replace")).get("error", "")
            except Exception:
                pass
            raise InstallError(detail or "This account can no longer install "
                               "an SI. Email support@sabr.co if that seems wrong.")
        raise InstallError(f"Server error ({e.code}). Try again in a minute.")
    except Exception as e:
        raise InstallError(f"Couldn't reach {base_url} — check your internet. ({e})")
    if not cfg.get("ok"):
        raise InstallError(cfg.get("error", "Invalid config response"))
    if cfg.get("version", 0) > CONTRACT_VERSION:
        raise InstallError("This installer is out of date — download the latest "
                           f"from {base_url}.")
    return cfg


class InstallError(Exception):
    """User-facing failure with a plain-English message."""


def _port_busy(port: int) -> bool:
    """True if something is already listening on 127.0.0.1:port."""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False


def _is_our_si(port: int) -> bool:
    """Prove the listener on this port is OUR SI, not a stranger.

    A bare TCP connect proves only that something accepted a socket. The SI
    serves /api/version unauthenticated precisely so this check can exist.
    """
    try:
        import json as _json
        from urllib.request import urlopen
        with urlopen(f"http://127.0.0.1:{port}/api/version", timeout=3) as r:
            if r.status != 200:
                return False
            body = _json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return False
    return isinstance(body, dict) and bool(body.get("commit") or body.get("version"))


class Installer:
    def __init__(self, cfg: dict, dest: str, base_url: str,
                 progress=print, dry_run: bool = False):
        self.cfg = cfg
        self.dest = dest
        self.base_url = base_url.rstrip("/")
        self.say = progress
        self.dry = dry_run

    # ── which port this SI gets ────────────────────────────────────
    @property
    def port(self) -> int:
        """Resolved lazily and cached.

        Deliberately NOT set in __init__: parts of the codebase (and the
        entry-point tests) build an Installer via __new__ to poke at one
        method without running the constructor. Making _entry_cmd depend on
        constructor state broke all of those with an AttributeError.
        """
        p = getattr(self, "_port", None)
        if p is None:
            p = self._resolve_port()
            self._port = p
        return p

    def _resolve_port(self) -> int:
        """Pick the port ONCE, here, and use it everywhere.

        8000 was hardcoded in three separate places: the autostart command,
        the readiness probe, and the finish-screen URL. Two consequences, both
        bad, both silent:

        1. A second SI on the same machine is impossible. Not "unsupported" —
           it installs, the launcher points at 8000, and it collides.
        2. Worse, the readiness probe only did a TCP connect. If ANYTHING was
           already on 8000 — a prior SI, a dev server, Ollama's web UI — the
           probe succeeded on the first try and the installer announced the
           new SI was ready when it had not started at all. A false success is
           the most expensive kind of bug we can ship: the customer walks away
           believing it worked.

        So: honour an explicit override, otherwise take 8000 if it is free,
        otherwise step to the next free port rather than colliding.
        """
        for var in ("SABR_SI_PORT", "LEON_PORT"):
            raw = (os.environ.get(var) or "").strip()
            if raw.isdigit() and 1 <= int(raw) <= 65535:
                return int(raw)
        for candidate in range(8000, 8064):
            if not _port_busy(candidate):
                if candidate != 8000:
                    # say() may not exist on a bare __new__ instance.
                    say = getattr(self, "say", None)
                    if callable(say):
                        say(f"Port 8000 is already taken on this machine — "
                            f"using {candidate} instead.")
                return candidate
        return 8000

    # ── steps ──────────────────────────────────────────────────────
    def run(self):
        name = self.cfg.get("si_name", "your SI")
        # FIRST, before any brain decision is made: repair PATH. A frozen GUI
        # app launched from Finder (or a Windows shortcut) gets the bare
        # service PATH — no /opt/homebrew/bin, no ~/.local/bin — so a claude
        # that works in every terminal is invisible to which(). a customer's Mac,
        # 2026-08-23: signed in to Claude Code, still told he had no brain.
        local_brain.augment_path()
        # Publish the resolved port so the finish screen and .env agree with
        # the launcher instead of all three independently assuming 8000.
        self.cfg["si_port"] = self.port
        self.say(f"Installing {name}…")
        self._warn_if_stale_installer()
        self.download_release()
        self.scrub_owner_files()
        self.scrub_owner_data()
        self._repair_windows_acls()
        self.write_env()
        self._detect_claude_login()
        if not self.dry:
            # The crash verdict from whatever is ALREADY on this machine,
            # read before install_deps replaces anything. On an update it
            # answers "was the thing we are replacing crash-looping?", which
            # is the single most useful fact about a re-install and one we
            # have never had. None on a fresh box — nothing has crashed yet.
            _crash = _crash_signal(self.dest)
            if _crash:
                _log(f"crash signal from existing install: {_crash.get('verdict')}")
            with _telemetry_step("deps"):
                self.install_deps()
            self.provision_actuator()
            self.provision_local_llm()
            with _telemetry_step("service_setup"):
                self.register_autostart()
            # first_boot spans launch AND the wait, because a launch that
            # returns is not a boot that happened — that conflation is the
            # exact bug the comment below was written for.
            with _telemetry_step("first_boot", crash=_crash) as _boot:
                self.launch()
                _answering = self._wait_until_answering()
                if not _answering:
                    _boot.fail("NotAnswering")
            # DO NOT SAY "READY" WITHOUT LOOKING. Added 2026-08-11.
            #
            # This line used to print unconditionally, one statement after a
            # bare Popen with no poll and no returncode. Nothing between the
            # launch and the word "ready" could ever have observed a dead SI,
            # so every way an install can come up broken — deps that failed
            # to wheel, a runner script that never got written, a crash-loop
            # restarting every five seconds forever — ended with a green
            # "ready" and a customer who believes the problem is on their end.
            # That is the same shape as the missing entry point: succeed
            # loudly, fail silently.
            #
            # A failure here is NOT an InstallError. The files are on disk and
            # autostart is registered; a reboot may well fix it. Say what is
            # actually true and point at the log.
            if not _answering:
                self.say(f"{name} is installed, but it has not started "
                         f"answering yet.")
                self.say(f"Give it a minute, or restart this computer. If it "
                         f"still does not come up, the reason is in "
                         f"{os.path.join(self.dest, 'brain_state', 'si.log')} (and "
                         f"{os.path.join(self.dest, 'sabr-si.log')}) — send us "
                         f"that file.")
                return
        # An SI that came up on its port but has no brain behind it is not
        # "ready" — it is a spinner. provision_local_llm sets this when the
        # machine has no cloud brain AND the local one could not be installed.
        if getattr(self, "failed_local_brain", False):
            self.say(f"{name} is installed and running, but it has no brain "
                     f"yet — sign in to Claude Code (open a terminal, run: "
                     f"claude), add a Claude API key, or install Ollama and "
                     f"re-run this installer.")
            return
        # LAST GATE: the port answering is not the SI answering. Aiden's
        # install (2026-08-12) passed every check above and still shipped an
        # SI that could not reply to a single message. Ask the running process
        # which brain would take a turn, and refuse to say "ready" if the
        # answer is "none of them". Never fatal — the files are on disk and it
        # may well be fixable in place — but never silent either.
        _bc = self._brain_check()
        if _bc is not None and not _bc.get("ok", False):
            _which = _bc.get("brain", "none")
            if _which == "local-but-gated":
                self.say(f"{name} is installed and running, but its local "
                         f"model is switched off for conversation and there "
                         f"is no cloud brain to fall back on — so it would "
                         f"not answer you. Re-run this installer to repair it.")
            else:
                self.say(f"{name} is installed and running, but it has no "
                         f"brain behind it yet, so it cannot answer. Sign in "
                         f"to Claude Code (open a terminal, run: claude), add "
                         f"a Claude API key, or install Ollama and re-run "
                         f"this installer.")
            self.say(f"Details are in "
                     f"{os.path.join(self.dest, 'brain_state', 'si.log')} (the SI's own log, written "
                     f"however it was started) and {os.path.join(self.dest, 'sabr-si.log')}.")
            return
        # SECOND GATE, SAME RULE, ONE LAYER OVER: a brain that can answer is
        # not an SI that can act. Aiden's "Iris" cleared every check above —
        # installed, running, answering, brain behind it — and could not take
        # a screenshot, move the mouse or press a key, because the packages
        # its body needs were never in the venv and nothing ever asked the
        # body a question. Ask it now, and say what is true.
        #
        # Never fatal, and deliberately not silent in EITHER direction: an SI
        # that can think but not touch is a real, usable product and must not
        # be reported as a failed install — but it must also never be handed
        # over with the owner believing it has hands it does not have.
        _body = self._body_check()
        if getattr(self, "no_body", None) or (
                _body is not None and not _body.get("ok", False)):
            why = getattr(self, "no_body", None) or ""
            if _body is not None and _body.get("missing"):
                why = why or ("no " + ", ".join(_body["missing"]))
            elif _body is not None and _body.get("error"):
                why = why or _body["error"]
            self.say(f"{name} is installed and can talk, but it cannot see or "
                     f"control this computer yet"
                     + (f" ({why})" if why else "") + ".")
            if IS_MAC:
                # The one platform where this is expected on a correct
                # install and is fixed by the owner, not by us.
                self.say("On a Mac this is usually the permission grants — "
                         "see the Privacy & Security step above. macOS "
                         "grants them per-program, so ticking them for this "
                         "installer is not enough on its own: it may ask "
                         "again for the SI itself, and those prompts or "
                         "Privacy & Security entries can be named \"python\" "
                         "or \"sh\". Approve those too — that IS your SI.")
            self.say(f"Everything else works. Details are in "
                     f"{os.path.join(self.dest, 'brain_state', 'si.log')} (the SI's own log, written "
                     f"however it was started) and {os.path.join(self.dest, 'sabr-si.log')}.")
            return
        if _body is not None:
            self.say(f"{name} can see your screen and use this computer.")
        self.say(f"{name} is ready.")

    def _brain_check(self):
        """Ask the running SI whether it has a brain. None = couldn't ask.

        None is deliberately distinct from a failing check: an older payload
        has no /api/brain-check route, and a 404 there must not be reported to
        a customer as "your SI has no brain".
        """
        try:
            import json as _json
            import urllib.request as _u
            port = getattr(self, "port", None) or 8000
            with _u.urlopen(f"http://127.0.0.1:{port}/api/brain-check",
                            timeout=10) as r:
                return _json.loads(r.read().decode("utf-8", "replace"))
        except Exception as exc:
            _log(f"brain-check unavailable: {exc}")
            return None

    def _wait_until_answering(self, timeout: float = 90.0) -> bool:
        """Poll the SI's own port until it responds, or give up.

        Local mode serves HTTP on 8000. Hosted mode runs the body, which
        listens on nothing — there is no port to poll, so we cannot prove
        liveness this way and must not claim failure we did not observe.
        """
        if self.cfg.get("brain_mode") != "local":
            return True
        port = self.port
        deadline = time.monotonic() + timeout
        told = False
        while time.monotonic() < deadline:
            # A TCP connect is NOT proof of life. It used to be, and that meant
            # anything squatting the port made us announce success for an SI
            # that never booted. Ask the listener who it is.
            if _is_our_si(port):
                return True
            if not told and time.monotonic() > deadline - timeout + 12:
                # First boot builds the neural state; silence for a while is
                # normal. Say so, or the wait reads as a hang.
                self.say("Still waking up — first boot takes a moment…")
                told = True
            time.sleep(2)
        return False

    def scrub_owner_files(self):
        """Apply scrub_list.txt (the ONE privacy manifest, 2026-09-02) to the
        tree we just extracted. The tarball is built clean, but the GUI path
        never ran any scrub at all — bootstrap.sh and install_client.py did —
        so a tarball rebuilt with one forgotten exclude shipped the owner's
        private files straight onto a customer's disk with no second line of
        defence. "!client-only" entries stay when the SI being installed is
        the owner's own (name leon)."""
        manifest = os.path.join(self.dest, "scrub_list.txt")
        try:
            with open(manifest, encoding="utf-8") as fh:
                lines = fh.read().splitlines()
        except OSError:
            lines = ["brain/owner_facts.py", "leon_notes.txt"]
        is_owner = (self.cfg.get("si_name") or "").strip().lower() == "leon"
        removed = 0
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("!client-only "):
                if is_owner:
                    continue
                line = line[len("!client-only "):].strip()
            if line.startswith(("/", "\\")) or ".." in line:
                continue  # never leave the tree
            target = os.path.normpath(os.path.join(self.dest, line))
            if not target.startswith(os.path.normpath(self.dest) + os.sep):
                continue
            try:
                if os.path.isdir(target) and not os.path.islink(target):
                    shutil.rmtree(target, ignore_errors=True)
                    removed += 1
                elif os.path.lexists(target):
                    os.remove(target)
                    removed += 1
            except OSError as e:
                _log(f"[scrub] could not remove {target}: {e}")
        if removed:
            _log(f"[scrub] removed {removed} owner-only item(s) per scrub_list.txt")

    def scrub_owner_data(self):
        """Companion to scrub_owner_files(), added 2026-09-03. That method
        removes owner-only *source files* on every install/update, which
        stops re-seeding — but brain_state/ is in _NEVER_REPLACE by design
        (a customer's own accumulated memory must survive every update), so
        any of Dean's personal/project data that got baked into a customer's
        knowledge.db / cognition_graph.db / projects.db BEFORE the file-level
        fix landed (2026-09-02) has been surviving every update since,
        untouched. This runs brain/tools/privacy_scrub.py in --apply mode
        against this install's brain_state, which deletes only rows matching
        a curated list of Dean/Sabr-owner-only phrases (never generic words),
        so a customer's own real memories are never touched. No-ops cleanly
        on a fresh install (no brain_state yet) and is always skipped for the
        owner's own SI (name == leon) — see privacy_scrub.py for the proof."""
        if self.dry:
            return
        is_owner = (self.cfg.get("si_name") or "").strip().lower() == "leon"
        if is_owner:
            return
        brain_state = os.path.join(self.dest, "brain_state")
        if not os.path.isdir(brain_state):
            return  # fresh install, nothing to scrub yet
        script = os.path.join(self.dest, "brain", "tools", "privacy_scrub.py")
        if not os.path.exists(script):
            return
        try:
            py = sys.executable or "python3"
            result = subprocess.run(
                [py, script, brain_state, "--apply",
                 "--si-name", self.cfg.get("si_name") or ""],
                capture_output=True, text=True, timeout=60)
            if result.returncode == 0 and result.stdout:
                try:
                    report = json.loads(result.stdout)
                    n = report.get("total_deleted", 0)
                    if n:
                        _log(f"[privacy_scrub] removed {n} owner-contaminated "
                             f"memory row(s) from brain_state")
                except (ValueError, json.JSONDecodeError):
                    pass
            elif result.returncode != 0:
                _log(f"[privacy_scrub] failed rc={result.returncode}: {result.stderr[:300]}")
        except Exception as e:
            _log(f"[privacy_scrub] could not run: {e}")

    def download_release(self):
        _ensure_writable_dir(self.dest)
        # Heal the debris of a crashed earlier run before staging a new one.
        # A previous update that died hard (power cut, force-quit, taskkill)
        # leaves .sabr-extract-*/.sabr-old-* staging dirs behind; every one
        # of them is a few hundred MB of dead weight, and letting them
        # accumulate is how a customer's disk fills with our failures.
        # ignore_errors: a stale dir that will not delete must never block
        # the update that would fix everything.
        try:
            for stale in os.listdir(self.dest):
                if stale.startswith((".sabr-extract-", ".sabr-old-")):
                    shutil.rmtree(os.path.join(self.dest, stale),
                                  ignore_errors=True)
        except OSError:
            pass
        rel = self.cfg.get("artifacts", {}).get("release_tarball", "/download")
        url = rel if rel.startswith("http") else self.base_url + rel
        # No silent TLS downgrade. Once the digest below is the thing standing
        # between a customer and a tampered payload, plaintext transport would
        # make it the ONLY thing instead of the second layer.
        if not url.lower().startswith("https://"):
            raise InstallError("Refusing to download your SI over an insecure "
                               "connection. Contact support.")
        expected_sha = (self.cfg.get("artifacts", {})
                        .get("release_tarball_sha256", "") or "").strip().lower()
        self.say("Downloading your SI…")
        # Which half of this function we are in, for telemetry. One try
        # block covers both the fetch and the unpack (they share a temp file
        # and a cleanup), so the two `except` arms at the bottom cannot tell
        # a dead connection from a bad archive without being told. A plain
        # local is enough and costs nothing; splitting the function to get
        # two try blocks would rewrite the most safety-critical code in the
        # installer for the benefit of an analytics label.
        _stage, _stage_t0 = "download", time.time()
        tmp = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)
        # Extract into a private empty dir, not self.dest: the "unwrap one
        # top-level dir" check must only ever see the tarball's own entries.
        # Anything already in dest (.env from a dry run, .venv from a retry)
        # would defeat the len==1 check and leave everything nested.
        extract_dir = tempfile.mkdtemp(prefix=".sabr-extract-", dir=self.dest)
        try:
            try:
                with _urlopen(url, timeout=120) as r:
                    total = 0
                    try:
                        total = int(r.headers.get("Content-Length") or 0)
                    except Exception:
                        total = 0
                    got, last_pct = 0, -5
                    hasher = hashlib.sha256()
                    _log(f"downloading {url} ({total} bytes)")
                    while chunk := r.read(1 << 20):
                        tmp.write(chunk)
                        hasher.update(chunk)
                        got += len(chunk)
                        # Silence for 350MB reads as a hang. Report progress.
                        if total:
                            pct = int(got * 100 / total)
                            if pct >= last_pct + 2:
                                last_pct = pct
                                self.say(f"Downloading your SI… {pct}% "
                                         f"({got >> 20} of {total >> 20} MB)")
                        elif got >> 20 != last_pct:
                            last_pct = got >> 20
                            self.say(f"Downloading your SI… {last_pct} MB")
                    _log(f"downloaded {got} bytes")
            finally:
                tmp.close()  # Windows can't unlink an open handle

            # A connection that dies mid-stream looks exactly like success to
            # the loop above — it just stops yielding chunks. Catch it here so
            # the customer gets "your connection dropped, try again" instead of
            # a baffling corrupt-archive traceback.
            if total and got != total:
                raise InstallError(
                    f"The download stopped early ({got >> 20} of {total >> 20} MB). "
                    "Your connection dropped — nothing was installed. Try again.")

            if not expected_sha:
                raise InstallError("The server did not send a fingerprint for "
                                   "your SI, so it can't be verified. Nothing "
                                   "was installed. Contact support.")
            actual_sha = hasher.hexdigest()
            _log(f"sha256 expected={expected_sha} actual={actual_sha}")
            if actual_sha != expected_sha:
                raise InstallError(
                    "The downloaded SI doesn't match its fingerprint, so it was "
                    "discarded and nothing was installed. This is usually a "
                    "corrupted download — try again. If it keeps happening, "
                    "stop and contact support.")

            # The bytes are here AND they are the bytes the server published.
            # That, and not "the socket closed", is what "download ok" means.
            telemetry_event("download", "ok",
                            duration_ms=int((time.time() - _stage_t0) * 1000))
            _stage, _stage_t0 = "extract", time.time()

            with tarfile.open(tmp.name, "r:gz") as tar:
                # Python ≥3.12 (and backports) require an explicit filter.
                # Where it's missing, fail closed rather than silently doing an
                # unfiltered extractall — an archive with ../ or absolute paths
                # would otherwise write outside extract_dir. Customer machines
                # run whatever Python they have, so this is not hypothetical.
                if hasattr(tarfile, "data_filter"):
                    tar.extractall(extract_dir, filter="data")
                else:
                    _safe_extractall(tar, extract_dir)
            entries = os.listdir(extract_dir)
            root = extract_dir
            if len(entries) == 1 and os.path.isdir(os.path.join(extract_dir, entries[0])):
                root = os.path.join(extract_dir, entries[0])
            # BEFORE the old install is touched: is this payload even the
            # shape of something that can run? The digest above proves the
            # bytes are the ones the server published; it cannot prove the
            # build was complete. _entry_cmd already refuses a payload with
            # no entry point — but it runs AFTER the swap, when the old
            # install is already gone. Refuse here instead, while refusing
            # still costs nothing.
            if not os.path.exists(os.path.join(root, "run.py")):
                raise InstallError(
                    "The downloaded release is missing its main program "
                    "(run.py), so it was not installed. Your current install "
                    "is untouched. This is our packaging error — contact "
                    "support and mention 'run.py missing from release'.")
            self._swap_payload(root)
            # Stamp what we just verified. bootstrap.sh has always written this
            # (landing/bootstrap.sh:915); this installer never did — so every
            # customer who installed via the downloaded EXE/app was permanently
            # update-blind. auto_update.installed_release() reads exactly this
            # key, gets "" for an unstamped install, and returns silently, so
            # nothing ever told them a newer release existed and nothing could
            # answer "what version are you running?" during support.
            # The digest is verified by this point, so this records a fact.
            if expected_sha:
                try:
                    with open(os.path.join(self.dest, ".sabr-release"), "w",
                              encoding="utf-8") as fh:
                        fh.write(f"release_sha256={expected_sha}\n")
                        fh.write("installed_at=" + time.strftime(
                            "%Y-%m-%dT%H:%M:%SZ", time.gmtime()) + "\n")
                except OSError:
                    pass  # a missing stamp must never fail a good install
            # After the swap: the payload is unpacked, verified, in place and
            # has an entry point. Anything short of that is not "extract ok".
            telemetry_event("extract", "ok",
                            duration_ms=int((time.time() - _stage_t0) * 1000))
        except InstallError as e:
            telemetry_event(_stage, "fail", error=e,
                            duration_ms=int((time.time() - _stage_t0) * 1000))
            raise
        except Exception as e:
            telemetry_event(_stage, "fail", error=e,
                            duration_ms=int((time.time() - _stage_t0) * 1000))
            raise InstallError(f"Download failed: {e}")
        finally:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass  # never mask the real error with a cleanup failure
            shutil.rmtree(extract_dir, ignore_errors=True)

    #: Never replaced from a release archive and never moved during a swap.
    #: A customer's whole life is in brain_state, their identity and keys are
    #: in .env, and .venv is hours of pip work a retry should not repeat.
    #: build_release.sh excludes brain_state/.env from the tarball — a
    #: build-time invariant enforced in a different file. The day one bad
    #: build includes brain_state, the sha256 check would VERIFY that build
    #: as authentic and a naive swap would replace everything the customer
    #: has accumulated, silently, on a routine update. Refuse here
    #: regardless of what the archive says.
    _NEVER_REPLACE = ("brain_state", ".env", ".venv")

    def _swap_payload(self, root: str) -> None:
        """Move the verified payload from its staging dir into self.dest —
        without ever destroying an old file before its replacement is ready.

        THE BUG THIS REPLACES (a tester's Windows box, 2026-08). The old loop
        went item by item: `shutil.rmtree(old)` then `os.replace(new)`. On
        Windows the rmtree is a minefield — the SI not fully stopped, an
        antivirus scan, a file open in an editor, a read-only attribute —
        and rmtree does not fail atomically: it deletes what it can and
        raises on what it cannot. One locked file mid-update meant a tree
        that was part new, part old, part GONE, and the `finally` above then
        deleted the staged new files too. That is exactly the install that a
        re-run of UPDATE kept failing on and only a full reinstall healed.

        So, three phases, none destructive until everything has worked:

          1. RENAME every existing target aside into one .sabr-old-* dir
             (same volume, pure renames). A rename either happens or it
             does not — nothing is ever half-deleted. A locked tree fails
             HERE, before anything has been touched, and the rollback below
             puts back the few renames that did land.
          2. RENAME the new items into place. Same-volume renames again
             (the staging dir is created inside dest for exactly this
             reason).
          3. Only after every item landed: delete the set-aside old copies.

        Any failure in 1 or 2 rolls back every rename, so the customer's
        working install survives the failed update byte for byte, and
        running UPDATE again is always a fresh, clean attempt — idempotent
        by construction. brain_state, .env and .venv are never part of the
        swap at all (_NEVER_REPLACE), so the SI's accumulated life cannot
        be lost here even if every other safeguard fails.
        """
        items = [i for i in os.listdir(root) if i not in self._NEVER_REPLACE]
        for skipped in self._NEVER_REPLACE:
            if os.path.exists(os.path.join(root, skipped)):
                _log(f"refusing to replace {skipped} from release archive")
        aside = tempfile.mkdtemp(prefix=".sabr-old-", dir=self.dest)
        moved = []   # (live target, parked old copy)
        placed = []  # (staged source, live target)
        try:
            for item in items:
                target = os.path.join(self.dest, item)
                if os.path.lexists(target):
                    parked = os.path.join(aside, item)
                    _replace_with_retries(target, parked,
                                          f"Updating {item}")
                    moved.append((target, parked))
            for item in items:
                target = os.path.join(self.dest, item)
                _replace_with_retries(os.path.join(root, item), target,
                                      f"Installing the new {item}")
                placed.append((os.path.join(root, item), target))
        except BaseException:
            # Put the old install back, whole. New items return to staging
            # first (freeing their targets), then every parked old item goes
            # home. Best-effort per item and LOGGED per item: a rollback
            # that throws away the remaining renames over one failure would
            # recreate the exact half-torn state this function exists to
            # prevent. Nothing is deleted on this path — even a rename that
            # fails leaves both copies on disk, recoverable by hand.
            for src, target in reversed(placed):
                try:
                    os.replace(target, src)
                except OSError as e:
                    _log(f"[rollback] could not unwind new {target}: {e}")
            for target, parked in reversed(moved):
                try:
                    os.replace(parked, target)
                except OSError as e:
                    _log(f"[rollback] could not restore old {target}: {e}")
            raise
        # Commit — every new item is in place; the old copies are now junk.
        # ignore_errors: a locked leftover must not fail a good update (the
        # sweep at the top of download_release clears it next run anyway).
        shutil.rmtree(aside, ignore_errors=True)

    def _repair_windows_acls(self):
        """Make the freshly-extracted tree readable by the human who will run it.

        On Windows, a process running ELEVATED creates files owned by
        BUILTIN\\Administrators, and the default ACL that lands on them has an
        OWNER RIGHTS entry, SYSTEM, and Administrators — and NO entry for the
        actual user account. That tree is unreadable from the owner's ordinary
        desktop session.

        The failure mode is vicious because nothing reports it. The install
        finishes green. Autostart registers fine. Then at every logon the
        supervisor launches, python opens run.py, and gets:

            can't open file '...\\SabrSI\\run.py': [Errno 13] Permission denied

        ...forever, in a retry loop, with the only evidence buried in a log
        the customer has no reason to open. It reads as "the product just
        doesn't work on my machine."

        Observed for real on 2026-08-11: an install placed by an elevated
        session left the whole tree owned by Administrators and the SI could
        not start from the owner's own session until ownership and an explicit
        user ACE were restored across 53,494 files.

        So: never assume the installer was launched unelevated. Repair
        unconditionally, right after extraction and before anything tries to
        run. Best-effort — a failure here must never fail an otherwise good
        install, because on an unelevated install this is already correct and
        the repair is a no-op.
        """
        if not IS_WINDOWS or self.dry:
            return
        # THE REPAIR USED TO REPORT SUCCESS WHILE DOING NOTHING TO FILES.
        # Measured on Aiden's Windows 11 box 2026-08-12: 768 of 771 payload
        # files carried a PROTECTED DACL granting only SYSTEM and
        # Administrators — the owner had no ACE at all and could not read his
        # own install — while every DIRECTORY was correct. That split is the
        # tell. The single grant below used (OI)(CI), which are INHERITANCE
        # flags: meaningful on a container, meaningless on a leaf. icacls
        # applies it to directories, skips it on files, and /C makes it
        # continue quietly. So the log line said "ACL repair applied" and the
        # files it was supposed to fix were untouched.
        #
        # Three changes: grant by SID literal (a bare or even qualified name
        # can resolve against the machine account on a box whose computer
        # name equals the user name — "name your PC after yourself" is the
        # Windows default); run a SECOND pass with no inheritance flags so
        # leaf files actually get an ACE; and VERIFY by reading a real file
        # afterwards, because icacls exits 0 having changed nothing.
        user = os.environ.get("USERNAME") or ""
        if not user:
            return
        computer = os.environ.get("COMPUTERNAME") or ""
        account = f"{computer}\\{user}" if computer else user
        principal = _current_user_sid() or account
        try:
            # takeown first: if the tree is owned by Administrators, the
            # OWNER RIGHTS ACE grants THEM, not the human, and a grant alone
            # can be refused. /D Y answers the "take ownership?" prompt.
            subprocess.run(["takeown", "/F", self.dest, "/R", "/D", "Y"],
                           check=False, capture_output=True, timeout=900,
                           env=_clean_env())
            passes = (
                # re-enable inheritance: undoes the protected (P) DACL that
                # blocked the user in the first place
                ["/inheritance:e", "/T", "/C", "/Q"],
                # containers, with inheritance for anything created later
                ["/grant", f"{principal}:(OI)(CI)F", "/T", "/C", "/Q"],
                # leaves — no inheritance flags, or icacls skips every file
                ["/grant", f"{principal}:F", "/T", "/C", "/Q"],
            )
            for args in passes:
                subprocess.run(["icacls", self.dest] + args, check=False,
                               capture_output=True, timeout=900,
                               env=_clean_env())
            _log(f"ACL repair applied for {principal} on {self.dest}")
        except (OSError, subprocess.SubprocessError) as e:
            _log(f"ACL repair skipped ({e}) — install continues")
            return
        self._verify_readable()

    def _verify_readable(self) -> None:
        """Prove the repair worked instead of trusting icacls' exit code.

        Without this the install marches on into "Setting up Python
        environment" and dies somewhere far away from the real cause, or
        worse, finishes and the SI can't read its own code at first boot.
        """
        if not IS_WINDOWS:
            return
        unreadable = 0
        checked = 0
        for root, _dirs, files in os.walk(self.dest):
            for name in files:
                if not name.endswith((".py", ".json", ".txt")):
                    continue
                checked += 1
                if not os.access(os.path.join(root, name), os.R_OK):
                    unreadable += 1
                if checked >= 40:
                    break
            if checked >= 40:
                break
        if unreadable:
            sid = _current_user_sid() or os.environ.get("USERNAME", "")
            raise InstallError(
                f"{unreadable} of the {checked} files just installed to "
                f"{self.dest} can't be read by this account, so the SI could "
                f"not start. Fix it with:  icacls \"{self.dest}\" /grant "
                f"\"*{sid}:(F)\" /T" + _log_hint())
        _log(f"ACL verify: {checked} sampled files readable")

    def write_env(self):
        self.say("Writing your configuration…")
        cfg = self.cfg
        # Read the existing .env FIRST. Several decisions below have to defer
        # to what is already installed on this machine, and they cannot do
        # that if the file is read after the new one is composed.
        env_path = os.path.join(self.dest, ".env")
        prior = {}
        try:
            with open(env_path, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, _, v = line.partition("=")
                        prior[k.strip()] = v.strip()
        except OSError:
            pass          # fresh box, or unreadable — everything below mints new.

        # AN EXISTING INSTALL'S BRAIN MODE WINS. Fixed 2026-08-11; this was the
        # worst bug in the update path and it was completely silent.
        #
        # This line used to be cfg.get('brain_mode', 'hosted'). If the server's
        # onboarding config omitted brain_mode for a tenant, an UPDATE of a
        # working LOCAL install rewrote it to hosted. Mode decides the entry
        # point (_entry_cmd), so autostart got repointed from run.py to
        # run_body.py against a remote brain — and the local brain_state on
        # that machine, the SI's entire accumulated life, became a directory
        # nothing opens. On the box this was found on that was 270,805 steps.
        # No error, no prompt. The SI comes back up, answers, and remembers
        # nothing, and there is no way for the owner to know why.
        #
        # The carry-forward loop further down could never save it either:
        # LEON_BRAIN_MODE is in `_ours`, so the prior value was explicitly
        # skipped. It needs the same rescue LEON_API_KEY already gets.
        brain_mode = (cfg.get("brain_mode")
                      or prior.get("LEON_BRAIN_MODE")
                      or "hosted")
        cfg["brain_mode"] = brain_mode
        lines = [
            f"# Sabr SI — {cfg.get('si_name','')} for {cfg.get('user_name','')}",
            # Identity, with a floor under it. An empty LEON_USER_NAME is not
            # cosmetic: the SI addresses its owner as "" and its STT prompt
            # loses the one proper noun it hears most. Dean's own box shipped
            # with LEON_USER_NAME= because the tenant record carried no
            # user_name. Prefer the server, then whatever is already
            # installed, then the actual account name on this machine.
            f"LEON_SI_NAME={cfg.get('si_name') or prior.get('LEON_SI_NAME') or 'Leon'}",
            f"LEON_USER_NAME={cfg.get('user_name') or prior.get('LEON_USER_NAME') or _os_account_name()}",
            f"LEON_TENANT_TOKEN={cfg.get('_token','')}",
            # The SAME token under the name the entitlement gate actually
            # reads. brain/cognition_gate.py and brain/tenant.py look for
            # SABR_TENANT_TOKEN; every installer except bootstrap.sh wrote
            # only LEON_TENANT_TOKEN, so the gate saw an unlicensed machine
            # on every GUI install. Two names for one value is the bug, but
            # renaming a key read in the field breaks live installs — write
            # both, and let the reader be wrong quietly instead of the
            # customer being locked out loudly.
            f"SABR_TENANT_TOKEN={cfg.get('_token','')}",
            f"LEON_BRAIN_MODE={brain_mode}",
        ]
        # The dashboard login key. This MUST be written here, in every mode,
        # and MUST be the value we show the owner at the end of the install.
        #
        # It used to be written only in hosted mode. In local mode run.py's
        # first boot generated one itself and appended it to .env — so the
        # key the owner was told to paste was a value that had never existed,
        # and the login screen said "dashboard key invalid" on a completely
        # healthy install. Generating it up here means there is exactly one
        # key, we know it, and run.py's auto-generate branch never fires.
        #
        # AND ON A REINSTALL, REUSE THE KEY THAT IS ALREADY THERE. Fixed
        # 2026-08-11, the same defect one layer over from the one above. This
        # branch minted a fresh token on EVERY run and then rewrote .env from
        # scratch, so choosing UPDATE / REINSTALL — the thing an owner does
        # when something looks wrong — silently invalidated the key they had
        # already saved, and the login screen said "dashboard key invalid" on
        # an install that was otherwise perfectly healthy. Same user-visible
        # symptom as the bug above, opposite cause, so fixing one looked like
        # fixing both. It did not.
        api_key = ((cfg.get("hosted", {}) or {}).get("api_key")
                   or prior.get("LEON_API_KEY") or "")
        if not api_key:
            api_key = secrets.token_urlsafe(32)
        cfg["dashboard_key"] = api_key
        lines.append(f"LEON_API_KEY={api_key}")
        if cfg.get("brain_mode") == "hosted":
            hosted = cfg.get("hosted", {})
            lines.append(f"LEON_BRAIN_URL={hosted.get('brain_url','')}")
        # Bind loopback only. The brain's own default is 0.0.0.0, which is
        # right for a firewalled server and wrong for someone's personal
        # machine: it makes Windows Defender raise a "allow python.exe on
        # public networks" prompt on first launch, and a careful owner
        # clicks Block — which firewalls the SI off from its own dashboard.
        lines.append("LEON_HOST=127.0.0.1")
        if cfg.get("elevenlabs_voice_id"):
            lines.append(f"ELEVENLABS_VOICE_ID={cfg['elevenlabs_voice_id']}")
        for key, val in (cfg.get("service_keys") or {}).items():
            if val and key.replace("_", "").isalnum():
                lines.append(f"{key}={val}")
        # ── RUNTIME DEFAULTS: think, hear, speak ─────────────────────────
        # Added 2026-08-12 after Dean's own Windows box. Everything above
        # this line is identity and auth — which is ALL this installer used
        # to write. The generated .env had no model settings, no speech
        # settings and no STT settings whatsoever, and the failure is not a
        # crash: the responder falls back to the cheapest model, every turn
        # spawns a cold process, and the SI answers in two-word fragments
        # while the dashboard spins with no error frame. Looks brain-damaged,
        # reads as "the product is bad."
        #
        # install_client.py has emitted this block for a while and there is a
        # regression test pinning it (tests/test_install_env_completeness.py)
        # — but that test reads install_client.py, and THIS is the installer
        # customers actually run. One guarded path, one unguarded path, and
        # the shipping one was the unguarded one. The test now covers both.
        #
        # prior wins on every key: an owner who tuned a value in the
        # dashboard keeps it through an update. These are floors, not policy.
        for key, val in (
            # Thinking. Absent -> cheapest model -> fragment replies.
            ("LEON_MODEL", "claude-opus-4-7"),
            ("LEON_CLI_MODEL", "opus"),
            ("LEON_CLI_DAEMON_MODEL", "sonnet"),
            ("LEON_CLI_CHITCHAT_MODEL", "opus"),
            ("LEON_DISTILL_WINDOW", "40"),
            # Absent -> cold process per turn -> the forever-spinner.
            ("LEON_PERSISTENT_CLAUDE", "1"),
            # Local model is a BACKUP, never the voice of a real
            # conversation. Inert until ollama is present; provision_local_llm
            # arms it during install.
            ("LEON_LOCAL_LLM_MODE", "fallback"),
            ("LEON_LOCAL_MODEL", "llama3.2:3b"),
            # Hearing. faster-whisper ships in requirements.txt, so it works
            # offline on a stock box; preferring a cloud backend with no key
            # makes every boot initialise something that cannot work.
            ("LEON_STT_PREFER", "faster-whisper"),
            # Bias the transcriber toward the two proper nouns it hears more
            # than any other words. Without it "Leon" comes back as "Leanne".
            ("LEON_STT_INITIAL_PROMPT",
             f"{cfg.get('si_name') or 'Leon'}, "
             f"{cfg.get('user_name') or _os_account_name()}, dashboard, "
             f"neural, synapse, restart."),
            # Boot calm. A fresh SI with goal pursuit on starts driving tools
            # and terminals before its owner has configured anything. Flip
            # this to 0 in .env once you want it acting on its own — the same
            # default install_client.py has shipped for months.
            ("LEON_DISABLE_GOAL_PURSUIT", "1"),
            # ALWAYS-LISTENING STARTS OFF ON A FRESH INSTALL (2026-08-12).
            #
            # The wake listener triggers on the SI's own name, and the first
            # thing two people do with a newly born SI is talk ABOUT it —
            # "did Iris boot?", "ask Iris". Every one of those sentences woke
            # it mid-conversation on Aiden's install. A brand-new owner has
            # also had zero chance to learn the controls, so an open mic is
            # the worst possible default: it is the one setting that can
            # embarrass someone in front of other people.
            #
            # Push-to-talk still works — it is deliberately independent of
            # this flag — so the SI is fully usable on day one, and the
            # toggle in the dashboard turns listening on the moment the
            # owner wants it. Because `prior` wins on every key in this
            # block, an owner who switches it on KEEPS it on through every
            # future update; this only ever governs a first install.
            ("LEON_WAKE_ENABLED", "0"),
            # Speech. Piper is bundled and free; ElevenLabs only when the
            # owner actually supplied a key, otherwise the ladder tries a
            # locked door first on every single utterance.
            ("LEON_TTS_PREFER",
             "elevenlabs" if (cfg.get("service_keys") or {}).get(
                 "ELEVENLABS_API_KEY") else "piper"),
            # Hands. Where the brain and the body meet.
            #
            # leon_transport picks this directory itself when the variable is
            # unset, and its guesses are AMBIENT: %LOCALAPPDATA%\SabrSI on
            # Windows, $XDG_RUNTIME_DIR (else the temp dir) on POSIX. Both
            # halves have to land on the same answer or the rendezvous file
            # the body writes is not the one the brain reads — and the brain's
            # response to "nothing is listening locally" is to fall back to
            # the 127.0.0.1:9100 PC relay, which exists on no customer
            # machine. Every hand tool then fails with WinError 10061 while a
            # perfectly healthy actuator sits there with 250 tools loaded.
            #
            # $XDG_RUNTIME_DIR is exactly the kind of variable that is set
            # under a systemd --user unit and absent over a bare SSH login, so
            # "both halves guess the same" is a coincidence, not a guarantee.
            # Pin it and it stops being either.
            #
            # self.dest, not a subdirectory: on a default Windows install
            # dest IS %LOCALAPPDATA%\SabrSI (see default_install_dir), so this
            # writes leon-actuator.rendezvous.json to the identical path the
            # known-good install on Dean's box uses. Byte-for-byte the layout
            # that already works; the pin only changes the non-default cases,
            # which are the ones that were broken.
            ("LEON_ACTUATOR_DIR", self.dest),
        ):
            if key not in prior:
                lines.append(f"{key}={val}")
        # Carry forward anything the OWNER added by hand or through the
        # dashboard's Integrations panel. The wizard never asks for these a
        # second time, so rewriting the file without them is a silent delete
        # of credentials the installer did not put there and cannot restore.
        #
        # THIS MUST RUN LAST. It used to run before LEON_HOST / LEON_BRAIN_URL
        # / ELEVENLABS_VOICE_ID / service_keys were appended, so those keys
        # were not yet in `_ours`. On a reinstall the prior value was carried
        # forward as if the owner had typed it, and then the installer appended
        # its own copy — a duplicate that grew by one line on EVERY reinstall.
        # Found on Dean's Windows box 2026-08-11: two LEON_HOST lines after one
        # UPDATE / REINSTALL. Harmless while the values agree; a silent
        # last-line-wins conflict the moment they don't.
        _ours = {ln.split("=", 1)[0] for ln in lines if "=" in ln}
        for k, v in prior.items():
            if k not in _ours and k.replace("_", "").isalnum() and v:
                lines.append(f"{k}={v}")
        # env_path was resolved above, where the previous file is read.
        # utf-8 pinned: these lines carry si_name/user_name from the
        # server, so an accented name written under a Windows locale
        # produces bytes python-dotenv cannot read.
        with open(env_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        if not IS_WINDOWS:
            os.chmod(env_path, 0o600)

    def _venv_python(self, venv_dir: str) -> str:
        exe = "python.exe" if IS_WINDOWS else "python"
        return os.path.join(venv_dir, "Scripts" if IS_WINDOWS else "bin", exe)

    def _ensure_long_paths(self, venv_dir: str) -> None:
        """Windows MAX_PATH. The venv contains paths past 260 characters.

        MEASURED on a real install, not inferred: this file exists on a live
        Windows box at 272 characters --

          %LOCALAPPDATA%\\SabrSI\\.venv\\Lib\\site-packages\\elevenlabs\\
          pronunciation_dictionaries\\rules\\types\\__pycache__\\
          body_set_rules_on_the_pronunciation_dictionary_v_1_...cpython-312.pyc

        -- and it works there only because that machine happens to have
        LongPathsEnabled=1 set by something unrelated. The Windows DEFAULT is
        0/absent. Nothing in this repo ever set it (grep for LongPathsEnabled
        returned zero matches before this change), and the silent Python
        bootstrap passes InstallAllUsers=0 with no long-path option.

        So on a normal customer machine pip hits WinError 206 partway through
        site-packages. Some of those failures land in the one-at-a-time
        fallback, which reports "everything else is in, your SI runs" -- an
        install that claims success and is broken at first boot. A longer
        Windows username makes it worse; the box this was measured on has an
        8-character one.

        Setting the key needs admin and this installer deliberately does not
        require it. So: try, and if we cannot, say so plainly instead of
        walking into a silently truncated venv. A warning the customer can act
        on beats a success message that is a lie.
        """
        if not IS_WINDOWS:
            return
        # Only worth the noise if this install actually has a path at risk.
        # 260 is the classic MAX_PATH; the deepest known package path adds
        # roughly 200 characters past the venv root.
        projected = len(os.path.abspath(venv_dir)) + 200
        try:
            import winreg
            key_path = r"SYSTEM\CurrentControlSet\Control\FileSystem"
            enabled = 0
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0,
                                    winreg.KEY_READ) as k:
                    enabled = int(winreg.QueryValueEx(k, "LongPathsEnabled")[0])
            except OSError:
                enabled = 0          # absent == disabled, which is the default
            if enabled == 1:
                _log("long paths already enabled")
                return
            _log(f"LongPathsEnabled={enabled}; projected venv path ~{projected} chars")
            try:
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0,
                                    winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, "LongPathsEnabled", 0,
                                      winreg.REG_DWORD, 1)
                _log("enabled LongPathsEnabled=1")
                self.say("Turned on Windows long-path support — some of the "
                         "files your SI needs have names longer than Windows "
                         "allows by default.")
                return
            except PermissionError:
                pass
            except OSError as e:
                _log(f"could not set LongPathsEnabled: {e}")
        except Exception as e:                     # winreg missing, odd build
            _log(f"long-path check failed: {type(e).__name__}: {e}")
            return
        if projected > 260:
            # Loud, specific, and actionable. Not fatal: pip may still get
            # through if the customer's username is short enough.
            self.say(
                "Heads up — Windows long file name support is switched off on "
                "this PC, and some of the files your SI needs have names "
                "longer than Windows allows by default. The install will try "
                "anyway, but if it fails partway through, that is why. To fix "
                "it: run this once in PowerShell as Administrator, then "
                "install again — "
                "Set-ItemProperty 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\"
                "FileSystem' -Name LongPathsEnabled -Value 1"
            )
            _log("WARNING: long paths disabled and cannot be enabled "
                 "(not elevated); pip may fail with WinError 206")

    def _build_venv(self, py: str, venv_dir: str) -> str:
        """Create the venv, and if the normal way fails, try the ways that
        survive the machines where it fails. Returns the venv's python."""
        self._ensure_long_paths(venv_dir)
        # A half-built venv from a previous failed attempt poisons retries.
        # Presence of python.exe is NOT proof the env works: a venv whose
        # pyvenv.cfg "home=" points at an interpreter the customer has since
        # uninstalled or upgraded keeps its python.exe stub, and every single
        # invocation of it fails. Presence-only checks reused that corpse and
        # reported a successful install on top of it. Run it before trusting it.
        if os.path.isdir(venv_dir):
            vpy = self._venv_python(venv_dir)
            dead = not os.path.exists(vpy)
            if not dead:
                try:
                    r = subprocess.run(
                        [vpy, "-c", "import sys, pip"],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                        timeout=60,
                    )
                    dead = r.returncode != 0
                    if dead:
                        _log("existing venv interpreter is broken: "
                             + r.stdout.decode("utf-8", "replace")[-400:])
                except Exception as e:
                    dead = True
                    _log(f"existing venv interpreter did not run: {e}")
            if dead:
                _log(f"removing unusable venv at {venv_dir}")
                shutil.rmtree(venv_dir, ignore_errors=True)
            else:
                # THE UPDATE-ONLY BUG (a tester's Windows box, 2026-08-26): a
                # venv that already works has no reason to be recreated, and
                # recreating it is not free. Falling through to the attempts
                # loop below runs `-m venv` on TOP of this directory anyway,
                # and CPython's venv module unconditionally re-copies
                # python.exe (and its DLLs, in --copies mode) into Scripts/
                # even when the target already exists — on Windows that is
                # the SAME file the SI process we just stopped
                # (_stop_si_before_overwrite, moments earlier, in
                # run_install) had open as its own running image. If Windows
                # or antivirus real-time scanning has not yet released that
                # handle — exactly the sharing-violation race
                # _replace_with_retries exists to ride out for the payload
                # swap — this copy fails with WinError 32, and `_run` has no
                # retry. All three fallback attempts recreate the identical
                # venv and re-copy the identical locked file, so they fail
                # the identical way and the whole update dies here.
                #
                # A fresh install (or a full uninstall-then-reinstall) never
                # hits this: venv_dir does not exist yet, `-m venv` runs
                # once against an empty directory with nothing to lock, and
                # that is why "wipe it and reinstall" was the only reliable
                # workaround — it does not fix anything, it just avoids
                # touching a venv that was never the problem. Nothing here
                # needs to change on a healthy update, so nothing should
                # touch it: return the interpreter that already works.
                _log(f"reusing verified venv at {venv_dir}")
                return vpy
        attempts = [
            (["-m", "venv", venv_dir], "Creating the Python environment"),
            # --copies: symlink creation needs Developer Mode or admin on
            # Windows, and fails on some network/OneDrive-backed profiles.
            (["-m", "venv", "--copies", venv_dir], "Creating the Python environment (copy mode)"),
            # No ensurepip on Debian/Ubuntu without python3-venv installed —
            # build the bare env, then bootstrap pip by hand.
            (["-m", "venv", "--without-pip", "--copies", venv_dir],
             "Creating the Python environment (minimal)"),
        ]
        last = None
        for argv, what in attempts:
            self.say(what + "…")
            try:
                _run([py] + argv, what)
            except InstallError as e:
                last = e
                _log(f"attempt failed, trying next: {e}")
                shutil.rmtree(venv_dir, ignore_errors=True)
                continue
            vpy = self._venv_python(venv_dir)
            if not os.path.exists(vpy):
                last = InstallError(f"{what} reported success but produced no "
                                    f"interpreter at {vpy}." + _log_hint())
                shutil.rmtree(venv_dir, ignore_errors=True)
                continue
            if "--without-pip" in argv:
                self.say("Bootstrapping the package installer…")
                try:
                    _run([vpy, "-m", "ensurepip", "--upgrade"], "Bootstrapping pip")
                except InstallError:
                    self._get_pip(vpy)
            return vpy
        raise last or InstallError("Could not create the Python environment."
                                   + _log_hint())

    def _get_pip(self, vpy: str) -> None:
        """Last-resort pip bootstrap for envs with no ensurepip."""
        tmp = os.path.join(tempfile.gettempdir(), "get-pip.py")
        with _urlopen("https://bootstrap.pypa.io/get-pip.py", timeout=60) as r, \
                open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
        _run([vpy, tmp], "Bootstrapping pip")

    def install_deps(self):
        self.say("Setting up Python environment (this takes a few minutes)…")
        venv_dir = os.path.join(self.dest, ".venv")
        # "venv" and "deps" are reported separately because they fail for
        # completely different reasons and are fixed by completely different
        # people: no interpreter / no ensurepip / a broken standalone build
        # is ours, while a wheel that will not compile on one customer's
        # machine is theirs. Rolled into one "deps failed" number, the two
        # are indistinguishable and neither is actionable. Note that the
        # enclosing `deps` step (Installer.run) also reports a failure when
        # this one does — deliberately: the summary reads "deps failed, and
        # it was the venv", not one number that hides the other.
        with _telemetry_step("venv"):
            py = _find_system_python(self.say)  # real interpreter, not our exe
            vpy = self._build_venv(py, venv_dir)
        # Always drive pip through the venv's own interpreter: the Scripts/pip
        # shim is absent in --without-pip envs and breaks if the path moves.
        pip = [vpy, "-m", "pip"]

        # PIP'S WHEEL CACHE CAN BE POISONED, AND IT KILLS THE WHOLE INSTALL
        # (2026-08-11, hit on a real Windows 10 box, user "Mr. Sabr").
        #
        # pip caches built wheels under %LOCALAPPDATA%\pip\cache\wheels. If a
        # single file in there is unreadable/unwritable — left over from an
        # install run under a different account, an interrupted write, or an
        # antivirus lock — pip does NOT skip it. It aborts the entire run with
        #   OSError: [Errno 13] Permission denied: '...\\pyautogui-...whl'
        # and every retry hits the same poisoned file, so the batch retry and
        # the per-package retry all die on the identical error. From the
        # customer's side the installer just refuses to work, forever, with a
        # message about a path they've never heard of.
        #
        # The cache is a speed optimisation and nothing else. So: when we see
        # a cache-permission failure, permanently switch this run to
        # --no-cache-dir and try again. Slower, always correct, and it cannot
        # be poisoned because it never touches the cache.
        cache_disabled = [False]

        def _pip_run(args, what, check=True):
            """pip, with automatic fallback off a poisoned wheel cache."""
            flags = ["--no-cache-dir"] if cache_disabled[0] else []
            res = _run(pip + args[:1] + flags + args[1:], what, check=False)
            if res.returncode != 0 and not cache_disabled[0] and \
                    _is_pip_cache_permission_error(res.stdout, res.stderr):
                cache_disabled[0] = True
                _log("pip wheel cache is unusable — retrying with --no-cache-dir")
                self.say("Working around a damaged package cache…")
                res = _run(pip + args[:1] + ["--no-cache-dir"] + args[1:],
                           what, check=check)
            elif check and res.returncode != 0:
                detail = (res.stderr or res.stdout or "").strip().splitlines()
                tail = " | ".join(detail[-3:])[:400] or f"exit {res.returncode}"
                raise InstallError(f"{what} failed: {tail}" + _log_hint())
            return res

        _pip_run(["install", "--upgrade", "pip", "wheel", "setuptools"],
                 "Updating the package installer", check=False)
        req = os.path.join(self.dest, "requirements.txt")

        # TORCH MUST COME FROM THE CPU INDEX, AND ONLY THIS FRONT END FORGOT.
        #
        # requirements.txt pins torch>=2.0 for the local-vision fallback and
        # carries a comment, on the line directly above the pin, telling the
        # installer to pass --index-url https://download.pytorch.org/whl/cpu.
        # install_client.py (the terminal path) does exactly that. This file —
        # the one PyInstaller freezes into SabrInstaller.exe, i.e. the only
        # thing a Windows beta tester ever runs — passed no index at all.
        # Verified 2026-08-12 by extracting the shipped .exe: zero occurrences
        # of whl/cpu anywhere in the frozen bytecode.
        #
        # Off plain PyPI, the Windows torch wheel is the CUDA build, and it
        # drags the nvidia-* CUDA runtime with it. Several GB, onto a machine
        # that may have no NVIDIA card, for a CPU-only feature. The likely
        # symptom is not "large download" — it is _run()'s 1800s timeout
        # firing mid-download and the whole install dying on
        # "Installing packages failed: ... timed out after 30 minutes."
        #
        # --extra-index-url would NOT fix this: pip takes the highest version
        # across all indexes and PyPI's CUDA build wins. The fix has to be to
        # satisfy torch FIRST, from the CPU index explicitly; the batch below
        # then finds the requirement already met and never reaches for PyPI.
        #
        # MEASURED, NOT ASSUMED (2026-08-12, pip --dry-run on this box):
        #   with the CPU index -> torch-2.13.0+cpu, 13 packages, no CUDA.
        #   without it         -> 18 nvidia-* CUDA runtime packages.
        # That is the download that eats the 1800s timeout.
        #
        # Applied on EVERY platform, including macOS. The first draft of this
        # fix guarded it with `not IS_MAC` on the belief that the CPU index
        # serves no darwin wheels. That belief was wrong -- the index lists
        # macosx_11_0_arm64 and macosx_14_0_arm64 wheels, and resolves clean.
        # A guard there would have been a second silent divergence between
        # platforms, which is the exact bug class this fix exists to close.
        self.say("Fetching the CPU build of torch…")
        _pip_run(["install", "torch>=2.0", "torchvision>=0.15",
                  "--index-url", "https://download.pytorch.org/whl/cpu"],
                 "Installing torch (CPU build)", check=False)

        self.say("Installing packages (a few minutes)…")
        r = _pip_run(["install", "-r", req], "Installing packages", check=False)
        if r.returncode != 0:
            # WHY THIS IS NOT A BATCH RETRY (2026-08-10, measured on a real
            # Windows 10 box running Python 3.14):
            #
            # `pip install -r` is all-or-nothing. pyaudio and webrtcvad ship
            # no cp314 wheels, so pip tried to compile them from C, hit
            # "Microsoft Visual C++ 14.0 or greater is required", and aborted
            # the WHOLE run. The old fallback then installed a bare 12-package
            # core — which silently dropped piper-tts, pyttsx3, onnxruntime,
            # sounddevice, soundfile, elevenlabs, deepgram-sdk, vosk,
            # webrtcvad and aiohttp. Every one of those installs fine.
            #
            # Result: a "successful" install with no voice, no wake word and
            # no audio at all, reported to the owner as "some optional
            # packages failed". Two bad packages took ten good ones with them.
            #
            # So: core first (it must succeed), then every remaining
            # requirement ONE AT A TIME so a single unbuildable package can
            # only ever cost you that one package — and we name the casualties
            # instead of hiding them behind the word "optional".
            self.say("Batch install failed — retrying package by package…")
            core = ["numpy", "scipy", "fastapi", "uvicorn[standard]", "websockets",
                    "python-multipart", "python-dotenv", "Pillow", "mss", "psutil",
                    "pyautogui", "anthropic"]
            # EVERY one-at-a-time install is constrained by the full
            # requirements set. Found on Dean's box 2026-08-12: he had
            # transformers 5.15.0 installed even though requirements.txt
            # pins transformers>=4.40,<5 — because `pip install -r` never
            # completed, and in THIS loop each package resolves alone, so a
            # later package that merely tolerates transformers 5 happily
            # upgraded past the pin behind us. The pin held on paper and lost
            # on disk. Symptom on his machine: "[VISION] load failed:
            # cannot import name 'AutoModelForCausalLM'" — the SI came up
            # blind, and the pin's whole reason for existing (moondream2's
            # remote code dies on 5.x) was documented three feet away in the
            # requirements file. A constraints file makes the pin binding no
            # matter what order packages land in.
            cons = _write_constraints(req, self.dest)
            cflag = ["-c", cons] if cons else []
            _pip_run(["install", *cflag, *core], "Installing the core packages")
            rest = [p for p in _parse_requirements(req)
                    if _req_name(p) not in {_req_name(c) for c in core}]
            failed = []
            for spec in rest:
                rr = _pip_run(["install", *cflag, spec],
                              f"Installing {_req_name(spec)}", check=False)
                if rr.returncode != 0:
                    failed.append(_req_name(spec))
            if failed:
                self.say("Could not install: " + ", ".join(failed)
                         + " — everything else is in. Your SI runs; these "
                           "specific features stay off until they're fixed.")
            else:
                self.say("All packages installed on the second pass.")
        self.venv_python = vpy
        # Handed to provision_actuator() so the body's dependencies go in
        # through the SAME pip that just ran — same venv, same constraints,
        # and above all the same poisoned-wheel-cache fallback. A second,
        # simpler pip call there would be a second thing to fix the next time
        # a customer's cache goes bad, and it would fail in exactly the way
        # this one already knows how to survive.
        self._pip_run = _pip_run

    # ── the offline backup brain ──────────────────────────────────
    def provision_local_llm(self):
        """Arm the local fallback model, or say plainly that it isn't armed.

        write_env() has always written LEON_LOCAL_LLM_MODE=fallback and
        LEON_LOCAL_MODEL=llama3.2:3b, with a comment promising that
        "provision_local_llm arms it during install". That function did not
        exist. Nothing anywhere started ollama or pulled the model. So every
        install advertised an offline backup brain it did not have, and the
        only symptom was one line in a log the owner never reads:
        "Local LLM not available: probe failed".

        REVISED 2026-08-12 (Dean). The version above this comment refused to
        download ollama, on the theory that a multi-gigabyte fetch mid-install
        is a side quest. That reasoning only holds for someone who ALREADY has
        a cloud brain. Dean's own beta tester has a Claude subscription, so
        every test we ran exercised the happy path and the installer still
        announced success — while a customer with NO cloud key would finish
        the exact same install, see the same "ready", and own an SI with
        nothing behind it at all. The installer was telling everyone it would
        work because it only ever watched it work for people who didn't need
        this path.

        So: install ollama when it is missing. If there is no cloud brain
        configured, this is the brain and a failure here is a failed install
        that must SAY it failed. If there is a cloud brain, this is the
        offline backup and a failure is a warning, never fatal.

        MOVED 2026-08-12 into installer/local_brain.py. The policy above was
        correct but it lived HERE, as a method, reachable only from the GUI —
        so the terminal install path (bootstrap.sh -> setup.sh ->
        install_client.py) shipped the original bug untouched. Both front ends
        now call the same function. Do not re-inline this.
        """
        if not local_brain.provision(self.dest, self.cfg, say=self.say):
            # Only reached when there is no cloud brain AND no local one.
            # Do NOT let the finish screen say "ready" over this.
            self.failed_local_brain = True

    # _has_cloud_brain / _install_ollama used to live here. They moved to
    # installer/local_brain.py on 2026-08-12 so the terminal installer
    # shares them. Leaving dead copies behind is how the two paths
    # silently diverged before — a stale duplicate still reads as
    # correct. Call local_brain.* instead.

    def _detect_claude_login(self):
        """Say, in plain words, which Claude this install will think with.

        THE GAP THIS CLOSES (a customer's install, 2026-08-23): the terminal path
        has had an honest signed-in check since 2026-08-10; the GUI — the
        thing a customer actually double-clicks — never checked at all. So a
        machine with Claude Code installed and signed in sailed through the
        GUI in silence, hit the no-brain gate at the end, and was told to go
        add an API key. The customer had to discover on his own that opening
        a terminal and signing in to claude was the actual fix.

        Purely advisory — never fatal, never blocks. provision_local_llm and
        the final brain gate still decide what the install IS; this step just
        stops the installer from being silent about the one connection the
        customer most cares about.
        """
        name = self.cfg.get("si_name", "your SI")
        try:
            exe = local_brain.find_claude()
            if not exe:
                # Used to say nothing here: "no claude on the box" was
                # treated as a normal state the API-key/ollama paths would
                # cover. But Claude Code IS the primary brain this product
                # is built to think on — a customer who never gets asked
                # shouldn't have to already know to go install it. Try, on
                # their behalf, before falling back to just saying so.
                # And if ~/.claude/.credentials.json exists, this machine
                # HAS signed in before — the program merely isn't findable
                # (deleted, or in a home find_claude doesn't know). Saying
                # "isn't on this machine yet" to that owner reads as "you
                # never signed in", which is false and corrosive.
                if local_brain.claude_credentials_present():
                    self.say("This machine is already signed in to Claude, "
                             "but the claude program itself couldn't be "
                             "found — reinstalling it now (up to a few "
                             "minutes)…")
                else:
                    self.say("Claude Code isn't on this machine yet — "
                             "installing it now (up to a few minutes)…")
                exe = local_brain.install_claude_code(self.say)
                if not exe:
                    self.say("Couldn't auto-install Claude Code — that's "
                              "fine, the install continues. Get it anytime "
                              "from claude.ai/code and this connects on "
                              "its own the next time your SI starts.")
                    return
                self.say("Claude Code installed.")
            self.say("Checking your Claude Code sign-in (up to a minute)…")
            if local_brain.claude_logged_in(exe):
                self.claude_verified = True
                self.say(f"Claude Code detected and signed in — "
                         f"{name} will think on your account. Nothing to "
                         f"paste.")
                return
            # Not signed in: open the actual sign-in flow FOR them instead
            # of describing it. a customer's install (2026-08-23) is the reason —
            # "open a terminal yourself, later" is a broken promise on a
            # product sold as terminal-free.
            self.say("Claude Code is installed but not signed in yet.")
            # SAY IT AFTER, NOT BEFORE (2026-08-24). This used to announce
            # "opening a sign-in window for you now" and then describe "the
            # window that just opened" — while the mac branch of
            # open_claude_login_terminal returned True unconditionally, so
            # on any Mac where the window did NOT appear (Apple Events
            # refused, no TCC grant) the installer narrated a window that
            # never existed. Only claim what the return value proves; on
            # False, give the exact manual step. Either way, poll — a
            # customer who opens Terminal themselves right now deserves the
            # same "picked it up the moment you're done" behavior.
            if local_brain.open_claude_login_terminal(exe):
                self.say("A sign-in window just opened — follow the "
                         "prompts there. This will pick it up the moment "
                         "you're done, no need to come back and tell it.")
            else:
                self.say("Couldn't open a sign-in window automatically on "
                         "this machine. Open the Terminal app yourself and "
                         "run: claude — complete the sign-in once, and "
                         "this will pick it up the moment you're done.")
            if local_brain.wait_for_claude_login(exe, self.say, timeout=180):
                self.claude_verified = True
                self.say(f"Signed in — {name} will think on your "
                         f"account.")
            else:
                self.say("Still not signed in — no rush. The install "
                         "finishes either way, and signing in whenever "
                         "you're ready (open the Terminal app, run: claude) "
                         "connects your SI automatically.")
        except Exception:
            # An advisory check must never take the install down with it.
            pass

    def _warn_if_stale_installer(self):
        """Say so when the customer is running an older .exe than we publish.

        THE FAILURE THIS PREVENTS (2026-08-12): a tester double-clicked the
        SabrInstaller.exe already sitting in his Downloads folder. It happily
        fetched the CURRENT payload — hash verified, every step green, ending
        in "<SI> is ready" — while silently skipping the steps that only the
        NEWER binary knows how to perform. The install was, from his side,
        a complete success that did not contain the fixes he was updating for,
        and there was nothing on screen or in the log to suggest otherwise.
        A reused installer is the normal thing for a person to do; being
        silent about it is our defect, not theirs.

        Deliberately a WARNING, not a gate. Advisory checks that can hard-fail
        an install on a network hiccup are worse than the problem they solve,
        so every failure path here is a no-op: no network, rate limited, an
        unparseable answer, a locally-run .py — all just proceed quietly.
        """
        if INSTALLER_BUILD == "dev":
            return                     # running the source; nothing to compare
        try:
            import urllib.request
            req = urllib.request.Request(
                "https://api.github.com/repos/47-Industries/"
                "sabr-installers/releases/latest",
                headers={"Accept": "application/vnd.github+json",
                         "User-Agent": "SabrInstaller"})
            with urllib.request.urlopen(req, timeout=8) as fh:
                latest = (json.loads(fh.read().decode()) or {}).get("tag_name")
        except Exception as exc:
            _log(f"stale-installer check skipped: {type(exc).__name__}: {exc}")
            return
        if not latest or latest == INSTALLER_BUILD:
            return
        _log(f"STALE INSTALLER: running {INSTALLER_BUILD}, latest {latest}")
        self.say(f"Heads up — this installer is build {INSTALLER_BUILD} and "
                 f"the current one is {latest}.")
        self.say("Your SI will still install and run. For the newest fixes, "
                 "download the installer again from sabrtechnologies.com and "
                 "re-run it — you will not lose anything.")

    # ── the body: hands, eyes, and the link between them ──────────
    def provision_actuator(self):
        """Put the packages the actuator needs where the actuator can find them.

        THE DEFECT (Aiden's "Iris", Windows 11, 2026-08-12). His SI booted,
        spoke, and had no hands: no screen_capture, no keyboard, no mouse, no
        file tools. Every diagnosis pointed at the actuator and the actuator
        was fine — it shipped in the tarball, run.py spawned it, it bound its
        socket and registered 250+ tools.

        What was missing was underneath it. `pip install -r requirements.txt`
        is all-or-nothing, and when it fails the installer falls back to
        installing packages ONE AT A TIME and then prints, of anything that
        did not make it, "Could not install: <names> — everything else is in.
        Your SI runs; these specific features stay off until they're fixed."
        If the names in that list happen to be mss, pyautogui or pygetwindow,
        "these specific features" means the SI's entire body, and the install
        goes on to say it is ready. The packages that decide whether an SI can
        touch its own machine were being treated as interchangeable with the
        other forty.

        So: install them again, deliberately, by name, and then IMPORT them
        with the SI's own interpreter to see whether they are really there.
        Cheap when requirements.txt already succeeded (pip says "already
        satisfied" and returns), decisive when it did not.

        Nothing here registers a startup entry, and that is on purpose. The
        SI's entry point already carries the body: run.py spawns
        leon-actuator/actuator.py as a child in local mode, run_body.py
        supervises it as a Child() in hosted mode, and the running process on
        the known-good Windows install is
            <dest>\\.venv\\Scripts\\python.exe <dest>\\leon-actuator\\actuator.py
        which is exactly what run.py's _spawn_actuator() emits. A second
        launcher — in sabr_si_run.bat, in the Startup folder, anywhere —
        would put two actuators on one machine, and run.py documents at
        length what that already cost once: concurrent writes to brain_state
        racing the shutdown save into PermissionError WinError 32, i.e. a
        product whose whole promise is a mind that persists, losing it.
        """
        act = os.path.join(self.dest, "leon-actuator", "actuator.py")
        if not os.path.exists(act):
            # Same class of failure as a missing run.py, and the same rule:
            # an entry point that is not on disk is an install failure, not a
            # detail. Not fatal though — a brain with no body still talks.
            self.no_body = "the body program is missing from this release"
            self.say("This release is missing the program that gives your SI "
                     "hands (leon-actuator) — it will be able to talk, but "
                     "not to see or touch anything on this computer.")
            _log(f"actuator source absent at {act}")
            return
        self.say("Installing your SI's hands…")
        # mss and Pillow are the eyes on every platform. Input differs:
        # Windows and macOS drive pyautogui; Linux drives the xdotool/wmctrl
        # binaries directly (see leon-actuator/platform_compat.py), which pip
        # cannot supply and which are checked below instead.
        # 2026-08-12: opencv + numpy belong in THIS list, not only in
        # requirements.txt. leon-actuator/camera_tools.py is the SI's real
        # webcam — DirectShow on Windows, AVFoundation on macOS, V4L2 on
        # Linux — and cv2 is the only thing it imports to reach the device.
        # requirements.txt does carry opencv-python-headless, but the pip
        # step there is all-or-nothing with a one-at-a-time fallback that
        # reports "everything else is in, your SI runs" over individual
        # failures. That is exactly how the hands shipped broken earlier
        # tonight. This list is the re-install-and-verify path, so a camera
        # dep that quietly failed upstream gets a second, checked chance.
        # If it still fails, camera_tools degrades to "opencv not installed"
        # rather than crashing — a legible error instead of a dead eye.
        deps = ["mss>=9.0.0", "Pillow>=10.0.0",
                "opencv-python-headless>=4.8.0", "numpy>=1.24.0"]
        if IS_WINDOWS:
            deps += ["pyautogui>=0.9.54", "pygetwindow>=0.0.9", "pyperclip>=1.8.2"]
        elif IS_MAC:
            # pyautogui's macOS backend is a pyobjc consumer; without Quartz
            # it imports and then fails on the first real call.
            # AVFoundation: platform_compat.mac_permissions asks it for the
            # camera/mic TCC authorization status. Without it that probe
            # silently returns None on every customer install, and a Mac
            # with the camera and mic switched OFF reads as "can't
            # determine" instead of naming the checkbox to tick.
            deps += ["pyautogui>=0.9.54", "pyobjc-framework-Quartz>=10.0",
                     "pyobjc-framework-AVFoundation>=10.0"]
        else:
            # requirements.txt gates pyautogui to win32/darwin, on the stated
            # grounds that "Linux does not need them: it drives xdotool/wmctrl
            # directly". That is true of the hand-written Linux paths in
            # actuator.py and false of the tools loaded from tools_extra.py —
            # mouse.position and friends call _ensure_pyautogui() on every
            # platform. Measured, not assumed: with xdotool present and
            # pyautogui absent, body.health reports input OK and
            # `mouse.position` still dies on ModuleNotFoundError. Install it
            # here; the marker in requirements.txt stays as it is, because
            # that file is also read on headless servers where the import
            # itself raises.
            deps += ["pyautogui>=0.9.54"]
        pip_run = getattr(self, "_pip_run", None)
        if pip_run is not None:
            pip_run(["install", *deps], "Installing desktop-control packages",
                    check=False)
        # PROVE IT. pip's exit code says the resolver was happy; it does not
        # say the SI's interpreter can import the module. Ask the interpreter.
        # cv2/numpy: the camera. Installed above on every platform since
        # 2026-08-12 but never verified here, so a silent pip failure left the
        # SI blind with a green checkmark over it — the same shape as the
        # hands shipping broken earlier that night.
        mods = ["mss", "PIL", "cv2", "numpy"]
        if IS_WINDOWS:
            mods += ["pyautogui", "pygetwindow", "pyperclip"]
        elif IS_MAC:
            # Quartz, NOT just pyautogui — and this is the whole point.
            # The comment on the dep list above already says it: pyautogui's
            # macOS backend is a pyobjc consumer, so "without Quartz it
            # imports and then fails on the first real call."
            #
            # Which means verifying `import pyautogui` on macOS proves
            # nothing. It succeeds, the install reports the hands are fine,
            # and the body dies the first time the SI tries to move the
            # mouse. Windows verifies all three of its input modules; macOS
            # verified one of two and skipped the one that actually fails.
            # Predicted from the Windows bugs, then found here before a customer hit
            # it — same class exactly: a green checkmark over a dead limb.
            mods += ["pyautogui", "Quartz"]
        missing = []
        vpy = getattr(self, "venv_python", None)
        if vpy:
            for mod in mods:
                r = subprocess.run([vpy, "-c", f"import {mod}"],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, timeout=120)
                if r.returncode != 0:
                    missing.append(mod)
                    _log(f"actuator dep {mod} unimportable: "
                         + r.stdout.decode("utf-8", "replace")[-300:])
        if missing:
            self.no_body = "missing packages: " + ", ".join(missing)
            self.say("Could not install everything your SI needs to see and "
                     "control this computer (" + ", ".join(missing) + ").")
        if IS_LINUX:
            # Named, not silently tolerated: on Linux these two binaries ARE
            # the hands, and no amount of pip fixes their absence.
            absent = [b for b in ("xdotool", "wmctrl") if not shutil.which(b)]
            if absent:
                self.no_body = "missing system tools: " + ", ".join(absent)
                self.say("Your SI needs " + " and ".join(absent) + " to move "
                         "the mouse and manage windows on Linux. Install with:")
                self.say("    sudo apt install " + " ".join(absent))

    def _body_check(self):
        """Ask the body whether it has hands. None = couldn't ask.

        The shape of _brain_check() above, one layer over, and None means the
        same thing it does there: an older payload has no body.health tool,
        and "we could not ask" must never be reported to a customer as "your
        SI has no hands".

        Run through the SI'S OWN interpreter, in the SI's own install, rather
        than importing leon_transport into this process. Three reasons, and
        the first is the one that matters: leon_transport resolves the
        rendezvous path at IMPORT time from LEON_ACTUATOR_DIR, so a check that
        runs inside the installer would be answering for the installer's
        environment, not the SI's — and a verification step that can pass
        while the real thing fails is worse than none. Second, this is a
        frozen PyInstaller binary and its sys.path is not the SI's. Third, on
        Windows this subprocess is silent: subprocess.run is patched at import
        (see the top of this file) so the check spawns no console window.
        """
        vpy = getattr(self, "venv_python", None)
        if not vpy or not os.path.exists(vpy):
            return None
        probe = r'''
import json, os, sys, time
dest = sys.argv[1]
# Same precedence as python-dotenv: the real environment wins over the file.
try:
    with open(os.path.join(dest, '.env'), encoding='utf-8', errors='replace') as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, _, v = line.partition('=')
                os.environ.setdefault(k.strip(), v.strip())
except OSError:
    pass
sys.path.insert(0, os.path.join(dest, 'leon-actuator'))
import leon_transport as t
out = {'rendezvous': t.RENDEZVOUS_PATH, 'socket': t.SOCKET_PATH,
       'listener_present': t.listener_present()}
try:
    s, tok = t.connect(8.0)
except Exception as e:
    out['ok'] = False
    out['error'] = '%s: %s' % (type(e).__name__, e)
    print(json.dumps(out))
    raise SystemExit(0)
req = {'tool': 'body.health', 'args': {}}
if tok:
    req['token'] = tok
s.sendall((json.dumps(req) + '\n').encode('utf-8'))
buf = b''
deadline = time.time() + 20
while not buf.endswith(b'\n') and time.time() < deadline:
    chunk = s.recv(65536)
    if not chunk:
        break
    buf += chunk
s.close()
try:
    out.update(json.loads(buf.decode('utf-8', 'replace')))
except Exception as e:
    out['ok'] = False
    out['error'] = 'unreadable answer: %s' % e
print(json.dumps(out))
'''
        try:
            r = subprocess.run([vpy, "-c", probe, self.dest],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               timeout=90)
            raw = (r.stdout or b"").decode("utf-8", "replace").strip()
            data = json.loads(raw.splitlines()[-1])
        except Exception as exc:
            _log(f"body-check unavailable: {exc}")
            return None
        _log(f"body-check: {raw[:500]}")
        # An older payload's actuator has no body.health. That is "we could
        # not ask", exactly like a 404 on /api/brain-check — not a verdict.
        if "unknown tool" in str(data.get("error", "")):
            return None
        return data

    def _set_env_key(self, key: str, value: str):
        """Rewrite one key in the installed .env, in place."""
        path = os.path.join(self.dest, ".env")
        try:
            with open(path, "r", encoding="utf-8") as fh:
                lines = fh.readlines()
        except OSError:
            return
        hit = False
        for i, ln in enumerate(lines):
            if ln.split("=", 1)[0].strip() == key:
                lines[i] = f"{key}={value}\n"
                hit = True
        if not hit:
            lines.append(f"{key}={value}\n")
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.writelines(lines)
        except OSError:
            pass

    # ── what actually runs on this machine ────────────────────────
    def _entry_cmd(self) -> list:
        # Whatever interpreter install_deps actually produced — a guessed
        # path here writes an autostart entry that can never run.
        py = getattr(self, "venv_python", None) or \
            self._venv_python(os.path.join(self.dest, ".venv"))
        if self.cfg.get("brain_mode") == "local":
            script = os.path.join(self.dest, "run.py")
            cmd = [py, script, "--port", str(self.port)]
        else:
            # Hosted: this machine runs the BODY (senses + hands) against the
            # hosted brain named in .env (LEON_BRAIN_URL).
            script = os.path.join(self.dest, "run_body.py")
            cmd = [py, script]
        # Found 2026-08-11: run_body.py existed only in the repo CI used to
        # build from, never in the tarball this installs. A hosted tenant got
        # autostart pointed at a file that was never on disk — the install
        # reported success, the machine registered a boot entry, and nothing
        # ever ran. Silent, and invisible until someone asked why their SI was
        # dead. An entry point that isn't there is an install failure, not a
        # detail: fail here, where the message can still reach a person.
        if not os.path.exists(script):
            raise InstallError(
                f"Your SI installed, but the program that runs it "
                f"({os.path.basename(script)}) is missing from this release, "
                f"so it could not be started or set to start with this "
                f"machine.\n\nNothing is broken on your computer — this is our "
                f"packaging error. Please contact support and mention "
                f"'{os.path.basename(script)} missing'.")
        return cmd

    def register_autostart(self):
        self.say("Registering your SI to start with this machine…")
        cmd = self._entry_cmd()
        if IS_LINUX:
            unit_dir = os.path.expanduser("~/.config/systemd/user")
            os.makedirs(unit_dir, exist_ok=True)
            # No [Install]/enable: the XDG autostart entry below is the ONE
            # trigger. Wanting graphical-session.target raced it on GNOME/
            # Plasma — the target started the unit before the entry imported
            # DISPLAY, buying a crash loop at every login until the restart
            # cycle picked up the imported env. (And on Cinnamon/XFCE/MATE/
            # LXQt the target never activates at all, so it couldn't be the
            # trigger anyway.) systemd still owns the process and Restart=;
            # PartOf stops it with the session where the target exists.
            # self.dest and cmd (which embeds the venv python path) both live
            # under the user's home dir — an open() with no encoding= falls
            # back to the locale's preferred codec, and a non-ASCII home
            # directory on a non-UTF-8 locale would raise here mid-install.
            with open(os.path.join(unit_dir, "sabr-si.service"), "w",
                     encoding="utf-8") as f:
                f.write("[Unit]\nDescription=Sabr SI\n"
                        "After=graphical-session.target\n"
                        "PartOf=graphical-session.target\n\n"
                        "[Service]\n"
                        # PEP 540: every locale-default open() in the SI
                        # becomes UTF-8, whatever the machine's codepage.
                        "Environment=PYTHONUTF8=1\n"
                        # QUOTING IS NOT COSMETIC AND THE TWO KEYS DIFFER.
                        # Measured with `systemd-analyze verify`, 2026-08-12:
                        #
                        #   ExecStart IS word-split. A bare ' '.join(cmd) with
                        #   a home dir like "/home/mr. sabr/leon brain" became
                        #   the command "/home/mr." -> "Command /home/mr. is
                        #   not executable", and boot persistence died while
                        #   the installer still said the SI would come back at
                        #   login. Quote EACH word; systemd strips the quotes.
                        #
                        #   WorkingDirectory is NOT word-split -- the rest of
                        #   the line is the path, spaces and all. Quoting it
                        #   makes systemd read the leading " as part of the
                        #   path and refuse to load the unit at all. It stays
                        #   bare. Do not "make these consistent".
                        #
                        # install_client.py:534 carries the same pair, and
                        # tests/test_autostart.py now asserts both files.
                        f"WorkingDirectory={self.dest}\n"
                        "ExecStart="
                        + " ".join('"%s"' % str(c).replace('"', r'\"')
                                   for c in cmd) + "\n"
                        "Restart=on-failure\nRestartSec=5\n")
            subprocess.run(["systemctl", "--user", "daemon-reload"],
                           check=False, env=_clean_env())
            # Start it now the same way the autostart entry will at every
            # login: import the session's display env into the user manager
            # first (the installer itself runs inside the session, so the
            # values are in our environment).
            subprocess.run(["systemctl", "--user", "import-environment",
                            "DISPLAY", "XAUTHORITY", "WAYLAND_DISPLAY"],
                           check=False, env=_clean_env())
            started = subprocess.run(
                ["systemctl", "--user", "start", "sabr-si.service"],
                check=False, capture_output=True, text=True, env=_clean_env())
            # Remembered for launch(): on a headless box (VPS, SSH-only server,
            # a container) there is no D-Bus session for `systemctl --user` to
            # reach at all, so this call fails outright and NOTHING starts —
            # not now, and not at "next login" either, because a bare SSH
            # login on many of these boxes never spins up a systemd --user
            # manager, and even when it does, the unit dies the moment that
            # SSH session ends unless lingering is enabled (below). Proven on
            # a real headless VPS 2026-08-12: `systemctl --user start` returns
            # 1 with "Failed to connect to user scope bus", the install still
            # reports success, and the SI never runs at all until someone
            # manually starts it.
            self._linux_unit_started = started.returncode == 0
            if started.returncode != 0:
                why = (started.stderr or "").strip().splitlines()
                _log(f"systemctl start failed: {why[-1] if why else started.returncode}")
                self.say("Could not start your SI through systemd on this "
                         "machine (no active login session) — starting it "
                         "directly instead.")
            # Lingering makes a --user unit survive logout and start without
            # a login at all, which is exactly the headless-server case this
            # comment block is about. Best-effort: it needs root, so a normal
            # non-sudo customer on a desktop simply keeps "starts at login"
            # instead, which is already correct for them.
            if shutil.which("loginctl"):
                # Not os.environ.get("USER", "") alone — a bare `curl | bash`
                # invocation or a cron/CI context can start with no USER set
                # at all, and an empty name makes `loginctl enable-linger`
                # target nobody. This needs the REAL OS account (root
                # included — unlike _os_account_name(), which deliberately
                # maps root to "friend" for a product-facing greeting, not a
                # system call), so fall through USERNAME/USER/LOGNAME to
                # getpass.getuser() without filtering any of them out.
                _acct = ""
                for _v in ("USERNAME", "USER", "LOGNAME"):
                    _acct = (os.environ.get(_v) or "").strip()
                    if _acct:
                        break
                if not _acct:
                    try:
                        import getpass as _getpass
                        _acct = (_getpass.getuser() or "").strip()
                    except Exception:
                        _acct = ""
                if _acct:
                    subprocess.run(
                        ["loginctl", "enable-linger", _acct],
                        check=False, capture_output=True, env=_clean_env())
            # XDG autostart is honored by every DE and runs after the session
            # env exists; it imports that env and starts the unit.
            autostart = os.path.expanduser("~/.config/autostart")
            os.makedirs(autostart, exist_ok=True)
            with open(os.path.join(autostart, "sabr-si.desktop"), "w",
                     encoding="utf-8") as f:
                f.write("[Desktop Entry]\n"
                        "Type=Application\n"
                        "Name=Sabr SI\n"
                        "Comment=Starts your SI with your desktop session\n"
                        "Exec=sh -c 'systemctl --user import-environment "
                        "DISPLAY XAUTHORITY WAYLAND_DISPLAY 2>/dev/null; "
                        "systemctl --user start sabr-si.service'\n"
                        "X-GNOME-Autostart-enabled=true\n"
                        "NoDisplay=true\n")
        elif IS_MAC:
            agents = os.path.expanduser("~/Library/LaunchAgents")
            os.makedirs(agents, exist_ok=True)
            # Every platform but this one could answer "why is my SI dead?".
            # Linux prints into journald; Windows gets sabr-si.log with
            # rotation and backoff (see the branch below). macOS had neither:
            # launchd threw stdout and stderr away, so an import-time crash on
            # a customer's Mac left NOTHING on disk — no traceback, no log, no
            # exit code. The only symptom is an SI that never answers.
            #
            # So: a runner script, same shape as the Windows .bat, because the
            # plist alone cannot rotate. launchd appends forever, and a crash
            # loop that prints a traceback every ThrottleInterval fills the
            # customer's disk in weeks. Rotate first, then exec — exec, so this
            # adds no supervising process and launchd still watches the real
            # python it is meant to watch.
            logfile = os.path.join(self.dest, "sabr-si.log")
            runner = os.path.join(self.dest, "sabr-si-run.sh")
            quoted = " ".join(shlex.quote(c) for c in cmd)
            with open(runner, "w", encoding="utf-8") as f:
                f.write(
                    "#!/bin/sh\n"
                    f"cd {shlex.quote(self.dest)} || exit 1\n"
                    # stat -f%z is the BSD/macOS spelling; GNU's -c%s is not
                    # present here. Guarded so a missing log is size 0, not an
                    # error that aborts the SI before it ever starts.
                    f"SZ=$(stat -f%z {shlex.quote(logfile)} 2>/dev/null || echo 0)\n"
                    f"[ \"$SZ\" -gt 33554432 ] && mv -f {shlex.quote(logfile)} "
                    f"{shlex.quote(logfile + '.1')} 2>/dev/null\n"
                    f"exec {quoted}\n")
            os.chmod(runner, 0o755)
            plist = {
                "Label": "com.sabr.si",
                "ProgramArguments": ["/bin/sh", runner],
                "WorkingDirectory": self.dest,
                "RunAtLoad": True,
                "EnvironmentVariables": {"PYTHONUTF8": "1"},
                "KeepAlive": {"SuccessfulExit": False},
                # Explicit rather than relying on launchd's default, and it is
                # the pacing for the rotation above: a crash loop costs one log
                # append per 10s, not one per millisecond.
                "ThrottleInterval": 10,
                "StandardOutPath": logfile,
                "StandardErrorPath": logfile,
            }
            path = os.path.join(agents, "com.sabr.si.plist")
            with open(path, "wb") as f:
                plistlib.dump(plist, f)
            subprocess.run(["launchctl", "load", "-w", path],
                           check=False, env=_clean_env())
        elif IS_WINDOWS:
            # systemd gets Restart=, launchd gets KeepAlive — Windows gets a
            # restart loop in the runner script, or a top-level crash means
            # the SI is dead until reboot.
            # self.dest / quoted embed a path under the user's Windows
            # profile — open() with no encoding= falls back to the console's
            # locale codec (cp1252 etc.), not UTF-8, so a non-ASCII Windows
            # username (accented Latin, Cyrillic, CJK) raised
            # UnicodeEncodeError right here. And cmd.exe itself reads a .bat
            # file in the console's ACTIVE codepage, not UTF-8 — writing
            # UTF-8 bytes without also telling cmd.exe to read them as UTF-8
            # trades the write-time crash for a run-time one, the moment
            # this same runner is launched below. `chcp 65001` as the first
            # executed line covers that half; both .bat files launch (this
            # one immediately, in launch() a few lines down — see SabrSI.bat
            # below, which only fires at next login but hits the same path).
            quoted = " ".join(f'"{c}"' if " " in c else c for c in cmd)
            runner = self._windows_runner_path()
            # Redirect into a log. Without this the SI runs windowless via
            # the Startup folder and every line it prints — including the
            # traceback from a subsystem that failed to come up — goes
            # nowhere. That is how an install shipped with a dead language
            # layer and a perfectly healthy-looking dashboard: the failure
            # printed a warning into a console that does not exist, the
            # brain kept serving, and the SI silently could not speak.
            # A silent failure mode is worse than a loud crash.
            logfile = os.path.join(self.dest, "sabr-si.log")
            # Two hazards this supervisor used to have, both only visible on a
            # machine left running for weeks:
            #
            #   1. The log was append-only and never rotated. A subsystem that
            #      prints a traceback every tick writes gigabytes into one file
            #      and eventually fills the customer's disk. Rotate at 32MB,
            #      keeping exactly one previous file, before each launch.
            #
            #   2. The retry delay was a flat 5 seconds forever. A crash that
            #      happens at import time — bad .env, missing DLL, corrupt
            #      state file — restarts 17,000 times a day, each one writing
            #      a fresh traceback into the log above. Back off instead:
            #      5s, then 15, 30, 60, capping at 300s. A healthy SI that has
            #      been up a while and exits normally still comes back fast,
            #      because the counter resets whenever the run lasted a while.
            logmax = 32 * 1024 * 1024
            with open(runner, "w", encoding="utf-8") as f:
                f.write("@echo off\n"
                        "chcp 65001 >nul\n"
                        "setlocal enabledelayedexpansion\n"
                        "set PYTHONUTF8=1\n"
                        # run.py now BLOCKS on a held install lock and takes over
                        # when the other instance exits, so this loop never spins
                        # on it. (:lockheld below only fires if someone opts a
                        # child into SABR_LOCKHELD_EXIT=3 explicitly.)
                        f"cd /d \"{self.dest}\"\n"
                        "set DELAY=5\n"
                        "set LOCKHELD=0\n"
                        ":loop\n"
                        # rotate an oversized log before we append to it again
                        f"for %%A in (\"{logfile}\") do if %%~zA GTR {logmax} ("
                        f"move /y \"{logfile}\" \"{logfile}.1\" >nul 2>&1)\n"
                        # remember when this attempt started, in seconds
                        "set T0=%TIME%\n"
                        f"{quoted} >> \"{logfile}\" 2>&1\n"
                        # run.py exits 3 when ANOTHER instance holds the install
                        # lock (someone launched the SI by hand, outside this
                        # supervisor). That is not a crash: do not back off and
                        # retry every 5 min forever writing the same line —
                        # Aiden's box logged it 6,591 times. Go quiet instead.
                        "set RC=!ERRORLEVEL!\n"
                        "if !RC! EQU 3 goto lockheld\n"
                        "set LOCKHELD=0\n"
                        # ran longer than a minute? treat as healthy, reset backoff
                        "call :elapsed RAN \"%T0%\" \"%TIME%\"\n"
                        "if !RAN! GEQ 60 (set DELAY=5) else ("
                        "set /a DELAY=!DELAY!*2 & "
                        "if !DELAY! GTR 300 set DELAY=300)\n"
                        # NOT `timeout /t` — timeout requires a console input
                        # handle and exits IMMEDIATELY with "Input redirection
                        # is not supported" when it doesn't have one (any
                        # non-interactive launch context). That silently turns
                        # the backoff below into a zero-delay spin, which is
                        # the exact failure the backoff exists to prevent.
                        # Measured on a real Windows box, 2026-08-11.
                        # `ping -n` sleeps without touching stdin.
                        "set /a _P=!DELAY!+1\n"
                        "ping -n !_P! 127.0.0.1 >nul 2>&1\n"
                        "goto loop\n"
                        "\n"
                        ":lockheld\n"
                        "set /a LOCKHELD=!LOCKHELD!+1\n"
                        # one log line per hour (12 x 5 min), not one per retry
                        "set /a _M=!LOCKHELD! %% 12\n"
                        f"if !_M! EQU 1 echo [SUPERVISOR] %DATE% %TIME% another instance of this SI is running outside this supervisor (run.py exit 3, seen !LOCKHELD!x). Standing by quietly; retrying every 5 min. >> \"{logfile}\"\n"
                        "ping -n 301 127.0.0.1 >nul 2>&1\n"
                        "goto loop\n"
                        "\n"
                        ":elapsed\n"
                        "set S=%~2\n"
                        "set E=%~3\n"
                        "for /f \"tokens=1-3 delims=:.\" %%a in (\"%S%\") do "
                        "set /a _S=(1%%a-100)*3600+(1%%b-100)*60+(1%%c-100)\n"
                        "for /f \"tokens=1-3 delims=:.\" %%a in (\"%E%\") do "
                        "set /a _E=(1%%a-100)*3600+(1%%b-100)*60+(1%%c-100)\n"
                        "set /a _D=_E-_S\n"
                        "if !_D! LSS 0 set /a _D=_D+86400\n"
                        "set %~1=!_D!\n"
                        "goto :eof\n")
            startup = os.path.join(
                os.environ.get("APPDATA", os.path.expanduser("~")),
                "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
            os.makedirs(startup, exist_ok=True)
            # The Startup entry used to be a .bat that ran `start "" /min`.
            # /min is MINIMIZED, not hidden — so every single sign-in flashed
            # a console and then parked a cmd.exe window in the customer's
            # taskbar, forever, for a background service they never asked to
            # see. That is the first thing a buyer notices and it makes the
            # product look like a script someone emailed them.
            #
            # A .vbs shim with WScript.Shell.Run window-style 0 is genuinely
            # hidden, needs nothing installed, and is the only no-dependency
            # way to do this on Windows. Written UTF-16LE-with-BOM because
            # wscript reads a .vbs in the system ANSI codepage otherwise,
            # which mangles the install path under a non-ASCII username —
            # the same class of bug the runner above already fights.
            with open(self._windows_startup_vbs(), "w", encoding="utf-16") as f:
                f.write('Set S = CreateObject("WScript.Shell")\r\n'
                        'S.Run Chr(34) & "' + runner + '" & Chr(34), 0, False\r\n')
            # An upgrade over an older install leaves the old .bat sitting in
            # Startup next to the new .vbs — two boot entries, two SIs, one
            # port. Remove it here rather than only at uninstall.
            try:
                os.remove(os.path.join(startup, "SabrSI.bat"))
            except OSError:
                pass

    def _windows_runner_path(self) -> str:
        return os.path.join(self.dest, "sabr_si_run.bat")

    def _windows_startup_vbs(self) -> str:
        startup = os.path.join(
            os.environ.get("APPDATA", os.path.expanduser("~")),
            "Microsoft", "Windows", "Start Menu", "Programs", "Startup")
        os.makedirs(startup, exist_ok=True)
        return os.path.join(startup, "SabrSI.vbs")

    def launch(self):
        self.say("Waking your SI…")
        if IS_LINUX:
            if getattr(self, "_linux_unit_started", False):
                return  # register_autostart already import-env'd + started it
            # systemd --user could not be reached (see register_autostart) —
            # on a headless box that means NOTHING starts the SI unless we do
            # it directly, right now, in this process. Without this branch an
            # install on any VPS / SSH-only server / container "succeeds" and
            # leaves no SI running at all, forever, until a human happens to
            # find and run the entry command by hand.
            subprocess.Popen(self._entry_cmd(), cwd=self.dest,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True, env=_clean_env())
            return
        if IS_WINDOWS:
            # Launch through the restart-loop runner so the first boot is
            # supervised the same way every later boot is — and hidden, the
            # same way every later boot is. Going through the Startup .vbs
            # means the very first launch and every login launch take the
            # identical path, so a window that appears here would be a window
            # that appears at login too, and we'd see it during install.
            subprocess.Popen(
                ["wscript.exe", self._windows_startup_vbs()],
                cwd=self.dest, env=_clean_env())
            return
        if IS_MAC:
            # Same reason Linux returns above, and it was missed here. The
            # LaunchAgent written a moment ago carries RunAtLoad, and
            # `launchctl load -w` starts it right then -- so a Popen here is a
            # SECOND SI, on the same port, against the same sqlite state and
            # the same log. One of them loses the bind and dies into DEVNULL
            # with nobody reading its exit code, but both are alive while the
            # race resolves. launchd owns the process on this platform; the
            # installer must not also.
            self._mac_privacy_preflight()
            return
        subprocess.Popen(self._entry_cmd(), cwd=self.dest,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True, env=_clean_env())

    def _mac_privacy_preflight(self):
        """Make the Mac blindness LOUD instead of silent.

        macOS is the mirror of the Windows session-zero problem, and it is
        worse because it fails quietly. A LaunchAgent DOES run in the user's
        GUI session, so unlike Windows there is a screen to grab -- but
        without the Screen Recording and Accessibility grants, `screencapture`
        still exits 0 and hands back an image of the desktop wallpaper, and
        every mouse/keyboard call is refused. The SI reports itself healthy
        and is functionally blind and handless, forever, and the owner is
        never told there is a checkbox to tick.

        leon_mac.tcc_preflight() has existed this whole time and nothing ever
        called it. Running it here is also what POPS the system permission
        dialogs -- the probes perform the real operation, which is the only
        way macOS will prompt. So this both diagnoses and fixes, at the one
        moment the owner is sitting in front of the installer paying
        attention.
        """
        try:
            sys.path.insert(0, os.path.join(self.dest, "landing"))
            import leon_mac  # type: ignore
            result = leon_mac.tcc_preflight()
        except Exception as e:
            # Never fail an otherwise-good install over a permission probe.
            _log(f"[warn] mac privacy preflight unavailable: {e}")
            return
        # HONESTY ABOUT WHO GOT THE GRANT (2026-08-24). TCC keys grants to
        # the program that asked — this installer process. The running SI is
        # launchd starting the venv's python, a DIFFERENT TCC identity, so a
        # grant collected here does NOT transfer to it. The old success line
        # ("permissions granted — your SI can see") claimed exactly that
        # transfer, and the owner then dismissed the second round of prompts
        # — named "python" or "sh", nothing saying Sabr — as noise.
        _second_round = (
            'Heads-up: macOS grants these per-program, and it may ask once '
            'more for your SI itself after install — those prompts, or new '
            'Privacy & Security entries, can be named "python" or "sh". '
            'Approve those too: that IS your SI.')
        if result.get("screen_recording") and result.get("accessibility"):
            self.say("Screen and input permissions granted to this "
                     "installer.")
            self.say(_second_round)
            return
        missing, panes = [], []
        if not result.get("screen_recording"):
            missing.append("Screen Recording")
            panes.append("x-apple.systempreferences:com.apple.preference."
                         "security?Privacy_ScreenCapture")
        if not result.get("accessibility"):
            missing.append("Accessibility")
            panes.append("x-apple.systempreferences:com.apple.preference."
                         "security?Privacy_Accessibility")
        # Open the exact pane(s), not a sentence describing the path to
        # them. Best-effort: a Mac where `open` fails still gets the words.
        for pane in panes:
            try:
                subprocess.run(["open", pane], check=False,
                               capture_output=True, timeout=10,
                               env=_clean_env())
            except Exception as e:
                _log(f"[warn] could not open settings pane {pane}: {e}")
        self.say("")
        self.say("ONE MORE STEP — macOS is holding your SI's eyes back.")
        self.say("In System Settings > Privacy & Security (it should have "
                 "just opened for you), switch ON:")
        for item in missing:
            self.say(f"    - {item}")
        self.say("Then quit and reopen your SI. Until you do, it can hear")
        self.say("and speak, but it cannot see your screen or move anything.")
        self.say(_second_round)
        _log(f"[mac] tcc preflight: {result.get('detail', '')}")


# Every ONLOGON task name this product (or a hand-registered recovery task)
# has ever used. Uninstall deletes all of them; only the first is created.
_WINDOWS_TASK_NAMES = ("Sabr SI", "SabrSI", "Sabr_SI", "SabrSI Autostart")


def _autostart_paths(dest: str) -> list:
    """Everything register_autostart() creates, per platform."""
    home = os.path.expanduser("~")
    if IS_LINUX:
        return [os.path.join(home, ".config", "systemd", "user", "sabr-si.service"),
                os.path.join(home, ".config", "autostart", "sabr-si.desktop")]
    if IS_MAC:
        # com.sabr.ollama is written by local_brain._mac_autostart_ollama —
        # macOS is the only platform where WE register the local brain's
        # startup (linux gets a systemd unit from ollama's own script, windows
        # gets one from its installer), so macOS is the only platform where we
        # have to clean it up. Leaving it behind is a ghost login item that
        # keeps launching a binary the uninstaller may have removed.
        return [os.path.join(home, "Library", "LaunchAgents", "com.sabr.si.plist"),
                os.path.join(home, "Library", "LaunchAgents", "com.sabr.ollama.plist")]
    if IS_WINDOWS:
        startup = os.path.join(os.environ.get("APPDATA", home), "Microsoft",
                               "Windows", "Start Menu", "Programs", "Startup")
        # "Sabr SI.bat" is the OTHER installer's name for the same thing
        # (install_client.py's Startup fallback). Two installers write two
        # differently-named shortcuts into one folder; an uninstaller that
        # only knows its own name leaves a boot entry pointing at a deleted
        # tree, which is a failed console on every sign-in forever.
        # SabrSI.vbs is the current hidden launcher; SabrSI.bat is what older
        # installs left in Startup. An uninstaller that only knows the current
        # name leaves the old one behind, and the old one is a boot entry
        # pointing at a deleted tree — a failed console on every sign-in.
        return [os.path.join(startup, "SabrSI.vbs"),
                os.path.join(startup, "SabrSI.bat"),
                os.path.join(startup, "Sabr SI.bat"),
                os.path.join(dest, "sabr_si_run.bat")]
    return []


def _stop_windows_si(dest: str) -> None:
    """Kill the SI itself, scoped to THIS install's interpreter.

    The previous code ran `taskkill /F /IM SabrInstaller.exe`, which kills the
    installer window the user is standing in and leaves the SI running. The
    tree then cannot be deleted (Windows holds open files), so the uninstall
    reports leftovers for a reason that looks like a permissions problem and
    is not. Matching on ExecutablePath keeps an unrelated python.exe safe.
    """
    venv_python = os.path.join(dest, ".venv", "Scripts", "python.exe")
    if not os.path.exists(venv_python):
        return
    escaped = venv_python.replace("\\", "\\\\").replace("'", "''")
    pids = ""
    # wmic is gone on current Windows 11 images; CIM is the supported path.
    # A false "nothing is running" here means deleting the tree out from
    # under a live process, so try both before believing it.
    for argv in (
        ["wmic", "process", "where", f"ExecutablePath='{escaped}'",
         "get", "ProcessId"],
        ["powershell", "-NoProfile", "-Command",
         f"Get-CimInstance Win32_Process -Filter \"ExecutablePath='{escaped}'\""
         f" | Select-Object -ExpandProperty ProcessId"],
    ):
        try:
            r = subprocess.run(argv, check=False, capture_output=True,
                               text=True, timeout=60, env=_clean_env())
            pids = r.stdout or ""
        except (OSError, subprocess.SubprocessError):
            pids = ""
        if pids.strip():
            break
    for tok in pids.split():
        if tok.isdigit():
            # The two discovery calls above are already guarded; these were
            # not. Same class of bug as the systemctl one in run_uninstall —
            # a missing taskkill would raise FileNotFoundError straight past
            # check=False and abort the uninstall that called us.
            _run_best_effort(["taskkill", "/PID", tok, "/T", "/F"],
                             "taskkill " + tok)

    # ALSO kill the supervisor shell — it is not an interpreter, so the scan
    # above cannot see it (2026-08-10, measured on Windows 10).
    #
    # register_autostart() writes sabr_si_run.bat as a `:loop / python run.py
    # / sleep / goto loop` restart supervisor (the sleep is a `ping -n`, not
    # `timeout` — see the comment at its write site for why), and Startup
    # launches it under
    # cmd.exe. Killing only the interpreter leaves that cmd.exe alive with
    # `cd /d <dest>` still in effect — and on Windows a process whose CURRENT
    # DIRECTORY is a folder blocks that folder's removal outright, no open
    # file required. So the uninstall killed the SI, deleted everything it
    # could, and then failed the final rmtree with WinError 32 pointing at
    # whatever file happened to be last. It reads as a permissions problem or
    # a stuck process; it is neither. It is our own supervisor.
    #
    # Worse: while that loop lives it keeps trying to relaunch a deleted SI
    # (starting ~5s apart, then backing off). Same shape as the pythonw-vs-python miss — the uninstaller
    # knew about only one of the two process kinds the installer creates.
    # TWO different installers write TWO different supervisor batch files, and
    # this only ever hunted for one of them. install_client.py (the tarball /
    # bootstrap.sh flow) writes start.bat, whose first line is `cd /d "%~dp0"`
    # — exactly the cwd-lock described above. So an install that arrived via
    # bootstrap and is then updated or uninstalled by THIS installer left a
    # live cmd.exe holding the folder, and the rmtree failed with WinError 32.
    # Hunt every supervisor name we have ever shipped, not just our own.
    runners = [os.path.join(dest, name)
               for name in ("sabr_si_run.bat", "start.bat")]
    argvs = []
    for runner in runners:
        escaped_runner = runner.replace("\\", "\\\\").replace("'", "''")
        base = os.path.basename(runner)
        argvs.append(
            ["wmic", "process", "where",
             f"Name='cmd.exe' and CommandLine like '%{escaped_runner}%'",
             "get", "ProcessId"])
        argvs.append(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process -Filter \"Name='cmd.exe'\" | "
             f"Where-Object {{ $_.CommandLine -like '*{base}*' }} | "
             "Select-Object -ExpandProperty ProcessId"])
    for argv in argvs:
        try:
            r = subprocess.run(argv, check=False, capture_output=True,
                               text=True, timeout=60, env=_clean_env())
            out = r.stdout or ""
        except (OSError, subprocess.SubprocessError):
            out = ""
        for tok in out.split():
            if tok.isdigit():
                _run_best_effort(["taskkill", "/PID", tok, "/T", "/F"],
                                 "taskkill " + tok)
    # Windows releases handles asynchronously after a kill; deleting the tree
    # in the same breath can still lose the race.
    time.sleep(2)


def _stop_linux_si(dest: str) -> None:
    """Kill the SI itself, scoped to THIS install's venv interpreter.

    `systemctl --user stop sabr-si.service` is not enough on its own. Two
    real ways it does nothing:

      1. No user D-Bus session (a headless VPS / SSH-only server / a
         container — reproduced live 2026-08-12: `systemctl --user` fails
         outright with "Failed to connect to user scope bus"). This is
         exactly the box register_autostart() now falls back to launching
         directly on (see launch()), so it is not a corner case — it is the
         SAME machine, at uninstall time.
      2. The unit was never running under systemd in the first place: any
         customer who read the "has not started answering yet" message and
         hand-ran the entry command, or who is mid-way through the fallback
         launch above, has a plain detached process systemd never heard of.

    Either way, without this, the rmtree a few lines below deletes the
    install directory out from under a LIVE process — on Linux that does not
    even fail loudly, unlink() just detaches the name while the process keeps
    running against the now-nameless inode — and the uninstall reports
    "Uninstalled." over an orphan that is still bound to the SI's port and
    will keep running until the machine reboots or a human finds it by hand.
    Proven exactly this way on a real headless VPS: uninstall reported
    success, `ps` still showed the venv python running the deleted run.py.

    Matches _stop_windows_si's approach: scope to processes whose executable
    IS this install's venv python, so an unrelated system python is never
    touched.
    """
    venv_python = os.path.join(dest, ".venv", "bin", "python")
    pids = set()
    try:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            try:
                exe = os.readlink(f"/proc/{entry}/exe")
            except OSError:
                continue  # gone, or not ours to read — never fatal
            if os.path.realpath(exe) == os.path.realpath(venv_python):
                pids.add(entry)
    except OSError as e:
        # /proc unreadable is exotic (some minimal containers hide it) —
        # fall back to a plain process-list scan by name instead of giving
        # up on stopping the SI entirely.
        _log(f"[warn] /proc unavailable ({e}), falling back to pgrep")
        try:
            r = subprocess.run(["pgrep", "-f", venv_python], check=False,
                               capture_output=True, text=True, timeout=30)
            pids.update(t for t in r.stdout.split() if t.isdigit())
        except (OSError, subprocess.SubprocessError):
            pass
    for pid in pids:
        try:
            os.kill(int(pid), signal.SIGTERM)
        except OSError:
            continue
    if pids:
        time.sleep(1)
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
            except OSError:
                pass  # already gone — the normal case after SIGTERM


def _stop_mac_si(dest: str) -> None:
    """Kill the SI itself, scoped to THIS install's venv interpreter — the
    macOS analog of _stop_windows_si/_stop_linux_si, added 2026-08-24.

    `launchctl unload` only stops the job LAUNCHD started. An SI the owner
    hand-launched after reading "has not started answering yet" — or any
    process left over from a pre-launchd install — is a plain process
    launchd never heard of, so the rmtree below deleted the tree out from
    under it and the orphan kept running (and holding the SI's port) until
    reboot. No /proc on macOS, so scope with pgrep -f on the venv python
    path — same never-touch-an-unrelated-python rule as the other two.
    SIGTERM first for a clean brain_state save, SIGKILL a beat later.
    """
    venv_python = os.path.join(dest, ".venv", "bin", "python")
    pids = set()
    try:
        r = subprocess.run(["pgrep", "-f", venv_python], check=False,
                           capture_output=True, text=True, timeout=30,
                           env=_clean_env())
        pids.update(t for t in (r.stdout or "").split() if t.isdigit())
    except (OSError, subprocess.SubprocessError) as e:
        _log(f"[warn] could not scan for running SI processes: {e}")
        return
    for pid in pids:
        try:
            os.kill(int(pid), signal.SIGTERM)
        except OSError:
            continue
    if pids:
        time.sleep(1)
        for pid in pids:
            try:
                os.kill(int(pid), signal.SIGKILL)
            except OSError:
                pass  # already gone — the normal case after SIGTERM


#: What an earlier install, update or uninstall may have left in $HOME.
#: bootstrap.sh's validate-then-swap keeps the previous tree (a FULL copy —
#: .env with the tenant token and dashboard key, plus brain_state) at
#: ~/.leon-brain-previous.<pid>, and an interrupted run leaves a staging or
#: failed tree; every uninstaller writes an identity archive. None of it was
#: ever looked at by run_uninstall, so WIPE could promise "no memory or
#: credentials remain" over a complete copy of both (found 2026-09-02).
_UPDATE_JUNK_GLOBS = (".leon-brain-staging.*", "leon-brain.failed.*")
_UPDATE_PREVIOUS_GLOB = ".leon-brain-previous.*"
_IDENTITY_ARCHIVE_GLOBS = ("sabr-si-backup-*.tar.gz",
                           "sabr-si-identity-*.tar.gz",
                           "si-identity-backup-*.tar.gz")


def _update_debris(dest: str) -> dict:
    """Leftovers of earlier installs, keyed by how safe they are to remove.

    junk:     staging / failed trees — duplicates of state that was carried
              forward or rolled back; safe in every mode.
    previous: the tree an update kept "until the new one is confirmed" —
              a full older copy of the SI; safe once a newer copy exists.
    archives: identity archives written by any uninstaller — the customer's
              deliberate backups; only WIPE may remove them.
    Never includes dest itself, symlinks, or a live ~/leon-brain install.
    """
    import glob
    home = os.path.expanduser("~")
    dest = os.path.abspath(dest)

    def _dirs(pattern):
        return sorted(p for p in glob.glob(os.path.join(home, pattern))
                      if os.path.isdir(p) and not os.path.islink(p)
                      and os.path.abspath(p) != dest)

    archives = set()
    for folder in {home, os.path.dirname(dest) or "."}:
        for pat in _IDENTITY_ARCHIVE_GLOBS:
            archives.update(os.path.abspath(p)
                            for p in glob.glob(os.path.join(folder, pat))
                            if os.path.isfile(p) and not os.path.islink(p))
    junk = []
    for pat in _UPDATE_JUNK_GLOBS:
        junk.extend(_dirs(pat))
    return {"junk": junk, "previous": _dirs(_UPDATE_PREVIOUS_GLOB),
            "archives": sorted(archives)}


# Temp-directory residue left by the SI itself, swept at uninstall.
#
# WHY THIS EXISTS (measured on Dean's Dell, 2026-09-04, clean-machine run):
# after a fully successful `--uninstall` — install tree gone, no autostart,
# no tasks, no processes, --version correctly reporting "no install" — the
# machine still held ELEVEN leon-sysprompt-*.txt files in %TEMP%, 8,948
# bytes each. Those are not scratch: each one is the SI's FULL system
# prompt, which names the owner and carries their personal context. The
# uninstaller's only prior contact with tempdir was writing its own log
# there, so nothing ever removed them.
#
# Two independent producers, both by design:
#   brain/leon_claude_session.py  one per session start ("stop() removes it"
#                                 — true only on a graceful stop; every crash
#                                 or kill orphans one forever)
#   brain/claude_api_responder.py one per PROCESS at import time, with no
#                                 deletion path at all
#
# So "uninstall leaves nothing behind" was false in the one place a customer
# would never think to look, and the leak grows with uptime.
#
# OWNERSHIP GUARD: on Linux/macOS /tmp is SHARED between users. This machine
# is literally a shared laptop (Dean + his mom, two SIs). Deleting by glob
# alone would reach across into another person's SI. mkstemp files are 0600
# and owned by their creator, so an os.remove would fail anyway — but fail
# LOUDLY in the log for a file that was never ours. Check st_uid first and
# skip anything we do not own. Windows %TEMP% is already per-user.
_TEMP_RESIDUE_GLOBS = (
    "leon-sysprompt-*.txt",
    "leon-sysprompt-oneshot-*.txt",
    "leon-tts-active",
    "leon-actuator.log",
    "leon_screen.png",
    "leon_shot.ps1",
    "sabr_full_install.log",
    "sabr_full_install.err.log",
)


def _sweep_temp_artifacts(progress=print) -> int:
    """Delete this user's SI leftovers from the system temp directory.

    Best-effort by construction: a file we cannot remove is a cosmetic
    leftover, never a reason to abort an uninstall that has already
    removed the install tree.
    """
    tmp = tempfile.gettempdir()
    try:
        me = os.getuid()            # POSIX only
    except AttributeError:
        me = None                   # Windows: %TEMP% is per-user already
    removed = 0
    for pattern in _TEMP_RESIDUE_GLOBS:
        for path in glob.glob(os.path.join(tmp, pattern)):
            try:
                if me is not None and os.stat(path).st_uid != me:
                    continue        # another user's SI on a shared box
                os.remove(path)
                removed += 1
            except OSError:
                pass
    if removed:
        _log(f"swept {removed} temp artifact(s) from {tmp}")
        progress(f"Cleaned up {removed} leftover working file(s).")
    return removed


def run_uninstall(dest: str, purge: bool = False, progress=print) -> int:
    """Stop the SI, remove its autostart registration, and delete the install.

    Identity is archived FIRST unless --purge is given. brain_state is
    everything the SI has learned and .env is its name and its owner's; a
    product that can erase that on one command is not one to trust with it.
    If the archive cannot be written we stop rather than delete.
    """
    # LOG TO TEMP, NEVER INTO dest (2026-08-10, measured on Windows 10).
    #
    # _log_open() prefers dest, so the uninstall wrote sabr-install.log INTO
    # the very folder it was about to delete, and kept the handle open for the
    # whole run. On Windows an open handle blocks directory removal outright,
    # so the final rmtree left exactly one file behind and the uninstall
    # reported "could not be removed" — looking like a permissions or
    # still-running-process problem when it was purely self-inflicted.
    #
    # Pointing it at a temp directory keeps the log (and _log_hint's pointer
    # to it) fully intact for support — it just no longer pins open the one
    # directory this function exists to delete.
    _log_open(os.path.join(tempfile.gettempdir(), "sabr-uninstall-log"))
    dest = os.path.abspath(dest)
    progress("Stopping your SI…")
    if IS_LINUX:
        # _run_best_effort, NOT a bare subprocess.run: `systemctl` is absent
        # on non-systemd distros, minimal containers and chroots, and
        # check=False does not cover a missing binary. This used to abort
        # the entire uninstall with FileNotFoundError before reaching a
        # single line of cleanup below — see _run_best_effort's docstring.
        for argv in (["systemctl", "--user", "stop", "sabr-si.service"],
                     ["systemctl", "--user", "disable", "sabr-si.service"]):
            _run_best_effort(argv, "systemctl " + argv[2])
        # systemctl above only stops a unit systemd actually knows is running.
        # Scoped-by-executable kill covers the headless case (no user bus) and
        # the hand-launched case (launch()'s direct-Popen fallback, or a
        # customer who ran the entry command themselves) — see _stop_linux_si.
        _stop_linux_si(dest)
    elif IS_MAC:
        # EVERY plist, not just [0]. Deleting a plist file without unloading it
        # first leaves launchd still running the job until the user logs out —
        # a live process for software that is gone. This used to hardcode index
        # 0, which silently stopped covering everything the moment a second
        # agent (the local brain) was added.
        for plist in _autostart_paths(dest):
            if os.path.exists(plist):
                # Same guard as the Linux branch. launchctl ships with macOS,
                # but "the binary is always there" is precisely the assumption
                # that made systemctl abort an uninstall — and the cost of
                # being wrong here is identical: no cleanup at all.
                _run_best_effort(["launchctl", "unload", "-w", plist],
                                 "launchctl unload")
        # launchctl only covers what launchd started. Hand-launched SIs
        # (the "has not started answering yet" recovery path) survive the
        # unload and keep running out of the deleted tree — the same gap
        # the other two platforms already close with their scoped kills.
        _stop_mac_si(dest)
    elif IS_WINDOWS:
        _stop_windows_si(dest)
        # The other installer registers an ONLOGON scheduled task rather than a
        # Startup shortcut. Deleting the tree without deleting the task leaves
        # Windows failing it at every sign-in for software that is gone.
        #
        # Sweep EVERY spelling, not just ours. Found on Dean's box 2026-08-12:
        # a live ONLOGON task named "SabrSI" (no space) was starting the SI,
        # while every uninstall path in this product only ever deletes
        # "Sabr SI" (with the space). One character apart, and the difference
        # is a boot entry that survives uninstall forever. A ghost task is the
        # single most visible way this product can fail AFTER the customer has
        # already decided to leave -- so the sweep is deliberately wider than
        # the set we create.
        for _task in _WINDOWS_TASK_NAMES:
            # schtasks is absent on Windows editions with Task Scheduler
            # stripped and in some locked-down/managed images. A ghost boot
            # entry is bad; an uninstall that cannot run at all is worse.
            _run_best_effort(["schtasks", "/delete", "/tn", _task, "/f"],
                             "schtasks /delete " + _task)

    removed, left = [], []
    for path in _autostart_paths(dest):
        if os.path.lexists(path):
            try:
                os.remove(path)
                removed.append(path)
            except OSError as e:
                left.append(f"{path} ({e.strerror})")
    if IS_LINUX and removed:
        # Reached only after the unit file has already been deleted, so a
        # missing systemctl here costs nothing at all — but it must not be
        # allowed to abort the archive and rmtree that still follow.
        _run_best_effort(["systemctl", "--user", "daemon-reload"],
                         "systemctl daemon-reload")

    # The SI's own scratch in the system temp dir — system prompts above all.
    # Runs AFTER the process is stopped (nothing can write a new one) and
    # BEFORE the archive, so a failure here still leaves the tree intact.
    _sweep_temp_artifacts(progress)

    # ~/.leon holds skills.db, lessons.db, reflection.db, self_repair.db and
    # tool_health.db — everything the SI actually learned — and it lives
    # OUTSIDE the install tree, so deleting dest never touched it. Two things
    # were true at once: the archive labelled "your SI's identity" did not
    # contain the learned cognition, and the next install silently inherited a
    # dead SI's skills and tool health.
    cognition = os.path.join(os.path.expanduser("~"), ".leon")

    archive = ""
    if not purge:
        keep = []
        if os.path.isdir(dest):
            keep = [n for n in (".env", "brain_state")
                    if os.path.lexists(os.path.join(dest, n))]
        # The cognition probe sits OUTSIDE the `keep` guard deliberately. With
        # it inside, a tree that has no .env or brain_state yet skips the whole
        # archive block while ~/.leon still gets deleted below — data loss.
        have_cognition = os.path.isdir(cognition)
        if keep or have_cognition:
            progress("Saving your SI's identity before removing anything…")
            stamp = _timestamp()
            archive = os.path.join(os.path.dirname(dest) or ".",
                                   f"sabr-si-backup-{stamp}.tar.gz")
            try:
                with tarfile.open(archive, "w:gz") as tar:
                    for name in keep:
                        tar.add(os.path.join(dest, name), arcname=name)
                    if have_cognition:
                        tar.add(cognition, arcname=".leon")
                if os.path.getsize(archive) <= 0:
                    raise OSError("empty archive")
            except Exception as e:
                try:
                    os.unlink(archive)
                except OSError:
                    pass
                raise InstallError(
                    f"Couldn't save your SI's memories to {archive} ({e}). "
                    f"Nothing has been removed. Free some space, or pass "
                    f"--purge if you really want them deleted." + _log_hint())

    # BEFORE the rmtree, not after. The receipt that authorises this lives
    # inside dest; once dest is gone the answer to "did we install Ollama?"
    # is unrecoverable, and the safe default (leave it) means every uninstall
    # abandons several GB plus a LaunchAgent restarting a server for software
    # that no longer exists. This is the only window in which the question
    # can be answered honestly.
    try:
        gone = local_brain.remove_ollama_if_ours(dest, say=progress)
        removed.extend(gone)
    except Exception as e:
        # An uninstall must complete. Leftover Ollama is a disk-space
        # complaint; a crash here is an SI the customer cannot get rid of.
        left.append(f"offline brain ({e})")

    if os.path.isdir(dest):
        progress("Removing the install…")
        shutil.rmtree(dest, ignore_errors=True)
        if os.path.isdir(dest):
            left.append(f"{dest} (could not be removed)")
        else:
            removed.append(dest)

    # Only now that it is safely inside the archive above.
    if os.path.isdir(cognition):
        shutil.rmtree(cognition, ignore_errors=True)
        if os.path.isdir(cognition):
            left.append(f"{cognition} (could not be removed)")
        else:
            removed.append(f"{cognition} (learned skills, lessons, reflections)")

    # WIPE ONLY: the private CPython the installer may have downloaded to
    # ~/.sabr/python (_autoinstall_python_standalone). A plain uninstall
    # deliberately leaves it — re-installing later reuses it instead of
    # downloading 25MB again, and it holds nothing personal. But the WIPE
    # verb is "selling / giving away this computer", and a quarter-GB
    # runtime nobody will ever explain to the next owner is exactly the
    # kind of leftover that verb promises not to leave.
    if purge:
        sabr_root = os.path.dirname(_standalone_python_root())  # ~/.sabr
        if os.path.isdir(sabr_root):
            shutil.rmtree(sabr_root, ignore_errors=True)
            if os.path.isdir(sabr_root):
                left.append(f"{sabr_root} (could not be removed)")
            else:
                removed.append(f"{sabr_root} (private Python runtime)")

    # Sweep what earlier installs/updates/uninstalls left in $HOME. The
    # fresh archive written above (keep mode) is the newest copy of the
    # SI's state, so once it exists the older "previous" tree is redundant;
    # without it, that tree may be the only copy left and must stay.
    still_here = []
    debris = _update_debris(dest)
    fresh_archive = os.path.abspath(archive) if archive else ""

    def _rm_tree(path, why):
        shutil.rmtree(path, ignore_errors=True)
        if os.path.isdir(path):
            left.append(f"{path} (could not be removed)")
        else:
            removed.append(f"{path} ({why})")

    for path in debris["junk"]:
        _rm_tree(path, "leftover from an interrupted update")
    for path in debris["previous"]:
        if purge or fresh_archive:
            _rm_tree(path, "previous install kept by an earlier update")
        else:
            still_here.append(path)
    for path in debris["archives"]:
        if path == fresh_archive:
            continue
        if purge:
            try:
                os.remove(path)
                removed.append(f"{path} (identity archive)")
            except OSError as e:
                left.append(f"{path} ({e.strerror})")
        else:
            still_here.append(path)

    for path in removed:
        progress(f"Removed {path}")
    for path in still_here:
        progress(f"Still on disk (yours to keep or delete): {path}")
    if archive:
        progress(f"Kept your SI's identity at {archive} — delete it yourself "
                 f"when you are sure.")
    for path in left:
        progress(f"Could not remove {path}")
    progress("Uninstalled." if not left else "Uninstalled, with leftovers above.")
    return 1 if left else 0


#: What the onboarding server sends when a Stripe buyer never chose a name.
#: It must never survive into the .env or the "is alive" line.
_SERVER_PLACEHOLDER_SI_NAME = "Sabr customer"


def _installed_si_name(dest: str) -> str:
    """The name the SI on this machine already answers to, if any."""
    try:
        with open(os.path.join(dest or "", ".env"),
                  encoding="utf-8", errors="replace") as fh:
            for line in fh:
                k, sep, v = line.strip().partition("=")
                if sep and k.strip() == "LEON_SI_NAME":
                    return v.strip()
    except OSError:
        pass
    return ""


def resolve_identity(cfg: dict, si_name: str = "", dest: str = "") -> dict:
    """Settle the SI's name before anything is written.

    The choice made locally at install time wins over whatever the server
    sent; a blank local choice falls back to the server value; and the
    server's Stripe-buyer placeholder ("Sabr customer") degrades to
    "your SI" so no customer ever meets a mind that introduces itself
    by a placeholder. user_name is deliberately NOT settled here: the
    owner introduces themselves out loud and the SI learns who they are —
    typing your own name into a form is the least alive version of an
    introduction, so the server value passes through untouched.

    AN EXISTING INSTALL'S NAME BEATS THE PLACEHOLDER. Added 2026-08-12,
    same shape as the LEON_BRAIN_MODE bug documented in write_env. A Stripe
    buyer's tenant record carries si_name="Sabr customer", so on every
    UPDATE / REINSTALL this function used to hand write_env the string
    "your SI" — which is in `_ours`, so the carry-forward loop could not
    rescue it either. The owner names their mind, runs an update three weeks
    later because something looks off, and it comes back calling itself
    "your SI". write_env's own `prior` fallback cannot help: cfg["si_name"]
    is always truthy by the time it runs. The rescue has to be here.
    """
    chosen = (si_name or "").strip() or (cfg.get("si_name") or "").strip()
    if not chosen or chosen == _SERVER_PLACEHOLDER_SI_NAME:
        chosen = _installed_si_name(dest).strip() or "your SI"
    cfg["si_name"] = chosen
    return cfg


def _stop_si_before_overwrite(dest: str, progress=print) -> None:
    """Stop a running SI before we start replacing the files it has open.

    Added 2026-08-11. run_uninstall has always stopped the SI first — with a
    comment explaining that Windows holds open files and the delete then fails
    for a reason that looks like a permissions problem and is not. The UPDATE /
    REINSTALL path never got the same treatment: it went straight from the
    button to download_release(), which rmtree/replace()s top-level items on
    top of a live install. On Windows that raises PermissionError, surfaces as
    a bare "Download failed", and the customer has no idea their own running SI
    is what blocked it. Worse when it half-succeeds: some DLLs are replaced and
    some are not, the import probe passes against the OLD ones still loaded on
    disk, and the installer reports a successful upgrade that never happened.

    Best-effort by design — a machine where nothing is running must still
    install. Every call is check=False; failure to stop is not failure to
    install.
    """
    if not os.path.isdir(dest):
        return
    progress("Stopping your SI before updating its files…")
    try:
        if IS_LINUX:
            subprocess.run(["systemctl", "--user", "stop", "sabr-si.service"],
                           check=False, capture_output=True, env=_clean_env())
        elif IS_MAC:
            # Named, NOT positional. This is the UPDATE path: it must stop the
            # SI only, and deliberately leave the local brain agent running —
            # so it cannot just iterate _autostart_paths(). It used to index
            # [0] and happen to be right; the moment a second agent was added
            # that was one list reorder away from unloading the wrong job.
            plist = next((p for p in _autostart_paths(dest)
                          if p.endswith("com.sabr.si.plist")), None)
            if plist and os.path.exists(plist):
                # WITHOUT -w. `unload -w` writes a persistent per-user
                # Disabled override that survives the plist itself — so any
                # InstallError between this stop and register_autostart's
                # `load -w` left the customer's SI disabled across every
                # reboot, silently, with the plist still sitting there
                # looking correct. A plain unload stops the job for the
                # overwrite and leaves the old registration enabled; a
                # failed update then costs one session, not the autostart.
                subprocess.run(["launchctl", "unload", plist],
                               check=False, capture_output=True, env=_clean_env())
        elif IS_WINDOWS:
            # End the scheduled task FIRST — otherwise Task Scheduler can
            # relaunch the SI in the gap between the kill and the overwrite.
            # ...and end EVERY spelling. If the live install was registered
            # under a different task name than the one we create (it was, on
            # Dean's box), ending only ours leaves Task Scheduler free to
            # relaunch the SI in the middle of the file overwrite -- a half
            # updated tree with a live process reading it.
            for _task in _WINDOWS_TASK_NAMES:
                subprocess.run(["schtasks", "/end", "/tn", _task],
                               check=False, capture_output=True,
                               env=_clean_env())
            _stop_windows_si(dest)
    except (OSError, subprocess.SubprocessError) as e:
        _log(f"[warn] could not stop a running SI before update: {e}")


def _resume_si_after_failed_update(dest: str, progress=print) -> None:
    """Put the OLD SI back when an update dies between the stop above and
    register_autostart. Best-effort, macOS-specific.

    Companion to _stop_si_before_overwrite dropping `-w`: without this, a
    failed update still left the SI stopped for the rest of the session even
    though its autostart survived. `load -w` rather than plain load, on
    purpose — it also clears the persistent Disabled override that installs
    stopped by OLDER builds' `unload -w` are still carrying. The other
    platforms need no equivalent: Linux's `systemctl stop` and Windows'
    `schtasks /end` never touch the enabled state.
    """
    if not IS_MAC:
        return
    plist = next((p for p in _autostart_paths(dest)
                  if p.endswith("com.sabr.si.plist")), None)
    if not plist or not os.path.exists(plist):
        return
    try:
        subprocess.run(["launchctl", "load", "-w", plist],
                       check=False, capture_output=True, timeout=60,
                       env=_clean_env())
        progress("The update did not finish — your existing SI has been "
                 "started again, unchanged.")
    except (OSError, subprocess.SubprocessError) as e:
        _log(f"[warn] could not restart the previous SI after a failed "
             f"update: {e}")


# ── RESTORE — put a brain_state snapshot back ──────────────────────────
#
# The verb an owner needs on the worst day they will have with this product:
# their SI has forgotten them, or learned something wrong, or a database
# went bad. Until now the only recovery was UNINSTALL (which archives
# brain_state to a tarball nobody knows how to unpack) or nothing.
#
# Snapshots are produced by brain/state_backup.py on a schedule, and by an
# agent's own meta.* tools, both through
# self_improve.snapshot_brain_state() — capped at MAX_SNAPSHOTS = 5. This
# side of the contract is deliberately import-free: the frozen installer
# reads the DIRECTORY LAYOUT, never the payload's code.

#: Layout shared with brain/self_improve.py (_snapshots_dir) and
#: brain/state_backup.py. Two processes, one convention, no import.
SNAPSHOT_DIRNAME = "brain_state-snapshots"

#: Where the pre-restore safety copy goes. NOT brain_state-snapshots/.
#:
#: That directory is rotated to MAX_SNAPSHOTS = 5 by _rotate_snapshots, and
#: rotation deletes the OLDEST. Writing the safety copy there when the
#: directory is already full deletes one snapshot to make room — and the
#: oldest snapshot is precisely the one an owner restoring "from before this
#: all started" is reaching for. The safety copy would eat the restore
#: target. Out here it cannot: nothing rotates this directory.
SAFETY_DIRNAME = "brain_state-backups"

#: How long to wait for a stopped SI to actually be gone. systemd, launchd
#: and taskkill all return before the process has finished dying, and the
#: whole safety property below is "the SI is not alive", not "we asked it to
#: stop".
_RESTORE_STOP_WAIT_S = 30.0


def _si_ports(dest: str) -> list:
    """Ports this install could be listening on, best first.

    The resolved port is not persisted anywhere (see _resolve_port — it is
    chosen per install run), so an override in .env is checked first and the
    same 8000-8063 range _resolve_port walks is checked after. Scanning
    matters: an SI that landed on 8003 because 8000 was taken must not read
    as "not running" and let a restore proceed underneath it.
    """
    ports = []
    try:
        with open(os.path.join(dest, ".env"), encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                if key.strip() in ("SABR_SI_PORT", "LEON_PORT"):
                    value = value.strip()
                    if value.isdigit() and 1 <= int(value) <= 65535:
                        ports.append(int(value))
    except OSError:
        pass
    ports.extend(range(8000, 8064))
    seen, out = set(), []
    for p in ports:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def si_is_running(dest: str) -> bool:
    """True if OUR SI is answering for this install.

    _is_our_si, not _port_busy: a bare TCP connect proves only that
    something accepted a socket, and treating a stranger's dev server as
    "the SI is alive" would block a restore the owner is entitled to. The
    error is asymmetric though — a false "not running" corrupts state — so
    only ports that fail the connect outright are skipped cheaply.
    """
    for port in _si_ports(dest):
        if _port_busy(port) and _is_our_si(port):
            return True
    return False


def _snapshot_time(name: str, path: str) -> float:
    """When a snapshot was taken. The NAME first, mtime only as a fallback.

    A directory mtime is NOT when the snapshot was taken. Snapshots are
    created with shutil.copytree(), which copystat()s the source directory
    onto the destination — so every snapshot inherits brain_state/'s mtime,
    and a run of them taken hours apart can carry byte-identical
    timestamps. Sorting on that shows an owner an arbitrary order and makes
    `--restore` with no argument pick an arbitrary snapshot, on the one
    screen where "the most recent one" has to be right.

    The name is authoritative because snapshot_brain_state() writes it as
    "{label}_{unix_ts}" — that integer is the only record of when the copy
    was actually made. Mirrored in brain/state_backup.snapshot_time.
    """
    _, _, tail = name.rpartition("_")
    if tail.isdigit():
        return float(tail)
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def list_snapshots(dest: str = "") -> list:
    """Snapshots available for this install, newest first.

    Each entry: {"label", "path", "taken_at", "when"}. `when` is
    preformatted because this feeds a GUI list an owner reads at a glance —
    "snapshot_1787035228" tells them nothing about which one is yesterday's.
    """
    dest = os.path.abspath(dest or default_install_dir())
    root = os.path.join(dest, SNAPSHOT_DIRNAME)
    out = []
    try:
        names = os.listdir(root)
    except OSError:
        return []
    for name in names:
        path = os.path.join(root, name)
        if not os.path.isdir(path):
            continue        # brain/state_backup.py's schedule stamp is a file
        taken = _snapshot_time(name, path)
        out.append({"label": name, "path": path, "taken_at": taken,
                    "when": time.strftime("%Y-%m-%d %H:%M",
                                          time.localtime(taken))})
    out.sort(key=lambda r: r["taken_at"], reverse=True)
    return out


def _resolve_snapshot(dest: str, label: str) -> str:
    """Validate a label and return its absolute path, or raise InstallError.

    A label reaches this from a CLI argument, so it is untrusted input that
    names a directory we are about to copy the whole of over the customer's
    live state. "../.." would restore the parent of the install; an absolute
    path would restore anything on the disk. Checked structurally AND by
    realpath, because a symlink inside the snapshots directory passes the
    first check and defeats it.
    """
    label = (label or "").strip()
    if not label:
        raise InstallError("No snapshot chosen, so nothing was restored.")
    if (os.sep in label or (os.altsep and os.altsep in label)
            or label in (".", "..") or label.startswith(".")):
        raise InstallError(f"'{label}' is not a valid snapshot name. Nothing "
                           f"was restored.")
    root = os.path.realpath(os.path.join(dest, SNAPSHOT_DIRNAME))
    path = os.path.realpath(os.path.join(root, label))
    if not path.startswith(root + os.sep):
        raise InstallError("That snapshot is outside your SI's backup folder "
                           "and was rejected. Nothing was restored.")
    if not os.path.isdir(path):
        raise InstallError(f"There is no snapshot called '{label}'. Nothing "
                           f"was restored.")
    try:
        if not os.listdir(path):
            # An empty snapshot restores to an empty brain_state — i.e. it
            # erases the SI's memory while reporting success. Refuse.
            raise InstallError(
                f"The snapshot '{label}' is empty — it was probably "
                f"interrupted while being written. Restoring it would erase "
                f"your SI's memory, so nothing was restored. Pick another.")
    except OSError as e:
        raise InstallError(f"That snapshot could not be read ({type(e).__name__}). "
                           f"Nothing was restored.")
    return path


def restore_snapshot(dest: str = "", label: str = "", progress=print,
                     stop: bool = True) -> dict:
    """Restore brain_state/ from a snapshot. Refuses while the SI is alive.

    THE ORDER MATTERS AND IS NOT NEGOTIABLE:

      1. Validate the snapshot — before anything is stopped or touched.
      2. Stop the SI, then PROVE it stopped. A stop command returning is not
         a process having exited, on any of the three platforms. Restoring
         under a live SI means overwriting SQLite files it holds open: on
         Windows the rename fails halfway, and on Linux/macOS it "works" and
         the SI keeps writing through its old file handles into a directory
         that no longer exists — silent, total, unrecoverable corruption of
         the exact thing the owner was trying to rescue.
      3. Safety-copy the CURRENT state, outside the rotated snapshot
         directory (see SAFETY_DIRNAME).
      4. Stage the new state alongside, then swap by rename.

    Step 4 is why this does not simply call the payload's
    self_improve.snapshot_restore(): that one deletes the live brain_state
    contents first and copies second, so anything that fails in between —
    disk full, a permission error, a power cut — leaves NO brain_state at
    all. Staging first means the live directory is only ever replaced by a
    complete one, and a failure before the swap leaves the original exactly
    as it was. Same principle as _swap_payload.
    """
    dest = os.path.abspath(dest or default_install_dir())
    _log_open(dest)
    if not os.path.isdir(dest):
        raise InstallError(f"No Sabr SI install found at {dest}, so there is "
                           f"nothing to restore.")

    snap = _resolve_snapshot(dest, label)
    _log(f"[restore] snapshot={snap}")

    if stop:
        progress("Stopping your SI before restoring its memory…")
        _stop_si_before_overwrite(dest, progress)
        deadline = time.time() + _RESTORE_STOP_WAIT_S
        while time.time() < deadline and si_is_running(dest):
            time.sleep(1.0)

    # THE SAFETY GATE. Checked whether or not we did the stopping: a caller
    # passing stop=False is asserting it already stopped the SI, and this is
    # what verifies that claim rather than trusting it.
    if si_is_running(dest):
        raise InstallError(
            "Your SI is still running, so its memory was NOT restored — "
            "restoring underneath a live SI would corrupt it. Close it (or "
            "restart this computer) and run the restore again. Nothing has "
            "been changed.")

    live = os.path.join(dest, "brain_state")
    stamp = _timestamp()
    safety_root = os.path.join(dest, SAFETY_DIRNAME)
    safety = os.path.join(safety_root, f"pre-restore_{stamp}")
    staging = os.path.join(dest, f".sabr-restore-{stamp}")
    retired = os.path.join(dest, f".sabr-old-state-{stamp}")

    saved = ""
    try:
        if os.path.isdir(live):
            progress("Saving a copy of the current memory first…")
            os.makedirs(safety_root, exist_ok=True)
            shutil.copytree(live, safety, symlinks=False,
                            ignore=shutil.ignore_patterns("*.lock", "*.tmp"))
            saved = safety
            _log(f"[restore] safety copy -> {safety}")

        progress("Preparing the restore…")
        shutil.copytree(snap, staging, symlinks=False)

        progress("Restoring…")
        if os.path.isdir(live):
            _replace_with_retries(live, retired, "Retiring the current memory")
        _replace_with_retries(staging, live, "Restoring the saved memory")
    except InstallError:
        # _replace_with_retries already explained itself. Put the live
        # directory back if we got as far as moving it aside.
        if os.path.isdir(retired) and not os.path.exists(live):
            try:
                os.replace(retired, live)
            except OSError:
                pass
        shutil.rmtree(staging, ignore_errors=True)
        raise
    except Exception as e:
        if os.path.isdir(retired) and not os.path.exists(live):
            try:
                os.replace(retired, live)
            except OSError:
                pass
        shutil.rmtree(staging, ignore_errors=True)
        raise InstallError(
            f"The restore could not be completed ({type(e).__name__}). Your "
            f"SI's memory is unchanged"
            + (f" and a copy of it is in {saved}." if saved else ".")
            + _log_hint())
    finally:
        # Only ever the retired copy: the safety copy is the customer's and
        # stays. It is redundant with `retired` on a clean run and is the
        # only thing left if this process is killed mid-swap.
        shutil.rmtree(retired, ignore_errors=True)

    _log(f"[restore] done label={os.path.basename(snap)}")
    progress("Restored. Start your SI (or restart this computer) to use it.")
    return {"restored_from": os.path.basename(snap), "snapshot_dir": snap,
            "brain_state": live, "safety_copy": saved}


def run_install(token: str, dest: str, base_url: str,
                progress=print, dry_run: bool = False,
                si_name: str = "") -> dict:
    _log_open(dest)  # before anything can fail

    # Capture the CALLER's callback under its own name before the closure is
    # defined. `progress` is a parameter, so it is a local of run_install, and
    # a closure over it reads whatever that name points at when it RUNS — not
    # what it pointed at when the closure was defined. So `progress = _say`
    # below used to make _say call itself: the first status message recursed
    # ~1000 frames and died with RecursionError before a single step printed,
    # on every install, on all four platforms. The separate name is the fix —
    # _report can never be rebound to _say.
    _report = progress

    def _say(msg):
        _log(f"[step] {msg}")
        _report(msg)

    progress = _say
    cfg = fetch_config(base_url, token)
    cfg["_token"] = token
    resolve_identity(cfg, si_name, dest)
    # Nothing is overwritten in a dry run, so nothing needs stopping.
    if not dry_run:
        _stop_si_before_overwrite(dest, progress)
    try:
        Installer(cfg, dest, base_url, progress=progress, dry_run=dry_run).run()
    except BaseException:
        # The stop above took the old SI down; if the install/update dies
        # before register_autostart re-registers it, put the old one back
        # (macOS; no-op elsewhere and on a fresh box with no plist yet).
        # Re-raised untouched — this is recovery, not error handling.
        if not dry_run:
            _resume_si_after_failed_update(dest, progress)
        raise
    return cfg


# ── GUI (tkinter — stdlib, themed to the Sabr aesthetic) ───────────────

def existing_install(dest: str = "") -> str:
    """Return the path of an existing install, or "" if this is a fresh box.

    Judged by artifacts the installer itself writes, not by the folder merely
    existing — a customer who made an empty ~/SabrSI by hand should still get
    the plain install flow, not a scary "already installed" screen.
    """
    dest = os.path.abspath(dest or default_install_dir())
    if not os.path.isdir(dest):
        return ""
    for marker in ("run.py", ".env", "brain_state", "brain"):
        if os.path.exists(os.path.join(dest, marker)):
            return dest
    return ""


def report_version(dest: str = "") -> str:
    """What is installed on this machine, in a form a customer can read out.

    "Every install can say what version it is" was on the spec, and the only
    thing that could answer was the SI's own /api/version — which requires
    the SI to be RUNNING. The one time support needs the version is when it
    will not start, and that is exactly when that endpoint is gone. So the
    installer answers it too, from files on disk, with the SI dead.

    Two independent facts, because they can legitimately disagree and the
    disagreement is itself the diagnosis:
      - VERSION: the commit the payload was built from.
      - .sabr-release: the sha of the tarball this machine actually installed,
        and when. Written by the download step (see the comment there).
    A payload commit with no release stamp means an install from before
    stamping existed — update-blind, and worth knowing.
    """
    dest = os.path.abspath(dest or default_install_dir())
    out = []
    try:
        with open(os.path.join(dest, "VERSION"), encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if line.lower().startswith(("commit:", "date:")):
                    out.append(line)
    except OSError:
        pass
    try:
        with open(os.path.join(dest, ".sabr-release"), encoding="utf-8",
                  errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if "=" in line:
                    k, _, v = line.partition("=")
                    out.append(f"{k.strip()}: {v.strip()}")
    except OSError:
        pass
    if not out:
        # Say WHERE it looked. "not installed" with no path sends people
        # hunting; a wrong --dest is the likeliest reason to see this.
        return f"No Sabr SI install found at {dest}"
    return f"Sabr SI at {dest}\n" + "\n".join("  " + line for line in out)


def token_from_install(dest: str = "") -> str:
    """The install token belonging to an install already on this machine.

    UPDATE MUST NOT ASK FOR THE TOKEN AGAIN. Found 2026-08-12: choosing
    "UPDATE / REINSTALL" dropped the customer onto the same "Paste the
    install token from your onboarding page" screen as a first-time install.
    Six months after buying, nobody still has that token — it was pasted once
    into a box that never showed it again. So the one verb an owner reaches
    for when something looks wrong was the one verb they could not complete,
    and the failure looked like a lost purchase rather than a missing field.

    It was never actually lost. write_env persists the pasted token into .env
    as LEON_TENANT_TOKEN and again as SABR_TENANT_TOKEN (two names, one
    value — see the comment there). Read it back instead of asking.

    Returns "" when there is no install or no token in it; callers must fall
    back to prompting rather than proceeding tokenless.
    """
    dest = os.path.abspath(dest or default_install_dir())
    try:
        with open(os.path.join(dest, ".env"), encoding="utf-8",
                  errors="replace") as fh:
            found = {}
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    found[k.strip()] = v.strip()
    except OSError:
        return ""
    # SABR_ first: it is the name the entitlement gate reads, so it is the
    # one kept correct when the two ever drift.
    for key in ("SABR_TENANT_TOKEN", "LEON_TENANT_TOKEN"):
        if found.get(key):
            return found[key]
    return ""


def _choose_mode_gui(dest: str) -> str:
    """First screen when an install is already present: Update / Restore /
    Uninstall / Wipe / Cancel. Returns "install", "restore", "uninstall",
    "wipe", or "" (customer closed the window).

    WIPE exists because UNINSTALL alone was a privacy trap: by default it
    archives .env and brain_state to a tar.gz sitting right next to the
    install folder rather than deleting them — correct for "I want to
    reinstall later and keep what it learned," silently wrong for "I am
    selling or giving away this computer." --purge already did the right
    thing but only existed as a CLI flag nobody running the GUI would ever
    type. This puts the choice where the customer who needs it will
    actually see it, worded for what THEY are doing, not for what the code
    calls it.
    """
    import tkinter as tk

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    _apply_brand_icon(root)
    root.configure(bg=BG)
    # RESTORE is only offered when there is something to restore. A button
    # that always exists and sometimes leads to "you have no snapshots" is a
    # worse answer than no button, especially on the screen an owner reaches
    # when something is already wrong.
    _snaps = list_snapshots(dest)
    root.geometry("520x%d" % (470 if _snaps else 430))
    root.resizable(False, False)
    choice = {"mode": ""}

    def label(text, size=11, fg=FG, pady=(0, 0)):
        tk.Label(root, text=text, bg=BG, fg=fg, font=("Helvetica", size),
                 wraplength=460, justify="center").pack(pady=pady)

    _apply_wordmark(root, BG, (28, 4))
    label("Your SI is already installed.", 18, FG, (8, 4))
    label(dest, 9, DIM, (0, 6))
    label("Update reinstalls the latest version and keeps everything your SI "
          "has learned."
          + (" Restore rolls its memory back to a saved copy — pick this if "
             "it has forgotten something or started behaving oddly." if _snaps
             else "")
          + " Uninstall archives its memory first, then removes it "
          "— pick this if you might reinstall later. Wipe removes it AND "
          "deletes that memory outright — pick this if you're selling or "
          "giving away this computer.",
          10, DIM, (0, 16))

    def pick(mode):
        choice["mode"] = mode
        root.destroy()

    def button(text, mode, fg=FG, bg="#1a1a1a"):
        # _mk_click_button, not tk.Button — see "themed buttons" note above
        # _apply_wordmark: macOS aqua ignores tk.Button's bg=, which made
        # this exact screen (Update/Uninstall/Wipe) render white-on-white
        # on a Mac (Kyle, 2026-08-25).
        _mk_click_button(root, text, command=lambda: pick(mode), bg=bg, fg=fg,
                         activebackground="#2a2a2a", activeforeground=fg,
                         font=("Helvetica", 11, "bold"), padx=24, pady=8,
                         cursor="hand2", width=30).pack(pady=4)

    button("UPDATE / REINSTALL", "install")
    if _snaps:
        button("RESTORE A SAVED MEMORY (%d available)" % len(_snaps), "restore")
    button("UNINSTALL (keep a backup)", "uninstall", fg="#ff6b6b")
    button("WIPE — SELLING / GIVING AWAY THIS COMPUTER", "wipe", fg="#ff3b3b")
    button("CANCEL", "")
    root.mainloop()
    return choice["mode"]


def _run_uninstall_gui(dest: str, purge: bool = False):
    """Uninstall with a progress window, so the customer sees it working.

    purge=True is the WIPE path from _choose_mode_gui: no identity archive
    is written at all, so there is nothing left on disk for a future owner
    of this machine to find. purge=False keeps the archive (a deliberate
    reinstall-later convenience) — its own message now says exactly where
    that archive landed rather than "archived next to the install folder,"
    because a customer who can't find something can't judge whether it's
    safe to leave behind.
    """
    import tkinter as tk
    from tkinter import ttk
    import threading

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    _apply_brand_icon(root)
    root.configure(bg=BG)
    root.geometry("520x320")
    root.resizable(False, False)

    def label(text, size=11, fg=FG, pady=(0, 0)):
        l = tk.Label(root, text=text, bg=BG, fg=fg, font=("Helvetica", size),
                     wraplength=460, justify="center")
        l.pack(pady=pady)
        return l

    _apply_wordmark(root, BG, (28, 4))
    title = label("Wiping your SI…" if purge else "Removing your SI…", 18, FG, (8, 4))
    status = label("", 10, DIM, (14, 4))
    bar = ttk.Progressbar(root, length=380, mode="indeterminate")
    bar.pack(pady=(8, 0))
    bar.start(12)

    def set_status(text):
        root.after(0, lambda: status.config(text=str(text)))

    def work():
        try:
            archive_dir = os.path.dirname(os.path.abspath(dest)) or dest
            run_uninstall(dest, purge=purge, progress=set_status)
            if purge:
                ok, msg = True, ("Nothing was kept. Safe to hand off this "
                                 "computer — no memory or credentials remain.")
            else:
                ok, msg = True, (
                    f"Its memory was archived to {archive_dir} (not encrypted). "
                    f"Delete that file yourself once you're sure, or if you're "
                    f"selling or giving away this computer, run Uninstall "
                    f"again and choose Wipe instead.")
        except Exception as e:
            _log("[uninstall-crash] " + repr(e))
            ok, msg = False, f"{e}{_log_hint()}"

        def done():
            bar.stop(); bar.pack_forget()
            if ok:
                title.config(text="Wiped." if purge else "Uninstalled.")
            else:
                title.config(text="Wipe failed." if purge else "Uninstall failed.")
            status.config(text=msg, fg=DIM if ok else "#ff6b6b")
            # _mk_click_button, not tk.Button — see "themed buttons" note
            _mk_click_button(root, "CLOSE", command=root.destroy, bg="#1a1a1a",
                             fg=FG, activebackground="#2a2a2a", activeforeground=FG,
                             font=("Helvetica", 11, "bold"),
                             padx=28, pady=8, cursor="hand2").pack(pady=(16, 0))
        root.after(0, done)

    threading.Thread(target=work, daemon=True).start()
    root.mainloop()


def _run_restore_gui(dest: str):
    """Pick a snapshot, confirm, restore — with the work off the UI thread.

    Two-step on purpose. This verb replaces everything the SI has learned
    since the chosen snapshot, and unlike UPDATE (which keeps memory) or
    UNINSTALL (which archives it) there is no undo an owner would think to
    look for. The second screen names what is about to be lost and says
    where the safety copy will land BEFORE they commit, not after.
    """
    import tkinter as tk
    from tkinter import ttk
    import threading

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    snaps = list_snapshots(dest)
    if not snaps:
        # Reachable via --restore on a box with no snapshots; the button on
        # _choose_mode_gui is hidden in this case.
        raise InstallError(
            "Your SI has no saved memory snapshots on this computer yet, so "
            "there is nothing to restore. Nothing was changed.")

    root = tk.Tk()
    root.title("Sabr SI")
    _apply_brand_icon(root)
    root.configure(bg=BG)
    root.geometry("560x480")
    root.resizable(False, False)

    def label(text, size=11, fg=FG, pady=(0, 0)):
        l = tk.Label(root, text=text, bg=BG, fg=fg, font=("Helvetica", size),
                     wraplength=500, justify="center")
        l.pack(pady=pady)
        return l

    _apply_wordmark(root, BG, (24, 4))
    title = label("Restore your SI's memory.", 18, FG, (6, 4))
    status = label("Pick the copy to go back to. Newest first.", 10, DIM, (0, 10))

    listbox = tk.Listbox(root, bg="#111111", fg=FG, selectbackground="#2a2a2a",
                         selectforeground=FG, relief="flat", height=8,
                         width=56, font=("Courier", 10),
                         highlightthickness=0, activestyle="none")
    for row in snaps:
        listbox.insert("end", "  %s   %s" % (row["when"], row["label"]))
    listbox.selection_set(0)
    listbox.pack(pady=(0, 10))

    bar = ttk.Progressbar(root, length=380, mode="indeterminate")
    holder = {"buttons": []}

    def set_status(text):
        root.after(0, lambda: status.config(text=str(text), fg=DIM))

    def work(chosen):
        try:
            res = restore_snapshot(dest, chosen, progress=set_status)
            ok, msg = True, ("Your SI's memory is back to %s. The copy it "
                             "replaced is saved in %s. Start your SI, or "
                             "restart this computer."
                             % (chosen, res.get("safety_copy") or dest))
        except InstallError as e:
            ok, msg = False, str(e)
        except Exception as e:
            _log("[restore-crash] " + repr(e))
            ok, msg = False, f"{type(e).__name__}{_log_hint()}"

        def done():
            bar.stop(); bar.pack_forget()
            title.config(text="Restored." if ok else "Nothing was restored.")
            status.config(text=msg, fg=DIM if ok else "#ff6b6b")
            _mk_click_button(root, "CLOSE", command=root.destroy, bg="#1a1a1a",
                             fg=FG, activebackground="#2a2a2a",
                             activeforeground=FG,
                             font=("Helvetica", 11, "bold"),
                             padx=28, pady=8, cursor="hand2").pack(pady=(16, 0))
        root.after(0, done)

    def go():
        sel = listbox.curselection()
        if not sel:
            status.config(text="Pick a snapshot first.", fg="#ff6b6b")
            return
        chosen = snaps[sel[0]]["label"]
        for b in holder["buttons"]:
            b.pack_forget()
        listbox.pack_forget()
        title.config(text="Restoring…")
        status.config(text="Stopping your SI first…", fg=DIM)
        bar.pack(pady=(8, 0))
        bar.start(12)
        threading.Thread(target=work, args=(chosen,), daemon=True).start()

    def confirm():
        sel = listbox.curselection()
        if not sel:
            status.config(text="Pick a snapshot first.", fg="#ff6b6b")
            return
        chosen = snaps[sel[0]]
        status.config(
            text=("This replaces everything your SI has learned since "
                  "%s. A copy of its current memory is saved first, in "
                  "%s, so this can be undone. Your SI will be stopped "
                  "while it happens."
                  % (chosen["when"], os.path.join(dest, SAFETY_DIRNAME))),
            fg=DIM)
        holder["buttons"][0].config(text="YES — RESTORE %s" % chosen["label"],
                                    command=go)

    def button(text, command, fg=FG):
        b = _mk_click_button(root, text, command=command, bg="#1a1a1a", fg=fg,
                             activebackground="#2a2a2a", activeforeground=fg,
                             font=("Helvetica", 11, "bold"), padx=20, pady=8,
                             cursor="hand2", width=34)
        b.pack(pady=4)
        holder["buttons"].append(b)
        return b

    button("RESTORE THE SELECTED COPY", confirm)
    button("CANCEL", root.destroy, fg=DIM)
    root.mainloop()


#: Apple ships no python3.11+ on a stock Mac (nothing at all, or an old stub
#: below our floor) — this is where we send someone who hit that wall.
PYTHON_DOWNLOAD_URL_MAC = "https://www.python.org/downloads/macos/"


def _augment_missing_python_error(err: "InstallError") -> "InstallError":
    """On macOS, a 'no usable Python' failure gets the download page opened
    for the customer instead of leaving a bare URL sitting in a text label
    they have to retype into a browser by hand."""
    if not IS_MAC or "No usable Python 3 found" not in str(err):
        return err
    opened = False
    try:
        import webbrowser
        opened = bool(webbrowser.open(PYTHON_DOWNLOAD_URL_MAC))
    except Exception:
        opened = False
    suffix = (" Opening the Python download page for you — install it, "
              "then come back and click INSTALL again."
              if opened else
              f" Install it from {PYTHON_DOWNLOAD_URL_MAC}, then click "
              f"INSTALL again.")
    return InstallError(str(err) + suffix)


def _no_display_reason() -> str:
    """Why the GUI cannot open here, or "" if it can.

    Every GUI screen in this file (run_gui, _choose_mode_gui, the uninstall/
    restore windows) goes through tkinter, which on Linux needs a live X11
    or Wayland display server. Nothing checked for one before this existed:
    a customer who curled the raw binary onto a headless VPS, or opened it
    over a plain SSH session with no X11 forwarding, hit tk.Tk() with no
    $DISPLAY and no $WAYLAND_DISPLAY and got Tk's own crash straight out of
    main() — `_tkinter.TclError: no display name and no $DISPLAY
    environment variable` — as a raw traceback plus PyInstaller's "Failed
    to execute script" line. Reproduced 2026-08-27 on a headless Ubuntu
    22.04 container running the frozen onefile binary with $DISPLAY
    unset: exactly that TclError, unhandled, every time.

    Windows and macOS do not use $DISPLAY at all, so this only ever fires
    on Linux — checking it elsewhere would misfire on a perfectly normal
    Mac or Windows box.
    """
    if not IS_LINUX:
        return ""
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        return ""
    return ("No graphical display found — this looks like a headless "
            "machine or an SSH session without X11/Wayland forwarding.")


def _gui_crash_exit(err: Exception) -> None:
    """Print one clean sentence and exit(1) instead of the crash `err` was
    about to become — the toolkit-level catch that backs up _no_display_reason
    for the cases it cannot see up front (Tk not installed at all, or a
    $DISPLAY that is set but stale/unreachable)."""
    print(f"ERROR: Could not open a graphical window ({err}).", file=sys.stderr)
    print("Run it in text mode instead:", file=sys.stderr)
    print(f"  {os.path.basename(sys.argv[0])} --no-gui --token YOUR_TOKEN",
          file=sys.stderr)
    sys.exit(1)


def run_gui(base_url: str):
    # One program, five verbs — install, update, restore, uninstall, wipe —
    # chosen here instead of by a command-line flag the customer will never
    # type. RESTORE only appears when snapshots exist (_choose_mode_gui).
    found = existing_install()
    if found:
        mode = _choose_mode_gui(found)
        if mode == "restore":
            _run_restore_gui(found)
            return
        if mode == "uninstall":
            _run_uninstall_gui(found, purge=False)
            return
        if mode == "wipe":
            _run_uninstall_gui(found, purge=True)
            return
        if not mode:
            return
    import tkinter as tk
    from tkinter import ttk
    import threading

    BG, FG, DIM = "#000000", "#ffffff", "#888888"
    root = tk.Tk()
    root.title("Sabr SI")
    _apply_brand_icon(root)
    root.configure(bg=BG)
    root.geometry("520x420")
    root.resizable(False, False)

    def label(text, size=11, fg=FG, pady=(0, 0)):
        l = tk.Label(root, text=text, bg=BG, fg=fg,
                     font=("Helvetica", size), wraplength=460, justify="center")
        l.pack(pady=pady)
        return l

    _apply_wordmark(root, BG, (28, 4))
    title = label("Bring your SI to life.", 18, FG, (8, 4))
    sub = label("Paste the install token from your onboarding page.", 10, DIM, (0, 16))

    # On an update, the token is already on this machine — prefill it and say
    # so, instead of demanding a string the owner pasted once months ago and
    # has no way to see again. Empty on a fresh box, so the first-run flow is
    # untouched.
    _known_token = token_from_install(found) if found else ""
    if _known_token:
        title.config(text="Update your SI.")
        sub.config(text="Using the token already on this machine. Your SI "
                        "keeps everything it has learned.")

    token_var = tk.StringVar(value=_known_token)
    entry = tk.Entry(root, textvariable=token_var, width=42, justify="center",
                     bg="#111111", fg=FG, insertbackground=FG, relief="flat",
                     font=("Courier", 11))
    entry.pack(ipady=8)
    entry.focus()

    def placeholder_entry(caption, hint):
        """A captioned entry whose grey hint text is never mistaken for
        input: value() returns "" while the hint is showing."""
        label(caption, 9, DIM, (10, 2))
        var = tk.StringVar(value=hint)
        ent = tk.Entry(root, textvariable=var, width=42, justify="center",
                       bg="#111111", fg=DIM, insertbackground=FG, relief="flat",
                       font=("Helvetica", 10))
        ent.pack(ipady=6)
        showing_hint = [True]

        def focus_in(_event):
            if showing_hint[0]:
                showing_hint[0] = False
                var.set("")
                ent.config(fg=FG)

        def focus_out(_event):
            if not var.get().strip():
                showing_hint[0] = True
                var.set(hint)
                ent.config(fg=DIM)

        ent.bind("<FocusIn>", focus_in)
        ent.bind("<FocusOut>", focus_out)

        def value():
            return "" if showing_hint[0] else var.get().strip()
        return ent, value

    si_entry, si_value = placeholder_entry(
        "Name your SI (optional)", "e.g. Atlas")

    status = label("", 10, DIM, (14, 4))
    bar = ttk.Progressbar(root, length=380, mode="indeterminate")

    def set_status(text):
        root.after(0, lambda: status.config(text=text))

    def finish(cfg=None, error=None):
        def _done():
            bar.stop(); bar.pack_forget()
            if error:
                status.config(text=str(error), fg="#ff6b6b")
                btn.config(state="normal")
                for e in (entry, si_entry):
                    e.config(state="normal")
            else:
                # cfg comes back from run_install with the names already
                # resolved (local choice > server > "your SI"), so this is
                # the customer's chosen name — the first thing their mind
                # ever says to them.
                title.config(text=f"{cfg.get('si_name', 'your SI')} is alive.")
                sub.config(text="")
                # si_port is whatever the installer actually resolved — NOT
                # always 8000. Sending someone to 8000 when their SI is on
                # 8001 shows them a blank page or, worse, somebody else's app
                # with their dashboard key in the URL.
                _p = cfg.get("si_port") or 8000
                url = (f"http://localhost:{_p}" if cfg.get("brain_mode") == "local"
                       else cfg.get("hosted", {}).get("brain_url", ONBOARDING_URL))
                # The dashboard's login screen asks for a key and says
                # "paste the key shown during setup". Nothing here ever
                # showed one, so that instruction pointed at a value the
                # owner had no way to obtain and the install read as broken
                # at the very last step. Show it, and put it on the
                # clipboard so the next screen is a paste, not a retype.
                key = cfg.get("dashboard_key", "")
                if key:
                    keybox = tk.Entry(root, font=("TkFixedFont", 10),
                                      justify="center", relief="flat",
                                      readonlybackground=root["bg"], fg=FG,
                                      width=46)
                    keybox.insert(0, key)
                    keybox.config(state="readonly")
                    keybox.pack(pady=(6, 0))
                    try:
                        root.clipboard_clear(); root.clipboard_append(key)
                    except Exception:
                        pass  # a clipboard we cannot reach must not fail the install
                    status.config(
                        text="Dashboard key above (already copied) — "
                             f"paste it at {url}", fg=DIM)
                else:
                    status.config(text=f"Opening your dashboard — {url}", fg=DIM)
                import webbrowser; webbrowser.open(url)
        root.after(0, _done)

    def go():
        token = token_var.get().strip()
        if not token:
            status.config(text="Paste your token first.", fg="#ff6b6b")
            return
        # Read the tk var on the main thread, before the worker starts.
        chosen_si = si_value()
        btn.config(state="disabled")
        for e in (entry, si_entry):
            e.config(state="disabled")
        status.config(fg=DIM)
        bar.pack(pady=(4, 0)); bar.start(12)
        def work():
            try:
                cfg = run_install(token, default_install_dir(), base_url,
                                  progress=set_status, si_name=chosen_si)
                finish(cfg=cfg)
            except InstallError as e:
                _log(f"[fail] {e}")
                # A fresh Mac has no python3.11+ on its own — stock macOS ships
                # either nothing or a stub well below our floor. The website
                # promises "double-click it, nothing to install first," so a
                # dead-end error naming a URL the customer has to go type in
                # themselves breaks that promise twice over. This can't
                # silently self-heal (no controlling terminal to run brew/
                # Xcode CLT non-interactively from inside a frozen GUI app,
                # and no sudo prompt to drive), so the fix that fits the
                # constraint is: put the download page in front of them
                # instead of a URL in a text label, and tell them they can
                # come straight back to THIS window when it's done.
                e = _augment_missing_python_error(e)
                finish(error=e)
            except Exception as e:
                import traceback
                _log("[crash] " + traceback.format_exc())
                finish(error=f"Unexpected error: {e}{_log_hint()}")
        threading.Thread(target=work, daemon=True).start()

    # _mk_click_button, not tk.Button — see "themed buttons" note above
    # _apply_wordmark
    btn = _mk_click_button(root, "INSTALL", command=go, bg="#1a1a1a", fg=FG,
                           activebackground="#2a2a2a", activeforeground=FG,
                           font=("Helvetica", 11, "bold"),
                           padx=28, pady=8, cursor="hand2")
    btn.pack(pady=(16, 0))
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description="Sabr SI installer")
    ap.add_argument("--token", help="install token from the onboarding wizard")
    ap.add_argument("--si-name", default="",
                    help="name your SI (optional; overrides the server's choice)")
    ap.add_argument("--url", default=ONBOARDING_URL, help="onboarding server")
    ap.add_argument("--dest", default=default_install_dir())
    ap.add_argument("--no-gui", action="store_true")
    ap.add_argument("--dry-run", action="store_true",
                    help="download + config only; no deps/services/launch")
    ap.add_argument("--version", action="store_true",
                    help="print what is installed on this machine and exit")
    ap.add_argument("--update", action="store_true",
                    help="update an existing install in place, keeping its "
                         "memory and settings (no token needed)")
    ap.add_argument("--uninstall", action="store_true",
                    help="stop the SI, remove autostart + the install folder")
    ap.add_argument("--list-snapshots", action="store_true",
                    help="list the saved memory snapshots on this machine")
    ap.add_argument("--restore", nargs="?", const="", metavar="SNAPSHOT",
                    help="restore your SI's memory from a saved snapshot "
                         "(stops the SI first, and keeps a copy of the "
                         "current memory). Give a snapshot name, or pass no "
                         "value to restore the most recent one.")
    ap.add_argument("--purge", action="store_true",
                    help="with --uninstall: delete brain_state/.env instead of "
                         "archiving them first")
    ap.add_argument("--stream", action="store_true",
                    help="mirror this install's log to Sabr support so they "
                         "can watch it live and diagnose a failure. Sends log "
                         "text only — no remote access to this machine.")
    args = ap.parse_args()

    # Answered before ANYTHING else — including the live-stream setup below,
    # which posts to the onboarding server. --version must work on a broken
    # install, a half-install, a box with nothing on it, and (since it is
    # CI's smoke test for the frozen Mac binary) a runner with no interest
    # in appearing in the support viewer. It touches no network and starts
    # nothing. Two facts, deliberately: the BINARY's own build first (dev
    # until the workflow stamps it), then what is on disk.
    if args.version:
        print(f"Sabr installer build {INSTALLER_BUILD}")
        print(report_version(args.dest))
        return

    # Same class as --version: reads the disk, touches no network, and has
    # to work on an install that is currently broken — which is the only
    # state anyone reaches for either of these verbs in.
    if args.list_snapshots:
        rows = list_snapshots(args.dest)
        if not rows:
            print(f"No saved memory snapshots at "
                  f"{os.path.join(os.path.abspath(args.dest or default_install_dir()), SNAPSHOT_DIRNAME)}")
            return
        print(f"Saved memory snapshots (newest first), "
              f"restore with --restore NAME:")
        for row in rows:
            print(f"  {row['when']}  {row['label']}")
        return

    if args.restore is not None:
        label = args.restore
        if not label:
            # No name given: the newest. That is what "restore my SI"
            # means to someone whose SI is broken right now, and making
            # them copy a timestamped directory name first is friction at
            # the worst possible moment.
            rows = list_snapshots(args.dest)
            if not rows:
                print("ERROR: no saved memory snapshots on this machine, so "
                      "there is nothing to restore. Nothing was changed.",
                      file=sys.stderr)
                sys.exit(1)
            label = rows[0]["label"]
            print(f"Restoring the most recent snapshot: {label}")
        try:
            result = restore_snapshot(args.dest, label)
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"ERROR: Unexpected error: {type(e).__name__}{_log_hint()}",
                  file=sys.stderr)
            sys.exit(1)
        if result.get("safety_copy"):
            print(f"The memory it replaced is saved in {result['safety_copy']}")
        return

    # Also honoured as an env var so a tester can be told one line to paste
    # rather than an argument they have to attach to the right command.
    # STREAMING IS ON BY DEFAULT FOR THE WINDOWED INSTALL (2026-08-12).
    #
    # It used to require --stream or an env var. Nobody who double-clicks an
    # .exe passes a flag, so in practice it was never on for a single real
    # customer — proven by Aiden's failed install, which left NOTHING in the
    # live viewer. The one install we most needed to watch was the one that
    # broke, and it was the one we were blind to. Log text only, no remote
    # access; SABR_STREAM_INSTALL=0 turns it off for anyone who objects.
    _want_stream = args.stream or os.environ.get("SABR_STREAM_INSTALL") == "1"
    if os.environ.get("SABR_STREAM_INSTALL") != "0" and not args.uninstall:
        _want_stream = True
    if _want_stream:
        # The BINARY's build, not the payload's. See INSTALLER_BUILD.
        sid = _stream_enable(si_name=args.si_name, version=INSTALLER_BUILD)
        print(f"Live install id: {sid}  (share this with support)")
        _log(f"live streaming enabled: install_id={sid}")
        _log(f"installer build={INSTALLER_BUILD} "
             f"frozen={getattr(sys, 'frozen', False)} exe={sys.argv[0]}")
        # And the payload that was already there, separately labelled, so an
        # update shows both "what ran" and "what it is replacing".
        try:
            _log("payload before this run: "
                 + report_version(args.dest).splitlines()[0][:120])
        except Exception:
            _log("payload before this run: none / unreadable")

    if args.uninstall:
        try:
            sys.exit(run_uninstall(args.dest, purge=args.purge))
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"ERROR: Unexpected error: {e}{_log_hint()}", file=sys.stderr)
            sys.exit(1)

    # UPDATE — the fourth verb, and until now the only one with no way to
    # type it. "Re-run the installer" did work, but a customer told to update
    # had nothing to type and no way to tell an update from a fresh install.
    # It reuses the token already sitting in the install, so updating never
    # depends on the owner still having a string they pasted once months ago.
    if args.update:
        found = existing_install(args.dest)
        if not found:
            print(f"ERROR: nothing installed at {args.dest} to update — run "
                  f"the installer without --update to install.",
                  file=sys.stderr)
            sys.exit(1)
        token = args.token or token_from_install(found)
        if not token:
            print("ERROR: that install has no token recorded; pass --token "
                  "to update it.", file=sys.stderr)
            sys.exit(1)
        try:
            run_install(token, found, args.url, dry_run=args.dry_run,
                        si_name=args.si_name)
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"ERROR: Unexpected error: {e}{_log_hint()}", file=sys.stderr)
            sys.exit(1)
        return

    if args.no_gui or args.dry_run:
        if not args.token:
            ap.error("--token is required with --no-gui/--dry-run")
        try:
            run_install(args.token, args.dest, args.url, dry_run=args.dry_run,
                        si_name=args.si_name)
        except InstallError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            # Matches what the GUI has always shown. Anything unhandled used
            # to reach the customer as a Python traceback plus a PyInstaller
            # "Failed to execute script" line.
            print(f"ERROR: Unexpected error: {e}{_log_hint()}", file=sys.stderr)
            sys.exit(1)
        return

    # HEADLESS GUARD — checked before touching tkinter at all. See
    # _no_display_reason for the crash this replaces: an unhandled
    # _tkinter.TclError (or, on a box with no Tk libs installed,
    # ModuleNotFoundError) straight out of main(), printed as a raw
    # traceback plus "Failed to execute script". A customer with a token
    # already in hand (e.g. following a support script) gets dropped into
    # the same text-mode flow --no-gui uses instead of being told to go
    # retype the command; a customer with no token gets one clear sentence
    # and the exact command to run, not a stack trace or a hang.
    _no_gui_reason = _no_display_reason()
    if _no_gui_reason:
        if args.token:
            print(f"{_no_gui_reason} Continuing in text mode.")
            try:
                run_install(args.token, args.dest, args.url,
                            dry_run=args.dry_run, si_name=args.si_name)
            except InstallError as e:
                print(f"ERROR: {e}", file=sys.stderr)
                sys.exit(1)
            except Exception as e:
                print(f"ERROR: Unexpected error: {e}{_log_hint()}",
                      file=sys.stderr)
                sys.exit(1)
            return
        print(f"ERROR: {_no_gui_reason}", file=sys.stderr)
        print("Run it in text mode instead:", file=sys.stderr)
        print(f"  {os.path.basename(sys.argv[0])} --no-gui --token YOUR_TOKEN",
              file=sys.stderr)
        sys.exit(1)

    try:
        run_gui(args.url)
    except ImportError as e:
        # Covers two real, reproduced crashes: ModuleNotFoundError when Tk
        # itself is not installed (minimal server images that never had
        # python3-tk / Tcl-Tk pulled in), and the plain ImportError Python
        # raises when tkinter's C extension loads but a library IT needs is
        # missing — reproduced 2026-08-27 on a bare Ubuntu 22.04 box with
        # the .deb's pre-fix (no Depends) control file: "ImportError:
        # libxcb.so.1: cannot open shared object file". Both are the same
        # class of problem to the customer (this machine cannot run the
        # GUI) and get the same one-line answer instead of a traceback.
        _gui_crash_exit(e)
    except Exception as e:
        # Safety net for what the upfront check above cannot see: $DISPLAY
        # set but stale/unreachable. Same rule as everywhere else in this
        # file — nothing unhandled reaches the customer as a traceback.
        try:
            import tkinter
            is_tcl_error = isinstance(e, tkinter.TclError)
        except Exception:
            is_tcl_error = False
        if is_tcl_error:
            _gui_crash_exit(e)
        raise


if __name__ == "__main__":
    main()
