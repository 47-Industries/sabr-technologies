# SI Onboarding / Auth Spec (Dean, 2026-08-10 05:00, from TEST1 first-boot)

## Core principle
The SI must be BORN connected. Never let the brain's first impression be
"I'm not connected, log me in." That impression belongs to the installer, not the mind.

## Flow (in the installer, at the name+key step)
1. Install page: "TEST1 is alive." User pastes the license key from the
   Sabr Technologies site and names their SI (already works).
2. RIGHT THERE, add a button: [Connect Claude Subscription].
   - Click -> opens Claude OAuth authorize page in browser -> user authorizes ->
     token flows back to the SI. Subscription-based, NOT pasted API key.
   - If the machine's `claude` CLI is ALREADY logged in, detect it and skip the
     step entirely (nothing to do — that's the ideal path).
   - API-key paste stays as a fallback option for people who prefer it, but it is
     NOT the default and NOT the only path.
3. By the time the dashboard opens, the brain can already talk. No login nag.

## Local model = safety net, NOT the greeter
- Ship a small local model with every SI (like the VPS fallback: qwen2.5:3b).
- Purpose: if the subscription lapses / auth breaks LATER, the SI can still speak
  and explain what's wrong ("your Claude subscription needs reconnecting").
- It must NEVER be the front-door first impression. Connected-at-birth first,
  local model only as the "something went wrong, here's what" voice.

## Why TEST1 was mute (root cause, verified live)
- .env had LEON_BRAIN_MODE=local, no key. CLI-only Max-plan mode.
- claude.exe present at C:\Users\Mr. Sabr\.local\bin, creds file existed but STALE:
  CLI returned "Not logged in - Please run /login". No valid subscription reachable.
- No local model on the box -> total silence. Both failures compounded.

## Still-open Windows bugs found same night
- actuator.py: half-ported. Line 58 stubs a Windows named-pipe path, but serve()
  at ~1596 still hardcodes socket.AF_UNIX -> crashes on Windows. Hands don't work
  yet on Windows. Needs a real Windows IPC (named pipe or loopback+token).

## Then
- Cross-model review (GPT/Qwen/etc — different blind spots) on the onboarding flow.
- Beat on it with throwaway test git repos.
