#!/usr/bin/env python3
"""
Leon 3D Viewer — Three.js + Mixamo humanoid driven by MuJoCo brain.

Serves a Three.js page that renders a realistic Soldier model.
MuJoCo joint angles stream to the browser via polling /state.
The browser maps joints to Mixamo bones in real-time.

Usage:
  python3 view_leon_3d.py                     # port 8765
  python3 view_leon_3d.py --brain             # with brain sim
  python3 view_leon_3d.py --brain --neurons 1000
"""

import argparse
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from http.server import HTTPServer
from pathlib import Path

os.environ["MUJOCO_GL"] = "egl"

ASSETS_DIR = Path(__file__).parent / "brain" / "assets"

# ── Globals ───────────────────────────────────────────────────────────
_brain = None
_body = None
_sim_running = False
_sim_hz = 0.0
_lock = threading.Lock()


def init_brain(neurons: int):
    global _brain, _body
    sys.path.insert(0, os.path.dirname(__file__))
    from brain.brain import Brain
    from brain.embodiment import MuJoCoBody

    _brain = Brain(total_neurons=neurons)
    _body = MuJoCoBody()
    _body.init_metabolic(_brain)
    _brain.simulated_body = _body
    print(f"[3D] Brain: {_brain.total_neurons:,} neurons, 101 body systems")


def brain_loop():
    global _sim_hz, _sim_running
    _sim_running = True
    tick = 0
    t0 = time.time()
    while _sim_running:
        with _lock:
            _brain.step()
        tick += 1
        elapsed = time.time() - t0
        if elapsed > 1.0:
            _sim_hz = tick / elapsed
            tick = 0
            t0 = time.time()
        if tick % 5 == 0:
            time.sleep(0.001)


def get_state() -> dict:
    if _body is None:
        return {}
    with _lock:
        state = _body.get_state()
        # Add raw joint positions for bone mapping (26 values)
        state["joint_positions"] = _body.joint_positions.tolist()
        state["root_pos"] = [
            float(_body.data.qpos[0]),  # x
            float(_body.data.qpos[1]),  # y
            0.0,                         # z fixed by slide joint
        ]
        state["root_yaw"] = float(_body.data.qpos[2])
        state["_sim_hz"] = round(_sim_hz, 1)
        state["_prompt"] = _body.for_prompt()
        # Animation-relevant signals
        state["breath_phase"] = float(_body.respiratory.phase)
        state["heart_phase"] = float(_body.cardiac.phase)
        state["restlessness"] = float(_body.proprioceptive_drift.restlessness)
        state["social_signal"] = float(_body.social_signal)
    return state


# ── HTML ──────────────────────────────────────────────────────────────

HTML_PAGE = """<!DOCTYPE html>
<html>
<head>
<title>Leon's World</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0a0a0a; overflow: hidden; font-family: 'Segoe UI', sans-serif; }
  #canvas-container { width: 100vw; height: 100vh; }
  canvas { display: block; }
  #hud {
    position: fixed; top: 16px; right: 16px; width: 280px;
    background: rgba(10,10,15,0.85); border: 1px solid rgba(100,140,255,0.2);
    border-radius: 8px; padding: 14px; color: #c8d0e0;
    font-size: 12px; backdrop-filter: blur(8px);
    max-height: 90vh; overflow-y: auto;
  }
  #hud h2 { color: #7aa8ff; font-size: 13px; margin-bottom: 8px; letter-spacing: 1px; }
  .section { margin-bottom: 10px; }
  .section h3 { color: #556; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 3px; }
  .row { display: flex; justify-content: space-between; padding: 1px 0; }
  .row .k { color: #667; }
  .row .v { color: #9fc; font-variant-numeric: tabular-nums; }
  .prompt {
    background: rgba(20,40,20,0.6); padding: 8px; border-radius: 4px;
    margin-top: 8px; color: #8d8; font-style: italic; font-size: 11px;
    white-space: pre-wrap; border-left: 2px solid #4a4;
  }
  .hz { color: #fa7; }
  #info {
    position: fixed; bottom: 16px; left: 16px; color: #445;
    font-size: 11px;
  }
</style>
</head>
<body>
<div id="canvas-container"></div>
<div id="hud">
  <h2>LEON</h2>
  <div id="status" class="section"></div>
  <div id="body-info" class="section"></div>
  <div id="emotions-info" class="section"></div>
  <div class="prompt" id="prompt-box">connecting...</div>
</div>
<div id="info">drag to orbit &bull; scroll to zoom &bull; right-drag to pan</div>

<script type="importmap">
{
  "imports": {
    "three": "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js",
    "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/"
  }
}
</script>
<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// ── Scene setup ──────────────────────────────────────────
const container = document.getElementById('canvas-container');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1a1a2e);
scene.fog = new THREE.Fog(0x1a1a2e, 15, 40);

const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 2.5, 4);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
container.appendChild(renderer.domElement);

// ── Controls ─────────────────────────────────────────────
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.minDistance = 1;
controls.maxDistance = 30;
controls.maxPolarAngle = Math.PI * 0.85;
controls.update();

// ── Lighting ─────────────────────────────────────────────
const ambientLight = new THREE.AmbientLight(0x404060, 0.8);
scene.add(ambientLight);

const hemiLight = new THREE.HemisphereLight(0x87ceeb, 0x362a1e, 0.6);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(0xfff0dd, 2.0);
dirLight.position.set(5, 8, 3);
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 2048;
dirLight.shadow.mapSize.height = 2048;
dirLight.shadow.camera.near = 0.5;
dirLight.shadow.camera.far = 25;
dirLight.shadow.camera.left = -8;
dirLight.shadow.camera.right = 8;
dirLight.shadow.camera.top = 8;
dirLight.shadow.camera.bottom = -8;
scene.add(dirLight);

// Soft fill light
const fillLight = new THREE.DirectionalLight(0x8899cc, 0.4);
fillLight.position.set(-3, 4, -2);
scene.add(fillLight);

// ── Ground ───────────────────────────────────────────────
const groundGeo = new THREE.PlaneGeometry(40, 40);
const groundMat = new THREE.MeshStandardMaterial({
  color: 0x3a3a3a, roughness: 0.85, metalness: 0.1
});
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

// Grid
const grid = new THREE.GridHelper(40, 40, 0x444444, 0x333333);
grid.position.y = 0.01;
scene.add(grid);

// ── Room outlines (study) ────────────────────────────────
const wallMat = new THREE.MeshStandardMaterial({
  color: 0x555566, roughness: 0.9, transparent: true, opacity: 0.3
});
function addWall(x, y, z, w, h, d) {
  const g = new THREE.BoxGeometry(w, h, d);
  const m = new THREE.Mesh(g, wallMat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  scene.add(m);
}
// Study walls (4m x 4m, height 3m)
addWall(-1.3, 1.5, 2, 1.4, 3, 0.2);  // N left
addWall(1.3, 1.5, 2, 1.4, 3, 0.2);   // N right
addWall(-1.3, 1.5, -2, 1.4, 3, 0.2); // S left
addWall(1.3, 1.5, -2, 1.4, 3, 0.2);  // S right
addWall(2, 1.5, -1.3, 0.2, 3, 1.4);  // E top
addWall(2, 1.5, 1.3, 0.2, 3, 1.4);   // E bot
addWall(-2, 1.5, -1.3, 0.2, 3, 1.4); // W top
addWall(-2, 1.5, 1.3, 0.2, 3, 1.4);  // W bot

// Desk
const deskMat = new THREE.MeshStandardMaterial({ color: 0x5a3a1a, roughness: 0.7 });
const deskTop = new THREE.Mesh(new THREE.BoxGeometry(1, 0.04, 0.6), deskMat);
deskTop.position.set(1.2, 0.75, 1.2);
deskTop.castShadow = true;
scene.add(deskTop);

// Screen on desk
const screenMat = new THREE.MeshStandardMaterial({
  color: 0x112233, roughness: 0.3, metalness: 0.5, emissive: 0x0a1520, emissiveIntensity: 0.5
});
const screen = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.02), screenMat);
screen.position.set(1.2, 1.05, 1.45);
scene.add(screen);

// ── Load Soldier model ───────────────────────────────────
let model = null;
let bones = {};
const loader = new GLTFLoader();

loader.load('/assets/soldier.glb', (gltf) => {
  model = gltf.scene;
  model.scale.set(1, 1, 1);
  model.position.set(0, 0, 0);
  model.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
      // Hide the visor — Leon doesn't wear a helmet
      if (child.name && child.name.toLowerCase().includes('visor')) {
        child.visible = false;
      }
    }
    if (child.isBone) {
      bones[child.name] = child;
    }
  });
  scene.add(model);
  console.log('Leon loaded, bones:', Object.keys(bones).length);
});

// ── Joint mapping: MuJoCo index → Mixamo bone + axis ────
// MuJoCo joint order (26 actuators):
// 0: neck_pitch, 1: neck_yaw
// 2-7: right arm (shoulder p/y/r, elbow, wrist p/y)
// 8-13: left arm
// 14-19: right leg (hip p/y/r, knee, ankle p/r)
// 20-25: left leg
const JOINT_MAP = [
  // idx, boneName, axis, scale
  [0, 'mixamorig:Head', 'x', 1],
  [1, 'mixamorig:Head', 'y', 1],
  [2, 'mixamorig:RightArm', 'x', 1],
  [3, 'mixamorig:RightArm', 'y', 1],
  [4, 'mixamorig:RightArm', 'z', 1],
  [5, 'mixamorig:RightForeArm', 'x', 1],
  [6, 'mixamorig:RightHand', 'x', 1],
  [7, 'mixamorig:RightHand', 'y', 1],
  [8, 'mixamorig:LeftArm', 'x', 1],
  [9, 'mixamorig:LeftArm', 'y', 1],
  [10, 'mixamorig:LeftArm', 'z', 1],
  [11, 'mixamorig:LeftForeArm', 'x', 1],
  [12, 'mixamorig:LeftHand', 'x', 1],
  [13, 'mixamorig:LeftHand', 'y', 1],
  [14, 'mixamorig:RightUpLeg', 'x', 1],
  [15, 'mixamorig:RightUpLeg', 'y', 1],
  [16, 'mixamorig:RightUpLeg', 'z', 1],
  [17, 'mixamorig:RightLeg', 'x', -1],
  [18, 'mixamorig:RightFoot', 'x', 1],
  [19, 'mixamorig:RightFoot', 'z', 1],
  [20, 'mixamorig:LeftUpLeg', 'x', 1],
  [21, 'mixamorig:LeftUpLeg', 'y', 1],
  [22, 'mixamorig:LeftUpLeg', 'z', 1],
  [23, 'mixamorig:LeftLeg', 'x', -1],
  [24, 'mixamorig:LeftFoot', 'x', 1],
  [25, 'mixamorig:LeftFoot', 'z', 1],
];

// ── Visible body animation from brain systems ────────────
let t = 0;

function applyBodyAnimation(state, dt) {
  t += dt;
  if (!state) return;

  const bp = state.breath_phase || 0;
  const hp = state.heart_phase || 0;
  const restless = state.restlessness || 0;

  // BREATHING: chest expands/contracts with respiratory oscillator
  const breathAmt = Math.sin(bp * Math.PI * 2) * 0.04;
  const spine1 = bones['mixamorig:Spine1'];
  const spine2 = bones['mixamorig:Spine2'];
  if (spine1) {
    if (!spine1._def) spine1._def = spine1.rotation.clone();
    spine1.rotation.x = spine1._def.x + breathAmt;
    spine1.rotation.z = spine1._def.z + Math.sin(t * 0.3) * 0.005; // subtle sway
  }
  if (spine2) {
    if (!spine2._def) spine2._def = spine2.rotation.clone();
    spine2.rotation.x = spine2._def.x + breathAmt * 0.6;
  }

  // HEAD: subtle idle movement (looking around slightly)
  const head = bones['mixamorig:Head'];
  if (head) {
    if (!head._def) head._def = head.rotation.clone();
    head.rotation.y = head._def.y + Math.sin(t * 0.15) * 0.08;  // slow look L/R
    head.rotation.x = head._def.x + Math.sin(t * 0.22) * 0.03;  // subtle nod
  }

  // SHOULDERS: rise slightly with breathing, drop on exhale
  const lShoulder = bones['mixamorig:LeftShoulder'];
  const rShoulder = bones['mixamorig:RightShoulder'];
  if (lShoulder) {
    if (!lShoulder._def) lShoulder._def = lShoulder.rotation.clone();
    lShoulder.rotation.z = lShoulder._def.z - breathAmt * 0.3;
  }
  if (rShoulder) {
    if (!rShoulder._def) rShoulder._def = rShoulder.rotation.clone();
    rShoulder.rotation.z = rShoulder._def.z + breathAmt * 0.3;
  }

  // ARMS: subtle idle sway
  const lArm = bones['mixamorig:LeftArm'];
  const rArm = bones['mixamorig:RightArm'];
  if (lArm) {
    if (!lArm._def) lArm._def = lArm.rotation.clone();
    lArm.rotation.x = lArm._def.x + Math.sin(t * 0.4) * 0.02;
    lArm.rotation.z = lArm._def.z + Math.sin(t * 0.25) * 0.015;
  }
  if (rArm) {
    if (!rArm._def) rArm._def = rArm.rotation.clone();
    rArm.rotation.x = rArm._def.x + Math.sin(t * 0.4 + 1) * 0.02;
    rArm.rotation.z = rArm._def.z - Math.sin(t * 0.25 + 1) * 0.015;
  }

  // WEIGHT SHIFT: hips sway side to side (natural standing)
  const hips = bones['mixamorig:Hips'];
  if (hips) {
    if (!hips._def) hips._def = hips.rotation.clone();
    hips.rotation.z = hips._def.z + Math.sin(t * 0.2) * 0.01;
    // Restlessness: bigger movements
    if (restless > 0.2) {
      hips.rotation.z += Math.sin(t * 1.5) * restless * 0.03;
      hips.rotation.y = hips._def.y + Math.sin(t * 0.8) * restless * 0.02;
    }
  }

  // APPLY MuJoCo joint angles on top (amplified for visibility)
  const jp = state.joint_positions;
  if (jp && jp.length >= 26) {
    const AMP = 3.0;  // amplify small MuJoCo angles for visibility
    for (const [idx, boneName, axis, scale] of JOINT_MAP) {
      const bone = bones[boneName];
      if (!bone) continue;
      if (!bone._def) bone._def = bone.rotation.clone();
      // Add MuJoCo joint angle on top of idle animation
      bone.rotation[axis] += jp[idx] * scale * AMP;
    }
  }
}

// ── HUD update ───────────────────────────────────────────
function r(k, v) { return '<div class="row"><span class="k">' + k + '</span><span class="v">' + v + '</span></div>'; }

function updateHUD(s) {
  let st = '';
  st += r('Sim', '<span class="hz">' + (s._sim_hz || 0) + ' Hz</span>');
  st += r('Heart', (s.heart_rate_hz || '?') + ' Hz');
  st += r('Breath', (s.breath_rate_hz || '?') + ' Hz');
  st += r('Confidence', s.confidence || '?');
  st += r('Antenna', s.antenna_completeness || '?');
  if (s.trust_level !== undefined) st += r('Trust', s.trust_level + ' (' + (s.trust_mode||'') + ')');
  document.getElementById('status').innerHTML = '<h3>Vitals</h3>' + st;

  let bd = '';
  if (s.hunger !== undefined) bd += r('Hunger', s.hunger);
  if (s.fatigue !== undefined) bd += r('Fatigue', s.fatigue);
  if (s.thirst !== undefined) bd += r('Thirst', s.thirst);
  if (s.pain_total !== undefined) bd += r('Pain', s.pain_total);
  if (s.sympathetic !== undefined) bd += r('Sympathetic', s.sympathetic);
  if (s.parasympathetic !== undefined) bd += r('Parasympathetic', s.parasympathetic);
  if (s.mental_effort !== undefined) bd += r('Mental effort', s.mental_effort);
  if (s.creative_drive !== undefined) bd += r('Creative drive', s.creative_drive);
  document.getElementById('body-info').innerHTML = '<h3>Body</h3>' + bd;

  let em = '';
  if (s.emotions) {
    for (const [k, v] of Object.entries(s.emotions)) {
      if (k !== 'dominant' && v > 0) em += r(k, v);
    }
    if (s.emotions.dominant) em += r('Dominant', '<b>' + s.emotions.dominant + '</b>');
  }
  if (s.in_flow) em += r('Flow', (s.flow_depth * 100).toFixed(0) + '%');
  if (s.wonder > 0) em += r('Wonder', s.wonder);
  if (s.social_emotions) {
    const se = s.social_emotions;
    if (se.dominant_social) em += r('Social', '<b>' + se.dominant_social + '</b>');
  }
  document.getElementById('emotions-info').innerHTML = '<h3>Mind</h3>' + (em || r('State', 'neutral'));

  if (s._prompt) document.getElementById('prompt-box').textContent = s._prompt;
}

// ── State polling ────────────────────────────────────────
let latestState = null;

async function pollState() {
  try {
    const res = await fetch('/state');
    latestState = await res.json();
  } catch (e) {}
}
setInterval(pollState, 200);  // 5Hz state updates
pollState();

// ── Animation loop ───────────────────────────────────────
const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const dt = clock.getDelta();

  controls.update();

  if (latestState && model) {
    applyBodyAnimation(latestState, dt);

    // Keep Leon centered for now — walking comes later
    model.position.set(0, 0, 0);

    updateHUD(latestState);
  }

  renderer.render(scene, camera);
}
animate();

// ── Resize ───────────────────────────────────────────────
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
</script>
</body>
</html>"""


# ── HTTP Server ───────────────────────────────────────────────────────

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self._serve_text(HTML_PAGE, "text/html")

        elif self.path == "/state":
            state = get_state()
            self._serve_text(json.dumps(state, default=str), "application/json")

        elif self.path.startswith("/assets/"):
            fname = self.path.split("/assets/")[-1]
            fpath = ASSETS_DIR / fname
            if fpath.exists():
                self.send_response(200)
                self.send_header("Content-Type", "model/gltf-binary")
                self.send_header("Content-Length", str(fpath.stat().st_size))
                self.end_headers()
                with open(fpath, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_error(404)

        else:
            self.send_error(404)

    def _serve_text(self, text, content_type):
        data = text.encode() if isinstance(text, str) else text
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)


def main():
    parser = argparse.ArgumentParser(description="Leon 3D Viewer")
    parser.add_argument("--brain", action="store_true")
    parser.add_argument("--neurons", type=int, default=1000)
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    os.chdir(os.path.dirname(__file__) or ".")

    if args.brain:
        init_brain(args.neurons)
        global _sim_running
        _sim_running = True
        threading.Thread(target=brain_loop, daemon=True, name="brain").start()
        print(f"[3D] Brain running")

    server = ThreadedHTTPServer(("0.0.0.0", args.port), Handler)
    print(f"[3D] Leon 3D viewer: http://0.0.0.0:{args.port}/")
    print(f"[3D] Drag to orbit, scroll to zoom, right-drag to pan")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _sim_running = False
        print("\n[3D] Shutdown")


if __name__ == "__main__":
    main()
