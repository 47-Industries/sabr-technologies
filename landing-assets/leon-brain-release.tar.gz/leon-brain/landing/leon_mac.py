#!/usr/bin/env python3
"""
leon_mac.py — macOS (Darwin) backend for the Leon desktop actuator.

The actuator was written for Linux (wmctrl / xdotool / xrandr / notify-send)
with a Windows branch bolted on. On macOS none of those binaries exist, so
Darwin used to fall through into the Linux path and fail on every window
operation. This module is the macOS implementation.

Design rule: every public function here MIRRORS THE OUTPUT SHAPE of the
Linux command it replaces, so the call sites in actuator.py need only swap
`subprocess.check_output(["wmctrl", "-l"])` for `wmctrl_list()` and keep
their existing parsers unchanged.

  wmctrl_list()   -> str   exactly like `wmctrl -l`
  listmonitors()  -> str   exactly like `xrandr --listmonitors`
  focus/close/move-> bool
  notify()        -> bool
  tcc_preflight() -> dict  real permission probe, not a plist read

Stdlib only (subprocess / shutil / json / re / socket / tempfile / os).
Nothing here ever raises: failures return False / "" / sensible defaults.
Every subprocess call has a timeout.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import tempfile
from typing import List, Optional, Tuple

# ── Tunables ──────────────────────────────────────────────────────────────
# osascript against System Events can be slow on a busy machine (it walks
# the accessibility tree of every process), so the enumeration timeout is
# deliberately generous while single-window actions stay short.
_T_SHORT = 5      # single, targeted AppleScript action
_T_LIST = 10      # full window enumeration / system_profiler
_T_TINY = 3       # trivial probes


def _osascript(script: str, timeout: int = _T_SHORT) -> Tuple[bool, str]:
    """Run an AppleScript. Returns (ok, output_or_error_text).

    Never raises. `ok` is False on non-zero exit, timeout, or missing
    binary; the second element then carries stderr/diagnostic text so
    callers (notably tcc_preflight) can pattern-match on it.
    """
    exe = shutil.which("osascript") or "/usr/bin/osascript"
    try:
        p = subprocess.run(
            [exe, "-e", script],
            capture_output=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, "timeout"
    except FileNotFoundError:
        return False, "osascript not found"
    except Exception as e:  # pragma: no cover - defensive
        return False, f"{type(e).__name__}: {e}"
    out = (p.stdout or b"").decode("utf-8", errors="replace").strip()
    err = (p.stderr or b"").decode("utf-8", errors="replace").strip()
    if p.returncode != 0:
        return False, err or out or f"exit {p.returncode}"
    return True, out


def _hostname() -> str:
    """Local short hostname — the third field of a `wmctrl -l` line."""
    try:
        return (socket.gethostname() or "localhost").split(".")[0]
    except Exception:
        return "localhost"


# ── Window enumeration ────────────────────────────────────────────────────
# One record per window. We ask System Events for every process that has a
# UI, then for each of its windows. Output is emitted as
#     <process>\x1f<window title>\x1e
# because window titles routinely contain commas, tabs and newlines, and
# AppleScript's default list coercion ("a, b, c") is ambiguous.
_ENUM_SCRIPT = r'''
set AppleScript's text item delimiters to ""
set acc to ""
tell application "System Events"
    set procs to (every process whose background only is false)
    repeat with p in procs
        set pname to ""
        try
            set pname to name of p
        end try
        try
            repeat with w in (every window of p)
                set wname to ""
                try
                    set wname to name of w
                end try
                set acc to acc & pname & (ASCII character 31) & wname & (ASCII character 30)
            end repeat
        end try
    end repeat
end tell
return acc
'''


def _enumerate_windows() -> List[Tuple[str, str]]:
    """-> [(process_name, window_title), ...]. Empty list on any failure."""
    ok, out = _osascript(_ENUM_SCRIPT, timeout=_T_LIST)
    if not ok or not out:
        return []
    wins: List[Tuple[str, str]] = []
    for rec in out.split("\x1e"):
        if not rec.strip():
            continue
        proc, _, title = rec.partition("\x1f")
        proc = proc.strip()
        # Collapse embedded newlines/tabs: a wmctrl line is ONE line and the
        # title is the 4th whitespace-separated field (rest-of-line).
        title = " ".join(title.split())
        if not proc and not title:
            continue
        # Windows with no title (palettes, sheets) still exist and are
        # focusable; give them the process name so they are addressable.
        wins.append((proc, title or proc))
    return wins


def _synth_id(index: int) -> str:
    """Stable hex-looking window id, wmctrl-shaped (0x + 8 hex digits).

    NOTE: unlike X11 these ids are NOT persistent across calls — they are
    positional. Any caller that captures an id and reuses it later must
    re-list first. actuator.py's move-to-monitor flow does exactly that.
    """
    return "0x%08x" % (index & 0xFFFFFFFF)


def wmctrl_list() -> str:
    """Windows in exact `wmctrl -l` format:  <id> <desktop> <host> <title>

    Returns "" if the accessibility permission is missing or osascript
    fails — same as an empty window list, which every call site handles.
    """
    try:
        host = _hostname()
        lines = []
        for i, (_proc, title) in enumerate(_enumerate_windows()):
            lines.append("%s  %s %s %s" % (_synth_id(i), 0, host, title))
        return ("\n".join(lines) + "\n") if lines else ""
    except Exception:
        return ""


def _find(title_substring: str) -> Optional[Tuple[str, str]]:
    """First (process, title) whose title contains the substring (ci).

    Falls back to matching the PROCESS name, so focus("Safari") works even
    when the window title is the page title rather than the app name.
    """
    if not title_substring or not isinstance(title_substring, str):
        return None
    needle = title_substring.lower()
    wins = _enumerate_windows()
    for proc, title in wins:
        if needle in (title or "").lower():
            return proc, title
    for proc, title in wins:
        if needle in (proc or "").lower():
            return proc, title
    return None


def _esc(s: str) -> str:
    """Escape a Python string for embedding in an AppleScript literal."""
    return (s or "").replace("\\", "\\\\").replace('"', '\\"')


# ── Actions ───────────────────────────────────────────────────────────────
def focus(title_substring: str) -> bool:
    """Raise/activate the first window whose title matches. False if none."""
    try:
        hit = _find(title_substring)
        if not hit:
            return False
        proc, title = hit
        script = (
            'tell application "System Events"\n'
            '  tell process "%s"\n'
            '    set frontmost to true\n'
            '    try\n'
            '      perform action "AXRaise" of (first window whose name is "%s")\n'
            '    end try\n'
            '  end tell\n'
            'end tell\n' % (_esc(proc), _esc(title))
        )
        ok, _ = _osascript(script, timeout=_T_SHORT)
        return bool(ok)
    except Exception:
        return False


def close(title_substring: str) -> bool:
    """Politely close the matching window (clicks its close button).

    This is the macOS analogue of `wmctrl -c` — it asks the window to go
    away (so unsaved-changes sheets still appear); it does not kill the app.
    """
    try:
        hit = _find(title_substring)
        if not hit:
            return False
        proc, title = hit
        script = (
            'tell application "System Events"\n'
            '  tell process "%s"\n'
            '    set w to (first window whose name is "%s")\n'
            '    click (first button of w whose subrole is "AXCloseButton")\n'
            '  end tell\n'
            'end tell\n' % (_esc(proc), _esc(title))
        )
        ok, _ = _osascript(script, timeout=_T_SHORT)
        if ok:
            return True
        # Fallback: ask the application itself to close the window. Works
        # for scriptable apps whose close button we could not reach.
        script2 = (
            'tell application "%s"\n'
            '  try\n'
            '    close (first window whose name is "%s")\n'
            '  on error\n'
            '    close front window\n'
            '  end try\n'
            'end tell\n' % (_esc(proc), _esc(title))
        )
        ok2, _ = _osascript(script2, timeout=_T_SHORT)
        return bool(ok2)
    except Exception:
        return False


def move(title_substring: str, x: int, y: int, w: int, h: int) -> bool:
    """Set position and size of the matching window. False if no match.

    Coordinates are macOS global screen points, origin top-left of the
    main display — the same convention listmonitors() reports.
    """
    try:
        hit = _find(title_substring)
        if not hit:
            return False
        proc, title = hit
        try:
            xi, yi, wi, hi = int(x), int(y), int(w), int(h)
        except Exception:
            return False
        script = (
            'tell application "System Events"\n'
            '  tell process "%s"\n'
            '    set frontmost to true\n'
            '    set w to (first window whose name is "%s")\n'
            '    set position of w to {%d, %d}\n'
            '    set size of w to {%d, %d}\n'
            '  end tell\n'
            'end tell\n' % (_esc(proc), _esc(title), xi, yi, wi, hi)
        )
        ok, _ = _osascript(script, timeout=_T_SHORT)
        return bool(ok)
    except Exception:
        return False


# ── Monitors ──────────────────────────────────────────────────────────────
_RES_RE = re.compile(r"(\d{3,5})\s*[xX×]\s*(\d{3,5})")


def _displays_from_profiler() -> List[Tuple[str, int, int, bool]]:
    """-> [(name, width, height, is_main), ...] from system_profiler JSON."""
    exe = shutil.which("system_profiler") or "/usr/sbin/system_profiler"
    try:
        p = subprocess.run(
            [exe, "SPDisplaysDataType", "-json"],
            capture_output=True,
            timeout=_T_LIST,
        )
        if p.returncode != 0:
            return []
        data = json.loads((p.stdout or b"{}").decode("utf-8", errors="replace"))
    except Exception:
        return []

    out: List[Tuple[str, int, int, bool]] = []
    try:
        for gpu in data.get("SPDisplaysDataType", []) or []:
            for d in gpu.get("spdisplays_ndrvs", []) or []:
                name = str(d.get("_name") or "Display").strip() or "Display"
                # Key names vary by macOS version; try the known ones then
                # fall back to any value that looks like "2560 x 1440".
                raw = ""
                for k in ("_spdisplays_resolution", "spdisplays_resolution",
                          "_spdisplays_pixels", "spdisplays_pixels"):
                    if d.get(k):
                        raw = str(d.get(k))
                        break
                if not raw:
                    for v in d.values():
                        if isinstance(v, str) and _RES_RE.search(v):
                            raw = v
                            break
                m = _RES_RE.search(raw or "")
                if not m:
                    continue
                w, h = int(m.group(1)), int(m.group(2))
                is_main = str(d.get("spdisplays_main", "")).lower().endswith("yes") or \
                    bool(d.get("spdisplays_main"))
                out.append((name, w, h, is_main))
    except Exception:
        return out
    return out


def _main_display_size() -> Tuple[int, int]:
    """Main display bounds via AppleScript Finder; (0, 0) if unavailable."""
    ok, out = _osascript(
        'tell application "Finder" to get bounds of window of desktop',
        timeout=_T_TINY,
    )
    if ok and out:
        nums = re.findall(r"-?\d+", out)
        if len(nums) >= 4:
            try:
                return int(nums[2]) - int(nums[0]), int(nums[3]) - int(nums[1])
            except Exception:
                pass
    return 0, 0


def listmonitors() -> str:
    """Monitors in exact `xrandr --listmonitors` format.

    First line "Monitors: N", then one line per monitor:
        " 0: +*Display 1920/0x1080/0+0+0  Display"
    The physical-mm fields are emitted as 0 (macOS does not report them
    through these APIs); actuator.py's parser at _list_monitors() ignores
    them, it only reads idx, w, h, x, y and name.

    IMPORTANT / KNOWN LIMITATION: system_profiler does NOT expose display
    ORIGINS (the x/y offset of each screen in the global coordinate space).
    We can only learn each display's size. Rather than invent wrong origins
    for a multi-monitor Mac — which would move windows off-screen — we emit
    a SINGLE monitor covering the main display at +0+0. Multi-monitor
    move_to_monitor on macOS therefore always targets the main display.
    Fixing this properly needs a native call (Quartz CGGetActiveDisplayList
    / NSScreen.frame), which is out of scope for a stdlib-only module.
    """
    try:
        name = "Display"
        w = h = 0

        disps = _displays_from_profiler()
        if disps:
            main = next((d for d in disps if d[3]), disps[0])
            name, w, h = main[0], main[1], main[2]

        if w <= 0 or h <= 0:
            fw, fh = _main_display_size()
            if fw > 0 and fh > 0:
                w, h = fw, fh

        if w <= 0 or h <= 0:
            # Last resort: a sane default so downstream math never divides
            # by zero or produces negative geometry.
            w, h = 1920, 1080

        # xrandr monitor names have no spaces; normalize.
        name = re.sub(r"\s+", "-", name.strip()) or "Display"
        return "Monitors: 1\n 0: +*%s %d/0x%d/0+0+0  %s\n" % (name, w, h, name)
    except Exception:
        return "Monitors: 1\n 0: +*Display 1920/0x1080/0+0+0  Display\n"


# ── Notifications ─────────────────────────────────────────────────────────
def notify(title: str, message: str) -> bool:
    """Post a macOS Notification Center banner. False on failure.

    Note: notifications are delivered under the identity of the process
    running osascript (Script Editor / Terminal). If the user has banners
    muted for that app nothing appears even though this returns True.
    """
    try:
        t = _esc(str(title or "Leon"))[:120]
        m = _esc(str(message or ""))[:500]
        script = 'display notification "%s" with title "%s"' % (m, t)
        ok, _ = _osascript(script, timeout=_T_SHORT)
        return bool(ok)
    except Exception:
        return False


# ── TCC (privacy) preflight ───────────────────────────────────────────────
# macOS gates screen capture and UI scripting behind per-app grants that a
# plist read cannot reliably answer (the TCC db is itself SIP-protected and
# the grant is keyed to the *parent* app bundle). So we ATTEMPT the real
# operation and read the failure.
_ACC_DENIED_MARKERS = (
    "-1743",
    "not allowed assistive access",
    "not authorized to send apple events",
    "-25211",
)


def _probe_screen_recording() -> Tuple[bool, str]:
    """Actually take a screenshot and check we got real pixels back.

    Without Screen Recording permission `screencapture` still exits 0 and
    writes a file — it is just a blank/desktop-picture-only image. A denied
    capture is tiny, so we gate on file size as well as existence.
    """
    exe = shutil.which("screencapture") or "/usr/sbin/screencapture"
    path = ""
    try:
        fd, path = tempfile.mkstemp(prefix="leon-tcc-", suffix=".png")
        os.close(fd)
        try:
            p = subprocess.run(
                [exe, "-x", "-t", "png", path],
                capture_output=True,
                timeout=_T_LIST,
            )
        except subprocess.TimeoutExpired:
            return False, "screencapture timed out"
        except FileNotFoundError:
            return False, "screencapture not found (not macOS?)"
        if p.returncode != 0:
            err = (p.stderr or b"").decode("utf-8", errors="replace").strip()
            return False, "screencapture failed: %s" % (err or p.returncode)
        try:
            size = os.path.getsize(path)
        except OSError:
            return False, "screencapture produced no file"
        # 8 KB: a real desktop PNG is far larger; a permission-denied or
        # empty capture is well under this.
        if size < 8192:
            return False, "screencapture produced a %d-byte image — Screen Recording likely denied" % size
        return True, "captured %d bytes" % size
    except Exception as e:
        return False, "%s: %s" % (type(e).__name__, e)
    finally:
        if path:
            try:
                os.unlink(path)
            except OSError:
                pass


def _probe_accessibility() -> Tuple[bool, str]:
    """Attempt a harmless System Events query; detect the -1743 denial."""
    ok, out = _osascript(
        'tell application "System Events" to get name of first process',
        timeout=_T_SHORT,
    )
    if ok:
        return True, "System Events responded: %s" % (out or "(empty)")
    low = (out or "").lower()
    for marker in _ACC_DENIED_MARKERS:
        if marker in low:
            return False, "Accessibility denied: %s" % out
    if "timeout" in low:
        return False, "System Events timed out (permission dialog may be waiting)"
    return False, "System Events error: %s" % (out or "unknown")


def tcc_preflight() -> dict:
    """Probe both privacy grants Leon needs. Never raises.

    -> {"screen_recording": bool, "accessibility": bool, "detail": str}

    Both probes run the REAL operation, so the first call on a fresh Mac
    may pop the system permission dialogs. That is intentional: it is the
    only way to get the user prompted.
    """
    try:
        sr_ok, sr_detail = _probe_screen_recording()
    except Exception as e:
        sr_ok, sr_detail = False, "%s: %s" % (type(e).__name__, e)
    try:
        ax_ok, ax_detail = _probe_accessibility()
    except Exception as e:
        ax_ok, ax_detail = False, "%s: %s" % (type(e).__name__, e)

    parts = ["screen_recording: %s" % sr_detail, "accessibility: %s" % ax_detail]
    if not sr_ok:
        parts.append("Grant in System Settings > Privacy & Security > Screen Recording.")
    if not ax_ok:
        parts.append("Grant in System Settings > Privacy & Security > Accessibility.")
    return {
        "screen_recording": bool(sr_ok),
        "accessibility": bool(ax_ok),
        "detail": " | ".join(parts),
    }


if __name__ == "__main__":  # pragma: no cover - manual smoke test on a Mac
    print("--- tcc_preflight ---")
    print(json.dumps(tcc_preflight(), indent=2))
    print("--- listmonitors ---")
    print(listmonitors(), end="")
    print("--- wmctrl_list ---")
    print(wmctrl_list(), end="")
