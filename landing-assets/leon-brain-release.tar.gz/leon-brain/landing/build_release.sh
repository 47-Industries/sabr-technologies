#!/usr/bin/env bash
# build_release.sh — the ONE correct way to rebuild the SI installer tarball.
#
# Why this exists: the naive "tar czf landing/leon-brain-release.tar.gz ... -C /opt leon-brain"
# command has TWO fatal bugs:
#   1) Self-inclusion: tar writes the output file INTO the tree it is archiving,
#      so the archive snowballs to gigabytes (a runaway). We build to /tmp instead.
#   2) Secret leak: it ships .env (live API keys), owner_facts.py (Dean's private
#      facts), the business lead DB, session logs and private thoughts to every
#      client. This script excludes all of that and HARD-FAILS if any secret slips in.
#
# Usage:  bash landing/build_release.sh           # build + place locally
#         bash landing/build_release.sh --deploy  # also `railway up` the sabr-deploy service
set -euo pipefail

ROOT=/opt/leon-brain
SRC=/tmp/leon-brain-release.tar.gz
LANDING="$ROOT/landing"
# The live site is the sabr-technologies GIT repo — Railway auto-deploys from a
# push to master. landing/sabr-deploy is a leftover scratch dir holding a STALE
# 51KB index.html; `railway up` from there would clobber the live 62KB page with
# an old one, and it has no landing-assets/ dir for the tarball to land in. So
# the deploy path is now: place into the repo, commit, push, let Railway build.
SITE="$ROOT/workspaces/sabr-technologies"

echo "[build] tarring source -> $SRC (out-of-tree, no self-inclusion, REPRODUCIBLE)"
rm -f "$SRC"
cd /opt
# Reproducible build: --sort + fixed mtime + numeric owner + gzip -n (no timestamp)
# => identical input always yields identical bytes/hash, so no matter which Leon
#    process rebuilds, the two serve sources never drift out of sync.
tar --sort=name --mtime='UTC 2020-01-01' --owner=0 --group=0 --numeric-owner -cf - \
  --exclude='brain_state' --exclude='brain_state.*' --exclude='brain_state-snapshots' \
  --exclude='__pycache__' --exclude='.git' --exclude='node_modules' --exclude='workspaces' \
  --exclude='*.bak*' --exclude='landing/sabr-deploy' --exclude='*leon-brain-release.tar.gz*' \
  --exclude='_rsync_backup_*' --exclude='_shadow_quarantine_*' \
  --exclude='leon-brain/secure' \
  --exclude='leon-brain/.env' --exclude='leon-brain/.env.*' \
  --exclude='leon-brain/brain/owner_facts.py' \
  --exclude='leon-brain/business/data' \
  --exclude='leon-brain/thoughts' \
  --exclude='leon-brain/gio-landscaping' \
  --exclude='leon-brain/SESSION_LOG.md' --exclude='leon-brain/NEXT_SESSION.md' \
  --exclude='leon-brain/leon_notes.txt' \
  --exclude='leon-brain/USER.md' --exclude='leon-brain/OWNERSHIP.md' \
  --exclude='leon-brain/.cache' --exclude='leon-brain/.npm' --exclude='leon-brain/.leon' \
  --exclude='leon-brain/.claude' --exclude='leon-brain/.pytest_cache' \
  --exclude='leon-brain/wintest' --exclude='leon-brain/server/routers/wintest.py' \
  --exclude='leon-brain/mactest' \
  --exclude='leon-brain/tests' \
  --exclude='leon-brain/quarantine' \
  --exclude='leon-brain/landing/installers' \
  --exclude='leon-brain/landing/*.mp4' --exclude='leon-brain/landing/*.mp3' \
  --exclude='*/.venv' \
  --exclude='leon-brain/rust-core/.rustup' --exclude='leon-brain/rust-core/.cargo' \
  --exclude='leon-brain/rust-core/leon_core/target' --exclude='leon-brain/rust-core/rustify-sandbox' \
  leon-brain | gzip -n > "$SRC"

# List the archive ONCE to a file (avoids SIGPIPE/pipefail races with grep -q).
LIST=/tmp/leon-release-list.txt
tar tzf "$SRC" > "$LIST"

# ── Audit gate 1: filenames ────────────────────────────────────────────────
# Blocklists fail silently — anything not named here walks straight through.
# That is exactly how the 2026-07-30 artifact shipped .env and the lead DB
# while the old `grep -c secure/` check returned 0 and looked green.
# So this list is broadened AND backed by gates 2 and 3 below.
echo "[audit 1/3] scanning filenames for secrets/private data..."
# Zero-byte .db placeholders carry no schema and no rows — those are allowed;
# any NON-empty database is a hard fail.
LIST_AUDIT=/tmp/leon-release-list-audit.txt
tar tzvf "$SRC" | awk '{sz=$3; p=$NF; if (p ~ /\.(db|sqlite3?)([.]|$)/ && sz+0==0) next; print p}' > "$LIST_AUDIT"
LEAK=$(grep -E "(^|/)\.env($|\.)|owner_facts\.py|\.db($|\.)|\.sqlite3?$|SESSION_LOG\.md|NEXT_SESSION\.md|leon_notes\.txt|(^|/)secure/|(^|/)\.claude/|(^|/)\.ssh/|(^|/)wintest(/|\.py)|tesla-(control|keygen|http-proxy)|\.pem$|\.key$|id_rsa|private.*key|credentials?\.json|\.netrc" "$LIST_AUDIT" || true)
if [ -n "$LEAK" ]; then
  echo "[FAIL] secret/private files found in tarball — aborting:"; echo "$LEAK"; exit 1
fi

# ── Audit gate 2: content ──────────────────────────────────────────────────
# A renamed .env, or a live token pasted into a config or a comment, matches
# no filename pattern. So grep the actual bytes for key SHAPES, not names.
echo "[audit 2/3] scanning file CONTENT for live credential shapes..."
CONTENT_HITS=$(tar xzOf "$SRC" 2>/dev/null | grep -aoE \
  "sk-ant-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{32,}|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|xox[baprs]-[A-Za-z0-9-]{20,}|AKIA[0-9A-Z]{16}|AIza[A-Za-z0-9_-]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|(LEON_API_KEY|ELEVENLABS_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY|TWILIO_AUTH_TOKEN|IBM_QUANTUM_TOKEN)[[:space:]]*=[[:space:]]*[\"']?[A-Za-z0-9_-]{16,}" \
  | sort -u || true)
if [ -n "$CONTENT_HITS" ]; then
  echo "[FAIL] live credential shapes found INSIDE tarball content — aborting."
  echo "$CONTENT_HITS" | sed -E 's/(.{8}).*/\1…[redacted]/' | head -20
  exit 1
fi

# ── Audit gate 3: size ceiling ─────────────────────────────────────────────
# A legitimate release is ~80 MB. The bad artifact was 353 MB — 72% of it Rust
# registry and toolchain cache. Bloat is the cheapest possible signal that an
# exclude was bypassed, so treat a blown ceiling as a hard failure, not a note.
MAX_BYTES=$(( 160 * 1024 * 1024 ))
SZ=$(stat -c%s "$SRC")
if [ "$SZ" -gt "$MAX_BYTES" ]; then
  echo "[FAIL] tarball is $((SZ/1048576)) MB, ceiling is $((MAX_BYTES/1048576)) MB — an exclude was almost certainly bypassed."
  echo "       heaviest paths:"; tar tzvf "$SRC" | awk '{s[$NF]=$3} END{for(p in s) print s[p], p}' | sort -rn | head -10
  exit 1
fi
echo "[audit] all three gates passed ($((SZ/1048576)) MB)"
# Sanity — required files MUST be present.
for need in "leon-brain/run.py" "leon-brain/requirements.txt" "leon-brain/landing/bootstrap.sh" "leon-brain/brain/voice/stt.py"; do
  grep -qx "$need" "$LIST" || { echo "[FAIL] missing required file: $need"; exit 1; }
done
GOOD=$(sha256sum "$SRC" | awk '{print $1}')
echo "[ok] clean build: $(du -h "$SRC" | awk '{print $1}'), sha256=$GOOD"

# Pin the digest INTO the installer. bootstrap.sh reaches customers over
# HTTPS and is the trust anchor; a digest fetched from beside the tarball
# would only prove the payload arrived intact from whoever sent it. The pin
# is written here so the script and the release it installs can never drift
# — and a tarball built without updating it makes every install fail loudly
# rather than accept unverified bytes.
BOOTSTRAP="$LANDING/bootstrap.sh"
grep -q '^EXPECTED_RELEASE_SHA256=' "$BOOTSTRAP" || {
  echo "[FAIL] $BOOTSTRAP has no EXPECTED_RELEASE_SHA256 line to pin into"; exit 1; }
sed -i "s|^EXPECTED_RELEASE_SHA256=.*|EXPECTED_RELEASE_SHA256=\"$GOOD\"|" "$BOOTSTRAP"
bash -n "$BOOTSTRAP" || { echo "[FAIL] pinning broke bootstrap.sh syntax"; exit 1; }
echo "[pin] bootstrap.sh EXPECTED_RELEASE_SHA256=$(echo "$GOOD" | cut -c1-12)..."
echo "[pin] NOTE: commit bootstrap.sh and push it to 47-Industries/sabr-technologies"
echo "[pin]       (landing-assets/bootstrap.sh + .sha256) or customers fetch the old pin."

# Place into every serve location with a matching sidecar. Both the pinned
# bootstrap.sh and the tarball go to the site repo, or the pin and the payload
# drift and every install fails the digest check.
cp -f "$BOOTSTRAP" "$SITE/landing-assets/bootstrap.sh"
( cd "$SITE/landing-assets" && sha256sum bootstrap.sh > bootstrap.sh.sha256 )
for d in "$LANDING" "$SITE/landing-assets"; do
  cp -f "$SRC" "$d/leon-brain-release.tar.gz"
  ( cd "$d" && sha256sum leon-brain-release.tar.gz > leon-brain-release.tar.gz.sha256 )
  echo "[place] $d  ($(awk '{print $1}' "$d/leon-brain-release.tar.gz.sha256" | cut -c1-12)...)"
done

if [ "${1:-}" = "--deploy" ]; then
  echo "[deploy] committing release into sabr-technologies and pushing (Railway auto-deploys)..."
  cd "$SITE"
  git add landing-assets/leon-brain-release.tar.gz landing-assets/leon-brain-release.tar.gz.sha256 \
          landing-assets/bootstrap.sh landing-assets/bootstrap.sh.sha256
  if git diff --cached --quiet; then
    echo "[deploy] nothing changed — the served release already matches this build."
  else
    git -c user.name="Leon" -c user.email="leon@sabr.dev" \
        commit -q -m "release: leon-brain-release.tar.gz ${GOOD:0:12} (audited: filenames, content, size)"
    git push -q origin HEAD
    echo "[deploy] pushed — Railway is building."
    echo "[deploy] verify in ~2min: bash $LANDING/verify_release.sh"
  fi
fi
echo "[done] release hash $GOOD"
