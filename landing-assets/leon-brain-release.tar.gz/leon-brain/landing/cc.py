#!/usr/bin/env python3
"""Leon's hands on the Command Center data store.

Reads/writes the same JSON the dashboard uses, through the live API so the
in-memory server lock is respected. Usage:

  cc.py show
  cc.py add-event 2026-06-30 "Gio invoice due" "Gio"
  cc.py del-event 2026-06-30 0
  cc.py set <client_id> <field> <value>      # e.g. set gio invoice paid
  cc.py note <client_id> "new status text"

Client ids: gio chris joe angie gummies spark8web 33i korea marita rahoo soul
Fields: nda(none|sent|signed) contract(none|sent|signed)
        invoice(none|made|sent|paid) yours billed equity st nm who ent kind
"""
import json
import sys
import urllib.request

API = "http://127.0.0.1:8500/api/cc/data"


def load():
    with urllib.request.urlopen(API) as r:
        return json.load(r)


def save(data):
    body = json.dumps(data).encode()
    req = urllib.request.Request(API, data=body, method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as r:
        return json.load(r)


def main():
    a = sys.argv[1:]
    if not a or a[0] in ("show", "list"):
        print(json.dumps(load(), indent=2))
        return
    cmd = a[0]
    d = load()
    if cmd == "add-event":
        day, title = a[1], a[2]
        client = a[3] if len(a) > 3 else ""
        d.setdefault("events", {}).setdefault(day, []).append(
            {"title": title, "client": client})
    elif cmd == "del-event":
        day, idx = a[1], int(a[2])
        d.get("events", {}).get(day, []).pop(idx)
        if not d["events"][day]:
            del d["events"][day]
    elif cmd == "set":
        cid, field, val = a[1], a[2], a[3]
        if field in ("yours", "billed"):
            val = float(val) if "." in val else int(val)
        d.setdefault("ov", {}).setdefault(cid, {})[field] = val
        d.setdefault("log", []).insert(0, {
            "t": "(leon shell)", "client": cid,
            "action": "edit", "reason": f"set {field}={val}"})
    elif cmd == "note":
        cid, txt = a[1], a[2]
        d.setdefault("ov", {}).setdefault(cid, {})["st"] = txt
    else:
        print(__doc__)
        return
    save(d)
    print(f"OK — {cmd} applied. Live for Dean within 20s (or on refresh).")


if __name__ == "__main__":
    main()
