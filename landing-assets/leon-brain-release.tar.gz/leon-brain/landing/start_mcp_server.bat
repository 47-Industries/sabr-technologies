@echo off
REM Leon MCP Server Launcher for Windows
REM This connects Leon's tools to Claude Code

echo Starting Leon MCP server...
python3 -m brain.leon_mcp_server

