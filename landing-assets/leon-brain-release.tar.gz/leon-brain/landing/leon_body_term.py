#!/usr/bin/env python3
# Leon body terminal server — bridges the dashboard's xterm panes to local tmux.
# Protocol (matches dashboard/index.html):
#   ws path: /ws/term/<windowName>?key=...
#   server -> client: raw pty bytes
#   client -> server: JSON {type:"input",data} | {type:"resize",rows,cols}
import asyncio, json, os, pty, fcntl, termios, struct, signal, urllib.parse, sys, platform
from websockets.asyncio.server import serve

# Derive the install root from THIS file's location (…/<install>/landing/leon_body_term.py)
# instead of a hardcoded developer path. The old hardcoded path only existed on
# Dean's machine, so on every client box chdir failed and tmux opened in the wrong
# place. This makes the terminal server portable to any install location.
WORKDIR = os.environ.get("LEON_HOME") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8200

def set_winsize(fd, rows, cols):
    try:
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    except Exception:
        pass

async def handle(ws):
    try:
        path = ws.request.path
    except Exception:
        path = "/ws/term/main"
    name = urllib.parse.urlparse(path).path.rstrip("/").rsplit("/", 1)[-1] or "main"
    session = "leon-" + "".join(c for c in name if c.isalnum() or c in "-_") or "main"
    pid, fd = pty.fork()
    if pid == 0:
        try:
            os.chdir(WORKDIR)
        except Exception:
            pass
        os.environ["TERM"] = "xterm-256color"
        os.execvp("tmux", ["tmux", "new-session", "-A", "-s", session])
        os._exit(1)
    loop = asyncio.get_event_loop()
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
    def on_read():
        try:
            data = os.read(fd, 65536)
        except (OSError, BlockingIOError):
            return
        if data:
            asyncio.ensure_future(ws.send(data))
        else:
            try: loop.remove_reader(fd)
            except Exception: pass
            asyncio.ensure_future(ws.close())
    loop.add_reader(fd, on_read)
    try:
        async for msg in ws:
            try:
                m = json.loads(msg)
            except Exception:
                continue
            t = m.get("type")
            if t == "input":
                try: os.write(fd, m.get("data", "").encode())
                except Exception: pass
            elif t == "resize":
                set_winsize(fd, int(m.get("rows", 24)), int(m.get("cols", 80)))
    except Exception:
        pass
    finally:
        try: loop.remove_reader(fd)
        except Exception: pass
        try: os.close(fd)
        except Exception: pass
        try: os.kill(pid, signal.SIGHUP)
        except Exception: pass

async def main():
    async with serve(handle, "127.0.0.1", PORT, max_size=16 * 1024 * 1024):
        print(f"leon_body_term listening on :{PORT}", flush=True)
        await asyncio.Future()

if __name__ == "__main__":
    if platform.system() == "Windows":
        print("[TERMINAL] Skipping terminal server on Windows — Unix PTY not available. "
              "Dashboard terminal panes disabled. The SI is unaffected.", flush=True)
        sys.exit(0)
    asyncio.run(main())
