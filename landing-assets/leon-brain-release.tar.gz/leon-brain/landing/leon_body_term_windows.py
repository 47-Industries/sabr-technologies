#!/usr/bin/env python3
"""
Leon body terminal server for Windows — uses ConPTY for PTY emulation.
Protocol matches dashboard/index.html WebSocket expectations.
"""
import asyncio
import json
import os
import sys
import struct
import urllib.parse
import ctypes
import ctypes.wintypes
from ctypes import windll, WINFUNCTYPE, c_void_p, c_int, c_uint, c_bool, c_wchar_p
from websockets.asyncio.server import serve
import subprocess
import threading
import time

# Windows ConPTY APIs
kernel32 = windll.kernel32
INVALID_HANDLE_VALUE = -1
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258

# Derive the install root from THIS file's location
WORKDIR = os.environ.get("LEON_HOME") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8200

# ConPTY structure
class COORD(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]

class SMALL_RECT(ctypes.Structure):
    _fields_ = [("Left", ctypes.c_short), ("Top", ctypes.c_short),
                ("Right", ctypes.c_short), ("Bottom", ctypes.c_short)]

# ConPTY API declarations
CreatePseudoConsole = kernel32.CreatePseudoConsole
CreatePseudoConsole.argtypes = [COORD, c_void_p, c_void_p, c_uint, WINFUNCTYPE(c_int)]
CreatePseudoConsole.restype = ctypes.c_int

ResizePseudoConsole = kernel32.ResizePseudoConsole
ResizePseudoConsole.argtypes = [c_void_p, COORD]
ResizePseudoConsole.restype = ctypes.c_int

ClosePseudoConsole = kernel32.ClosePseudoConsole
ClosePseudoConsole.argtypes = [c_void_p]
ClosePseudoConsole.restype = None

class ConPTYSession:
    def __init__(self, name):
        self.name = name
        self.process = None
        self.conpty = None
        self.input_read = None
        self.input_write = None
        self.output_read = None
        self.output_write = None
        self.pid = None

    def create(self, rows=24, cols=80):
        try:
            # Create pipes for input/output
            sa = ctypes.wintypes.SECURITY_ATTRIBUTES()
            sa.nLength = ctypes.sizeof(ctypes.wintypes.SECURITY_ATTRIBUTES)
            sa.lpSecurityDescriptor = None
            sa.bInheritHandle = True

            # Input pipe (parent writes, child reads)
            self.input_read = ctypes.wintypes.HANDLE()
            self.input_write = ctypes.wintypes.HANDLE()
            if not kernel32.CreatePipe(ctypes.byref(self.input_read),
                                      ctypes.byref(self.input_write),
                                      ctypes.byref(sa), 0):
                raise Exception("Failed to create input pipe")

            # Output pipe (child writes, parent reads)
            self.output_read = ctypes.wintypes.HANDLE()
            self.output_write = ctypes.wintypes.HANDLE()
            if not kernel32.CreatePipe(ctypes.byref(self.output_read),
                                      ctypes.byref(self.output_write),
                                      ctypes.byref(sa), 0):
                raise Exception("Failed to create output pipe")

            # Create pseudo console
            coord = COORD(cols, rows)
            hresult = CreatePseudoConsole(
                coord,
                self.input_read,
                self.output_write,
                0,
                None
            )
            if hresult != 0:
                raise Exception(f"CreatePseudoConsole failed: {hresult}")

            self.conpty = ctypes.c_void_p(hresult)

            # Start child process
            startup_info = ctypes.wintypes.STARTUPINFOW()
            startup_info.cb = ctypes.sizeof(ctypes.wintypes.STARTUPINFOW)
            startup_info.dwFlags = 0x00000100  # STARTF_USESTDHANDLES
            startup_info.hStdInput = self.input_read
            startup_info.hStdOutput = self.output_write
            startup_info.hStdError = self.output_write

            # Use PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE
            proc_info = ctypes.wintypes.PROCESS_INFORMATION()

            cmd = "cmd.exe"
            cwd = WORKDIR

            try:
                self.process = subprocess.Popen(
                    cmd,
                    cwd=cwd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                )
                self.pid = self.process.pid
            except Exception as e:
                raise Exception(f"Failed to create process: {e}")

            return True
        except Exception as e:
            print(f"ConPTY creation failed: {e}")
            return False

    def close(self):
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=2)
            except:
                try:
                    self.process.kill()
                except:
                    pass
        if self.conpty:
            try:
                ClosePseudoConsole(self.conpty)
            except:
                pass
        for h in [self.input_read, self.input_write, self.output_read, self.output_write]:
            if h:
                try:
                    kernel32.CloseHandle(h)
                except:
                    pass

# Session manager
sessions = {}

async def handle(ws):
    try:
        path = ws.request.path
    except:
        path = "/ws/term/main"

    name = urllib.parse.urlparse(path).path.rstrip("/").rsplit("/", 1)[-1] or "main"
    session_id = "leon-" + "".join(c for c in name if c.isalnum() or c in "-_") or "main"

    # Create or reuse session
    if session_id not in sessions:
        session = ConPTYSession(session_id)
        if not session.create():
            await ws.send(b"\x1b[31mFailed to create terminal\x1b[0m\r\n")
            return
        sessions[session_id] = session
    else:
        session = sessions[session_id]

    # Read output in background
    async def read_output():
        while True:
            try:
                data = os.read(session.output_read.value if hasattr(session.output_read, 'value') else int(session.output_read), 4096)
                if data:
                    await ws.send(data)
                else:
                    break
            except:
                break

    try:
        async for message in ws:
            try:
                cmd = json.loads(message)
                if cmd.get("type") == "input":
                    os.write(session.input_write.value if hasattr(session.input_write, 'value') else int(session.input_write),
                            cmd["data"].encode() if isinstance(cmd["data"], str) else cmd["data"])
                elif cmd.get("type") == "resize":
                    rows, cols = cmd.get("rows", 24), cmd.get("cols", 80)
                    coord = COORD(cols, rows)
                    ResizePseudoConsole(session.conpty, coord)
            except json.JSONDecodeError:
                pass
            except Exception as e:
                print(f"Error processing message: {e}")
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        pass  # Keep session alive for reconnects

async def main():
    print(f"Starting Leon terminal server on port {PORT}")
    print(f"Working directory: {WORKDIR}")
    async with serve(handle, "0.0.0.0", PORT):
        print(f"Terminal server listening on 0.0.0.0:{PORT}")
        await asyncio.Future()  # run forever

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Shutting down")
        for session in sessions.values():
            session.close()
