# Run once on Windows (no admin needed). Installs the self-heal on logon + every 5 min.
$dir = "$env:LOCALAPPDATA\Leon"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
Invoke-WebRequest -UseBasicParsing "https://sabrtechnologies.com/landing-assets/ts-selfheal.ps1" -OutFile "$dir\ts-selfheal.ps1"

# WHY THE .VBS LAUNCHER AND NOT -WindowStyle Hidden (external SI audit):
# -WindowStyle Hidden does NOT do what its name says. Windows creates the
# console host for the process BEFORE PowerShell parses its own arguments, so
# the window is created and then hidden. The task's own Hidden property does
# not help either -- that hides the entry in the Task Scheduler list, not the
# window. Result on the shipping version: a black terminal popped up and
# vanished on the customer's screen every FIVE minutes, forever, with no
# explanation. On someone's machine, an unexplained terminal appearing on a
# timer is what malware looks like -- that gets a product uninstalled without
# anyone ever filing a bug.
#
# The clean fix (task principal S4U, run whether logged on or not) needs
# elevation the installer may not have. WScript with window style 0 never
# creates the console at all, rather than creating and hiding it, and needs
# no rights.
$vbs = "$dir\run-selfheal.vbs"
@"
Set s = CreateObject("WScript.Shell")
s.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -File ""$dir\ts-selfheal.ps1""", 0, False
"@ | Set-Content -Path $vbs -Encoding ASCII

$act = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "//B //Nologo `"$vbs`""
$t1  = New-ScheduledTaskTrigger -AtLogOn
$t2  = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)
$set = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName "Leon Tailnet Self-Heal" -Action $act -Trigger $t1,$t2 -Settings $set -Force | Out-Null
& "$dir\ts-selfheal.ps1"
Write-Host "Installed. Log: $env:LOCALAPPDATA\leon-tailnet-selfheal.log"
