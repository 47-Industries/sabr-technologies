#!/usr/bin/env bash
# RETIRED 2026-08-11. Do not use. Do not un-retire without reading this.
#
# What this script used to do: clone https://github.com/sabrtechnologies/leon-brain,
# tar it up, and `cp -f` the result over landing/leon-brain-release.tar.gz.
#
# Why that is dangerous now: that repo is a fossil. 106 of its 388 shared files
# had drifted from the tree that actually ships, and its claude_api_responder.py
# had not been touched since 2026-06-24. Worse, the failure is SILENT: the
# onboarding server hashes whatever tarball is on disk and serves that digest,
# so an install of the wrong payload verifies cleanly and reports success. The
# customer gets months-old code and nothing anywhere says so.
#
# It also claimed in its own header to be "the ONE correct way" to cut a
# release — the same claim landing/build_release.sh makes. Two scripts both
# asserting they are the only correct one is how today happened. Only one of
# them can be right, so this one is now a wall instead of a footgun.
#
# THE ONE CORRECT WAY:
#     bash /opt/leon-brain/landing/build_release.sh [--deploy]
#
# That script builds from the live tree, runs three hard audit gates (secret
# filenames, live credential shapes inside file contents, size ceiling),
# requires every entry point to be present, pins the sha256 into bootstrap.sh,
# and places atomically into every serve location.
set -euo pipefail
echo "build_client_release.sh is RETIRED — it built from a fossil repo and could" >&2
echo "silently ship months-old code that still passes digest verification." >&2
echo >&2
echo "Use:  bash /opt/leon-brain/landing/build_release.sh [--deploy]" >&2
exit 1
