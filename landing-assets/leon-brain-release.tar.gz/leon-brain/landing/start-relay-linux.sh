#!/bin/bash
# Start Leon relay services on Linux PC
# Run this: bash start-relay-linux.sh
# Or download and run: curl -s https://2.25.174.126:8500/start-relay-linux.sh | bash

set -e

echo "[*] Stopping old relay processes..."
pkill -f "actuator.py|pc_relay.py" 2>/dev/null || true
sleep 1

WORK_DIR="$HOME/leon-relay-work"
mkdir -p "$WORK_DIR"
cd "$WORK_DIR"

echo "[*] Downloading relay services..."
# Get pc_relay.py
if ! curl -fsSL -k -o pc_relay.py "https://2.25.174.126:8500/pc_relay.py"; then
    echo "[ERROR] Failed to download pc_relay.py"
    exit 1
fi
chmod +x pc_relay.py

# Get actuator.py — try to clone first, fall back to download
echo "[*] Getting actuator.py..."
if [ -d "leon-actuator" ]; then
    cd leon-actuator
    git pull 2>/dev/null || true
    cd ..
else
    if ! git clone --depth 1 https://github.com/47-Industries/leon-actuator.git 2>/dev/null; then
        echo "[!] Git clone failed, downloading actuator.py directly..."
        # Fallback: try to get it from the VPS
        if ! curl -fsSL -k -o "leon-actuator-actuator.py" "https://2.25.174.126:8500/actuator.py"; then
            echo "[ERROR] Could not get actuator.py from VPS either"
            echo "[*] Try manually: git clone https://github.com/47-Industries/leon-actuator.git"
            exit 1
        fi
        mkdir -p leon-actuator
        mv "leon-actuator-actuator.py" "leon-actuator/actuator.py"
    fi
fi

echo "[*] Starting services..."
cd "$WORK_DIR"

# Start actuator daemon
echo "[*] Starting actuator.py..."
cd leon-actuator
python3 actuator.py > /tmp/actuator.log 2>&1 &
ACTUATOR_PID=$!
echo "    PID: $ACTUATOR_PID"
cd "$WORK_DIR"

# Give actuator time to create socket
sleep 2

# Start relay
echo "[*] Starting pc_relay.py on port 9100..."
python3 pc_relay.py --port 9100 --bind 0.0.0.0 > /tmp/pc_relay.log 2>&1 &
RELAY_PID=$!
echo "    PID: $RELAY_PID"

sleep 1

# Test connectivity
echo "[*] Testing..."
if ps -p $ACTUATOR_PID > /dev/null && ps -p $RELAY_PID > /dev/null; then
    echo "[OK] Both services running!"
    echo "    Actuator: PID $ACTUATOR_PID"
    echo "    Relay:    PID $RELAY_PID on port 9100"
    echo ""
    echo "[*] To verify:"
    echo "    curl -s http://localhost:9100 | head -c 100"
else
    echo "[ERROR] Services failed to start"
    echo "    Check logs:"
    echo "      cat /tmp/actuator.log"
    echo "      cat /tmp/pc_relay.log"
    exit 1
fi

echo ""
echo "[DONE] Relay ready. The VPS can now reach your machine on port 9100 via Tailscale."
