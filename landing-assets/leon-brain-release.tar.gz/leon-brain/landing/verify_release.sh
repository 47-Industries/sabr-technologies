#!/usr/bin/env bash
# verify_release.sh — audit ANY release tarball, from anywhere, at any time.
#
# Why this exists separately from build_release.sh:
# build_release.sh's gates only protect artifacts that build_release.sh built.
# The 2026-07-30 leak got in precisely because something ELSE placed a tarball
# into landing/ — the guard worked, it was bypassed. So the audit has to be
# runnable against a finished object, including one already being served.
#
# Usage:
#   bash landing/verify_release.sh                       # audit both live URLs + local copies
#   bash landing/verify_release.sh /path/to/file.tar.gz  # audit one file
#   bash landing/verify_release.sh https://host/x.tar.gz # audit one URL
#
# Exit 0 = clean. Exit 1 = DO NOT SHIP.
set -uo pipefail

MAX_BYTES=$(( 160 * 1024 * 1024 ))

NAME_PAT="(^|/)\.env($|\.)|owner_facts\.py|\.db($|\.)|\.sqlite3?$|SESSION_LOG\.md|NEXT_SESSION\.md|leon_notes\.txt|(^|/)secure/|(^|/)\.claude/|(^|/)\.ssh/|(^|/)wintest(/|\.py)|tesla-(control|keygen|http-proxy)|\.pem$|\.key$|id_rsa|private.*key|credentials?\.json|\.netrc"

CONTENT_PAT="sk-ant-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{32,}|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|xox[baprs]-[A-Za-z0-9-]{20,}|AKIA[0-9A-Z]{16}|AIza[A-Za-z0-9_-]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|(LEON_API_KEY|ELEVENLABS_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY|TWILIO_AUTH_TOKEN|IBM_QUANTUM_TOKEN)[[:space:]]*=[[:space:]]*[\"']?[A-Za-z0-9_-]{16,}"

RC=0

audit() {
  local label="$1" f="$2" fail=0
  local sz; sz=$(stat -c%s "$f")
  local sha; sha=$(sha256sum "$f" | awk '{print $1}')
  echo "── $label"
  echo "   $((sz/1048576)) MB   sha256 ${sha:0:16}…"

  # Match on names, but drop ZERO-BYTE database placeholders: an empty .db has
  # no schema and no rows, so it carries nothing. Any non-empty one is a leak.
  local names; names=$(tar tzvf "$f" 2>/dev/null \
    | awk '{sz=$3; p=$NF; if (p ~ /\.(db|sqlite3?)([.]|$)/ && sz+0==0) next; print p}' \
    | grep -E "$NAME_PAT" || true)
  if [ -n "$names" ]; then
    echo "   [FAIL] gate 1 — secret/private FILENAMES present:"
    echo "$names" | sed 's/^/          /' | head -20
    fail=1
  else echo "   [ok]   gate 1 filenames"; fi

  local hits; hits=$(tar xzOf "$f" 2>/dev/null | grep -aoE "$CONTENT_PAT" | sort -u || true)
  if [ -n "$hits" ]; then
    echo "   [FAIL] gate 2 — live credential SHAPES inside file content:"
    echo "$hits" | sed -E 's/(.{8}).*/          \1…[redacted]/' | head -20
    fail=1
  else echo "   [ok]   gate 2 content"; fi

  if [ "$sz" -gt "$MAX_BYTES" ]; then
    echo "   [FAIL] gate 3 — $((sz/1048576)) MB exceeds $((MAX_BYTES/1048576)) MB ceiling; an exclude was bypassed:"
    tar tzvf "$f" | awk '{s[$NF]=$3} END{for(p in s) print s[p], p}' | sort -rn | head -8 | sed 's/^/          /'
    fail=1
  else echo "   [ok]   gate 3 size"; fi

  if [ "$fail" = 1 ]; then echo "   >>> DO NOT SHIP THIS ARTIFACT"; RC=1
  else echo "   >>> clean"; fi
  echo
}

fetch_and_audit() {
  local url="$1" tmp; tmp=$(mktemp /tmp/verify-rel-XXXX.tar.gz)
  if curl -fsSL --max-time 300 -o "$tmp" "$url"; then audit "$url" "$tmp"
  else echo "── $url"; echo "   [warn] unreachable — skipped"; echo; fi
  rm -f "$tmp"
}

if [ $# -gt 0 ]; then
  for t in "$@"; do
    case "$t" in http://*|https://*) fetch_and_audit "$t" ;; *) audit "$t" "$t" ;; esac
  done
else
  echo "auditing every place a customer could download from"; echo
  fetch_and_audit "https://sabr-technologies-production.up.railway.app/landing-assets/leon-brain-release.tar.gz"
  fetch_and_audit "http://2.25.174.126:8500/landing-assets/leon-brain-release.tar.gz"
  for f in /opt/leon-brain/landing/leon-brain-release.tar.gz \
           /opt/leon-brain/workspaces/sabr-technologies/landing-assets/leon-brain-release.tar.gz \
           /opt/leon-brain/landing/sabr-deploy/landing-assets/leon-brain-release.tar.gz; do
    [ -f "$f" ] && audit "$f" "$f"
  done
fi

[ "$RC" = 0 ] && echo "ALL CLEAN" || echo "LEAKS FOUND — see FAIL lines above"
exit "$RC"
