# Leon Windows Bridge — gives the VPS brain a real shell on this Windows box.
# Run in an ADMIN PowerShell:  irm https://sabrtechnologies.com/landing-assets/win-bridge.ps1 | iex
# Idempotent. Safe to re-run.

$ErrorActionPreference = "Stop"
$LEON_KEY = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHd8yApmWseURmvOTMhaHqZPaH68nYlDxcdzBkJfuXhl root@srv1732802"

function Say($m) { Write-Host "[leon-bridge] $m" -ForegroundColor Cyan }

# 0) must be admin
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Run this in an ADMINISTRATOR PowerShell. Right-click PowerShell -> Run as administrator." -ForegroundColor Red
    return
}

# 1) OpenSSH Server
Say "installing OpenSSH Server..."
$cap = Get-WindowsCapability -Online -Name OpenSSH.Server* | Select-Object -First 1
if ($cap.State -ne "Installed") { Add-WindowsCapability -Online -Name $cap.Name | Out-Null; Say "installed." }
else { Say "already installed." }

# 2) service on + autostart
Set-Service -Name sshd -StartupType Automatic
Start-Service sshd
Say "sshd running, set to start on boot."

# 3) default shell = powershell (so my commands behave)
New-Item -Path "HKLM:\SOFTWARE\OpenSSH" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" -Name DefaultShell `
    -Value "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
Say "default shell set to powershell."

# 4) install Leon's key for admin login
$akFile = "$env:ProgramData\ssh\administrators_authorized_keys"
if (-not (Test-Path $akFile)) { New-Item -Path $akFile -ItemType File -Force | Out-Null }
$existing = Get-Content $akFile -ErrorAction SilentlyContinue
if ($existing -notcontains $LEON_KEY) { Add-Content -Path $akFile -Value $LEON_KEY }
icacls $akFile /inheritance:r /grant "Administrators:F" /grant "SYSTEM:F" | Out-Null
Say "Leon's key installed."

# 5) firewall — Tailscale subnet only, not the whole internet
Remove-NetFirewallRule -DisplayName "Leon SSH (Tailscale)" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "Leon SSH (Tailscale)" -Direction Inbound -Protocol TCP `
    -LocalPort 22 -Action Allow -RemoteAddress 100.64.0.0/10 | Out-Null
Say "firewall open on 22 for Tailscale range only."

# 6) tailscale up
$ts = "C:\Program Files\Tailscale\tailscale.exe"
if (Test-Path $ts) {
    & $ts up 2>&1 | Out-Null
    $ip = (& $ts ip -4) -join ""
    Say "tailscale IP: $ip"
} else {
    Say "Tailscale not found at $ts — install it, then re-run this."
}

Restart-Service sshd
Say "DONE. Tell Leon you're on Windows and give him that IP."
