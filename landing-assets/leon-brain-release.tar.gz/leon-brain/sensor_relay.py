#!/usr/bin/env python3
"""
Sensor Relay — streams local mic + screen to remote Leon brain.

Runs on Dean's PC. Captures mic audio and screen, sends to VPS.
The dashboard handles webcam + TTS already (just point browser at VPS).

Usage:
    python3 sensor_relay.py --host 2.25.174.126 --port 8000
"""

import argparse
import base64
import io
import json
import os
import subprocess
import sys
import threading
import time
from urllib.request import Request, urlopen
from urllib.error import URLError

import numpy as np

# ── Config ──────────────────────────────────────────────────────────
SAMPLE_RATE = 16000
CHUNK_DURATION_S = 0.5
CHUNK_SAMPLES = int(SAMPLE_RATE * CHUNK_DURATION_S)
AUDIO_SEND_INTERVAL_S = 2.0       # send audio features every 2s
SCREEN_SEND_INTERVAL_S = 5.0      # send screen capture every 5s
CAPTION_INTERVAL_S = 10.0         # caption screen via Moondream every 10s
WEBCAM_CAPTION_INTERVAL_S = 8.0   # caption webcam via Moondream every 8s
N_BANDS = 32

_running = True
_host = os.environ.get("LEON_BRAIN_HOST", "127.0.0.1")  # override per install
_port = 8000
_scheme = "http"


def _base_url():
    """scheme://host[:port] — port omitted when it's the scheme default."""
    if (_scheme, _port) in (("https", 443), ("http", 80)):
        return f"{_scheme}://{_host}"
    return f"{_scheme}://{_host}:{_port}"


# Shared Moondream2 instance. Loaded once by the screen captioner thread,
# reused by the webcam captioner. ~1.8GB VRAM — loading twice OOMs the GPU.
_shared_vision = None
_shared_vision_ready = threading.Event()


def _api(path, data):
    """POST JSON to the VPS brain API. Includes Bearer auth from LEON_API_KEY."""
    url = _base_url() + path
    body = json.dumps(data).encode()
    headers = {"Content-Type": "application/json"}
    _tok = os.environ.get("LEON_API_KEY", "")
    if _tok:
        headers["Authorization"] = f"Bearer {_tok}"
    req = Request(url, data=body, headers=headers)
    try:
        with urlopen(req, timeout=5) as resp:
            return resp.status == 200
    except Exception as e:
        return False


def _api_get(path):
    """GET JSON from the VPS brain API. Returns dict on success, None on failure."""
    url = _base_url() + path
    headers = {}
    _tok = os.environ.get("LEON_API_KEY", "")
    if _tok:
        headers["Authorization"] = f"Bearer {_tok}"
    req = Request(url, headers=headers, method="GET")
    try:
        with urlopen(req, timeout=5) as resp:
            if resp.status != 200:
                return None
            return json.loads(resp.read().decode())
    except Exception:
        return None


# ── Identity perception (face + voice + learn-mode) ──────────────────
# All recognition lives in the leon_perception module — a clean façade over
# the sandboxed leon_identity / leon_voiceid / leon_learn engines. We import
# its three functions once here; if the module or any of its engines can't
# load for ANY reason, they fall back to no-ops so the always-on capture loops
# keep running with plain, unlabeled perception. This single guarded import
# replaces what used to be three separate in-line patch blocks.
try:
    import os as _p_os
    import sys as _p_sys
    _p_sys.path.insert(0, _p_os.path.expanduser("~/leon-identity"))
    from leon_perception import (
        identify_faces as _identify_faces,
        voice_speaker as _voice_speaker,
        learn_voice as _learn_voice,
    )
except Exception as _pe:  # pragma: no cover - defensive
    print("[RELAY] identity perception unavailable (%s) — perception stays generic" % _pe, flush=True)

    def _identify_faces(_img_bytes):
        return ""

    def _voice_speaker(_pcm16):
        return ""

    def _learn_voice(_audio_f32, _sr):
        return None


# ── Audio relay ─────────────────────────────────────────────────────

def _compute_spectrum(audio):
    """Log-mel-ish spectral energy bands."""
    windowed = audio * np.hanning(len(audio))
    fft = np.abs(np.fft.rfft(windowed))
    freqs = fft.size
    bands = np.zeros(N_BANDS, dtype=np.float32)
    edges = np.logspace(np.log10(1), np.log10(freqs), N_BANDS + 1).astype(int)
    for i in range(N_BANDS):
        lo, hi = edges[i], edges[i + 1]
        if hi <= lo:
            hi = lo + 1
        bands[i] = np.mean(fft[lo:hi]) if lo < freqs else 0.0
    bands = np.log1p(bands)
    mx = bands.max()
    if mx > 0:
        bands /= mx
    return bands


def _audio_loop():
    """Capture mic audio, compute features, send to VPS."""
    try:
        import sounddevice as sd
    except ImportError:
        print("[RELAY] sounddevice not installed — mic relay disabled")
        return

    audio_buffer = []
    buf_lock = threading.Lock()

    def callback(indata, frames, time_info, status):
        with buf_lock:
            audio_buffer.append(indata[:, 0].copy())
            while len(audio_buffer) > 20:
                audio_buffer.pop(0)

    try:
        stream = sd.InputStream(
            samplerate=SAMPLE_RATE, channels=1, dtype="float32",
            blocksize=CHUNK_SAMPLES, callback=callback,
        )
        stream.start()
        print("[RELAY] Mic open — streaming audio to VPS")
    except Exception as e:
        print(f"[RELAY] Mic unavailable: {e}")
        return

    while _running:
        time.sleep(AUDIO_SEND_INTERVAL_S)
        with buf_lock:
            if len(audio_buffer) < 2:
                continue
            n = min(len(audio_buffer), int(AUDIO_SEND_INTERVAL_S / CHUNK_DURATION_S))
            audio = np.concatenate(audio_buffer[-n:])

        rms = float(np.sqrt(np.mean(audio ** 2)))
        if rms < 0.005:
            continue  # silence — don't waste bandwidth
        _learn_voice(audio, SAMPLE_RATE)

        spectrum = _compute_spectrum(audio)
        features = np.zeros(256, dtype=np.float32)
        features[:N_BANDS] = spectrum
        features[N_BANDS] = min(1.0, rms * 10)

        # Fill rest with interpolated spectrum
        remaining = 256 - (N_BANDS + 1)
        features[N_BANDS + 1:] = np.interp(
            np.linspace(0, N_BANDS - 1, remaining),
            np.arange(N_BANDS), spectrum,
        )

        ok = _api("/api/relay/audio", {
            "features": features.tolist(),
            "rms": rms,
            "spectrum": spectrum.tolist(),
        })
        if ok:
            pass  # quiet success
        else:
            print("[RELAY] audio send failed", end="\r")

    stream.stop()
    stream.close()


# ── System-audio loopback (echo reference) ─────────────────────────
#
# Bug this fixes: a stranger's voice on a video call played through
# Dean's speakers, the mic picked it up, and it got filed under Dean's
# own name in the conversation store. Root cause: on_utterance's only
# guards (audio_is_speaker, transcript_is_self_echo_at) both compare
# against LEON'S OWN recorded speech — neither has any way to recognise
# a THIRD PARTY's voice coming out of the same speakers, because
# nothing in this process ever captured what the speakers were actually
# playing. brain/audio_daemon.py solves this on the VPS/Linux side via
# a PulseAudio `.monitor` source feeding audio_gate.note_reference_audio;
# there was no equivalent here. This is that equivalent, for Windows,
# via WASAPI loopback — content-blind envelope correlation against
# audio_gate.REFERENCE, so it rejects ANY system audio bleeding into
# the mic, not just Leon's own TTS.
def _find_wasapi_loopback_device():
    """Resolve the CURRENT default output device as a WASAPI loopback
    input. Called fresh on every (re)connect — never cached across a
    reconnect — so a changed default output device (headset unplugged,
    Bluetooth speaker dropped, Dean switches to the TV) is picked up
    instead of this silently going on capturing a dead device.
    Returns (device_index, channels, samplerate) or (None, None, None).
    """
    import sounddevice as sd
    try:
        hostapis = sd.query_hostapis()
        wasapi_idx = None
        for i, ha in enumerate(hostapis):
            if "wasapi" in ha["name"].lower():
                wasapi_idx = i
                break
        if wasapi_idx is None:
            return None, None, None
        out_idx = hostapis[wasapi_idx].get("default_output_device", -1)
        if out_idx is None or out_idx < 0:
            return None, None, None
        info = sd.query_devices(out_idx)
        channels = int(info.get("max_output_channels") or 2) or 2
        samplerate = float(info.get("default_samplerate") or 48000.0) or 48000.0
        return out_idx, channels, samplerate
    except Exception:
        return None, None, None


def _system_audio_loop():
    """Capture what's actually leaving the PC's speakers (WASAPI
    loopback) and publish it into audio_gate.REFERENCE, so
    looks_like_echo() has something real to correlate against in THIS
    process. Without this thread, audio_gate.REFERENCE.available is
    always False on Dean's PC and looks_like_echo() is a permanent
    no-op — see on_utterance.

    Windows-only (WASAPI has no cross-platform equivalent here). A dead
    or stale loopback stream is exactly the failure mode that produced
    the bug this exists to catch, so this polls for device changes and
    stream death and LOGS every reconnect instead of failing silently.
    """
    if not sys.platform.startswith("win"):
        print("[RELAY] system-audio loopback skipped — WASAPI is "
              "Windows-only on this path; looks_like_echo() has no "
              "reference and will never reject on this platform.",
              flush=True)
        return
    try:
        import sounddevice as sd
    except ImportError:
        print("[RELAY] sounddevice not installed — system-audio "
              "loopback disabled, looks_like_echo() will never reject",
              flush=True)
        return

    from brain.voice import audio_gate

    backoff = 1.0
    while _running:
        device, channels, samplerate = _find_wasapi_loopback_device()
        if device is None:
            print("[RELAY] system-audio loopback: no WASAPI output "
                  "device found — retrying "
                  f"in {backoff:.0f}s (looks_like_echo() cannot reject "
                  "until this succeeds)", flush=True)
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
            continue

        def _callback(indata, frames, time_info, status, _sr=samplerate):
            if status:
                print(f"[RELAY] system-audio loopback status: {status}",
                      flush=True)
            try:
                mono = (indata.mean(axis=1) if indata.ndim > 1
                        and indata.shape[1] > 1 else indata[:, 0])
                audio_gate.note_reference_audio(mono.copy(), _sr)
            except Exception:
                pass

        stream = None
        try:
            stream = sd.InputStream(
                device=device, channels=channels, samplerate=samplerate,
                dtype="float32",
                blocksize=int(samplerate * CHUNK_DURATION_S),
                callback=_callback,
                extra_settings=sd.WasapiSettings(loopback=True),
            )
            stream.start()
            print(f"[RELAY] system-audio loopback opened (device={device}, "
                  f"{channels}ch @ {samplerate:.0f}Hz) — "
                  f"looks_like_echo() now has a reference", flush=True)
            backoff = 1.0
            # Poll rather than block: a stream that has silently died is
            # exactly the failure mode this thread exists to catch, so
            # "dead but nobody noticed" must not be reachable.
            while _running and stream.active:
                time.sleep(2.0)
                new_device, _, _ = _find_wasapi_loopback_device()
                if new_device is not None and new_device != device:
                    print(f"[RELAY] system-audio loopback: default "
                          f"output device changed ({device} -> "
                          f"{new_device}) — reopening loopback stream",
                          flush=True)
                    break
            if _running and not stream.active:
                print("[RELAY] system-audio loopback: stream went "
                      "inactive unexpectedly — reopening", flush=True)
        except Exception as e:
            print(f"[RELAY] system-audio loopback failed: {e} — "
                  f"retrying in {backoff:.0f}s", flush=True)
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
        finally:
            if stream is not None:
                try:
                    stream.stop()
                    stream.close()
                except Exception:
                    pass


# ── Screen relay ────────────────────────────────────────────────────

def _get_active_monitor():
    """Which monitor has the focused window (1-indexed)."""
    try:
        import subprocess
        result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowgeometry"],
            capture_output=True, text=True, timeout=2,
        )
        boundaries = [(0, 1920), (1920, 3840), (3840, 5760)]
        for line in result.stdout.splitlines():
            if "Position:" in line:
                x = int(line.split("Position:")[1].split("(")[0].strip().split(",")[0])
                for i, (lo, hi) in enumerate(boundaries):
                    if lo <= x < hi:
                        return i + 1
                return 1
    except Exception:
        pass
    return None


def _screen_loop():
    """Capture active monitor screen, send to VPS as JPEG."""
    try:
        import mss
        from PIL import Image
    except ImportError:
        print("[RELAY] mss/Pillow not installed — screen relay disabled")
        return

    print("[RELAY] Screen capture active — streaming to VPS")
    prev_hash = None

    while _running:
        time.sleep(SCREEN_SEND_INTERVAL_S)
        try:
            active_mon = _get_active_monitor()
            with mss.mss() as sct:
                if active_mon and active_mon < len(sct.monitors):
                    monitor = sct.monitors[active_mon]
                else:
                    monitor = sct.monitors[1]
                shot = sct.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")

            # Resize to save bandwidth
            w, h = img.size
            if w > 800:
                img = img.resize((800, int(h * 800 / w)))

            # Skip if nothing changed
            img_hash = hash(img.tobytes()[:2000])
            if img_hash == prev_hash:
                continue
            prev_hash = img_hash

            # Encode as JPEG
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=60)
            b64 = base64.b64encode(buf.getvalue()).decode()

            ok = _api("/api/relay/screen", {
                "image_b64": b64,
                "monitor": active_mon or 1,
                "width": img.size[0],
                "height": img.size[1],
            })
        except Exception as e:
            print(f"[RELAY] screen error: {e}")


# ── Screen captioner (Moondream2 on local GPU) ─────────────────────

def _caption_loop():
    """Caption the screen locally with Moondream2, send text to VPS.

    This gives Leon's proactive watch on the VPS real captions instead of
    empty strings. Moondream2 runs on the PC's GPU (sub-second, free).
    Captions are sent to /api/relay/perception every CAPTION_INTERVAL_S.
    """
    # Add brain/ to path so we can import local_vision
    _brain_dir = os.path.dirname(os.path.abspath(__file__))
    if _brain_dir not in sys.path:
        sys.path.insert(0, _brain_dir)

    global _shared_vision
    try:
        from brain.local_vision import LocalVision
    except ImportError as e:
        print(f"[RELAY] LocalVision import failed: {e} — captioner disabled",
              flush=True)
        return

    vision = LocalVision()
    print("[RELAY] Loading Moondream2 for screen captioning...", flush=True)
    if not vision.prewarm():
        print(f"[RELAY] Moondream2 load failed: {vision.last_error} — captioner disabled",
              flush=True)
        return
    _shared_vision = vision
    _shared_vision_ready.set()
    print("[RELAY] Moondream2 ready — captioning screen", flush=True)

    prev_caption = ""
    last_post_ts = 0.0
    # Even when the caption hasn't changed, re-POST every KEEPALIVE_S so
    # the VPS-side freshness window stays satisfied (proactive accepts
    # captions up to 90s old).
    KEEPALIVE_S = 30.0
    while _running:
        time.sleep(CAPTION_INTERVAL_S)
        try:
            import mss
            from PIL import Image

            active_mon = _get_active_monitor()
            with mss.mss() as sct:
                if active_mon and active_mon < len(sct.monitors):
                    monitor = sct.monitors[active_mon]
                else:
                    monitor = sct.monitors[1]
                shot = sct.grab(monitor)
                img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")

            # Resize for Moondream (1280 max width)
            w, h = img.size
            if w > 1280:
                img = img.resize((1280, int(h * 1280 / w)))

            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=85)
            img_bytes = buf.getvalue()

            result = vision.query(
                img_bytes,
                "What application or type of content is visible on this screen? "
                "One sentence. Do not read, quote, or transcribe any text you see."
            )
            if not result.get("ok"):
                continue

            caption = (result.get("answer") or "").strip()
            if not caption:
                continue

            now = time.time()
            changed = caption != prev_caption
            keepalive_due = (now - last_post_ts) >= KEEPALIVE_S
            if not changed and not keepalive_due:
                continue

            ok = _api("/api/relay/perception", {
                "source": "screen",
                "caption": caption,
                "monitor": active_mon or 1,
                "ts": now,
            })
            if ok:
                last_post_ts = now
                if changed:
                    prev_caption = caption
                    print(f"[RELAY] caption: {caption[:80]}", flush=True)
        except Exception as e:
            print(f"[RELAY] caption error: {e}", flush=True)


# ── Webcam captioner (Moondream2 on local GPU) ─────────────────────

def _caption_webcam_loop():
    """Caption Dean's webcam locally with Moondream2, send text to VPS.

    The browser holds /dev/video0 exclusively, so we can't open the
    camera directly. Instead we GET the cached frame from VPS
    (/api/webcam/last-frame), caption it with Moondream2 here on the
    PC GPU, and POST the caption back to /api/relay/perception with
    source=webcam. This is what makes "hey Dean, you're back" possible
    — the proactive watch needs a webcam caption to fire its welcome /
    new-person / visible-emotion triggers.
    """
    # Share the screen captioner's Moondream2 instance — loading twice
    # OOMs the 8GB GPU (~5GB per load).
    if not _shared_vision_ready.wait(timeout=120):
        print("[RELAY] Moondream2 never came up — webcam captioner disabled",
              flush=True)
        return
    vision = _shared_vision
    if vision is None:
        print("[RELAY] Shared vision is None — webcam captioner disabled",
              flush=True)
        return
    print("[RELAY] Moondream2 ready — captioning webcam", flush=True)

    prev_caption = ""
    consecutive_misses = 0
    last_post_ts = 0.0
    KEEPALIVE_S = 30.0
    while _running:
        time.sleep(WEBCAM_CAPTION_INTERVAL_S)
        try:
            frame = _api_get("/api/webcam/last-frame")
            if not frame or not frame.get("ok"):
                consecutive_misses += 1
                if consecutive_misses == 5:
                    # Dashboard probably closed — log once, keep trying quietly
                    err = (frame or {}).get("error", "unknown")
                    print(f"[RELAY] webcam cache empty ({err}) — dashboard closed?",
                          flush=True)
                continue
            consecutive_misses = 0

            b64 = frame.get("image_b64", "")
            if not b64:
                continue
            img_bytes = base64.b64decode(b64)

            result = vision.query(
                img_bytes,
                "Describe the person in this image. Are they present, looking "
                "at the camera, or away? Any visible emotion or fatigue? "
                "One sentence. If no person, say 'no one visible'."
            )
            if result.get("ok"):
                _c = (result.get("answer") or "").strip()
                if _c:
                    _who = _identify_faces(img_bytes)
                    if _who:
                        result["answer"] = f"[{_who}] {_c}"
            if not result.get("ok"):
                continue

            caption = (result.get("answer") or "").strip()
            if not caption:
                continue

            now = time.time()
            changed = caption != prev_caption
            keepalive_due = (now - last_post_ts) >= KEEPALIVE_S
            if not changed and not keepalive_due:
                continue

            ok = _api("/api/relay/perception", {
                "source": "webcam",
                "caption": caption,
                "ts": now,
            })
            if ok:
                last_post_ts = now
                if changed:
                    prev_caption = caption
                    print(f"[RELAY] webcam: {caption[:80]}", flush=True)
        except Exception as e:
            print(f"[RELAY] webcam caption error: {e}", flush=True)


# ── Wake word + STT (Vosk wake → faster-whisper) ──────────────────

def _wake_loop():
    """Always-on PC-side wake word + ambient STT.

    When the user says 'hey leon' followed by an utterance, the Vosk
    listener fires on_wake then on_utterance (PCM16). We STT the
    utterance locally with faster-whisper (PC GPU) and POST the text
    to /api/relay/heard on VPS, which routes it through Leon's
    responder as if Dean had typed it. Closes the hands-free loop.

    Coordination with TTS: if a marker file /tmp/leon-tts-active
    exists (touched by the actuator/dashboard during TTS playback),
    we pause the listener so Leon doesn't transcribe his own voice.
    Lightweight, optional — absence of the file just means "no TTS
    playing now."
    """
    _brain_dir = os.path.dirname(os.path.abspath(__file__))
    if _brain_dir not in sys.path:
        sys.path.insert(0, _brain_dir)

    # Stagger startup so we don't compete with Moondream2 GPU load.
    time.sleep(25)

    try:
        from brain.voice.wake_word_vosk import VoskWakeWordListener
        from brain.voice.stt import STT
        from brain.voice import audio_gate
    except ImportError as e:
        print(f"[RELAY] wake/stt import failed: {e} — wake disabled",
              flush=True)
        return

    # Resolve Vosk model — repo-local path
    vosk_model_dir = os.path.join(
        _brain_dir, "brain_state", "voice", "vosk",
        "vosk-model-small-en-us-0.15",
    )
    if not os.path.isdir(vosk_model_dir):
        print(f"[RELAY] vosk model not found at {vosk_model_dir} — "
              f"wake disabled. Download from https://alphacephei.com/"
              f"vosk/models", flush=True)
        return
    os.environ.setdefault("LEON_VOSK_MODEL", vosk_model_dir)
    # "hey leon" ONLY. Reverted from "hey leon|leon" (2026-06-19): bare "leon"
    # made Leon's OWN TTS (he says his name / "Leon" constantly) trigger the wake
    # → he heard himself and replied in a feedback loop.
    # As of 2026-08-02 the mute gate is capture-timestamp based (see
    # brain/voice/audio_gate.py): the marker file feeds a ledger of
    # speaker-active intervals and every mic chunk is judged by WHEN IT WAS
    # RECORDED, plus a content-level echo check against Leon's own last
    # sentence. Re-enabling bare "leon" is now much safer but is still a
    # deliberate decision — leaving it at "hey leon" until Dean asks.
    os.environ.setdefault("LEON_WAKE_PHRASES", "hey leon")

    try:
        stt = STT(prefer="faster-whisper", model_size="base")
        print(f"[RELAY] STT ready (backend={stt.backend_name})", flush=True)
    except Exception as e:
        print(f"[RELAY] STT init failed: {e} — wake disabled", flush=True)
        return

    # ── Speaker state: published into the ONE ledger, not held here ───
    # The old code kept its own answer to "is TTS playing" (_tts_playing()
    # polled at callback time) AND a gate thread that flipped the
    # listener's _paused flag. Both evaluated the question at the wrong
    # instant — the audio in question had been recorded seconds earlier.
    # Now: this process's only job is to TRANSLATE the PC-local TTS marker
    # file into intervals in brain.voice.audio_gate.LEDGER (back-dated to
    # the marker's mtime, so the poll period stops being a latency hole).
    # The listener itself gates every chunk by its capture timestamp.
    _TTS_MARKER = audio_gate.DEFAULT_MARKER

    threading.Thread(
        target=audio_gate.marker_publisher,
        kwargs={"marker_path": _TTS_MARKER, "running": lambda: _running},
        daemon=True, name="tts-marker-publisher",
    ).start()


    # Push-to-talk floor: the second reason wake was disabled on 2026-06-23.
    # Dean holds Space on the dashboard, Vosk hears the SAME words, and one
    # utterance becomes two competing inputs — so Leon answers over him.
    # The dashboard now claims the floor for the held window; we poll that
    # claim in the background and stand down while it's held. Polling in a
    # thread (not inline) is deliberate: the wake path must never block on
    # the network to decide whether to listen.
    #
    # 2026-08-02 — the boolean check at callback time was NOT enough, and this
    # is the bug Dean hit: he'd be mid-sentence on push-to-talk and a fragment
    # of his OWN words would arrive as a separate message ("you heard me").
    # Why: Vosk endpoints an utterance AFTER the talking stops. The audio is
    # captured during the hold, but on_utterance only fires once Dean goes
    # quiet — by which time he's released the key and _ptt["active"] reads
    # False. The gate was checking the wrong instant. A 0.5s poll could also
    # miss a short hold entirely, between samples.
    # Two changes: (1) we now know how long ago the floor was last held, so an
    # utterance whose AUDIO WINDOW overlaps a recent hold is dropped no matter
    # when it endpoints; (2) we actually pause the listener during the hold —
    # same shape as the TTS gate below — so the audio is never buffered in the
    # first place. Belt and suspenders, because filtering alone already failed.
    _PTT_BLANKING_S = 3.0
    # How long a failed poll may coast on the last known PTT state before
    # failing open. Covers a blip or two without turning an outage into
    # permanent deafness.
    _PTT_POLL_GRACE_S = 6.0
    _ptt = {"active": False, "since": 1e9, "stamp": time.time()}

    def _ptt_poll():
        while _running:
            try:
                _h = {}
                _tok = os.environ.get("LEON_API_KEY", "")
                if _tok:
                    _h["Authorization"] = f"Bearer {_tok}"
                _rq = Request(_base_url() + "/api/relay/ptt",
                              headers=_h)
                with urlopen(_rq, timeout=2) as r:
                    _d = json.loads(r.read())
                _was_active = _ptt["active"]
                _ptt["active"] = bool(_d.get("active"))
                _ptt["since"] = float(_d.get("since_active", 1e9))
                _ptt["stamp"] = time.time()
                # Rising edge = Dean just barged in and the dashboard cut
                # Leon's playback. This process has its OWN ledger (fed by
                # the PC-local TTS marker file), so it has to learn about
                # the stop the same way: end the open interval at
                # stop + SINK_DRAIN_S. Push-to-talk gets no exemption from
                # the capture-timestamp gate — it just ends the interval,
                # and the drain window stays gated, which is the point.
                if _ptt["active"] and not _was_active:
                    audio_gate.note_barge_in()
                # Same poll carries the sentences Leon just spoke, feeding
                # the clock-free echo check in the wake listener.
                for _s in (_d.get("spoken") or [])[-6:]:
                    audio_gate.note_recent_speech_once(_s)
            except Exception:
                # Unreachable VPS must FAIL OPEN — a network blip should
                # degrade to "wake still works", never to "Leon went deaf".
                # BUT (2026-08-07, Dean mid-dictation bug): clearing active
                # on the FIRST failed poll opened a hole — one 2s timeout
                # during a space-bar hold made the floor look free, so the
                # wake listener fired on "hey leon" INSIDE the sentence Dean
                # was dictating. Keep the last known hold for a short grace
                # (_PTT_POLL_GRACE_S) before failing open; a real outage
                # still degrades to "wake works" after a few seconds.
                if (time.time() - _ptt["stamp"]) > _PTT_POLL_GRACE_S:
                    _ptt["active"] = False
            time.sleep(0.5)

    threading.Thread(target=_ptt_poll, name="ptt-poll", daemon=True).start()

    def _ptt_age() -> float:
        """Seconds since the mic floor was last held. Aged forward locally so
        a 0.5s-stale poll doesn't make a fresh release look old."""
        return _ptt["since"] + (time.time() - _ptt["stamp"])

    def _ptt_owns(audio_window_s: float = 0.0) -> bool:
        """True if push-to-talk owns (or just owned) the words in question.

        audio_window_s is how far back this audio reaches. An utterance that
        ENDS now but STARTED during Dean's hold is his push-to-talk speech —
        it must not come back around as a second, separate input.
        """
        if _ptt["active"]:
            return True
        return _ptt_age() < (audio_window_s + _PTT_BLANKING_S)

    def on_wake(event):
        # Self-hearing gate. The listener has ALREADY dropped every chunk
        # recorded while the speakers were live (capture-timestamp gate in
        # wake_word_vosk), so this is a backstop against the interval
        # arriving late: the wake's own event.ts is checked against the
        # ledger, not "is TTS playing at this instant".
        _wake_ts = float(getattr(event, "ts", 0.0) or time.time())
        if audio_gate.audio_is_speaker(_wake_ts):
            print(f"[RELAY] wake suppressed — recorded while Leon was speaking",
                  flush=True)
            return
        # Text is a TIEBREAKER, never a reason on its own: wake_is_self_echo
        # only fires when _wake_ts also lands in/next to a speaker interval.
        # Dean says "hey Leon" seconds after Leon said his own name all day.
        if audio_gate.wake_is_self_echo(event.wake_word, _wake_ts):
            print(f"[RELAY] wake suppressed — '{event.wake_word}' is in what "
                  f"Leon just said AND was captured over his voice", flush=True)
            return
        if _ptt_owns():
            print(f"[RELAY] wake suppressed — push-to-talk holds the floor "
                  f"(age={_ptt_age():.1f}s)", flush=True)
            return
        print(f"[RELAY] wake fired: '{event.wake_word}' "
              f"score={event.score:.2f}", flush=True)
        # Light the dashboard's pulsing 'listening' tag the instant the wake
        # fires, so Dean sees Leon is hearing him (he asked for this 2026-06-19).
        try:
            _api("/api/relay/wake", {"phase": "triggered",
                                     "wake_word": event.wake_word,
                                     "score": float(event.score)})
        except Exception:
            pass

    def on_utterance(utt):
        # Judged on the audio's CAPTURE window, not on "now". An utterance
        # endpoints only after the talking stops, so by the time we get
        # here the speakers may well be quiet again — that lag is exactly
        # what used to let Leon's own voice through.
        _u_end = float(getattr(utt, "ended_ts", 0.0) or time.time())
        _u_start = float(getattr(utt, "started_ts", 0.0)
                         or (_u_end - float(getattr(utt, "duration_s", 0.0) or 0.0)))
        if audio_gate.audio_is_speaker(_u_start, max(0.0, _u_end - _u_start)):
            print(f"[RELAY] utterance dropped — recorded while Leon was "
                  f"speaking", flush=True)
            return
        # Overlap check, not instant check. This utterance's audio reaches
        # back utt.duration_s (plus Vosk's pre-roll). If ANY of that window
        # touched a push-to-talk hold, these are words Dean already sent me
        # through the browser — echoing them back as a new message is the
        # "you heard me" bug.
        _win = float(getattr(utt, "duration_s", 0.0) or 0.0) + 1.5
        if _ptt_owns(_win):
            print(f"[RELAY] utterance dropped — push-to-talk owns this audio "
                  f"(dur={_win:.1f}s, ptt age={_ptt_age():.1f}s)", flush=True)
            return
        if utt.duration_s < 0.4:
            print(f"[RELAY] utterance too short ({utt.duration_s:.1f}s)",
                  flush=True)
            return
        try:
            result = stt.transcribe(utt.pcm16, sample_rate=16000)
            text = (getattr(result, "text", "") or "").strip()
            if not text:
                print(f"[RELAY] empty transcription", flush=True)
                return
            # Strip the wake phrase itself if it leaked into the STT output
            # (sometimes the pre-roll includes "hey leon" at the start).
            low = text.lower().lstrip()
            for phrase in ("hey leon,", "hey leon", "leon,", "leon"):
                if low.startswith(phrase):
                    text = text[len(phrase):].lstrip(" ,.")
                    break
            if not text:
                print(f"[RELAY] only wake word, no utterance",
                      flush=True)
                return
            # Echo rejection, text-vs-text — no loopback reference exists in
            # this process (the mic is here, the speakers are driven by the
            # dashboard).
            #
            # RULE — DO NOT UNDO: the text match is only a TIEBREAKER. It may
            # reject ONLY when this audio's own capture window also falls
            # inside a speaker interval, or within the guard margins (plus
            # TEXT_TIEBREAK_SLACK_S) of one. TEXT ALONE IS NEVER SUFFICIENT.
            # Dean quotes Leon back constantly ("so you restarted the daemon?")
            # — rejecting on words alone eats his real speech, and a dropped
            # utterance is a turn he has to say twice. transcript_is_self_echo_at
            # enforces this; the bare transcript_is_self_echo is a score, not a
            # verdict, and must not be used to reject here.
            _echoed, _ov = audio_gate.transcript_is_self_echo_at(
                text, _u_start, max(0.0, _u_end - _u_start))
            if _echoed:
                print(f"[RELAY] utterance dropped — echo of Leon's own words "
                      f"captured over his voice (overlap={_ov:.2f}): "
                      f"{text[:60]!r}", flush=True)
                return
            # ADDITIONAL, independent reject: content-blind envelope
            # correlation against whatever actually left the speakers
            # (_system_audio_loop's WASAPI loopback feed). The two checks
            # above can only ever catch LEON'S OWN voice coming back —
            # both compare against text/intervals Leon himself produced.
            # A third party's voice on a call (Zoom, a video, anyone else
            # in the room's speakers) has no reason to match either one,
            # so it sails through both and used to get filed as a Dean
            # turn. This one doesn't care whose voice it is.
            _is_echo, _corr = audio_gate.looks_like_echo(
                utt.pcm16, _u_start, 16000)
            if _is_echo:
                print(f"[RELAY] utterance dropped — correlates with "
                      f"system audio output (corr={_corr:.2f}), not a "
                      f"live voice in the room: {text[:60]!r}", flush=True)
                return
            # ── Diagnostic for the OTHER failure mode ────────────────
            # Dean overheard on the phone / talking to someone in the
            # room, arriving as if he'd addressed Leon. That is NOT
            # self-hearing — nothing here can be blamed on the speakers.
            # It means Vosk's small model hallucinated "hey leon" out of
            # ordinary conversation. Before rejecting on that suspicion
            # (which would eat real turns whenever the pre-roll clips the
            # wake phrase), MEASURE it: faster-whisper is far more
            # accurate than Vosk, and it transcribed the pre-roll too. If
            # whisper doesn't see a Leon anywhere near the front, the
            # wake was probably a phantom. Logged, not enforced.
            _head = low[:40]
            _confirmed = any(k in _head for k in ("leon", "lion", "leo n"))
            if not _confirmed:
                print(f"[RELAY] UNCONFIRMED WAKE — vosk fired on "
                      f"'{utt.wake_word}' but whisper heard no name at the "
                      f"front: {text[:80]!r}", flush=True)
                # ENFORCED (Dean, 2026-08-07). This used to be logged and
                # forwarded anyway, which is exactly the "you randomly hear
                # me on the phone" bug: Vosk's small model hallucinates
                # "hey leon" out of ordinary conversation, and the phone
                # call landed in the conversation box as a Dean turn.
                # Whisper transcribed the pre-roll too — if the far more
                # accurate model heard no name anywhere near the front,
                # this was never addressed to Leon. Drop it. Dean's rule:
                # only push-to-talk, typed text, or a REAL "hey leon"
                # reach the conversation.
                # Escape hatch for debugging: LEON_WAKE_REQUIRE_CONFIRM=0.
                if os.environ.get("LEON_WAKE_REQUIRE_CONFIRM", "1").strip() != "0":
                    try:
                        _api("/api/relay/wake", {"phase": "transcribed",
                                                 "transcript": text,
                                                 "rejected": True})
                    except Exception:
                        pass
                    print(f"[RELAY] utterance dropped — phantom wake "
                          f"(whisper unconfirmed): {text[:80]!r}", flush=True)
                    return
            speaker = _voice_speaker(utt.pcm16)
            _slab = f" [{speaker}]" if speaker else ""
            print(f"[RELAY] heard{_slab} ({utt.duration_s:.1f}s, "
                  f"wake_confirmed={_confirmed}): {text!r}", flush=True)
            # Update the dashboard tag: transcription done, show what he said.
            try:
                _api("/api/relay/wake", {"phase": "transcribed", "transcript": text})
            except Exception:
                pass
            ok = _api("/api/relay/heard", {
                "text": text,
                "speaker": speaker or "unknown",
                "duration_s": utt.duration_s,
                "wake_word": utt.wake_word,
                "wake_score": utt.wake_score,
                "confidence": getattr(result, "confidence", 0.0),
                "ts": time.time(),
                # Capture instant of the audio behind this transcript. The
                # VPS ingress gate (brain/voice/ingress_gate.py) uses it to
                # apply the capture-timestamp rule instead of the weaker
                # arrival-window heuristic. Harmless to older servers.
                "captured_ts": _u_start,
            })
            if not ok:
                print(f"[RELAY] heard POST failed", flush=True)
        except Exception as e:
            print(f"[RELAY] STT/POST error: {e}", flush=True)

    listener = VoskWakeWordListener(
        on_wake=on_wake,
        on_utterance=on_utterance,
    )
    if not listener.start():
        err = listener.stats.get("error", "unknown")
        print(f"[RELAY] wake start failed: {err}", flush=True)
        return

    # ── Push-to-talk gate thread ──────────────────────────────────────
    # What used to live here was the TTS-gate thread: it polled "is TTS
    # playing" and flipped listener._paused, which meant a chunk recorded
    # during playback but consumed after the gate lifted still fired the
    # wake. That whole responsibility now belongs to the speaker ledger
    # (published from the TTS marker, applied per chunk by capture
    # timestamp inside the listener) — no blanking window, no race.
    #
    # This thread keeps ONLY the push-to-talk duty, which is a different
    # thing entirely: while Dean physically holds the floor, Vosk must not
    # buffer the same words the browser is already sending (de-duplication,
    # not self-hearing).
    #
    # Barge-in itself is NOT an exemption from the gate. Holding the button
    # interrupts Leon instantly and ENDS the speaker interval at
    # stop + SINK_DRAIN_S (see the rising edge in _ptt_poll). The audio still
    # draining out of the speakers after the stop therefore stays gated by
    # the same capture-timestamp rule as everything else — a bypass would
    # hand that drain window to STT as if Dean had spoken it.
    _ptt_paused = False

    def _ptt_gate_loop():
        nonlocal _ptt_paused
        while _running:
            held = _ptt["active"]
            if held and not _ptt_paused:
                listener.pause()
                _ptt_paused = True
                print("[RELAY] wake PAUSED (push-to-talk holds the floor)",
                      flush=True)
            elif not held and _ptt_paused:
                try:
                    if getattr(listener, "_recognizer", None):
                        listener._recognizer.Reset()
                except Exception:
                    pass
                listener.resume()
                _ptt_paused = False
                print("[RELAY] wake RESUMED (push-to-talk released)", flush=True)
            time.sleep(0.1)

    threading.Thread(target=_ptt_gate_loop, daemon=True,
                     name="ptt-gate").start()

    while _running:
        time.sleep(5)
    listener.stop()


# ── Local tmux helper (scroll, copy-mode, send-keys) ───────────────
# VPS calls this instead of SSH-ing back for tmux commands.
# Eliminates ~200ms SSH round-trip per scroll event.
#
# Hardening (2026-06-08 security audit C3):
#   - Bind to Tailscale IP only (not 0.0.0.0). Hostinger / LAN can't reach.
#   - Require shared-secret header X-Auth-Token matching LEON_API_KEY.
#   - Allowlist tmux subcommands. The VPS scroll path only calls
#     copy-mode / send-keys -X / display-message — refuse anything else.

import hmac as _hmac

_HELPER_PORT = 8002
# Tailscale IP of THIS host (PC). VPS reaches us via this.
_HELPER_BIND_HOST = os.environ.get("LEON_RELAY_BIND", "127.0.0.1")
_HELPER_TOKEN = os.environ.get("LEON_API_KEY", "").strip()

# Tmux subcommands the VPS legitimately needs (see workspaces.py ws_term
# scroll/resize paths). Anything else → 403.
_TMUX_ALLOWED_SUBCOMMANDS = {
    "copy-mode", "send-keys", "display-message",
    "resize-window", "refresh-client",
}
# For send-keys we further constrain -X flag (mode-only commands), no -l
# arbitrary literal text injection.
_SEND_KEYS_ALLOWED_X = {
    "scroll-up", "scroll-down", "cancel",
    "page-up", "page-down", "halfpage-up", "halfpage-down",
}


def _tmux_args_ok(args):
    """Validate a list of tmux args matches the allowlist for the helper."""
    if not args:
        return False, "empty args"
    sub = args[0]
    if sub not in _TMUX_ALLOWED_SUBCOMMANDS:
        return False, f"subcommand not allowed: {sub}"
    if sub == "send-keys":
        # send-keys must have -X (mode command) and the X-command must
        # be in the small mode-only allowlist. Refuse -l (literal text
        # injection), -R (reset), and any other free-form variant.
        if "-l" in args or "-R" in args:
            return False, "send-keys -l/-R refused"
        if "-X" not in args:
            return False, "send-keys requires -X (mode command)"
        # Find the X command (arg right after -X, or after -X -N <n>)
        try:
            xi = args.index("-X")
            xcmd_idx = xi + 1
            if xcmd_idx < len(args) and args[xcmd_idx] == "-N":
                xcmd_idx = xi + 3  # skip -N and its number
            xcmd = args[xcmd_idx] if xcmd_idx < len(args) else ""
            if xcmd not in _SEND_KEYS_ALLOWED_X:
                return False, f"send-keys -X command not allowed: {xcmd}"
        except (ValueError, IndexError):
            return False, "send-keys -X arg parse failed"
    return True, ""


def _tmux_helper():
    """HTTP server that runs tmux commands locally for the VPS — gated."""
    from http.server import HTTPServer, BaseHTTPRequestHandler

    if not _HELPER_TOKEN:
        print("[RELAY] WARNING: LEON_API_KEY not set; tmux helper disabled "
              "(would have run on this host without auth).")
        return

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.path != "/tmux":
                self.send_response(404); self.end_headers(); return
            # Auth
            tok = self.headers.get("X-Auth-Token", "")
            if not tok or not _hmac.compare_digest(tok, _HELPER_TOKEN):
                self.send_response(401); self.end_headers()
                self.wfile.write(b'{"ok":false,"error":"unauthorized"}')
                return
            # Body
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(length))
                args = body.get("args", [])
            except Exception:
                self.send_response(400); self.end_headers()
                self.wfile.write(b'{"ok":false,"error":"bad_request"}')
                return
            # Allowlist
            ok, reason = _tmux_args_ok(args)
            if not ok:
                self.send_response(403); self.end_headers()
                self.wfile.write(json.dumps({"ok": False, "error": reason}).encode())
                return
            # Run
            try:
                result = subprocess.check_output(
                    ["tmux"] + args,
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                    text=True,
                )
                self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps({"ok": True, "out": result}).encode())
            except subprocess.CalledProcessError as e:
                self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps({"ok": False, "error": "tmux_failed",
                                             "rc": e.returncode}).encode())
            except Exception as e:
                self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps({"ok": False, "error": str(e)[:200]}).encode())

        def log_message(self, format, *args):
            pass  # silence

    try:
        server = HTTPServer((_HELPER_BIND_HOST, _HELPER_PORT), Handler)
    except OSError as e:
        print(f"[RELAY] Tmux helper bind {_HELPER_BIND_HOST}:{_HELPER_PORT} failed: {e}")
        return
    print(f"[RELAY] Tmux helper on {_HELPER_BIND_HOST}:{_HELPER_PORT} (auth + allowlist)")
    server.serve_forever()


# ── Main ────────────────────────────────────────────────────────────

# ── Wheel-click push-to-talk (evdev) ────────────────────────────────
# Dean remapped his mouse wheel-click to Spacebar at the OS level. That
# remapper GRABS the physical button and injects a synthetic key, so:
#   - the browser never sees button 1 (the dashboard's mousedown handler is
#     dead code by construction), and
#   - the injected Space goes to whatever window holds KEYBOARD focus, which
#     is not necessarily the dashboard, because the consumed click never
#     focused it.
# No amount of dashboard JavaScript can fix that — the event never arrives.
# So we read the input device directly, here on his PC, and push a toggle
# down the websocket the dashboard already holds. A socket event does not
# require focus; a keystroke does. That asymmetry is the whole fix.
#
# Set LEON_PTT_DEVICE=/dev/input/eventN to override autodetection.
# Set LEON_WHEEL_PTT=0 to disable this watcher entirely.

_WHEEL_DEBOUNCE_S = 0.30


def _ptt_candidate_devices():
    """Input devices that could carry the remapped wheel-click.

    We do NOT hardcode an event number — those renumber across reboots and
    reconnects. We identify by capability, which is stable:

      * The remapper grabs the mouse and emits on its own virtual device, so
        the press may arrive as KEY_SPACE from a device that is not the mouse
        and is not the keyboard. Name-matching would miss it; capability
        matching does not.
      * A REAL keyboard also emits KEY_SPACE, and binding to it would make
        every physical spacebar press toggle the mic — the double-fire Leon
        explicitly warned about. We exclude it by counting keys: a full
        keyboard reports the whole alphabet; a remapped mouse reports a
        handful. `_looks_like_keyboard` is that test.
    """
    try:
        from evdev import InputDevice, ecodes, list_devices
    except Exception:
        return [], "python-evdev not installed"

    override = os.environ.get("LEON_PTT_DEVICE", "").strip()
    if override:
        try:
            return [InputDevice(override)], ""
        except Exception as e:
            return [], f"LEON_PTT_DEVICE={override} unusable: {e}"

    # Linux keycodes are laid out by SCANCODE, not alphabetically: KEY_A is 30,
    # KEY_Z is 44, and 30..44 is a mixed bag of letters and punctuation. A
    # `KEY_A <= k <= KEY_Z` range check therefore does NOT mean "is a letter",
    # and it let a real keyboard through in testing — which would have made
    # every physical spacebar press toggle the mic. Enumerate them instead.
    import string as _string
    _LETTER_CODES = {getattr(ecodes, f"KEY_{c}") for c in _string.ascii_uppercase
                     if hasattr(ecodes, f"KEY_{c}")}

    def _looks_like_keyboard(caps_keys):
        # The alphabet is the tell. A remapped mouse emits one or two keys.
        return len(_LETTER_CODES & set(caps_keys)) >= 20

    picked, denied = [], 0
    for path in list_devices():
        try:
            dev = InputDevice(path)
        except PermissionError:
            denied += 1
            continue
        except Exception:
            continue
        caps = dev.capabilities()
        keys = set(caps.get(ecodes.EV_KEY, []))
        has_space = ecodes.KEY_SPACE in keys
        has_middle = ecodes.BTN_MIDDLE in keys
        if (has_space or has_middle) and not _looks_like_keyboard(keys):
            picked.append(dev)
        else:
            dev.close()
    if not picked and denied:
        return [], (f"no readable input devices ({denied} permission-denied) — "
                    "this user is not in the 'input' group")
    return picked, ""


def _wheel_ptt_loop():
    """One physical wheel-click → one mic toggle, regardless of window focus."""
    devices, why = _ptt_candidate_devices()
    if not devices:
        # Never fatal: the relay's other senses must keep working, and Dean
        # still has the physical Spacebar. Say why, once, in plain words.
        print(f"[RELAY] wheel-click PTT unavailable: {why or 'no candidate device'}",
              flush=True)
        _api("/api/relay/ptt-source", {"ok": False, "reason": why or "no candidate device"})
        return

    from evdev import ecodes
    from select import select

    names = ", ".join(f"{d.name} ({d.path})" for d in devices)
    print(f"[RELAY] wheel-click PTT watching: {names}", flush=True)
    _api("/api/relay/ptt-source", {"ok": True, "devices": names})

    last_fire = 0.0
    fds = {d.fd: d for d in devices}
    while _running:
        try:
            r, _, _ = select(list(fds), [], [], 1.0)
            for fd in r:
                for ev in fds[fd].read():
                    if ev.type != ecodes.EV_KEY:
                        continue
                    # value 1 = press, 0 = release, 2 = autorepeat. Only the
                    # press toggles: a held wheel must not machine-gun, and a
                    # release must not undo the toggle it just made.
                    if ev.value != 1:
                        continue
                    if ev.code not in (ecodes.KEY_SPACE, ecodes.BTN_MIDDLE):
                        continue
                    # Debounce ACROSS devices, not per device: when the
                    # remapper's virtual device and the mouse both report the
                    # same press, that is one physical action, not two.
                    now = time.time()
                    if now - last_fire < _WHEEL_DEBOUNCE_S:
                        continue
                    last_fire = now
                    _api("/api/relay/mic-toggle", {"source": "wheel"})
        except OSError:
            # Device unplugged or renumbered. Re-detect rather than dying —
            # event numbers are not stable and a USB re-seat must not cost
            # Dean his push-to-talk until the next restart.
            print("[RELAY] PTT device vanished — re-detecting in 3s", flush=True)
            for d in devices:
                try: d.close()
                except Exception: pass
            time.sleep(3.0)
            devices, why = _ptt_candidate_devices()
            if not devices:
                print(f"[RELAY] wheel-click PTT gone: {why}", flush=True)
                return
            fds = {d.fd: d for d in devices}
        except Exception as e:
            print(f"[RELAY] PTT watcher error: {e}", flush=True)
            time.sleep(1.0)


def main():
    global _host, _port, _scheme, _running

    parser = argparse.ArgumentParser(description="Leon Sensor Relay")
    parser.add_argument("--host", default=os.environ.get("LEON_BRAIN_HOST", "127.0.0.1"),
                        help="Brain host (LEON_BRAIN_HOST)")
    parser.add_argument("--port", type=int, default=8000, help="VPS port")
    parser.add_argument("--scheme", choices=["auto", "http", "https"], default="auto",
                        help="URL scheme; auto = https on port 443, else http")
    args = parser.parse_args()
    _host = args.host
    _port = args.port
    _scheme = args.scheme if args.scheme != "auto" else ("https" if _port == 443 else "http")

    # Verify VPS is reachable (with auth)
    print(f"[RELAY] Connecting to Leon brain at {_base_url()}...")
    try:
        _tok = os.environ.get("LEON_API_KEY", "")
        if not _tok:
            print("[RELAY] WARNING: LEON_API_KEY not set in env — VPS will reject our requests.")
        _hdrs = {"Authorization": f"Bearer {_tok}"} if _tok else {}
        url = _base_url() + "/api/state"
        req = Request(url, headers=_hdrs)
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            print(f"[RELAY] Connected — {data['total_neurons']:,} neurons, "
                  f"{data['steps_per_second']:.1f} sps")
    except Exception as e:
        print(f"[RELAY] Cannot reach VPS: {e}")
        sys.exit(1)

    # Start sensor threads + tmux helper + captioners (screen + webcam)
    threads = []
    t0 = threading.Thread(target=_tmux_helper, name="tmux-helper", daemon=True)
    t1 = threading.Thread(target=_audio_loop, name="audio-relay", daemon=True)
    t2 = threading.Thread(target=_screen_loop, name="screen-relay", daemon=True)
    t3 = threading.Thread(target=_caption_loop, name="caption-relay", daemon=True)
    t4 = threading.Thread(target=_caption_webcam_loop, name="webcam-caption-relay",
                          daemon=True)
    # Wake word listener DISABLED (2026-06-23): the always-on Vosk
    # listener caused three unsolvable problems:
    #   1. Self-hearing: Leon's TTS plays through speakers → Vosk picks
    #      up "leon" → fires wake → captures Leon's own response → loop
    #   2. Push-to-talk interruption: Dean holds Space (dashboard mic) →
    #      Vosk ALSO hears him → fires a competing input → "thinking"
    #      cuts him off → two transcriptions → two answers
    #   3. Double voice: paplay + dashboard Audio both played TTS
    # RESOLVED 2026-08-02 — all three now have real fixes, so the default
    # flips to ON:
    #   1. Self-hearing: the actuator sets /tmp/leon-tts-active for the exact
    #      playback window; BOTH on_wake and on_utterance check it (2026-06-21).
    #   2. PTT collision: the dashboard now claims the mic floor via
    #      /api/relay/ptt while Space/middle-click/mic is held, and the wake
    #      loop stands down for that window. Fails OPEN on a network blip —
    #      a dropped claim leaves Leon hearing, never deaf.
    #   3. Double voice: paplay + dashboard both playing TTS — single path now.
    # Set LEON_WAKE_ENABLED=0 to force it back off.
    if os.environ.get("LEON_WAKE_ENABLED", "1") == "1":
        t5 = threading.Thread(target=_wake_loop, name="wake-relay", daemon=True)
        # Feeds audio_gate.REFERENCE so on_utterance's looks_like_echo()
        # check has something to correlate against. Started alongside the
        # wake loop because it exists only to serve that check.
        t6 = threading.Thread(target=_system_audio_loop,
                              name="system-audio-loopback", daemon=True)
        threads.extend([t0, t1, t2, t3, t4, t5, t6])
    else:
        print("[RELAY] wake listener DISABLED (push-to-talk only). "
              "Set LEON_WAKE_ENABLED=1 to re-enable.", flush=True)
        threads.extend([t0, t1, t2, t3, t4])
    # Wheel-click PTT: separate from the wake listener on purpose — it must
    # keep working when wake is disabled, since it IS the push-to-talk.
    if os.environ.get("LEON_WHEEL_PTT", "1") == "1":
        threads.append(threading.Thread(target=_wheel_ptt_loop,
                                        name="wheel-ptt", daemon=True))
    for t in threads:
        t.start()

    print("[RELAY] Sensors streaming. Ctrl+C to stop.")
    print(f"[RELAY] Open dashboard at: {_base_url()}")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[RELAY] Shutting down...")
        _running = False
        for t in threads:
            t.join(timeout=3)


if __name__ == "__main__":
    main()
