# VERIFY: <slug>

REPRODUCTION — OLD CODE (must fail)
  command:
  output:

REPRODUCTION — NEW CODE (must pass)
  command:
  output:

LAYER CHECKED: (the layer Dean experiences — live endpoint, not repo file)

REGRESSION TEST ADDED:

VERDICT: fixed | I think
