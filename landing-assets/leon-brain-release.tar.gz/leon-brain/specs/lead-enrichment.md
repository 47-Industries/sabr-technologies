# SPEC: lead-enrichment

INTAKE (one sentence)
  What changes: the 173 scraped leads get real contact info, a real score,
    and the unworkable ones get killed, so the pipeline becomes actionable.
  How we know it worked: >= 40 leads sitting in a stage other than "new"
    with at least one reachable contact method, and score values are no
    longer all 75.

OBSERVED PROBLEM (measured 2026-08-06 17:38, sample n=15 of stage=new)
  - 14/15 have empty email
  - 13/15 have empty phone
  - 15/15 have score exactly 75  <- default never overwritten
  - 9/15 are Shop:Beauty (salons/nails) — off ideal-customer-profile

FILES TO TOUCH
  - the lead store backing business_list_leads (locate first, do not assume)
  - the scoring function that currently emits a constant 75
  - a new enrichment pass (name + city -> website -> email/phone)

ORDER OF CHANGES
  1. Locate the lead store and the scorer. Read before writing.
  2. TRIAGE: mark leads with no website and no contact as "cold".
     Do not delete. Dean's data, reversible only.
  3. ENRICH: for the survivors, resolve official website, then scrape
     contact page for email + phone. Rate-limited, polite, cached.
  4. RESCORE on signals that mean something:
       has_website / site_is_broken_or_wix / has_contact /
       industry_fits_ICP / city_in_FL_primary_market
     Score must vary. A constant score is a failed build.
  5. Promote enriched + reachable leads out of "new".

FAILURE BRANCHES
  - business has no findable web presence -> cold, logged, not retried
  - site blocks scraping / 403 -> mark unknown, do not guess an email
  - name collision (generic names like "Auto Care") -> require city match,
    else leave unenriched rather than attach the wrong business
  - rate limit hit -> back off, resume, never hammer
  - NEVER fabricate an email address. Empty beats invented.

TEST LIST (the exact commands that prove it)
  - pipeline report: stage breakdown must show >1 stage
  - list stage=new: score column must contain >1 distinct value
  - spot-check 5 enriched leads by hand: does the email resolve to that
    actual business, yes/no
  - re-run enrichment twice: second run must be idempotent, no dupes

OUT OF SCOPE
  - sending any outreach. Enrichment only. Messaging clients as Dean
    still requires Dean's approval.

APPROVED BY LEON: yes
