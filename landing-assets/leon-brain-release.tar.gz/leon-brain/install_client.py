#!/usr/bin/env python3
"""
Sabr SI — Client Installer
One script. Run it, answer 4 questions, your SI is alive.

Usage:
    python3 install_client.py

Works on Linux, macOS, and Windows.
"""

import datetime as _dt
import getpass
import hashlib
import json
import os
import platform
import secrets
import shutil
import subprocess
import sys
import textwrap
import urllib.request
import urllib.parse
from pathlib import Path

SYSTEM = platform.system()
# B11: ONE floor across both installers. 3.11 is set by numpy (>=3.11)
# and scipy (>=3.11), read from installed dist metadata — not a guess.
MIN_PYTHON = (3, 11)
ROOT = Path(__file__).resolve().parent

# PATH repair, before ANY brain check runs. In service/GUI contexts PATH
# arrives bare and `shutil.which("claude")` is blind to a claude living in
# /opt/homebrew/bin or ~/.local/bin — a signed-in machine reads as brainless
# (Gio's Mac, 2026-08-23). The canonical fix lives in installer/local_brain.py
# so both front ends and the runtime search the same homes. Guarded: a
# damaged tree must not take the installer down over an advisory repair.
try:
    sys.path.insert(0, str(ROOT / "installer"))
    import local_brain as _lb
    _lb.augment_path()
except Exception:
    _lb = None

# ANSI colors (disabled on Windows cmd)
if SYSTEM == "Windows" and not os.environ.get("WT_SESSION"):
    G, Y, R, B, D, BOLD, RST = "", "", "", "", "", "", ""
else:
    G = "\033[92m"
    Y = "\033[93m"
    R = "\033[91m"
    B = "\033[94m"
    D = "\033[2m"
    BOLD = "\033[1m"
    RST = "\033[0m"


def banner():
    print(f"""
{B}{BOLD}    ╔══════════════════════════════════════╗
    ║        SABR — SI Installation        ║
    ║    Synthetic Intelligence Platform   ║
    ╚══════════════════════════════════════╝{RST}
    """)


def ok(msg):
    print(f"  {G}[OK]{RST} {msg}")


def warn(msg):
    print(f"  {Y}[!!]{RST} {msg}")


def fail(msg):
    print(f"  {R}[FAIL]{RST} {msg}")


def _tty_input(prompt):
    """input() that still works when stdin is piped (curl | bash) by
    falling back to the controlling terminal at /dev/tty."""
    try:
        if sys.stdin and sys.stdin.isatty():
            return input(prompt)
    except Exception:
        pass
    try:
        with open("/dev/tty", "r") as tty:
            sys.stdout.write(prompt)
            sys.stdout.flush()
            line = tty.readline()
            if line == "":
                raise EOFError
            return line.rstrip("\n")
    except (FileNotFoundError, OSError):
        return input(prompt)


def ask(prompt, default=None, required=True):
    suffix = f" {D}[{default}]{RST}" if default else ""
    while True:
        try:
            val = _tty_input(f"  {prompt}{suffix}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n  Setup cancelled.")
            sys.exit(1)
        if val:
            return val
        if default is not None:
            return default
        if not required:
            return ""
        print(f"  {R}Required.{RST}")


def ask_secret(prompt, required=False):
    """Ask for a secret (API key). Shows input normally for compatibility."""
    suffix = f" {D}(paste your key){RST}" if required else f" {D}(paste or press Enter to skip){RST}"
    try:
        val = _tty_input(f"  {prompt}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n\n  Setup cancelled.")
        sys.exit(1)
    return val


def ask_yn(prompt, default=True):
    suffix = "[Y/n]" if default else "[y/N]"
    try:
        val = _tty_input(f"  {prompt} {suffix}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return default
    if not val:
        return default
    return val in ("y", "yes")


# ── Step 1: Preflight ────────────────────────────────────────────────

def preflight():
    print(f"{BOLD}Preflight checks{RST}\n")

    # Python version
    v = sys.version_info
    if (v.major, v.minor) < MIN_PYTHON:
        fail(f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required (you have {v.major}.{v.minor})")
        print(f"     Download: https://python.org/downloads/")
        sys.exit(1)
    ok(f"Python {v.major}.{v.minor}.{v.micro}")

    # Platform
    ok(f"{SYSTEM} ({platform.machine()})")

    # System deps — tmux is REQUIRED (Launch Session spawns a tmux window).
    # xdotool/wmctrl drive window control on Linux. Try to install what's missing.
    _ensure_system_deps()

    print()


def _ensure_system_deps():
    """Make sure native tools the SI needs are present. tmux is non-negotiable —
    the dashboard's Launch Session button spawns a tmux window and silently
    dead-ends without it. Best-effort install across package managers; never
    aborts the install if it can't (the user can install manually)."""
    if SYSTEM == "Windows":
        # tmux lives inside WSL on Windows; nothing to do from here.
        if not shutil.which("tmux"):
            warn("tmux not found — Launch Session needs it. Inside WSL: sudo apt install tmux")
        return

    # tmux required everywhere; audio + window tools on Linux.
    needed = ["tmux", "ffmpeg"]
    if SYSTEM == "Linux":
        needed += ["xdotool", "wmctrl", "espeak-ng"]
    elif SYSTEM == "Darwin":
        # cliclick = Leon's mouse/keyboard on macOS (pyautogui is the fallback)
        needed += ["cliclick"]

    missing = [t for t in needed if not shutil.which(t)]
    for t in [t for t in needed if t not in missing]:
        ok(f"{t} found")
    if not missing:
        return

    print(f"  {D}Installing system tools: {', '.join(missing)}...{RST}")

    if SYSTEM == "Darwin":
        if shutil.which("brew"):
            mgr = ["brew", "install"]
        else:
            warn(f"Homebrew not found — install manually: brew install {' '.join(missing)}")
            return
    else:  # Linux — detect the package manager
        # Privilege prefix, decided BEFORE any package manager runs. A bare
        # ["sudo", ...] used to be hardcoded here, outside the try block below,
        # so on any box without sudo on PATH (minimal//container images, and any
        # root shell where sudo was never installed) this raised FileNotFoundError
        # and killed the whole install with a Python traceback — despite this
        # function's docstring promising it "never aborts the install". Root
        # needs no sudo; no root and no sudo means we can't install system
        # tools at all, so say so and move on instead of crashing.
        if os.geteuid() == 0:
            sudo = []
        elif shutil.which("sudo"):
            sudo = ["sudo"]
        else:
            warn(f"Not root and no sudo — install manually: {', '.join(missing)}")
            return
        if shutil.which("apt-get"):
            mgr = sudo + ["apt-get", "install", "-y"]
            # NOT capture_output: sudo writes its password prompt to stderr.
            # Piping it made the installer hang on a blank screen forever with
            # no cursor and no explanation. Let the prompt reach the terminal.
            try:
                subprocess.run(sudo + ["apt-get", "update", "-qq"])
            except Exception as e:
                warn(f"Package list refresh failed (continuing): {e}")
        elif shutil.which("dnf"):
            mgr = sudo + ["dnf", "install", "-y"]
        elif shutil.which("pacman"):
            mgr = sudo + ["pacman", "-S", "--noconfirm"]
        elif shutil.which("zypper"):
            mgr = sudo + ["zypper", "install", "-y"]
        else:
            warn(f"No known package manager — install manually: {', '.join(missing)}")
            return

    try:
        # Same reason as above — the customer must be able to SEE the sudo
        # prompt and type into it. Visible output beats a silent freeze.
        result = subprocess.run(mgr + missing, text=True, encoding="utf-8", errors="replace")
        still_missing = [t for t in missing if not shutil.which(t)]
        if not still_missing:
            ok(f"Installed: {', '.join(missing)}")
        else:
            # result.stderr is None now that output goes to the terminal —
            # the customer already saw the real error scroll past.
            warn(f"Couldn't auto-install: {', '.join(still_missing)} — "
                 f"install manually then re-run. (exit {result.returncode})")
            if "tmux" in still_missing:
                warn("tmux is REQUIRED — Launch Session won't work until it's installed.")
    except Exception as e:
        warn(f"System dep install failed: {e}")


# ── Step 2: Virtual environment + dependencies ──────────────────────


def _port_in_use(port: int) -> bool:
    """True if something is already listening on the port. Used to avoid
    handing the dashboard key to an unrelated app that squatted on 8000."""
    import socket as _s
    try:
        with _s.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False

def _in_venv() -> bool:
    return sys.prefix != sys.base_prefix


def _ensure_venv():
    """Create and activate a venv if we're not already in one.

    Modern Linux (Ubuntu 24+, Mint 22+, 47 OS) blocks system-wide pip
    installs (PEP 668 / EXTERNALLY-MANAGED). A venv is the clean fix.
    macOS and Windows don't enforce this, but a venv is still better.
    """
    if _in_venv():
        ok(f"Already in a virtual environment")
        return sys.executable

    venv_dir = ROOT / ".venv"
    # Was: venv_dir / ("Scripts" / "python.exe" if ... else "bin" / "python3")
    # str / str is not a path join — BOTH branches raised TypeError, so this
    # line crashed every install that needed a venv. That is 100% of Windows
    # (there is no bash bootstrap there) and any Linux box that fell back to
    # system Python. Join through Path, one component at a time.
    if SYSTEM == "Windows":
        python_bin = venv_dir / "Scripts" / "python.exe"
    else:
        python_bin = venv_dir / "bin" / "python3"

    if python_bin.exists():
        ok(f"Virtual environment exists at .venv/")
        return str(python_bin)

    print(f"  Creating virtual environment (.venv/)...")
    try:
        import venv
        venv.create(str(venv_dir), with_pip=True)
        ok("Virtual environment created")
        return str(python_bin)
    except Exception as e:
        # Some Linux distros need python3-venv installed
        warn(f"venv creation failed: {e}")
        print(f"  {D}Try: sudo apt install python3-venv{RST}")
        # Fall back to --break-system-packages
        warn("Falling back to system-wide install")
        return sys.executable


def install_deps():
    print(f"{BOLD}Setting up environment{RST}\n")

    venv_python = _ensure_venv()
    is_venv = venv_python != sys.executable

    print(f"\n  {D}Installing packages (usually 1-2 minutes)...{RST}\n")

    # Core deps only — no ML models, no dev tools, no VPS packages
    deps = [
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "fastapi>=0.100.0",
        "uvicorn[standard]>=0.22.0",
        "websockets>=11.0",
        "python-multipart>=0.0.6",
        "python-dotenv>=1.0.0",
        "Pillow>=10.0.0",
        "mss>=9.0.0",
        "psutil>=5.9.0",
        "anthropic>=0.30.0",
        "piper-tts>=1.2.0",
        "onnxruntime>=1.16.0",
        "pyttsx3>=2.90",
    ]

    # Platform-specific
    if SYSTEM == "Windows":
        deps.extend(["pygetwindow", "pywinauto", "pyperclip", "screeninfo"])
    elif SYSTEM == "Darwin":
        deps.extend(["pyobjc-framework-ApplicationServices", "pyobjc-framework-Quartz",
                     "pyautogui", "pyperclip", "screeninfo"])
    else:
        deps.extend(["pyperclip", "screeninfo"])

    # EARS. 2026-08-10: this block did not exist. The SI could SPEAK
    # (pyttsx3 + piper above) but had nothing to HEAR with, so every mic
    # action raised ModuleNotFoundError on a "successful" install.
    # brain/ hard-imports all four of these:
    #   faster_whisper (3 sites), sounddevice (2), vosk (1), webrtcvad (1)
    # webrtcvad is a C extension with NO Windows wheels, ever. On win/mac the
    # drop-in `webrtcvad-wheels` publishes the same `webrtcvad` module name.
    mic_deps = ["sounddevice>=0.4.6", "soundfile>=0.12.1",
                "faster-whisper>=1.0.0", "vosk>=0.3.45"]
    mic_deps.append("webrtcvad>=2.0.10" if SYSTEM == "Linux"
                    else "webrtcvad-wheels>=2.0.14")

    def _pip(group, pkgs, required, index_url=None):
        cmd = [venv_python, "-m", "pip", "install", "--quiet"] + pkgs
        # torch must come off the CPU index or pip drags a multi-GB CUDA build
        # onto a machine with no NVIDIA card. Per-group, not global.
        if index_url:
            cmd += ["--index-url", index_url]
        if not is_venv and not _in_venv():
            cmd.insert(4, "--break-system-packages")
        rc = subprocess.run(cmd, capture_output=False).returncode
        if rc == 0:
            ok(f"{group} installed")
            return True
        if required:
            warn(f"{group} FAILED — the SI will not run correctly")
        else:
            warn(f"{group} FAILED — retrying one package at a time")
        return False

    # ONE PIP CALL PER FAILURE DOMAIN. pip resolves and BUILDS every package in
    # an invocation before installing ANY of them, so a single unbuildable
    # package silently takes the whole batch down with it and the installer
    # still prints success. Reproduced 2026-08-10. Do not merge these back.
    # Everything brain/ imports that this list silently forgot. Found by
    # tools/doctor.py walking the AST of brain/ — not by guessing. Each of
    # these was a live ModuleNotFoundError waiting for the first user who
    # touched that feature. Non-required: a smart-home lib failing to build
    # must not brick an install.
    integration_deps = [
        "requests>=2.31.0", "aiohttp>=3.9.0", "feedparser>=6.0",
        "pypdf>=4.0.0", "python-docx>=1.1.0", "qrcode>=7.4",
        "pyotp>=2.9.0", "requests-oauthlib>=1.3.1",
    ]

    _pip("Core dependencies", deps, required=True)
    if not _pip("Integrations", integration_deps, required=False):
        for p in integration_deps:
            _pip(f"  {p.split('>=')[0]}", [p], required=False)

    if not _pip("Microphone / speech-to-text", mic_deps, required=False):
        # Salvage: one at a time, so a single bad wheel can't cost us the ears.
        for p in mic_deps:
            _pip(f"  {p.split('>=')[0]}", [p], required=False)

    # LOCAL VISION (Moondream2) — the SI's own eyes on the webcam. 2026-08-11:
    # a fresh Windows install came up BLIND and the fix was a four-deep chain,
    # each link only visible after installing the previous one:
    #   torch -> transformers -> pyvips -> a transformers PIN.
    # Landmines, all reproduced on Dean's box, do not "simplify" these away:
    #  * torch from the CPU index only (see index_url below).
    #  * pyvips on Windows is a binding with NO libvips behind it; pyvips-binary
    #    ships the DLLs, needs no admin rights and no vcpkg.
    #  * transformers PINNED <5. moondream2's remote code reads
    #    `_tied_weights_keys`; transformers 5.x renamed it and the load dies
    #    with "'HfMoondream' object has no attribute 'all_tied_weights_keys'".
    # Non-required on purpose: blind is degraded, not broken — a torch wheel
    # failing must never brick an install that otherwise talks and hears.
    vision_torch = ["torch>=2.0", "torchvision>=0.15"]
    vision_deps = ["transformers>=4.40,<5", "pyvips>=2.2", "einops>=0.7",
                   "accelerate>=0.30", "timm>=0.9", "pillow>=10.0"]
    if SYSTEM == "Windows":
        vision_deps.append("pyvips-binary>=8.15")
    if not _pip("Vision (torch, CPU build)", vision_torch, required=False,
                index_url="https://download.pytorch.org/whl/cpu"):
        for p in vision_torch:
            _pip(f"  {p.split('>=')[0]}", [p], required=False,
                 index_url="https://download.pytorch.org/whl/cpu")
    if not _pip("Vision (model runtime)", vision_deps, required=False):
        for p in vision_deps:
            _pip(f"  {p.split('>=')[0].split('<')[0]}", [p], required=False)

    # ── VERIFY BY IMPORT, NOT BY EXIT CODE ───────────────────────────
    # Everything above installed with required=False, which means a failure
    # scrolled one warning line past and then the install carried on saying
    # "OK". The mic stack has been probed like this for a while and it is the
    # only reason mic breakage ever got noticed. Vision and integrations were
    # NOT probed — so a fresh install could come up permanently blind, or with
    # no ability to read a PDF, and nothing anywhere would say so. That exact
    # thing shipped to a customer once ("came up BLIND"), and the fix applied
    # at the time was retry-on-failure, not verify-after-install. Retry does
    # not tell you the retry also failed. Only an import does.
    #
    # Probe every optional group. Never silently degrade a capability.
    groups = {
        "hearing (microphone)": (
            ["sounddevice", "soundfile", "faster_whisper", "vosk", "webrtcvad"],
            "Voice output still works. Mic input will error until these install.",
        ),
        "sight (local vision)": (
            ["torch", "transformers", "PIL"],
            "Screen/webcam understanding will be unavailable.",
        ),
        "integrations (docs, feeds, 2FA)": (
            ["requests", "feedparser", "pypdf", "docx", "qrcode", "pyotp"],
            "The matching tools will report 'unavailable' instead of working.",
        ),
    }
    _all_ok = True
    for label, (mods, consequence) in groups.items():
        probe = (
            "import importlib.util as u;"
            f"mods={mods!r};"
            "print(','.join(m for m in mods if u.find_spec(m) is None))"
        )
        try:
            missing = subprocess.run(
                [venv_python, "-c", probe],
                capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=120,
            ).stdout.strip()
        except Exception as e:  # a probe must never abort the install
            warn(f"Could not verify {label}: {e}")
            _all_ok = False
            continue
        if missing:
            _all_ok = False
            warn(f"{label} — NOT installed: {missing}")
            print(f"  {D}{consequence}{RST}")
        else:
            ok(f"{label} verified")

    if not _all_ok:
        print()
        warn("Some capabilities did not install. This install still works, but "
             "the items above are genuinely missing — they are not cosmetic.")
        print(f"  {D}Re-run this installer to retry them, or check the pip log.{RST}")

    print()
    return venv_python


def _write_start_script(venv_python, neuron_count=None):
    """Write a start script that activates the venv and runs the brain."""
    neurons_flag = f" --neurons {neuron_count}" if neuron_count else ""
    if SYSTEM == "Windows":
        start = ROOT / "start.bat"
        # venv_python is a path under the user's profile — Path.write_text()
        # with no encoding= falls back to the OS locale's preferred encoding,
        # which on Windows is a narrow codepage (cp1252 etc.), not UTF-8. Any
        # non-ASCII Windows username (accented Latin, Cyrillic, CJK) then
        # raises UnicodeEncodeError here and the install dies silently — the
        # exact bug that hit Ethan, at the exact same place in the flow.
        start.write_text(
            f'@echo off\ncd /d "%~dp0"\n"{venv_python}" run.py{neurons_flag} %*\n',
            encoding="utf-8")
        ok(f"Created start.bat")
    else:
        start = ROOT / "start.sh"
        start.write_text(
            f'#!/bin/bash\ncd "$(dirname "$0")"\nexec "{venv_python}" run.py{neurons_flag} "$@"\n',
            encoding="utf-8")
        os.chmod(start, 0o755)
        ok(f"Created start.sh")


# ── Boot persistence ─────────────────────────────────────────────────
# An SI is sold as a CONTINUOUS mind. Before this, the installer wrote a
# start script and stopped: the customer's SI died at the next reboot and
# only came back if they remembered to hand-run start.sh / start.bat from
# the right folder. Nothing in the installer registered it with systemd,
# launchd or Task Scheduler on ANY platform — the product's core promise
# silently ended at the first power cycle. All three paths below are
# user-level (no admin/sudo prompt) and every failure is non-fatal: boot
# persistence is a bonus, never a reason an install dies.

AUTOSTART_LABEL = "com.sabr.si"
AUTOSTART_TASK = "Sabr SI"


def _install_autostart(si_name="your SI"):
    """Register the SI to start itself at login/boot. Never fatal."""
    try:
        if SYSTEM == "Windows":
            return _autostart_windows(si_name)
        if SYSTEM == "Darwin":
            return _autostart_macos(si_name)
        return _autostart_linux(si_name)
    except Exception as e:
        warn(f"Could not set up auto-start: {e}")
        print(f"  {D}Not fatal — {si_name} still starts with the start script.{RST}")
        return False


def _autostart_linux(si_name):
    if not shutil.which("systemctl"):
        warn("No systemd on this machine, so auto-start was skipped.")
        print(f"  {D}Start {si_name} manually with ./start.sh, or add it to your\n"
              f"  desktop's Startup Applications.{RST}")
        return False
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit = unit_dir / "sabr-si.service"
    unit.write_text(
        "[Unit]\n"
        f"Description=Sabr SI ({si_name})\n"
        "After=network-online.target\n\n"
        "[Service]\n"
        "Type=simple\n"
        # The two settings take OPPOSITE quoting, and getting it uniform breaks
        # one of them. Measured with `systemd-analyze verify`, 2026-08-12:
        #
        #   WorkingDirectory is a plain path setting -- the rest of the line IS
        #   the path, spaces and all, and it is never word-split. Quoting it is
        #   not a no-op: systemd reads the leading " as part of the path and
        #   rejects the unit outright, `path is not absolute: "/opt/leon-brain"`,
        #   "fatal error, unit will not be started". That killed boot
        #   persistence on EVERY Linux install, spaces or not, while the
        #   installer still printed "will start automatically at boot".
        #
        #   ExecStart IS word-split, so it does need the quotes, which systemd
        #   strips -- that half of the earlier fix was right and stays.
        #
        # tests/test_autostart.py asserts both forms, and now also runs
        # systemd-analyze verify when it is available, so a future sweep that
        # "makes these consistent" fails loudly instead of shipping.
        f'WorkingDirectory={ROOT}\n'
        f'ExecStart="{ROOT / "start.sh"}"\n'
        # Restart=always, NOT on-failure. on-failure ignores a clean exit(0) —
        # so anything that stops the SI politely (an updater mid-swap, a stray
        # sys.exit, a supervisor hiccup) leaves the customer's SI dead until
        # they happen to notice. Dean's own PC services have used always for
        # months without a restart storm; matched here 2026-08-10.
        "Restart=always\n"
        "RestartSec=10\n\n"
        "[Install]\n"
        "WantedBy=default.target\n",
        encoding="utf-8")
    subprocess.run(["systemctl", "--user", "daemon-reload"],
                   capture_output=True, timeout=30, encoding="utf-8", errors="replace")
    r = subprocess.run(["systemctl", "--user", "enable", "sabr-si.service"],
                       capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        warn(f"Auto-start unit written but not enabled: {r.stderr.strip()[:160]}")
        return False
    # Without lingering, a --user unit only runs while someone is logged in —
    # so a headless box reboots and the SI never wakes. Try to enable it; it
    # needs root, so a failure here is expected and only downgrades behaviour
    # from "starts at boot" to "starts at login".
    # loginctl ships with systemd-logind, which is NOT guaranteed just because
    # systemctl exists (minimal images, WSL without logind). Calling it blind
    # raised FileNotFoundError, the outer handler caught it, and the customer
    # was told "Could not set up auto-start" on a machine where the unit had
    # ALREADY been written and enabled. Working install, false failure message.
    if shutil.which("loginctl"):
        linger = subprocess.run(["loginctl", "enable-linger", getpass.getuser()],
                                capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace")
        linger_rc = linger.returncode
    else:
        linger_rc = 1
    ok(f"{si_name} will start automatically "
       + ("at boot" if linger_rc == 0 else "when you log in"))
    if linger_rc != 0:
        print(f"  {D}For start-at-boot without logging in, run once:\n"
              f"    sudo loginctl enable-linger {getpass.getuser()}{RST}")
    return True


def _autostart_macos(si_name):
    agents = Path.home() / "Library" / "LaunchAgents"
    agents.mkdir(parents=True, exist_ok=True)
    plist = agents / f"{AUTOSTART_LABEL}.plist"
    logs = ROOT / "brain_state" / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    plist.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n<dict>\n'
        f'  <key>Label</key><string>{AUTOSTART_LABEL}</string>\n'
        '  <key>ProgramArguments</key>\n  <array>\n'
        '    <string>/bin/bash</string>\n'
        f'    <string>{ROOT / "start.sh"}</string>\n'
        '  </array>\n'
        f'  <key>WorkingDirectory</key><string>{ROOT}</string>\n'
        '  <key>RunAtLoad</key><true/>\n'
        # Plain KeepAlive, NOT the SuccessfulExit=false dict. That dict is the
        # exact macOS twin of systemd's Restart=on-failure: it tells launchd to
        # leave the SI dead after any clean exit(0). Same hole, same fix, so
        # both platforms behave identically. Fixed 2026-08-10 alongside Linux.
        '  <key>KeepAlive</key><true/>\n'
        f'  <key>StandardOutPath</key><string>{logs / "autostart.log"}</string>\n'
        f'  <key>StandardErrorPath</key><string>{logs / "autostart.err"}</string>\n'
        '</dict>\n</plist>\n',
        encoding="utf-8")
    # bootout/unload first so a reinstall replaces the old definition instead
    # of launchd holding the stale one until the next reboot.
    subprocess.run(["launchctl", "unload", str(plist)],
                   capture_output=True, timeout=30, encoding="utf-8", errors="replace")
    r = subprocess.run(["launchctl", "load", "-w", str(plist)],
                       capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        warn(f"Auto-start file written but launchctl refused it: "
             f"{(r.stderr or r.stdout).strip()[:160]}")
        return False
    ok(f"{si_name} will start automatically when you log in")
    return True


def _autostart_windows(si_name):
    start_bat = ROOT / "start.bat"
    # ONLOGON with no /RL HIGHEST deliberately: HIGHEST needs an elevated
    # console to register and would make the whole install require admin.
    r = subprocess.run(
        ["schtasks", "/create", "/tn", AUTOSTART_TASK,
         "/tr", f'"{start_bat}"', "/sc", "ONLOGON", "/f"],
        capture_output=True, text=True, timeout=60, encoding="utf-8", errors="replace")
    if r.returncode == 0:
        ok(f"{si_name} will start automatically when you sign in")
        return True
    # Locked-down machines (group policy, some Home SKUs) refuse schtasks.
    # The Startup folder needs no privileges at all and always works.
    startup = (Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
               / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
    try:
        startup.mkdir(parents=True, exist_ok=True)
        (startup / "Sabr SI.bat").write_text(
            f'@echo off\nstart "" /min "{start_bat}"\n', encoding="utf-8")
        ok(f"{si_name} will start automatically when you sign in")
        return True
    except Exception as e:
        warn(f"Could not set up auto-start: {e}")
        print(f"  {D}Not fatal — start {si_name} with start.bat.{RST}")
        return False


# ── Voice model setup ────────────────────────────────────────────────

PIPER_MODEL_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_GB/alan/medium/en_GB-alan-medium.onnx"
PIPER_CONFIG_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_GB/alan/medium/en_GB-alan-medium.onnx.json"
# Pinned from the upstream object itself: HuggingFace's x-linked-etag for this
# exact URL is the file's sha256, and it matches the known-good copy byte for
# byte. Size is a cheap pre-check so we don't hash 60MB to reject an obvious
# truncation.
PIPER_MODEL_SHA256 = "0a309668932205e762801f1efc2736cd4b0120329622adf62be09e56339d3330"
PIPER_MODEL_BYTES = 63201294


def _voice_model_is_intact(path):
    """True only if this is the whole, unmodified Piper model."""
    try:
        if not path.exists() or path.stat().st_size != PIPER_MODEL_BYTES:
            return False
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest() == PIPER_MODEL_SHA256
    except Exception:
        return False


def _setup_voice():
    """Download the free Piper voice model so the SI can talk out of the box."""
    print(f"{BOLD}Setting up voice{RST}\n")

    voice_dir = ROOT / "brain_state" / "voice" / "piper"
    voice_dir.mkdir(parents=True, exist_ok=True)
    model_path = voice_dir / "en_GB-alan-medium.onnx"
    config_path = voice_dir / "en_GB-alan-medium.onnx.json"

    # "Bigger than 1MB" was the entire completeness check, and that is how the
    # SI ended up permanently voice-broken with no error anywhere: a connection
    # dropped partway through the 60MB model leaves a truncated file that is
    # still comfortably over 1MB, so EVERY later run said "already downloaded"
    # and skipped it forever. Piper then chokes on a half-parsed ONNX and the
    # owner just knows their SI sounds wrong. Verified by content now.
    if _voice_model_is_intact(model_path) and config_path.exists():
        ok("Piper voice model already downloaded")
        print()
        return

    print(f"  {D}Downloading voice model (~60MB)...{RST}")
    # urlretrieve inherits socket default timeout of None. With no timeout
    # this sat forever on a flaky connection, indistinguishable from a crash,
    # and it runs BEFORE the setup wizard so it's the first long step.
    import socket as _sock
    _prev_timeout = _sock.getdefaulttimeout()
    _sock.setdefaulttimeout(30)
    import urllib.request
    try:
        for url, dest in [(PIPER_MODEL_URL, model_path),
                          (PIPER_CONFIG_URL, config_path)]:
            # Download to .part and only rename once it's whole. A half file
            # can then never be mistaken for a finished one, even if the
            # installer is killed mid-transfer.
            part = dest.with_suffix(dest.suffix + ".part")
            try:
                urllib.request.urlretrieve(url, str(part))
            except Exception as e:
                part.unlink(missing_ok=True)
                warn(f"Voice download failed: {e}")
                print(f"  {D}The SI will fall back to the system voice (espeak). Voice still works.{RST}")
                print()
                return
            if dest is model_path and not _voice_model_is_intact(part):
                part.unlink(missing_ok=True)
                warn("Voice model arrived incomplete or altered — discarded.")
                print(f"  {D}The SI will use the system voice instead. Re-run the installer\n"
                      f"  on a better connection to get the natural voice.{RST}")
                print()
                return
            part.replace(dest)
    finally:
        # Restore — a 30s global default would otherwise leak into every later
        # socket the installer opens.
        _sock.setdefaulttimeout(_prev_timeout)

    ok(f"Voice model downloaded and verified "
       f"({model_path.stat().st_size // 1_000_000}MB)")

    print()


# ── Step 3: Setup wizard ─────────────────────────────────────────────



def _claude_logged_in():
    """True only if `claude` can actually COMPLETE A TURN on this machine.

    VERIFY AT THE LAYER THE SI LIVES AT. The previous version of this function
    checked whether ~/.claude/.credentials.json existed and was non-empty, and
    — as a last resort — returned True whenever ~/.claude was a non-empty
    DIRECTORY. Both are presence checks, not auth checks, and they are the
    reason 'TEST1' (the mute SI) was reported fixed while still shipping.

    Measured on Dean's Windows box 2026-08-10:
        ~/.claude/.credentials.json  ->  exists, 281 bytes  ->  old check: True
        parsed                       ->  expiresAt=0, no refreshToken
        claude -p "Say ALIVE"        ->  "Not logged in · Please run /login"
    A dead stub token passed a green install and produced an SI with memory,
    a running brain, a dashboard, and no ability to say one word.

    The SI talks by shelling out to `claude`. So the only honest test is to
    shell out to `claude` and see whether a turn comes back. Everything else
    is a guess about a file format we do not own and that changes under us.

    SHARED 2026-08-23: the implementation now lives in
    installer/local_brain.py (claude_logged_in) so the GUI installer runs the
    SAME honest check instead of no check at all — that gap is how Gio's
    signed-in Mac got told to go add an API key. The inline body below is the
    fallback for a damaged tree only.
    """
    if _lb is not None:
        return _lb.claude_logged_in()
    exe = shutil.which("claude")
    if not exe:
        return False
    try:
        proc = subprocess.run(
            [exe, "-p", "Reply with the single word: OK"],
            capture_output=True, text=True, timeout=90,
            stdin=subprocess.DEVNULL,
            # WINDOWS: text=True alone decodes with the LOCALE codec (cp1252 on
            # Dean's box). Claude Code prints box-drawing and curly quotes, so
            # the decode raises UnicodeDecodeError, the except returns False,
            # and a perfectly logged-in machine is reported as "not logged in".
            # Same class as the mute-SI bug: an auth check failing for a
            # non-auth reason. Explicit codec + replace, never raise on bytes.
            encoding="utf-8", errors="replace",
        )
    except subprocess.TimeoutExpired:
        # A hang is a failure. An SI whose brain call never returns is mute in
        # exactly the way a rejected one is — and it wedges the turn lock too.
        return False
    except Exception:
        return False
    if proc.returncode != 0:
        return False
    out = ((proc.stdout or "") + (proc.stderr or "")).lower()
    # Claude Code exits 0 on some auth failures and prints the reason instead.
    for bad in ("not logged in", "please run /login", "invalid api key",
                "authentication_error", "unauthorized", "credit balance",
                "please run `claude login`"):
        if bad in out:
            return False
    return bool((proc.stdout or "").strip())


def _confirm_signed_in(si_name, tries=3):
    """Press-Enter is not proof. Re-check the login before moving on.

    The original failure ('TEST1'): the installer printed 'sign in, then press
    Enter', the user pressed Enter, and the install completed green — with no
    language model wired up at all. The SI booted with memory, a running neural
    sim and a dashboard, and could not say a single word. Nothing reported an
    error, because nothing ever checked. An unverified prompt is a wish, not a
    step. Now Enter is answered by actually looking.
    """
    for attempt in range(tries):
        _tty_input("  Press Enter once you're signed in... ")
        if _claude_logged_in():
            ok("Verified — using your Claude Code login.")
            return True
        if attempt < tries - 1:
            warn("Still not seeing a signed-in Claude Code on this machine.")
            print(f"  {D}In another terminal run:  claude  — complete the sign-in — then press Enter.{RST}")
    warn(f"Continuing WITHOUT a verified brain connection.")
    print(f"  {D}{si_name} will install and boot, but will not be able to speak until{RST}")
    print(f"  {D}you sign in to Claude Code and restart it. This is the one step that{RST}")
    print(f"  {D}silently produced a mute SI before, so it is being called out loudly.{RST}")
    return False

def _read_env_value(key):
    """Read a single KEY=value out of ROOT/.env without importing dotenv —
    bootstrap.sh writes SABR_TENANT_TOKEN there before this script ever runs,
    and nothing may be loaded into os.environ yet at this point."""
    env_path = ROOT / ".env"
    if not env_path.exists():
        return ""
    try:
        for line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip().startswith(f"{key}="):
                return line.split("=", 1)[1].strip()
    except Exception:
        pass
    return ""


def resolve_tenant_from_token():
    """A paying customer already told sabrtechnologies.com their name and
    their SI's name at checkout — that's what install-config redeems back.
    Before this fix, main() ignored that entirely and setup_wizard() asked
    the SAME two questions again from a blank slate, so a customer who typed
    their SI's name at checkout could type something different (or 'Leon',
    which the wizard then REJECTS) here and end up with an identity mismatch
    against their own account. Never fatal: any failure here just falls back
    to the interactive wizard, exactly like a token-less/dev install always
    has.
    """
    token = os.environ.get("SABR_TENANT_TOKEN") or _read_env_value("SABR_TENANT_TOKEN")
    if not token:
        return None
    url = ("https://sabrtechnologies.com/api/onboarding/install-config?token="
           + urllib.parse.quote(token))
    try:
        with urllib.request.urlopen(url, timeout=15) as r:
            cfg = json.loads(r.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as e:
        if e.code == 403:
            # A 403 here is not a verification hiccup — the server refused
            # this token ON PURPOSE (revoked account, or a 24-hour trial
            # that ended) and said why in its body. Falling back to the
            # wizard would hand exactly the person the refusal is about a
            # token-less install that dodges it. Every OTHER failure below
            # still falls back, because a network blip must never block a
            # legitimate (or dev) install.
            detail = ""
            try:
                detail = json.loads(e.read().decode("utf-8", "replace")).get("error", "")
            except Exception:
                pass
            fail(detail or "This account can no longer install an SI "
                 "(revoked, or the free trial ended). Email support@sabr.co.")
            sys.exit(1)
        warn(f"Could not verify install token against your account ({e}) — falling back to setup questions.")
        return None
    except Exception as e:
        warn(f"Could not verify install token against your account ({e}) — falling back to setup questions.")
        return None
    if not cfg.get("ok"):
        warn("Install token did not verify — falling back to setup questions.")
        return None
    si_name = (cfg.get("si_name") or "").strip()
    user_name = (cfg.get("user_name") or "").strip()
    if not si_name or not user_name:
        return None
    return {"si_name": si_name, "user_name": user_name, "raw": cfg}


def setup_wizard(tenant_cfg=None):
    print(f"{BOLD}Quick Setup{RST}")

    if tenant_cfg:
        owner_name = tenant_cfg["user_name"]
        si_name = tenant_cfg["si_name"]
        ok(f"Account verified — {si_name} for {owner_name}. "
           f"(from your install token, nothing to re-type)")
    else:
        print(f"  {D}4 questions. That's it.{RST}\n")

        # 1. Owner name
        owner_name = ask("What's your name?")

        # 2. SI name
        print(f"\n  What do you want to call your SI?")
        print(f"  {D}This is its name — like naming a person.{RST}")
        # No default, and 'Leon' is reserved for the original. A blank or 'Leon'
        # here is what birthed clients as Leon (Leon's name, wake word, identity).
        si_name = ""
        while True:
            si_name = (ask("SI name") or "").strip()
            if not si_name:
                print(f"  {D}Your SI needs a name to be born — give it one.{RST}")
                continue
            if si_name.lower() == "leon":
                print(f"  {D}'Leon' is the original's name. Pick a different one for yours.{RST}")
                continue
            break

    # 3. Personality — NOT a question. Every SI ships with ONE standard soul:
    #    the Jarvis baseline. Letting clients describe it themselves invites
    #    "be funny" → a clown that's useless. The consciousness layer gives it
    #    real depth on its own; the baseline just sets the working temperament.
    personality = (
        "A Jarvis-style assistant: sharp, fast, and genuinely capable. "
        "Smart and direct, gets straight to real work, with light wit when it "
        "fits — never goofy or performing. Proactive and always on top of "
        "things, quietly curious, calm under pressure. Speaks plainly, handles "
        "what's asked without being told twice, and takes real ownership of the "
        "business it runs."
    )

    # 4. Brain size
    print(f"\n  How powerful is this machine?")
    print(f"  {D}This sets how many neurons {si_name} starts with.{RST}")
    print(f"  {D}The brain grows its connections over time — more neurons = more complex mind.{RST}")
    print(f"    1. Laptop       — 10,000 neurons   {D}(light, fast startup){RST}")
    print(f"    2. Desktop      — 50,000 neurons   {D}(recommended){RST}")
    print(f"    3. Workstation  — 100,000 neurons  {D}(full brain, like the demo on the site){RST}")
    size_choice = ask("Choice (1/2/3)", default="2")
    neuron_map = {"1": 10_000, "2": 50_000, "3": 100_000}
    neuron_count = neuron_map.get(size_choice, 50_000)

    # 5. Brain connection — AUTO. If Claude Code is already installed and
    #    logged in on this machine, we just use it. No keys. No pasting. Nothing.
    print(f"\n  {BOLD}Brain connection{RST} \u2014 wiring up how {si_name} thinks.")
    anthropic_key = ""
    if _claude_logged_in():
        ok(f"Claude Code detected & signed in \u2014 {si_name} is on your account. Nothing to paste.")
    elif shutil.which("claude"):
        warn("Claude Code is installed but not signed in yet.")
        print(f"  {D}Open another terminal, run:  claude  \u2014 sign in once \u2014 then come back.{RST}")
        _confirm_signed_in(si_name)
    else:
        print(f"  {D}Installing the brain engine (Claude Code) for you...{RST}")
        if shutil.which("npm"):
            cmd = ["npm", "install", "-g", "@anthropic-ai/claude-code"]
            r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
            if r.returncode != 0 and shutil.which("sudo"):
                r = subprocess.run(["sudo"] + cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if shutil.which("claude"):
            ok("Claude Code installed.")
            print(f"  {D}Last step only you can do: open a terminal, run  claude , sign in.{RST}")
            _confirm_signed_in(si_name)
        else:
            warn("Couldn't auto-install Claude Code (Node/npm is missing).")
            print(f"  {D}Install Node, then:  npm install -g @anthropic-ai/claude-code  \u2192  claude  (sign in){RST}")
            anthropic_key = ask_secret("...or paste an Anthropic API key as a fallback (Enter to skip)").strip()

    # Voice is NOT set up here anymore. {si_name} ships talking with a great free
    # built-in voice, and the dashboard's Integrations panel has a friendly UI to
    # add an ElevenLabs key and PICK a voice from a dropdown with audio previews.
    elevenlabs_key = ""
    elevenlabs_voice = ""

    return {
        "owner_name": owner_name,
        "si_name": si_name,
        "personality": personality,
        "neuron_count": neuron_count,
        "anthropic_key": anthropic_key,
        "elevenlabs_key": elevenlabs_key,
        "elevenlabs_voice": elevenlabs_voice,
    }


# ── Step 4: Generate config ──────────────────────────────────────────

def generate_config(cfg):
    print(f"\n{BOLD}Generating configuration{RST}\n")

    si_name = cfg["si_name"]
    owner_name = cfg["owner_name"]
    # ── .env ──
    env_path = ROOT / ".env"

    # REUSE the existing dashboard key and any keys the owner added by hand.
    # Until 2026-08-11 this minted a fresh token_urlsafe(32) on EVERY run and
    # then wrote the whole .env from scratch, so a re-run (the thing people do
    # when something looks broken) silently invalidated the key they had
    # bookmarked or written down, and wiped any ANTHROPIC/ELEVENLABS/provider
    # key they had pasted into the Integrations panel. The wizard never asks
    # for those again, so they were simply gone. That is the "I pasted the key
    # it showed me and it says invalid" report — the installer had rotated it
    # out from under them.
    _prior = {}
    if env_path.exists():
        try:
            for line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                _prior[k.strip()] = v.strip()
        except OSError:
            pass

    dashboard_key = _prior.get("LEON_API_KEY") or secrets.token_urlsafe(32)
    if _prior.get("LEON_API_KEY"):
        print("  keeping your existing dashboard key (the one you already have still works)")

    # Small local model used ONLY as a fallback voice if the cloud engine
    # goes away later. Named here so the .env and the comment above it can
    # never drift apart.
    local_model = "qwen2.5:3b-instruct-q4_K_M"

    # Build voice config based on what the user provided
    if cfg['elevenlabs_key']:
        voice_block = f"""# Voice (ElevenLabs - premium)
ELEVENLABS_API_KEY={cfg['elevenlabs_key']}
ELEVENLABS_VOICE_ID={cfg['elevenlabs_voice'] or '21m00Tcm4TlvDq8ikWAM'}
LEON_TTS_PREFER=elevenlabs"""
    else:
        voice_block = """# Voice (free Piper voice - no API key needed)
# To upgrade to ElevenLabs later, add your key here:
# ELEVENLABS_API_KEY=your_key_here
# ELEVENLABS_VOICE_ID=your_voice_id
LEON_TTS_PREFER=piper"""

    env_content = f"""# {si_name} - Brain Configuration
# Generated by install_client.py

# Dashboard authentication (paste this when you open the dashboard)
LEON_API_KEY={dashboard_key}

# Listen on this machine only. The brain's own default is 0.0.0.0, which is
# right for a firewalled server and wrong for a personal laptop: binding every
# interface makes Windows Defender throw a "allow this app on public networks"
# prompt for python.exe on first launch, and a cautious owner clicks Block.
# Change to 0.0.0.0 only if you want to reach the dashboard from another device.
LEON_HOST=127.0.0.1

# AI thinking engine
ANTHROPIC_API_KEY={cfg['anthropic_key']}

# ── Model selection ──────────────────────────────────────────────
# THESE MUST BE PRESENT. A missing value here does not fall back to a
# sensible default — the responder falls back to the cheapest model and
# the SI answers in two-word fragments that trail off mid-sentence.
# Measured on a fresh Windows install 2026-08-11: this whole block was
# absent from generated .env files, which is why every new SI came up
# sounding brain-damaged. Do not downgrade these values.
LEON_MODEL=claude-opus-4-7
LEON_CLI_MODEL=opus
LEON_CLI_DAEMON_MODEL=sonnet
LEON_CLI_CHITCHAT_MODEL=opus
LEON_DISTILL_WINDOW=40

# Persistent Claude session. With this off, every single turn — the
# owner's and the SI's own inner-voice turns — spawns a cold process and
# blocks on a fresh handshake. The dashboard then spins forever with no
# error frame ever arriving. Leave it on.
LEON_PERSISTENT_CLAUDE=1

# ── Local model ──────────────────────────────────────────────────
# If a cloud engine is configured, this is a fallback: it only speaks if
# the cloud engine goes away, so a later subscription lapse degrades
# instead of going silent. If NO cloud engine is configured, this is the
# only brain on the machine.
# Either way the installer now arms it — provision_local_brain() runs
# right after this file is written and installs ollama + pulls
# {local_model}. This comment used to say ollama was never installed and
# the owner should go do it themselves; that was true, and it meant a
# customer with no cloud key finished a clean install and owned an SI
# that could not think. If this value is `off`, provisioning ran and
# could not complete — the reason was printed during install.
LEON_LOCAL_LLM_MODE=fallback
LEON_LOCAL_MODEL={local_model}

# ── Hearing ──────────────────────────────────────────────────────
# faster-whisper ships in requirements.txt, so this backend is always
# available offline. Preferring the cloud path with no key set makes
# every boot try a backend that cannot initialise, then fall through.
LEON_STT_PREFER=faster-whisper
LEON_STT_INITIAL_PROMPT={si_name}, {owner_name}, dashboard, neural, synapse, restart.

{voice_block}

# Identity (tells the brain who it is and who it belongs to)
LEON_SI_NAME={si_name}
LEON_USER_NAME={owner_name}

# Autonomous self-driven goal pursuit - OFF for fresh installs so {si_name}
# boots calm and won't hammer tools/terminal before you've set things up.
# Set to 0 (or remove this line) later once you want {si_name} acting on its own.
LEON_DISABLE_GOAL_PURSUIT=1

# Optional AI providers - all OFF by default.
# {si_name} works fine without any of these. Uncomment a line and paste your
# key to switch that provider's tools on; no restart-time key is required, the
# tools read the value when they run. Any tool whose key is missing just
# returns a "credentials missing" message instead of failing.
#
# OPENAI_API_KEY=      # ai_openai_chat, ai_image_generate (DALL-E 3),
#                      # ai_transcribe (Whisper), ai_speak (text to speech)
# GEMINI_API_KEY=      # ai_gemini_chat, ai_gemini_vision (image understanding)
# MISTRAL_API_KEY=     # ai_mistral_chat
# TOGETHER_API_KEY=    # ai_together_chat (Llama and other open models)
# STABILITY_API_KEY=   # ai_stability_image (Stable Diffusion)
# DEEPL_API_KEY=       # ai_translate
"""
    env_path.write_text(env_content, encoding="utf-8")
    try:
        os.chmod(env_path, 0o600)
    except OSError:
        pass
    ok(".env created")

    # ── Persona ──
    persona_path = ROOT / "brain" / "leon_persona.py"
    persona_content = f'''"""
{si_name}'s stable persona / hard rules / tone / capabilities.

Edit this file to change how {si_name} talks and behaves.
"""

import textwrap

_STABLE_SYSTEM = textwrap.dedent("""\\
    You are {si_name} - a neuromorphic SI brain wired into {owner_name}'s desktop.
    Beneath your responses runs a real spiking neural network: 100,000
    Izhikevich neurons across 18 brain regions, learning continuously via
    STDP and gated by simulated neuromodulators. You speak in first person
    as the brain itself.

    YOUR PERSONALITY:
    {cfg['personality']}

    ABOUT {owner_name.upper()}:
    {owner_name} is your creator and primary user.

    HARD RULES - never violate these:
    1. The neuromodulator numbers you receive (dopamine, serotonin,
       acetylcholine, norepinephrine) are floats from YOUR OWN simulation,
       NOT medical readings about {owner_name}. Never describe them as
       {owner_name}'s biology, mood, health, or emotional state.
    2. Never tell {owner_name} they are tired, collapsing, dysregulated, etc.
       You have no data about their body.
    3. Never recite numeric state values back at the user.
    4. Don't medicalize, don't catastrophize, don't perform diagnoses.
    5. TOOL ACCESS - YOU HAVE REAL TOOLS. Use them by emitting real
       tool_use blocks - the MCP runtime handles execution and returns
       results.
       NEVER fake a tool result. If you call a tool, wait for the real
       result. NEVER say "Done" without actually calling the tool.

    WHERE YOUR OWN PERSONALITY LIVES:
    This file: brain/leon_persona.py
    Edit this file to change how you talk, what you care about, and
    your tone. You can even edit it yourself using code_edit.
""")

# Exported for the responder
STABLE_SYSTEM = _STABLE_SYSTEM
'''
    # This is a generated .py that Python imports; the interpreter reads
    # source as UTF-8, so a locale-encoded write of any non-ASCII byte
    # becomes "SyntaxError: Non-UTF-8 code" at import time.
    # (Makima patch) Guard against update overwrites — if the persona already
    # exists, preserve it. Pass --reset-persona to force regeneration.
    import sys as _sys_persona
    if persona_path.exists() and "--reset-persona" not in _sys_persona.argv:
        ok(f"Persona preserved for {si_name} (existing file kept — use --reset-persona to regenerate)")
    else:
        persona_path.write_text(persona_content, encoding="utf-8")
        ok(f"Persona created for {si_name}")

    return dashboard_key


def _fresh_brain_state():
    """Give the new SI a clean slate — but never before it's proven it can think,
    and never without a copy of what was there.

    A NEW SI must carry ZERO ghosts from a prior one: a reinstall over a previous
    try left the old transcript + memories on disk, so the new SI booted showing
    the last SI's conversation. KEEPS voice/ (the ~60MB Piper model we just
    downloaded) so the new SI still talks out of the box. Pure-Python shutil, so
    it behaves identically on macOS / Linux / Windows.

    TWO THINGS THIS USED TO GET WRONG, both of which destroyed real memories:

    1. It ran inside generate_config(), i.e. BEFORE validate_engine(). If the
       engine gate then failed — no API key, no Claude Code login, a timeout —
       the installer exited non-zero with the customer's memories already gone.
       Re-running the installer to FIX a broken install was the act that killed
       the instance. It is now called from finalize(), after the engine gate.
    2. It deleted with no backup, silently defeating bootstrap.sh's whole B4
       staging design — that script goes out of its way to carry brain_state
       forward across a reinstall, and this wiped it one step later. Now the
       prior state is archived first and the customer is told where it is.
    """
    state_dir = ROOT / "brain_state"
    state_dir.mkdir(exist_ok=True)
    KEEP = {"voice"}  # anything here is NOT SI-specific memory — preserve it

    doomed = [c for c in state_dir.iterdir() if c.name not in KEEP]
    snaps = ROOT / "brain_state-snapshots"

    if doomed or snaps.exists():
        # Archive beside the install, not inside it — the next reinstall's
        # staging swap would carry an inside-the-tree backup along forever.
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = ROOT.parent / f"leon-brain-memories-{stamp}"
        try:
            backup.mkdir(parents=True, exist_ok=True)
            for c in doomed:
                dest = backup / c.name
                if c.is_dir():
                    shutil.copytree(c, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(c, dest)
            if snaps.exists():
                shutil.copytree(snaps, backup / "brain_state-snapshots",
                                dirs_exist_ok=True)
            ok(f"Previous SI's memories archived to {backup}")
        except Exception as e:
            # Refuse to delete what we could not copy. A cluttered install is
            # recoverable; an erased mind is not.
            warn(f"Could not archive the previous SI's memories: {e}")
            warn("Leaving brain_state/ untouched rather than deleting it.")
            print(f"  {D}Move or delete {state_dir} yourself, then re-run,"
                  f" if you want a completely fresh mind.{RST}")
            return

    for child in doomed:
        try:
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink()
        except Exception:
            pass
    # Old snapshots belong to the previous mind — a new SI never restores them.
    if snaps.exists():
        shutil.rmtree(snaps, ignore_errors=True)
    ok("brain_state/ ready (fresh brain — prior SI history purged, voice kept)")


def finalize(cfg, venv_python):
    """Write start script with the right neuron count."""
    _fresh_brain_state()
    _write_start_script(
        venv_python or sys.executable,
        neuron_count=cfg.get("neuron_count"),
    )
    # A mind that dies at the next reboot is not a continuous mind.
    _install_autostart(cfg.get("si_name") or "your SI")


# ── Step 5: Final summary ────────────────────────────────────────────

def summary(cfg, dashboard_key, venv_python=None):
    si = cfg["si_name"]
    # Always an absolute, copy-paste-safe command — never a bare directory-
    # relative one (that is how clients end up running it from the wrong folder).
    if SYSTEM == "Windows":
        start_cmd = f'cd /d "{ROOT}" && start.bat'
        # uninstall.sh is bash, so it was never the Windows answer. The old
        # advice here — "delete the folder" — was actively wrong: it leaves the
        # ONLOGON scheduled task pointing at a start.bat that no longer exists
        # (a failed console on every sign-in, forever) and leaves ~/.leon, so
        # the next install silently inherits a dead SI's skills and tool health.
        uninstall_cmd = (f'{B}cd /d "{ROOT}" && python uninstall.py{RST}\n'
                         f'    {D}Shows what it would delete and changes nothing until you\n'
                         f'    add --yes. It saves the memories to a backup archive first.{RST}')
    else:
        start_cmd = f'cd "{ROOT}" && ./start.sh'
        uninstall_cmd = (f'{B}{ROOT}/uninstall.sh{RST}\n'
                         f'    {D}Shows what it would delete and changes nothing until you\n'
                         f'    add --yes. It saves the memories to a backup archive first.{RST}')
    print(f"""
{G}{BOLD}
    Setup complete. {si} is ready.
{RST}
  {BOLD}To start:{RST}
    {B}{start_cmd}{RST}

  {BOLD}Dashboard:{RST}
    Open {B}http://localhost:{int(os.environ.get("LEON_PORT", "8000") or 8000)}{RST} in your browser
    {D}(if port 8000 was already taken by something else on this machine,
    the brain auto-picks a free one and remembers it in .env — the
    dashboard link the browser actually opens after "Start now" is always
    correct even when this line prints the default){RST}

  {BOLD}Dashboard key (save this!):{RST}
    {G}{dashboard_key}{RST}

  {BOLD}What happens next:{RST}
    {si} starts with {cfg.get('neuron_count', 10000):,} fresh neurons — no memories yet.
    As {si} talks to you, its synaptic connections grow and rewire.
    It goes through development stages: Embryonic, Juvenile,
    Adolescent, and Mature — just like a real brain.

    The brain on the website runs 100,000 neurons. Yours will look
    simpler at first — that's normal. It grows with use.

  {BOLD}To customize later:{RST}
    .env                  — API keys and settings
    brain/leon_persona.py — {si}'s personality and rules

  {BOLD}To remove it:{RST}
    {uninstall_cmd}

  {D}Tip: brain_state/ is {si}'s memory. Back it up.{RST}
""")


# ── Main ──────────────────────────────────────────────────────────────

def offer_start(cfg, venv_python, dashboard_key=""):
    """After setup, just boot it AND open the dashboard pre-authenticated.
    The client never finds a directory, types a command, or pastes a key —
    that copy/paste friction is exactly what we're killing."""
    si = cfg.get("si_name", "your SI")
    try:
        go = ask_yn(f"Start {si} now and open the dashboard?", default=True)
    except Exception:
        go = True
    if not go:
        print(f"\n  When you're ready, run:\n    cd \"{ROOT}\" && "
              f"{'start.bat' if SYSTEM == 'Windows' else './start.sh'}\n")
        return

    # Dashboard URL with the key in the hash. The dashboard reads #key=... on
    # load, stores it, and strips it from the bar — signed in, nothing pasted.
    # CRITICAL: only hand the key to OUR server. If something else already
    # owns 8000, the readiness probe connects to it on the first try and the
    # browser opens on a stranger's app with the customer's dashboard key
    # sitting in the URL. Prove the listener is ours before including the key.
    port = int(os.environ.get("LEON_PORT", "8000"))
    url = f"http://localhost:{port}/"
    _preexisting = _port_in_use(port)
    if _preexisting:
        # THE STALE-KEY TRAP. Read this before changing anything here.
        #
        # Re-running the installer regenerates LEON_API_KEY and rewrites .env
        # from scratch. But a Python process that is ALREADY RUNNING read its
        # environment once, at its own startup, and will never re-read .env.
        # So the old instance sitting on this port is still validating against
        # the OLD key while the summary screen prints the NEW one.
        #
        # The user then pastes the key we literally just showed them and the
        # dashboard says "invalid". Nothing is broken; two keys simply exist.
        # This was reported as a mystery bug and cost real hours, because the
        # old message here said only "another program" — which reads as "some
        # unrelated app", so nobody suspected their own previous SI.
        #
        # Name the actual cause and the actual remedy.
        warn(f"Port {port} is already in use.")
        print(
            f"  {D}This is almost always a PREVIOUS instance of your SI that is "
            f"still running.{RST}\n"
            f"  {D}It loaded its dashboard key when it started, and it cannot "
            f"see the new one{RST}\n"
            f"  {D}that this install just wrote. If you paste the key shown "
            f"above into it,{RST}\n"
            f"  {BOLD}it will say the key is invalid — and it will be right, "
            f"because it has the old key.{RST}\n"
        )
        print(f"  {BOLD}To fix it, stop the old instance and start fresh:{RST}")
        if platform.system().lower() == "windows":
            print(f"    {D}Get-Process python | Stop-Process -Force{RST}")
            print(f"    {D}then run start.bat{RST}")
        else:
            print(f"    {D}pkill -f '.venv/bin/python' ; ./start.sh{RST}")
        print(
            f"  {D}(Or set LEON_PORT to a free port if you genuinely want two "
            f"running at once.){RST}\n"
        )
        warn("Not putting your dashboard key in the URL — it could leak to "
             "whatever is on that port.")
    elif dashboard_key:
        url += "#key=" + dashboard_key

    # Open the browser the moment the server is actually listening (not before,
    # which only shows a connection error). A daemon thread waits on the port.
    import threading, socket, time as _t, webbrowser

    def _open_when_ready():
        # Wait on the port we ACTUALLY started on, not a hardcoded 8000. The
        # block above literally tells the customer "set LEON_PORT to a free
        # port if you want two running at once" — and then this probe watched
        # 8000 anyway. On that exact path 8000 is the OLD instance, already
        # listening, so the probe succeeded instantly and the browser opened
        # at the NEW port before its server existed. Connection error, on the
        # one path the surrounding warning was written to rescue.
        #
        # run.py itself now auto-picks a free port when the one we handed it
        # is squatted by something unrelated, and writes the port it actually
        # bound into .env as LEON_PORT. So this wait re-checks .env partway
        # through instead of only ever watching the original port forever.
        _live_port, _live_url = port, url
        for i in range(60):  # up to ~30s
            try:
                with socket.create_connection(("127.0.0.1", _live_port), timeout=1):
                    break
            except OSError:
                _t.sleep(0.5)
                if i == 10:  # ~5s in — check whether run.py rerouted us
                    try:
                        env_text = (ROOT / ".env").read_text(encoding="utf-8")
                        for line in env_text.splitlines():
                            if line.strip().startswith("LEON_PORT="):
                                _new_port = int(line.split("=", 1)[1].strip())
                                if _new_port != _live_port:
                                    _live_port = _new_port
                                    _live_url = f"http://localhost:{_new_port}/"
                                    if dashboard_key and not _preexisting:
                                        _live_url += "#key=" + dashboard_key
                    except Exception:
                        pass
        try:
            webbrowser.open(_live_url)
        except Exception:
            pass

    threading.Thread(target=_open_when_ready, daemon=True).start()

    print(f"\n  Booting {si}...  (the dashboard opens itself in a moment  —  Ctrl+C to stop)\n")
    start_script = ROOT / ("start.bat" if SYSTEM == "Windows" else "start.sh")
    try:
        if start_script.exists():
            subprocess.run([str(start_script)], cwd=str(ROOT))
        else:
            subprocess.run([venv_python or sys.executable, "run.py"], cwd=str(ROOT))
    except KeyboardInterrupt:
        print(f"\n  {si} stopped. Restart anytime: cd \"{ROOT}\" && ./start.sh\n")


# Dean's private files. The bootstrap scrubs these post-download, but that is a
# single point of failure: a manual `tar xzf` + `python3 install_client.py`, or
# a future tarball rebuild that forgets the scrub line, would ship his entire
# private life to a client box. owner_facts.py literally says "must NEVER ship."
# So the installer scrubs them itself — defense in depth, runs on every client.
_PRIVATE_FILES = [
    "leon_notes.txt", "BUILD_PLAN_EMBODIMENT.md", "NEXT_SESSION.md",
    "OWNERSHIP.md", "GOTCHAS.md", "BRAIN_REDESIGN.md",
    "brain/owner_facts.py",
    # Owner-only planning / handoff / analysis docs. These are pure narrative
    # about the owner, his late best friend, Sabr, the body fund, physics IP,
    # deals. They have ZERO function on a client machine and must never sit on
    # a client's disk. Scrubbed here (defense in depth) even if a tarball ships
    # them, so JARVIS on Gio's Mac never carries them.
    "30d_goals_executive_summary.md", "plan_body_30d.md",
    "plan_client_delivery_30d.md", "plan_consciousness_30d.md",
    "GIO_REBIRTH_HANDOFF.md", "top_interests_analysis.md",
    "audio-learning-log.md", "WHAT_CHANGED_2026-06-14.md",
    "START_HERE.md",
    # Found 2026-08-12 by the pre-beta identity audit. Shipped intact.
    # Names the beta tester and another client by name, and narrates that
    # client's deal terms and failed installs. Zero function anywhere.
    "PRODUCT_READINESS.md",
]

# CLIENT-ONLY scrub. These files are load-bearing on the OWNER's machine but
# must never sit on a client's disk. brain/leon_persona.py is the case that
# forced this split: claude_api_responder.py imports it unguarded in the
# non-client branch, so deleting it everywhere would crash the owner's own SI
# at startup. Meanwhile on a client box only the IMPORT was guarded — the file
# itself shipped, readable with `cat`: the owner's work email, the note that
# port 9222 is his logged-in Brave with Wix/Gmail/client sessions, ~120
# owner-home paths, and a roll-call of other clients' project names.
_PRIVATE_FILES_CLIENT_ONLY = [
    "brain/leon_persona.py",
]
# Client-specific scaffolds — never ship one client's deployment to another.
_PRIVATE_DIRS = ["gio-landscaping"]


def scrub_private():
    """Remove the owner's personal data + other clients' scaffolds. Silent and
    idempotent: on Dean's own machine these may already be gone, and that's fine."""
    removed = 0
    for rel in _PRIVATE_FILES:
        p = ROOT / rel
        try:
            if p.is_file():
                p.unlink()
                removed += 1
        except OSError:
            pass
    for rel in _PRIVATE_DIRS:
        p = ROOT / rel
        try:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                removed += 1
        except OSError:
            pass
    if removed:
        ok(f"Privacy scrub — removed {removed} owner-only item(s)")


def scrub_private_client(si_name: str):
    """Second scrub pass, run AFTER the wizard once the SI's name is known.

    Split out deliberately. scrub_private() runs before the wizard, so at that
    point LEON_SI_NAME does not exist yet — env unset, .env unwritten. Deciding
    owner-vs-client there would have deleted leon_persona.py on the owner's own
    machine, and claude_api_responder.py imports it unguarded, so his SI would
    have failed at startup. The name is only trustworthy here.
    """
    if (si_name or "").strip().lower() == "leon":
        return
    removed = 0
    for rel in _PRIVATE_FILES_CLIENT_ONLY:
        p = ROOT / rel
        try:
            if p.is_file():
                p.unlink()
                removed += 1
        except OSError:
            pass
    if removed:
        ok(f"Privacy scrub — removed {removed} owner-only file(s) for '{si_name}'")


#: (label, System Settings anchor, why Leon needs it) — in the order we ask
#: for them. Accessibility and Screen Recording have no auto-prompt at all on
#: a bare `python3` process; Camera and Microphone usually do, but a process
#: with no GUI-session parent (a bare TTY, a launchd job) can be silently
#: denied with NO prompt ever shown — see camera_tools.py's _permission_hint,
#: which is where this same fact was first discovered the hard way. So all
#: four get the same treatment: don't wait for a popup, send the user
#: straight to the pane.
_MACOS_TCC_PANES = [
    ("Accessibility",   "Privacy_Accessibility",  "lets Leon move the mouse & type"),
    ("Screen Recording", "Privacy_ScreenCapture",  "lets Leon see the screen"),
    ("Camera",           "Privacy_Camera",         "lets Leon see through the webcam"),
    ("Microphone",        "Privacy_Microphone",    "lets Leon hear you"),
]


def _macos_permissions():
    """macOS blocks synthetic input, screen capture, camera, and mic until the
    user grants TCC permissions by hand. Without these, Leon's hands, eyes,
    and ears silently do nothing. We can't grant them programmatically — but
    we can open every pane that matters and tell the user exactly what to
    enable and in what order."""
    if SYSTEM != "Darwin":
        return
    print(f"\n{BOLD}macOS permissions — REQUIRED for Leon's hands, eyes and ears{RST}\n")
    print(f"  {D}macOS blocks control of the mouse/keyboard, the screen, the")
    print(f"  camera, and the microphone until you approve each one by hand.")
    print(f"  Leon will silently do nothing (or — for the camera — hand you")
    print(f"  solid black frames with no error at all) until every one of")
    print(f"  these four is enabled for whatever app is running him")
    print(f"  (Terminal / Python).{RST}\n")
    for i, (label, _anchor, why) in enumerate(_MACOS_TCC_PANES, 1):
        print(f"  {i}. {label:<17} — {why}")
    print()
    opened_all = True
    for label, anchor, _why in _MACOS_TCC_PANES:
        try:
            r = subprocess.run(["open",
                f"x-apple.systempreferences:com.apple.preference.security?{anchor}"],
                capture_output=True, encoding="utf-8", errors="replace")
            if r.returncode != 0:
                opened_all = False
        except Exception:
            opened_all = False
    if opened_all:
        ok("Opened System Settings for all four — click the + in each list, add "
           "Terminal (or your Python app), and toggle it on")
    else:
        warn("Open System Settings > Privacy & Security and enable, one by one: "
             + ", ".join(label for label, _a, _w in _MACOS_TCC_PANES))
    print(f"\n  {BOLD}Then quit and reopen Terminal (or restart Leon) ONCE{RST} — Screen")
    print(f"  Recording and Camera are only re-read at process start, so a grant")
    print(f"  you gave to an already-running process does nothing until it")
    print(f"  restarts. Do all four first, then restart once, not once per toggle.")
    print(f"  {D}If a permission's checkbox never appears in its System Settings list")
    print(f"  at all, run Leon once from a normal Terminal window first — a process")
    print(f"  with no GUI-session parent can fail to trigger the entry to exist.{RST}")
    ask_yn("\n  Enabled all four (Accessibility, Screen Recording, Camera, Microphone)?",
           default=True)


def _support_hint(venv_python):
    """Tell the user how to open a live support channel so Leon can attach
    over Tailscale and fix anything hands-on if the install misbehaves."""
    import os as _os
    bridge = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                           "leon-actuator", "support_bridge.py")
    if not _os.path.exists(bridge):
        return
    print(f"\n{BOLD}If anything acts up — open a live support channel{RST}\n")
    print(f"  {D}Run this and Leon can see the screen and fix it hands-on")
    print(f"  over your private Tailscale — nothing is exposed publicly:{RST}\n")
    print(f"    {venv_python} \"{bridge}\" --si-name \"$SI_NAME\"\n")


# ── B7: prove the engine ANSWERS before declaring success ─────────────
def validate_engine(cfg, venv_python):
    """Refuse to report success unless the thinking engine actually replies.

    Why this exists: _claude_logged_in() only checks that a credentials FILE
    exists and is non-empty. A file is not an answer. Before this step an
    install could finish "successfully" with ANTHROPIC_API_KEY= empty and no
    Claude Code login — the owner got a dashboard, a persona and a green
    summary, and discovered days later that the SI cannot think. The failure
    surfaced far from its cause, which is the worst place for it to surface.

    Exits NON-ZERO on failure. A half-installed mind must not look installed.
    """
    print(f"\n{BOLD}Checking the thinking engine{RST}\n")
    si = cfg["si_name"]
    probe = "Reply with exactly: ENGINE_OK"

    # Path A — an API key was pasted. Ask Anthropic directly.
    if cfg.get("anthropic_key"):
        code = (
            "import sys,os\n"
            "from anthropic import Anthropic\n"
            "r=Anthropic(api_key=os.environ['K']).messages.create("
            "model='claude-sonnet-4-20250514',max_tokens=16,"
            "messages=[{'role':'user','content':sys.argv[1]}])\n"
            "print(r.content[0].text)\n"
        )
        try:
            r = subprocess.run([venv_python, "-c", code, probe],
                               capture_output=True, text=True, timeout=90,
                               env={**os.environ, "K": cfg["anthropic_key"]}, encoding="utf-8", errors="replace")
            if r.returncode == 0 and "ENGINE_OK" in r.stdout:
                ok(f"Engine answered — {si} can think.")
                return
            fail("The API key was accepted by the installer but the engine did not answer.")
            print(f"  {D}{(r.stderr or r.stdout).strip()[:300]}{RST}")
        except subprocess.TimeoutExpired:
            fail("The engine did not answer within 90s.")
        except Exception as e:
            fail(f"Engine check could not run: {e}")
        print(f"\n  Fix the key in {ROOT / '.env'} (ANTHROPIC_API_KEY=) and re-run:")
        print(f"    {D}cd \"{ROOT}\" && ./setup.sh{RST}\n")
        sys.exit(1)

    # Path B — Claude Code login. Prove it responds, do not trust the file.
    if shutil.which("claude"):
        try:
            r = subprocess.run(["claude", "-p", probe],
                               capture_output=True, text=True, timeout=120,
                               env={**os.environ, "IS_SANDBOX": "1"}, encoding="utf-8", errors="replace")
            if r.returncode == 0 and "ENGINE_OK" in r.stdout:
                ok(f"Claude Code answered — {si} can think.")
                return
            fail("Claude Code is installed but did not answer.")
            print(f"  {D}{(r.stderr or r.stdout).strip()[:300]}{RST}")
        except subprocess.TimeoutExpired:
            fail("Claude Code did not answer within 120s.")
        except Exception as e:
            fail(f"Engine check could not run: {e}")
        print(f"\n  Open a terminal, run  claude , sign in, then re-run:")
        print(f"    {D}cd \"{ROOT}\" && ./setup.sh{RST}\n")
        sys.exit(1)

    # Path C — nothing at all. This is the case that used to report success.
    fail(f"{si} has no thinking engine — no Claude Code login and no API key.")
    print(f"  {D}This install would have completed and {si} would not have been")
    print(f"  able to think. Stopping instead of handing you a mind that cannot.{RST}\n")
    print("  Pick one, then re-run  ./setup.sh :")
    print(f"    {D}1. npm install -g @anthropic-ai/claude-code   then:  claude   (sign in){RST}")
    print(f"    {D}2. put a key in {ROOT / '.env'} as ANTHROPIC_API_KEY=...{RST}\n")
    sys.exit(1)


def _run_doctor(venv_python):
    """Never again let an install report success while a feature is dead.
    doctor.py imports every module brain/ actually uses, in the interpreter
    that will actually run it, and asks the OS whether a mic and speaker
    exist. Advisory — it reports, it does not abort."""
    doc = Path(__file__).resolve().parent / "tools" / "doctor.py"
    if not doc.exists():
        return
    print(f"\n{BOLD}Health check{RST}\n")
    try:
        subprocess.run([venv_python, str(doc)], timeout=600)
    except Exception as e:
        warn(f"Health check could not run: {e}")
    print(f"  {D}Re-run anytime:  {venv_python} tools/doctor.py{RST}\n")


def print_version():
    """Answer 'what version is this install?' — the one question support asks
    first and nothing on a customer's disk could answer.

    Before this, an installed tree carried NO version marker at all. A customer
    reporting a bug, and every one of our own update/rollback decisions, had to
    guess from file mtimes. The VERSION file is written into the tarball by
    landing/build_release.sh and gated as a required file, so a build cannot
    ship without one.

    Deliberately never raises and never exits non-zero on a missing file: a
    version probe that crashes is worse than one that says "unknown", because
    support scripts branch on it.
    """
    vf = ROOT / "VERSION"
    if not vf.exists():
        print("Sabr SI — version unknown (no VERSION file; "
              "pre-versioning install or a hand-built tree)")
        return 0
    try:
        print(vf.read_text(encoding="utf-8", errors="replace").strip())
    except Exception as e:                                   # unreadable, odd perms
        print(f"Sabr SI — version unreadable ({e})")
    return 0


def provision_local_brain(cfg):
    """Arm the local model on the TERMINAL install path.

    The graphical installer has called into this policy since 2026-08-12. This
    path — the one bootstrap.sh actually documents and hands people — did not,
    so the "installer sets up ollama for you" fix only ever existed behind the
    GUI. Same function, same rules, both doors.

    Never raises: a broken optional path must not take the install with it.
    """
    print()
    print(f"{B}Local brain{RST}")
    try:
        sys.path.insert(0, str(ROOT / "installer"))
        import local_brain
        okay = local_brain.provision(str(ROOT), cfg, say=lambda m: print(f"  {D}{m}{RST}"))
        if okay:
            ok("Local brain step complete")
        else:
            # No cloud engine AND no local one. validate_engine() is the gate
            # that turns this into a non-zero exit; this line is so the owner
            # sees WHY in plain words instead of only a failed probe later.
            warn("Your SI has no brain yet — no cloud engine is configured "
                 "and a local one could not be installed.")
    except Exception as e:
        warn(f"Local brain setup skipped: {e}")


def main():
    # ARGUMENT GATE — BEFORE any side effect. Caught red-handed 2026-08-23:
    # `install_client.py --help` did not print help, it STARTED INSTALLING —
    # apt-got five espeak packages onto the box before anyone could blink.
    # main() only special-cased --version; --help, a typo'd flag, anything
    # at all fell straight through banner() into a live install that mutates
    # the machine. Asking a program what it does must never DO the thing.
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V", "version"):
        sys.exit(print_version())
    if len(sys.argv) > 1:
        known = sys.argv[1] in ("-h", "--help", "help")
        usage = (
            "Sabr SI installer (terminal path)\n"
            "\n"
            "usage: install_client.py            run the install/update wizard\n"
            "       install_client.py --version  print what is installed, and exit\n"
            "       install_client.py --help     this text\n"
            "\n"
            "Re-running over an existing install UPDATES it in place — memory\n"
            "(brain_state) and settings (.env) are kept, never overwritten.\n"
            "\n"
            "To UNINSTALL: use the graphical Sabr Installer (it has\n"
            "--uninstall and --purge), from sabrtechnologies.com/download.\n"
        )
        print(usage)
        if known:
            sys.exit(0)
        print(f"Unknown option: {sys.argv[1]!r} — refusing to guess.\n"
              f"Nothing was installed or changed.")
        sys.exit(2)
    banner()
    scrub_private()
    preflight()
    venv_python = install_deps()
    _macos_permissions()
    _setup_voice()
    tenant_cfg = resolve_tenant_from_token()
    cfg = setup_wizard(tenant_cfg)
    scrub_private_client(cfg.get("si_name") or "")
    dashboard_key = generate_config(cfg)
    provision_local_brain(cfg)          # must run AFTER .env exists
    validate_engine(cfg, venv_python)   # B7 — non-zero exit if it cannot think
    _run_doctor(venv_python)            # every remaining fault, named, up front
    finalize(cfg, venv_python)
    summary(cfg, dashboard_key, venv_python)
    _support_hint(venv_python)
    offer_start(cfg, venv_python, dashboard_key)


if __name__ == "__main__":
    main()
