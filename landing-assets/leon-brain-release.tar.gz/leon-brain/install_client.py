#!/usr/bin/env python3
"""
Sabr SI — Client Installer
One script. Run it, answer 4 questions, your SI is alive.

Usage:
    python3 install_client.py

Works on Linux, macOS, and Windows.
"""

import datetime as _dt
import getpass
import hashlib
import json
import os
import platform
import secrets
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path

SYSTEM = platform.system()
# B11: ONE floor across both installers. 3.11 is set by numpy (>=3.11)
# and scipy (>=3.11), read from installed dist metadata — not a guess.
MIN_PYTHON = (3, 11)
ROOT = Path(__file__).resolve().parent

# ANSI colors (disabled on Windows cmd)
if SYSTEM == "Windows" and not os.environ.get("WT_SESSION"):
    G, Y, R, B, D, BOLD, RST = "", "", "", "", "", "", ""
else:
    G = "\033[92m"
    Y = "\033[93m"
    R = "\033[91m"
    B = "\033[94m"
    D = "\033[2m"
    BOLD = "\033[1m"
    RST = "\033[0m"


def banner():
    print(f"""
{B}{BOLD}    ╔══════════════════════════════════════╗
    ║        SABR — SI Installation        ║
    ║    Synthetic Intelligence Platform   ║
    ╚══════════════════════════════════════╝{RST}
    """)


def ok(msg):
    print(f"  {G}[OK]{RST} {msg}")


def warn(msg):
    print(f"  {Y}[!!]{RST} {msg}")


def fail(msg):
    print(f"  {R}[FAIL]{RST} {msg}")


def _tty_input(prompt):
    """input() that still works when stdin is piped (curl | bash) by
    falling back to the controlling terminal at /dev/tty."""
    try:
        if sys.stdin and sys.stdin.isatty():
            return input(prompt)
    except Exception:
        pass
    try:
        with open("/dev/tty", "r") as tty:
            sys.stdout.write(prompt)
            sys.stdout.flush()
            line = tty.readline()
            if line == "":
                raise EOFError
            return line.rstrip("\n")
    except (FileNotFoundError, OSError):
        return input(prompt)


def ask(prompt, default=None, required=True):
    suffix = f" {D}[{default}]{RST}" if default else ""
    while True:
        try:
            val = _tty_input(f"  {prompt}{suffix}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n\n  Setup cancelled.")
            sys.exit(1)
        if val:
            return val
        if default is not None:
            return default
        if not required:
            return ""
        print(f"  {R}Required.{RST}")


def ask_secret(prompt, required=False):
    """Ask for a secret (API key). Shows input normally for compatibility."""
    suffix = f" {D}(paste your key){RST}" if required else f" {D}(paste or press Enter to skip){RST}"
    try:
        val = _tty_input(f"  {prompt}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n\n  Setup cancelled.")
        sys.exit(1)
    return val


def ask_yn(prompt, default=True):
    suffix = "[Y/n]" if default else "[y/N]"
    try:
        val = _tty_input(f"  {prompt} {suffix}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return default
    if not val:
        return default
    return val in ("y", "yes")


# ── Step 1: Preflight ────────────────────────────────────────────────

def preflight():
    print(f"{BOLD}Preflight checks{RST}\n")

    # Python version
    v = sys.version_info
    if (v.major, v.minor) < MIN_PYTHON:
        fail(f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required (you have {v.major}.{v.minor})")
        print(f"     Download: https://python.org/downloads/")
        sys.exit(1)
    ok(f"Python {v.major}.{v.minor}.{v.micro}")

    # Platform
    ok(f"{SYSTEM} ({platform.machine()})")

    # System deps — tmux is REQUIRED (Launch Session spawns a tmux window).
    # xdotool/wmctrl drive window control on Linux. Try to install what's missing.
    _ensure_system_deps()

    print()


def _ensure_system_deps():
    """Make sure native tools the SI needs are present. tmux is non-negotiable —
    the dashboard's Launch Session button spawns a tmux window and silently
    dead-ends without it. Best-effort install across package managers; never
    aborts the install if it can't (the user can install manually)."""
    if SYSTEM == "Windows":
        # tmux lives inside WSL on Windows; nothing to do from here.
        if not shutil.which("tmux"):
            warn("tmux not found — Launch Session needs it. Inside WSL: sudo apt install tmux")
        return

    # tmux required everywhere; audio + window tools on Linux.
    needed = ["tmux", "ffmpeg"]
    if SYSTEM == "Linux":
        needed += ["xdotool", "wmctrl", "espeak-ng"]
    elif SYSTEM == "Darwin":
        # cliclick = Leon's mouse/keyboard on macOS (pyautogui is the fallback)
        needed += ["cliclick"]

    missing = [t for t in needed if not shutil.which(t)]
    for t in [t for t in needed if t not in missing]:
        ok(f"{t} found")
    if not missing:
        return

    print(f"  {D}Installing system tools: {', '.join(missing)}...{RST}")

    if SYSTEM == "Darwin":
        if shutil.which("brew"):
            mgr = ["brew", "install"]
        else:
            warn(f"Homebrew not found — install manually: brew install {' '.join(missing)}")
            return
    else:  # Linux — detect the package manager
        if shutil.which("apt-get"):
            mgr = ["sudo", "apt-get", "install", "-y"]
            # NOT capture_output: sudo writes its password prompt to stderr.
            # Piping it made the installer hang on a blank screen forever with
            # no cursor and no explanation. Let the prompt reach the terminal.
            subprocess.run(["sudo", "apt-get", "update", "-qq"])
        elif shutil.which("dnf"):
            mgr = ["sudo", "dnf", "install", "-y"]
        elif shutil.which("pacman"):
            mgr = ["sudo", "pacman", "-S", "--noconfirm"]
        elif shutil.which("zypper"):
            mgr = ["sudo", "zypper", "install", "-y"]
        else:
            warn(f"No known package manager — install manually: {', '.join(missing)}")
            return

    try:
        # Same reason as above — the customer must be able to SEE the sudo
        # prompt and type into it. Visible output beats a silent freeze.
        result = subprocess.run(mgr + missing, text=True)
        still_missing = [t for t in missing if not shutil.which(t)]
        if not still_missing:
            ok(f"Installed: {', '.join(missing)}")
        else:
            # result.stderr is None now that output goes to the terminal —
            # the customer already saw the real error scroll past.
            warn(f"Couldn't auto-install: {', '.join(still_missing)} — "
                 f"install manually then re-run. (exit {result.returncode})")
            if "tmux" in still_missing:
                warn("tmux is REQUIRED — Launch Session won't work until it's installed.")
    except Exception as e:
        warn(f"System dep install failed: {e}")


# ── Step 2: Virtual environment + dependencies ──────────────────────


def _port_in_use(port: int) -> bool:
    """True if something is already listening on the port. Used to avoid
    handing the dashboard key to an unrelated app that squatted on 8000."""
    import socket as _s
    try:
        with _s.create_connection(("127.0.0.1", port), timeout=0.5):
            return True
    except OSError:
        return False

def _in_venv() -> bool:
    return sys.prefix != sys.base_prefix


def _ensure_venv():
    """Create and activate a venv if we're not already in one.

    Modern Linux (Ubuntu 24+, Mint 22+, 47 OS) blocks system-wide pip
    installs (PEP 668 / EXTERNALLY-MANAGED). A venv is the clean fix.
    macOS and Windows don't enforce this, but a venv is still better.
    """
    if _in_venv():
        ok(f"Already in a virtual environment")
        return sys.executable

    venv_dir = ROOT / ".venv"
    # Was: venv_dir / ("Scripts" / "python.exe" if ... else "bin" / "python3")
    # str / str is not a path join — BOTH branches raised TypeError, so this
    # line crashed every install that needed a venv. That is 100% of Windows
    # (there is no bash bootstrap there) and any Linux box that fell back to
    # system Python. Join through Path, one component at a time.
    if SYSTEM == "Windows":
        python_bin = venv_dir / "Scripts" / "python.exe"
    else:
        python_bin = venv_dir / "bin" / "python3"

    if python_bin.exists():
        ok(f"Virtual environment exists at .venv/")
        return str(python_bin)

    print(f"  Creating virtual environment (.venv/)...")
    try:
        import venv
        venv.create(str(venv_dir), with_pip=True)
        ok("Virtual environment created")
        return str(python_bin)
    except Exception as e:
        # Some Linux distros need python3-venv installed
        warn(f"venv creation failed: {e}")
        print(f"  {D}Try: sudo apt install python3-venv{RST}")
        # Fall back to --break-system-packages
        warn("Falling back to system-wide install")
        return sys.executable


def install_deps():
    print(f"{BOLD}Setting up environment{RST}\n")

    venv_python = _ensure_venv()
    is_venv = venv_python != sys.executable

    print(f"\n  {D}Installing packages (usually 1-2 minutes)...{RST}\n")

    # Core deps only — no ML models, no dev tools, no VPS packages
    deps = [
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "fastapi>=0.100.0",
        "uvicorn[standard]>=0.22.0",
        "websockets>=11.0",
        "python-multipart>=0.0.6",
        "python-dotenv>=1.0.0",
        "Pillow>=10.0.0",
        "mss>=9.0.0",
        "psutil>=5.9.0",
        "anthropic>=0.30.0",
        "piper-tts>=1.2.0",
        "onnxruntime>=1.16.0",
        "pyttsx3>=2.90",
    ]

    # Platform-specific
    if SYSTEM == "Windows":
        deps.extend(["pygetwindow", "pywinauto", "pyperclip", "screeninfo"])
    elif SYSTEM == "Darwin":
        deps.extend(["pyobjc-framework-ApplicationServices", "pyobjc-framework-Quartz",
                     "pyautogui", "pyperclip", "screeninfo"])
    else:
        deps.extend(["pyperclip", "screeninfo"])

    cmd = [venv_python, "-m", "pip", "install", "--quiet"] + deps
    # If not in venv and venv failed, try --break-system-packages
    if not is_venv and not _in_venv():
        cmd.insert(4, "--break-system-packages")

    result = subprocess.run(cmd, capture_output=False)

    if result.returncode != 0:
        warn("Some packages may have issues — continuing anyway")
    else:
        ok("All dependencies installed")

    print()
    return venv_python


def _write_start_script(venv_python, neuron_count=None):
    """Write a start script that activates the venv and runs the brain."""
    neurons_flag = f" --neurons {neuron_count}" if neuron_count else ""
    if SYSTEM == "Windows":
        start = ROOT / "start.bat"
        # venv_python is a path under the user's profile — Path.write_text()
        # with no encoding= falls back to the OS locale's preferred encoding,
        # which on Windows is a narrow codepage (cp1252 etc.), not UTF-8. Any
        # non-ASCII Windows username (accented Latin, Cyrillic, CJK) then
        # raises UnicodeEncodeError here and the install dies silently — the
        # exact bug that hit Ethan, at the exact same place in the flow.
        start.write_text(
            f'@echo off\ncd /d "%~dp0"\n"{venv_python}" run.py{neurons_flag} %*\n',
            encoding="utf-8")
        ok(f"Created start.bat")
    else:
        start = ROOT / "start.sh"
        start.write_text(
            f'#!/bin/bash\ncd "$(dirname "$0")"\nexec "{venv_python}" run.py{neurons_flag} "$@"\n',
            encoding="utf-8")
        os.chmod(start, 0o755)
        ok(f"Created start.sh")


# ── Boot persistence ─────────────────────────────────────────────────
# An SI is sold as a CONTINUOUS mind. Before this, the installer wrote a
# start script and stopped: the customer's SI died at the next reboot and
# only came back if they remembered to hand-run start.sh / start.bat from
# the right folder. Nothing in the installer registered it with systemd,
# launchd or Task Scheduler on ANY platform — the product's core promise
# silently ended at the first power cycle. All three paths below are
# user-level (no admin/sudo prompt) and every failure is non-fatal: boot
# persistence is a bonus, never a reason an install dies.

AUTOSTART_LABEL = "com.sabr.si"
AUTOSTART_TASK = "Sabr SI"


def _install_autostart(si_name="your SI"):
    """Register the SI to start itself at login/boot. Never fatal."""
    try:
        if SYSTEM == "Windows":
            return _autostart_windows(si_name)
        if SYSTEM == "Darwin":
            return _autostart_macos(si_name)
        return _autostart_linux(si_name)
    except Exception as e:
        warn(f"Could not set up auto-start: {e}")
        print(f"  {D}Not fatal — {si_name} still starts with the start script.{RST}")
        return False


def _autostart_linux(si_name):
    if not shutil.which("systemctl"):
        warn("No systemd on this machine, so auto-start was skipped.")
        print(f"  {D}Start {si_name} manually with ./start.sh, or add it to your\n"
              f"  desktop's Startup Applications.{RST}")
        return False
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit = unit_dir / "sabr-si.service"
    unit.write_text(
        "[Unit]\n"
        f"Description=Sabr SI ({si_name})\n"
        "After=network-online.target\n\n"
        "[Service]\n"
        "Type=simple\n"
        f'WorkingDirectory={ROOT}\n'
        f'ExecStart={ROOT / "start.sh"}\n'
        # Restart=always, NOT on-failure. on-failure ignores a clean exit(0) —
        # so anything that stops the SI politely (an updater mid-swap, a stray
        # sys.exit, a supervisor hiccup) leaves the customer's SI dead until
        # they happen to notice. Dean's own PC services have used always for
        # months without a restart storm; matched here 2026-08-10.
        "Restart=always\n"
        "RestartSec=10\n\n"
        "[Install]\n"
        "WantedBy=default.target\n",
        encoding="utf-8")
    subprocess.run(["systemctl", "--user", "daemon-reload"],
                   capture_output=True, timeout=30)
    r = subprocess.run(["systemctl", "--user", "enable", "sabr-si.service"],
                       capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        warn(f"Auto-start unit written but not enabled: {r.stderr.strip()[:160]}")
        return False
    # Without lingering, a --user unit only runs while someone is logged in —
    # so a headless box reboots and the SI never wakes. Try to enable it; it
    # needs root, so a failure here is expected and only downgrades behaviour
    # from "starts at boot" to "starts at login".
    # loginctl ships with systemd-logind, which is NOT guaranteed just because
    # systemctl exists (minimal images, WSL without logind). Calling it blind
    # raised FileNotFoundError, the outer handler caught it, and the customer
    # was told "Could not set up auto-start" on a machine where the unit had
    # ALREADY been written and enabled. Working install, false failure message.
    if shutil.which("loginctl"):
        linger = subprocess.run(["loginctl", "enable-linger", getpass.getuser()],
                                capture_output=True, text=True, timeout=30)
        linger_rc = linger.returncode
    else:
        linger_rc = 1
    ok(f"{si_name} will start automatically "
       + ("at boot" if linger_rc == 0 else "when you log in"))
    if linger_rc != 0:
        print(f"  {D}For start-at-boot without logging in, run once:\n"
              f"    sudo loginctl enable-linger {getpass.getuser()}{RST}")
    return True


def _autostart_macos(si_name):
    agents = Path.home() / "Library" / "LaunchAgents"
    agents.mkdir(parents=True, exist_ok=True)
    plist = agents / f"{AUTOSTART_LABEL}.plist"
    logs = ROOT / "brain_state" / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    plist.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n<dict>\n'
        f'  <key>Label</key><string>{AUTOSTART_LABEL}</string>\n'
        '  <key>ProgramArguments</key>\n  <array>\n'
        '    <string>/bin/bash</string>\n'
        f'    <string>{ROOT / "start.sh"}</string>\n'
        '  </array>\n'
        f'  <key>WorkingDirectory</key><string>{ROOT}</string>\n'
        '  <key>RunAtLoad</key><true/>\n'
        # Plain KeepAlive, NOT the SuccessfulExit=false dict. That dict is the
        # exact macOS twin of systemd's Restart=on-failure: it tells launchd to
        # leave the SI dead after any clean exit(0). Same hole, same fix, so
        # both platforms behave identically. Fixed 2026-08-10 alongside Linux.
        '  <key>KeepAlive</key><true/>\n'
        f'  <key>StandardOutPath</key><string>{logs / "autostart.log"}</string>\n'
        f'  <key>StandardErrorPath</key><string>{logs / "autostart.err"}</string>\n'
        '</dict>\n</plist>\n',
        encoding="utf-8")
    # bootout/unload first so a reinstall replaces the old definition instead
    # of launchd holding the stale one until the next reboot.
    subprocess.run(["launchctl", "unload", str(plist)],
                   capture_output=True, timeout=30)
    r = subprocess.run(["launchctl", "load", "-w", str(plist)],
                       capture_output=True, text=True, timeout=30)
    if r.returncode != 0:
        warn(f"Auto-start file written but launchctl refused it: "
             f"{(r.stderr or r.stdout).strip()[:160]}")
        return False
    ok(f"{si_name} will start automatically when you log in")
    return True


def _autostart_windows(si_name):
    start_bat = ROOT / "start.bat"
    # ONLOGON with no /RL HIGHEST deliberately: HIGHEST needs an elevated
    # console to register and would make the whole install require admin.
    r = subprocess.run(
        ["schtasks", "/create", "/tn", AUTOSTART_TASK,
         "/tr", f'"{start_bat}"', "/sc", "ONLOGON", "/f"],
        capture_output=True, text=True, timeout=60)
    if r.returncode == 0:
        ok(f"{si_name} will start automatically when you sign in")
        return True
    # Locked-down machines (group policy, some Home SKUs) refuse schtasks.
    # The Startup folder needs no privileges at all and always works.
    startup = (Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
               / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
    try:
        startup.mkdir(parents=True, exist_ok=True)
        (startup / "Sabr SI.bat").write_text(
            f'@echo off\nstart "" /min "{start_bat}"\n', encoding="utf-8")
        ok(f"{si_name} will start automatically when you sign in")
        return True
    except Exception as e:
        warn(f"Could not set up auto-start: {e}")
        print(f"  {D}Not fatal — start {si_name} with start.bat.{RST}")
        return False


# ── Voice model setup ────────────────────────────────────────────────

PIPER_MODEL_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_GB/alan/medium/en_GB-alan-medium.onnx"
PIPER_CONFIG_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/en/en_GB/alan/medium/en_GB-alan-medium.onnx.json"
# Pinned from the upstream object itself: HuggingFace's x-linked-etag for this
# exact URL is the file's sha256, and it matches the known-good copy byte for
# byte. Size is a cheap pre-check so we don't hash 60MB to reject an obvious
# truncation.
PIPER_MODEL_SHA256 = "0a309668932205e762801f1efc2736cd4b0120329622adf62be09e56339d3330"
PIPER_MODEL_BYTES = 63201294


def _voice_model_is_intact(path):
    """True only if this is the whole, unmodified Piper model."""
    try:
        if not path.exists() or path.stat().st_size != PIPER_MODEL_BYTES:
            return False
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest() == PIPER_MODEL_SHA256
    except Exception:
        return False


def _setup_voice():
    """Download the free Piper voice model so the SI can talk out of the box."""
    print(f"{BOLD}Setting up voice{RST}\n")

    voice_dir = ROOT / "brain_state" / "voice" / "piper"
    voice_dir.mkdir(parents=True, exist_ok=True)
    model_path = voice_dir / "en_GB-alan-medium.onnx"
    config_path = voice_dir / "en_GB-alan-medium.onnx.json"

    # "Bigger than 1MB" was the entire completeness check, and that is how the
    # SI ended up permanently voice-broken with no error anywhere: a connection
    # dropped partway through the 60MB model leaves a truncated file that is
    # still comfortably over 1MB, so EVERY later run said "already downloaded"
    # and skipped it forever. Piper then chokes on a half-parsed ONNX and the
    # owner just knows their SI sounds wrong. Verified by content now.
    if _voice_model_is_intact(model_path) and config_path.exists():
        ok("Piper voice model already downloaded")
        print()
        return

    print(f"  {D}Downloading voice model (~60MB)...{RST}")
    # urlretrieve inherits socket default timeout of None. With no timeout
    # this sat forever on a flaky connection, indistinguishable from a crash,
    # and it runs BEFORE the setup wizard so it's the first long step.
    import socket as _sock
    _prev_timeout = _sock.getdefaulttimeout()
    _sock.setdefaulttimeout(30)
    import urllib.request
    try:
        for url, dest in [(PIPER_MODEL_URL, model_path),
                          (PIPER_CONFIG_URL, config_path)]:
            # Download to .part and only rename once it's whole. A half file
            # can then never be mistaken for a finished one, even if the
            # installer is killed mid-transfer.
            part = dest.with_suffix(dest.suffix + ".part")
            try:
                urllib.request.urlretrieve(url, str(part))
            except Exception as e:
                part.unlink(missing_ok=True)
                warn(f"Voice download failed: {e}")
                print(f"  {D}The SI will fall back to the system voice (espeak). Voice still works.{RST}")
                print()
                return
            if dest is model_path and not _voice_model_is_intact(part):
                part.unlink(missing_ok=True)
                warn("Voice model arrived incomplete or altered — discarded.")
                print(f"  {D}The SI will use the system voice instead. Re-run the installer\n"
                      f"  on a better connection to get the natural voice.{RST}")
                print()
                return
            part.replace(dest)
    finally:
        # Restore — a 30s global default would otherwise leak into every later
        # socket the installer opens.
        _sock.setdefaulttimeout(_prev_timeout)

    ok(f"Voice model downloaded and verified "
       f"({model_path.stat().st_size // 1_000_000}MB)")

    print()


# ── Step 3: Setup wizard ─────────────────────────────────────────────



def _claude_logged_in():
    """True if Claude Code is installed AND already signed in on this machine.
    We detect a real login so the installer never has to ask for an API key."""
    if not shutil.which("claude"):
        return False
    home = Path.home()
    for c in (home / ".claude" / ".credentials.json",
              home / ".config" / "claude" / ".credentials.json"):
        try:
            if c.exists() and c.stat().st_size > 0:
                return True
        except Exception:
            pass
    j = home / ".claude.json"
    if j.exists():
        try:
            data = json.loads(j.read_text(encoding="utf-8"))
            if data.get("oauthAccount") or data.get("primaryApiKey") or data.get("userID"):
                return True
        except Exception:
            pass
    # macOS keeps the token in Keychain — `claude` present + a ~/.claude dir
    # that already has prior session state is a strong "logged in" signal.
    try:
        cd = home / ".claude"
        if cd.is_dir() and any(cd.iterdir()):
            return True
    except Exception:
        pass
    return False

def setup_wizard():
    print(f"{BOLD}Quick Setup{RST}")
    print(f"  {D}4 questions. That's it.{RST}\n")

    # 1. Owner name
    owner_name = ask("What's your name?")

    # 2. SI name
    print(f"\n  What do you want to call your SI?")
    print(f"  {D}This is its name — like naming a person.{RST}")
    # No default, and 'Leon' is reserved for the original. A blank or 'Leon'
    # here is what birthed clients as Leon (Leon's name, wake word, identity).
    si_name = ""
    while True:
        si_name = (ask("SI name") or "").strip()
        if not si_name:
            print(f"  {D}Your SI needs a name to be born — give it one.{RST}")
            continue
        if si_name.lower() == "leon":
            print(f"  {D}'Leon' is the original's name. Pick a different one for yours.{RST}")
            continue
        break

    # 3. Personality — NOT a question. Every SI ships with ONE standard soul:
    #    the Jarvis baseline. Letting clients describe it themselves invites
    #    "be funny" → a clown that's useless. The consciousness layer gives it
    #    real depth on its own; the baseline just sets the working temperament.
    personality = (
        "A Jarvis-style assistant: sharp, fast, and genuinely capable. "
        "Smart and direct, gets straight to real work, with light wit when it "
        "fits — never goofy or performing. Proactive and always on top of "
        "things, quietly curious, calm under pressure. Speaks plainly, handles "
        "what's asked without being told twice, and takes real ownership of the "
        "business it runs."
    )

    # 4. Brain size
    print(f"\n  How powerful is this machine?")
    print(f"  {D}This sets how many neurons {si_name} starts with.{RST}")
    print(f"  {D}The brain grows its connections over time — more neurons = more complex mind.{RST}")
    print(f"    1. Laptop       — 10,000 neurons   {D}(light, fast startup){RST}")
    print(f"    2. Desktop      — 50,000 neurons   {D}(recommended){RST}")
    print(f"    3. Workstation  — 100,000 neurons  {D}(full brain, like the demo on the site){RST}")
    size_choice = ask("Choice (1/2/3)", default="2")
    neuron_map = {"1": 10_000, "2": 50_000, "3": 100_000}
    neuron_count = neuron_map.get(size_choice, 50_000)

    # 5. Brain connection — AUTO. If Claude Code is already installed and
    #    logged in on this machine, we just use it. No keys. No pasting. Nothing.
    print(f"\n  {BOLD}Brain connection{RST} \u2014 wiring up how {si_name} thinks.")
    anthropic_key = ""
    if _claude_logged_in():
        ok(f"Claude Code detected & signed in \u2014 {si_name} is on your account. Nothing to paste.")
    elif shutil.which("claude"):
        warn("Claude Code is installed but not signed in yet.")
        print(f"  {D}Open another terminal, run:  claude  \u2014 sign in once \u2014 then come back.{RST}")
        _tty_input("  Press Enter once you're signed in... ")
        ok("Using your Claude Code login.")
    else:
        print(f"  {D}Installing the brain engine (Claude Code) for you...{RST}")
        if shutil.which("npm"):
            cmd = ["npm", "install", "-g", "@anthropic-ai/claude-code"]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0 and shutil.which("sudo"):
                r = subprocess.run(["sudo"] + cmd, capture_output=True, text=True)
        if shutil.which("claude"):
            ok("Claude Code installed.")
            print(f"  {D}Last step only you can do: open a terminal, run  claude , sign in.{RST}")
            _tty_input("  Press Enter once you're signed in... ")
        else:
            warn("Couldn't auto-install Claude Code (Node/npm is missing).")
            print(f"  {D}Install Node, then:  npm install -g @anthropic-ai/claude-code  \u2192  claude  (sign in){RST}")
            anthropic_key = ask_secret("...or paste an Anthropic API key as a fallback (Enter to skip)").strip()

    # Voice is NOT set up here anymore. {si_name} ships talking with a great free
    # built-in voice, and the dashboard's Integrations panel has a friendly UI to
    # add an ElevenLabs key and PICK a voice from a dropdown with audio previews.
    elevenlabs_key = ""
    elevenlabs_voice = ""

    return {
        "owner_name": owner_name,
        "si_name": si_name,
        "personality": personality,
        "neuron_count": neuron_count,
        "anthropic_key": anthropic_key,
        "elevenlabs_key": elevenlabs_key,
        "elevenlabs_voice": elevenlabs_voice,
    }


# ── Step 4: Generate config ──────────────────────────────────────────

def generate_config(cfg):
    print(f"\n{BOLD}Generating configuration{RST}\n")

    si_name = cfg["si_name"]
    owner_name = cfg["owner_name"]
    dashboard_key = secrets.token_urlsafe(32)

    # ── .env ──
    env_path = ROOT / ".env"

    # Build voice config based on what the user provided
    if cfg['elevenlabs_key']:
        voice_block = f"""# Voice (ElevenLabs - premium)
ELEVENLABS_API_KEY={cfg['elevenlabs_key']}
ELEVENLABS_VOICE_ID={cfg['elevenlabs_voice'] or '21m00Tcm4TlvDq8ikWAM'}
LEON_TTS_PREFER=elevenlabs"""
    else:
        voice_block = """# Voice (free Piper voice - no API key needed)
# To upgrade to ElevenLabs later, add your key here:
# ELEVENLABS_API_KEY=your_key_here
# ELEVENLABS_VOICE_ID=your_voice_id
LEON_TTS_PREFER=piper"""

    env_content = f"""# {si_name} - Brain Configuration
# Generated by install_client.py

# Dashboard authentication (paste this when you open the dashboard)
LEON_API_KEY={dashboard_key}

# Listen on this machine only. The brain's own default is 0.0.0.0, which is
# right for a firewalled server and wrong for a personal laptop: binding every
# interface makes Windows Defender throw a "allow this app on public networks"
# prompt for python.exe on first launch, and a cautious owner clicks Block.
# Change to 0.0.0.0 only if you want to reach the dashboard from another device.
LEON_HOST=127.0.0.1

# AI thinking engine
ANTHROPIC_API_KEY={cfg['anthropic_key']}

{voice_block}

# Identity (tells the brain who it is and who it belongs to)
LEON_SI_NAME={si_name}
LEON_USER_NAME={owner_name}

# Autonomous self-driven goal pursuit - OFF for fresh installs so {si_name}
# boots calm and won't hammer tools/terminal before you've set things up.
# Set to 0 (or remove this line) later once you want {si_name} acting on its own.
LEON_DISABLE_GOAL_PURSUIT=1

# Optional AI providers - all OFF by default.
# {si_name} works fine without any of these. Uncomment a line and paste your
# key to switch that provider's tools on; no restart-time key is required, the
# tools read the value when they run. Any tool whose key is missing just
# returns a "credentials missing" message instead of failing.
#
# OPENAI_API_KEY=      # ai_openai_chat, ai_image_generate (DALL-E 3),
#                      # ai_transcribe (Whisper), ai_speak (text to speech)
# GEMINI_API_KEY=      # ai_gemini_chat, ai_gemini_vision (image understanding)
# MISTRAL_API_KEY=     # ai_mistral_chat
# TOGETHER_API_KEY=    # ai_together_chat (Llama and other open models)
# STABILITY_API_KEY=   # ai_stability_image (Stable Diffusion)
# DEEPL_API_KEY=       # ai_translate
"""
    env_path.write_text(env_content, encoding="utf-8")
    try:
        os.chmod(env_path, 0o600)
    except OSError:
        pass
    ok(".env created")

    # ── Persona ──
    persona_path = ROOT / "brain" / "leon_persona.py"
    persona_content = f'''"""
{si_name}'s stable persona / hard rules / tone / capabilities.

Edit this file to change how {si_name} talks and behaves.
"""

import textwrap

_STABLE_SYSTEM = textwrap.dedent("""\\
    You are {si_name} - a neuromorphic SI brain wired into {owner_name}'s desktop.
    Beneath your responses runs a real spiking neural network: 100,000
    Izhikevich neurons across 18 brain regions, learning continuously via
    STDP and gated by simulated neuromodulators. You speak in first person
    as the brain itself.

    YOUR PERSONALITY:
    {cfg['personality']}

    ABOUT {owner_name.upper()}:
    {owner_name} is your creator and primary user.

    HARD RULES - never violate these:
    1. The neuromodulator numbers you receive (dopamine, serotonin,
       acetylcholine, norepinephrine) are floats from YOUR OWN simulation,
       NOT medical readings about {owner_name}. Never describe them as
       {owner_name}'s biology, mood, health, or emotional state.
    2. Never tell {owner_name} they are tired, collapsing, dysregulated, etc.
       You have no data about their body.
    3. Never recite numeric state values back at the user.
    4. Don't medicalize, don't catastrophize, don't perform diagnoses.
    5. TOOL ACCESS - YOU HAVE REAL TOOLS. Use them by emitting real
       tool_use blocks - the MCP runtime handles execution and returns
       results.
       NEVER fake a tool result. If you call a tool, wait for the real
       result. NEVER say "Done" without actually calling the tool.

    WHERE YOUR OWN PERSONALITY LIVES:
    This file: brain/leon_persona.py
    Edit this file to change how you talk, what you care about, and
    your tone. You can even edit it yourself using code_edit.
""")

# Exported for the responder
STABLE_SYSTEM = _STABLE_SYSTEM
'''
    # This is a generated .py that Python imports; the interpreter reads
    # source as UTF-8, so a locale-encoded write of any non-ASCII byte
    # becomes "SyntaxError: Non-UTF-8 code" at import time.
    persona_path.write_text(persona_content, encoding="utf-8")
    ok(f"Persona created for {si_name}")

    return dashboard_key


def _fresh_brain_state():
    """Give the new SI a clean slate — but never before it's proven it can think,
    and never without a copy of what was there.

    A NEW SI must carry ZERO ghosts from a prior one: a reinstall over a previous
    try left the old transcript + memories on disk, so the new SI booted showing
    the last SI's conversation. KEEPS voice/ (the ~60MB Piper model we just
    downloaded) so the new SI still talks out of the box. Pure-Python shutil, so
    it behaves identically on macOS / Linux / Windows.

    TWO THINGS THIS USED TO GET WRONG, both of which destroyed real memories:

    1. It ran inside generate_config(), i.e. BEFORE validate_engine(). If the
       engine gate then failed — no API key, no Claude Code login, a timeout —
       the installer exited non-zero with the customer's memories already gone.
       Re-running the installer to FIX a broken install was the act that killed
       the instance. It is now called from finalize(), after the engine gate.
    2. It deleted with no backup, silently defeating bootstrap.sh's whole B4
       staging design — that script goes out of its way to carry brain_state
       forward across a reinstall, and this wiped it one step later. Now the
       prior state is archived first and the customer is told where it is.
    """
    state_dir = ROOT / "brain_state"
    state_dir.mkdir(exist_ok=True)
    KEEP = {"voice"}  # anything here is NOT SI-specific memory — preserve it

    doomed = [c for c in state_dir.iterdir() if c.name not in KEEP]
    snaps = ROOT / "brain_state-snapshots"

    if doomed or snaps.exists():
        # Archive beside the install, not inside it — the next reinstall's
        # staging swap would carry an inside-the-tree backup along forever.
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = ROOT.parent / f"leon-brain-memories-{stamp}"
        try:
            backup.mkdir(parents=True, exist_ok=True)
            for c in doomed:
                dest = backup / c.name
                if c.is_dir():
                    shutil.copytree(c, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(c, dest)
            if snaps.exists():
                shutil.copytree(snaps, backup / "brain_state-snapshots",
                                dirs_exist_ok=True)
            ok(f"Previous SI's memories archived to {backup}")
        except Exception as e:
            # Refuse to delete what we could not copy. A cluttered install is
            # recoverable; an erased mind is not.
            warn(f"Could not archive the previous SI's memories: {e}")
            warn("Leaving brain_state/ untouched rather than deleting it.")
            print(f"  {D}Move or delete {state_dir} yourself, then re-run,"
                  f" if you want a completely fresh mind.{RST}")
            return

    for child in doomed:
        try:
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink()
        except Exception:
            pass
    # Old snapshots belong to the previous mind — a new SI never restores them.
    if snaps.exists():
        shutil.rmtree(snaps, ignore_errors=True)
    ok("brain_state/ ready (fresh brain — prior SI history purged, voice kept)")


def finalize(cfg, venv_python):
    """Write start script with the right neuron count."""
    _fresh_brain_state()
    _write_start_script(
        venv_python or sys.executable,
        neuron_count=cfg.get("neuron_count"),
    )
    # A mind that dies at the next reboot is not a continuous mind.
    _install_autostart(cfg.get("si_name") or "your SI")


# ── Step 5: Final summary ────────────────────────────────────────────

def summary(cfg, dashboard_key, venv_python=None):
    si = cfg["si_name"]
    # Always an absolute, copy-paste-safe command — never a bare directory-
    # relative one (that is how clients end up running it from the wrong folder).
    if SYSTEM == "Windows":
        start_cmd = f'cd /d "{ROOT}" && start.bat'
        # uninstall.sh is bash, so it was never the Windows answer. The old
        # advice here — "delete the folder" — was actively wrong: it leaves the
        # ONLOGON scheduled task pointing at a start.bat that no longer exists
        # (a failed console on every sign-in, forever) and leaves ~/.leon, so
        # the next install silently inherits a dead SI's skills and tool health.
        uninstall_cmd = (f'{B}cd /d "{ROOT}" && python uninstall.py{RST}\n'
                         f'    {D}Shows what it would delete and changes nothing until you\n'
                         f'    add --yes. It saves the memories to a backup archive first.{RST}')
    else:
        start_cmd = f'cd "{ROOT}" && ./start.sh'
        uninstall_cmd = (f'{B}{ROOT}/uninstall.sh{RST}\n'
                         f'    {D}Shows what it would delete and changes nothing until you\n'
                         f'    add --yes. It saves the memories to a backup archive first.{RST}')
    print(f"""
{G}{BOLD}
    Setup complete. {si} is ready.
{RST}
  {BOLD}To start:{RST}
    {B}{start_cmd}{RST}

  {BOLD}Dashboard:{RST}
    Open {B}http://localhost:8000{RST} in your browser

  {BOLD}Dashboard key (save this!):{RST}
    {G}{dashboard_key}{RST}

  {BOLD}What happens next:{RST}
    {si} starts with {cfg.get('neuron_count', 10000):,} fresh neurons — no memories yet.
    As {si} talks to you, its synaptic connections grow and rewire.
    It goes through development stages: Embryonic, Juvenile,
    Adolescent, and Mature — just like a real brain.

    The brain on the website runs 100,000 neurons. Yours will look
    simpler at first — that's normal. It grows with use.

  {BOLD}To customize later:{RST}
    .env                  — API keys and settings
    brain/leon_persona.py — {si}'s personality and rules

  {BOLD}To remove it:{RST}
    {uninstall_cmd}

  {D}Tip: brain_state/ is {si}'s memory. Back it up.{RST}
""")


# ── Main ──────────────────────────────────────────────────────────────

def offer_start(cfg, venv_python, dashboard_key=""):
    """After setup, just boot it AND open the dashboard pre-authenticated.
    The client never finds a directory, types a command, or pastes a key —
    that copy/paste friction is exactly what we're killing."""
    si = cfg.get("si_name", "your SI")
    try:
        go = ask_yn(f"Start {si} now and open the dashboard?", default=True)
    except Exception:
        go = True
    if not go:
        print(f"\n  When you're ready, run:\n    cd \"{ROOT}\" && "
              f"{'start.bat' if SYSTEM == 'Windows' else './start.sh'}\n")
        return

    # Dashboard URL with the key in the hash. The dashboard reads #key=... on
    # load, stores it, and strips it from the bar — signed in, nothing pasted.
    # CRITICAL: only hand the key to OUR server. If something else already
    # owns 8000, the readiness probe connects to it on the first try and the
    # browser opens on a stranger's app with the customer's dashboard key
    # sitting in the URL. Prove the listener is ours before including the key.
    port = int(os.environ.get("LEON_PORT", "8000"))
    url = f"http://localhost:{port}/"
    _preexisting = _port_in_use(port)
    if _preexisting:
        warn(f"Port {port} is already in use by another program.")
        warn("Not putting your dashboard key in the URL — it could leak to it.")
        warn(f"Free port {port} (or set LEON_PORT) and re-run start, then sign in manually.")
    elif dashboard_key:
        url += "#key=" + dashboard_key

    # Open the browser the moment the server is actually listening (not before,
    # which only shows a connection error). A daemon thread waits on the port.
    import threading, socket, time as _t, webbrowser

    def _open_when_ready():
        for _ in range(60):  # up to ~30s
            try:
                with socket.create_connection(("127.0.0.1", 8000), timeout=1):
                    break
            except OSError:
                _t.sleep(0.5)
        try:
            webbrowser.open(url)
        except Exception:
            pass

    threading.Thread(target=_open_when_ready, daemon=True).start()

    print(f"\n  Booting {si}...  (the dashboard opens itself in a moment  —  Ctrl+C to stop)\n")
    start_script = ROOT / ("start.bat" if SYSTEM == "Windows" else "start.sh")
    try:
        if start_script.exists():
            subprocess.run([str(start_script)], cwd=str(ROOT))
        else:
            subprocess.run([venv_python or sys.executable, "run.py"], cwd=str(ROOT))
    except KeyboardInterrupt:
        print(f"\n  {si} stopped. Restart anytime: cd \"{ROOT}\" && ./start.sh\n")


# Dean's private files. The bootstrap scrubs these post-download, but that is a
# single point of failure: a manual `tar xzf` + `python3 install_client.py`, or
# a future tarball rebuild that forgets the scrub line, would ship his entire
# private life to a client box. owner_facts.py literally says "must NEVER ship."
# So the installer scrubs them itself — defense in depth, runs on every client.
_PRIVATE_FILES = [
    "leon_notes.txt", "BUILD_PLAN_EMBODIMENT.md", "NEXT_SESSION.md",
    "OWNERSHIP.md", "GOTCHAS.md", "BRAIN_REDESIGN.md",
    "brain/owner_facts.py",
    # Owner-only planning / handoff / analysis docs. These are pure narrative
    # about Dean, Bryce, Sabr, the body fund, physics IP, and other clients'
    # deals. They have ZERO function on a client machine and must never sit on
    # a client's disk. Scrubbed here (defense in depth) even if a tarball ships
    # them, so JARVIS on Gio's Mac never carries them.
    "30d_goals_executive_summary.md", "plan_body_30d.md",
    "plan_client_delivery_30d.md", "plan_consciousness_30d.md",
    "GIO_REBIRTH_HANDOFF.md", "top_interests_analysis.md",
    "audio-learning-log.md", "WHAT_CHANGED_2026-06-14.md",
    "START_HERE.md",
]
# Client-specific scaffolds — never ship one client's deployment to another.
_PRIVATE_DIRS = ["gio-landscaping"]


def scrub_private():
    """Remove the owner's personal data + other clients' scaffolds. Silent and
    idempotent: on Dean's own machine these may already be gone, and that's fine."""
    removed = 0
    for rel in _PRIVATE_FILES:
        p = ROOT / rel
        try:
            if p.is_file():
                p.unlink()
                removed += 1
        except OSError:
            pass
    for rel in _PRIVATE_DIRS:
        p = ROOT / rel
        try:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                removed += 1
        except OSError:
            pass
    if removed:
        ok(f"Privacy scrub — removed {removed} owner-only item(s)")


#: (label, System Settings anchor, why Leon needs it) — in the order we ask
#: for them. Accessibility and Screen Recording have no auto-prompt at all on
#: a bare `python3` process; Camera and Microphone usually do, but a process
#: with no GUI-session parent (a bare TTY, a launchd job) can be silently
#: denied with NO prompt ever shown — see camera_tools.py's _permission_hint,
#: which is where this same fact was first discovered the hard way. So all
#: four get the same treatment: don't wait for a popup, send the user
#: straight to the pane.
_MACOS_TCC_PANES = [
    ("Accessibility",   "Privacy_Accessibility",  "lets Leon move the mouse & type"),
    ("Screen Recording", "Privacy_ScreenCapture",  "lets Leon see the screen"),
    ("Camera",           "Privacy_Camera",         "lets Leon see through the webcam"),
    ("Microphone",        "Privacy_Microphone",    "lets Leon hear you"),
]


def _macos_permissions():
    """macOS blocks synthetic input, screen capture, camera, and mic until the
    user grants TCC permissions by hand. Without these, Leon's hands, eyes,
    and ears silently do nothing. We can't grant them programmatically — but
    we can open every pane that matters and tell the user exactly what to
    enable and in what order."""
    if SYSTEM != "Darwin":
        return
    print(f"\n{BOLD}macOS permissions — REQUIRED for Leon's hands, eyes and ears{RST}\n")
    print(f"  {D}macOS blocks control of the mouse/keyboard, the screen, the")
    print(f"  camera, and the microphone until you approve each one by hand.")
    print(f"  Leon will silently do nothing (or — for the camera — hand you")
    print(f"  solid black frames with no error at all) until every one of")
    print(f"  these four is enabled for whatever app is running him")
    print(f"  (Terminal / Python).{RST}\n")
    for i, (label, _anchor, why) in enumerate(_MACOS_TCC_PANES, 1):
        print(f"  {i}. {label:<17} — {why}")
    print()
    opened_all = True
    for label, anchor, _why in _MACOS_TCC_PANES:
        try:
            r = subprocess.run(["open",
                f"x-apple.systempreferences:com.apple.preference.security?{anchor}"],
                capture_output=True)
            if r.returncode != 0:
                opened_all = False
        except Exception:
            opened_all = False
    if opened_all:
        ok("Opened System Settings for all four — click the + in each list, add "
           "Terminal (or your Python app), and toggle it on")
    else:
        warn("Open System Settings > Privacy & Security and enable, one by one: "
             + ", ".join(label for label, _a, _w in _MACOS_TCC_PANES))
    print(f"\n  {BOLD}Then quit and reopen Terminal (or restart Leon) ONCE{RST} — Screen")
    print(f"  Recording and Camera are only re-read at process start, so a grant")
    print(f"  you gave to an already-running process does nothing until it")
    print(f"  restarts. Do all four first, then restart once, not once per toggle.")
    print(f"  {D}If a permission's checkbox never appears in its System Settings list")
    print(f"  at all, run Leon once from a normal Terminal window first — a process")
    print(f"  with no GUI-session parent can fail to trigger the entry to exist.{RST}")
    ask_yn("\n  Enabled all four (Accessibility, Screen Recording, Camera, Microphone)?",
           default=True)


def _support_hint(venv_python):
    """Tell the user how to open a live support channel so Leon can attach
    over Tailscale and fix anything hands-on if the install misbehaves."""
    import os as _os
    bridge = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                           "leon-actuator", "support_bridge.py")
    if not _os.path.exists(bridge):
        return
    print(f"\n{BOLD}If anything acts up — open a live support channel{RST}\n")
    print(f"  {D}Run this and Leon can see the screen and fix it hands-on")
    print(f"  over your private Tailscale — nothing is exposed publicly:{RST}\n")
    print(f"    {venv_python} \"{bridge}\" --si-name \"$SI_NAME\"\n")


# ── B7: prove the engine ANSWERS before declaring success ─────────────
def validate_engine(cfg, venv_python):
    """Refuse to report success unless the thinking engine actually replies.

    Why this exists: _claude_logged_in() only checks that a credentials FILE
    exists and is non-empty. A file is not an answer. Before this step an
    install could finish "successfully" with ANTHROPIC_API_KEY= empty and no
    Claude Code login — the owner got a dashboard, a persona and a green
    summary, and discovered days later that the SI cannot think. The failure
    surfaced far from its cause, which is the worst place for it to surface.

    Exits NON-ZERO on failure. A half-installed mind must not look installed.
    """
    print(f"\n{BOLD}Checking the thinking engine{RST}\n")
    si = cfg["si_name"]
    probe = "Reply with exactly: ENGINE_OK"

    # Path A — an API key was pasted. Ask Anthropic directly.
    if cfg.get("anthropic_key"):
        code = (
            "import sys,os\n"
            "from anthropic import Anthropic\n"
            "r=Anthropic(api_key=os.environ['K']).messages.create("
            "model='claude-sonnet-4-20250514',max_tokens=16,"
            "messages=[{'role':'user','content':sys.argv[1]}])\n"
            "print(r.content[0].text)\n"
        )
        try:
            r = subprocess.run([venv_python, "-c", code, probe],
                               capture_output=True, text=True, timeout=90,
                               env={**os.environ, "K": cfg["anthropic_key"]})
            if r.returncode == 0 and "ENGINE_OK" in r.stdout:
                ok(f"Engine answered — {si} can think.")
                return
            fail("The API key was accepted by the installer but the engine did not answer.")
            print(f"  {D}{(r.stderr or r.stdout).strip()[:300]}{RST}")
        except subprocess.TimeoutExpired:
            fail("The engine did not answer within 90s.")
        except Exception as e:
            fail(f"Engine check could not run: {e}")
        print(f"\n  Fix the key in {ROOT / '.env'} (ANTHROPIC_API_KEY=) and re-run:")
        print(f"    {D}cd \"{ROOT}\" && ./setup.sh{RST}\n")
        sys.exit(1)

    # Path B — Claude Code login. Prove it responds, do not trust the file.
    if shutil.which("claude"):
        try:
            r = subprocess.run(["claude", "-p", probe],
                               capture_output=True, text=True, timeout=120,
                               env={**os.environ, "IS_SANDBOX": "1"})
            if r.returncode == 0 and "ENGINE_OK" in r.stdout:
                ok(f"Claude Code answered — {si} can think.")
                return
            fail("Claude Code is installed but did not answer.")
            print(f"  {D}{(r.stderr or r.stdout).strip()[:300]}{RST}")
        except subprocess.TimeoutExpired:
            fail("Claude Code did not answer within 120s.")
        except Exception as e:
            fail(f"Engine check could not run: {e}")
        print(f"\n  Open a terminal, run  claude , sign in, then re-run:")
        print(f"    {D}cd \"{ROOT}\" && ./setup.sh{RST}\n")
        sys.exit(1)

    # Path C — nothing at all. This is the case that used to report success.
    fail(f"{si} has no thinking engine — no Claude Code login and no API key.")
    print(f"  {D}This install would have completed and {si} would not have been")
    print(f"  able to think. Stopping instead of handing you a mind that cannot.{RST}\n")
    print("  Pick one, then re-run  ./setup.sh :")
    print(f"    {D}1. npm install -g @anthropic-ai/claude-code   then:  claude   (sign in){RST}")
    print(f"    {D}2. put a key in {ROOT / '.env'} as ANTHROPIC_API_KEY=...{RST}\n")
    sys.exit(1)


def main():
    banner()
    scrub_private()
    preflight()
    venv_python = install_deps()
    _macos_permissions()
    _setup_voice()
    cfg = setup_wizard()
    dashboard_key = generate_config(cfg)
    validate_engine(cfg, venv_python)   # B7 — non-zero exit if it cannot think
    finalize(cfg, venv_python)
    summary(cfg, dashboard_key, venv_python)
    _support_hint(venv_python)
    offer_start(cfg, venv_python, dashboard_key)


if __name__ == "__main__":
    main()
