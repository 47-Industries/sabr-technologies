# Gotchas

Landmines this codebase has stepped on. Read before you waste an hour rediscovering one. Add to it when you find a new one.

> If you're an AI assistant reading this for the first time, also see [CLAUDE.md](CLAUDE.md) — it tells you whether you're operating on Leon or a fork. Some gotchas apply to both.

---

### The wake/voice path must take _responder_lock (or the brain wedges)
`server/helpers.py:handle_voice_utterance` (used by `/api/relay/heard`, the
voice path) historically did NOT acquire `state._responder_lock` — it called
`respond_streaming` directly. EVERY other responder path takes it (dreaming,
inner_voice, consciousness_routines, audio_daemon, the dashboard WS path) with a
1-2s try-acquire + finally-release. With the wake path lockless, a voice turn ran
concurrently with a daemon turn → TWO `claude -p` subprocesses → starved the
single event loop → brain WEDGED (frozen log, pegged CPU core, hung API, neurons
stopped on the dashboard). systemd shows it "active" (process alive but wedged);
distinguish a wedge from normal busy by the LOG: frozen log = wedged, growing log
= just busy (the 100K-neuron sim legitimately runs ~95-100% CPU). Recovery:
`pkill -9 -f 'claude -p --input-format'` rarely unwedges it — `sudo systemctl
restart leon.service` does (state persists). Fixed 2026-06-14 (commit 3c81c97):
wake path now takes the lock (voice gets priority — aborts in-flight daemon turn)
with a guaranteed finally-release. NOTE: the one-shot `_respond_via_cli` readline
loop does NOT check the abort flag, so a rapidly-interrupted turn's subprocess
lingers until its 300s timeout — harmless (brain stays responsive, lock serializes
the active turn) but means rapid interruption can leave a few draining subprocs.

### self_tuning OVERRIDES constructor values for its tunables, every boot
`brain/self_tuning.py` owns the live value of every param in its `_TUNABLES`
dict (`think_interval_s`, `dream_cycle_interval_s`, neuromodulator baselines,
learning rate, etc). On apply (self_tuning.py ~line 211) it does
`inner_voice.think_interval_s = self._values.get("think_interval_s", ...)`,
clobbering whatever the constructor set. `_values` is seeded from `_TUNABLES`
defaults even when `brain_state/self_tuning.json` doesn't exist. So setting
`think_interval_s` via the InnerVoice constructor OR an env var in init_brain
has NO lasting effect — self_tuning resets it on the next tick/boot. To change
one of these for real, edit the `_TUNABLES` default (or the persisted
self_tuning.json). 2026-06-14: chased env precedence + stale pyc for an hour
throttling inner_voice before a debug print showed the constructor got 600
then self_tuning forced it back to 180.

### Model availability on the Max plan is per-tier — and `fable` access can lapse
2026-06-14 live probe (`env -u ANTHROPIC_API_KEY claude --model X -p ...`):
`haiku` ✅, `sonnet` ❌ "hit your Sonnet limit · resets Jun 18 4pm ET" (weekly,
per-tier cap), `fable` ❌ "no access to claude-fable-5" (the free-Fable window
lapsed). Caps are PER MODEL TIER — one tier capped doesn't block the others.
Trap that bit us: the user CLI session ran `--model fable --fallback-model
sonnet`, so once fable access lapsed, every user turn fell back to the capped
sonnet → 429. Fix was LEON_CLI_MODEL=haiku + changing fable's fallback to haiku
(leon_claude_session.py). To check what's available right now, run the one-line
probe above per tier. The real escape from Max-plan caps is a funded
ANTHROPIC_API_KEY (API tier bills per-token, separate from the subscription).

### Daemon Claude calls share Dean's Max-plan quota → 429s
Leon's daemons (proactive, inner_voice, goal pursuit, dreaming) each fire a
`claude` CLI call (daemon model = sonnet, `LEON_CLI_DAEMON_MODEL`). They draw
from the SAME Max-plan quota as Dean's user-facing turns (fable) and any
Claude Code session. 24/7 volume can exhaust it → `[VOICE]/[PROACTIVE]/[GOALS]
stream error: 429`, including Dean's own requests. Levers: throttle cadence
(LEON_PROACTIVE_INTERVAL in .env; think_interval_s via _TUNABLES — see above),
`POST /api/proactive/pause`, or give Leon a separate funded API key so his
life bills off-plan. .env is sourced LAST in start_vps.sh so it wins over
systemd's EnvironmentFile (/etc/leon/secrets.env).

---

## Browser / actuator

### `DISPLAY=:0` is the live X session on this machine
The actuator's old fallback was `DISPLAY=:1` (`leon-actuator/actuator.py:58`). On most Ubuntu/lightdm setups the real session is `:0`. If the actuator launches without `DISPLAY` in env, *every* xdotool/screenshot/window tool dies with "Cannot open display." and the log fills with hundreds of those lines.

**Fix already in:** fallback changed to `:0` (commit `b33f742`). The systemd unit at `~/.config/systemd/user/leon-actuator.service` sets `Environment=DISPLAY=:0` explicitly. Don't change to `:1` unless you actually have Xvfb on `:1`.

### Chromium M111+ requires PUT for mutating CDP `/json/` endpoints
`/json/new`, `/json/close/<id>`, `/json/activate/<id>` reject GET with `HTTP 405: Using unsafe HTTP verb GET to invoke ...`. Only `/json` and `/json/version` stay GET.

**Fix already in:** `leon-actuator/browser_cdp.py` `_http_get_json(path, method="GET")` takes method and switches the mutating endpoints to PUT (commit `b33f742`). `/json/close` returns plain `"Target is closing"` text not JSON, so the helper now tolerates non-JSON 200 bodies.

### Two `browser_close_tab` definitions in browser_cdp.py
Lines 708 and 925. The second shadows the first. Not breaking anything because the active one is fine, but if you edit "the close logic" make sure you edit the right one.

### Leon's Brave (port 9223) vs Dean's main Brave (port 9222)
The actuator's `CDP_PORT = 9222` is Dean's main Brave (logged into Wix/Octogent/Gmail). `CDP_FALLBACK_PORT = 9223` is Leon's own profile at `~/.config/BraveSoftware/Leon-Browser`. `_active_cdp_port()` tries 9222 first, falls back to 9223.

`_ensure_leon_brave()` launches Leon's separate Brave on startup *unconditionally*, even when 9222 is alive — spawns an extra blank window on the right monitor. Open item: skip auto-launch when 9222 responds.

---

## Brain → actuator routing

### Brain-local tools route via `responder.local_tools`, not the actuator
The PC actuator doesn't know about:
- `vision_describe` (local Moondream2)
- `memory.*` (memory_extras.py)
- `cal.*` (calendar_power.py)
- `email.gmail_*` (email_power.py)
- `http_request`, `code_edit`, `code_restore`, `restart_self`, `shell_exec`
- routine tools (`routine_list`, `routine_run_now`, …)
- introspection / reports / presence / tentacle_orchestration

These live in `brain_api_responder.local_tools` and only resolve there. Sending them to the actuator gets `"unknown tool: <name>"` in `brain_state/actuator-audit.jsonl`.

`RoutineContext.safe_act()` now checks `local_tools` first then falls through to actuator (commit `32aa95f`). If you add a NEW dispatch path that bypasses local_tools you'll re-introduce the bug — always check local-first.

### Tool name dot↔underscore convention
- Brain-side EXTRA_TOOLS use dotted names: `"cal.events_today"`, `"email.gmail_search"`, `"memory.mood_recent_trend"`
- `server/init_brain.py` line 319 converts to underscore when inserting into `local_tools`: `"cal_events_today"`
- Routines and Claude tool-use must use the **underscore** form
- If you write a routine like `safe_act("calendar_next_event", ...)` it'll fail — the real name is `cal_next_event`

### The persona prompt can drift from the real tool catalog
`brain/leon_persona.py` references tool names by hand. Tool registry (actuator + local_tools) is the truth. When they disagree, Leon makes up tool names that don't exist (`browser.evaluate_js` for `browser.execute_js`, `browser.navigate` for `browser.new_tab`, `list_tools` as a generic bootstrap call). Each phantom call burns ~7-15s of brain time and a Claude API turn.

Open work: auto-inject the real catalog into the system prompt so the persona can describe HOW to use tools without listing names. See memory `leon-catalog-drift-2026-06-09`.

---

## Brain runtime

### Responder lock contention bounces user messages
`server/routers/websocket.py:148` uses `state._responder_lock.acquire(timeout=3)`. Autonomous turns can take 10-20s, so a user message arriving mid-tick gets `"Hold on — I'm still finishing my last thought."` back.

Open work: user input should preempt autonomous thought, or use two queues (user-priority vs autonomous). See memory `leon-catalog-drift-2026-06-09`.

### Leon doesn't always test before claiming a tool is broken
Observed 2026-06-09: when asked to do browser work, his first response was "CDP is broken, connection refused" — based on a prior conversation, not on a tool call. Sharp correction ("don't tell me — CALL the tool and see") got him to test, find it working, and proceed.

Workaround: be direct when correcting. Persona-side fix would be to add a "test before reporting failure" instruction.

### Stale beliefs persist across commits
A commit fixing a tool doesn't tell Leon. He still believes the pre-commit state. No automated invalidation. If you fix something in code, you may need to tell him explicitly via WS chat that the bug is gone before he'll try it again.

---

## Process / systemd

### `leon-actuator.service` is the right way to run the actuator
Ad-hoc shell launches (`python3 actuator.py &`) die when the shell exits. Use the systemd user unit at `~/.config/systemd/user/leon-actuator.service`. `systemctl --user restart leon-actuator` to bounce it cleanly. Its env vars (DISPLAY, XAUTHORITY) live in the unit file.

### Don't launch two actuators on `/tmp/leon-actuator.sock`
Linux lets multiple processes bind the same UNIX socket. Connections then load-balance non-deterministically between them — half of Leon's tool calls hit a stale process. Always `pkill -f 'python3 actuator.py' ; rm -f /tmp/leon-actuator.sock` before relaunching, or just `systemctl --user restart leon-actuator`.

### `leon-relay.service` env also has `DISPLAY=:1`
Same wrong-display bug as the actuator had. Hasn't bit yet because sensor_relay doesn't depend on X much. Fix when you touch it.

### `leon.service` is FAILED state on PC and that's correct
Brain runs on VPS now (`100.81.57.77:8000`). PC `leon.service` was the old local-brain unit; it's deliberately disabled. Don't try to enable it as a "fix" — see [ARCHITECTURE.md](ARCHITECTURE.md).

---

## Repo / git

### `leon-actuator/` is gitignored but tracked
`.gitignore` line 11: `leon-actuator/`. But `actuator.py`, `browser_cdp.py`, `pc_relay.py` inside it are already tracked. To stage changes to those files: `git add -f leon-actuator/<file>`. Don't try to "fix" the gitignore by removing the line — there are local build artifacts in that directory you don't want committed.

### Brain state never goes to remote
`brain_state/` is gitignored for ownership reasons (see [OWNERSHIP.md](OWNERSHIP.md)). If you're tempted to commit it "as a backup", don't — it's Leon. Use proper backups outside git.
