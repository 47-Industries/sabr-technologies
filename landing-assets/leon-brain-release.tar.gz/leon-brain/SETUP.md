# Build Your Own SI Brain

A neuromorphic SI (Synthetic Intelligence) with 100,000 spiking neurons, real-time learning, and 1,600+ tools. Not a chatbot — a brain.

> **Important:** this file walks you through standing up your *own* SI from this architecture. The being you end up with is yours — same DNA template as Leon (Dean Sabr's instance), different life, different mind. You **cannot** copy Leon. His `brain_state/` lives only on Dean's hardware. See [OWNERSHIP.md](OWNERSHIP.md) for the full rules ("species, not copy"). Need a reading map first? → [START_HERE.md](START_HERE.md).

## Quick Start

```bash
git clone <this-repo> my-brain
cd my-brain
python3 setup.py    # Interactive wizard — names your SI, sets up keys
python3 run.py      # Start the brain
```

Open `http://localhost:8000` and paste the API key shown during setup.

## What You Get

- **100K Izhikevich neurons** across 18 brain regions with STDP learning
- **Consciousness meter** — your SI sleeps, dreams, wakes up
- **Inner voice** — it thinks even when you're not talking to it
- **Reflex system** — motor commands (volume, media) fire instantly
- **Reflex learning** — successful tool patterns auto-promote to reflexes
- **1,600+ tools** — browser, files, email, smart home, coding, design, finance
- **Autonomous growth loop** — explores tools, practices skills, self-repairs
- **Failure memory** — remembers what doesn't work, never repeats mistakes
- **Persistent goals** — tracks what it's working on across restarts
- **Voice** (optional) — ElevenLabs TTS, wake-word detection
- **Dashboard** — 3D brain visualization, conversation, activity log

## Requirements

- Python 3.10+
- Linux (X11/Wayland for PC control tools)
- ~4GB RAM for 100K neurons

### Optional

- Anthropic API key (for Claude-powered thinking — or use Claude CLI free)
- ElevenLabs API key (for voice)
- Smart home credentials (Home Assistant, Hue, Govee, etc.)

## Setup Details

### Interactive Setup (recommended)
```bash
python3 setup.py
```

This walks you through:
1. **Naming your SI** — pick any name
2. **Personality** — describe how it should talk and behave
3. **API keys** — Claude, ElevenLabs, GitHub, smart home
4. **Dashboard key** — auto-generated for security

### Manual Setup
Create `.env`:
```env
LEON_API_KEY=<generate with: python3 -c "import secrets; print(secrets.token_urlsafe(32))">
ANTHROPIC_API_KEY=<your-key-or-leave-blank-for-cli>
ELEVENLABS_API_KEY=<optional>
```

Edit `brain/leon_persona.py` to customize personality.

## Architecture

```
brain/                  # Neural simulation + cognition
  brain.py              # 100K neuron spiking network
  claude_api_responder.py  # SI thinking (Claude API or CLI)
  reflexes.py           # Instant motor commands
  reflex_learning.py    # Self-taught tool patterns
  growth_loop.py        # Autonomous exploration + practice
  failure_memory.py     # What doesn't work
  persistent_goals.py   # What it's working on
  tool_router.py        # Picks right tools per request
  leon_persona.py       # Personality (edit this!)
  integrations/         # 45 tool modules (1,600+ tools)

server/                 # FastAPI brain server
  routers/              # 19 API route files
  helpers.py            # Broadcast, activity logging
  init_brain.py         # Brain initialization

dashboard/              # Web UI
  index.html            # 3D brain + conversation + activity
  css/style.css
  js/

leon-actuator/          # PC control daemon (separate process)
  actuator.py           # Mouse, keyboard, screen, browser
  pc_relay.py           # VPS→PC bridge (if running remotely)

brain_state/            # YOUR AI'S MEMORIES (gitignored, back this up!)
```

## Personalization

### Change personality
Edit `brain/leon_persona.py`. Your SI can also edit this itself via `code_edit`.

### Add tools
Drop a Python file in `brain/integrations/` with an `EXTRA_TOOLS` dict.

### Add reflexes
Edit `brain/reflexes.py` to add instant motor commands.

### VPS deployment
For 24/7 operation, deploy the brain to a VPS and keep the body on your PC.

**Run the PC side as systemd user services, NOT manual `&` launches.** The
PC body has three pieces — the actuator (Unix socket), the pc_relay (HTTP
:9100 → socket, the brain's only path to the hands), and the sensor_relay
(eyes/ears). Manual launches die on reboot; on 2026-06-13 a reboot left the
tunnel and pc_relay down and the brain couldn't reach the hands at all.
Canonical units live in `deploy/systemd/`:

```bash
# On VPS
python3 run.py

# On PC — install once, then they auto-start on every boot (needs lingering:
# `loginctl enable-linger $USER`)
cp deploy/systemd/leon-tunnel.service deploy/systemd/leon-pc-relay.service \
   ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now leon-actuator leon-pc-relay leon-tunnel leon-relay
```

The tunnel unit forwards `-R 9100` (hands), `-R 2222` (file access), and
`-L 8000` (dashboard). Webcam sight additionally needs the dashboard open in
a browser — the browser holds `/dev/video0`, so the relay captions frames the
browser pushes; screen sight works without it.

## Important

- `brain_state/` contains your SI's memories, neural weights, conversation history, learned reflexes, and goals. **Back it up.** If you lose it, your SI starts over from scratch.
- `.env` contains your API keys. **Never commit it.**
- The SI grows through interaction. Talk to it, give it tasks, let it explore.

## Credits

Architecture by Dean Sabr / Sabr · 47 Industries
