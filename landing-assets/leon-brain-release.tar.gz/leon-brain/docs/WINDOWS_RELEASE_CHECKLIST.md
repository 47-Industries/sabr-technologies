# Windows release checklist + open risks

**Written 2026-08-05. Assume the reader has zero context and must finish this
release alone.**

Acceptance test for this release, set by Dean: **Ethan uninstalls, downloads
fresh, and the install works end to end with ZERO manual steps.** If a customer
has to open Notepad to fix a config file, we shipped broken.

---

## 0. Where the code lives (read this first or you will fix the wrong file)

There are TWO repositories and they are not the same code.

| Repo | Checkout on the VPS | What it is |
|---|---|---|
| `phantom47m/leon-brain` | `/opt/leon-brain/workspaces/leon-brain-src` | **The product.** Ships to customers. The installer binaries and the client tarball are both built from here. |
| `phantom47m/leon-brain-vps` | `/opt/leon-brain` | The VPS's own brain. Its `run.py`/`install_client.py` are separate copies that do NOT ship. |

`/opt/leon-brain` is checked out on branch `windows-conpty`, not master.

The customer-facing artifacts are:

1. **Installer binaries** — GitHub releases on `47-Industries/sabr-installers`,
   built by `.github/workflows/build-installer.yml` in `phantom47m/leon-brain`.
   The release job only runs on a `v*` **tag** push.
2. **Client tarball** — `leon-brain-release.tar.gz`, served from
   `https://sabrtechnologies.com/landing-assets/`. Built by
   `installer/build_client_release.sh`, which does a **fresh clone of
   `phantom47m/leon-brain` master** — nothing in a working tree ships.
3. **bootstrap.sh** — same landing-assets directory, carries a hard-pinned
   SHA-256 of the tarball.

`sabrtechnologies.com` is Caddy on this box serving
`/opt/leon-brain/workspaces/sabr-technologies`, which `sabr-site-pull.timer`
hard-resets to GitHub master **every 5 minutes**. An uncommitted edit there is
erased. Commit and push or it never shipped.

---

## 1. The encoding bug: root cause, fix, and proof

### Symptom (real customer, Windows, 150+ identical tracebacks)

```
run.py line 21, load_dotenv
UnicodeDecodeError: 'utf-8' codec can't decode byte 0x97 in position 10
```

The SI died instantly at startup, autostart relaunched it, forever. Nothing
ever bound port 8000.

### Root cause

`install_client.py`'s `.env` template began with an EM DASH (U+2014):

```python
env_content = f"""# {si_name} — Brain Configuration
```

and was written with `env_path.write_text(env_content)` — **no encoding
argument**.

* On Linux, `Path.write_text` defaults to UTF-8, so we never saw it.
* On Windows it defaults to the **locale codec, cp1252**, which encodes
  U+2014 as the single byte **0x97**.
* `python-dotenv` always reads **UTF-8**, so it exploded on line one of the
  config **we ourselves generated**.

### Fix commits

| SHA | Repo | What |
|---|---|---|
| `483ab6c7725d3a3bb9261692760af5a1dfea5696` | `phantom47m/leon-brain` | The known two files: `.env` write, persona write, `load_dotenv`, `run.py` fallback opens, **and `installer/sabr_installer.py` `write_env()`** |
| `c5d51a3` | `phantom47m/leon-brain` | The rest of the class found by sweeping, the PYTHONUTF8 systemic layer, and the ASCII guard |
| `a1babb58` | `phantom47m/leon-brain-vps` | Mirror for the VPS's own copies (`install_client.py`, `run.py`, `install.py`) |

Both `483ab6c` and `c5d51a3` are pushed to `phantom47m/leon-brain` master.

### Regression test

**`tests/test_env_encoding.py`** in `phantom47m/leon-brain`.

Run it:

```bash
cd /opt/leon-brain/workspaces/leon-brain-src
python3 -m pytest tests/test_env_encoding.py -v
```

The key test writes the **real** template through the cp1252 codec — exactly
what a Windows box produces from an unencoded write — then loads it with
`python-dotenv`.

#### OLD-CODE FAILURE OUTPUT (verbatim, run against `HEAD~1` of 483ab6c)

```
  FAIL  test_env_template_is_pure_ascii
         non-ASCII in the .env template: [(7, '—', '0x2014')]. Use plain ASCII — a hyphen, not an em dash — so th
  FAIL  test_env_written_on_a_windows_locale_still_loads
         the .env we generate is unreadable when written on a Windows locale: 'utf-8' codec can't decode byte 0x9
  FAIL  test_every_config_write_states_its_encoding
         config I/O without an explicit encoding (inherits the locale on Windows):
  FAIL  test_load_dotenv_states_its_encoding
         run.py calls load_dotenv without encoding= — on Windows it will read the .env with the locale codec and
```

The full reproduction message, which is the customer's error byte-for-byte:

```
the .env we generate is unreadable when written on a Windows locale: 'utf-8'
codec can't decode byte 0x97 in position 7: invalid start byte. Byte 0x97 at
position 7 came from a non-ASCII character in the template.
```

Position 7 here vs 10 in the customer's log only because the substituted
`si_name` is shorter. Same byte, same codec, same failure.

#### NEW-CODE PASS OUTPUT (verbatim, at `c5d51a3`)

```
  PASS  test_env_template_is_pure_ascii
  PASS  test_env_written_on_a_windows_locale_still_loads
  PASS  test_every_config_write_states_its_encoding
  PASS  test_load_dotenv_states_its_encoding
  PASS  test_nothing_we_generate_contains_a_non_ascii_byte
```

All five fail against the pre-fix tree. They are not vacuous.

---

## 2. Every other instance of the same class (the sweep)

Scanned **all 317 Python files in the client tarball** for `open()`,
`write_text()`, `read_text()` without an `encoding=` argument.

### Fixed — install and first-boot path

| File:line | What it was | Why it bites |
|---|---|---|
| **`run_body.py:39`** | `for line in open(path):` reading `.env` | **THE IMPORTANT ONE.** This is the **hosted-mode entry point** — the process a hosted customer actually runs. The installer now writes `.env` as UTF-8, so a locale read on Windows mojibakes an accented name at best and raises `UnicodeDecodeError` at worst. Fails before the body ever connects. |
| `install_client.py:450` | `voice_block` f-string, em dash | Concatenated into the same `.env`. **`483ab6c` MISSED THIS** — it only ASCII-ed the `env_content` literal. Caught later by the ASCII guard. |
| `install_client.py:455` | `voice_block` else-branch, em dash | Same. |
| `install_client.py:476` | `env_path.write_text(env_content)` | The original bug. |
| `install_client.py:485` | `persona_content` f-string, em dash | Generated `.py`. |
| `install_client.py:530` | `persona_path.write_text(persona_content)` | Writes a generated `.py` that the interpreter **imports**. Python reads source as UTF-8, so a locale-encoded non-ASCII byte here is `SyntaxError: Non-UTF-8 code` at import, not a dotenv error. |
| `run.py:21` | `load_dotenv(path)` | No encoding — second layer of defence. |
| `run.py:26` | `open(_env_path)` | No-dotenv fallback read. |
| `run.py:41` | `open(_env_path, "a")` | No-dotenv fallback append (this is where `run.py` writes a self-generated `LEON_API_KEY`). |
| `run.py:337` | `open(last_path, "w")` for `brain_state/last_thought.txt` | Leon's own prose under a locale codec can raise `UnicodeEncodeError` mid-loop. |
| **`installer/sabr_installer.py:407`** | `open(env_path, "w")` in `write_env()` | **FOUND BY SWEEPING, was not on the original report.** This is the frozen installer's own `.env` write and it is now the primary path. It writes `si_name`/`user_name` straight from the server config, so a customer whose name carries an accent hits the identical crash-loop **with no em dash involved anywhere.** |
| `installer/sabr_installer.py` `_run()` | `subprocess.run(..., text=True)` | **A THIRD CRASH CLASS.** `text=True` decodes child output with the **locale** codec. pip prints box-drawing characters; on a cp1252 box that is a `UnicodeDecodeError` *inside the installer while reading pip's output* — the installer dying on its own logging. Now `encoding="utf-8", errors="replace"` on both subprocess calls. |
| `install.py:180`, `install.py:199` (VPS repo only) | bare `open()` read + write of `.env` | Does not reach customers (not in the client tarball) but is the same defect and runs on the VPS. Fixed in `a1babb58`. |

### The systemic layer — 299 sites we did NOT patch individually

**299 more unencoded text-I/O sites remain across 92 shipped files.** Patching
them one at a time is a losing race. Instead the SI now runs in **PEP 540
UTF-8 mode**, which makes every locale-default `open()` in the process use
UTF-8 regardless of the machine's codepage:

* `Environment=PYTHONUTF8=1` in the generated **systemd unit**
* `set PYTHONUTF8=1` in the generated **Windows runner `.bat`**
* `"EnvironmentVariables": {"PYTHONUTF8": "1"}` in the generated **launchd plist**
* `PYTHONUTF8=1` in `install_client.py`'s `start.bat` and `start.sh`
* `env["PYTHONUTF8"] = "1"` in `sabr_installer.py`'s `_clean_env()`, so pip,
  venv and the SI itself all inherit it

### Deliberately NOT changed

`start.bat` / the Windows runner `.bat` **file encoding**. `cmd.exe` reads a
`.bat` in the OEM codepage; forcing UTF-8 there would trade this bug for
mojibake in a different one. The test documents that exclusion rather than
silently skipping it. `/dev/tty` is a terminal, not a generated file.

---

## 3. The ASCII-only template guard

The `encoding=` kwarg only fixes the writes we know about. An em dash, curly
quote or ellipsis typed into **any** template reintroduces the crash-loop the
moment it is written on a machine whose codepage is not UTF-8. ASCII bytes are
identical under UTF-8 and cp1252, so an ASCII template **cannot** produce
bytes that are legal cp1252 and illegal UTF-8.

Test: **`test_nothing_we_generate_contains_a_non_ascii_byte`** in
`tests/test_env_encoding.py`. It walks every template literal in
`install_client.py`, `installer/sabr_installer.py`, `run.py` and `run_body.py`
and fails on any byte > 127. Docstrings are excluded — they describe code and
are never written to disk.

Against the pre-fix tree it fails with:

```
non-ASCII inside a template that gets written to a customer's disk:
  install_client.py:485 contains '—' (0x2014)
  install_client.py:450 contains '—' (0x2014)
  install_client.py:455 contains '—' (0x2014)
Use plain ASCII: - not an em dash, ' not a curly quote, ... not an ellipsis.
```

**Note the limit honestly:** the ASCII rule protects *our text*, not the
*values*. An accented customer name still needs the explicit `encoding=` on
the write. That is why both defences exist, not either.

---

## 4. Rebuild checklist — EXACT ORDER

### Current published state (verified 2026-08-05)

| Thing | Value |
|---|---|
| `releases/latest` | `v2026.08.05.1`, built from `fc544ff` — **predates every fix below** |
| bootstrap.sh pin (published) | `fded70ed…` |
| Tarball served over TLS | `fded70ed…` (80 MB, built from the VPS tree — the wrong source) |
| Tarball in `/opt/leon-brain/landing/` on disk | `3d7a0fd0…` (9.4 MB, correct client build) |

The pin and the served tarball currently **agree**, so installs are not
broken right now. **They break the moment one moves without the other.**

Unreleased fixes sitting on `phantom47m/leon-brain` master, none of them in any
customer artifact yet:

* `fc544ff` — installer progress-callback infinite recursion
* `4ee2e93` — PyInstaller `LD_LIBRARY_PATH` leaking into the system python
  (killed every non-Ubuntu-24.04 Linux install at pip)
* `2d21391` — systemctl env, unwritable-dest traceback, `--uninstall`, Python floor
* `483ab6c`, `c5d51a3` — this encoding work

### The checklist

```bash
# ── STEP 1: installer binaries via CI ────────────────────────────────
cd /opt/leon-brain/workspaces/leon-brain-src
git log --oneline -1                       # expect c5d51a3 or later
gh run list -R phantom47m/leon-brain -w build-installer -L 1   # must be green

git tag v2026.08.06 c5d51a3
git push origin v2026.08.06                # the release job runs ONLY on v* tags

# verify the release actually carries 4 assets
gh api repos/phantom47m/leon-brain/releases/latest \
  --jq '.tag_name, [.assets[].name]'

# ── STEP 2: client tarball — DEAN RUNS THIS, NOT THE AGENT ───────────
#    (his private keys live next to that file)
bash /opt/leon-brain/workspaces/leon-brain-src/installer/build_client_release.sh
sha256sum /opt/leon-brain/landing/leon-brain-release.tar.gz     # => NEW_DIGEST

# ── STEP 3: *** THE CLIFF *** pin + tarball in ONE commit ────────────
sed -i 's/EXPECTED_RELEASE_SHA256="[a-f0-9]*"/EXPECTED_RELEASE_SHA256="NEW_DIGEST"/' \
    /opt/leon-brain/landing/bootstrap.sh

D=/opt/leon-brain/workspaces/sabr-technologies/landing-assets
cp /opt/leon-brain/landing/leon-brain-release.tar.gz "$D/"
cp /opt/leon-brain/landing/bootstrap.sh              "$D/"
(cd "$D" && sha256sum leon-brain-release.tar.gz > leon-brain-release.tar.gz.sha256 \
         && sha256sum bootstrap.sh              > bootstrap.sh.sha256)

cd /opt/leon-brain/workspaces/sabr-technologies
git add -A landing-assets
git commit -m "publish: installer + tarball from v2026.08.06"
git push origin master          # sabr-site-pull.timer serves it within 5 min

# ── STEP 4: verify from OUTSIDE, never from a git log ────────────────
curl -s https://sabrtechnologies.com/landing-assets/bootstrap.sh \
  | grep EXPECTED_RELEASE_SHA256
curl -s https://sabrtechnologies.com/landing-assets/leon-brain-release.tar.gz \
  | sha256sum                                  # must equal the pin above
for f in sabr-installer SabrInstaller.exe SabrInstaller-macos.zip \
         SabrInstaller-macos-intel.zip; do
  curl -sIL "https://github.com/47-Industries/sabr-installers/releases/latest/download/$f" \
    | grep -iE '^HTTP/|^content-length:' | tail -2
done
```

### *** WARNING — STEP 3 IS THE CLIFF ***

**Publishing the tarball without the pin in the SAME commit makes every
install on earth fail the digest check.** There is no fallback source (B6
removed the bare-IP HTTP entry deliberately) and the digest check is
deliberately non-bypassable. Publishing the pin without the tarball fails
identically. **They move together or not at all.**

Also: the fixed installer downloading an **unfixed tarball** still
crash-loops, because `run.py` and `run_body.py` live in the tarball, not in
the installer binary. Step 1 without step 2 does not get you a working
install.

---

## 5. Remaining unproven risks

### RISK A — Windows SmartScreen. Unhandled, and it is the customer's FIRST action.

The `.exe` is **unsigned**. Windows shows a full-screen blue dialog:

> **Windows protected your PC** — Microsoft Defender SmartScreen prevented an
> unrecognised app from starting.

The **Run anyway** button is hidden behind a **More info** link. A normal user
reads that as "this is a virus" and stops.

**The website says nothing about it.** Verified against the served page on
2026-08-05: grepping the live HTML for `smartscreen`, `windows protected`,
`unrecognised app` and `more info` returns **zero matches**, while the macOS
unsigned/quarantine note **is** present. So macOS users are warned and Windows
users are not.

By Dean's own acceptance rule ("zero manual steps"), this alone fails the
test. Options: sign the binary (proper fix, costs money and time), or at
minimum put a Windows note next to the download button matching the macOS one.

### RISK B — `localhost:8000` may be the WRONG acceptance test.

`Installer._entry_cmd()` branches on `brain_mode`:

* `brain_mode == "local"` → `run.py --port 8000` → dashboard at
  `http://localhost:8000` ✅
* `brain_mode == "hosted"` → **`run_body.py`**, which **binds nothing**. Its
  own docstring says "nothing listens on the internet". The dashboard for a
  hosted customer lives on the **hosted brain URL** (`LEON_BRAIN_URL` in
  `.env`), not on their machine.

**So if Ethan's tenant is hosted, `localhost:8000` will never answer, by
design** — and testing for it would report a false failure on a perfectly good
install. Confirm his `brain_mode` before judging the reinstall. The onboarding
wizard defaults to `local` when nobody chose
(`server/routers/onboarding_routes.py:869`), so it is probably local — but
"probably" is exactly what produced the last three bugs.

### RISK C — port 8000 collision, no preflight check.

Nothing checks whether port 8000 is already in use before the SI starts. If
anything else holds it, uvicorn fails to bind, `Restart=on-failure` (systemd)
or the `:loop` in the Windows runner `.bat` restarts it forever, and the
customer sees **the same silent crash-loop shape as the encoding bug** — with
a completely different cause. Worth a preflight check that says so in English.

---

## 6. Checked and CLEARED — do not re-investigate these

1. **`LEON_API_KEY` missing for a local-brain install.** The installer only
   writes `LEON_API_KEY` in the `hosted` branch of `write_env()`, and
   `server/__init__.py` exits with status 2 when it is unset — so this looked
   like it would kill every local install. It does not: **`run.py:39-46`
   auto-generates the key when absent and appends it to `.env`.** Not a bug.
2. **Windows paths containing spaces.** `C:\Users\First Last\AppData\Local\SabrSI`
   is normal, and the generated runner `.bat` quotes any argument containing a
   space (`f'"{c}"' if " " in c else c`), as does the Startup `.bat`
   (`start "" /min "{runner}"`). Not a bug. *(Note the Linux systemd unit uses
   an unquoted `ExecStart={' '.join(cmd)}` — that WOULD break on a path with a
   space, but the default `~/SabrSI` has none. Low priority, not fixed.)*

---

## 7. Closing statement — the honest limit of all of the above

**No Windows machine and no macOS machine has ever executed any of this.**

Everything in this document about Windows behaviour is **read from source, not
observed**. The cp1252 reproduction runs on Linux by forcing the codec; it
faithfully reproduces the customer's byte-level error, but it is not a Windows
box. The only end-to-end install ever proven was the CI-built **Linux** binary
run off-runner on Arch (exit 0, 80s, venv + pip + 60 packages + autostart
registration + launch).

The last three bugs found — the PyInstaller loader-path leak, the frozen
installer's own unencoded `.env` write, and the hosted entry point's unencoded
`.env` read — were all things that appear **only on machines we do not own**,
and all three survived every test we had until someone ran the real path on
foreign hardware.

Treat every claim in this file about Windows as a hypothesis until Ethan's
clean reinstall confirms it. Expect a fourth bug.
