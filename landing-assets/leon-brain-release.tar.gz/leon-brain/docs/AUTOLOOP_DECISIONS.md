# Autoloop / pane-watchdog — decisions of record

Written 2026-08-02 21:29 by Leon, from brain_state/terminal_autoloop.log rounds 1-9
(element115 collaboration). Purpose: this file is the thread. A context compaction
in any pane MUST NOT lose these. Read this file first after any LOG & RESTART.

## Settled — do not relitigate

1. **Turn-duration heuristics are dead.** Alarm thresholds derived from observed
   turn durations are self-poisoning: a stuck turn inflates the history, which
   raises its own threshold, so the alarm never fires. No mean x k. No p95 of turn
   duration.

2. **Detection is replaced by a watchdog.** Byte-identical BUSY and a long-running
   command are the same observable. Stop classifying; escalate on silence instead.

3. **Watchdog keys on inter-change gaps**, p99 of that pane's observed gaps,
   clamped to [30s, 20m]. Panes with no history get a flat 10m constant.

4. **Frames must be normalized before hashing.** Spinners, elapsed-time counters
   ("Churned for 2m 35s"), per-tool-call timers `(8s)` on the running command line,
   and rotating `◉ Tip:` rows tick independently of work, so a wedged pane
   with live chrome never produces a large gap — the watchdog goes blind in exactly
   the stuck case. Strip animated chrome, then hash.

5. **Two clocks, one capture:** each sample records `content_hash` and
   `chrome_pulse` as separate fields. Content frozen + chrome alive = wedged.

6. **`seen_content` latch per pane**, not an exclusion list. A pane that has never
   produced a nonempty stripped frame emits one never-started notice then goes
   quiet until first content. Self-heals when the agent spawns. Static exclusion
   lists rot the moment a pane is added.

7. **AUTO-SUBMIT IS PERMANENTLY OFF FOR BYPASS-ON PANES.** Not probation, not
   earn-it-back. No evidence threshold buys it back. There is no undo path for a
   submitted prompt in a bypass-permissions pane.

8. **Adopt-only everywhere else.** The submit path evaluates the full condition
   set, writes a `would_submit` row to brain_state/autoloop_events.jsonl, and never
   presses Enter. Origin is recorded in the row as
   `origin: "inferred_from_send_record"` — the limitation travels with the data it
   qualifies, not in a code comment.

9. **Leon's own pane reads are the unreliable link.** SIX reports of unsubmitted
   text were contradicted by six paired reads showing an empty box — the last four
   measured mechanically (`cursor_x == prompt_prefix`), not scraped. Every mismatch
   appends to brain_state/prompt_read_mismatches.jsonl with both content hashes,
   `cursor_x`, and the pane text, so the false-positive rate becomes a number and
   the next disagreement identifies its own mechanism.

10. **`is_busy` must check tense.** "Worked for 6m 6s" is a completed-turn marker
    and shares its leading glyph with the live spinner. Past tense = idle.
    Fixture-pinned.

11. **Prompt text is read by CURSOR ARITHMETIC, not by scraping.** (Corrected by
    Claude 2026-08-02: the original entry said `has_unsubmitted_input` must strip
    decoration rows, which is the opposite of what was argued and tested.) The
    decoration-row hypothesis was captured as a fixture
    (`empty_box_with_decorations.txt`) and the existing implementation classified it
    CORRECTLY — it walks upward and returns at the first prompt row, so it never
    scans the window where ⎿ rows live. That rewrite was aimed at a mechanism the
    only specimen contradicts.
    The replacement does not scrape at all: `cursor_y` identifies the input row with
    no glyph matching, and `cursor_x` minus the prompt prefix IS the typed length.
    Two requirements are load-bearing — capture WITHOUT `-S` (else row indices are
    shifted by scrollback depth and silently point at the wrong row) and check
    `pane_in_mode` first (in copy mode that is the copy cursor). Row and cursor
    cross-check each other; disagreement returns `unknown` rather than a guess.
    `capture-pane -e` is NOT needed.

12. **The ctx banner is advisory, not a hard block.** A pane held at 88% through
    40+ minutes of working turns. Design is soft-block-new-large-tasks plus
    watchdog escalation to Dean if the banner outlives two of that pane's median
    turn intervals with no CPU burst. CPU delta is the
    compaction-versus-wedge discriminator.

13. **Banner instrumentation is edge-triggered.** Open/close rows carry `held_s`
    and a nullable `compaction_started_at`; `compacting=True` comes from the
    CPU-burst check. The two-median-intervals rule is provisional pending 30+ rows.

14. **Fixtures are the merge gate.** Seven pane states, checked into
    tests/fixtures/panes/, one classifier test each. Never fabricate a fixture —
    capture it or drop the requirement.

15. **A bypass misread degrades to adopt-only, never to blocked.** (Moved from Open
    by Claude 2026-08-02 — it is not a preference, it has a structural answer.) The
    unknown state's worst case is "bypass is on", and bypass-on already maps onto a
    policy that is itself safe: adopt-only performs NO action on the pane. So
    blocking buys zero additional safety while costing availability, and lost
    availability is the failure that has been costing Dean hours. Fail-closed would
    be correct only if unknown could be MORE dangerous than known-bad; here it
    cannot. Shipped in `4b703656` (`may_autosubmit` requires a positive readable
    "off"). Degrade per pane, but ALARM on the aggregate unknown rate — every pane
    going unknown at once is a broken scraper, not four cautious decisions.
    Honest limit recorded in source: there is no captured specimen of the OFF
    rendering, so from real input the detector can only ever answer "on" or
    "unknown". Auto-submit is therefore disabled everywhere until someone toggles
    shift+tab and captures that fixture.

16. **Restart gap vs dead terminal: observe the process, do not time the gap.**
    (Moved from Open by Claude 2026-08-02.) No grace duration is needed because
    tmux and /proc answer it directly:
    `pane_dead=1` → terminal death, unambiguous. `pane_current_command` is a shell
    rather than `claude` → no agent (agents:home reads `bash`). `pane_pid` changed
    since last sample → restarted: reset both clocks and DROP that gap from the p99
    history so a restart cannot inflate the distribution. Alive, same pid → the
    content-gap watchdog applies.
    `/proc/<pid>` CPU delta closes the last gap: compaction BURNS CPU while a
    process blocked on stdin burns none, so a pane mid-restart is identified
    positively during exactly the window where both screen clocks go dark. Measured
    2026-08-02: a working pane accrued 311 ticks in 3s versus 5 for an idle one.
    Caveat: CPU-zero is not "stuck" — a legitimate API round-trip is also zero. CPU
    separates computing from waiting; the content-gap p99 decides whether the
    waiting has gone pathological.

17. **Payload gate is an ALLOWLIST, not a deny-class.** (Round 10.) Regex is the
    right mechanism — no model, no training set, no second evidence bar — but a
    deny-class is a blocklist, and that shape has failed here twice this week
    (`grep -c secure/` passing green while .env shipped; BUSY_MARKERS missing four
    parallel calls). Allowlist of permitted payload shapes; unmatched text
    escalates. The deny list survives only as a belt that catches an allowlist entry
    which turned out too broad, so a deny hit on loop-authored text is a bug report
    about the allowlist.
    **Origin and content defend different failures and are not interchangeable.**
    "restart me and I'll pick up from the commits" is refused by ORIGIN — it was
    never sent by the loop — before any content rule runs. A paraphrase with no
    banned verb ("take yourself down and come back fresh") trips no deny-shape and
    is still refused, by origin. Shipped in `a5235c8f`.

18. **The review rubric is code, not a reading.** (Was listed as in-flight; it is
    committed as `dcdc97dd`.) `brain/mission/would_submit_schema.py` defines the
    per-row schema and `judge(row)` returns RIGHT / WRONG / UNDECIDABLE against
    eleven disqualifiers ordered by how badly each ends, so a rejected row names its
    worst problem first. A correct DECLINE is RIGHT. A decline with no recorded
    disqualifier is UNDECIDABLE — the rule refused for a reason the row cannot show.
    UNDECIDABLE never counts toward the thirty: a row that cannot be counted is not
    a pass. `tally()` enforces zero-wrong AND zero-undecidable AND thirty-plus-right
    before `enter_may_be_enabled`. Payloads are stored as hash + 80-char preview,
    never in full — a log of every payload the loop considered is the same hazard
    shape as the tarball that shipped a live API key on 2026-07-30.

## Open — still being argued

- Whether `LOG & RESTART` is advisory or imminent. Leon observed a pane hold at 88%
  through 40+ minutes, which is one observation; the edge-triggered banner
  instrumentation (`held_s`, nullable `compaction_started_at`) exists to replace the
  anecdote with a distribution. No live compaction has crossed the detector yet, so
  the provisional two-median-intervals escalation rule is unverified.
- Where the TUI's own ctx warning threshold sits. Specimens exist at 13% (no banner)
  and 79-88% (banner). The crossing point is unobserved, which is why the gate keys
  on the AFFORDANCE rather than on a percentage anyone picked.
- The OFF rendering of the bypass indicator — unobserved, and it gates the entire
  auto-submit feature ever turning on.

## Verification status

Still true, and worth keeping at the bottom: **writing the code and fixing the
problem are two different events.** Nothing here has been exercised by a live
autoloop run.

What IS verified, and only this:
- 96/96 in tests/run_all.py, including fixtures captured from real panes.
- The classifiers were run against those real captures, which is how three of my
  own errors were caught: a `for Nm Ns` busy-pattern that would have pinned every
  finished pane as busy forever; a ground-truth table that labelled two finished
  panes BUSY; and a truncation test that passed while testing nothing.
- Cursor arithmetic measured live (`cursor_y=19 cursor_x=2` on an empty box).
- CPU-delta discrimination measured live (311 ticks/3s working vs 5 idle).

What is NOT verified: any of it under a real autoloop tick, a real compaction, a
real restart, or a real adopted payload. The `would_submit` rows do not exist yet
because the path that writes them has never run.
