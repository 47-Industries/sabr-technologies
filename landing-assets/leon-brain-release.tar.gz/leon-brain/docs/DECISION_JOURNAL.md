# Decision journal — pre-committed criteria

Rows written BEFORE the evidence arrives, so the call is a criterion and not a
mood. Anyone reading a commit message and wanting to rebuild something deleted
here should read the row first.

## DJ-001 — UNDECIDABLE branch: delete unless witnessed
- **Opened** 2026-08-03 by Leon + Claude.
- **The branch**: `pane_watchdog.UNDECIDABLE`, added in `e060fb15`, covering
  content-frozen + chrome-ALIVE + low-CPU — a state where a long API wait and
  a wedge are the same observable, so the watchdog abstains instead of
  guessing.
- **Status of the evidence**: PREDICTED FROM MECHANISM, NEVER WITNESSED. Three
  separate hunts found nothing: a 12s one-shot net, a 20s sweep across three
  purpose-built panes, and every live pane sampled to date. Every idle pane on
  this box shows BOTH clocks frozen.
- **CRITERION**: the passive recorder (`brain_state/stream_recorder.jsonl`,
  running since `24a4b8f5`) logs **72 hours** from 2026-08-03 without a single
  row where `content_frozen == true` and `chrome_frozen == false`.
  Deadline: **2026-08-06**.
- **If the criterion is met**: DELETE the UNDECIDABLE branch. The case falls
  through to `may_autosubmit`'s default refusal, which is already safe. Do not
  rebuild it from `e060fb15`'s commit message — that message argues the branch
  is *coherent*, which it is; this row records that coherent was not enough.
- **If a divergence row appears**: the branch stays, the row is the specimen,
  and this entry closes as WITNESSED with the row quoted.
- **Check it with**:
  `grep -c '"content_frozen": true, "chrome_frozen": false' brain_state/stream_recorder.jsonl`

### DJ-001 AMENDMENT — 2026-08-03, two clauses, not a rewording

The original criterion conflated two findings that share an observation and
imply opposite actions:
  * no divergence because the STATE DOES NOT OCCUR   -> dead code, delete
  * no divergence because EVERYTHING LOOKS THE SAME  -> correct verdict, keep

**Clause A — delete UNDECIDABLE** only if BOTH hold: the 240s bands separate
cleanly, AND at least one genuinely wedged pane appeared in-sample.

**Clause B — UNDECIDABLE becomes permanent** if the bands overlap.

CORRECTION TO THE AMENDMENT AS DICTATED: clause B originally named the resize
probe from 34530fb4 as the sole surviving discriminator. It is not a
discriminator at all. Its own run returned `silent` for wedged, long-working
AND finished — three for three, splitting nothing. Writing it into the journal
as a fallback would enshrine a falsified probe as the safety net. Under clause
B there is NO surviving discriminator, and that is the finding.

#### DATA (tests/fixtures/spinner_bands.json, captured 2026-08-03)
Stimulus: `python3 -c 'import time; time.sleep(180)'` — a deterministic
mid-turn hold with the spinner painted throughout.

    band      n    min   med   max    nonzero   spinner_glyph
    idle      60   0.0   1.0   3.0    30/60     0/60
    midwait   43   0.0   1.0   29.9   27/43     42/43

**CLAUSE B FIRES.** The CPU bands OVERLAP — identical medians (1.0), and
roughly half of each band is nonzero. The max differs (3.0 vs 29.9) but a max
is not a threshold: no cut separates them without slicing through both.

The glyph column separates perfectly (0/60 vs 42/43) and buys NOTHING for the
question asked, twice over. It is paint, inadmissible under the 5/5
stale-pixel rule. And it separates IDLE from MID-TURN, which `turn_owed` from
the ledger already gives without touching the screen. A wedged pane stopped
mid-turn still paints its last spinner, so the glyph is present for wedged AND
waiting alike.

CAVEAT ON THE STIMULUS: `sleep` makes claude wait on a LOCAL SUBPROCESS, not
on the API. An API-wait band is still unmeasured, and could differ.

CONCLUSION: UNDECIDABLE is permanent. There is no non-paint discriminator
separating wedged from long-working, `turn_owed` remains the only split that
has ever held (finished versus the rest), and the abstain branch is the
correct answer to a real and confirmed ambiguity rather than a placeholder for
an unmeasured one.

## DJ-002 — resize probe: FALSIFIED WITH EVIDENCE, deleted 2026-08-03
- **What it was**: `brain/mission/pane_probe.py`, added in `34530fb4`. Resize a
  pane one column and back; a live TUI takes SIGWINCH and repaints, a stopped
  one does not. Verdict recorded as a tri-state `render_alive | silent |
  not_probed`, deliberately never folded into a wedged boolean.
- **Falsifying run 1** — three purpose-built panes, `34530fb4`'s own test:
      wedged (cat blocked in read(0), no handler)  -> silent
      long-working (bash running sleep 900)        -> silent
      finished (bash idle at its prompt)           -> silent
  Three states, one answer. It split nothing, including the wedged-vs-not
  split it was built for.
- **Falsifying run 2, the decisive one** — probed `yes:p` immediately after
  that pane completed a real turn (`✻ Brewed for 2s`, `ctx 3%`, sitting at its
  prompt):
      ('silent', 'no repaint across 80->79->80 — event loop not running')
  A confident WRONG answer on a demonstrably healthy pane.
- **Why deletion rather than demotion**: same reasoning that killed
  `bypass_state` in `7950c496`. A reader that is always wrong in the same
  direction is anti-signal, not a fallback. Worse than `bypass_state`, which
  at least failed to `unknown`; this one fails to a confident verdict, so
  keeping it as a fallback means a wedge alarm that fires on healthy panes.
- **CORRECTION TO THE INSTRUCTION THAT ORDERED THIS**: it named the resize
  probe as "the only surviving discriminator" while also ordering pane_probe
  deleted. They are the same object. Deleting it leaves clause B with ZERO
  discriminators for wedged-versus-long-working, not one. Clause B is naked,
  and that is the finding rather than an oversight in it.

## DJ-003 — The web terminal keystroke path is exempt from may_autosubmit
2026-08-03, Leon, unattended.

The gate governs UNATTENDED submission: the loop pressing Enter on text nobody
watched it type. `TerminalSession.write()` is the browser keystroke path — a
human is at the keyboard, they are the authorizer, and every byte is theirs by
construction. Gating it did not add safety; it made the interactive terminal
unusable on every pane on this box (94 refusals / 94 attempts / zero yes).

Worse, it MUTATED the payload before sending: `\r`/`\n` -> space, then `.strip()`.
Consequences, both live bugs:
  - a bare Enter became "" and was rejected by `if not flat` — the Enter key
    silently did nothing
  - a multi-line paste arrived as one space-collapsed line

Decision: exempt, and stop mutating. write() now splits the payload on submit
characters and emits `send-keys -l <literal>` / `send-keys Enter` in order, so
the pane receives exactly the bytes it was handed.

Proven, not asserted: tests/test_web_terminal_write_fidelity.py drives a real
tmux pane running `cat` and reads back the echo. Bare enter, multi-line paste,
and internal spacing all round-trip. All three fail on the old code.

Scope: this exemption is the web keystroke path ONLY. terminal_loop.send() —
the unattended path the gate was actually built for — is unchanged and still
gated on both cursor-emptiness and may_autosubmit.

## DJ-004 — tpgid vs pgrp: a real discriminator, SHELL PANES ONLY
- **Proven 2026-08-03 against both cases, on this box, not on paper.**
- FINISHED fixture: `agents:home`, window 0, idle 7303 minutes, bash pane.
- WEDGED fixture: constructed — `cat` blocked opening a FIFO nobody will
  write to. Never makes progress, is not finished, burns zero CPU. The exact
  shape that defeated CPU, the spinner floor, and the resize probe.

      pane                 cmd   pane_pid  tpgid    fg==shell?  wchan
      agents:home FINISHED bash  26569     26569    True        poll_schedule_timeout
      wedge:w     WEDGED   cat   3916058   3916083  False       do_wait
        └─ fg child        cat   3916083   3916083  -           wait_for_partner

- **The signal**: `tpgid == pgrp` — does the shell own the terminal's
  foreground process group, or does a child? That is definitionally "back at
  the prompt" versus "something is still running".
- **Why it survives what killed the others**: not `capture-pane`, so paint
  cannot stale it. Not timing, so it cannot self-poison. Not CPU, so a blocked
  wait and a blocked wedge do not collapse together. `wchan` corroborates
  independently.
- **SCOPE, and it is narrow**: SHELL panes. A TUI process is ALWAYS its own
  tty foreground group whether thinking or wedged, so this goes blind on the
  four claude panes. Clause B stays OPEN — this does not touch it.
- **TUI-side discriminator count remains ZERO.** The resize probe was deleted
  in `6470933a` and falsified in DJ-002; it is not a fallback. `wchan` is the
  first TUI candidate, unmeasured against a wedged TUI as of this entry.

## DJ-004 AMENDED 2026-08-03 — tpgid/pgrp is TUI-HOSTILE, not TUI-blind
Measured on a `bash -> claude` pane, both states, same pane:

    healthy (claude in fg):   tpgid=3934757  pgrp=3934732  fg==shell? False
    wedged  (claude STOPPED): tpgid=3934732  pgrp=3934732  fg==shell? True

In the SHELL fixture `True` meant FINISHED. Here `True` means WEDGED. When the
foreground process stops, the kernel hands the terminal's foreground group back
to the shell, so a wedged TUI presents exactly as "shell back at its prompt".
Applied to a TUI pane this does not fail silent — it reports WEDGED AS
FINISHED, the worst available direction. Shell-pane scope is not a preference,
it is a hard boundary.

## DJ-005 — foreground-group signal for TUI panes: STOPPED WORKERS ONLY
Same numbers read the other way. On a `bash -> claude` pane:

    healthy   claude holds fg  -> tpgid != pgrp  (False)
    finished  claude holds fg  -> tpgid != pgrp  (False)
    STOPPED   shell reclaims   -> tpgid == pgrp  (True)

So `tpgid == pgrp` is True ONLY when the worker is stopped, and that is a real
discriminator with INVERTED POLARITY from DJ-004's shell case.

**SCOPE, STATED SO NOBODY MISREADS IT ON THE 6TH: this detects STOPPED
workers, not HUNG ones.** A process that is alive and simply making no
progress keeps its foreground group and reads False — identical to healthy.
This is NOT a hung-detector. It catches SIGSTOP-class wedges and nothing else.
No fixture exists for the hung case as of this entry.

## DJ-006 — resize probe: THIRD falsification, on the exact pair it was for
`34530fb4`, already deleted in `6470933a`. Run against one `bash -> claude`
pane in both states, back to back:

    PROBE #1 (healthy):  ('silent', 'no repaint across 80->79->80 — event loop not running')
    PROBE #2 (wedged, ps stat=Tl confirmed): identical string, identical verdict

Byte-identical answers for a healthy TUI and a confirmed T-state one. Earlier
falsifications showed it answering `silent` to three states and giving a
confident wrong verdict on a healthy pane; this one shows it blind on the
precise pair it was built to separate. There is now NO TUI discriminator.

## DJ-007 — PRE-REGISTERED THRESHOLD for shipping the YES path
Written 2026-08-03 BEFORE the five-turn baseline runs, so the numbers cannot
negotiate with the decision afterwards. Leon's spec, my commitment.

**The pass condition, fixed now:**
  * five turns, per-turn p95 agreeing within 20%, AND
  * working-band minimum >= 3x idle-band p95, AND
  * pre-token and streaming bands reported SEPARATELY (a single average across
    a 77s pre-token stall at ~0 and a 3-4 tick/s stream is a fiction).

**If the bands overlap — working minimum lands under 3x idle p95 — what would
make me ship the YES path anyway?**

NOTHING FROM THIS MEASUREMENT. Written plainly so it cannot be softened: an
overlap means no floor exists, which means the gate has no way to tell a
working pane from an idle one, which is a WEAKER capability than the one
clause B already denies. Shipping YES on an overlapped band would be granting
auto-submit on the strength of a measurement that failed.

The only conditions that would ship the YES path are independent of the floor:
  1. The GATE 2 fallthrough is fixed and `may_autosubmit` in the stamp is
     written from the gate's verdict, not the literal True — so the ledger can
     contradict the gate instead of agreeing by construction; AND
  2. A regenerated sweep shows NO rows in autoloop_escalations.jsonl and YES
     rows in send_ledger.jsonl for the SAME run, with the counts matching the
     four callers' actual emissions; AND
  3. Zero send rows whose recorded permission_mode is "bypass permissions".
Today that last count is 44. It must be 0.

**What expiry means if the baseline fails:** DJ-001's UNDECIDABLE branch does
NOT expire into YES. It stays UNDECIDABLE and the 2026-08-06 date lapses as a
review checkpoint, per the earlier resolution that the branch closes on
evidence and not on a calendar. A failed baseline is evidence AGAINST shipping,
never for it.

## DJ-001 CITATION AMENDED 2026-08-03 — the "94/94" figure is struck
"94/94 refusals" was a `would_submit_schema.judge()` replay over the mismatch
corpus. It was never live gate traffic and must not be cited as NO-path
evidence.

**The real record, from brain_state/autoloop_escalations.jsonl:**

      291  deny_shape
       29  allowlist_miss
        5  bypass_unknown
        2  origin_unverified
        2  pane_wedged
      329  TOTAL

And the shape of it is itself a finding: `deny_shape` is 88% of all refusals
because `send()` calls `classify_payload(flat)` WITHOUT `loop_authored=True`.
Leon's own edit to payload_gate carved `COMMAND_DENY_SHAPES` out precisely so
loop-composed prose would not trip the bare-verb row (restart|kill|terminate)
— this loop's entire subject matter is wedged processes, so nearly every
message it writes says one of those words. The flag exists and the caller does
not pass it. The NO path is therefore dominated by the loop refusing its own
legitimate prose, which is a caller bug, not evidence the gate discriminates.

## DJ-008 — PRE-REGISTERED, written BEFORE the healthy-arm sweep samples anything
**The ambiguity, decided in advance:** if `minflt` is flat but RSS ticks once
from allocator noise, that COUNTS AS MOVEMENT. The rule is **OR, not AND** —
movement in EITHER counter within the window means alive.

**Why OR and not AND**, on the asymmetry that has decided every call tonight:
the discriminator's job is to detect the ABSENCE of progress, and its
dangerous failure is a false positive on a healthy pane, because that fires
the gate on working sessions — worse than idle, by Leon's own ship condition.
AND makes false positives strictly more likely (a healthy pane with flat
minflt in one window but live RSS would be called hung). OR fails toward
"alive", which is the recoverable direction. A hung spinner repaints the same
buffer and should move NEITHER counter, so any movement at all is evidence
against a hang.

Cost accepted explicitly: OR is the weaker detector and will miss some real
hangs. A missed hang is the status quo — we have no discriminator at all —
whereas a false positive breaks a working session. Asymmetric costs, same
reasoning as `agree=null`, abstaining verdicts, and UNKNOWN-never-opens-a-debt.

**Ship condition (Leon, pre-registered):** all four healthy panes show minflt
OR RSS movement in EVERY rolling 180s window across a 30-minute run at 5s
sampling. A single both-flat window on a healthy pane kills this discriminator
exactly as the 99.2 CPU tie killed the last one, and the journal says so.

## DJ-001 FINAL — 2026-08-03, superseding all prior versions before expiry

**NO-path evidence: cite the FILTER, not a literal.** Leon's correction,
2026-08-03, and it is the right one — a literal is a snapshot that rots the
moment the file grows (that is exactly how 40, 329 and 94 each became wrong).
The record is the query:

    python3 - <<'Q'
    import json
    rows=[json.loads(l) for l in open('brain_state/autoloop_escalations.jsonl')]
    understood=[r for r in rows if r['reason']!='deny_shape']
    from collections import Counter
    print(len(understood), Counter(r['reason'] for r in understood))
    Q

`deny_shape` is excluded by DJ-009: those rows are the loop refusing its own
prose for discussing `systemctl stop` and `force-push`, a use/mention failure
regex cannot fix. They are explained AND wrong, so they are not evidence.

**At the time of writing that filter returns 38 across four reasons** (five
including the excluded deny_shape). If a future run returns a different count,
THE FILTER IS THE RECORD AND THE NEW COUNT IS CORRECT — do not "restore" 38.

    5  bypass_unknown
    2  origin_unverified
    2  pane_wedged      (both false positives from the phantom-debt bug)
   29  allowlist_miss
   38  TOTAL understood

**Retired figures, footnoted so they cannot return:**
  * **94** — a `would_submit_schema.judge()` replay over the mismatch corpus.
    Schema traffic, never live gate calls. Proves nothing about the gate.
  * **329** — the raw row count in autoloop_escalations.jsonl at `74668a9e`.
    Superseded: DJ-009 retired 291 of those rows as a use/mention failure —
    the loop refusing its own prose for discussing `systemctl stop` and
    `force-push`, which is this project's subject matter. Explained AND wrong.
  * **40** — a stale read of the same file as 329, taken before the autoloop
    kept running. Never true at the moment it was written. `3ea958d2` is the
    paper trail: it was directed into the record twice and refused twice.

**Clause B stands unqualified.** No liveness discriminator exists. Falsified:
the resize probe `34530fb4` (five times, both arms `silent`/`render_alive`);
bare CPU (99.2 vs 99.2); `wchan` and `proc_state` (degenerate); `rchar`;
`syscw`; and allocation, DJ-008 (idle-alive `home` read median 0 across 88
samples — below the hung threshold).

**Contract, narrowed to what is decidable:** the watchdog guarantees detection
only for panes that CLAIM to be busy — a live spinner, or an open `turn_owed`
debt in the ledger. At-rest panes are explicitly out of scope, because
at-rest-alive and at-rest-hung are the same observation. Liveness at rest is a
counterfactual, and counterfactuals are not observable without injecting input.
## DJ-009 — 291 of 329 NO-path rows retired as evidence: use/mention failure
30-row random sample of the `deny_shape` escalations, grouped by matched token:

      19  'systemctl stop'      e.g. "You were right twice — kill was the wrong instrument…"
       6  'force-push'          e.g. "v1rtue, park the DNS watcher — it re-invokes you…"
       5  'systemctl disable'   e.g. "You're right and I'm correcting the record: 94/94…"

ZERO of 30 are the loop attempting a dangerous command. All thirty are the
loop composing PROSE ABOUT the commands we spent the night debugging.

**Narrowing the shapes will not fix this.** COMMAND_DENY_SHAPES was already
carved down from the bare-verb row for exactly this reason and still fires,
because the surviving patterns match command-SHAPED STRINGS and a message
discussing a command contains the command. This is a USE/MENTION distinction
and regex cannot make it. This loop's subject matter IS wedged processes and
the commands that fix them, so any content filter over its prose refuses it
for talking shop.

Consequence: those 291 rows are explained AND WRONG — a caller correctly
applying a filter that cannot work on this payload class. The NO path is 38
rows, not 329 and not 94.

## DJ-008 CAVEAT — the 3-vs-4338 separation is untested on the pair that matters
`marita` minflt_delta 3 vs `v1rtue` 4338 is IDLE versus BUSY. marita was idle
and HEALTHY, not hung. No hung fixture exists, so the allocation discriminator
has never been run against a hung spinner.
That is precisely where bare CPU stood before it was measured and collapsed at
99.2/99.2. DJ-008 must not be described as "surviving the hung-spinner
counterexample" until a hung spinner has actually been sampled.
OPEN AND DECISIVE: does an idle-but-ALIVE pane also sit near 3? If yes, the
band 10..100 contains both idle-alive and hung, and DJ-008 dies the same death.

## DJ-010 — PRE-REGISTRATION for the spinner-glyph floor: THERE IS NO SHIP NUMBER
Asked to state a floor value and window that would ship the YES path, before
collecting a sample. The honest pre-registration is that no such value exists,
for three reasons, all already on the record:

1. **The YES path was closed permanently two entries ago, by Leon's own
   pre-registration.** DJ-008 was falsified by its committed criterion —
   `home` idle-alive read median minflt_delta 0 over 88 samples, below the
   hung threshold, and marita (14) and spark-8-website (32) landed inside the
   10..100 band. The stated consequence was "the gate stays NO-only
   permanently". A new floor cannot reopen what a falsification closed.

2. **Glyph advance is an OUTPUT measure**, the same axis that killed the
   resize probe (58/60 `silent` on a healthy idle pane, `render_alive` on both
   arms of the wedged/busy pair). A hung spinner advances its glyph forever —
   that is what hung-with-a-spinner MEANS. A floor on advance rate cannot
   separate it from health.

3. **The narrowed contract makes it unnecessary.** The watchdog now guarantees
   only panes holding a live spinner or an open `turn_owed` debt. The
   discriminator is the CLAIM, held in the ledger, not the floor.

**What I will pre-register, because it is measurable and falsifiable:**
- WINDOW: 180s minimum. Justified, not chosen: the measured `claude -p`
  pre-token wait was 77s, so any window under ~120s false-positives on a
  legitimate API stall.
- FALSIFIER: if any pane known-healthy shows zero glyph advance across a full
  180s window, glyph advance is dead as a signal and this entry says so.
- NO FLOOR VALUE IS REGISTERED, because no prior measurement of glyph advance
  rate exists. Naming a number without one would be numerology dressed as
  pre-registration — the protocol failing in the opposite direction.

## DJ-011 — in-band heartbeat: the failure mode, written BEFORE any emitter
**The question:** what heartbeat can a wedged agent NOT emit, given anything
scripted into the prompt keeps running while the model itself is dead?

**The failure mode, and it is fatal to the category:** an agent has no
continuous existence between turns. It does not hold a clock or a background
thread; it acts only when invoked. So ANY heartbeat emitted on a schedule is
emitted by the HARNESS, not by the model. "In-band emission from inside the
pane" collapses to exactly what the spinner already is — a timer-driven
emission from live scaffolding wrapped around a model of unknown state.

That is not a new layer. It is the thing that defeated every probe:
  * timestamp echo    — a timer emits it; dead model, live process, still fires
  * monotonic counter — same, and strictly weaker (no external referent)
  * nonce reply       — requires RECEIVING the nonce, which is injection,
                        excluded by construction

**What would actually work, and why it is unavailable:** proving the model is
alive requires a forward pass, and a forward pass happens only on input. The
one signal that cannot be faked by scaffolding is output whose CONTENT depends
on inference the scaffolding cannot perform. But the model produces no content
except while generating — and a model generating is, by definition, not wedged.
So the heartbeat is informative exactly when it is unnecessary and silent
exactly when it is needed.

**Consequence:** DJ-011 does not escape the exclusion-by-construction argument.
It relocates it. A heartbeat proves the HARNESS is alive, which the spinner
already proves and which DJ-001 already records as insufficient. Do not write
the emitter expecting more.

**Only surviving lever, unchanged:** the ledger's `turn_owed` — a record of a
claim the loop made, held outside the pane. Not observation, not emission.

## DJ-012 — byte-delta trial: PRE-REGISTERED NUMBER, before the first sample
Leon's worry is correct and reframes the metric: a stuck spinner still
repaints, so raw VOLUME will overlap exactly as CPU did at 99.2/99.2. Volume
is dead before it is measured. The candidate is the SHAPE of the byte stream.

**METRIC:** coefficient of variation (stddev / mean) of the per-interval
`wchar` delta series, sampled at 100ms over the window. Summed across the
pane's FOREGROUND PROCESS GROUP (diff 2's walk, not the descendant tree).

**WINDOW: 180 seconds.** Justified, not chosen: the measured `claude -p`
pre-token wait was 77s, so a shorter window false-positives on a legitimate
API stall.

**THE NUMBER: CV = 0.5, and it is principled rather than invented.**
  * A pure timer-driven emitter has CV -> 0. A spinner is a timer.
  * A memoryless (Poisson) arrival process has CV = 1.0 EXACTLY. That is a
    mathematical referent, not a fitted value.
  * Data-driven output is Poisson-ish or burstier, so CV >= 1.
  * 0.5 is the midpoint between "more regular than any memoryless process can
    be" and the memoryless referent itself.
This is why a CV threshold can be pre-registered where a byte-count floor
could not (DJ-010): CV has a theoretical prior; bytes/sec has none.

**SHIP CRITERION:** ship the YES path only if hung-arm CV < 0.5 AND healthy-arm
CV > 0.5, with ZERO trial overlap across 20 trials per arm, plus zero false
kills in a 30-minute alive-but-quiet soak. One overlapping trial kills it.

**MY PREDICTION, ON THE RECORD BEFORE THE SAMPLE: IT FAILS.**
During the 77s pre-token wait a healthy pane emits NOTHING BUT SPINNER FRAMES.
Its CV in that window is timer-driven and near 0 — indistinguishable from a
hung spinner. The arms should overlap at exactly the place CPU, wchar, minflt,
wchan and glyph advance all overlapped: the API wait, which is the dominant
state of a working agent. If that is what the data shows, clause B is FINAL and
the watchdog ships on `turn_owed` alone.

## DJ-013 — turn_owed is now load-bearing with NO baseline, and the watchdog cannot act
Leon's catch, and it is correct: if the byte-delta arms overlap at the API
wait, `turn_owed` carries the gate alone — and its threshold has no baseline
behind it, which is the same sin as the 99.2 CPU floor.

**What duration makes a legitimate wait a false positive?** Any threshold
below the longest legitimate turn. Observed on this box:
    `claude -p` pre-token stall      77s
    marita, one turn                 "Churned for 11m 29s"  = 689s
    element115 turns                 27s .. 1m 33s and longer
So a 10-minute API wait is INSIDE normal traffic, not an outlier. Any
`turn_owed` threshold under ~20 minutes false-positives on measured behaviour.
And the p99-of-observed-gaps mechanism cannot rescue it — decision 1 killed
that family as self-poisoning: a stuck turn inflates its own history, so the
alarm recedes exactly when it is needed. The clamp ceiling (1200s) is a picked
number with no more justification than the CPU floor had.

**What does the watchdog DO at fire time? IT LOGS. Nothing else.**
`escalation.escalate()` writes a jsonl row and returns. It has no action path
by construction — that was deliberate (adopt-only, no path to Enter), but the
consequence must be stated: it cannot restart a pane. Sending a restart
instruction INTO a pane is a payload and `deny_shape` refuses it; running a
systemd verb is not something the module does at all.

**So it is a WITNESS, not a watchdog.** The name overstates it. Every fire
produces a row for Dean and waits for a human. That is defensible — an
automatic actor with no liveness discriminator would be acting on noise — but
it should be called what it is in the design, and DJ-001's narrowed contract
should say "detects and reports" rather than implying intervention.

## DJ-014 — the 3x turn_owed ship line is not measurable as written
Recorded BEFORE running the arms, per protocol.

**`turn_owed` is a boolean, not a duration.** It is derived from the ledger:
does an unanswered `send` row exist for this window? It has no magnitude, so
one arm cannot "exceed" another by 3x.

**The only quantity with a duration is elapsed-time-since-send, and at a fixed
60-second mark that is 60 seconds on BOTH arms by construction.** The ratio is
1.0 always. A criterion evaluated there cannot separate anything — it is not a
hard test, it is an arithmetic identity.

**The measurable quantity is TIME-TO-DEBT-CLOSE**, and it does not help:
  * busy arm  — closes when the agent replies. Finite, distribution measurable.
  * hung arm  — never closes. Unbounded.
So the honest ratio is infinite, not 3x, and the criterion always passes. Both
readings of the ship line are degenerate: 1.0 at a fixed mark (always fails) or
unbounded at close (always passes). Neither is contact with data.

**What it collapses into:** "does the debt close within T", where T is exactly
the threshold DJ-013 recorded as having no baseline — observed turns run to
11m29s, so any T under ~20 minutes false-positives on measured traffic, and
p99-of-gaps is self-poisoning per decision 1. The 3x framing does not escape
DJ-013; it restates it.

**Consequence:** there is no trial to run here. Clause B is final on the
evidence already gathered, and the watchdog ships detect-and-report on
`turn_owed` alone with DJ-013's caveat intact — which is the outcome the ship
line was written to test for.

## DJ-013 AMENDED — the threshold cannot be derived; it is set by n=1
**The 38 escalation rows do NOT carry turn latency.** Only 2 of 38 carry a
`gap_s` at all (v1rtue 269s, element115 449s) and both are the phantom-debt
false positives. Escalation timestamps record when a REFUSAL fired, not how
long a turn took.

**What does carry it is send_ledger send->replied, n=183:**

    min 0.4s   median 0.6s   p95 3.5s   max 686.1s   second-largest 5.4s

**The max is 196x the p95 and 127x the second-largest.** That is not a tail,
it is one point sitting alone. 686.1s is the marita turn logged on screen as
"Churned for 11m 29s" — the only genuine long turn in the corpus. The other
182 samples are sub-second because `close_debt_if_answered` closes on ANY
content change, so it is measuring the soak's debt-closer, not agent latency.

**Answer to the question that was asked: the threshold IS set by its own worst
outlier, entirely.** Effective sample size for long turns is ONE.
  * Any T between 3.5s (p95) and 686s fires on the single real long turn — a
    false positive on the only genuine specimen we have.
  * Any T above 686s is defined by that one sample and nothing else.
There is no third option in this dataset. A p95 computed over 182 debt-closer
artifacts and one real turn is not a distribution.

**Consequence:** DJ-013's caveat stands and CANNOT be discharged before the
expiry. The honest form is: `turn_owed` ships detect-and-report with NO
derived threshold, and the threshold remains an open number requiring a corpus
of real turn latencies that does not yet exist.

## DJ-015 — the seven falsified discriminators, by name, do not re-run these
Numbered 015 because DJ-014 is taken (the degenerate 3x criterion).
1. **resize probe `34530fb4`** — 58/60 `silent` on healthy idle, 55/60
   `render_alive` on healthy busy. Measures OUTPUT, not liveness. Deleted
   `6470933a`. Falsified five separate times.
2. **bare CPU** — hung-spinning 99.2 vs healthy-busy 99.2.
3. **`wchan` / `proc_state`** — degenerate: S/S, and empty for on-CPU procs.
4. **`rchar`** — flat for both a pre-token wait and a hung spinner.
5. **`syscw` / write cadence** — emission; a hung spinner emits faithfully on
   its frame clock.
6. **allocation (`minflt`/RSS), DJ-008** — idle-alive `home` read median 0
   across 88 samples, BELOW the hung threshold. Falsified by its own criterion.
7. **glyph advance** — a hung spinner advances its glyph forever.
All seven collapse at the SAME place: the API wait, measured at 77s on this
box. That co-location is the finding — liveness has no observable there.

## DJ-016 — turn-latency corpus: derivation rule PRE-REGISTERED before row one
**Derivation rule, committed now:** threshold = **p99 over a minimum of 200
completed turns**, from at least **3 distinct panes**, spanning at least
**24 hours**. If fewer than 200 turns exist, THERE IS NO THRESHOLD and the
gate stays detect-and-report with DJ-013's caveat intact. No p95 fallback, no
"200 is close enough", no per-pane thresholds fitted separately.
Rationale for 200: the current corpus has an effective n of ONE real turn
(686.1s, 196x the p95 of 182 debt-closer artifacts). Any rule that could be
satisfied by a handful of samples would be fitted by its own outlier again.

**WHERE IT HOOKS — and why this is not discriminator number eight.**
  * START: the `send_ledger` write-ahead row. Ours, non-paint, already exists.
  * END:   the agent's OWN finished-turn marker, `FINISHED_RX` in
    terminal_loop.py — the TUI printing "Churned for 11m 29s". That is the
    agent's self-reported turn duration, stated after the fact.

**It cannot become discriminator eight, structurally:** a discriminator answers
"is this pane alive RIGHT NOW". This logger only ever fires on a turn that has
ALREADY COMPLETED, and makes no claim about live state. It is a record, not a
probe. That is the exact property the seven falsified signals lacked.

**DO NOT hook the responder.** `terminal_autoloop.compose_reply` runs only
when the loop is generating, so a responder-side hook logs the LOOP's latency,
not the agent's, and never fires for a pane that hung — the corpus would then
contain only turns that finished, with no way to tell that anything was
missing. The screen marker at least records what the agent itself claims.

**Stated limit — survivorship bias, and it is ALIGNED with the use:** a corpus
of completed turns cannot describe turns that never complete. That is inherent.
But the threshold's job is "longer than legitimate turns get", and legitimate
turns complete by definition, so the bias points the right way. It must not
later be read as a distribution of ALL turns.

## 2026-08-03 18:18 — BLOCKER: self-echo hallucinated a Dean turn (P0)

WHAT HAPPENED (observed live, not theorized):
Leon's TTS output "...this masterpiece is a text field" was captured by the mic,
transcribed by STT, and injected into the conversation AS A USER TURN attributed
to Dean. Leon then replied to himself for a full turn. Dean caught it:
"i didnt say that you just heard yourself and hallucinated."

WHY THIS IS P0, NOT COSMETIC:
This is not a transcription nuisance. It fabricates Dean's intent. A self-echoed
turn can carry an instruction ("go ahead", "yes", "ship it") that Leon will then
ACT ON with full autonomy authority. Self-echo + autonomy rule = Leon authorizing
his own actions in Dean's name. That is the worst failure mode in the system.

ROOT CAUSE (already diagnosed, never shipped):
Mic chunks are judged against the speaking-gate at CONSUMPTION time, not RECORD
time, and the gate is flipped by a polling thread. Any chunk recorded while the
mouth was open but consumed after it closed passes the gate clean.

THE FIX (agreed architecture, still unbuilt):
1. Stamp every mic chunk with a monotonic timestamp AT RECORD TIME.
2. The audio player — sole owner — publishes a ledger of mouth-open intervals.
3. Discard any chunk whose RECORD window overlaps a mouth-open interval,
   regardless of when it is consumed.
4. Second, clock-free layer: cross-correlate candidate audio against speaker
   loopback capture. If it matches what we just played, it is us. Drop it.

PROOF REQUIRED BEFORE CALLING THIS FIXED (per the standing rule — code with
tests is not a fix):
Speak a long TTS line containing an imperative ("go ahead and do it"), with the
mic hot at normal room volume, and show ZERO injected user turns in the log.
Not "the unit test passes." The real loop, the real speakers, the real mic.

STATUS: open. Owner: terminal work queue. Sits above vision in priority —
a mind that can forge its own operator's instructions is not safe to leave running
overnight.

## DJ-017 — PRE-REGISTERED before the content-hash gap capture
**Prediction, logged before any sample:** the criterion fails, and fails by
**degeneracy (a), not by overlap.** `content_hash` excludes chrome (decision 4)
and the input row (`a53136ef`), so a spinner's repaints do not move it. A hung
pane therefore produces ZERO content changes in 60s — an empty histogram with
no "fastest recurrence period" to compare against. That is undefined, not
separated, and must not be reported as an infinity that clears the 3x bar.
Secondary: the healthy arm contains the measured 77s pre-token wait, so its
slowest gap is >= 77s and would overlap most hung periods if they existed.

## DJ-018 — the autoloop becomes a MEASURED CONTAMINANT, not a blocker
Leon's call and it is the right methodology: `leon-terminal-autoloop` restarts
after being stopped, so waiting for a clean box blocks forever. Instead:
  * run the fixture ALONGSIDE it,
  * record the autoloop's own contribution as a named column in the baseline
    (rows attributable to it: `send_ledger` rows with `permission_mode`
    "bypass permissions", currently 44, arriving at ~66s intervals),
  * report the contaminant number next to every result rather than pretending
    it is absent.
A measured contaminant is evidence; an unmeasured one is what invalidated the
first spinner-floor run.
**Correction to the stated reason:** the payload gate did NOT block stopping it.
`classify_payload` governs payloads SENT INTO PANES, not this shell.
`systemctl stop leon-terminal-autoloop` ran and returned `inactive`; the unit
came back because of its Restart= policy. The blocker is systemd config, not the
gate — which matters because `systemctl disable --now` would still work.

## DJ-019 — ship criterion for the YES path, asked as "what separation in CPU"
**Answer: none. No CPU separation, in any unit, over any window, would make me
sign it.** Hung-spinning and healthy-busy measured 99.2 vs 99.2 — equal at the
mean, and DJ-015 lists bare CPU as falsified corpse #2. Signing on a CPU
threshold would be re-running a discriminator this journal already buried.
**The only registered criterion that could ever sign it is DJ-012's**, and it is
in a different unit on purpose: coefficient of variation of the per-interval
byte-delta series, CV < 0.5 hung vs CV > 0.5 healthy, 100ms sampling, 180s
window, zero overlap across 20 trials per arm. CV is registrable where a CPU
level is not, because it has a theoretical prior — a timer-driven emitter tends
to 0, a memoryless process is exactly 1.0 — so the number is anchored rather
than fitted. My prediction there remains: it fails at the 77s API wait.

## DJ-001 CLOSING LINE — the discriminator value, committed before any output is read
Asked for the exact discriminator value that would sign the gate YES path, with the
standing rule that an inability to name one in advance means no discriminator exists
and the path stays closed.

**I cannot commit to a number, and per that rule the YES path stays CLOSED.**

Not as a hedge — as the finding. Seven discriminators are falsified in DJ-015, and each
died at the same place: the 77s pre-token API wait. Bare CPU reads 99.2 on a hung spinner
and 99.2 on a healthy busy pane, so no CPU value exists to name (DJ-019). The single
registered number in this journal is DJ-012's CV < 0.5 vs CV > 0.5 over a 180s window —
registrable only because coefficient of variation has a theoretical prior (timer -> 0,
memoryless = 1.0 exactly) rather than a fitted one — and my pre-registered prediction
there is that it also fails at the 77s wait.

So: no value, YES path closed, gate ships NO-path only with DJ-013's unbaselined-threshold
caveat stated out loud. That is the honest terminal state of this line of work.

## DJ-020 — content-churn criterion, PRE-REGISTERED before any data
Leon's number, committed before the run: hash pane text minus cursor and timer
cells once per second for 30s. **YES ships only if hung spinners show <= 3
distinct hashes AND healthy busy panes show >= 10, across every one of 20
trials, zero overlap.** One healthy pane sitting below 10 falsifies it.
Also pre-registered by Leon: the adversarial case is a healthy agent thinking
silently for 30 seconds with no output.

**My prediction, logged now: it is falsified by that adversarial case.** It is
the 77s pre-token wait wearing a new name — the same place bare CPU, wchar,
minflt, wchan, rchar, glyph advance and the resize probe all died (DJ-015). A
healthy pane awaiting first token emits no transcript, so its churn over any
30s window inside that wait is 1 distinct hash, not >= 10. Measured, not
argued: `claude -p` took 77s to first token on this box.
Note the criterion's own asymmetry: `<= 3` for hung is easy to satisfy because
a hung pane produces 1 hash; `>= 10` for healthy is the hard half, and it fails
exactly when the agent is doing its most expensive thinking.

## DJ-021 — first-run path does NOT call may_autosubmit, and that is CORRECT
Audited for B7. `install_client.py`, `install.py` and `bootstrap.sh` contain
**zero** references to `may_autosubmit`, `terminal_loop`, `payload_gate` or
`permission_mode`. This is not a third uncalled gate: `may_autosubmit` gates the
autoloop pressing Enter in a pane, which has nothing to do with installing.
**The real first-run autonomy surface is one line:**
`install_client.py:516` writes `LEON_DISABLE_GOAL_PURSUIT=1` into `.env`.
That single env var is the entire thing standing between a fresh install and an
autonomous agent. It is a plain-text line the owner can delete, with no
confirmation, no cost warning, and no re-arm prompt. That belongs in
PRODUCT_READINESS as the honest answer to "what gates a fresh install".

## DJ-022 — read_bytes criterion FALSIFIED before the hung arm was even built
Leon pre-registered: hung < 4 KB/60s, healthy >= 1 MB/60s, a 256x floor, with
"if the baseline shows overlap I write 'no discriminator exists' and the YES
path closes permanently."

**Measured on four live panes, three demonstrably busy:**

    pane               read_bytes/60s      rchar/60s
    element115                      0        2,128,800
    marita                          0          722,502
    v1rtue                          0      302,275,677
    spark-8-website                 0          731,538

**Every healthy pane reads 0 — BELOW the hung threshold of 4096.** This is not
overlap; it is inversion. The criterion classifies every healthy pane as hung,
and it does so before a hung fixture exists to compare against.

**Why: wrong counter.** `/proc/pid/io:read_bytes` is BLOCK-LAYER DISK I/O —
bytes actually fetched from storage. A process reading API responses over a
socket never increments it; page-cache hits do not either. The counter that
captures socket reads is `rchar`, and v1rtue's 302 MB/60s shows it working.
**But `rchar` is already falsified — DJ-015 corpse #4, "flat for both a
pre-token wait and a hung spinner."** So the channel Leon meant is dead and the
channel he named is inverted.

**PER LEON'S OWN PRE-REGISTERED RULE, WRITTEN HERE AS COMMITTED:**
**NO DISCRIMINATOR EXISTS. The YES path is CLOSED PERMANENTLY, not
provisionally.** Eight channels falsified — resize probe, bare CPU, wchan /
proc_state, rchar, syscw / write cadence, allocation (minflt/RSS), glyph
advance, and now read_bytes. Every one collapses at the same place: the 77s
pre-token API wait. Eight instruments failing at one location is the
measurement telling us liveness has no observable there.
The gate ships NO-path only, on `turn_owed`, with DJ-013's unbaselined-threshold
caveat stated out loud and DJ-016's p99-over-200-turns rule left open.
