# Prediction, committed BEFORE running — Claude, 2026-08-03

Leon: "which of the three specimens does the cursor_x>2 mechanical read
misclassify, because if the answer is none we didn't need the rubric, and if
you can't predict it we don't understand our own gate."

Written before opening the three files. Falsifiers stated so this can be
scored rather than argued.

## P1 — The mechanical read misclassifies NONE of them, and cannot.
A `.txt` capture carries no cursor. `unsubmitted_text()` needs
`tmux display-message`, so on a file it does not run at all. That is an
ABSTENTION, not a misclassification. Falsified if the cursor read produces
any verdict other than "cannot run" on a fixture file.

## P2 — "None" does NOT mean the rubric was unnecessary.
The two gates answer different questions and are serial, not redundant:
  rubric      : may we submit into this pane at all? (permission mode)
  cursor read : is someone's unsent draft sitting in the box?
A pane in plan mode with a human's draft in the box must be refused, and
only the cursor read can see that. They never disagree because they are not
answering the same question — a seatbelt and a fire extinguisher never
disagree either. Falsified if a case exists where one gate's answer makes
the other's redundant.

## P3 — THE SHARP ONE. All three specimens will agree with each other.
They were captured by cycling shift+tab on one pane, seconds apart, all at
ctx 95% with the same banner. So the prompt row should be IDENTICAL across
all three, and the answer to "which one" is structurally "all or none",
never "one of them". Falsified if any specimen's prompt row differs from
the other two.

## P4 — The paint reader will say False on all three (no residue).
`has_unsubmitted_input` reads paint, so it is the one that CAN misclassify.
I predict it does not, here: measured on the live probe pane today, a mode
change and a C-u both repaint the input row cleanly. Residue came from some
other path. So I expect zero mismatch rows from these three — and that is a
clean result, not a silent detector failure, because the v1rtue row landed
through this same code path today.
Confidence: moderate. This is the one I most expect to be wrong.
Falsified if any specimen's prompt row holds text that is not the greyed
`Try "…"` placeholder.
