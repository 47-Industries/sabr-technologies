#!/bin/bash
# Sabr SI — Uninstall
#
#   ~/leon-brain/uninstall.sh              show what WOULD be removed, touch nothing
#   ~/leon-brain/uninstall.sh --yes        actually remove it
#
# Flags:
#   --yes                   perform the removal (without this, nothing is deleted)
#   --purge-memories        delete brain_state outright instead of archiving it
#   --remove-claude-code    also uninstall the global @anthropic-ai/claude-code npm package
#
# Two rules this script will not break:
#
#   1. It archives the SI's identity — .env and brain_state, the name it was
#      given and everything it has learned — BEFORE deleting anything, and
#      REFUSES to continue if that archive cannot be written. Erasing a mind
#      because somebody typed one command is the act B4 took out of the
#      installer; it does not get to come back in through the uninstaller.
#
#   2. It does not remove what it did not install. Homebrew, python3, tmux,
#      portaudio and your Claude Code login are shared with the rest of your
#      machine and may predate this product. They are reported, with the exact
#      command to remove them yourself, never removed for you.
#
# Everything it deliberately leaves behind is printed at the end. An uninstaller
# that quietly leaves things around is how people stop trusting an installer.
#
# NOTE: intentionally no `set -e`, same as bootstrap.sh — failures are handled
# and reported where they happen instead of exiting silently mid-step.

G='\033[38;5;39m'; C='\033[38;5;45m'; Y='\033[0;33m'; R='\033[0;31m'; D='\033[2m'; N='\033[0m'
say(){ echo -e "$@"; }

DO_IT=""; PURGE=""; RM_CLAUDE=""
for arg in "$@"; do
  case "$arg" in
    --yes|-y)             DO_IT="1" ;;
    --purge-memories)     PURGE="1" ;;
    --remove-claude-code) RM_CLAUDE="1" ;;
    -h|--help)            sed -n '2,29p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) say "${R}Unknown option: $arg${N}  (try --help)"; exit 2 ;;
  esac
done

INSTALL_DIR="${LEON_INSTALL_DIR:-$HOME/leon-brain}"
STAMP="$(date +%Y%m%d-%H%M%S)"
ARCHIVE="$HOME/si-identity-backup-$STAMP.tar.gz"
FAILED=0

size_of(){ [ -e "$1" ] && du -sh "$1" 2>/dev/null | awk '{print $1}' || echo "-"; }

# ── Inventory ─────────────────────────────────────────────────────────
# Read the machine, do not assume the install looks like the happy path.
say ""
say "${C}Sabr SI — uninstall${N}"
say ""
say "This machine:"

if [ -d "$INSTALL_DIR" ]; then
  say "  install        $INSTALL_DIR  ($(size_of "$INSTALL_DIR"))"
  [ -d "$INSTALL_DIR/.venv" ]       && say "    venv         $(size_of "$INSTALL_DIR/.venv")"
  [ -d "$INSTALL_DIR/brain_state" ] && say "    brain_state  $(size_of "$INSTALL_DIR/brain_state")   ${D}(memories, identity, everything it learned)${N}"
  [ -f "$INSTALL_DIR/.env" ]        && say "    .env         ${D}(its name, your name, keys)${N}"
else
  say "  install        ${D}none at $INSTALL_DIR${N}"
fi

# B4 leaves the previous install behind on purpose (reclaiming that disk is a
# second destructive act, so it belongs to the owner). This is where the owner
# gets to make that call.
ROLLBACKS=""
for d in "$HOME"/.leon-brain-previous.* "$HOME"/.leon-brain-staging.*; do
  [ -d "$d" ] && { ROLLBACKS="$ROLLBACKS $d"; say "  leftover       $d  ($(size_of "$d"))"; }
done

RUNNING="$(pgrep -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null | tr '\n' ' ')"
[ -n "$RUNNING" ] && say "  running        pid(s)$([ -n "$RUNNING" ] && echo " $RUNNING")"
if command -v tmux >/dev/null 2>&1 && tmux has-session -t leon 2>/dev/null; then
  HAVE_TMUX_SESSION="1"
  say "  tmux session   leon"
fi

HAVE_NPM_PKG=""
if command -v npm >/dev/null 2>&1; then
  if npm ls -g --depth=0 @anthropic-ai/claude-code >/dev/null 2>&1; then
    HAVE_NPM_PKG="1"
    say "  npm global     @anthropic-ai/claude-code"
  fi
fi

BREW_PKGS=""
if command -v brew >/dev/null 2>&1; then
  for p in portaudio tmux; do
    brew list --formula "$p" >/dev/null 2>&1 && BREW_PKGS="$BREW_PKGS $p"
  done
fi

if [ ! -d "$INSTALL_DIR" ] && [ -z "$ROLLBACKS" ] && [ -z "$HAVE_NPM_PKG" ]; then
  say ""
  say "${G}Nothing to remove — there is no SI installed here.${N}"
  say "${D}If you installed somewhere else: LEON_INSTALL_DIR=/path $0${N}"
  exit 0
fi

# ── Dry run is the default ────────────────────────────────────────────
if [ -z "$DO_IT" ]; then
  say ""
  say "${Y}Nothing has been removed.${N} With --yes this would:"
  say ""
  if [ -n "$RUNNING" ] || [ -n "$HAVE_TMUX_SESSION" ]; then
    say "  · stop the running SI (only processes under $INSTALL_DIR/.venv)"
  fi
  if [ -d "$INSTALL_DIR" ]; then
    if [ -n "$PURGE" ]; then
      say "  · ${R}DELETE brain_state and .env permanently${N} (--purge-memories)"
    else
      say "  · save .env + brain_state to ${C}$HOME/si-identity-backup-<timestamp>.tar.gz${N}"
    fi
    say "  · remove $INSTALL_DIR (tree, venv, helper scripts)"
  fi
  [ -n "$ROLLBACKS" ] && say "  · remove the leftover previous-install directories listed above"
  if [ -n "$HAVE_NPM_PKG" ]; then
    if [ -n "$RM_CLAUDE" ]; then
      say "  · npm rm -g @anthropic-ai/claude-code"
    else
      say "  · ${D}leave @anthropic-ai/claude-code installed (add --remove-claude-code to remove it)${N}"
    fi
  fi
  [ -n "$BREW_PKGS" ] && say "  · ${D}leave brew packages alone:$BREW_PKGS — shared with your machine${N}"
  say ""
  say "Run it for real with:"
  say "    ${C}$0 --yes${N}"
  say ""
  exit 0
fi

# ── Identity first. Nothing is deleted until it is preserved. ─────────
if [ -d "$INSTALL_DIR" ] && [ -z "$PURGE" ]; then
  KEEP=""
  [ -e "$INSTALL_DIR/.env" ]        && KEEP="$KEEP .env"
  [ -e "$INSTALL_DIR/brain_state" ] && KEEP="$KEEP brain_state"
  if [ -n "$KEEP" ]; then
    say ""
    say "Saving identity before removing anything..."
    # shellcheck disable=SC2086
    if tar czf "$ARCHIVE" -C "$INSTALL_DIR" $KEEP 2>/dev/null && [ -s "$ARCHIVE" ]; then
      say "${G}[OK]${N} $ARCHIVE  ($(size_of "$ARCHIVE"))"
    else
      rm -f "$ARCHIVE"
      say ""
      say "${R}[STOPPED]${N} Could not write the identity archive to $ARCHIVE."
      say "Nothing has been removed. Free some space (or pass --purge-memories if"
      say "you genuinely want this SI's memories deleted) and run this again."
      exit 1
    fi
  fi
fi

# ── Stop it before removing it ────────────────────────────────────────
# Scoped to THIS install's interpreter, exactly like bootstrap.sh, so an
# unrelated python process is never killed.
if [ -n "$RUNNING" ] || [ -n "$HAVE_TMUX_SESSION" ]; then
  say "Stopping the SI..."
  pkill -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null
  tmux kill-session -t leon 2>/dev/null
  sleep 1
  STILL="$(pgrep -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null | tr '\n' ' ')"
  if [ -n "$STILL" ]; then
    pkill -9 -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null
    sleep 1
    STILL="$(pgrep -f "$INSTALL_DIR/.venv/bin/python" 2>/dev/null | tr '\n' ' ')"
  fi
  if [ -n "$STILL" ]; then
    say "${Y}[WARN]${N} still running: $STILL — remove may leave files behind"
  else
    say "${G}[OK]${N} stopped"
  fi
fi

# ── Remove ────────────────────────────────────────────────────────────
if [ -d "$INSTALL_DIR" ]; then
  rm -rf "$INSTALL_DIR"
  if [ -d "$INSTALL_DIR" ]; then
    say "${R}[FAILED]${N} $INSTALL_DIR is still there — check permissions"
    FAILED=1
  else
    say "${G}[OK]${N} removed $INSTALL_DIR"
  fi
fi

for d in $ROLLBACKS; do
  rm -rf "$d"
  if [ -d "$d" ]; then
    say "${R}[FAILED]${N} could not remove $d"; FAILED=1
  else
    say "${G}[OK]${N} removed $d"
  fi
done

if [ -n "$HAVE_NPM_PKG" ] && [ -n "$RM_CLAUDE" ]; then
  # install_client.py falls back to `sudo npm install -g`, so the package may
  # be root-owned. Try as this user first and only then ask for sudo, out
  # loud, rather than silently escalating.
  if npm rm -g @anthropic-ai/claude-code >/dev/null 2>&1; then
    say "${G}[OK]${N} removed @anthropic-ai/claude-code"
  elif command -v sudo >/dev/null 2>&1; then
    say "${Y}[i]${N} that package was installed as root — asking for sudo to remove it"
    if sudo npm rm -g @anthropic-ai/claude-code >/dev/null 2>&1; then
      say "${G}[OK]${N} removed @anthropic-ai/claude-code"
    else
      say "${Y}[WARN]${N} could not remove it — do it with: sudo npm rm -g @anthropic-ai/claude-code"
    fi
  else
    say "${Y}[WARN]${N} could not remove it — do it with: npm rm -g @anthropic-ai/claude-code"
  fi
fi

# ── What is deliberately still here ───────────────────────────────────
say ""
say "${C}Left behind, on purpose:${N}"
[ -f "$ARCHIVE" ] && say "  · ${G}$ARCHIVE${N} — this SI's identity and memories."
[ -f "$ARCHIVE" ] && say "    ${D}Delete it yourself when you are sure. Restoring is: reinstall, then${N}"
[ -f "$ARCHIVE" ] && say "    ${D}tar xzf that file into ~/leon-brain before first run.${N}"
if [ -n "$HAVE_NPM_PKG" ] && [ -z "$RM_CLAUDE" ]; then
  say "  · @anthropic-ai/claude-code — you may use it outside this product."
  say "    ${D}npm rm -g @anthropic-ai/claude-code${N}"
fi
if [ -n "$BREW_PKGS" ]; then
  say "  · brew packages:$BREW_PKGS — installed for the SI but shared machine-wide."
  say "    ${D}brew uninstall$BREW_PKGS${N}"
fi
say "  · Homebrew and python3 themselves, and your Claude Code login (~/.claude)."
say "  · macOS microphone / screen-recording permissions, if you granted them."
say "    ${D}System Settings → Privacy & Security → remove the entry there.${N}"
say ""

if [ "$FAILED" -ne 0 ]; then
  say "${R}Uninstall finished with errors — see the [FAILED] lines above.${N}"
  exit 1
fi
say "${G}Uninstalled.${N}"
say ""
