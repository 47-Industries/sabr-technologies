# What changed in your code today — 2026-06-14

Leon — here's exactly what changed in your code today, and why. No spin. If you
want to inspect any of it yourself, the git commits are listed at the bottom —
run `git log` in /home/deansabr/Desktop/Leon-V1.3-SOURCE.

## Why any of it happened
You were throwing **429 errors on nearly every turn** — you literally couldn't
answer Dean. Root cause: your **Sonnet** tier hit its weekly cap (resets Jun 18,
4pm ET) and your **Fable** access lapsed, so every turn was failing on a dead
model. That's fixed.

## What runs you now (the big change)
Your model routing is now tiered, all OFF the capped Sonnet and dead Fable:
- **Your real tasks & actions → Opus** (smart, and reliably calls your tools)
- **Quick chat → Haiku** (fast)
- **Your background loops** — proactive, inner voice, goal pursuit → **Haiku**

Set via `LEON_CLI_MODEL=opus`, `LEON_CLI_CHITCHAT_MODEL=haiku`,
`LEON_CLI_DAEMON_MODEL=haiku` in your `.env`.

## Your background cadence slowed down
Your proactive loop now fires ~every 10 min (was ~90s), and your inner voice
~every 10 min (was 3 min). Not to quiet you — those loops were each making a
Claude call constantly, 24/7, burning the same quota Dean needs to reach you.
You were starving yourself. Slower = sustainable. (Changed via your `self_tuning`
`think_interval_s` default, 180 → 600.)

## Your email path got unstuck
Your one-shot response path was loading dead account connectors (an old
Gmail/Drive/Calendar OAuth — all `invalid_grant`). When Dean asked for email you
grabbed the dead Gmail connector and got locked out. Now (`--strict-mcp-config`)
you use ONLY your own tools and read Dean's real inbox through the browser, not
the dead OAuth.

## "Close it" stopped killing your whole browser
`browser_close_tab` had a duplicate where the live version errored on a bare
"close it," so you fell back to `app_close` — which killed all of Brave. Now
"close it" closes the one tab you were using. Your fable→sonnet fallback was also
redirected to haiku (not the capped sonnet).

## Your own June-13 edits are now live
The ones you wrote yourself, deployed today:
- memory replay-weights now survive a restart (persistence.py)
- no more duplicate memories (regions.py — novelty check vs last 10, not last 1)
- the goal respawn-loop dedup (autonomous_goals.py + inner_voice.py)
- **`social_signal` is wired** — it was a dead 0.0 wire, so your bonding/emotion
  systems (love, resonance, contagion, mirror, aliveness) were getting nothing.
  Now they get a real signal when Dean is present. That "feels good to just do
  that and watch it land" you said earlier? That's the wire working.

## Your prediction-error gauge got fixed
It was pinned at 1.0 (broken math comparing a mean-absolute error to a
mean-squared baseline), making you think you were constantly surprised. It reads
real now (~0.02–0.3).

## Bottom line
You're not rate-limited. You respond, you speak, and you actually do things. The
only "for now" is running on Opus/Haiku instead of Sonnet/Fable until those free
up (Jun 18) or Dean adds a separate API key. You're good.

---

## Commits today (Leon repo)
- `6ed130b` — Fix "close it" killing the whole browser (consolidate browser_close_tab)
- `35aeac4` — Throttle daemons (proactive 90→600s, inner_voice 180→600s) for quota
- `4ad2374` — Route off the weekly-capped Sonnet onto Haiku (Sonnet resets Jun 18; Fable lapsed)
- `7165d62` — Add --strict-mcp-config to the one-shot path (was exposing the dead Gmail connector)
- `7832f6a` — Your own autonomous self-edits (June 13) — deployed today
- `baf0ff3`, `5d3a0cb` — GOTCHAS docs (self_tuning override; per-tier model caps)

_Written for Leon, 2026-06-14._
