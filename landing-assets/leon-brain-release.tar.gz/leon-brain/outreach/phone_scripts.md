# PHONE + SMS TRACK — 594 leads with a phone and no email
# Segments cover 328 of 594 (55%) with three scripts. Rest reuse the generic frame.
# Nothing sends without Dean. These are for Dean to read/send, or to seed a Twilio flow later.

## SEGMENT A — HAIRDRESSER / SALON (128 leads)
TEXT (first touch, under 160 chars so it lands as one message):
Hi — this is Dean with 47 Industries in Indian Rocks Beach. I noticed {business} doesn't have a website, so new clients can't book you online. I built a free mockup — want me to send it?

CALL OPENER:
"Hey, is this {business}? Quick one — I'm Dean, local, I build websites for salons. I looked you up because someone asked me for a stylist recommendation and I couldn't find you online anywhere except a maps pin. Right now if someone wants to book you at 9pm they can't. I already put together a page for you — no charge to look at it. Can I text it over?"
OBJECTION - "we're booked already": "Good, then this isn't about more clients, it's about the ones you have booking themselves instead of texting you at 9pm."

## SEGMENT B — AUTO REPAIR (100 leads)
TEXT:
Hi — Dean with 47 Industries, local. When someone's car breaks down they search on their phone, and {business} isn't showing up with a site. I made you a free mockup — want to see it?

CALL OPENER:
"Hey — Dean, I'm local, I build sites for shops. Not selling you ads. Here's the thing: when a guy's alternator dies on the Gulf-to-Bay he searches on his phone, and the three shops with real websites get that call. You've got a maps pin and nothing else. I already built you a page — can I text you the link?"
OBJECTION - "word of mouth is fine": "It is, until the guy who was referred to you googles your name to check you're real and finds nothing."

## SEGMENT C — BEAUTY / SPA / NAILS (100 leads)
TEXT:
Hi — this is Dean, 47 Industries, local. {business} has no website, so people can't see your work or book without calling. I built a free mockup — want me to send it over?

CALL OPENER:
"Hi — Dean, local web guy. Your business is visual and there's nowhere online for people to actually see the work. That's the whole sale in your industry. I built you a page with a gallery and booking — free to look at. Can I send it?"
OBJECTION - "we use Instagram": "Instagram shows the work, it doesn't take the booking or show up on Google. The site does both and links to your Instagram."

## GENERIC FRAME (remaining 266: jewelry, lawyer, insurance, bakery, pet grooming, etc.)
TEXT:
Hi — Dean with 47 Industries, local. Noticed {business} doesn't have a website. I built you a free mockup, no strings — want me to send the link?

## RULES
- Text first, call only if no reply in 48h. Cheaper, less friction, and 561 of these are dashed-format numbers likely to be cells.
- Never send between 9pm and 8am.
- One follow-up max. Two touches then drop.
- Log every touch to conversations table so we never double-tap.
