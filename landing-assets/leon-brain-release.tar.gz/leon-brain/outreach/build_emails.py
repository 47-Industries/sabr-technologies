#!/usr/bin/env python3
"""Per-lead, ready-to-send outreach. Each email links to THAT lead's real mockup.
DRAFT ONLY — nothing is sent. Dean sends, or approves sending."""
import sqlite3, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from build_demo import slug, MAP

DB   = "/opt/leon-brain/business/data/business.db"
BASE = "https://mrcloudmedia.com/demo/"
OUT  = "/opt/leon-brain/outreach/ready_to_send.md"

BODY = {
 "barber": ("quick question about {name}",
"""Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed {name} doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

{url}

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries"""),
 "beauty": None, "trade": None, "pro": None, "retail": None,
}
BODY["beauty"] = BODY["barber"]
BODY["trade"] = ("{name} — not showing up when people search",
"""Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
{name} isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

{url}

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries""")
BODY["pro"] = ("{name} — a homepage I built for you",
"""Hi — I'm Dean, I build websites for Florida businesses.

{name} doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

{url}

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries""")
BODY["retail"] = ("{name} — built you a homepage, free look",
"""Hey — Dean here, I build websites for Florida businesses.

I noticed {name} doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

{url}

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries""")

rows = list(sqlite3.connect(DB).execute("""select business_name,industry,city,phone,email
    from leads where source='osm_overpass' and coalesce(email,'')!='' order by score desc"""))
demo_dir = "/opt/leon-brain/landing/demo"
out, missing = [], []
for name, ind, city, phone, email in rows:
    fn = slug(name) + ".html"
    if not os.path.exists(os.path.join(demo_dir, fn)):
        missing.append(name); continue
    theme = MAP.get(ind, "retail")
    subj, body = BODY[theme]
    url = BASE + fn
    out.append(f"### {name} — {city or 'FL'} ({theme})\n"
               f"TO: {email}\nSUBJECT: {subj.format(name=name)}\nMOCKUP: {url}\n\n"
               f"{body.format(name=name, url=url)}\n\n---\n")

with open(OUT, "w") as f:
    f.write("# READY TO SEND — one email per lead, each links to that lead's real mockup.\n"
            "# STATUS: DRAFT. Nothing sent. Requires Dean's approval.\n"
            f"# {len(out)} emails.\n\n" + "\n".join(out))
print(f"wrote {len(out)} emails -> {OUT}")
if missing: print("NO MOCKUP FOR:", missing)
