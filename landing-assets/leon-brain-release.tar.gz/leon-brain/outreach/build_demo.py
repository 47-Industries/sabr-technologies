#!/usr/bin/env python3
"""Stamp a demo homepage per lead. One template, many sites — the leverage play."""
import sqlite3, html, re, os, sys

OUT = "/opt/leon-brain/landing/demo"
DB  = "/opt/leon-brain/business/data/business.db"

THEMES = {
 "barber": dict(brand="#1b1b1f", accent="#c9a227", hero="Walk in. Look sharp. Leave happy.",
   sub="Fresh cuts, fades, beard work and hot towel shaves in {city}. Walk-ins welcome, appointments even better.",
   cta="Book a chair", svc=[("Haircuts","Classic, fade, taper — whatever you walk in asking for."),
     ("Beard &amp; Shave","Line-up, trim, and hot towel straight razor shaves."),
     ("Kids Cuts","Patient with the little ones. No drama, no wiggling."),
     ("Designs","Parts, patterns, and custom line work."),
     ("Color","Gray blending and full color."),
     ("Walk-ins","No appointment? Come through. We'll get you in.")]),
 "beauty": dict(brand="#2a1f2d", accent="#c77b9e", hero="Book your next appointment in ten seconds.",
   sub="Full service beauty in {city}. Lashes, nails, skin, and everything in between.",
   cta="Book now", svc=[("Lashes","Classic, hybrid, and volume sets with fills."),
     ("Nails","Manicures, pedicures, gel and acrylic."),
     ("Facials","Deep cleansing, hydrating, and anti-aging treatments."),
     ("Waxing","Face and body, quick and clean."),
     ("Brows","Shaping, tinting, and lamination."),
     ("Gift Cards","Available for any service.")]),
 "trade": dict(brand="#16202b", accent="#e07b39", hero="When it breaks, you need someone who answers.",
   sub="Serving {city} and the surrounding area. Fast response, honest pricing, licensed and insured.",
   cta="Call for a free estimate", svc=[("Emergency Service","Same-day response when things go wrong."),
     ("Repairs","Diagnosed properly the first time, not guessed at."),
     ("Installation","New systems installed to code and warrantied."),
     ("Maintenance","Scheduled service that stops problems before they start."),
     ("Inspections","Written reports with photos."),
     ("Free Estimates","No charge to come look and tell you what it'll take.")]),
 "pro": dict(brand="#12233a", accent="#3d6b9c", hero="Straight answers when it matters most.",
   sub="Serving clients across {city} and the surrounding counties. Consultations available this week.",
   cta="Request a consultation", svc=[("Consultations","An honest read on where you stand, before you commit."),
     ("Representation","Experienced advocacy from first filing to resolution."),
     ("Document Review","Careful review so nothing gets missed."),
     ("Filings","Prepared correctly and submitted on time."),
     ("Mediation","Resolution without the courtroom where possible."),
     ("Ongoing Counsel","Available when questions come up later.")]),
 "retail": dict(brand="#20261f", accent="#6f8f5a", hero="See what we make before you walk in.",
   sub="A local shop in {city} — real work, made and sold by people who care about it.",
   cta="Visit us", svc=[("Our Work","Made here, chosen carefully, priced fairly."),
     ("Custom Orders","Tell us what you're after and we'll make it happen."),
     ("Delivery","Local delivery available on most orders."),
     ("Special Occasions","Weddings, birthdays, and everything worth marking."),
     ("Gift Options","Wrapped and ready, same day."),
     ("Visit the Shop","Come see it in person. It's better that way.")]),
}
MAP = {"hairdresser":"barber","beauty":"beauty","roofer":"trade","plumber":"trade",
 "electrician":"trade","hvac":"trade","carpenter":"trade","car_repair":"trade",
 "remodeler":"trade","tiler":"trade","damage_restoration":"trade","builder":"trade",
 "electronics_repair":"trade","lawyer":"pro","estate_agent":"pro","accountant":"pro",
 "insurance":"pro","florist":"retail","bakery":"retail","furniture":"retail",
 "jewelry":"retail","garden_centre":"retail","pet_grooming":"retail",
 "embroiderer":"retail","watchmaker":"retail","photographer":"retail"}

TPL = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{name} — {city}</title><meta name="description" content="{name} in {city}. {cta}.">
<style>
:root{{--ink:{brand};--accent:{accent};--mut:#67707a;--line:#e5e8ec;--soft:#f7f8fa}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font:16px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:var(--ink)}}
.wrap{{max-width:1060px;margin:0 auto;padding:0 24px}}
.note{{background:#fffbe6;border-bottom:1px solid #f0e0a0;padding:12px;font-size:13px;color:#6b5a1e;text-align:center}}
header{{position:sticky;top:0;background:rgba(255,255,255,.96);backdrop-filter:blur(8px);border-bottom:1px solid var(--line);z-index:9}}
.nav{{display:flex;align-items:center;justify-content:space-between;height:66px}}
.logo{{font-weight:800;letter-spacing:-.02em;font-size:17px}}
.pill{{background:var(--accent);color:#fff;text-decoration:none;padding:10px 19px;border-radius:8px;font-weight:700;font-size:14px}}
.hero{{padding:82px 0 66px;background:linear-gradient(180deg,var(--soft),#fff)}}
.hero h1{{font-size:clamp(32px,5.2vw,50px);line-height:1.1;letter-spacing:-.03em;font-weight:800;max-width:17ch}}
.hero p{{margin:18px 0 30px;font-size:18px;color:var(--mut);max-width:54ch}}
.btn{{padding:14px 26px;border-radius:9px;text-decoration:none;font-weight:700;background:var(--accent);color:#fff;display:inline-block}}
section{{padding:72px 0;border-top:1px solid var(--line)}}
h2{{font-size:29px;letter-spacing:-.025em;font-weight:800;margin-bottom:34px}}
.grid{{display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(250px,1fr))}}
.card{{border:1px solid var(--line);border-radius:12px;padding:24px;transition:.15s}}
.card:hover{{border-color:#ccd3da;transform:translateY(-2px)}}
.card h3{{font-size:17px;font-weight:700;margin-bottom:7px}}
.card p{{color:var(--mut);font-size:15px}}
.cta{{background:var(--ink);color:#fff;text-align:center}}
.cta h2{{color:#fff;margin-bottom:10px}}.cta p{{color:#9aa6b2;margin-bottom:26px}}
footer{{padding:34px 0;color:var(--mut);font-size:14px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px}}
</style></head><body>
<div class="note">Concept mockup by 47 Industries — not a live site. Placeholder content; real photos and details would replace this.</div>
<header><div class="wrap nav"><div class="logo">{name_uc}</div><a class="pill" href="{contact_href}">{contact_label}</a></div></header>
<div class="hero"><div class="wrap"><h1>{hero}</h1><p>{sub}</p><a class="btn" href="{contact_href}">{cta}</a></div></div>
<section><div class="wrap"><h2>What we offer</h2><div class="grid">{cards}</div></div></section>
<section class="cta"><div class="wrap"><h2>{cta}</h2><p>We'd love to hear from you.</p><a class="btn" href="{contact_href}">{contact_label}</a></div></section>
<div class="wrap"><footer><div>{name} — {city}</div><div>Concept by <a href="https://47industries.com" style="color:inherit">47 Industries</a> — <a href="https://47industries.com" style="color:inherit">want this as your real site?</a></div></footer></div>
</body></html>"""

def slug(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')[:60]

def build(name, industry, city, phone, email):
    theme = THEMES[MAP.get(industry,"retail")]
    city = city or "Florida"
    if phone: href, label = "tel:"+re.sub(r'[^\d+]','',phone), phone
    else:     href, label = "mailto:"+email, "Email us"
    cards = "".join(f'<div class="card"><h3>{t}</h3><p>{d}</p></div>' for t,d in theme["svc"])
    return TPL.format(name=html.escape(name), name_uc=html.escape(name.upper()), city=html.escape(city),
        brand=theme["brand"], accent=theme["accent"], hero=theme["hero"],
        sub=theme["sub"].format(city=html.escape(city)), cta=theme["cta"],
        contact_href=href, contact_label=html.escape(label), cards=cards)

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    c = sqlite3.connect(DB)
    rows = list(c.execute("""select business_name,industry,city,phone,email from leads
        where source='osm_overpass' and coalesce(email,'')!='' order by score desc"""))
    built = []
    for name,ind,city,phone,email in rows:
        fn = slug(name)+".html"
        open(os.path.join(OUT,fn),"w").write(build(name,ind,city,phone,email))
        built.append((name, fn))
    print(f"built {len(built)} demos")
    for n,f in built[:6]: print("  ", n, "->", f)
