# READY TO SEND — one email per lead, each links to that lead's real mockup.
# STATUS: DRAFT. Nothing sent. Requires Dean's approval.
# 54 emails.

### Modern Wonders — Hialeah (trade)
TO: Modernwonders.llc@gmail.com
SUBJECT: Modern Wonders — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/modern-wonders.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Modern Wonders isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/modern-wonders.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### The Millimeter To My Lens — Lake Park (retail)
TO: 2756587@gmail.com
SUBJECT: The Millimeter To My Lens — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/the-millimeter-to-my-lens.html

Hey — Dean here, I build websites for Florida businesses.

I noticed The Millimeter To My Lens doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/the-millimeter-to-my-lens.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Florida Restoration Consultants & Estimators — West Park (trade)
TO: jerry.frcpro@gmail.com
SUBJECT: Florida Restoration Consultants & Estimators — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/florida-restoration-consultants-estimators.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Florida Restoration Consultants & Estimators isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/florida-restoration-consultants-estimators.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Stitch by stitch — Hialeah (retail)
TO: celcin66@gmail.com
SUBJECT: Stitch by stitch — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/stitch-by-stitch.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Stitch by stitch doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/stitch-by-stitch.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### BockTek — Fort Myers (trade)
TO: chrissbock@gmail.com
SUBJECT: BockTek — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/bocktek.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
BockTek isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/bocktek.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Gadget Quick Fix — Tallahassee (trade)
TO: gadgetquickfixtal@gmail.com
SUBJECT: Gadget Quick Fix — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/gadget-quick-fix.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Gadget Quick Fix isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/gadget-quick-fix.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Cellfix — Panama City Beach (trade)
TO: innspro@gmail.com
SUBJECT: Cellfix — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/cellfix.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Cellfix isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/cellfix.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Prostone Marble and Granite — Pompano Beach (trade)
TO: Prostonegmd@hotmail.com
SUBJECT: Prostone Marble and Granite — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/prostone-marble-and-granite.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Prostone Marble and Granite isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/prostone-marble-and-granite.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Eagle 79 Tile Services — Deerfield Beach (trade)
TO: eagleservicescorp@yahoo.com
SUBJECT: Eagle 79 Tile Services — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/eagle-79-tile-services.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Eagle 79 Tile Services isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/eagle-79-tile-services.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Just in Time Watch Service — Pembroke Pines (retail)
TO: frank@justintimewatchservice.com
SUBJECT: Just in Time Watch Service — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/just-in-time-watch-service.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Just in Time Watch Service doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/just-in-time-watch-service.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### BK Cabinets — Melbourne (trade)
TO: bkcabinetsfl@gmail.com
SUBJECT: BK Cabinets — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/bk-cabinets.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
BK Cabinets isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/bk-cabinets.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### New Image Beauty Lounge — Miami (beauty)
TO: Newimagebeautylounge@gmail.com
SUBJECT: quick question about New Image Beauty Lounge
MOCKUP: https://mrcloudmedia.com/demo/new-image-beauty-lounge.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed New Image Beauty Lounge doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/new-image-beauty-lounge.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Asian nails and spa — Miami (beauty)
TO: LIENVAN6690@GMAIL.COM
SUBJECT: quick question about Asian nails and spa
MOCKUP: https://mrcloudmedia.com/demo/asian-nails-and-spa.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Asian nails and spa doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/asian-nails-and-spa.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Dynasty Cuttz Barber Shop — Orlando (barber)
TO: dynastycuttz400@gmail.com
SUBJECT: quick question about Dynasty Cuttz Barber Shop
MOCKUP: https://mrcloudmedia.com/demo/dynasty-cuttz-barber-shop.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Dynasty Cuttz Barber Shop doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/dynasty-cuttz-barber-shop.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Aircraft Repair Shop — Kissimmee (trade)
TO: sales@asap-usa.com
SUBJECT: Aircraft Repair Shop — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/aircraft-repair-shop.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Aircraft Repair Shop isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/aircraft-repair-shop.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Southern Tire Mart — Defuniak Springs (trade)
TO: mossyhead145@stmtires.com
SUBJECT: Southern Tire Mart — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/southern-tire-mart.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Southern Tire Mart isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/southern-tire-mart.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### The Plastic Flamingo — Daytona Beach (beauty)
TO: tpfdaytona@gmail.com
SUBJECT: quick question about The Plastic Flamingo
MOCKUP: https://mrcloudmedia.com/demo/the-plastic-flamingo.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed The Plastic Flamingo doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/the-plastic-flamingo.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Saaab Store — Tampa (trade)
TO: saaabstore@yahoo.com
SUBJECT: Saaab Store — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/saaab-store.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Saaab Store isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/saaab-store.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### 5 Star Cuts barber shop & Magazine cut — Miami (barber)
TO: fivestarcutsbarbershop@gmail.com
SUBJECT: quick question about 5 Star Cuts barber shop & Magazine cut
MOCKUP: https://mrcloudmedia.com/demo/5-star-cuts-barber-shop-magazine-cut.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed 5 Star Cuts barber shop & Magazine cut doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/5-star-cuts-barber-shop-magazine-cut.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Mike's Auto Glass Tampa — Tampa (trade)
TO: mikesglasstampa@gmail.com
SUBJECT: Mike's Auto Glass Tampa — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/mike-s-auto-glass-tampa.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Mike's Auto Glass Tampa isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/mike-s-auto-glass-tampa.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### South Florida Face and Body — Miami Beach (beauty)
TO: southfloridafaceandbody@gmail.com
SUBJECT: quick question about South Florida Face and Body
MOCKUP: https://mrcloudmedia.com/demo/south-florida-face-and-body.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed South Florida Face and Body doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/south-florida-face-and-body.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Endless Summer Tanning & Spa — Port Charlotte (beauty)
TO: EndlessSummerTanAndSpa@gmail.com
SUBJECT: quick question about Endless Summer Tanning & Spa
MOCKUP: https://mrcloudmedia.com/demo/endless-summer-tanning-spa.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Endless Summer Tanning & Spa doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/endless-summer-tanning-spa.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Element, Pickup trucks and trailer repair — FL (trade)
TO: info@element-fe.com
SUBJECT: Element, Pickup trucks and trailer repair — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/element-pickup-trucks-and-trailer-repair.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Element, Pickup trucks and trailer repair isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/element-pickup-trucks-and-trailer-repair.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Close Male Grooming — Wekiva Springs (barber)
TO: closemalegrooming2024@hotmail.com
SUBJECT: quick question about Close Male Grooming
MOCKUP: https://mrcloudmedia.com/demo/close-male-grooming.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Close Male Grooming doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/close-male-grooming.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### La Figa Barbershop — Key Largo (barber)
TO: lafigabarbershop@gmail.com
SUBJECT: quick question about La Figa Barbershop
MOCKUP: https://mrcloudmedia.com/demo/la-figa-barbershop.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed La Figa Barbershop doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/la-figa-barbershop.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Anthony Ferrer Barber — Clermont (barber)
TO: anthonyferrersalon@gmail.com
SUBJECT: quick question about Anthony Ferrer Barber
MOCKUP: https://mrcloudmedia.com/demo/anthony-ferrer-barber.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Anthony Ferrer Barber doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/anthony-ferrer-barber.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Keynoa's Innovative Styling Studio — Jacksonville (barber)
TO: keynoas@gmail.com
SUBJECT: quick question about Keynoa's Innovative Styling Studio
MOCKUP: https://mrcloudmedia.com/demo/keynoa-s-innovative-styling-studio.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Keynoa's Innovative Styling Studio doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/keynoa-s-innovative-styling-studio.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Platinum Styles Barbershop — Deltona (barber)
TO: platinumbarbershop@gmail.com
SUBJECT: quick question about Platinum Styles Barbershop
MOCKUP: https://mrcloudmedia.com/demo/platinum-styles-barbershop.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Platinum Styles Barbershop doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/platinum-styles-barbershop.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### JLynnLashes & More — Casselberry (beauty)
TO: jlynnlashesmore@gmail.com
SUBJECT: quick question about JLynnLashes & More
MOCKUP: https://mrcloudmedia.com/demo/jlynnlashes-more.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed JLynnLashes & More doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/jlynnlashes-more.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Elite Truck Parts — Fort Pierce (trade)
TO: elitetruckparts@gmail.com
SUBJECT: Elite Truck Parts — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/elite-truck-parts.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Elite Truck Parts isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/elite-truck-parts.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Cutz Barbershop — Longwood (barber)
TO: cutzbarbershop14@gmail.com
SUBJECT: quick question about Cutz Barbershop
MOCKUP: https://mrcloudmedia.com/demo/cutz-barbershop.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Cutz Barbershop doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/cutz-barbershop.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### parkland nails — Coconut Creek (beauty)
TO: parklandnailllc@outlook.com
SUBJECT: quick question about parkland nails
MOCKUP: https://mrcloudmedia.com/demo/parkland-nails.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed parkland nails doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/parkland-nails.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Bennett's Hair Salon — Pensacola (barber)
TO: stefanie.smith@hotmail.com
SUBJECT: quick question about Bennett's Hair Salon
MOCKUP: https://mrcloudmedia.com/demo/bennett-s-hair-salon.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Bennett's Hair Salon doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/bennett-s-hair-salon.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Gciano's Barber & Salon — Pinellas Park (barber)
TO: gcianosbarbersalon@gmail.com
SUBJECT: quick question about Gciano's Barber & Salon
MOCKUP: https://mrcloudmedia.com/demo/gciano-s-barber-salon.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Gciano's Barber & Salon doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/gciano-s-barber-salon.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Salah barber shop — Jacksonville (barber)
TO: salahsoltan@hotmail.com
SUBJECT: quick question about Salah barber shop
MOCKUP: https://mrcloudmedia.com/demo/salah-barber-shop.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Salah barber shop doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/salah-barber-shop.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Drew The Barber at Hendrix Salon — Sunrise (barber)
TO: drewthebarberfl@gmail.com
SUBJECT: quick question about Drew The Barber at Hendrix Salon
MOCKUP: https://mrcloudmedia.com/demo/drew-the-barber-at-hendrix-salon.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Drew The Barber at Hendrix Salon doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/drew-the-barber-at-hendrix-salon.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Beach Barbers — Panama City Beach (barber)
TO: beachbarbers47@gmail.com
SUBJECT: quick question about Beach Barbers
MOCKUP: https://mrcloudmedia.com/demo/beach-barbers.html

Hey — I'm Dean, I build websites for small businesses here in Florida.

I noticed Beach Barbers doesn't have a site, so I went ahead and built the
homepage to show you what it'd look like. No charge, no catch:

https://mrcloudmedia.com/demo/beach-barbers.html

The part that actually matters isn't the site — it's that people decide
on their week at 11pm, and right now there's no way for them to book you
then. That's the thing I'd fix.

If you like the direction, I'll finish it out with your real photos and
booking. If not, keep the link, no hard feelings.

Worth a ten minute call?
— Dean, 47 Industries

---

### Affordable Auto & Tire Service — FL (trade)
TO: affordable27861@aol.com
SUBJECT: Affordable Auto & Tire Service — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/affordable-auto-tire-service.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Affordable Auto & Tire Service isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/affordable-auto-tire-service.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### ICU Motors LLC — Orlando (trade)
TO: icumotorsllc@gmail.com
SUBJECT: ICU Motors LLC — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/icu-motors-llc.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
ICU Motors LLC isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/icu-motors-llc.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Oldsmar Florist — Oldsmar (retail)
TO: Oflorist@aol.com
SUBJECT: Oldsmar Florist — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/oldsmar-florist.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Oldsmar Florist doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/oldsmar-florist.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Materia Collection — Bay Harbor Islands (retail)
TO: info@materiacollection.com
SUBJECT: Materia Collection — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/materia-collection.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Materia Collection doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/materia-collection.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Woof Gang Bakery & Grooming Jupiter Farms — Jupiter (retail)
TO: jupiterfarms@woofgangbakery.com
SUBJECT: Woof Gang Bakery & Grooming Jupiter Farms — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/woof-gang-bakery-grooming-jupiter-farms.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Woof Gang Bakery & Grooming Jupiter Farms doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/woof-gang-bakery-grooming-jupiter-farms.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Judy's Fine Jewelry — FL (retail)
TO: thosewhoareawake@gmail.com
SUBJECT: Judy's Fine Jewelry — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/judy-s-fine-jewelry.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Judy's Fine Jewelry doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/judy-s-fine-jewelry.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Red Ribbon — FL (retail)
TO: pinellas.store@rrbiusa.com
SUBJECT: Red Ribbon — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/red-ribbon.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Red Ribbon doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/red-ribbon.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Mary & Lu’s Flowers — FL (retail)
TO: mqflowering@gmail.com
SUBJECT: Mary & Lu’s Flowers — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/mary-lu-s-flowers.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Mary & Lu’s Flowers doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/mary-lu-s-flowers.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Tiger Wood Custom Cabinets — FL (retail)
TO: tigerwoodscustcabs@gmail.com
SUBJECT: Tiger Wood Custom Cabinets — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/tiger-wood-custom-cabinets.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Tiger Wood Custom Cabinets doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/tiger-wood-custom-cabinets.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### French Florist — Boca Raton (retail)
TO: bocaraton@frenchflorist.com
SUBJECT: French Florist — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/french-florist.html

Hey — Dean here, I build websites for Florida businesses.

I noticed French Florist doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/french-florist.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### VerdeVin Plant Shop — Leesburg (retail)
TO: verdevinllc@gmail.com
SUBJECT: VerdeVin Plant Shop — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/verdevin-plant-shop.html

Hey — Dean here, I build websites for Florida businesses.

I noticed VerdeVin Plant Shop doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/verdevin-plant-shop.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Leader's — Clearwater (retail)
TO: clearwater@leadersfurniture.com
SUBJECT: Leader's — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/leader-s.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Leader's doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/leader-s.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Divorce Smart Esq. — Boca Raton (pro)
TO: temi@divorcesmartesq.com
SUBJECT: Divorce Smart Esq. — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/divorce-smart-esq.html

Hi — I'm Dean, I build websites for Florida businesses.

Divorce Smart Esq. doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/divorce-smart-esq.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---

### Kayler, Kayler and Leto P.A. — Sebring (pro)
TO: nsl@kaylor-kaylor.com
SUBJECT: Kayler, Kayler and Leto P.A. — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/kayler-kayler-and-leto-p-a.html

Hi — I'm Dean, I build websites for Florida businesses.

Kayler, Kayler and Leto P.A. doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/kayler-kayler-and-leto-p-a.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---

### Casa de Maria Realty — Bay Harbor Islands (pro)
TO: maria@casademariarealty.com
SUBJECT: Casa de Maria Realty — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/casa-de-maria-realty.html

Hi — I'm Dean, I build websites for Florida businesses.

Casa de Maria Realty doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/casa-de-maria-realty.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---

### Assured Appraisal — Altamonte Springs (pro)
TO: bert@assuredappraisalfl.com
SUBJECT: Assured Appraisal — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/assured-appraisal.html

Hi — I'm Dean, I build websites for Florida businesses.

Assured Appraisal doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/assured-appraisal.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---

### Station Sqaure Realty — FL (pro)
TO: raycassano@gmail.com
ALT: assuntazaghet@gmail.com (second contact — only if no reply)
SUBJECT: Station Sqaure Realty — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/station-sqaure-realty.html

Hi — I'm Dean, I build websites for Florida businesses.

Station Sqaure Realty doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/station-sqaure-realty.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---
