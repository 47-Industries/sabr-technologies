# HELD — these businesses ALREADY have a live website.
# The email claims 'I noticed you don't have a site' — that is factually wrong for these.
# Rewrite as a redesign/upgrade pitch before sending.


### Just in Time Watch Service — Pembroke Pines (retail)
TO: frank@justintimewatchservice.com
SUBJECT: Just in Time Watch Service — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/just-in-time-watch-service.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Just in Time Watch Service doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/just-in-time-watch-service.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Aircraft Repair Shop — Kissimmee (trade)
TO: sales@asap-usa.com
SUBJECT: Aircraft Repair Shop — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/aircraft-repair-shop.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Aircraft Repair Shop isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/aircraft-repair-shop.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Southern Tire Mart — Defuniak Springs (trade)
TO: mossyhead145@stmtires.com
SUBJECT: Southern Tire Mart — not showing up when people search
MOCKUP: https://mrcloudmedia.com/demo/southern-tire-mart.html

Hey — Dean here, I build sites for Florida businesses.

When someone's got a burst pipe or a dead AC on a Saturday, they search,
they call the first few results, and they book whoever answers. Right now
Southern Tire Mart isn't in that list, because there's no site to rank.

So I built you one to look at. Free, already live:

https://mrcloudmedia.com/demo/southern-tire-mart.html

You're already doing the work — this is just about being findable when
someone's ready to pay. If you like it I'll finish it properly with your
service area, photos and reviews.

Worth a quick call?
— Dean, 47 Industries

---

### Materia Collection — Bay Harbor Islands (retail)
TO: info@materiacollection.com
SUBJECT: Materia Collection — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/materia-collection.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Materia Collection doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/materia-collection.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Woof Gang Bakery & Grooming Jupiter Farms — Jupiter (retail)
TO: jupiterfarms@woofgangbakery.com
SUBJECT: Woof Gang Bakery & Grooming Jupiter Farms — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/woof-gang-bakery-grooming-jupiter-farms.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Woof Gang Bakery & Grooming Jupiter Farms doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/woof-gang-bakery-grooming-jupiter-farms.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### French Florist — Boca Raton (retail)
TO: bocaraton@frenchflorist.com
SUBJECT: French Florist — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/french-florist.html

Hey — Dean here, I build websites for Florida businesses.

I noticed French Florist doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/french-florist.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Leader's — Clearwater (retail)
TO: clearwater@leadersfurniture.com
SUBJECT: Leader's — built you a homepage, free look
MOCKUP: https://mrcloudmedia.com/demo/leader-s.html

Hey — Dean here, I build websites for Florida businesses.

I noticed Leader's doesn't have a site, so I built the homepage to show you
what one would look like. It's live right now:

https://mrcloudmedia.com/demo/leader-s.html

No charge and no catch — it's easier to show you than describe it. If you
like it, I'll finish it out with your real photos and details.

Worth ten minutes?
— Dean, 47 Industries

---

### Divorce Smart Esq. — Boca Raton (pro)
TO: temi@divorcesmartesq.com
SUBJECT: Divorce Smart Esq. — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/divorce-smart-esq.html

Hi — I'm Dean, I build websites for Florida businesses.

Divorce Smart Esq. doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/divorce-smart-esq.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries

---

### Assured Appraisal — Altamonte Springs (pro)
TO: bert@assuredappraisalfl.com
SUBJECT: Assured Appraisal — a homepage I built for you
MOCKUP: https://mrcloudmedia.com/demo/assured-appraisal.html

Hi — I'm Dean, I build websites for Florida businesses.

Assured Appraisal doesn't have a site, and in your field that costs you the clients
who look you up before they call. So rather than pitch you, I built the
homepage and put it online for you to look at:

https://mrcloudmedia.com/demo/assured-appraisal.html

Free, no obligation. If the direction's right I'll finish it out properly.
If not, no harm done.

Do you have ten minutes this week?
— Dean, 47 Industries
