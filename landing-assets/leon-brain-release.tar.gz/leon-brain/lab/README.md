# SABR-1 Lab — Leon's design & simulation bench (PERSISTENT)

venv: /opt/leon-brain/lab/venv   (rebuild: pip install -r requirements-lab.txt)
system dep: ngspice (pacman -S ngspice) — PySpice needs libngspice.so

- build123d  : real B-rep CAD (OpenCascade). Parametric parts -> STL + STEP.
- trimesh    : independent mesh audit. NEVER grade a part with the tool that made it.
- mujoco     : rigid-body + TENDON dynamics. This is where designs get disproved.
- pybullet   : second opinion physics / URDF.
- PySpice    : real SPICE circuit simulation.

## Log of findings
2026-08-16  finger flexor routing.
  v1 anchors on proximal phalanx -> MCP locked at 2.4 deg at ALL tensions.
  v2 anchors moved behind each axis -> WORSE (curl collapsed to 8 deg). Hypothesis wrong.
  v3 flexor ORIGINATES IN THE PALM (world frame) -> MCP 12->61 deg, tip travel 66->114mm.
  ROOT CAUSE: a tendon anchored to the same body it must rotate makes no torque
  about that joint. Flexors must originate proximal to the joint they drive.
