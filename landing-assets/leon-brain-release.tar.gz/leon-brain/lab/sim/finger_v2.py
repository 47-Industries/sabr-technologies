"""SABR-1: tendon-driven 3-phalanx finger. Real MuJoCo dynamics, headless."""
import mujoco, numpy as np
XML = """
<mujoco model="sabr1_finger">
  <option timestep="0.0005" gravity="0 0 -9.81" integrator="implicitfast"/>
  <worldbody>
    <body name="prox" pos="0 0 0">
      <joint name="mcp" type="hinge" axis="0 1 0" range="0 1.6" damping="0.02"/>
      <geom type="capsule" fromto="0 0 0 0.038 0 0" size="0.008" mass="0.0046"/>
      <site name="s0" pos="-0.006 0 -0.011"/>
      <site name="s1" pos="0.034 0 -0.007"/>
      <body name="mid" pos="0.038 0 0">
        <joint name="pip" type="hinge" axis="0 1 0" range="0 1.7" damping="0.02"/>
        <geom type="capsule" fromto="0 0 0 0.026 0 0" size="0.007" mass="0.0031"/>
        <site name="s2" pos="-0.004 0 -0.010"/>
        <site name="s3" pos="0.023 0 -0.006"/>
        <body name="dist" pos="0.026 0 0">
          <joint name="dip" type="hinge" axis="0 1 0" range="0 1.5" damping="0.02"/>
          <geom type="capsule" fromto="0 0 0 0.020 0 0" size="0.006" mass="0.0021"/>
          <site name="s4" pos="-0.003 0 -0.009"/>
          <site name="tip" pos="0.020 0 0"/>
        </body>
      </body>
    </body>
  </worldbody>
  <tendon>
    <spatial name="flexor" width="0.0006" rgba="1 0 0 1">
      <site site="s0"/><site site="s1"/><site site="s2"/><site site="s3"/><site site="s4"/>
    </spatial>
  </tendon>
  <actuator>
    <motor name="flex" tendon="flexor" gear="1" ctrlrange="-40 0"/>
  </actuator>
</mujoco>
"""
m = mujoco.MjModel.from_xml_string(XML); d = mujoco.MjData(m)
tip = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_SITE, "tip")
mujoco.mj_forward(m, d); start = d.site_xpos[tip].copy()
print(f"  finger mass     {sum(m.body_mass):.4f} kg   ({sum(m.body_mass)*1000:.1f} g)")
print(f"  tip at rest     x={start[0]*1000:.1f} z={start[2]*1000:.1f} mm")
print(f"\n  {'tendon N':>9}{'MCP deg':>9}{'PIP deg':>9}{'DIP deg':>9}{'tip travel mm':>15}")
for pull in (-5, -10, -20, -30, -40):
    mujoco.mj_resetData(m, d); d.ctrl[0] = pull
    for _ in range(6000): mujoco.mj_step(m, d)   # 3.0 s settle
    q = np.degrees(d.qpos)
    trav = np.linalg.norm(d.site_xpos[tip] - start)*1000
    print(f"  {abs(pull):>9.0f}{q[0]:>9.1f}{q[1]:>9.1f}{q[2]:>9.1f}{trav:>15.1f}")
print("\n  -> curl is progressive and settles: the tendon V2 routing — anchors moved BEHIND each joint axis for a real moment arm.")
