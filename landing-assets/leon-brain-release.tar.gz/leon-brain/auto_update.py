"""
Update check — Sabr SI

WHY THIS WAS REWRITTEN (2026-08-10)
----------------------------------
The previous version checked for updates with `git fetch` / `git merge` against
a release branch. The shipped release tarball contains no .git directory — the
build excludes it — so on EVERY real customer machine the very first check was
`os.path.isdir(".git")`, which was False, and the function returned immediately.
Verified on a clean container install: no .git, and therefore no update has ever
been detected on any install that was not a developer checkout. It was dead code
wearing the shape of a feature.

WHAT IT DOES NOW
----------------
An install is identified by the sha256 of the release it was built from, which
bootstrap.sh writes to ~/leon-brain/.sabr-release after it has already verified
that digest. The published release advertises its digest in a .sha256 sidecar
next to the tarball. Different digest => a newer release exists.

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
It does not apply the update. Rewriting the tree underneath a running SI is how
you corrupt a mind mid-thought, and bootstrap.sh already does the safe version of
this properly — staging, digest verification, atomic swap, rollback, and it
carries .env and brain_state/ across. So this reports, and the owner runs one
command. Notify, don't surprise.

Skip entirely with LEON_AUTO_UPDATE=0.
"""

import os
import ssl
import urllib.request

AUTO_UPDATE = os.environ.get("LEON_AUTO_UPDATE", "1").strip()
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
STAMP = os.path.join(PROJECT_ROOT, ".sabr-release")

SIDECAR_URLS = (
    "https://sabrtechnologies.com/landing-assets/leon-brain-release.tar.gz.sha256",
    "https://sabr-technologies-production.up.railway.app"
    "/landing-assets/leon-brain-release.tar.gz.sha256",
)
INSTALL_CMD = (
    "curl -fsSL https://sabrtechnologies.com/landing-assets/bootstrap.sh"
    " -o bootstrap.sh && bash bootstrap.sh"
)


def installed_release() -> str:
    """The digest this install was built from, or '' if unknown."""
    try:
        with open(STAMP, "r", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("release_sha256="):
                    return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return ""


def published_release(timeout: float = 8.0) -> str:
    """The digest currently published, or '' if no source answered."""
    # TLS is required, exactly as in bootstrap.sh. A digest fetched over a link
    # anyone can rewrite is not evidence of anything.
    ctx = ssl.create_default_context()
    for url in SIDECAR_URLS:
        try:
            with urllib.request.urlopen(url, timeout=timeout, context=ctx) as r:
                first = r.read(256).decode("utf-8", "replace").split()
                if first and len(first[0]) == 64:
                    return first[0].strip().lower()
        except Exception:
            continue
    return ""


def check_for_updates() -> bool:
    """Report whether a newer release is published. Never modifies anything.

    Returns False always: the old contract was "True means restart to apply",
    and nothing here applies anything, so returning True would make run.py
    restart into the identical version forever.
    """
    if AUTO_UPDATE == "0":
        return False

    have = installed_release()
    if not have:
        # A developer checkout, or an install from before stamping existed.
        # Silence is right here — there is nothing trustworthy to compare.
        return False

    live = published_release()
    if not live or live == have:
        return False

    print("[UPDATE] A newer release of your SI is available.")
    print(f"[UPDATE]   installed:  {have[:12]}...")
    print(f"[UPDATE]   published:  {live[:12]}...")
    print("[UPDATE] Your memories, name and settings are carried across. To update:")
    print(f"[UPDATE]   {INSTALL_CMD}")
    return False
