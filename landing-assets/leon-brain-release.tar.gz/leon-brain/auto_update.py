"""
OTA (Over-The-Air) Update System — Sabr SI

On every startup, checks if there's a newer version available.
If so, pulls the update automatically (git pull from release branch).

Skip by setting LEON_AUTO_UPDATE=0 in .env.
"""

import os
import subprocess
import sys

UPDATE_BRANCH = os.environ.get("LEON_UPDATE_BRANCH", "release")
AUTO_UPDATE = os.environ.get("LEON_AUTO_UPDATE", "1").strip()
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))


def check_for_updates() -> bool:
    """Check and apply updates. Returns True if updated (restart needed)."""
    if AUTO_UPDATE == "0":
        return False

    # Check if this is a git repo
    git_dir = os.path.join(PROJECT_ROOT, ".git")
    if not os.path.isdir(git_dir):
        return False

    try:
        # Fetch latest from remote
        r = subprocess.run(
            ["git", "fetch", "origin", UPDATE_BRANCH],
            cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=15,
        )
        if r.returncode != 0:
            return False

        # Check if we're behind
        r = subprocess.run(
            ["git", "log", f"HEAD..origin/{UPDATE_BRANCH}", "--oneline"],
            cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=10,
        )
        new_commits = r.stdout.strip()
        if not new_commits:
            return False

        commit_count = len(new_commits.split("\n"))
        print(f"[UPDATE] {commit_count} new update(s) available")

        # Show what's new
        for line in new_commits.split("\n")[:5]:
            print(f"[UPDATE]   {line}")
        if commit_count > 5:
            print(f"[UPDATE]   ... and {commit_count - 5} more")

        # Pull the updates (merge, not rebase — safer for clients)
        r = subprocess.run(
            ["git", "merge", f"origin/{UPDATE_BRANCH}", "--ff-only"],
            cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=30,
        )
        if r.returncode == 0:
            print(f"[UPDATE] Updated successfully. {commit_count} commit(s) applied.")
            return True
        else:
            # Fast-forward failed (local changes). Try with strategy.
            print(f"[UPDATE] Fast-forward failed. Trying merge...")
            r = subprocess.run(
                ["git", "merge", f"origin/{UPDATE_BRANCH}",
                 "-m", "auto-merge: OTA update from Sabr"],
                cwd=PROJECT_ROOT, capture_output=True, text=True, timeout=30,
            )
            if r.returncode == 0:
                print(f"[UPDATE] Merged successfully.")
                return True
            else:
                print(f"[UPDATE] Merge conflict. Skipping update — manual merge needed.")
                # Abort the merge
                subprocess.run(["git", "merge", "--abort"],
                              cwd=PROJECT_ROOT, capture_output=True, timeout=5)
                return False

    except subprocess.TimeoutExpired:
        print("[UPDATE] Timeout checking for updates. Continuing with current version.")
        return False
    except FileNotFoundError:
        # git not installed
        return False
    except Exception as e:
        print(f"[UPDATE] Error: {e}")
        return False
