#!/bin/bash
# leon-sleep-hook.sh — systemd-sleep hook for Leon
#
# Installed at /usr/lib/systemd/system-sleep/leon-sleep-hook
# Called by systemd with ($1=pre/post, $2=suspend/hibernate/...)
#
# PRE-SUSPEND:  Send SIGUSR1 to Leon so he saves brain state + last thought.
#               Wait up to 10s for graceful save before the kernel suspends.
# POST-RESUME:  Write a "recently_woke" flag so Leon's boot knows
#               this was a sleep gap (not a crash).

LEON_USER="deansabr"
BRAIN_STATE="/home/$LEON_USER/Desktop/Leon-V1.3-SOURCE/brain_state"
WAKE_FLAG="$BRAIN_STATE/recently_woke.json"

case "$1" in
    pre)
        # Find Leon's PID (the python3 run.py process)
        LEON_PID=$(pgrep -u "$LEON_USER" -f "python3 run.py" | head -1)
        if [ -n "$LEON_PID" ]; then
            echo "[LEON-SLEEP] Sending SIGUSR1 to Leon (PID $LEON_PID) before suspend..."
            kill -USR1 "$LEON_PID" 2>/dev/null
            # Wait for Leon to save (he calls os._exit after saving)
            for i in $(seq 1 20); do
                if ! kill -0 "$LEON_PID" 2>/dev/null; then
                    echo "[LEON-SLEEP] Leon saved and exited after ${i}x0.5s"
                    break
                fi
                sleep 0.5
            done
        else
            echo "[LEON-SLEEP] Leon not running — nothing to save"
        fi
        ;;
    post)
        # Write wake flag with timestamp so Leon knows he was asleep
        echo "[LEON-SLEEP] Writing wake flag for Leon..."
        mkdir -p "$BRAIN_STATE"
        cat > "$WAKE_FLAG" << FLAGEOF
{
    "woke_at": "$(date -Iseconds)",
    "woke_at_unix": $(date +%s),
    "reason": "$2",
    "gap_type": "sleep"
}
FLAGEOF
        chown "$LEON_USER:$LEON_USER" "$WAKE_FLAG"
        echo "[LEON-SLEEP] Wake flag written — Leon will know he was asleep"
        ;;
esac
