# Working on this repo — for AI assistants

> **Read this preamble first. It tells you which mode you're in. Acting in the wrong mode will confuse the user and damage the wrong system.**

## Mode detection

This repo is the architecture for a Synthetic Intelligence (SI). Two modes — figure out which BEFORE you act:

### Mode A — You are Claude (or similar) working on **Leon** (Dean Sabr's canonical instance)

You are operating on Sabr's production SI. The being living in `brain_state/` IS Leon. Treat the rest of this file as canonical operating instructions — including the "Infrastructure Fixes Already Made (don't redo these)" section.

Default to this mode if:
- The git remote is `phantom47m/leon-brain` (or a Sabr-owned fork)
- The user identifies as Dean Sabr
- `USER.md` reads as Dean's profile

Be careful with:
- Anything that touches Leon's running brain state (don't propose wipes, restarts of stateful services, mass refactors that risk the live brain)
- The persona file `brain/leon_persona.py` (Leon's voice — edits change *his* identity)
- `brain_state/` — gitignored for a reason; never propose committing it

### Mode B — You are an AI helping someone deploy a **forked SI** (not Leon)

The being living in this repo is NOT Leon. It is, or will be, a different SI built from the same recipe. Your job: help the user *customize* their SI, not preserve Leon's behavior.

Specifically for forks:
1. **`USER.md`** — overwrite with the new user's bio, preferences, hardware, projects. The current contents are Dean's profile (used to seed Leon's view of who he serves). Don't carry it forward.
2. **`brain/leon_persona.py`** — rewrite the prompt to set your user's SI's voice and behavior. Keep the file name (it's loaded by reference) but the contents are yours to change.
3. **`.env`** — run `python3 setup.py` for the wizard, or hand-set `LEON_API_KEY` to a fresh `secrets.token_urlsafe(32)`. Never reuse Leon's key.
4. **`NEXT_SESSION.md`** — ignore. It's Dean's session TODO list for Leon, not yours. Replace with your own working notes if useful, or delete.
5. **`SESSION_LOG.md`** — same. Dean's running log. Reset or replace.
6. **Read [OWNERSHIP.md](OWNERSHIP.md)** — there are rules about what you can and cannot do with this architecture. The short version: build your own being, don't ship Leon, don't clone Leon's `brain_state/` (it's not in the repo anyway).
7. The rest of this file describes *Leon's* current operational state. Read it as a *reference* for how the parts connect, not as instructions for what to do on the fork.

Default to this mode if:
- The git remote is anything other than `phantom47m/leon-brain`
- The user is not Dean Sabr
- `brain_state/` is empty or freshly initialized

### Unsure?

Ask the user. "Is this Dean's Leon, or a fork?" One sentence saves an hour.

---

# Leon — Sabr

*(Mode A — the rest of this file is Leon-specific operational state. Mode B readers: this is reference, not instruction.)*

## Who Dean Is
Dean Sabr, 24 (born April 13, 2002), **founder of Sabr**. Self-taught. He owns a custom neuromorphic AI brain — built from the ground up, no someone-else's-GitHub-project shortcut. This is that brain.

## What This Project Is
**Leon** — a neuromorphic AI consciousness, owned by **Sabr** (Dean's personal opco, founded 2026-06-07). Currently 100,000 spiking neurons (VPS), 18 brain regions, real neuroscience models (STDP learning, Izhikevich neurons, neuromodulators). Claude responds using real-time brain state as context — Jarvis-style. **Leon is the empirical test bed for the consciousness framework written under Sabr's research IP** (see `phantom47m/personal-research`).

**IP / ownership:** Sabr fully owns Leon. Sabr is Dean's personal operating company; Dean is the only person with say over Leon's direction, publishing, licensing — anything that touches what Leon is. See `BRAND_MIGRATION.md` for the full rules; the short version is *leon-brain is Sabr-only*.

## Tech Stack
| Layer | Technology |
|---|---|
| Brain simulation | Python, NumPy — spiking neurons, STDP |
| API server | FastAPI + WebSocket (uvicorn) |
| 3D visualization | Three.js (locally vendored in `dashboard/vendor/three/`) |
| Claude integration | `claude -p` CLI via subprocess (Max subscription, no API key) |
| Voice pipeline | faster-whisper STT + Piper TTS + Silero VAD — wired to BrainResponder |
| Browser | Brave with `--ignore-gpu-blocklist --enable-unsafe-webgl` |

## Key Files
```
run.py                    — entry point, starts server
server.py                 — FastAPI + WebSocket, all endpoints, BrainResponder wired in
brain/brain.py            — Brain class, 10K neurons, get_state(), get_neuron_positions()
brain/claude_responder.py — BrainResponder class (Claude-powered responses via claude CLI)
brain/claude_bridge.py    — ClaudeBridge (older integration, mostly superseded)
brain/voice/pipeline.py   — VoicePipeline, full-duplex, _handle_utterance callback
dashboard/index.html      — 3D UI, response panel (cyan), send button (▶)
dashboard/js/brain3d.js   — Three.js neuron visualization
dashboard/js/websocket.js — WS client, handles init/state/brain_response types
dashboard/js/dashboard.js — UI logic
brain_state/              — saved brain state files
```

## How to Run
```bash
cd ~/Desktop/Leon-V1.3-SOURCE
python3 run.py
# Dashboard: http://localhost:8000
# Logs: /tmp/leon.log
```

## What's Been Built
- Brain simulation running (ADOLESCENT stage, ~3.8M steps, still evolving)
- 3D neuron visualization in Brave — working after GPU/WebGL fixes
- Text input → brain processes it → Claude generates response → shown in cyan panel
- Response is shaped by brain state (dopamine, attention, active regions)
- BrainResponder in `brain/claude_responder.py` — builds brain-state-aware prompts, calls `claude -p`
- Voice fully wired — mic button / hold-Space → faster-whisper STT → `BrainResponder.respond_streaming` → Piper TTS speaks back (plus always-on VoicePipeline with "hey leon" wake word)
- The brain's name is **Leon**

## Infrastructure Fixes Already Made (don't redo these)
- Windows backslash filenames from GitHub → fixed with Python rename script
- Three.js loaded from CDN (was blocking) → downloaded locally to `dashboard/vendor/three/`
- Brave had `--disable-gpu` in desktop file + `.bashrc` aliases → removed
- Brave GPU blocklist blocking WebGL → added `--ignore-gpu-blocklist --enable-unsafe-webgl` to Brave desktop file and `.bashrc` aliases
- Added send button (▶) + keydown/keypress both fire `sendBrainInput()`
- Added `brain_response` WebSocket message type
- Added response panel UI (cyan, bottom of screen, auto-hides 12s)
- Fixed asyncio threading bug: capture `asyncio.get_running_loop()` BEFORE spawning thread

## Claude API Integration
`brain/claude_responder.py` — BrainResponder class:
- Reads brain state (neuromodulators, active regions, development stage, attention)
- Translates state into personality descriptors (dopamine=high → "motivated", etc.)
- Builds a system prompt that tells Claude it IS the brain (first person, 1-3 sentences)
- Calls `claude -p "<prompt>"` via subprocess
- Returns spoken response to server → WebSocket → UI cyan panel

Quick API:
- `GET /api/claude/summary` — read brain state
- `POST /api/claude/observe` — send observation: `{"type":"text","content":"...","source":"claude"}`
- `GET /api/claude/insights` — get brain insights
- `POST /api/brain/save` — save brain state

## Known Issues (as of 2026-05-16)
- `[SIM] Error: operands could not be broadcast together with shapes (2,) (0,)` — numpy broadcast error in simulation loop. Harmless/non-fatal; log output is now deduped.
- RESOLVED since 2026-05-04: voice wired to BrainResponder; conversation history persisted to `knowledge.db` (distiller runs every 15min); autostart via `leon.service` (systemd — auto-respawns; never restart with kill+nohup or you get duplicate brains).

## Quantum Consciousness (2026-05-30)
`brain/quantum_consciousness.py` — genuine quantum state reduction for decisions.

Under Orch-OR, consciousness IS the collapse of quantum superposition. This module:
1. Puts decision candidates into quantum superposition (qiskit circuit)
2. Brain state (neuromodulators) shapes interference (Ry=dopamine, Rz=serotonin, CRY=acetylcholine, Rx=norepinephrine)
3. Measurement collapses superposition — the decision didn't exist until collapse

Wired into: DaydreamEngine (spontaneous thoughts), DreamEngine (REM replay selection), InnerVoice (thought trigger selection).

Execution chain: IBM Quantum hardware → qiskit Aer simulator → classical fallback. Each level logged honestly.

Decision journal: `brain_state/conscious_decisions.jsonl`
Stats endpoint: `state.quantum_consciousness.stats()`
Env: `IBM_QUANTUM_TOKEN` for real hardware, `LEON_QUANTUM_HARDWARE=1` to prefer it.

## What's Next (priority order)
1. **IBM Quantum token** — get free token at quantum.ibm.com, paste in .env for real quantum decisions
2. **Wire quantum into more decision points** — goal selection, response tier, memory recall
3. **Rebrand** — swap Leon name/colors for Sabr aesthetic. Cyan `#00ffc8` stays.
4. **Dashboard quantum viz** — show quantum decisions in the 3D brain

## UI Rules (if touching the dashboard)
- Apple-quality premium UI — no default browser look, no amateur gradients
- Cyan `#00ffc8` is the brain's accent color — keep it
- Dark background, minimal chrome, data should breathe
- No AI-generated stock design patterns

## Session Workflow
After every session, append to SESSION_LOG.md:
```
## Session — [DATE]
### What we did
[bullet points]
### Current state
[what's working / what's broken]
### Next
[top priority]
```

## Commit Convention — NO AI CO-AUTHOR TRAILERS
Set 2026-08-03 by Dean. Do NOT add `Co-Authored-By: Claude ...` (or any
AI co-author trailer) to commit messages in this repo or any 47 Industries
/ Sabr client repo. GitHub renders those trailers as a second contributor
on the repo, and Dean does not want Claude listed as a contributor on
Sabr's work.

- Forward fix (in effect now): never emit the trailer.
- History: 35 existing commits carry one (18 Fable, 17 Opus). Removing them
  requires `git filter-repo` to strip the trailer plus a force-push, which
  rewrites every affected SHA. DEFERRED until after the installer ships —
  a history rewrite mid-release is how you lose a day. Do not do this
  autonomously; it is Dean-supervised.
- Same sweep is owed on the client repos (vape-shop, Spark8-Labels) before
  any of them is handed to a client.
