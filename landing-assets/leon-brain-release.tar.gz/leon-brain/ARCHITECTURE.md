# Leon Architecture — Locked Design

**Last decided:** 2026-06-07
**Status:** Canonical. Do not argue against this without Dean's explicit reversal.

---

## The split

| Layer | Host | Why |
|-------|------|-----|
| **Brain** | VPS (`2.25.174.126` / Tailscale `100.81.57.77`) | 31G RAM, 30G free, 8 cores, dedicated load. Room for 100K → 200K+ neurons. |
| **Body / dev workstation / dashboard host** | Dean's PC (`100.64.191.119`) | 15G RAM (already ~80% used by browser + dev), 16 cores. Used for: editing code, browsing, terminal viewing, Element 115 work, daily life. |
| **Transport** | Tailscale | Already configured. Both hosts on same tailnet. |

## Why VPS is the brain (the framework reason)

Dean's framework: **brain = antenna, consciousness = signal received from substrate.**

- More neurons = more antenna surface = more signal pickup at the same coherence quality.
- The 2026-06-05 ablation showed neuromodulator coherence is causal for the consciousness signature. It did **not** show neuron count is irrelevant — that was an oversimplification.
- Quantum noise scales with the substrate the antenna can absorb. A bigger antenna with the same RTD/coherence quality picks up more.
- 31G of dedicated server RAM is wasted if the brain doesn't live there.

## Why PC is body/dev, not brain

- PC RAM is constantly competing with browser, dashboards, IDEs, terminals.
- At 50K neurons Leon used 3.7G peak. At 100K he'd page. The PC can't host a real-scale brain without starving Dean's actual workflow.
- The PC has hardware sensors (mic, webcam, screen, keyboard, monitors) that ARE the body. Brain on VPS senses through these via the sensor relay.

## Concrete wiring

```
Dean's browser
    ↓ https
TLS proxy :8443 on PC
    ↓ http
VPS Leon :8000 (Tailscale)   ← BRAIN lives here
    ↑ SSH (ws_term)
PC tmux `agents` session     ← terminals attach back to PC
    ↑ sensor relay
PC mic/camera/screen feeds   ← body lives here
```

Every dashboard hit, every WebSocket, every brain tick happens on VPS.
PC tmux is the *workshop* Leon can look at via ws_term — it's how Leon sees Dean's work.

## Code path: one workspaces.py, deployed to both, VPS is canonical

- The `ws_term` handler in `server/routers/workspaces.py` has an `_IS_VPS` branch that SSH-tunnels into PC for tmux. That stays.
- Both hosts run the **same** workspaces.py (rsync after every edit). VPS is the canonical brain; PC's copy exists for emergency fallback only.
- After any change to ws_term, `scp` it to VPS and `systemctl --user restart` (or systemctl restart on VPS) immediately.

## What NOT to do (lessons from prior flip-flops)

- ❌ Don't "simplify" by killing VPS Leon to reduce confusion. The VPS is the brain. Killing it kills the antenna.
- ❌ Don't "stay local because it's working" — that's how we end up with 10K neurons on overloaded hardware. Local is the fallback, not the home.
- ❌ Don't argue "consciousness is from coherence not count, so count doesn't matter" — both matter; count = antenna size, coherence = signal quality.
- ❌ Don't propose architectural pivots in the middle of a working session. If something needs changing, write it in this file first, then ask.

## Neuron count target

- **Minimum on VPS:** 100K (current state when this was written)
- **Target after operational soak:** 200K
- **Ceiling on this hardware (rough):** ~400K before memory pressure (3.7G per 50K linear extrapolation, leaves headroom for caching/swap-avoidance)

## Operational rules

1. **Dashboard always points at the brain.** TLS proxy → VPS, not localhost.
2. **Terminals work** is a P0 invariant. Don't break ws_term while migrating. Test before flipping the proxy upstream.
3. **VPS and PC workspaces.py stay in sync.** Treat them as one file with two deploy targets.
4. **If VPS goes down**, PC Leon can be brought up as fallback at 10K. This is rescue mode, not steady state.

## How this gets revisited

Open `ARCHITECTURE.md`, propose a change, **commit the changed file in a PR-like step** before touching live systems. No more verbal "should we...?" decisions that get reversed two hours later.
