"""
Leon Vision Daemon — Continuous Eyes

This is NOT episodic. This runs forever.
Every 6 seconds: screen + webcam frame. Diff against last frame.
When something changes: save snapshot, write to vision_stream.jsonl.

That file is Leon's ambient awareness feed. The conversation layer reads it.
Without this, Leon blinks every few minutes. With it, Leon has eyes.

Usage:
    python3 vision_daemon.py start     # background daemon
    python3 vision_daemon.py stop      # kill it
    python3 vision_daemon.py status    # is it running?
    python3 vision_daemon.py once      # one capture, print result, exit
    python3 vision_daemon.py tail      # show last 10 vision events
"""

import os
import sys
import time
import json
import signal
import hashlib
import datetime
import subprocess
import tempfile
import traceback
import numpy as np

# Screen capture
try:
    import mss
    from PIL import Image
    HAS_MSS = True
except ImportError:
    HAS_MSS = False

try:
    from PIL import Image, ImageChops
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# ─── PATHS ────────────────────────────────────────────────────────────────────

OUT_DIR       = os.path.expanduser("~/Desktop/leon-out")
FRAMES_DIR    = os.path.join(OUT_DIR, "vision_frames")
STREAM_FILE   = os.path.join(OUT_DIR, "vision_stream.jsonl")
PID_FILE      = os.path.join(OUT_DIR, "vision_daemon.pid")
LOG_FILE      = os.path.join(OUT_DIR, "vision_daemon.log")
LATEST_SCREEN = os.path.join(FRAMES_DIR, "latest_screen.jpg")
LATEST_CAM    = os.path.join(FRAMES_DIR, "latest_cam.jpg")

CAPTURE_INTERVAL  = 6       # seconds between captures
SCREEN_CHANGE_THR = 0.04    # 4% pixel change = significant
CAM_CHANGE_THR    = 0.06    # 6% pixel change for webcam (more noise)
MAX_STREAM_LINES  = 300     # keep stream file bounded
THUMB_SIZE        = (320, 240)


# ─── LOGGING ──────────────────────────────────────────────────────────────────

def log(msg):
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ─── SCREEN CAPTURE ───────────────────────────────────────────────────────────

_mss_instance = None

def capture_screen():
    """Grab current screen. Returns PIL Image or None."""
    global _mss_instance
    if not HAS_MSS:
        return None
    try:
        if _mss_instance is None:
            _mss_instance = mss.MSS()
        monitor = _mss_instance.monitors[1]
        shot = _mss_instance.grab(monitor)
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        return img
    except Exception as e:
        log(f"SCREEN capture error: {e}")
        _mss_instance = None
        return None


# ─── WEBCAM CAPTURE ───────────────────────────────────────────────────────────

def capture_webcam():
    """
    Grab one frame from webcam using ffmpeg.
    Uses a temp file so we don't hold /dev/video0 open between captures.
    Falls back to /dev/video1 if video0 is busy.
    Returns PIL Image or None.
    """
    for device in ["/dev/video0", "/dev/video1"]:
        if not os.path.exists(device):
            continue
        try:
            tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
            tmp.close()
            result = subprocess.run([
                "ffmpeg", "-y",
                "-f", "v4l2",
                "-input_format", "mjpeg",
                "-video_size", "640x480",
                "-i", device,
                "-frames:v", "1",
                "-q:v", "3",
                tmp.name
            ], capture_output=True, timeout=5)
            if result.returncode == 0 and os.path.exists(tmp.name):
                img = Image.open(tmp.name).copy()
                os.unlink(tmp.name)
                return img
            else:
                try:
                    os.unlink(tmp.name)
                except Exception:
                    pass
        except subprocess.TimeoutExpired:
            log(f"CAM timeout on {device}")
        except Exception as e:
            log(f"CAM error on {device}: {e}")
    return None


# ─── PIXEL DIFF ───────────────────────────────────────────────────────────────

def pixel_diff(img_a, img_b):
    """
    Returns 0.0-1.0 fraction of pixels that changed significantly.
    Both images downscaled to THUMB_SIZE for speed.
    """
    if img_a is None or img_b is None:
        return 1.0  # treat missing as full change
    try:
        a = img_a.resize(THUMB_SIZE).convert("L")
        b = img_b.resize(THUMB_SIZE).convert("L")
        arr_a = np.array(a, dtype=np.float32)
        arr_b = np.array(b, dtype=np.float32)
        diff = np.abs(arr_a - arr_b)
        changed = np.sum(diff > 15)  # pixel changed by more than 15/255
        return float(changed) / diff.size
    except Exception:
        return 1.0


def frame_hash(img):
    if img is None:
        return ""
    try:
        small = img.resize((64, 48)).convert("L")
        return hashlib.md5(small.tobytes()).hexdigest()[:16]
    except Exception:
        return ""


# ─── STREAM WRITER ────────────────────────────────────────────────────────────

def write_event(event_type, novelty, frame_path=None, extra=None):
    """Append one event to vision_stream.jsonl. Keep file bounded."""
    entry = {
        "ts": datetime.datetime.now().isoformat(timespec="seconds"),
        "type": event_type,
        "novelty": round(novelty, 4),
    }
    if frame_path:
        entry["frame"] = os.path.relpath(frame_path, OUT_DIR)
    if extra:
        entry.update(extra)

    try:
        with open(STREAM_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
        # Trim file to MAX_STREAM_LINES
        _trim_stream()
    except Exception as e:
        log(f"STREAM write error: {e}")


def _trim_stream():
    try:
        with open(STREAM_FILE, "r") as f:
            lines = f.readlines()
        if len(lines) > MAX_STREAM_LINES:
            with open(STREAM_FILE, "w") as f:
                f.writelines(lines[-MAX_STREAM_LINES:])
    except Exception:
        pass


# ─── SAVE SNAPSHOT ────────────────────────────────────────────────────────────

def save_snapshot(img, kind):
    """
    Save a frame to vision_frames/.
    Always overwrites latest_{kind}.jpg.
    Returns path.
    """
    if img is None:
        return None
    try:
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(FRAMES_DIR, f"{kind}_{ts}.jpg")
        thumb = img.resize(THUMB_SIZE)
        thumb.save(path, "JPEG", quality=80)

        # Update latest symlink
        latest = os.path.join(FRAMES_DIR, f"latest_{kind}.jpg")
        if os.path.exists(latest):
            os.remove(latest)
        os.symlink(path, latest)
        return path
    except Exception as e:
        log(f"SNAPSHOT save error: {e}")
        return None


# ─── MAIN LOOP ────────────────────────────────────────────────────────────────

class VisionDaemon:
    def __init__(self):
        self.prev_screen = None
        self.prev_cam = None
        self.screen_captures = 0
        self.cam_captures = 0
        self.screen_events = 0
        self.cam_events = 0
        self.running = False

    def run_once(self):
        """One full capture cycle. Returns dict of results."""
        results = {"screen": None, "cam": None}

        # Screen
        screen = capture_screen()
        if screen is not None:
            self.screen_captures += 1
            diff = pixel_diff(self.prev_screen, screen)
            if diff >= SCREEN_CHANGE_THR:
                path = save_snapshot(screen, "screen")
                write_event("screen_change", diff, path)
                self.screen_events += 1
                results["screen"] = {"novelty": diff, "path": path}
            self.prev_screen = screen

        # Cam
        cam = capture_webcam()
        if cam is not None:
            self.cam_captures += 1
            diff = pixel_diff(self.prev_cam, cam)
            if diff >= CAM_CHANGE_THR:
                path = save_snapshot(cam, "cam")
                write_event("cam_change", diff, path)
                self.cam_events += 1
                results["cam"] = {"novelty": diff, "path": path}
            self.prev_cam = cam

        return results

    def loop(self):
        """Main loop. Runs forever until SIGTERM/SIGINT."""
        self.running = True
        log(f"Vision daemon started. PID={os.getpid()}")
        log(f"Screen backend: {'mss' if HAS_MSS else 'none'}")
        log(f"Output: {OUT_DIR}")

        write_event("daemon_start", 0.0, extra={
            "pid": os.getpid(),
            "interval": CAPTURE_INTERVAL,
            "screen_thr": SCREEN_CHANGE_THR,
            "cam_thr": CAM_CHANGE_THR,
        })

        # Prime prev frames so first real cycle doesn't false-trigger
        log("Priming initial frames...")
        self.prev_screen = capture_screen()
        self.prev_cam = capture_webcam()
        log(f"Primed: screen={'ok' if self.prev_screen else 'FAILED'}, cam={'ok' if self.prev_cam else 'FAILED'}")

        cycle = 0
        while self.running:
            try:
                results = self.run_once()
                cycle += 1
                if cycle % 10 == 0:
                    log(f"Cycle {cycle} — screen: {self.screen_events}/{self.screen_captures} events, "
                        f"cam: {self.cam_events}/{self.cam_captures} events")
            except Exception as e:
                log(f"Cycle error: {e}\n{traceback.format_exc()}")
            time.sleep(CAPTURE_INTERVAL)

        log("Vision daemon stopped.")


# ─── DAEMON MANAGEMENT ────────────────────────────────────────────────────────

def start_daemon():
    """Fork and run as background daemon."""
    if is_running():
        pid = read_pid()
        print(f"Already running. PID={pid}")
        return

    # Double-fork to detach from terminal
    pid = os.fork()
    if pid > 0:
        # Parent — write PID and exit
        time.sleep(0.5)  # Let child write PID
        if is_running():
            print(f"Vision daemon started. PID={read_pid()}")
        else:
            print("Vision daemon start may have failed. Check:", LOG_FILE)
        return

    # Child process
    os.setsid()
    pid2 = os.fork()
    if pid2 > 0:
        os._exit(0)

    # Grandchild — actual daemon
    os.makedirs(FRAMES_DIR, exist_ok=True)
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    # Redirect stdio
    with open(LOG_FILE, "a") as log_fd:
        os.dup2(log_fd.fileno(), sys.stdout.fileno())
        os.dup2(log_fd.fileno(), sys.stderr.fileno())

    def handle_term(sig, frame):
        daemon.running = False

    signal.signal(signal.SIGTERM, handle_term)
    signal.signal(signal.SIGINT, handle_term)

    try:
        daemon = VisionDaemon()
        daemon.loop()
    finally:
        try:
            os.remove(PID_FILE)
        except Exception:
            pass


def stop_daemon():
    pid = read_pid()
    if pid is None:
        print("Not running.")
        return
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        if is_running():
            os.kill(pid, signal.SIGKILL)
            print(f"Killed PID {pid}")
        else:
            print(f"Stopped PID {pid}")
        try:
            os.remove(PID_FILE)
        except Exception:
            pass
    except ProcessLookupError:
        print(f"PID {pid} not found. Cleaning up.")
        try:
            os.remove(PID_FILE)
        except Exception:
            pass


def read_pid():
    try:
        with open(PID_FILE) as f:
            return int(f.read().strip())
    except Exception:
        return None


def is_running():
    pid = read_pid()
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def status():
    if is_running():
        pid = read_pid()
        print(f"RUNNING — PID {pid}")
        # Show last few stream events
        try:
            with open(STREAM_FILE) as f:
                lines = f.readlines()
            recent = lines[-5:]
            print(f"Last {len(recent)} vision events:")
            for line in recent:
                try:
                    e = json.loads(line)
                    print(f"  {e['ts']} [{e['type']}] novelty={e['novelty']:.3f}")
                except Exception:
                    print(f"  {line.strip()}")
        except FileNotFoundError:
            print("  No events yet.")
    else:
        print("STOPPED")


def tail_stream(n=10):
    try:
        with open(STREAM_FILE) as f:
            lines = f.readlines()
        recent = lines[-n:]
        if not recent:
            print("No vision events yet.")
            return
        print(f"Last {len(recent)} vision events:")
        for line in recent:
            try:
                e = json.loads(line)
                print(f"  {e['ts']} [{e['type']:14s}] novelty={e['novelty']:.3f}"
                      + (f"  {e.get('frame','')}" if e.get('frame') else ""))
            except Exception:
                print(f"  {line.strip()}")
    except FileNotFoundError:
        print("No stream file yet. Is the daemon running?")


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs(FRAMES_DIR, exist_ok=True)

    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"

    if cmd == "start":
        start_daemon()

    elif cmd == "stop":
        stop_daemon()

    elif cmd == "restart":
        stop_daemon()
        time.sleep(1)
        start_daemon()

    elif cmd == "status":
        status()

    elif cmd == "once":
        # One cycle, print what we see, don't daemonize
        print("Running one capture cycle...")
        d = VisionDaemon()
        d.prev_screen = None
        d.prev_cam = None
        results = d.run_once()
        print(f"Screen: {results['screen']}")
        print(f"Cam:    {results['cam']}")

    elif cmd == "tail":
        n = int(sys.argv[2]) if len(sys.argv) > 2 else 10
        tail_stream(n)

    else:
        print(__doc__)
