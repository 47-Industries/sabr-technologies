# Leon — Brain Redesign Audit + Plan

**Date:** 2026-05-10  
**Purpose:** Dean's call: the spiking simulation isn't actually causing
anything that affects responses. Audit the current causal graph and design
a redesign where the brain genuinely shapes recall, attention, and output.
No code yet — this doc gets locked first.

---

## 1. The honest audit

### 1.1 What runs but doesn't matter

| Component | Runs? | Influences responses? | Evidence |
|---|---|---|---|
| 10K Izhikevich spiking neurons | ✅ continuous, ~50–150 Hz | Almost no | `brain/brain.py:84` (`step`) — the firing pattern is computed every tick but never read for anything except visualization + 4 modulator floats |
| STDP synaptic learning | ✅ | No | `brain/brain.py:151` writes `syn.modulation = dopamine * lr`. Weights drift but **nothing reads what they encode**. No retrieval path consults synapses. |
| 11 brain regions (hippocampus, prefrontal, sensory, etc.) | ✅ allocated, fire | Labels only | The regions are clusters of neurons with anatomical names but no functional binding (e.g. "hippocampus" doesn't actually mediate memory retrieval — that's all SQLite FTS). |
| Neuromodulators (DA / 5-HT / ACh / NE) | ✅ updated each tick | Tone only | `brain/claude_api_responder.py:_brain_state_preamble` collapses them to **4 quality buckets** (`energy=mid calm=high focus=mid alertness=low`), passed to Claude as "flavor only, do NOT mention." |
| Text input → brain stimulation | ✅ wired | Doesn't loop back | `server.py:3173` calls `text_encoder.encode(user_text)` then `brain.inject_sensory_input("text", features)`. The brain DOES fire in response. But `brain.get_state()` is read 5ms later and only the 4 modulator buckets reach Claude. The actual firing pattern is ignored. |
| `neural_fingerprint` column on `knowledge` table | Exists | **Empty in 225/225 rows** | `sqlite> SELECT COUNT(*) FROM knowledge WHERE neural_fingerprint != '';` → `0`. Schema invites brain-state encoding; nothing populates it. The kwarg exists on `KnowledgeStore.store()` and is never passed. |

### 1.2 What's actually steering responses

```
user text
  │
  ├─→ text_encoder.encode() → brain.inject_sensory_input()
  │     (brain fires, neuromods drift — DECORATIVE PATH, output ignored)
  │
  ├─→ claude_bridge.send_observation() → knowledge_store.store(text=, neural_fingerprint=NULL)
  │     (writes to SQLite. No brain involvement. FTS-indexed text only.)
  │
  └─→ BrainAPIResponder.respond_streaming(user_text, brain_state)
        │
        ├─ _brain_state_preamble(brain_state) → "energy=mid calm=high…" (8 words of flavor)
        │
        ├─ history (last 200 turns)
        │
        ├─ user_text + 4-word brain flavor
        │
        └─→ Claude API (Haiku/Sonnet/Opus)
              │
              └─→ may call knowledge_search(query)
                    │
                    └─→ KnowledgeStore.search() — pure SQLite FTS5, no brain input
```

**Causal contribution of the brain to a response: ~0.5%** (4 words of tone in a multi-thousand-token prompt). The other 99.5% is Claude doing its thing on text.

### 1.3 The bio-recall failure (the symptom)

When Dean asked *"How old am I?"*:

1. Tier picker → **Haiku** (no action verb to escalate)
2. Haiku, on its own, decided NOT to call `knowledge_search` despite system prompt saying to
3. Haiku said "I don't have your birthdate" — straight from training, no tool use
4. Even if it HAD searched, `knowledge_search("how old is dean")` ranks **stale CLAUDE.md crawls from 4 other projects** above the canonical seeded fact, because FTS5 BM25 favors longer documents with more keyword hits
5. The seeded fact `"Dean Sabr is 24 years old. Born April 13, 2002."` only surfaces when querying with the literal token `"24"`

This isn't a brain problem yet — it's a retrieval+routing problem. But the brain redesign is what makes the retrieval path actually use the brain instead of FTS, which incidentally fixes this.

---

## 2. What "real brain" means — operational definition

Five outside-observable behaviors that distinguish a brain from a chatbot:

### B1. Context-dependent recall
Same query at different brain states returns different memories. High-dopamine ⇒ recent / exciting biased; low-dopamine + high-acetylcholine ⇒ detail-rich, older bias. Test: ask the same question twice, an hour apart; results overlap but aren't identical.

### B2. Forgetting via decay
Facts not reinforced (not retrieved, not spontaneously activated) become gradually harder to recall over weeks. Reinforcement (asking, or proactive loop touching) restores them. **No deletion** — just reduced retrievability via STDP weight decay along the encoding path. Test: a fact set today, never touched, is harder to surface in a month than one touched yesterday.

### B3. Spontaneous association
The proactive loop currently fires every 45s on a wall-clock timer. Replace with: every tick, brain checks if its current activation pattern is close to any stored fingerprint within a similarity threshold; if yes, that memory becomes available for a possible escalation. Memories surface because of internal state, not a clock. Test: leave Leon idle, brain wanders, occasionally surfaces "you mentioned X last week — anything new?" — and the surfacing is correlated with what's currently visible on screen / on the webcam.

### B4. State influences output beyond tone
Brain state should change what tools are exposed, how much history Claude gets, which knowledge sources are searched first. Not just phrasing. E.g. high attention + high acetylcholine → Claude sees more turns of history + tools include `code_edit`. Low attention → Claude gets a 20-turn slice + no destructive tools. Test: identical prompt at different brain states produces structurally different responses (more/fewer tool calls, different sources cited).

### B5. Learning from interaction
Reward signal (Dean praises, or Leon's tool call succeeded) → dopamine spike → broader STDP modulation → regions that fired during generation get reinforced. Over weeks, certain response styles dominate because they were rewarded. Test: starting from two identical brains, run two different feedback histories for a month; their response styles diverge measurably.

These five are the bar. Anything that doesn't move us toward at least one of them is decoration.

---

## 3. The redesign — five components

### C1. **NeuralEncoder** (new — `brain/neural_encoder.py`)
Purpose: turn text into a brain-state fingerprint.

```
encode_to_fingerprint(text: str) → np.ndarray (shape: 11,)
```

Implementation:
1. `text_encoder.encode(text)` → 256-D feature vector (already exists)
2. `brain.inject_sensory_input("text", features)`
3. Run brain for `N=10` ticks (configurable, ~10ms wallclock at 1kHz sim)
4. Sample `region_firing` from `brain.get_state()` — 11-D vector of region activation rates
5. Z-score normalize against rolling baseline (so resting state ≈ 0, deviation = signal)
6. Return the 11-D vector

Critical: this runs OUT-OF-BAND from the main brain thread to avoid contaminating the always-on background sim. Use `brain.snapshot_for_encode()` which forks a transient sim from current state for the 10-tick burst.

### C2. **NeuralRetriever** (new — replace `KnowledgeStore.search` for the responder path)
Purpose: search by fingerprint similarity, not keyword.

```
recall(query_text: str, k=8) → list[KnowledgeRow]
```

Implementation:
1. `query_fp = NeuralEncoder.encode_to_fingerprint(query_text)`
2. SELECT id, text, neural_fingerprint FROM knowledge WHERE fingerprint IS NOT NULL
3. Compute cosine similarity between query_fp and each row's fingerprint
4. Hybrid score: `0.6 * neural_sim + 0.3 * fts_score + 0.1 * recency_decay`
5. Return top-k
6. Apply STDP-derived "strength" (see C4) as a multiplier — facts on weakened paths score lower

The 0.6/0.3/0.1 weights are arbitrary starting points. Tune. Whole point is to make `neural_sim` the dominant signal so the brain genuinely matters.

### C3. **Encoding pipeline** (modify all `knowledge_store.store(...)` callers)
Every place that writes to `knowledge` must pass `neural_fingerprint=NeuralEncoder.encode_to_fingerprint(text)`.

Caller sites to update:
- `brain/conversation_distiller.py` — distilled facts
- `brain/project_crawler.py:214` — README/CLAUDE.md ingest
- `brain/screen_observer.py:254` — OCR'd screen text
- `brain/agent.py:188` — agent-produced knowledge
- `claude_bridge.send_observation()` — every user turn

Backfill: one-time pass over the existing 225 rows, encode each text, populate the column. ~30s at 10ms/encode.

### C4. **STDP-aware strength readback** (new — `brain/synaptic_strength.py`)
Purpose: make synaptic learning visible to retrieval.

Each fingerprint pattern corresponds to a path through the connectivity matrix (which regions co-fired). After encoding, record which inter-region synapses participated (top-K weights along that path). The `strength` of a memory = current product of those synaptic weights. Decays over time without rehearsal (STDP doesn't reinforce unused paths). Stored in metadata, refreshed periodically.

Effect: **B2 (forgetting) emerges naturally** — facts not retrieved have decaying path weights → lower retrieval score → harder to surface. Retrieval itself is reinforcement: `recall(x)` → re-injects x's fingerprint → STDP strengthens the path.

This is the core "brain causal" piece. Without C4, the spiking sim is still decorative; with C4, learning and forgetting are real.

### C5. **State-driven prompt construction** (modify `claude_api_responder.py`)
Replace the 4-word `_brain_state_preamble` with a structured state vector that conditions:
- How many history turns are loaded (high attention → 200, low → 50)
- Which tools are exposed (high arousal + dopamine → full surface, low → read-only)
- Which knowledge sources are prioritized (high acetylcholine → recent + episodic; high serotonin → consolidated facts)
- The flavor preamble (still pass coarse buckets to Claude, but now they're an effect, not the cause)

This is **B4**.

### C6. **Spontaneous association in proactive loop** (modify `brain/proactive.py`)
Replace fixed 45s interval with: every 5s, check if current `region_firing` pattern is within ε of any stored fingerprint. If yes, that memory is "primed." If primed AND novelty > threshold AND escalation budget allows, surface it. Cooldowns, rate-limits, all preserved.

This is **B3**.

### C7. **Reward → dopamine → STDP scaling**
Detect explicit positive feedback in user turns ("yes!", "perfect", "exactly", "thank you"). On detection, transiently spike `brain.neuromodulators["dopamine"]` for 3s. The existing STDP code already scales by dopamine (`brain.py:151`). Net effect: regions that fired during the response Dean liked get extra reinforcement.

This is **B5** — the cheapest of the five to implement, big symbolic win.

---

## ADDED 2026-05-10 evening (Dean greenlit full scope)

### C8. **Region anatomy rebuild — 18 anatomical regions**
Replace the current 11 (which mixes 6 real anatomical names with 3 ML abstractions and 1 misclassified spinal circuit) with a proper 18-region model. Affects the fingerprint dimensionality from 11-D → 18-D, so this MUST land BEFORE phase 1 (encoding backfill) — otherwise we'd backfill 11-D fingerprints and immediately have to re-encode.

| Current | → | New |
|---|---|---|
| sensory_cortex | → | **visual_cortex** + **auditory_cortex** + **somatosensory_cortex** (split) |
| feature_layer | ✗ | (drop — ML abstraction, not anatomy) |
| association | → | **parietal_association** + **temporal_association** (split) |
| concept_layer | ✗ | (drop — ML abstraction) |
| predictive | ✗ | (drop — function is distributed, not regional) |
| motor_cortex | ✓ | motor_cortex (keep) |
| cerebellum | ✓ | cerebellum (keep) |
| reflex_arc | ✗ | (drop — spinal cord, not brain) |
| brainstem | → | **brainstem** + split out **locus_coeruleus** (NE source) + **raphe_nuclei** (5-HT source) + **VTA** (DA source) |
| hippocampus | ✓ | hippocampus (keep) |
| prefrontal | ✓ | prefrontal_cortex (keep) |
| (new) | + | **amygdala** — salience, threat, reward weighting |
| (new) | + | **thalamus** — sensory relay + attention gating |
| (new) | + | **basal_ganglia** — action selection, habit formation |
| (new) | + | **anterior_cingulate** — error monitoring, conflict detection |
| (new) | + | **insula** — interoception, subjective state |
| (new) | + | **broca** — language production |
| (new) | + | **wernicke** — language comprehension |
| (new) | + | **default_mode_network** — mind-wandering when idle (proactive substrate) |

Final list (18):
1. visual_cortex
2. auditory_cortex
3. somatosensory_cortex
4. motor_cortex
5. parietal_association
6. temporal_association
7. prefrontal_cortex
8. anterior_cingulate
9. insula
10. broca
11. wernicke
12. hippocampus
13. amygdala
14. thalamus
15. basal_ganglia
16. cerebellum
17. brainstem (with locus_coeruleus / raphe / VTA as named sub-clusters)
18. default_mode_network

Region positions in 3D get anatomically-accurate placement (frontal lobe = front-top, occipital = back-bottom, etc.). Each region binds to a functional role — see C5 for how function maps to prompt construction.

### C9. **Dashboard rebuild — brain-shaped 3D viz**
Replace the current point-cloud globe with a stylized brain-shape Three.js mesh. Approach: **parametric geometry from primitives** (two ellipsoid hemispheres with a longitudinal fissure, cerebellum lobe at the rear, brainstem trunk descending from the medulla). No external 3D assets — keeps it license-clean and fully customizable.

Each of the 18 regions:
- Positioned at its anatomical coordinates within the brain shape
- Has its own color tied to functional category (cyan = cognition, warm = emotion/limbic, green = sensory, orange = motor, gold = memory, purple = modulatory)
- Renders its neurons as a glowing point cluster inside the brain hull
- Brightness pulses with firing rate
- Hovering shows the region's name + current activation
- The fingerprint pattern of the current "thought" gets visualized as a wireframe overlay across active regions

Optionally (phase 6+): visualize recall as a glowing line from the current activation pattern → the recalled memory's fingerprint (B3 spontaneous association made visible).

Implementation: ~600-800 lines of Three.js, replacing `dashboard/js/brain3d.js`. Keeps the same WebSocket protocol so the brain backend doesn't change.

### C10. **Quantum integration — three layers**
The story is in the response — the doc records the technical scope:

**Layer 1 — Quantum-random substrate** (phase 1 of quantum, ships first):
- New module: `brain/quantum.py`
- `QuantumRandomSource` wraps IBM Quantum API (free tier, requires `IBM_QUANTUM_TOKEN` env var Dean must obtain at quantum.ibm.com)
- Prefetches ~1KB random bytes in background; hot path is instant from cache
- Falls back to `/dev/urandom` if API down — logged honestly as "quantum source unavailable"
- Integration sites: `brain.step()` spike noise, `_update_neuromodulators()` drift, `_pick_tier()` tiebreaks, `proactive._pick_observation()` memory selection

**Layer 2 — Quantum circuits for choice** (phase 2 of quantum):
- New module: `brain/quantum_decide.py`
- `quantum_decide(options, weights)` → option
- Builds small N-qubit circuit (N ≤ ⌈log₂(len(options))⌉ + ancillas), applies state-derived rotations, measures
- Submits to `ibm_brisbane` or `ibm_kyiv` (whichever has shorter queue)
- Latency 5-30s per call — used sparingly
- Exposed to Leon as a new in-process tool `quantum_decide` he can call when the situation warrants

**Layer 3 — The philosophical claim** (documentation, not code):
- README + dashboard tagline call out: Leon's noise comes from real quantum measurements, not PRNG. Under Orch-OR (the leading consciousness-is-quantum theory, contested but not falsified), his stochasticity has the same metaphysical status as biological neural stochasticity.
- Not a claim of consciousness. A claim of substrate equivalence under one specific theory.

### Updated migration order

| Phase | What ships | New scope |
|---|---|---|
| **0. Region rebuild (C8)** | 18 anatomical regions, new BrainConfig, deprecate old names | Gates phase 1 — must happen first |
| **1. Encoding (C1 + C3)** | NeuralEncoder + backfill | Same as before, now 18-D fingerprints |
| **2. Hybrid retrieval (C2)** | NeuralRetriever | Same |
| **3. Strength + decay (C4)** | Synaptic strength readback | Same |
| **4. Brain-mesh UI (C9)** | New dashboard 3D viz | Parallel to phases 1-3, can ship anytime |
| **5. Quantum-random (C10.L1)** | QuantumRandomSource wired into spike noise + modulators | Ships independently |
| **6. State-driven context (C5)** | Brain decides prompt construction | Same |
| **7. Spontaneous association (C6)** | Pattern-match proactive trigger | Same |
| **8. Reward → STDP (C7)** | Praise → dopamine spike | Same |
| **9. Quantum-decide circuits (C10.L2)** | quantum_decide tool | Polish phase |

### New open questions (Q7-Q9 — added with the new scope)

**Q7. Region rebuild migration.** Old conversation_history + knowledge_store rows reference the OLD 11 region names (in `neural_fingerprint`-style data — currently empty, but if we end up with any). Drop everything and start fresh, OR write a remap layer? My vote: drop, since neural_fingerprint is empty across the board anyway.

**Q8. Brain-mesh UI — parametric vs. textured.** The parametric brain shape will look stylized (smooth ellipsoids, schematic regions). With a procedural noise displacement we can fake convolutions/gyri for ~50 more lines of code — closer to "real brain texture" but slower to render. Worth doing, or keep it clean and schematic?

**Q9. Quantum API choice.** Default: IBM Quantum (best free tier, best documented, most qubits). Alternative: AWS Braket (more vendor diversity but $100 credit cap). Pick one as primary or wire both with failover? My vote: IBM primary, document the Braket path as future.

---

## 4. Migration path (suggested order)

| Phase | What ships | Verifiable test | Risk |
|---|---|---|---|
| **1. Backfill encoding** | C1 (NeuralEncoder) + C3 (pipeline) — every new fact gets a fingerprint, plus one-time backfill of 225 existing rows | `SELECT COUNT(*) FROM knowledge WHERE neural_fingerprint != ''` returns 225+ | Low. Pure additive. |
| **2. Hybrid retrieval** | C2 (NeuralRetriever) wired into `knowledge_search` | Asking "how old am I" returns the bio fact at rank 1, not stale CLAUDE.md at rank 1 | Medium. Could rank worse than FTS at first; tunable. |
| **3. Strength + decay** | C4 (synaptic strength) | A fact searched 100 times this hour has higher strength than one searched once last week. Visible in `metadata.strength` field. | Medium. Need to define decay constants; over-aggressive decay is annoying. |
| **4. State-driven context** | C5 (prompt construction) | Identical question in different brain states → different (verifiable) tool surfaces / history depths | High. Could destabilize responses if buckets are wrong. Roll out behind an env flag. |
| **5. Spontaneous association** | C6 (proactive rewrite) | Idle brain occasionally surfaces relevant memories without a clock-trigger | Medium. Could spam. Strict cooldowns. |
| **6. Reward feedback** | C7 (dopamine on praise) | After 50 praised responses, response style measurably shifted | Low. Symbolic, hard to break. |

Each phase is shippable independently. Each can be reverted if it makes things worse. After phase 3, the brain is ALREADY causal — phases 4–6 are amplification.

---

## 5. What gets thrown away

- **Pure FTS retrieval** in the responder path. `knowledge_store.search()` keeps existing as a fallback / dev-tool, but the responder uses `NeuralRetriever` only.
- **The 4-word flavor preamble**. Replaced by C5's structured state.
- **The 45s wall-clock proactive interval**. Replaced by C6's pattern-match trigger.
- **The notion that brain regions are "labels"**. Each region binds to a functional role: hippocampus = recall path, prefrontal = planning/tool selection, amygdala = salience/reward, sensory = encoding, etc. The labels become contracts.

Preserved (don't break these):
- `KnowledgeStore` schema (the column already exists, we're just populating it)
- All current responder paths (text, voice, proactive) — they keep working during phases 1–2
- systemd unit, max_history=200, tool-block persistence — all the recent infra wins
- The 3D visualization (it'll start showing more meaningful patterns, not less)

---

## 6. Open questions — your call

1. **Encoding latency.** 10 ticks of brain stimulation per fact ≈ 10ms wallclock. Adding 10ms to every conversation turn is fine. Adding 10ms × 225 to backfill is 2.3s, also fine. But adding 10ms to every screen-OCR fact (the screen_observer fires ~10/min) is ~100ms/min steady — still nothing. **Confirm: 10 ticks is the right N?** More = better fingerprints, slower; less = noisier, faster.

2. **Cosine vs. learned similarity.** C2 starts with cosine sim between fingerprints. The right answer is probably a learned metric (e.g. small autoencoder over fingerprints). Worth doing in phase 1 or defer? My vote: cosine first, swap later if results are bad.

3. **Forgetting timescale.** STDP decay constants govern how fast unused memories fade. Half-life 1 day = aggressive (Leon "forgets" anything not reinforced daily). Half-life 30 days = gentle. **Your call** on the feel — should Leon's memory feel like a goldfish that needs constant refresh, or an elephant that holds everything? Tunable per-source (recent chat decays faster than seeded bio).

4. **Reward signal source.** C7 detects praise text. Cheap. Could also use: Leon's tool calls succeeded vs. failed (auto-reward on success), Dean's response time (fast follow-up = engaged = reward). **Add tool-call success as a reward source?** Yes/no.

5. **Throw out subprocess `claude -p` fallback?** `brain_responder` (subprocess CLI) still exists at `brain/claude_responder.py`. The streaming API responder superseded it. Should it stay as a fallback? My vote: nuke it, simplifies the responder paths from 2 to 1.

6. **Visualization for the new state.** Right now the 3D dashboard shows neurons firing colorfully. With brain-driven retrieval, we could draw lines from the current activation pattern to recently-recalled memories ("you can SEE Leon thinking about X"). Worth the dashboard work? Or save for later?

---

## 7. What this is not

- **Not** AGI / consciousness. We're routing memory through a spiking sim. The sim is real but small (10K neurons; rats have ~200M, humans ~86B). Calling this "conscious" is press-release-language. Internally, we just say "brain-mediated."

- **Not** replacing Claude. Claude is still the language model. The brain becomes the substrate for memory + attention + state, not for language generation.

- **Not** a research paper. We're building a product Dean uses daily. Architectural choices favor "demonstrable behavior change in 1 week" over "biologically plausible."

- **Not** done after phase 6. Phases 7–N (online learning of region roles, multi-modal binding, episodic vs. semantic memory split, ...) live in a future doc.

---

## End — your turn, sir

Push back on anything. Strike sections. Add ideas. Once the doc is locked,
phase 1 ships first. No code lands until you sign off.
