#!/bin/bash
# Start Leon brain on VPS — 100K neurons, split-brain architecture
# Body/sensors are on Dean's PC, brain is here.
cd /opt/leon-brain

# Source .env
set -a
source .env 2>/dev/null
set +a

# Leon env
export LEON_QUANTUM_SOURCE=aer
export LEON_HOST_ROLE=brain
export LEON_COGNITION_PROMPT=on
export LEON_COGNITION_AUTOPILOT=on
export LEON_COGNITION_RETRIEVAL=on
export LEON_EXECUTIVE_AUTHORITATIVE=on
# Allow claude CLI as root
export IS_SANDBOX=1
# LEON_AUTONOMOUS_UNRESTRICTED now controlled by mode presets in /etc/leon/secrets.env

export LEON_PC_RELAY_URL="http://127.0.0.1:9100/actuator"
export LEON_REMOTE_PC_HOST="deansabr@100.64.191.119"
export LEON_REMOTE_PC_OS="linux"
exec python3 run.py --neurons 100000 --host 0.0.0.0 --port 8000
