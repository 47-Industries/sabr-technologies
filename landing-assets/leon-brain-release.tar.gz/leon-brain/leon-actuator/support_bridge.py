#!/usr/bin/env python3
"""
support_bridge.py — Leon's live hands-on channel into a client machine.

THE IDEA (Dean, 2026-07-02):
  Instead of guessing how the installer behaves on a real client Mac, open a
  live channel into a customer's machine while it's actually failing. Leon SEES the
  screen in real time, DRIVES the mouse/keyboard through the actuator, reads
  the logs, and fixes things by hand. Every real fix he makes gets recorded to
  a fix-journal. After enough live back-and-forth, those journalled fixes are
  folded back into install_client.py — so the NEXT person installs hands-off,
  no Leon babysitting required. The live session is temporary; the recipe is
  permanent.

WHAT THIS DOES on the client:
  1. Ensures Tailscale is installed + joined (the secure transport — no open
     ports to the public internet, auth is the tailnet identity).
  2. Starts the actuator (Leon's hands) bound to loopback.
  3. Starts the MJPEG screen stream (Leon's eyes) — view_leon_web.py.
  4. Runs the macOS permission probe and prints exactly what's blocked.
  5. Prints the tailnet address + a fix-journal path for Leon to attach to.

Run on the client:  python3 support_bridge.py --si-name Jarvis
Then Leon attaches over Tailscale, works live, and appends every fix to the
journal. Tear down with Ctrl-C — nothing is left listening publicly.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SYSTEM = __import__("platform").system()  # Linux / Darwin / Windows
JOURNAL = HERE / "fix_journal.jsonl"


def _log(msg: str) -> None:
    print(f"[support] {msg}", flush=True)


def _has(binary: str) -> bool:
    return shutil.which(binary) is not None


# ── 1. Tailscale — the secure transport ────────────────────────────────
def ensure_tailscale() -> str:
    """Make sure tailscale is installed and the node is up. Returns the
    tailnet IP, or '' if the user still needs to authenticate."""
    if not _has("tailscale"):
        _log("Tailscale not found — installing…")
        if SYSTEM == "Darwin":
            if _has("brew"):
                subprocess.run(["brew", "install", "tailscale"], check=False)
            else:
                _log("Install Tailscale from https://tailscale.com/download/mac then re-run")
                return ""
        elif SYSTEM == "Linux":
            subprocess.run(["sh", "-c",
                            "curl -fsSL https://tailscale.com/install.sh | sh"], check=False)
        else:
            _log("Install Tailscale for Windows from tailscale.com/download then re-run")
            return ""
    # Bring the node up (idempotent). --ssh lets Leon get a real shell too.
    subprocess.run(["tailscale", "up", "--ssh", "--accept-routes"], check=False)
    try:
        r = subprocess.run(["tailscale", "ip", "-4"], capture_output=True, text=True, timeout=10)
        ip = r.stdout.strip().splitlines()[0] if r.stdout.strip() else ""
    except Exception:
        ip = ""
    if not ip:
        _log("Tailscale needs sign-in — run `tailscale up` and approve, then re-run")
    return ip


# ── 2 + 3. Eyes and hands ──────────────────────────────────────────────
def start_actuator() -> subprocess.Popen | None:
    act = HERE / "actuator.py"
    if not act.exists():
        _log("actuator.py missing — hands unavailable")
        return None
    _log("Starting actuator (Leon's hands) on loopback…")
    return subprocess.Popen([sys.executable, str(act)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def start_screen_stream(port: int = 8765) -> subprocess.Popen | None:
    # view_leon_web.py lives one level up in the brain root.
    viewer = HERE.parent / "view_leon_web.py"
    if not viewer.exists():
        _log("view_leon_web.py missing — screen stream unavailable")
        return None
    _log(f"Starting screen stream (Leon's eyes) on :{port}…")
    return subprocess.Popen([sys.executable, str(viewer), "--port", str(port)],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ── 4. What's actually blocked ─────────────────────────────────────────
def permission_report() -> dict:
    try:
        sys.path.insert(0, str(HERE))
        from platform_compat import platform as P  # type: ignore
        status = P.permissions_status()
    except Exception as e:
        status = {"error": str(e)}
    _log(f"Permission status: {json.dumps(status)}")
    return status


# ── 5. The fix-journal — this is what makes the recipe ─────────────────
def journal_fix(problem: str, fix: str, applies_to: str = "install_client.py") -> None:
    """Every real fix Leon makes during a live session gets appended here.
    Later these get rolled into the installer so the next client is hands-off."""
    entry = {"ts": time.time(), "os": SYSTEM, "problem": problem,
             "fix": fix, "applies_to": applies_to, "folded_in": False}
    with open(JOURNAL, "a") as f:
        f.write(json.dumps(entry) + "\n")
    _log(f"Journalled fix → {JOURNAL}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--si-name", default="Jarvis", help="what this SI calls itself")
    ap.add_argument("--port", type=int, default=8765, help="screen stream port")
    args = ap.parse_args()

    _log(f"Opening live support channel for '{args.si_name}' on {SYSTEM}")
    ip = ensure_tailscale()
    perms = permission_report()
    act = start_actuator()
    stream = start_screen_stream(args.port)

    print("\n" + "=" * 60)
    print(f"  LIVE SUPPORT CHANNEL OPEN — {args.si_name} @ {SYSTEM}")
    print(f"  Screen (Leon's eyes):  http://{ip or '<tailscale-ip>'}:{args.port}/")
    print(f"  Hands: actuator {'UP' if act else 'DOWN'}")
    if perms.get("notes"):
        print("  BLOCKED:")
        for n in perms["notes"]:
            print(f"    - {n}")
    print(f"  Fix journal: {JOURNAL}")
    print("  Ctrl-C to tear down. Nothing is exposed publicly.")
    print("=" * 60 + "\n")

    try:
        while True:
            time.sleep(5)
    except KeyboardInterrupt:
        _log("Tearing down live channel…")
        for p in (act, stream):
            if p:
                p.terminate()
        _log("Done. Channel closed.")


if __name__ == "__main__":
    main()
