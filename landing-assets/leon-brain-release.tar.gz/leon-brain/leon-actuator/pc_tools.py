"""pc_tools — first-class handlers for Leon's registered pc.* tool namespace.

The brain already declares ~38 pc.* tools (display, power, audio, window,
workspace, mouse, keyboard, app) but NONE had PC-side handlers, so Leon had to
improvise raw shell every time (e.g. brightness via xrandr gamma). This module
implements them for real, so they're fast, reliable, first-class actions.

All run as Dean's desktop user over the authenticated localhost tunnel, and
mutating actions are audit-logged (shared log with system_tools).
"""

from __future__ import annotations

import json
import os
import platform as _platform
import shutil
import subprocess
import sys
import time
from typing import Any, Dict, List

_AUDIT_LOG = os.path.expanduser("~/.local/share/leon/pc-control.log")


# ── Cross-platform backend ────────────────────────────────────────────────
# Same shape as actuator.py's _pc()/_pc_call(): every Linux branch below is
# the original hand-written xdotool/wmctrl/xrandr/pactl code, untouched.
# Non-Linux dispatches into platform_compat, or returns a structured
# "unsupported" result for the handful of genuinely X11-only actions.
_pc_backend = None
_pc_error = None


def _pc():
    """Lazily resolve the platform backend. Returns None if unavailable."""
    global _pc_backend, _pc_error
    if _pc_backend is None and _pc_error is None:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import platform_compat  # type: ignore
            _pc_backend = platform_compat._detect()
        except Exception as e:
            _pc_error = f"platform_compat unavailable: {type(e).__name__}: {e}"
    return _pc_backend


def _is_linux() -> bool:
    """Read live so tests can monkeypatch platform.system()."""
    return _platform.system() == "Linux"


def _pc_call(method: str, *a, **kw) -> Dict[str, Any]:
    """Run a platform_compat method, wrapped in this module's result shape."""
    be = _pc()
    if be is None:
        return _err(_pc_error or "no platform backend")
    fn = getattr(be, method, None)
    if fn is None:
        return _unsupported(method)
    try:
        return _ok(result=fn(*a, **kw))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")


def _unsupported(feature: str, detail: str = "") -> Dict[str, Any]:
    """Category C: no cross-platform equivalent exists. Say so cleanly instead
    of shelling out to a binary that isn't installed and raising."""
    sysname = _platform.system()
    msg = f"{feature} is not supported on {sysname} — Linux/X11 only"
    if detail:
        msg += f" ({detail})"
    return {"ok": False, "error": msg, "unsupported_on": sysname,
            "supported_on": ["Linux"], "feature": feature}


def _audit(tool: str, detail: str) -> None:
    try:
        os.makedirs(os.path.dirname(_AUDIT_LOG), exist_ok=True)
        with open(_AUDIT_LOG, "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{tool}\t{detail}\n")
    except Exception:
        pass


def _env() -> Dict[str, str]:
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    env.setdefault("DISPLAY", ":1")  # PC X display is :1 (see leon-x-env.sh)
    return env


def _sh(cmd, timeout: float = 8.0) -> subprocess.CompletedProcess:
    """Run a list-form command. Never raises; returns the CompletedProcess.

    The docstring used to lie: a missing binary raised FileNotFoundError
    straight out of subprocess.run, which is exactly what happened to every
    xdotool/wmctrl call the moment this module ran anywhere but Dean's X11
    box. Now a missing binary or a timeout comes back as a non-zero result
    with the reason on stderr, so callers see an error string, not a traceback.
    """
    try:
        return subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout, env=_env())
    except FileNotFoundError:
        return subprocess.CompletedProcess(
            cmd, 127, "", f"{cmd[0]}: command not found on {_platform.system()}")
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(
            cmd, 124, "", f"{cmd[0]}: timed out after {timeout}s")
    except OSError as e:
        return subprocess.CompletedProcess(cmd, 126, "", f"{cmd[0]}: {e}")


def _ok(**kw) -> Dict[str, Any]:
    d = {"ok": True}; d.update(kw); return d


def _err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


# ── Monitor alias resolution ───────────────────────────────────────────────
def _outputs() -> List[str]:
    if not _is_linux():
        be = _pc()
        if be is None:
            return []
        try:
            return [str(m.get("name") or f"display-{i}")
                    for i, m in enumerate(be.list_monitors())]
        except Exception:
            return []
    r = _sh(["xrandr", "--listmonitors"])
    outs = []
    for line in r.stdout.splitlines()[1:]:
        parts = line.split()
        if parts:
            outs.append(parts[-1])
    return outs


def _resolve_output(name: str) -> str:
    """Map 'left'/'middle'/'right' (by x-offset order) or a raw output name."""
    if not name:
        return ""
    outs = _outputs()
    alias = name.strip().lower()
    if not _is_linux():
        # platform_compat already hands back monitors in left-to-right order.
        if alias in ("left", "middle", "center", "right") and outs:
            idx = {"left": 0, "middle": 1, "center": 1, "right": len(outs) - 1}
            return outs[min(idx[alias], len(outs) - 1)]
        for o in outs:
            if o.lower() == alias:
                return o
        return name
    if alias in ("left", "middle", "center", "right") and outs:
        # order outputs by x offset
        geo = []
        r = _sh(["xrandr", "--listmonitors"])
        for line in r.stdout.splitlines()[1:]:
            p = line.split()
            if not p:
                continue
            out = p[-1]
            # geometry field like 1920/521x1080/293+0+0 -> parse +X+Y
            g = p[2] if len(p) > 2 else ""
            xoff = 0
            if "+" in g:
                try:
                    xoff = int(g.split("+")[1])
                except Exception:
                    xoff = 0
            geo.append((xoff, out))
        geo.sort()
        ordered = [o for _, o in geo]
        idx = {"left": 0, "middle": 1, "center": 1, "right": len(ordered) - 1}
        return ordered[idx[alias]] if ordered else name
    # exact/case-insensitive match against real outputs
    for o in outs:
        if o.lower() == alias:
            return o
    return name  # pass through (let xrandr error if wrong)


# ── DISPLAY ────────────────────────────────────────────────────────────────
def display_list(args):
    if not _is_linux():
        r = _pc_call("list_monitors")
        return _ok(monitors=r["result"]) if r.get("ok") else r
    r = _sh(["xrandr", "--listmonitors"])
    return _ok(monitors=r.stdout.strip())


def display_brightness_set(args):
    """Per-screen software brightness (0.0-1.0) via xrandr --brightness.
    Independent per output — NOT the all-screens gamma sweep. Args:
    {output: 'left'|'middle'|'right'|'HDMI-1', level: 0.0-1.0}."""
    if not _is_linux():
        return _unsupported(
            "pc.display_brightness_set",
            "xrandr --brightness has no macOS/Windows equivalent; macOS needs "
            "the `brightness` CLI or DDC, Windows needs WMI/monitorcontrol")
    out = _resolve_output(args.get("output") or args.get("monitor") or "")
    level = args.get("level")
    if not out or level is None:
        return _err("need output (left/middle/right or name) and level 0.0-1.0")
    level = max(0.1, min(1.0, float(level)))
    r = _sh(["xrandr", "--output", out, "--brightness", str(level)])
    if r.returncode != 0:
        return _err(f"xrandr: {r.stderr.strip()[:200]}")
    _audit("pc.display_brightness_set", f"{out}={level}")
    return _ok(output=out, level=level)


def display_brightness_all(args):
    if not _is_linux():
        return _unsupported(
            "pc.display_brightness_all",
            "xrandr --brightness has no macOS/Windows equivalent")
    level = args.get("level")
    if level is None:
        return _err("need level 0.0-1.0")
    level = max(0.1, min(1.0, float(level)))
    done = []
    for out in _outputs():
        _sh(["xrandr", "--output", out, "--brightness", str(level)])
        done.append(out)
    _audit("pc.display_brightness_all", f"{level} -> {done}")
    return _ok(level=level, outputs=done)


def display_rotate(args):
    if not _is_linux():
        return _unsupported(
            "pc.display_rotate",
            "display rotation is an xrandr feature; macOS/Windows expose it "
            "only through private APIs or the Settings UI")
    out = _resolve_output(args.get("output") or args.get("monitor") or "")
    rot = (args.get("rotation") or args.get("rotate") or "normal").lower()
    if rot not in ("normal", "left", "right", "inverted"):
        return _err("rotation must be normal|left|right|inverted")
    if not out:
        return _err("need output")
    r = _sh(["xrandr", "--output", out, "--rotate", rot])
    if r.returncode != 0:
        return _err(f"xrandr: {r.stderr.strip()[:200]}")
    _audit("pc.display_rotate", f"{out}={rot}")
    return _ok(output=out, rotation=rot)


# ── POWER ──────────────────────────────────────────────────────────────────
def system_lock_screen(args):
    if not _is_linux():
        r = _pc_call("lock_screen")
        if r.get("ok") and r.get("result"):
            _audit("pc.system_lock_screen", "locked")
            return _ok(via=_platform.system())
        return r if not r.get("ok") else _err("no screen-lock command worked")
    for cmd in (["loginctl", "lock-session"], ["xdg-screensaver", "lock"],
                ["gnome-screensaver-command", "-l"]):
        if shutil.which(cmd[0]):
            r = _sh(cmd)
            if r.returncode == 0:
                _audit("pc.system_lock_screen", "locked")
                return _ok(via=cmd[0])
    return _err("no screen-lock command worked")


def system_suspend(args):
    _audit("pc.system_suspend", "suspend")
    if not _is_linux():
        r = _pc_call("power_suspend")
        return _ok(via=_platform.system()) if r.get("ok") and r.get("result") else \
            (r if not r.get("ok") else _err("suspend command failed"))
    r = _sh(["systemctl", "suspend"], timeout=6)
    return _ok(via="systemctl suspend") if r.returncode == 0 else _err(r.stderr.strip()[:200])


def system_reboot(args):
    _audit("pc.system_reboot", "reboot")
    if not _is_linux():
        r = _pc_call("power_reboot")
        return _ok(via=_platform.system()) if r.get("ok") and r.get("result") else \
            (r if not r.get("ok") else _err("reboot command failed"))
    r = _sh(["sudo", "-n", "systemctl", "reboot"], timeout=6)
    return _ok(via="reboot") if r.returncode == 0 else _err(r.stderr.strip()[:200])


def system_shutdown(args):
    _audit("pc.system_shutdown", "poweroff")
    if not _is_linux():
        r = _pc_call("power_shutdown")
        return _ok(via=_platform.system()) if r.get("ok") and r.get("result") else \
            (r if not r.get("ok") else _err("shutdown command failed"))
    r = _sh(["sudo", "-n", "systemctl", "poweroff"], timeout=6)
    return _ok(via="poweroff") if r.returncode == 0 else _err(r.stderr.strip()[:200])


def power_status(args):
    if not _is_linux():
        if _platform.system() == "Darwin":
            up = _sh(["uptime"]).stdout.strip()
            batt = _sh(["pmset", "-g", "batt"]).stdout.strip()
        else:
            up = _sh(["powershell", "-NoProfile", "-Command",
                      "(Get-Date) - (gcim Win32_OperatingSystem).LastBootUpTime"]).stdout.strip()
            batt = _sh(["powershell", "-NoProfile", "-Command",
                        "(Get-CimInstance Win32_Battery).EstimatedChargeRemaining"]).stdout.strip()
        return _ok(uptime=up, battery=batt or "no battery (on AC)")
    up = _sh(["uptime", "-p"]).stdout.strip()
    # desktop: report AC + uptime; laptop: include battery if upower present
    batt = ""
    if shutil.which("upower"):
        d = _sh(["bash", "-lc",
                 "upower -i $(upower -e | grep -m1 BAT) 2>/dev/null | grep -E 'state|percentage'"])
        batt = d.stdout.strip()
    return _ok(uptime=up, battery=batt or "no battery (desktop, on AC)")


# ── AUDIO (per-application streams) ────────────────────────────────────────
_AUDIO_C = ("per-application audio stream control is a PulseAudio/PipeWire "
            "feature; macOS has no CLI equivalent and Windows needs pycaw's "
            "session API, which is not wired up here")


def _sink_inputs():
    """Return [{id, app}] for active audio streams."""
    if not _is_linux():
        return []
    r = _sh(["pactl", "-f", "json", "list", "sink-inputs"])
    out = []
    try:
        for si in json.loads(r.stdout or "[]"):
            props = si.get("properties", {})
            app = (props.get("application.name")
                   or props.get("media.name") or "unknown")
            out.append({"id": si.get("index"), "app": app})
    except Exception:
        pass
    return out


def audio_list_streams(args):
    if not _is_linux():
        return _unsupported("pc.audio_list_streams", _AUDIO_C)
    return _ok(streams=_sink_inputs())


def _match_stream(app):
    app = (app or "").lower()
    for s in _sink_inputs():
        if app in str(s["app"]).lower():
            return s["id"]
    return None


def audio_set_app_volume(args):
    if not _is_linux():
        return _unsupported("pc.audio_set_app_volume", _AUDIO_C)
    app = args.get("app") or args.get("name")
    level = args.get("level")
    if app is None or level is None:
        return _err("need app (name substring) and level 0-100")
    sid = _match_stream(app)
    if sid is None:
        return _err(f"no audio stream matching '{app}'. Active: {_sink_inputs()}")
    _sh(["pactl", "set-sink-input-volume", str(sid), f"{int(max(0,min(150,level)))}%"])
    _audit("pc.audio_set_app_volume", f"{app}={level}%")
    return _ok(app=app, id=sid, level=level)


def audio_mute_app(args):
    if not _is_linux():
        return _unsupported("pc.audio_mute_app", _AUDIO_C)
    app = args.get("app") or args.get("name")
    if app is None:
        return _err("need app")
    sid = _match_stream(app)
    if sid is None:
        return _err(f"no audio stream matching '{app}'")
    state = "1" if args.get("mute", True) else "0"
    _sh(["pactl", "set-sink-input-mute", str(sid), state])
    _audit("pc.audio_mute_app", f"{app}={state}")
    return _ok(app=app, id=sid, mute=state)


# ── WINDOW / WORKSPACE (wmctrl + xdotool) ──────────────────────────────────
_ACTIVE_WID_C = ("this action needs an X11 window id from `xdotool "
                 "getactivewindow`; macOS/Windows expose no equivalent handle "
                 "through platform_compat")


def _focus_verified(title: str, tries: int = 3, settle: float = 0.15) -> bool:
    """Did focus ACTUALLY move? pygetwindow's activate() and AppleScript's
    `set frontmost` both return success while doing nothing when another app
    holds the foreground lock (Windows SetForegroundWindow restrictions,
    macOS TCC). Never trust the return code — read the front window back.

    Also serves as the settling delay the xdotool path got for free: xdotool
    round-trips through the X server, library calls return immediately, so
    slower machines raced the window manager.
    """
    be = _pc()
    if be is None:
        return False
    want = (title or "").lower()
    for attempt in range(tries):
        time.sleep(settle)
        try:
            if _platform.system() == "Windows":
                import pygetwindow as gw  # type: ignore
                front = gw.getActiveWindow()
                if front is not None and want in (front.title or "").lower():
                    return True
            else:
                import subprocess as _sp
                r = _sp.run(["osascript", "-e",
                             'tell application "System Events" to get name of '
                             'first process whose frontmost is true'],
                            capture_output=True, text=True, timeout=5)
                if want in (r.stdout or "").strip().lower():
                    return True
        except Exception:
            return False
        if attempt < tries - 1:
            try:
                be.window_focus(title)   # retry the activate, then re-check
            except Exception:
                return False
    return False


def _active_wid():
    if not _is_linux():
        return ""
    r = _sh(["xdotool", "getactivewindow"])
    return r.stdout.strip()


def window_minimize_all(args):
    if not _is_linux():
        r = _pc_call("show_desktop", True)
        if r.get("ok"):
            _audit("pc.window_minimize_all", "show-desktop")
            return _ok()
        return r
    _sh(["wmctrl", "-k", "on"]); _audit("pc.window_minimize_all", "show-desktop")
    return _ok()


def window_restore_all(args):
    if not _is_linux():
        r = _pc_call("show_desktop", False)
        return _ok() if r.get("ok") else r
    _sh(["wmctrl", "-k", "off"]); return _ok()


def window_cycle(args):
    if not _is_linux():
        # macOS cycles apps with cmd+Tab, not alt+Tab.
        combo = "cmd+tab" if _platform.system() == "Darwin" else "alt+tab"
        r = _pc_call("keyboard_hotkey", combo)
        return _ok(via=combo) if r.get("ok") else r
    _sh(["xdotool", "key", "alt+Tab"]); return _ok()


def window_focus_by_class(args):
    cls = args.get("wm_class") or args.get("class") or args.get("name")
    if not cls:
        return _err("need class/name")
    if not _is_linux():
        # No WM_CLASS off X11 — match on app/window title instead.
        r = _pc_call("window_focus", cls)
        if not r.get("ok"):
            return r
        if not _focus_verified(cls):
            return _err(f"focus did not take for '{cls}' — the activate call "
                        "reported success but the front window did not change "
                        "(another app is holding the foreground lock)")
        return _ok(focused=cls, matched_on="title", verified=True)
    r = _sh(["wmctrl", "-x", "-a", cls])
    return _ok(focused=cls) if r.returncode == 0 else _err("no window with that class")


def window_close_active(args):
    if not _is_linux():
        r = _pc_call("window_close_active")
        if r.get("ok") and r.get("result"):
            _audit("pc.window_close_active", "front window")
            return _ok(closed="front window")
        return r if not r.get("ok") else _err("no active window")
    wid = _active_wid()
    if not wid:
        return _err("no active window")
    _sh(["xdotool", "windowclose", wid]); _audit("pc.window_close_active", wid)
    return _ok(closed=wid)


def window_force_kill(args):
    if not _is_linux():
        return _unsupported(
            "pc.window_force_kill",
            "`xdotool windowkill` destroys an X11 client connection; the "
            "equivalent off X11 would be killing the owning process, which is "
            "a different and more destructive action, so it is not aliased")
    wid = _active_wid()
    if not wid:
        return _err("no active window")
    _sh(["xdotool", "windowkill", wid]); _audit("pc.window_force_kill", wid)
    return _ok(killed=wid)


def window_sticky_toggle(args):
    if not _is_linux():
        return _unsupported(
            "pc.window_sticky_toggle",
            "'sticky' (visible on every workspace) is an EWMH window hint "
            "with no macOS Spaces / Windows virtual-desktop equivalent")
    _sh(["wmctrl", "-r", ":ACTIVE:", "-b", "toggle,sticky"]); return _ok()


def window_snap_quarter(args):
    """Snap active window to a screen quarter: {quarter: 'tl'|'tr'|'bl'|'br'}."""
    q = (args.get("quarter") or "").lower()
    if not _is_linux():
        return _unsupported(
            "pc.window_snap_quarter",
            "needs the active window's id + display geometry together; "
            "use window.snap / window.position on the titled window instead")
    geo = _sh(["xdotool", "getactivewindow", "getdisplaygeometry"]).stdout.split()
    if len(geo) != 2:
        return _err("could not read display geometry")
    W, H = int(geo[0]), int(geo[1])
    hw, hh = W // 2, H // 2
    pos = {"tl": (0, 0), "tr": (hw, 0), "bl": (0, hh), "br": (hw, hh)}
    if q not in pos:
        return _err("quarter must be tl|tr|bl|br")
    x, y = pos[q]
    wid = _active_wid()
    _sh(["wmctrl", "-r", ":ACTIVE:", "-b", "remove,maximized_vert,maximized_horz"])
    _sh(["xdotool", "windowsize", wid, str(hw), str(hh)])
    _sh(["xdotool", "windowmove", wid, str(x), str(y)])
    return _ok(quarter=q, size=[hw, hh], pos=[x, y])


def window_opacity(args):
    if not _is_linux():
        return _unsupported(
            "pc.window_opacity",
            "_NET_WM_WINDOW_OPACITY is an X11 property honoured by a "
            "compositor; no macOS/Windows equivalent")
    wid = _active_wid()
    op = args.get("opacity")
    if op is None or not wid:
        return _err("need opacity 0.0-1.0 and an active window")
    val = int(max(0.15, min(1.0, float(op))) * 0xFFFFFFFF)
    r = _sh(["xprop", "-id", wid, "-f", "_NET_WM_WINDOW_OPACITY", "32c",
             "-set", "_NET_WM_WINDOW_OPACITY", str(val)])
    if r.returncode != 0:
        return _err("opacity needs a compositor (picom/compton) running")
    return _ok(opacity=op)


def window_move_to_next_monitor(args):
    if not _is_linux():
        return _unsupported(
            "pc.window_move_to_next_monitor",
            "the Linux path fires a WM-specific super+shift+Right binding "
            "that has no portable counterpart")
    outs = _outputs()
    _sh(["xdotool", "key", "super+shift+Right"])  # common WM binding; best-effort
    return _ok(note="sent move-to-next-monitor (WM-dependent)", monitors=outs)


def workspace_list_windows(args):
    if not _is_linux():
        r = _pc_call("window_list")
        return _ok(windows=r["result"]) if r.get("ok") else r
    r = _sh(["wmctrl", "-l"]); return _ok(windows=r.stdout.strip())


def workspace_count(args):
    if not _is_linux():
        return _unsupported(
            "pc.workspace_count",
            "no portable read of macOS Spaces / Windows virtual desktops")
    r = _sh(["wmctrl", "-d"]); return _ok(desktops=len(r.stdout.strip().splitlines()))


def workspace_send_window(args):
    if not _is_linux():
        return _unsupported(
            "pc.workspace_send_window",
            "moving a window between macOS Spaces / Windows virtual desktops "
            "has no scriptable API")
    n = args.get("workspace")
    if n is None:
        return _err("need workspace index")
    _sh(["wmctrl", "-r", ":ACTIVE:", "-t", str(int(n))])
    return _ok(sent_to=n)


# ── MOUSE / KEYBOARD ───────────────────────────────────────────────────────
def mouse_position(args):
    if not _is_linux():
        r = _pc_call("mouse_get_pos")
        if not r.get("ok"):
            return r
        x, y = r["result"]
        return _ok(x=int(x), y=int(y))
    r = _sh(["xdotool", "getmouselocation", "--shell"])
    d = {}
    for line in r.stdout.splitlines():
        if "=" in line:
            k, v = line.split("=", 1); d[k.lower()] = v
    return _ok(x=int(d.get("x", 0)), y=int(d.get("y", 0)))


def mouse_center_active(args):
    if not _is_linux():
        return _unsupported("pc.mouse_center_active", _ACTIVE_WID_C)
    wid = _active_wid()
    g = _sh(["xdotool", "getwindowgeometry", "--shell", wid]).stdout
    d = {}
    for line in g.splitlines():
        if "=" in line:
            k, v = line.split("=", 1); d[k.lower()] = v
    try:
        cx = int(d["x"]) + int(d["width"]) // 2
        cy = int(d["y"]) + int(d["height"]) // 2
        _sh(["xdotool", "mousemove", str(cx), str(cy)])
        return _ok(x=cx, y=cy)
    except Exception:
        return _err("could not read active window geometry")


def mouse_scroll_precise(args):
    amount = int(args.get("amount", 3))
    if not _is_linux():
        pos = _pc_call("mouse_get_pos")
        x, y = pos["result"] if pos.get("ok") else (0, 0)
        # Linux convention here: positive amount scrolls UP (button 4).
        r = _pc_call("mouse_scroll", int(x), int(y), abs(amount),
                     "up" if amount > 0 else "down")
        return _ok(scrolled=amount) if r.get("ok") else r
    button = "4" if amount > 0 else "5"
    for _ in range(abs(amount)):
        _sh(["xdotool", "click", button])
    return _ok(scrolled=amount)


def mouse_smooth_drag(args):
    x1, y1 = args.get("x1"), args.get("y1")
    x2, y2 = args.get("x2"), args.get("y2")
    if None in (x1, y1, x2, y2):
        return _err("need x1,y1,x2,y2")
    if not _is_linux():
        r = _pc_call("mouse_drag", int(x1), int(y1), int(x2), int(y2), 1)
        return _ok(dragged=[[x1, y1], [x2, y2]]) if r.get("ok") else r
    _sh(["xdotool", "mousemove", str(x1), str(y1)])
    _sh(["xdotool", "mousedown", "1"])
    steps = 20
    for i in range(1, steps + 1):
        ix = int(x1 + (x2 - x1) * i / steps)
        iy = int(y1 + (y2 - y1) * i / steps)
        _sh(["xdotool", "mousemove", str(ix), str(iy)])
    _sh(["xdotool", "mouseup", "1"])
    return _ok(dragged=[[x1, y1], [x2, y2]])


def keyboard_hold_combo(args):
    combo = args.get("combo") or args.get("keys")
    if not combo:
        return _err("need combo e.g. 'ctrl+alt+t'")
    if not _is_linux():
        r = _pc_call("keyboard_hotkey", combo)
        if not r.get("ok"):
            return r
        _audit("pc.keyboard_hold_combo", combo)
        return _ok(combo=combo)
    _sh(["xdotool", "key", combo]); _audit("pc.keyboard_hold_combo", combo)
    return _ok(combo=combo)


def keyboard_type_human(args):
    text = args.get("text", "")
    if not text:
        return _err("need text")
    if not _is_linux():
        r = _pc_call("keyboard_type", text, int(args.get("delay_ms", 60)))
        return _ok(typed_len=len(text)) if r.get("ok") else r
    _sh(["xdotool", "type", "--delay", str(int(args.get("delay_ms", 60))), text], timeout=30)
    return _ok(typed_len=len(text))


# ── APP ────────────────────────────────────────────────────────────────────
def app_count_running(args):
    if not _is_linux():
        r = _pc_call("window_list")
        return _ok(window_count=len(r["result"])) if r.get("ok") else r
    r = _sh(["wmctrl", "-l"])
    return _ok(window_count=len(r.stdout.strip().splitlines()))


def app_quit_by_class(args):
    cls = args.get("wm_class") or args.get("class") or args.get("name")
    if not cls:
        return _err("need class/name")
    if not _is_linux():
        lst = _pc_call("window_list")
        if not lst.get("ok"):
            return lst
        closed = 0
        for w in lst["result"]:
            hay = f"{w.get('app', '')} {w.get('title', '')}".lower()
            if cls.lower() in hay:
                if _pc_call("window_close", w.get("title") or w.get("app")).get("ok"):
                    closed += 1
        _audit("pc.app_quit_by_class", f"{cls} x{closed}")
        return _ok(app=cls, closed=closed, matched_on="title")
    r = _sh(["wmctrl", "-x", "-l"])
    closed = 0
    for line in r.stdout.splitlines():
        if cls.lower() in line.lower():
            wid = line.split()[0]
            _sh(["wmctrl", "-i", "-c", wid]); closed += 1
    _audit("pc.app_quit_by_class", f"{cls} x{closed}")
    return _ok(app=cls, closed=closed)


# ── NOTIFICATIONS (new) ────────────────────────────────────────────────────
def notify(args):
    title = args.get("title", "Leon")
    body = args.get("body") or args.get("message") or ""
    if not _is_linux():
        r = _pc_call("notify", str(title), str(body))
        if not r.get("ok"):
            return r
        _audit("pc.notify", f"{title}: {body[:60]}")
        # macOS `display notification` exits 0 even when the owner has
        # notifications turned off for the host app, and Windows toasts get
        # swallowed by Focus Assist the same way. Delivery is genuinely
        # unverifiable — say so instead of claiming a success we can't see.
        return _ok(title=title, body=body, delivered="unverifiable",
                   note="notification dispatched; the OS does not report "
                        "whether it was shown (silently dropped if "
                        "notifications are disabled for the host app, or "
                        "Do Not Disturb / Focus Assist is on)")
    _sh(["notify-send", str(title), str(body)])
    _audit("pc.notify", f"{title}: {body[:60]}")
    return _ok(title=title, body=body)


# ── clipboard history (simple file-backed) ─────────────────────────────────
_CLIP_HIST = os.path.expanduser("~/.local/share/leon/clip-history.json")


def _clip_load():
    try:
        return json.load(open(_CLIP_HIST))
    except Exception:
        return []


def _clip_save(h):
    os.makedirs(os.path.dirname(_CLIP_HIST), exist_ok=True)
    json.dump(h[-50:], open(_CLIP_HIST, "w"))


def clipboard_history_add(args):
    txt = args.get("text")
    if txt is None:
        # capture current clipboard
        if not _is_linux():
            g = _pc_call("clipboard_paste")
            txt = (g.get("result") or "") if g.get("ok") else ""
        else:
            txt = _sh(["xclip", "-selection", "clipboard", "-o"]).stdout if shutil.which("xclip") else ""
    h = _clip_load(); h.append({"t": time.time(), "text": txt}); _clip_save(h)
    return _ok(count=len(h))


def clipboard_history_list(args):
    h = _clip_load()
    return _ok(history=[{"i": i, "text": e["text"][:120]} for i, e in enumerate(h)])


def clipboard_history_clear(args):
    _clip_save([]); return _ok(cleared=True)


def clipboard_history_restore(args):
    i = args.get("index")
    h = _clip_load()
    if i is None or not (0 <= int(i) < len(h)):
        return _err("need valid index (see clipboard_history_list)")
    txt = h[int(i)]["text"]
    if not _is_linux():
        r = _pc_call("clipboard_copy", txt)
        return _ok(restored_index=i) if r.get("ok") else r
    if shutil.which("xclip"):
        p = subprocess.Popen(["xclip", "-selection", "clipboard"],
                             stdin=subprocess.PIPE, env=_env())
        p.communicate(txt.encode())
    return _ok(restored_index=i)


def screenshot_region_picker(args):
    """Interactive region select needs a user at the screen; fall back to a
    full-screen shot saved to ~/Desktop/leon-out."""
    outdir = os.path.expanduser("~/Desktop/leon-out")
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, f"shot-{int(time.time())}.png")
    if not _is_linux():
        # mss is already an actuator dependency and is cross-platform, so the
        # full-screen fallback works everywhere; only the interactive picker
        # was ever gnome-specific.
        try:
            import mss  # type: ignore
            import mss.tools  # type: ignore
            with mss.MSS() as sct:
                img = sct.grab(sct.monitors[0])
                mss.tools.to_png(img.rgb, img.size, output=path)
            return _ok(path=path, note="full-screen (the interactive region "
                                       "picker is Linux-only)")
        except Exception as e:
            return _err(f"screenshot failed: {type(e).__name__}: {e}")
    r = _sh(["gnome-screenshot", "-f", path], timeout=10)
    return _ok(path=path) if r.returncode == 0 else _err("screenshot failed")


def preflight(args):
    """PROVE Leon can actually drive this machine — call at startup.

    Do not trust return codes on macOS: with Accessibility or Screen
    Recording denied, input and capture calls succeed and silently do
    nothing. This moves the cursor and reads it back, grabs a frame and
    checks it isn't black, and reports the exact System Settings pane to
    open for anything that fails."""
    be = _pc()
    if be is None:
        return _err(_pc_error or "no platform backend")
    try:
        import platform_compat  # type: ignore
        r = platform_compat.preflight(
            move_probe=bool(args.get("move_probe", True)))
    except Exception as e:
        return _err(f"{type(e).__name__}: {e}")
    if not r.get("ok"):
        return {"ok": False,
                "error": "; ".join(f"{b['capability']}: {b['why']}"
                                   for b in r["blocking"]),
                "blocking": r["blocking"], "checks": r["checks"],
                "system": r["system"]}
    return _ok(**r)


EXTRA_TOOLS: Dict[str, Any] = {
    "pc.preflight": preflight,
    "pc.display_list": display_list,
    "pc.display_brightness_set": display_brightness_set,
    "pc.display_brightness_all": display_brightness_all,
    "pc.display_rotate": display_rotate,
    "pc.system_lock_screen": system_lock_screen,
    "pc.system_suspend": system_suspend,
    "pc.system_reboot": system_reboot,
    "pc.system_shutdown": system_shutdown,
    "pc.power_status": power_status,
    "pc.audio_list_streams": audio_list_streams,
    "pc.audio_set_app_volume": audio_set_app_volume,
    "pc.audio_mute_app": audio_mute_app,
    "pc.window_minimize_all": window_minimize_all,
    "pc.window_restore_all": window_restore_all,
    "pc.window_cycle": window_cycle,
    "pc.window_focus_by_class": window_focus_by_class,
    "pc.window_close_active": window_close_active,
    "pc.window_force_kill": window_force_kill,
    "pc.window_sticky_toggle": window_sticky_toggle,
    "pc.window_snap_quarter": window_snap_quarter,
    "pc.window_opacity": window_opacity,
    "pc.window_move_to_next_monitor": window_move_to_next_monitor,
    "pc.workspace_list_windows": workspace_list_windows,
    "pc.workspace_count": workspace_count,
    "pc.workspace_send_window": workspace_send_window,
    "pc.mouse_position": mouse_position,
    "pc.mouse_center_active": mouse_center_active,
    "pc.mouse_scroll_precise": mouse_scroll_precise,
    "pc.mouse_smooth_drag": mouse_smooth_drag,
    "pc.keyboard_hold_combo": keyboard_hold_combo,
    "pc.keyboard_type_human": keyboard_type_human,
    "pc.app_count_running": app_count_running,
    "pc.app_quit_by_class": app_quit_by_class,
    "pc.notify": notify,
    "pc.clipboard_history_add": clipboard_history_add,
    "pc.clipboard_history_list": clipboard_history_list,
    "pc.clipboard_history_clear": clipboard_history_clear,
    "pc.clipboard_history_restore": clipboard_history_restore,
    "pc.screenshot_region_picker": screenshot_region_picker,
}
