"""
Leon Actuator — separate process that exposes Leon's "hands" over a Unix
socket. This is the security boundary: Claude does NOT call pyautogui /
subprocess directly. Claude emits a tool_use event → brain server validates
+ proxies to this process via JSON-RPC → this process does the deed.

Why a separate process: process isolation. The actuator can be killed
without taking the brain down, runs with a tighter capability set, and
only listens on a uid-restricted Unix socket so random browser tabs can't
poke at it.

Tool surface (intentionally tiny — only add to it deliberately):
  screen.capture()                         → base64 PNG of full screen
  window.list()                            → list of active windows
  window.focus(title_substring)            → focus first matching window
  app.launch(name)                         → whitelisted app launcher
  app.close(title_substring)               → wmctrl close-window (HIGH risk)
  mouse.click(x, y, button="left")         → single click at coords
  mouse.move(x, y)                         → move cursor
  mouse.scroll(clicks, direction, x?, y?)  → scroll wheel
  mouse.drag(x1, y1, x2, y2, button="left") → drag (HIGH risk)
  keyboard.type(text)                      → type a string
  keyboard.hotkey(combo)                   → e.g. "ctrl+l", "alt+tab"
  clipboard.copy(text)                     → write to system clipboard
  clipboard.paste()                        → read system clipboard
  notify(title, body)                      → desktop notification (notify-send)

Each tool returns:
  {ok: bool, result: ...}  on success
  {ok: false, error: str}  on failure

Every call is logged to brain_state/actuator-audit.jsonl with timestamp,
tool, args, outcome — replayable for debugging.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
import zipfile
from typing import Any, Dict, List, Optional


# ── Config ────────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# .env MUST BE LOADED BEFORE leon_transport IS IMPORTED (2026-08-12).
#
# leon_transport computes SOCKET_PATH and RENDEZVOUS_PATH at import time from
# LEON_ACTUATOR_DIR. This block used to sit ~30 lines BELOW the import, so a
# LEON_ACTUATOR_DIR written into the install's .env was read by the brain
# (run.py loads .env before it touches anything) and ignored by the body,
# which had already resolved its rendezvous path from the ambient
# environment. Two halves of the same SI binding and dialling different
# paths: the actuator listens perfectly, the brain finds nothing listening,
# falls back to the 127.0.0.1:9100 relay that exists on no customer machine,
# and every hand tool fails while the body sits there healthy. The SI has a
# body and cannot reach it — the same failure mode as the POSIX-only probe
# fixed in brain/actuator_client.py, arriving by a different road.
#
# load_dotenv does not override values already in the environment, so a
# parent that exports LEON_ACTUATOR_DIR (run.py's spawn does) still wins.
# Also loads ANTHROPIC_API_KEY for vision-grounded tools (click_element calls
# Sonnet for bbox grounding). Best-effort: without python-dotenv installed
# click_element just returns ok:false with a clear error message.
try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv(os.path.join(PROJECT_ROOT, ".env"))
except Exception:
    pass

import leon_transport as _transport
SOCKET_PATH = _transport.SOCKET_PATH

PLATFORM = platform.system()  # "Windows", "Linux", "Darwin" (macOS)
IS_WINDOWS = PLATFORM == "Windows"
# NOTE: SOCKET_PATH is set ABOVE from leon_transport and must NOT be reassigned
# here. This line used to re-hardcode it and silently clobbered the
# cross-platform value four lines after it was computed — the fix was in the
# file, being overwritten by the very code it replaced. serve() happened to
# call _transport.bind_listener() directly so the LISTENER was fine, which is
# what made this so hard to see: the actuator really was listening, and every
# consumer of SOCKET_PATH was looking somewhere else.
# The named pipe named here was never implemented either — leon_transport uses
# token-authed loopback TCP on Windows because named pipes need pywin32, which
# the installer's bare venv does not have. (Found on TEST1, 2026-08-10.)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIT_PATH = os.path.join(PROJECT_ROOT, "brain_state", "actuator-audit.jsonl")
DISPLAY = os.environ.get("DISPLAY") or ":0"
# Only meaningful on X11. Forcing it on macOS/Windows is at best noise and at
# worst confuses child processes into thinking an X server exists.
if PLATFORM == "Linux":
    os.environ["DISPLAY"] = DISPLAY

# Load .env so ANTHROPIC_API_KEY is available to vision-grounded tools
# (click_element calls Sonnet for bbox grounding). Best-effort: fall back
# silently if python-dotenv isn't installed — click_element will just
# return ok:false with a clear error message in that case.
try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv(os.path.join(PROJECT_ROOT, ".env"))
except Exception:
    pass

# Whitelisted apps — explicit list. Add to it deliberately. Each entry maps
# a friendly name to the shell command Leon is allowed to launch.
# Leon's own Brave profile — separate from Dean's logged-in sessions.
# Uses a dedicated user-data-dir and CDP port so Leon never touches
# Dean's cookies, passwords, or active sessions.
LEON_BRAVE_PROFILE = os.environ.get(
    "LEON_BRAVE_PROFILE",
    os.path.expanduser("~/.config/BraveSoftware/Leon-Browser"))
LEON_CDP_PORT = 9223

_APP_WHITELISTS: Dict[str, Dict[str, str]] = {
    "Linux": {
        "brave":      "brave-browser",
        "browser":    "brave-browser",
        "chrome":     "brave-browser",
        "spotify":    "spotify",
        "code":       "code",
        "vscode":     "code",
        "terminal":   "gnome-terminal",
        "files":      "nautilus",
        "calculator": "gnome-calculator",
        "slack":      "slack",
    },
    # macOS: `open -a` resolves the app bundle by name.
    "Darwin": {
        "brave":      "open -a 'Brave Browser'",
        "browser":    "open -a 'Brave Browser'",
        "chrome":     "open -a 'Google Chrome'",
        "safari":     "open -a Safari",
        "spotify":    "open -a Spotify",
        "code":       "open -a 'Visual Studio Code'",
        "vscode":     "open -a 'Visual Studio Code'",
        "terminal":   "open -a Terminal",
        "files":      "open -a Finder",
        "calculator": "open -a Calculator",
        "slack":      "open -a Slack",
    },
    # Windows: `start` resolves registered app paths / shell verbs.
    "Windows": {
        "brave":      'cmd /c start "" brave',
        "browser":    'cmd /c start "" brave',
        "chrome":     'cmd /c start "" chrome',
        "edge":       'cmd /c start "" msedge',
        "spotify":    'cmd /c start "" spotify',
        "code":       'cmd /c start "" code',
        "vscode":     'cmd /c start "" code',
        "terminal":   'cmd /c start "" wt',
        "files":      "explorer",
        "calculator": "calc",
        "slack":      'cmd /c start "" slack',
    },
}

# Whitelist for whatever OS this SI actually woke up on.
APP_WHITELIST: Dict[str, str] = _APP_WHITELISTS.get(
    PLATFORM, _APP_WHITELISTS["Linux"])

# ── Lazy heavy imports — only when first needed ───────────────────────────
_pyautogui = None
_mss = None


def _ensure_pyautogui():
    global _pyautogui
    if _pyautogui is None:
        import pyautogui  # type: ignore
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0.05
        _pyautogui = pyautogui
    return _pyautogui


# ── Cross-platform backend ────────────────────────────────────────────────
# platform_compat.py carries full LinuxX11 / MacOS / Windows implementations
# of the OS-coupled primitives (windows, clipboard, notify, monitors). The
# Linux code paths below stay hand-written and untouched — they're battle
# tested on Dean's machine and I'm not risking a regression there. Everything
# NON-Linux dispatches into platform_compat instead of dying on wmctrl.
_pc_backend = None
_pc_error = None


def _pc():
    """Lazily resolve the platform backend. Returns None if unavailable."""
    global _pc_backend, _pc_error
    if _pc_backend is None and _pc_error is None:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import platform_compat  # type: ignore
            _pc_backend = platform_compat._detect()
        except Exception as e:
            _pc_error = f"platform_compat unavailable: {type(e).__name__}: {e}"
    return _pc_backend


def _pc_call(method: str, *a, **kw):
    """Run a platform_compat method, wrapped in the actuator result shape.
    Returns None when the caller should fall through to the native path."""
    be = _pc()
    if be is None:
        return {"ok": False, "error": _pc_error or "no platform backend"}
    fn = getattr(be, method, None)
    if fn is None:
        return {"ok": False, "error": f"{method} unsupported on {PLATFORM}"}
    try:
        return {"ok": True, "result": fn(*a, **kw)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _ensure_mss():
    global _mss
    if _mss is None:
        import mss  # type: ignore
        _mss = mss
    return _mss


# ── Audit log ─────────────────────────────────────────────────────────────
_audit_lock = threading.Lock()


_REDACT_KEYS = {"password", "token", "secret", "key", "auth", "cookie",
                 "credential", "api_key", "apikey", "bearer"}
_REDACT_TOOLS = {"clipboard.paste", "file_read"}


def _redact_args(tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Strip sensitive values from args before logging."""
    redacted = {}
    for k, v in args.items():
        if any(rk in k.lower() for rk in _REDACT_KEYS):
            redacted[k] = "[REDACTED]"
        elif isinstance(v, str) and len(v) > 500:
            redacted[k] = v[:100] + f"...[truncated {len(v)} chars]"
        else:
            redacted[k] = v
    # For tools that return sensitive data, redact the result reference
    if tool in _REDACT_TOOLS:
        redacted = {k: "[REDACTED]" for k in args}
    return redacted


def _audit(tool: str, args: Dict[str, Any], result: Dict[str, Any]) -> None:
    line = json.dumps({
        "ts": time.time(),
        "tool": tool,
        "args": _redact_args(tool, args),
        "ok": bool(result.get("ok", False)),
        "error": result.get("error"),
    }, default=str)
    try:
        os.makedirs(os.path.dirname(AUDIT_PATH), exist_ok=True)
        with _audit_lock:
            with open(AUDIT_PATH, "a") as f:
                f.write(line + "\n")
            # Rotate: cap at 10K lines (~2MB)
            try:
                with open(AUDIT_PATH, "r") as f:
                    lines = f.readlines()
                if len(lines) > 10000:
                    with open(AUDIT_PATH, "w") as f:
                        f.writelines(lines[-5000:])
            except Exception:
                pass
    except Exception:
        pass


# ── Tool implementations ──────────────────────────────────────────────────
def screen_capture(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Grab a screenshot of all monitors, return base64 PNG."""
    try:
        mss_mod = _ensure_mss()
        from PIL import Image  # type: ignore
        with mss_mod.MSS() as sct:
            # Monitor 0 is the "all monitors" virtual screen
            mon = sct.monitors[0]
            img = sct.grab(mon)
            pil = Image.frombytes("RGB", img.size, img.rgb)
            # Downscale a bit to keep payload reasonable
            max_w = 1920
            if pil.width > max_w:
                ratio = max_w / pil.width
                pil = pil.resize((max_w, int(pil.height * ratio)), Image.LANCZOS)
            buf = io.BytesIO()
            pil.save(buf, format="PNG", optimize=True)
            return {"ok": True, "result": {
                "image_b64": base64.b64encode(buf.getvalue()).decode("ascii"),
                "width": pil.width,
                "height": pil.height,
                "format": "png",
            }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_list(_args: Dict[str, Any]) -> Dict[str, Any]:
    """List active windows. Linux: wmctrl. Mac/Windows: platform_compat."""
    if PLATFORM != "Linux":
        return _pc_call("window_list")
    try:
        out = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
        wins = []
        for line in out.splitlines():
            parts = line.split(None, 3)
            if len(parts) >= 4:
                wins.append({"id": parts[0], "desktop": parts[1], "host": parts[2], "title": parts[3]})
        return {"ok": True, "result": wins}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_focus(args: Dict[str, Any]) -> Dict[str, Any]:
    """Focus the first window whose title contains the given substring."""
    title = args.get("title_substring") or args.get("title") or ""
    if not title:
        return {"ok": False, "error": "title_substring is required"}
    if PLATFORM != "Linux":
        r = _pc_call("window_focus", title)
        if r.get("ok") and not r.get("result"):
            return {"ok": False, "error": f"no window matching '{title}'"}
        return {"ok": True, "result": {"focused": title}} if r.get("ok") else r
    try:
        subprocess.run(["wmctrl", "-a", title], check=True, timeout=2)
        return {"ok": True, "result": {"focused": title}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _list_monitors() -> list:
    """Parse `xrandr --listmonitors` → list of {idx, name, x, y, w, h}.
    Non-Linux goes through platform_compat (Quartz / pyautogui)."""
    if PLATFORM != "Linux":
        be = _pc()
        return be.list_monitors() if be else []
    import re
    out = subprocess.check_output(["xrandr", "--listmonitors"], timeout=2).decode()
    mons = []
    for line in out.splitlines()[1:]:  # skip "Monitors: N"
        # Format: " 0: +*HDMI-0 1920/521x1080/293+0+0  HDMI-0"
        m = re.search(r'^\s*(\d+):\s*\S+\s+(\d+)/\d+x(\d+)/\d+\+(\d+)\+(\d+)\s+(\S+)', line)
        if m:
            idx, w, h, x, y, name = m.groups()
            mons.append({"idx": int(idx), "name": name,
                         "x": int(x), "y": int(y), "w": int(w), "h": int(h)})
    return mons


def window_list_monitors(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Return geometry of all connected monitors. Use this before window.move_to_monitor."""
    try:
        return {"ok": True, "result": _list_monitors()}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_move_to_monitor(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move a window to a specific monitor by index, name, or position word.

    args:
      window_id (str, optional):       exact wmctrl window ID (e.g. '0x03600251').
                                       Preferred when available — title_substring
                                       can match the wrong window (e.g. another
                                       Brave window the user is using).
      title_substring (str, optional): substring of window title to match.
                                       Used only when window_id is not supplied.
      monitor (int|str, required):     0/1/2  OR  "left"/"middle"/"right"
                                       OR  monitor name like "HDMI-1"
      maximize (bool, optional):       default True — fill the target monitor
    """
    window_id = (args.get("window_id") or "").strip()
    title = args.get("title_substring") or args.get("title") or ""
    monitor = args.get("monitor")
    maximize = args.get("maximize", True)
    if not (window_id or title) or monitor is None:
        return {"ok": False, "error": "either window_id or title_substring, plus monitor, are required"}

    try:
        mons = _list_monitors()
        if not mons:
            return {"ok": False, "error": "no monitors detected (is X running?)"}

        # Resolve monitor selector → index. Position words map by x-coordinate,
        # not by monitor index (so "right" = max-x monitor, not idx 2).
        target_mon = None
        if isinstance(monitor, int):
            target_mon = next((m for m in mons if m["idx"] == monitor), None)
        elif isinstance(monitor, str):
            word = monitor.strip().lower()
            if word in ("right", "rightmost"):
                target_mon = max(mons, key=lambda m: m["x"])
            elif word in ("left", "leftmost", "primary"):
                target_mon = min(mons, key=lambda m: m["x"])
            elif word in ("middle", "center", "centre"):
                xs = sorted(m["x"] for m in mons)
                if len(xs) >= 3:
                    mid = xs[len(xs) // 2]
                    target_mon = next(m for m in mons if m["x"] == mid)
                else:
                    return {"ok": False, "error": f"'middle' needs ≥3 monitors, have {len(mons)}"}
            else:
                target_mon = next((m for m in mons if m["name"].lower() == word), None)
                if target_mon is None:
                    try:
                        idx = int(word)
                        target_mon = next((m for m in mons if m["idx"] == idx), None)
                    except ValueError:
                        pass
        if target_mon is None:
            return {"ok": False, "error": f"could not resolve monitor='{monitor}' against {[m['name'] for m in mons]}"}

        # Prefer exact window_id when given (avoids matching the wrong
        # window if multiple share a substring — e.g. two Brave windows).
        # Otherwise fall back to title-substring matching.
        win_id = None
        if window_id:
            wlist = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
            # Normalize hex IDs (wmctrl outputs lowercase hex, but accept either case)
            wanted = window_id.lower()
            for line in wlist.splitlines():
                parts = line.split(None, 3)
                if len(parts) >= 1 and parts[0].lower() == wanted:
                    win_id = parts[0]
                    break
            if not win_id:
                return {"ok": False, "error": f"window_id '{window_id}' not found"}
        else:
            wlist = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
            for line in wlist.splitlines():
                parts = line.split(None, 3)
                if len(parts) >= 4 and title.lower() in parts[3].lower():
                    win_id = parts[0]
                    break
            if not win_id:
                return {"ok": False, "error": f"no window matching '{title}'"}

        # wmctrl -e fails on maximized windows; unmaximize first.
        subprocess.run(
            ["wmctrl", "-ir", win_id, "-b", "remove,maximized_vert,maximized_horz"],
            timeout=2, check=False,
        )
        # Move + resize to target monitor's geometry. Gravity 0 = NorthWest.
        subprocess.run(
            ["wmctrl", "-ir", win_id, "-e",
             f"0,{target_mon['x']},{target_mon['y']},{target_mon['w']},{target_mon['h']}"],
            timeout=2, check=True,
        )
        if maximize:
            subprocess.run(
                ["wmctrl", "-ir", win_id, "-b", "add,maximized_vert,maximized_horz"],
                timeout=2, check=False,
            )
        subprocess.run(["wmctrl", "-ia", win_id], timeout=2, check=False)  # raise/focus

        return {"ok": True, "result": {
            "window_id": win_id,
            "monitor": target_mon,
            "maximized": bool(maximize),
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ── UI grounding: click by description or text ───────────────────────────
# These are Phase 0 tools that close the "I can see but can't act" gap.
# Three tiers, cheapest first:
#   click_text(text)             → tesseract OCR + fuzzy match. ~0.5s, $0.
#   click_element(description)   → Sonnet vision returns bbox. ~1.5s, ~$0.003.
#   browser_dom_click(...)       → CDP into Brave. Fastest, but Brave needs the
#                                  --remote-debugging-port flag (see browser_cdp.py).
# Leon's system prompt teaches the priority. These tools coexist with the
# low-level mouse.click for cases where coords are already known.


def _ocr_screen_with_boxes():
    """Run tesseract over the current desktop and return (PIL image, box list).
    Each box: {text, conf, x, y, w, h, cx, cy}. Coords are in REAL screen pixels
    (no downscale)."""
    import pytesseract  # imported lazily; only needed for click_text
    mss_mod = _ensure_mss()
    from PIL import Image  # type: ignore
    with mss_mod.MSS() as sct:
        mon = sct.monitors[0]
        img = sct.grab(mon)
        pil = Image.frombytes("RGB", img.size, img.rgb)
    data = pytesseract.image_to_data(pil, output_type=pytesseract.Output.DICT)
    boxes = []
    n = len(data.get("text") or [])
    for i in range(n):
        text = (data["text"][i] or "").strip()
        conf_raw = data["conf"][i]
        try:
            conf = float(conf_raw)
        except (TypeError, ValueError):
            conf = -1.0
        if not text or conf < 30:  # tesseract uses -1 for non-text rows
            continue
        x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
        boxes.append({
            "text": text, "conf": conf,
            "x": int(x), "y": int(y), "w": int(w), "h": int(h),
            "cx": int(x + w / 2), "cy": int(y + h / 2),
        })
    return pil, boxes


def click_text(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click on visible text via OCR (cheapest path — no API cost).

    Args:
      text (str, required):   text to find on screen (case-insensitive, fuzzy).
      occurrence (int, opt):  0-indexed; pick Nth match if multiple. Default 0.
      button (str, opt):      'left' (default) / 'right' / 'middle'.
      min_confidence (int):   tesseract confidence threshold (0-100). Default 50.

    Strategy:
      1. OCR the screen with bounding boxes.
      2. Try exact (case-insensitive) substring match first.
      3. If 0 matches, try multi-word phrase match (join adjacent boxes on same line).
      4. If still 0, fall back to difflib fuzzy ratio ≥ 0.75.
      5. Click center of chosen box.

    Returns ok:false with error text if no match — caller can escalate to
    click_element (vision-grounded).
    """
    import difflib
    text = (args.get("text") or "").strip()
    if not text:
        return {"ok": False, "error": "text is required"}
    occurrence = int(args.get("occurrence", 0))
    button = (args.get("button") or "left").lower()
    min_conf = float(args.get("min_confidence", 50))
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}

    try:
        _pil, boxes = _ocr_screen_with_boxes()
        boxes = [b for b in boxes if b["conf"] >= min_conf]
        if not boxes:
            return {"ok": False, "error": "OCR returned no text above min_confidence"}

        needle = text.lower()

        # Strategy 1: exact substring on a single box
        exact = [b for b in boxes if needle in b["text"].lower()]
        # Strategy 2: phrase across boxes on same line (group by y-band)
        phrase = []
        if not exact and " " in needle:
            # Sort by y then x; group rows within 8px y-tolerance
            rows = []
            for b in sorted(boxes, key=lambda b: (b["y"], b["x"])):
                if rows and abs(b["y"] - rows[-1][0]["y"]) <= 8:
                    rows[-1].append(b)
                else:
                    rows.append([b])
            for row in rows:
                row_text = " ".join(b["text"] for b in row).lower()
                if needle in row_text:
                    # Find which boxes make up the match and use their union as bbox
                    matched = []
                    accum = ""
                    for b in row:
                        accum = (accum + " " + b["text"]).strip().lower()
                        matched.append(b)
                        if needle in accum:
                            # Trim leading boxes that don't contribute
                            while matched and needle not in " ".join(
                                m["text"] for m in matched).lower():
                                matched.pop(0)
                            break
                    if matched and needle in " ".join(m["text"] for m in matched).lower():
                        xs = [m["x"] for m in matched]
                        ys = [m["y"] for m in matched]
                        rights = [m["x"] + m["w"] for m in matched]
                        bots = [m["y"] + m["h"] for m in matched]
                        phrase.append({
                            "text": " ".join(m["text"] for m in matched),
                            "conf": min(m["conf"] for m in matched),
                            "x": min(xs), "y": min(ys),
                            "w": max(rights) - min(xs), "h": max(bots) - min(ys),
                            "cx": (min(xs) + max(rights)) // 2,
                            "cy": (min(ys) + max(bots)) // 2,
                        })
        # Strategy 3: fuzzy
        fuzzy = []
        if not exact and not phrase:
            for b in boxes:
                ratio = difflib.SequenceMatcher(None, needle, b["text"].lower()).ratio()
                if ratio >= 0.75:
                    fuzzy.append((ratio, b))
            fuzzy.sort(key=lambda p: -p[0])
            fuzzy = [b for _, b in fuzzy]

        candidates = exact or phrase or fuzzy
        if not candidates:
            sample = ", ".join(b["text"] for b in boxes[:10])
            return {"ok": False, "error":
                    f"no text matching '{text}' found on screen (sample: {sample}...)"}
        if occurrence >= len(candidates):
            return {"ok": False, "error":
                    f"only {len(candidates)} matches for '{text}', occurrence={occurrence} out of range"}

        chosen = candidates[occurrence]
        pg = _ensure_pyautogui()
        pg.click(chosen["cx"], chosen["cy"], button=button)
        return {"ok": True, "result": {
            "clicked": {"x": chosen["cx"], "y": chosen["cy"], "button": button},
            "matched_text": chosen["text"],
            "matched_box": {"x": chosen["x"], "y": chosen["y"],
                            "w": chosen["w"], "h": chosen["h"]},
            "strategy": "exact" if exact else ("phrase" if phrase else "fuzzy"),
            "total_matches": len(candidates),
        }}
    except ImportError as e:
        return {"ok": False, "error":
                f"OCR backend missing: {e}. Install: `pip install pytesseract` + `apt install tesseract-ocr`"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def click_element(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click on a UI element by description, using Sonnet vision to find its bbox.

    Args:
      description (str, required): natural-language description of target
                                   (e.g. "the first Tesla video thumbnail",
                                   "the red Subscribe button", "the 7 key").
      button (str, opt):           'left' (default) / 'right' / 'middle'.

    Cost: ~$0.003 per call (Sonnet vision input).
    Latency: ~1.5s end-to-end.

    Use this when click_text can't find the target (no visible text, image
    elements, ambiguous matches). For browser pages, prefer browser_dom_click
    if CDP is available — it's faster and free.
    """
    import base64, io, json as _json, re as _re
    description = (args.get("description") or "").strip()
    if not description:
        return {"ok": False, "error": "description is required"}
    button = (args.get("button") or "left").lower()
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}

    # Capture screen (full virtual screen, all monitors)
    try:
        mss_mod = _ensure_mss()
        from PIL import Image  # type: ignore
        with mss_mod.MSS() as sct:
            mon = sct.monitors[0]
            img = sct.grab(mon)
            pil = Image.frombytes("RGB", img.size, img.rgb)
            full_w, full_h = pil.width, pil.height
            # Downscale for Sonnet (cheaper input). Track scale to map coords back.
            target_w = 1920
            if pil.width > target_w:
                scale = target_w / pil.width
                pil = pil.resize((target_w, int(pil.height * scale)), Image.LANCZOS)
            else:
                scale = 1.0
            buf = io.BytesIO()
            pil.save(buf, format="PNG", optimize=True)
            img_b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception as e:
        return {"ok": False, "error": f"screen capture failed: {type(e).__name__}: {e}"}

    # Ask Sonnet to find the element. Strict JSON-only response.
    try:
        import anthropic  # type: ignore
    except ImportError:
        return {"ok": False, "error": "anthropic SDK not installed"}

    client = anthropic.Anthropic()  # uses ANTHROPIC_API_KEY from env
    prompt = (
        "You are a UI grounding model. Find the element matching this description "
        f"in the screenshot:\n\n  DESCRIPTION: {description}\n\n"
        "Respond with ONLY a single-line JSON object, no prose, no markdown:\n"
        '  {"found": true, "x1": INT, "y1": INT, "x2": INT, "y2": INT, "confidence": 0-1, '
        '"label": "short description of what you clicked"}\n'
        '  OR  {"found": false, "reason": "..."}\n\n'
        f"Image dimensions are {pil.width} x {pil.height} pixels. Coordinates must be "
        "within those bounds. If multiple candidates match, pick the most prominent / "
        "first one in reading order. If you're not sure, set confidence < 0.5."
    )

    try:
        msg = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=200,
            messages=[{
                "role": "user",
                "content": [
                    {"type": "image",
                     "source": {"type": "base64", "media_type": "image/png", "data": img_b64}},
                    {"type": "text", "text": prompt},
                ],
            }],
        )
        raw = msg.content[0].text.strip() if msg.content else ""
    except Exception as e:
        return {"ok": False, "error": f"Sonnet vision call failed: {type(e).__name__}: {e}"}

    # Extract JSON (model sometimes wraps in code fences despite the instruction)
    m = _re.search(r'\{[^{}]*\}', raw)
    if not m:
        return {"ok": False, "error": f"vision returned non-JSON: {raw[:200]}"}
    try:
        parsed = _json.loads(m.group(0))
    except Exception as e:
        return {"ok": False, "error": f"vision JSON parse failed: {e} — raw: {raw[:200]}"}

    if not parsed.get("found"):
        return {"ok": False, "error":
                f"vision didn't find '{description}': {parsed.get('reason', 'no reason given')}"}

    try:
        x1, y1, x2, y2 = parsed["x1"], parsed["y1"], parsed["x2"], parsed["y2"]
        # Map downscaled coords back to real screen coords
        cx = int(((x1 + x2) / 2) / scale)
        cy = int(((y1 + y2) / 2) / scale)
        # Sanity-clamp to full screen
        cx = max(0, min(cx, full_w - 1))
        cy = max(0, min(cy, full_h - 1))
        confidence = float(parsed.get("confidence", 0.5))

        pg = _ensure_pyautogui()
        pg.click(cx, cy, button=button)
        return {"ok": True, "result": {
            "clicked": {"x": cx, "y": cy, "button": button},
            "label": parsed.get("label", description),
            "confidence": confidence,
            "bbox_downscaled": [x1, y1, x2, y2],
            "scale": scale,
        }}
    except (KeyError, ValueError) as e:
        return {"ok": False, "error": f"vision returned malformed bbox: {e} — raw: {raw[:200]}"}


def app_launch(args: Dict[str, Any]) -> Dict[str, Any]:
    """Launch a whitelisted app."""
    name = (args.get("name") or "").strip().lower()
    if not name:
        return {"ok": False, "error": "name is required"}
    cmd = APP_WHITELIST.get(name)
    if cmd is None:
        return {"ok": False, "error": f"app '{name}' is not whitelisted. Allowed: {sorted(APP_WHITELIST.keys())}"}
    try:
        # Split into argv — Mac/Windows entries carry arguments ("open -a X").
        # Linux entries are single tokens, so this is a no-op there. Never
        # shell=True: the whitelist is the security boundary, not the shell.
        import shlex
        argv = shlex.split(cmd)
        kw = {} if IS_WINDOWS else {"start_new_session": True}
        subprocess.Popen(argv, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, **kw)
        return {"ok": True, "result": {"launched": name, "cmd": cmd}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


_leon_screen_origin = None


def _leon_screen_x() -> int:
    """X coordinate where Leon's own monitor starts.

    This used to be a hardcoded 3840 — Dean's three-monitor layout baked
    into shipped code. On a laptop or any single-screen machine that flung
    the cursor thousands of pixels off into nothing. Now it's measured:
    the rightmost monitor's x origin, 0 when there's only one screen.
    Override with LEON_SCREEN_X if an SI's owner wants a specific display.
    """
    global _leon_screen_origin
    if _leon_screen_origin is not None:
        return _leon_screen_origin
    env = os.environ.get("LEON_SCREEN_X")
    if env and env.strip().lstrip("-").isdigit():
        _leon_screen_origin = int(env.strip())
        return _leon_screen_origin
    try:
        mons = _list_monitors() or []
        xs = [int(m.get("x", 0)) for m in mons]
        # Single screen (or unknown) → share it. Never invent an offset.
        _leon_screen_origin = max(xs) if len(xs) > 1 else 0
    except Exception:
        _leon_screen_origin = 0
    return _leon_screen_origin


def mouse_click(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click at (x, y). Uses Leon's own cursor (right monitor only).
    Optional button: left|right|middle."""
    x = args.get("x")
    y = args.get("y")
    button = args.get("button", "left")
    if x is None or y is None:
        return {"ok": False, "error": "x and y are required"}
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}
    btn_map = {"left": 1, "right": 3, "middle": 2}

    # Non-Linux (Windows/macOS): pyautogui directly — leon_cursor is
    # xdotool-based and therefore Linux-only.
    if PLATFORM != "Linux":
        try:
            pg = _ensure_pyautogui()
            pg.click(int(x), int(y), button=button)
            return {"ok": True, "result": {"clicked": [int(x), int(y)], "button": button,
                                            "platform": PLATFORM}}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # Linux: use leon_cursor (xdotool-based pointer borrowing)
    try:
        from leon_cursor import leon_click, is_on_right_monitor
        ix, iy = int(x), int(y)
        if not is_on_right_monitor(ix):
            # Auto-shift to right monitor
            ix = ix + _leon_screen_x()
        leon_click(ix, iy, button=btn_map[button])
        return {"ok": True, "result": {"clicked": [ix, iy], "button": button,
                                        "cursor": "leon"}}
    except ImportError:
        # Fallback to pyautogui if leon_cursor not available
        try:
            pg = _ensure_pyautogui()
            pg.click(int(x), int(y), button=button)
            return {"ok": True, "result": {"clicked": [int(x), int(y)], "button": button}}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_move(args: Dict[str, Any]) -> Dict[str, Any]:
    """Move Leon's cursor to (x, y). Clamped to right monitor."""
    x = args.get("x")
    y = args.get("y")
    if x is None or y is None:
        return {"ok": False, "error": "x and y are required"}

    # Non-Linux (Windows/macOS): pyautogui directly — leon_cursor is
    # xdotool-based and therefore Linux-only.
    if PLATFORM != "Linux":
        try:
            pg = _ensure_pyautogui()
            pg.moveTo(int(x), int(y), duration=0.1)
            return {"ok": True, "result": {"moved": [int(x), int(y)], "platform": PLATFORM}}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    # Linux: use leon_cursor (xdotool-based pointer borrowing)
    try:
        from leon_cursor import leon_mouse_move, is_on_right_monitor
        ix, iy = int(x), int(y)
        if not is_on_right_monitor(ix):
            ix = ix + _leon_screen_x()
        leon_mouse_move(ix, iy)
        return {"ok": True, "result": {"moved": [ix, iy], "cursor": "leon"}}
    except ImportError:
        try:
            pg = _ensure_pyautogui()
            pg.moveTo(int(x), int(y), duration=0.1)
            return {"ok": True, "result": {"moved": [int(x), int(y)]}}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def keyboard_type(args: Dict[str, Any]) -> Dict[str, Any]:
    """Type a string into the focused window."""
    text = args.get("text", "")
    if not isinstance(text, str):
        return {"ok": False, "error": "text must be a string"}
    if len(text) > 4000:
        return {"ok": False, "error": "text too long (>4000 chars)"}
    try:
        from leon_cursor import leon_type
        if leon_type(text):
            return {"ok": True, "result": {"typed_chars": len(text), "method": "leon_cursor"}}
    except ImportError:
        pass
    try:
        pg = _ensure_pyautogui()
        pg.typewrite(text, interval=0.01)
        return {"ok": True, "result": {"typed_chars": len(text)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def keyboard_hotkey(args: Dict[str, Any]) -> Dict[str, Any]:
    """Fire a keyboard shortcut. combo is e.g. 'ctrl+l', 'alt+tab', 'super+e'."""
    combo = args.get("combo", "").strip().lower()
    if not combo:
        return {"ok": False, "error": "combo is required"}
    keys = [k.strip() for k in combo.split("+") if k.strip()]
    if not keys:
        return {"ok": False, "error": f"invalid combo: {combo}"}
    try:
        from leon_cursor import leon_key
        if leon_key(combo):
            return {"ok": True, "result": {"combo": combo, "method": "leon_cursor"}}
    except ImportError:
        pass
    try:
        pg = _ensure_pyautogui()
        pg.hotkey(*keys)
        return {"ok": True, "result": {"combo": combo}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def app_close(args: Dict[str, Any]) -> Dict[str, Any]:
    """Politely close a window matched by title substring (wmctrl -c sends
    the WM_DELETE message — same as clicking the [X] button). HIGH-risk
    tool: gated by the responder's confirmation layer before it gets here."""
    title = args.get("title_substring") or args.get("title") or ""
    if not title or not isinstance(title, str):
        return {"ok": False, "error": "title_substring is required"}
    if PLATFORM != "Linux":
        r = _pc_call("window_close", title)
        if r.get("ok") and not r.get("result"):
            return {"ok": False, "error": f"no window matching '{title}'"}
        return {"ok": True, "result": {"closed": title}} if r.get("ok") else r
    try:
        subprocess.run(["wmctrl", "-c", title], check=True, timeout=2)
        return {"ok": True, "result": {"closed": title}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_scroll(args: Dict[str, Any]) -> Dict[str, Any]:
    """Scroll the wheel. Positive `clicks` + direction='down' scrolls down.
    Optional x,y first parks the cursor over the target before scrolling."""
    clicks = args.get("clicks", 3)
    direction = (args.get("direction") or "down").lower()
    x = args.get("x")
    y = args.get("y")
    magnitude = abs(int(clicks))
    units = magnitude if direction == "down" else -magnitude
    if x is not None and y is not None:
        try:
            from leon_cursor import leon_scroll, is_on_right_monitor
            ix, iy = int(x), int(y)
            if not is_on_right_monitor(ix):
                ix = ix + _leon_screen_x()
            if leon_scroll(ix, iy, units):
                return {"ok": True, "result": {"scrolled": units, "direction": direction,
                                                "method": "leon_cursor"}}
        except ImportError:
            pass
    try:
        pg = _ensure_pyautogui()
        if x is not None and y is not None:
            pg.moveTo(int(x), int(y), duration=0.05)
        amount = magnitude if direction == "up" else -magnitude
        pg.scroll(amount)
        return {"ok": True, "result": {"scrolled": amount, "direction": direction}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_drag(args: Dict[str, Any]) -> Dict[str, Any]:
    """Press at (x1,y1), drag to (x2,y2), release. HIGH-risk because a
    misaimed drag can trash a layout / move files / select-all."""
    x1, y1 = args.get("x1"), args.get("y1")
    x2, y2 = args.get("x2"), args.get("y2")
    button = args.get("button", "left")
    if None in (x1, y1, x2, y2):
        return {"ok": False, "error": "x1, y1, x2, y2 are required"}
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}
    try:
        pg = _ensure_pyautogui()
        pg.moveTo(int(x1), int(y1), duration=0.1)
        pg.dragTo(int(x2), int(y2), duration=0.3, button=button)
        return {"ok": True, "result": {"dragged": [int(x1), int(y1), int(x2), int(y2)]}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def clipboard_copy(args: Dict[str, Any]) -> Dict[str, Any]:
    """Write text to the system clipboard. xclip daemonizes itself
    after reading stdin (it has to stay alive to serve the X selection),
    so we can't communicate(timeout=) — write, close stdin, then verify
    by reading the clipboard back. xsel exits immediately so we use it
    when available."""
    text = args.get("text", "")
    if not isinstance(text, str):
        return {"ok": False, "error": "text must be a string"}
    if len(text) > 100000:
        return {"ok": False, "error": "text too large (>100KB)"}

    if PLATFORM != "Linux":
        r = _pc_call("clipboard_copy", text)
        if r.get("ok") and not r.get("result"):
            return {"ok": False, "error": "clipboard write failed"}
        return ({"ok": True, "result": {"copied_chars": len(text),
                                        "via": PLATFORM.lower()}}
                if r.get("ok") else r)

    # Try xsel first (exits immediately) then xclip (daemonizes)
    last_err = "no clipboard backend available"
    for cmd in (["xsel", "-b", "-i"], ["xclip", "-selection", "clipboard"]):
        # shutil.which, not `which`: on Windows the `which` BINARY does not
        # exist, so this raised FileNotFoundError on the first iteration and
        # the whole probe died -- reported as a generic dispatcher error, so
        # the real cause (there is no `which` here) was never visible.
        bin_path = shutil.which(cmd[0]) or ""
        if not bin_path:
            continue
        try:
            p = subprocess.Popen(
                cmd, stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            try:
                p.stdin.write(text.encode("utf-8"))
                p.stdin.close()
            except Exception:
                pass
            # Verify by reading back. xclip backgrounds itself within ~50ms.
            time.sleep(0.05)
            try:
                out = subprocess.check_output(
                    ["xclip", "-selection", "clipboard", "-o"]
                    if cmd[0] == "xclip" else ["xsel", "-b", "-o"],
                    timeout=1,
                ).decode("utf-8", errors="replace")
            except Exception:
                out = ""
            if out == text or out.startswith(text[:200]):
                return {"ok": True, "result": {"copied_chars": len(text), "via": cmd[0]}}
            last_err = f"{cmd[0]}: clipboard mismatch on read-back"
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
    return {"ok": False, "error": last_err}


def clipboard_paste(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Read current clipboard contents (text only)."""
    if PLATFORM != "Linux":
        r = _pc_call("clipboard_paste")
        if r.get("ok"):
            return {"ok": True, "result": {"text": r.get("result") or "",
                                           "via": PLATFORM.lower()}}
        return r
    last_err = "no clipboard backend available"
    for cmd in (["xclip", "-selection", "clipboard", "-o"], ["xsel", "-b", "-o"]):
        try:
            out = subprocess.check_output(cmd, timeout=2,
                                          stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
            return {"ok": True, "result": {"text": out, "via": cmd[0]}}
        except FileNotFoundError:
            continue
        except subprocess.CalledProcessError as e:
            last_err = f"{cmd[0]} exit {e.returncode}"
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
    return {"ok": False, "error": last_err}


def browser_open(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open a URL in Brave (or whichever Chromium is on PATH). This is
    the right primitive for 'open youtube' / 'open github' / 'go to X' —
    `app.launch(brave)` only opens the browser, this actually navigates.

    Auto-prepends https:// if the user gave a bare host. When `new_window`
    is True, polls for the newly-spawned window and returns its ID so the
    caller can immediately move/focus that exact window without title-guessing
    (page titles for fresh tabs are unreliable — youtube.com loads as 'YouTube'
    briefly, then becomes whatever video title autoplays).
    """
    import time
    url = (args.get("url") or "").strip()
    if not url:
        return {"ok": False, "error": "url is required"}
    # Light sanitization so we don't shell-out random arguments
    if " " in url or "\n" in url or "\t" in url:
        return {"ok": False, "error": "url cannot contain whitespace"}
    if not url.startswith(("http://", "https://", "file://", "about:")):
        url = "https://" + url
    new_window = bool(args.get("new_window"))

    # Snapshot the current window IDs so we can identify the new one
    # after launch (only matters when new_window=True).
    before_ids = set()
    if new_window:
        try:
            out = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
            before_ids = {line.split()[0] for line in out.splitlines() if line.strip()}
        except Exception:
            pass

    # Leon uses his OWN Brave profile (separate user-data-dir + CDP port)
    # so he never touches Dean's logged-in sessions.
    candidates = ["brave-browser", "google-chrome", "chromium", "firefox", "xdg-open"]
    chosen_cmd = None
    for cmd in candidates:
        path = shutil.which(cmd) or ""   # see note above: `which` is POSIX-only
        if not path:
            continue
        argv = [cmd]
        # Use Leon's dedicated profile for Chromium-based browsers
        if cmd in ("brave-browser", "google-chrome", "chromium"):
            argv.extend([
                f"--user-data-dir={LEON_BRAVE_PROFILE}",
                f"--remote-debugging-port={LEON_CDP_PORT}",
                "--remote-allow-origins=http://127.0.0.1:9223",
                "--no-first-run",
                "--no-default-browser-check",
                f"--window-position={_leon_screen_x()},0",
                "--window-size=1920,1080",
            ])
        if new_window and cmd != "xdg-open":
            argv.append("--new-window")
        argv.append(url)
        try:
            subprocess.Popen(argv, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
            chosen_cmd = cmd
            break
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    if chosen_cmd is None:
        return {"ok": False, "error": "no usable browser found on PATH"}

    # If we asked for a new window, wait up to 4s for it to appear and
    # report its ID + title. This lets the caller pair browser_open with
    # window.move_to_monitor without guessing titles.
    new_window_info = None
    if new_window:
        deadline = time.monotonic() + 4.0
        while time.monotonic() < deadline:
            try:
                out = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
                for line in out.splitlines():
                    parts = line.split(None, 3)
                    if len(parts) < 4:
                        continue
                    wid = parts[0]
                    title = parts[3]
                    if wid in before_ids:
                        continue
                    # Only consider plausible browser windows
                    if any(tok in title for tok in ("Brave", "Chrome", "Chromium", "Firefox")):
                        new_window_info = {"id": wid, "title": title}
                        break
                if new_window_info:
                    break
            except Exception:
                pass
            time.sleep(0.25)

    result = {"url": url, "via": chosen_cmd}
    if new_window_info:
        result["window_id"] = new_window_info["id"]
        result["window_title"] = new_window_info["title"]

    # ALWAYS move Leon's browser windows to the right monitor (HDMI-1).
    # Leon's workspace is the right monitor. Dean uses left + middle.
    # If caller specified a monitor, honor that; otherwise default to right.
    move_to = args.get("move_to_monitor", "HDMI-1")
    wid_to_move = (new_window_info or {}).get("id") if new_window else None
    # Fallback: if no window ID from new_window detection, find the most
    # recently created browser window and move THAT. This handles the case
    # where Leon calls browser_open without new_window=True.
    if not wid_to_move:
        try:
            time.sleep(1.0)
            out = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
            for line in reversed(out.splitlines()):
                parts = line.split(None, 3)
                if len(parts) >= 4 and any(tok in parts[3] for tok in ("Brave", "Chrome", "Chromium")):
                    wid_to_move = parts[0]
                    break
        except Exception:
            pass
    if move_to and wid_to_move:
        try:
            time.sleep(0.5)  # let the window manager settle
            move_result = window_move_to_monitor({
                "window_id": wid_to_move,
                "monitor": move_to,
                "maximize": True,
            })
            result["moved_to_monitor"] = move_to
            result["move_ok"] = move_result.get("ok", False)
        except Exception as e:
            result["move_error"] = str(e)

    # ── Login-page detection ──────────────────────────────────────────
    # After opening, do a quick CDP check for login/signup forms.
    # If detected, warn Leon so he doesn't blindly fill credentials.
    try:
        time.sleep(1.5)  # let the page load
        from browser_cdp import _list_tabs, _CDPSession, _evaluate
        tabs = _list_tabs()
        # Find the tab matching our URL
        _url_lower = url.lower()
        matched_tab = None
        for t in tabs:
            if _url_lower.rstrip("/") in (t.get("url") or "").lower():
                matched_tab = t
                break
        if not matched_tab and tabs:
            # Fall back to most recent tab
            matched_tab = tabs[0]
        if matched_tab:
            s = _CDPSession(matched_tab["webSocketDebuggerUrl"])
            try:
                login_check = _evaluate(s, """
                    (() => {
                        const pw = document.querySelector('input[type="password"]');
                        const login_text = document.body.innerText.toLowerCase();
                        const has_login = pw !== null
                            || login_text.includes('log in')
                            || login_text.includes('sign in')
                            || login_text.includes('create account');
                        const title = document.title;
                        const actual_url = location.href;
                        return JSON.stringify({has_login, title, actual_url});
                    })()
                """)
                parsed = json.loads(login_check) if login_check else {}
                if parsed.get("has_login"):
                    result["login_page_detected"] = True
                    result["page_title"] = parsed.get("title", "")
                    result["actual_url"] = parsed.get("actual_url", "")
                    result["warning"] = (
                        "LOGIN PAGE DETECTED. This page has a login form. "
                        "Dean's browser may already be logged into a personal "
                        "account here. Do NOT fill any credentials unless Dean "
                        "explicitly gave you a username and password. If you "
                        "need to use a specific account, ASK Dean first."
                    )
            finally:
                s.close()
    except Exception:
        pass  # CDP not available or page not loaded yet — that's fine

    return {"ok": True, "result": result}


def web_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run a web search by opening Google in the browser. For 'search for
    X' / 'look up Y' style requests where the user wants the results page,
    not just navigation."""
    import urllib.parse
    q = (args.get("query") or "").strip()
    if not q:
        return {"ok": False, "error": "query is required"}
    engine = (args.get("engine") or "google").lower()
    if engine == "duckduckgo":
        url = "https://duckduckgo.com/?q=" + urllib.parse.quote_plus(q)
    elif engine == "youtube":
        url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(q)
    else:
        url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(q)
    return browser_open({"url": url})


# ── File ops (sandboxed) ──────────────────────────────────────────────────
# Leon has full filesystem access. Dean explicitly granted unrestricted
# read/write (2026-05-31). shell_exec and code_edit are already
# unrestricted — these match the same level.
_HOME = os.path.expanduser("~")
_FILE_WRITE_ROOTS = [
    _HOME,                                         # full home directory
    os.path.join(_HOME, "Desktop", "leon-out"),    # default output dir
]
_FILE_READ_ROOTS = [
    _HOME,                                         # full home directory
    "/tmp",                                        # temp files
]
_FILE_EXT_WHITELIST = {
    ".html", ".htm", ".css", ".js", ".jsx", ".ts", ".tsx", ".json",
    ".md", ".txt", ".log", ".csv", ".tsv",
    ".py", ".sh", ".rb", ".go", ".rs", ".java", ".kt", ".swift",
    ".c", ".cpp", ".h", ".hpp",
    ".yaml", ".yml", ".toml", ".ini", ".conf", ".cfg",
    ".sql", ".env",
    ".svg",
}
_FILE_MAX_BYTES = 1_048_576   # 1 MB per write/read


def _resolve_under(path: str, roots: list) -> Optional[str]:
    """Return the resolved absolute path if it falls under one of the
    allowed roots, else None. Defends against `..` traversal + symlinks
    that point outside the sandbox."""
    try:
        abs_path = os.path.realpath(os.path.expanduser(path))
    except Exception:
        return None
    for r in roots:
        root_real = os.path.realpath(r)
        if abs_path == root_real or abs_path.startswith(root_real + os.sep):
            return abs_path
    return None


def _file_ext_ok(path: str) -> bool:
    ext = os.path.splitext(path)[1].lower()
    return ext in _FILE_EXT_WHITELIST


def file_write(args: Dict[str, Any]) -> Dict[str, Any]:
    """Write text to a file under ~/Desktop/leon-out/. Auto-creates parent
    directories. Refuses paths outside the sandbox or with disallowed
    extensions. Use `mode='a'` to append; default is overwrite."""
    raw_path = (args.get("path") or "").strip()
    content = args.get("content")
    mode = (args.get("mode") or "w").lower()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    if mode not in ("w", "a"):
        return {"ok": False, "error": f"mode must be 'w' or 'a' (got {mode!r})"}
    if not isinstance(content, str):
        return {"ok": False, "error": "content must be a string"}
    if len(content.encode("utf-8", errors="replace")) > _FILE_MAX_BYTES:
        return {"ok": False, "error": f"content exceeds {_FILE_MAX_BYTES} bytes"}
    # If user gave a bare filename, drop it under the default write root
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(_FILE_WRITE_ROOTS[0], raw_path)
    abs_path = _resolve_under(raw_path, _FILE_WRITE_ROOTS)
    if abs_path is None:
        return {"ok": False, "error": (
            f"path outside sandbox. Writable roots: {_FILE_WRITE_ROOTS}"
        )}
    if not _file_ext_ok(abs_path):
        return {"ok": False, "error": (
            f"extension not in whitelist: {os.path.splitext(abs_path)[1]}"
        )}
    try:
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, mode, encoding="utf-8") as f:
            f.write(content)
        return {"ok": True, "result": {
            "path": abs_path,
            "bytes": len(content.encode("utf-8", errors="replace")),
            "mode": mode,
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_read(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read a UTF-8 text file under any allowed read root. Caps at 1MB."""
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(_FILE_WRITE_ROOTS[0], raw_path)
    abs_path = _resolve_under(raw_path, _FILE_READ_ROOTS)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such file: {abs_path}"}
    if os.path.isdir(abs_path):
        return {"ok": False, "error": "path is a directory; use file_list"}
    try:
        with open(abs_path, "rb") as f:
            data = f.read(_FILE_MAX_BYTES + 1)
        truncated = len(data) > _FILE_MAX_BYTES
        text = data[:_FILE_MAX_BYTES].decode("utf-8", errors="replace")
        return {"ok": True, "result": {
            "path": abs_path,
            "text": text,
            "bytes": len(data),
            "truncated": truncated,
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_list(args: Dict[str, Any]) -> Dict[str, Any]:
    """List files in a directory under an allowed read root. Returns
    name + size + is_dir flags. Skips hidden entries by default."""
    raw_path = (args.get("path") or _FILE_WRITE_ROOTS[0]).strip()
    show_hidden = bool(args.get("show_hidden"))
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(_FILE_WRITE_ROOTS[0], raw_path)
    abs_path = _resolve_under(raw_path, _FILE_READ_ROOTS)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isdir(abs_path):
        return {"ok": False, "error": f"not a directory: {abs_path}"}
    try:
        entries = []
        for name in sorted(os.listdir(abs_path)):
            if not show_hidden and name.startswith("."):
                continue
            p = os.path.join(abs_path, name)
            try:
                st = os.stat(p)
                entries.append({
                    "name": name,
                    "is_dir": os.path.isdir(p),
                    "size": st.st_size,
                    "mtime": st.st_mtime,
                })
            except OSError:
                continue
        return {"ok": True, "result": {
            "path": abs_path,
            "entries": entries[:500],   # cap so very large dirs don't blow up
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def notify(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pop a desktop notification via notify-send. Lets Leon ping Dean
    without speaking — useful for ambient updates ('build done', 'meeting
    in 5')."""
    title = (args.get("title") or "Leon").strip()[:120]
    body = (args.get("body") or "").strip()[:500]
    if not body:
        return {"ok": False, "error": "body is required"}
    urgency = (args.get("urgency") or "normal").lower()
    if urgency not in ("low", "normal", "critical"):
        urgency = "normal"
    if PLATFORM != "Linux":
        r = _pc_call("notify", title, body)
        return {"ok": True, "result": {"title": title}} if r.get("ok") else r
    try:
        subprocess.run(["notify-send", "-u", urgency, "-i", "dialog-information",
                        title, body], timeout=2, check=False)
        return {"ok": True, "result": {"title": title}}
    except FileNotFoundError:
        return {"ok": False, "error": "notify-send not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def tts_marker_set(args):
    """Touch the TTS marker file so the mic knows the SI is talking.

    THIS TOOL DID NOT EXIST. server/helpers.py has been calling it before
    every single spoken reply since it was written; the actuator answered
    "unknown tool", and helpers.py threw that answer away inside a bare
    `except Exception: pass`. So the marker was never written, the relay's
    speaker ledger stayed permanently empty, and every echo defence
    downstream of it degraded to pass-everything. That is the whole reason
    the SI transcribes its own voice as the owner's.

    The file's mtime is the start of the interval and its contents carry how
    long the clip runs, so a reader that wakes up late can still back-date
    correctly instead of losing the window.
    """
    try:
        duration = float(args.get("duration_s") or 0.0)
        cooldown = float(args.get("cooldown_s") or 0.0)
    except (TypeError, ValueError):
        duration, cooldown = 0.0, 0.0
    # Same resolution rule as brain/voice/audio_gate._default_marker_path().
    # If these two ever disagree the bug is invisible again, so keep the
    # env override name identical.
    marker = os.environ.get("LEON_TTS_MARKER", "").strip()
    if not marker:
        import tempfile
        marker = os.path.join(tempfile.gettempdir(), "leon-tts-active")
    try:
        with open(marker, "w", encoding="utf-8") as fh:
            fh.write("%.3f %.3f %.3f\n" % (time.time(), duration, cooldown))
        return {"ok": True, "marker": marker,
                "duration_s": duration, "cooldown_s": cooldown}
    except OSError as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}",
                "marker": marker}


def body_health(_args: Dict[str, Any]) -> Dict[str, Any]:
    """Can this SI actually touch anything? Answering the socket is not enough.

    The exact shape of GET /api/brain-check (server/routers/misc.py), for the
    exact same reason and written the day after it. That endpoint exists
    because a 200 on the port is not a brain; this tool exists because an
    accepted connection is not a body.

    Aiden's install of "Iris" (2026-08-12) is the case. The actuator was on
    disk, it started, it bound its socket, it registered 250+ tools, and it
    answered every request it was given — so any liveness test built on
    "does it connect" or "did the process start" passed. It still had no
    hands: `mss` and `pyautogui` were never installed into the SI's venv, so
    screen.capture, mouse.* and keyboard.* each raised ModuleNotFoundError at
    CALL time, one tool call too late for the installer to have noticed. The
    owner is told his SI is ready and finds out himself, one dead tool at a
    time.

    So this reports capability, not liveness, and it proves it by DOING the
    cheapest real version of each thing rather than trusting an import:
    grabbing one pixel is the difference between "mss imports" and "this
    machine will hand us the screen" — on a headless Linux box, a locked-down
    RDP session, or a Mac without the Screen Recording grant, the import
    succeeds and the grab does not.

    Deliberately cheap and side-effect free: nothing is clicked, typed or
    written. `ok` means the two capabilities Aiden actually lost — sight and
    input — are both real. Files alone are not hands.
    """
    detail: Dict[str, Any] = {}

    def probe(name, fn):
        try:
            fn()
            detail[name] = True
        except Exception as e:
            detail[name] = False
            detail[name + "_why"] = f"{type(e).__name__}: {e}"[:200]

    def _screen():
        mss_mod = _ensure_mss()
        from PIL import Image  # noqa: F401  — screen_capture needs it too
        with mss_mod.mss() as sct:
            sct.grab({"left": 0, "top": 0, "width": 1, "height": 1})

    def _input():
        # Read the cursor position: the lightest call that still goes all the
        # way down to the OS input layer, and it moves nothing.
        if PLATFORM == "Linux":
            # Linux drives xdotool/wmctrl directly (see platform_compat) —
            # they are system binaries, not pip packages, so an import probe
            # would report hands this machine does not have.
            if not shutil.which("xdotool"):
                raise RuntimeError("xdotool is not installed")
            subprocess.run(["xdotool", "getmouselocation"], timeout=5,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           check=True)
        else:
            _ensure_pyautogui().position()

    def _windows():
        if PLATFORM == "Linux":
            if not shutil.which("wmctrl"):
                raise RuntimeError("wmctrl is not installed")
        else:
            be = _pc()
            if be is None:
                raise RuntimeError(_pc_error or "no platform backend")

    def _files():
        os.listdir(PROJECT_ROOT)

    probe("screen", _screen)
    probe("input", _input)
    probe("windows", _windows)
    probe("files", _files)

    # ── Camera: reported honestly, never fatal ────────────────────────────
    # Same rule as sight and input — say what is REAL, not what imported —
    # but with the opposite verdict when it is missing. Plenty of desktops
    # have no webcam at all, and a tower with no camera is a healthy install;
    # failing body.health over it would tell an owner his SI is broken when
    # nothing is. So `camera` never enters `ok` or `missing`.
    #
    # Three states, because they need three different answers from the SI:
    #   "ready"   a real, non-black frame came back — it can see the room
    #   "absent"  no camera on this machine — the honest "I have no eyes here"
    #   "blocked" a camera exists but will not deliver: opencv missing, OS
    #             permission denied (macOS streams solid BLACK rather than
    #             erroring — see camera_tools._frame_is_black), or another
    #             app is holding the device exclusively (Windows/Teams/Zoom).
    # "blocked" is the one that matters: it is the state that looks like
    # "works" to every naive check and produces a confident description of a
    # black rectangle. camera_why carries the fix-it text to the owner.
    def _camera_status():
        try:
            import camera_tools  # type: ignore
        except Exception as e:
            return "blocked", f"camera support not installed: {type(e).__name__}: {e}"
        try:
            # probe=True actually opens the device — the same "grab one pixel"
            # standard the screen probe is held to. An import proves nothing.
            rep = camera_tools.camera_report({"max_index": 2, "timeout": 4})
        except Exception as e:
            return "blocked", f"camera probe failed: {type(e).__name__}: {e}"[:300]
        res = (rep or {}).get("result") or {}
        if res.get("working_cameras"):
            return "ready", None
        if res.get("permission_likely_blocked") or res.get("cameras"):
            return "blocked", (res.get("summary") or "camera present but unusable")
        if not res.get("opencv"):
            return "blocked", (
                "opencv is not installed in this SI's Python environment, so "
                "the camera cannot be opened even if one is attached")
        return "absent", "no camera device detected on this machine"

    try:
        _cam_state, _cam_why = _camera_status()
    except Exception as e:  # a health probe must never take the body down
        _cam_state, _cam_why = "blocked", f"{type(e).__name__}: {e}"[:200]
    detail["camera"] = (_cam_state == "ready")
    detail["camera_state"] = _cam_state
    if _cam_why:
        detail["camera_why"] = str(_cam_why)[:300]

    ok = bool(detail.get("screen") and detail.get("input"))
    missing = [k for k in ("screen", "input", "windows", "files")
               if not detail.get(k)]
    return {
        "ok": ok,
        "platform": PLATFORM,
        "transport": _transport.describe(),
        "tools": len(TOOLS),
        "missing": missing,
        **detail,
    }


# Tool dispatch table
TOOLS = {
    "body.health":      body_health,
    "tts.marker_set":   tts_marker_set,
    "screen.capture":   screen_capture,
    "window.list":      window_list,
    "window.focus":     window_focus,
    "window.list_monitors":    window_list_monitors,
    "window.move_to_monitor":  window_move_to_monitor,
    "click.text":              click_text,
    "click.element":           click_element,
    "app.launch":       app_launch,
    "app.close":        app_close,
    "mouse.click":      mouse_click,
    "mouse.move":       mouse_move,
    "mouse.scroll":     mouse_scroll,
    "mouse.drag":       mouse_drag,
    "keyboard.type":    keyboard_type,
    "keyboard.hotkey":  keyboard_hotkey,
    "clipboard.copy":   clipboard_copy,
    "clipboard.paste":  clipboard_paste,
    "browser.open":     browser_open,
    "web.search":       web_search,
    # CDP-based browser DOM tools (only work when Brave was launched with
    # --remote-debugging-port=9222). See leon-actuator/browser_cdp.py.
    "browser.dom_state":     lambda a: __import__("browser_cdp", fromlist=["browser_dom_state"]).browser_dom_state(a),
    "browser.dom_click":     lambda a: __import__("browser_cdp", fromlist=["browser_dom_click"]).browser_dom_click(a),
    "browser.dom_extract":   lambda a: __import__("browser_cdp", fromlist=["browser_dom_extract"]).browser_dom_extract(a),
    "browser.dom_scroll_to": lambda a: __import__("browser_cdp", fromlist=["browser_dom_scroll_to"]).browser_dom_scroll_to(a),
    "browser.solve_captcha":  lambda a: __import__("browser_cdp", fromlist=["browser_solve_captcha"]).browser_solve_captcha(a),
    "browser.close_tab":      lambda a: __import__("browser_cdp", fromlist=["browser_close_tab"]).browser_close_tab(a),
    "browser.cleanup":        lambda a: __import__("browser_cdp", fromlist=["browser_cleanup"]).browser_cleanup(a),
    "file.write":       file_write,
    "file.read":        file_read,
    "file.list":        file_list,
    "notify":           notify,
}

# ── Extra tools from tools_extra.py ──────────────────────────────────────
# Merging EXTRA_TOOLS into TOOLS at module load so the dispatch lookup is one
# dict. tools_extra is a sibling module that imports from this one lazily,
# so the order matters — keep this AFTER TOOLS is defined above.
try:
    from tools_extra import EXTRA_TOOLS as _EXTRA_TOOLS
    TOOLS.update(_EXTRA_TOOLS)
    print(f"[ACTUATOR] loaded {len(_EXTRA_TOOLS)} extra tools from tools_extra")
except Exception as _e:
    print(f"[ACTUATOR] WARN: tools_extra failed to load: {_e}")

# camera_tools.py has been on disk, complete and cross-platform, since it was
# written — and was never imported here, so `webcam.capture` was not a key in
# TOOLS on ANY install. Aiden asked his SI "Iris" (Windows 11, 2026-08-12) to
# look at the camera and see him; the brain's only webcam path was the
# dashboard-browser round trip built for Dean (server/helpers.py
# _make_webcam_tool), and the body's own camera was not reachable at all
# because the dispatch table had no entry to reach it with. A module that is
# not registered is a module that does not exist. Note the import is
# deliberately NOT conditional on cv2 being installed: camera_tools imports
# opencv lazily, so on a machine with no opencv the tools still register and
# return a specific "install opencv" message instead of "unknown tool", which
# is the difference between a fixable answer and a mystery.
try:
    from camera_tools import EXTRA_TOOLS as _CAMERA_TOOLS
    TOOLS.update(_CAMERA_TOOLS)
    print(f"[ACTUATOR] loaded {len(_CAMERA_TOOLS)} camera tools (webcam.capture/camera.report)")
except Exception as _e:
    print(f"[ACTUATOR] WARN: camera_tools failed to load: {_e}")

try:
    from info_tools import EXTRA_TOOLS as _INFO_TOOLS
    TOOLS.update(_INFO_TOOLS)
    print(f"[ACTUATOR] loaded {len(_INFO_TOOLS)} info tools from info_tools")
except Exception as _e:
    print(f"[ACTUATOR] WARN: info_tools failed to load: {_e}")

try:
    from browser_apps import EXTRA_TOOLS as _BROWSER_APPS
    TOOLS.update(_BROWSER_APPS)
    print(f"[ACTUATOR] loaded {len(_BROWSER_APPS)} browser_apps tools")
except Exception as _e:
    print(f"[ACTUATOR] WARN: browser_apps failed to load: {_e}")

try:
    from browser_power import EXTRA_TOOLS as _BROWSER_POWER
    TOOLS.update(_BROWSER_POWER)
    print(f"[ACTUATOR] loaded {len(_BROWSER_POWER)} browser_power tools")
except Exception as _e:
    print(f"[ACTUATOR] WARN: browser_power failed to load: {_e}")

try:
    from creative_tools import EXTRA_TOOLS as _CREATIVE_TOOLS
    TOOLS.update(_CREATIVE_TOOLS)
    print(f"[ACTUATOR] loaded {len(_CREATIVE_TOOLS)} creative tools (image/video/music gen)")
except Exception as _e:
    print(f"[ACTUATOR] WARN: creative_tools failed to load: {_e}")

try:
    from integration_tools import EXTRA_TOOLS as _INTEGRATION_TOOLS
    TOOLS.update(_INTEGRATION_TOOLS)
    print(f"[ACTUATOR] loaded {len(_INTEGRATION_TOOLS)} integration tools (youtube/spotify/slack/notion/etc)")
except Exception as _e:
    print(f"[ACTUATOR] WARN: integration_tools failed to load: {_e}")

try:
    from accessibility import EXTRA_TOOLS as _A11Y_TOOLS
    TOOLS.update(_A11Y_TOOLS)
    print(f"[ACTUATOR] loaded {len(_A11Y_TOOLS)} accessibility tools (a11y.find/click/cache)")
except Exception as _e:
    print(f"[ACTUATOR] WARN: accessibility tools failed to load: {_e}")

# System control tools (Leon direct PC control)
try:
    from system_tools import EXTRA_TOOLS as _SYS_TOOLS
    TOOLS.update(_SYS_TOOLS)
    print(f"[ACTUATOR] loaded {len(_SYS_TOOLS)} system tools (system.volume/mute, media.key, shell.exec)")
except Exception as _e:
    print(f"[ACTUATOR] WARN: system tools failed to load: {_e}")

try:
    from pc_tools import EXTRA_TOOLS as _PC_TOOLS
    TOOLS.update(_PC_TOOLS)
    print(f"[ACTUATOR] loaded {len(_PC_TOOLS)} pc.* tools")
except Exception as _e:
    print(f"[ACTUATOR] WARN: pc_tools failed to load: {_e}")

# ── CDP browser tools (extended) ──────────────────────────────────────────
# Late-binding via lambdas so browser_cdp.py is only imported when these are
# actually called. That keeps the actuator boot fast even if Brave's debug
# port isn't reachable yet.
def _cdp_lambda(fn_name):
    def _wrap(args):
        mod = __import__("browser_cdp", fromlist=[fn_name])
        return getattr(mod, fn_name)(args)
    return _wrap

for _name in (
    "browser_back", "browser_forward", "browser_reload",
    "browser_close_tab", "browser_new_tab", "browser_switch_tab", "browser_list_tabs",
    "browser_dom_fill", "browser_dom_select", "browser_dom_check",
    "browser_dom_hover", "browser_dom_keydown",
    "browser_dom_wait_for", "browser_dom_wait_for_text",
    "browser_dom_get_text", "browser_dom_set_value",
    "browser_get_html", "browser_get_url", "browser_get_title",
    "browser_get_cookies", "browser_local_storage_get", "browser_console_logs",
    "browser_set_viewport", "browser_zoom", "browser_screenshot_full",
    "browser_ensure_cdp",
):
    TOOLS[_name.replace("_", ".", 1)] = _cdp_lambda(_name)
del _name


# ── JSON-RPC server over Unix socket ──────────────────────────────────────
def _handle_client(conn: socket.socket) -> None:
    try:
        # Read until newline — simple line-delimited JSON protocol
        buf = b""
        while not buf.endswith(b"\n"):
            chunk = conn.recv(4096)
            if not chunk:
                return
            buf += chunk
            if len(buf) > 1_000_000:
                conn.sendall(b'{"ok":false,"error":"request too large"}\n')
                return

        try:
            req = json.loads(buf.decode("utf-8"))
        except Exception:
            conn.sendall(b'{"ok":false,"error":"invalid json"}\n')
            return

        # On loopback-TCP transports (Windows) any local process could dial
        # this port, so a shared secret is required. No-op on POSIX, where
        # the socket file's 0600 mode is already the access control.
        if not _transport.check_token(req.get("token")):
            conn.sendall(b'{"ok":false,"error":"unauthorized: bad or missing actuator token"}\n')
            return

        tool = req.get("tool")
        args = req.get("args") or {}
        if not isinstance(tool, str) or not isinstance(args, dict):
            conn.sendall(b'{"ok":false,"error":"missing tool or args"}\n')
            return

        fn = TOOLS.get(tool)
        if fn is None:
            result = {"ok": False, "error": f"unknown tool: {tool}"}
        else:
            try:
                result = fn(args)
            except Exception as e:
                result = {"ok": False, "error": f"unhandled {type(e).__name__}: {e}"}

        _audit(tool, args, result)
        try:
            conn.sendall((json.dumps(result) + "\n").encode("utf-8"))
        except Exception:
            pass
    finally:
        try: conn.close()
        except Exception: pass


def serve() -> None:
    # Transport is chosen by leon_transport: Unix socket on POSIX, loopback
    # TCP + token on Windows (AF_UNIX does not exist there). See that module.
    sock, addr = _transport.bind_listener(backlog=8)
    print(f"[ACTUATOR] listening on {addr} via {_transport.describe()} (DISPLAY={DISPLAY})", flush=True)
    print(f"[ACTUATOR] tools: {', '.join(sorted(TOOLS.keys()))}", flush=True)
    print(f"[ACTUATOR] whitelisted apps: {', '.join(sorted(APP_WHITELIST.keys()))}", flush=True)
    try:
        while True:
            conn, _ = sock.accept()
            t = threading.Thread(target=_handle_client, args=(conn,), daemon=True)
            t.start()
    except KeyboardInterrupt:
        pass
    finally:
        try: sock.close()
        except Exception: pass
        _transport.clear_rendezvous()


def _ensure_leon_brave():
    """Pre-launch Leon's own Brave instance if not already running.

    Chromium ignores --user-data-dir when another instance is running.
    By launching Leon's Brave FIRST (with his own profile + CDP port +
    window position on the right monitor), subsequent browser_open calls
    add tabs to HIS instance instead of Dean's.
    """
    import time as _t
    # Check if Leon's Brave is already running
    try:
        out = subprocess.check_output(
            ["pgrep", "-f", f"user-data-dir={LEON_BRAVE_PROFILE}"],
            timeout=2
        ).decode().strip()
        if out:
            print(f"[ACTUATOR] Leon's Brave already running (PIDs: {out.replace(chr(10), ',')})")
            return
    except subprocess.CalledProcessError:
        pass  # no match = not running
    except Exception:
        pass

    # Clear stale singleton locks — if Leon's Brave crashed, it leaves
    # locks behind and Chromium routes new launches to Dean's instance.
    import glob as _glob
    for lockfile in _glob.glob(os.path.join(LEON_BRAVE_PROFILE, "Singleton*")):
        try:
            os.remove(lockfile)
            print(f"[ACTUATOR] Cleared stale lock: {os.path.basename(lockfile)}")
        except Exception:
            pass

    print(f"[ACTUATOR] Launching Leon's Brave on right monitor (HDMI-1)...")
    try:
        # Ensure DISPLAY is set — systemd services don't inherit X env
        _env = {**os.environ, "DISPLAY": ":0"}
        subprocess.Popen([
            "brave-browser",
            f"--user-data-dir={LEON_BRAVE_PROFILE}",
            f"--remote-debugging-port={LEON_CDP_PORT}",
            "--remote-allow-origins=http://127.0.0.1:9223",
            "--no-first-run",
            "--no-default-browser-check",
            f"--window-position={_leon_screen_x()},0",
            "--window-size=1920,1080",
            "about:blank",
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
           start_new_session=True, env=_env)
        _t.sleep(3)
        # Verify it actually started
        try:
            out = subprocess.check_output(
                ["pgrep", "-f", f"user-data-dir={LEON_BRAVE_PROFILE}"],
                timeout=2
            ).decode().strip()
            if out:
                print(f"[ACTUATOR] Leon's Brave running (PIDs: {out.replace(chr(10), ',')})")
            else:
                print("[ACTUATOR] WARNING: Leon's Brave launch may have failed — no process found")
        except Exception:
            print("[ACTUATOR] WARNING: Could not verify Leon's Brave launch")
    except Exception as e:
        print(f"[ACTUATOR] Failed to launch Leon's Brave: {e}")


if __name__ == "__main__":
    _ensure_leon_brave()
    serve()
