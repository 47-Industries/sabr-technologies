"""system_tools — Leon's direct control of Dean's PC.

Registered into the actuator's dotted-name dispatch (EXTRA_TOOLS). These run as
Dean's desktop user, reached ONLY through the authenticated localhost relay
(Bearer LEON_API_KEY over the SSH -R 9100 tunnel — not network-exposed). This
is the "real hands on the actual machine" layer: system volume, media keys, and
arbitrary shell.

Every shell.exec and system change is appended to an audit log
(~/.local/share/leon/pc-control.log) so Dean always has a record of what Leon
did to his box.
"""

from __future__ import annotations

import os
import platform as _platform
import shutil
import subprocess
import sys
import time
from typing import Any, Dict

_AUDIT_LOG = os.path.expanduser("~/.local/share/leon/pc-control.log")


# ── Cross-platform backend ────────────────────────────────────────────────
# Same shape as actuator.py's _pc()/_pc_call(): the Linux pactl/xdotool paths
# below are untouched, everything non-Linux dispatches into platform_compat.
_pc_backend = None
_pc_error = None


def _pc():
    """Lazily resolve the platform backend. Returns None if unavailable."""
    global _pc_backend, _pc_error
    if _pc_backend is None and _pc_error is None:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import platform_compat  # type: ignore
            _pc_backend = platform_compat._detect()
        except Exception as e:
            _pc_error = f"platform_compat unavailable: {type(e).__name__}: {e}"
    return _pc_backend


def _is_linux() -> bool:
    """Read live so tests can monkeypatch platform.system()."""
    return _platform.system() == "Linux"


def _pc_call(method: str, *a, **kw) -> Dict[str, Any]:
    """Run a platform_compat method, wrapped in the actuator result shape."""
    be = _pc()
    if be is None:
        return {"ok": False, "error": _pc_error or "no platform backend"}
    fn = getattr(be, method, None)
    if fn is None:
        return {"ok": False, "error": f"{method} unsupported on {_platform.system()}",
                "unsupported_on": _platform.system()}
    try:
        return {"ok": True, "result": fn(*a, **kw)}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _audit(tool: str, detail: str) -> None:
    try:
        os.makedirs(os.path.dirname(_AUDIT_LOG), exist_ok=True)
        with open(_AUDIT_LOG, "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{tool}\t{detail}\n")
    except Exception:
        pass  # never let logging failure block the action


def _env() -> Dict[str, str]:
    """Environment for desktop/audio subprocesses. The actuator already has
    DISPLAY (via leon-x-env.sh); ensure XDG_RUNTIME_DIR so pactl/wpctl find the
    PipeWire/PulseAudio socket even if the service env is minimal."""
    env = dict(os.environ)
    if hasattr(os, "getuid"):  # POSIX only
        env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def _run(cmd: list, timeout: float = 8.0) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True,
                          timeout=timeout, env=_env())


# ── Audio (the thing that just failed: "lower my volume by 10") ────────────
def _pactl_default_sink() -> str:
    return "@DEFAULT_SINK@"


def system_volume(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set or adjust the default sink volume.
      {"level": 0-100}   -> set absolute
      {"delta": -10..10} -> adjust relative (e.g. -10 = "lower by 10")
    Uses pactl (works on both PipeWire-pulse and PulseAudio)."""
    if not _is_linux():
        level = args.get("level")
        delta = args.get("delta")
        if level is None and delta is None:
            return {"ok": False, "error": "need 'level' (0-100) or 'delta' (e.g. -10)"}
        r = _pc_call("volume_set", level=None if level is None else int(level),
                     delta=None if delta is None else int(delta))
        if not r.get("ok"):
            return r
        _audit("system.volume", str(r.get("result")))
        vol = _pc_call("volume_get")
        return {"ok": True, "action": r.get("result"),
                "volume": vol.get("result") if vol.get("ok") else None}
    if not shutil.which("pactl"):
        return {"ok": False, "error": "pactl not found on PC"}
    sink = _pactl_default_sink()
    try:
        if "level" in args and args["level"] is not None:
            lvl = max(0, min(150, int(args["level"])))
            _run(["pactl", "set-sink-volume", sink, f"{lvl}%"])
            action = f"set {lvl}%"
        elif "delta" in args and args["delta"] is not None:
            d = int(args["delta"])
            sign = "+" if d >= 0 else "-"
            _run(["pactl", "set-sink-volume", sink, f"{sign}{abs(d)}%"])
            action = f"delta {d}%"
        else:
            return {"ok": False, "error": "need 'level' (0-100) or 'delta' (e.g. -10)"}
        # read back
        vol = _run(["pactl", "get-sink-volume", sink]).stdout.strip().splitlines()
        _audit("system.volume", action)
        return {"ok": True, "action": action, "volume": vol[0] if vol else None}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "pactl timed out"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_mute(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mute/unmute/toggle the default sink. {"mute": true|false} or {} = toggle."""
    if not _is_linux():
        want = args["mute"] if args.get("mute") is not None else "toggle"
        r = _pc_call("volume_mute", want)
        if not r.get("ok"):
            return r
        _audit("system.mute", str(want))
        return {"ok": True, "mute": str(want)}
    if not shutil.which("pactl"):
        return {"ok": False, "error": "pactl not found on PC"}
    sink = _pactl_default_sink()
    if "mute" in args and args["mute"] is not None:
        state = "1" if args["mute"] else "0"
    else:
        state = "toggle"
    try:
        _run(["pactl", "set-sink-mute", sink, state])
        _audit("system.mute", state)
        return {"ok": True, "mute": state}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def media_key(args: Dict[str, Any]) -> Dict[str, Any]:
    """Media transport / hardware keys.
      {"key": "playpause|play|pause|next|previous|stop|volumeup|volumedown|mute"}
    Prefers playerctl for transport; falls back to xdotool XF86 keys."""
    key = (args.get("key") or "").lower()
    if not _is_linux():
        r = _pc_call("media_key", key)
        if not r.get("ok"):
            return r
        _audit("media.key", key)
        return {"ok": True, "key": key, "via": "platform_compat"}
    transport = {"playpause": "play-pause", "play": "play", "pause": "pause",
                 "next": "next", "previous": "previous", "stop": "stop"}
    try:
        if key in transport and shutil.which("playerctl"):
            _run(["playerctl", transport[key]])
            _audit("media.key", key)
            return {"ok": True, "key": key, "via": "playerctl"}
        xf86 = {"playpause": "XF86AudioPlay", "next": "XF86AudioNext",
                "previous": "XF86AudioPrev", "stop": "XF86AudioStop",
                "volumeup": "XF86AudioRaiseVolume",
                "volumedown": "XF86AudioLowerVolume", "mute": "XF86AudioMute"}
        if key in xf86 and shutil.which("xdotool"):
            _run(["xdotool", "key", xf86[key]])
            _audit("media.key", key)
            return {"ok": True, "key": key, "via": "xdotool"}
        return {"ok": False, "error": f"unsupported key '{key}' or tool missing"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def volume_adjust(args: Dict[str, Any]) -> Dict[str, Any]:
    """Nudge master volume by a delta. {"delta": -10} / {"delta": +10}

    THIS TOOL DID NOT EXIST. brain/reflexes.py has called "volume.adjust" for
    its whole life (three call sites, plus self_repair_tools.py recommends it
    by name as THE correct way to change volume), and the actuator has always
    answered "unknown tool: volume.adjust". Observed live 2026-08-12: Dean
    said "can you lower my volume?" and the SI replied "Couldn't lower volume:
    unknown tool: volume.adjust" -- reading a raw dispatcher error out loud,
    which is why it sounded suddenly stupid and off-voice. Asked again, a
    different path picked media.key and it worked, which is why it "sounded
    normal again and then did it."

    Exactly the same class as tts.marker_set: a name the brain calls that
    nobody ever implemented on the other side. Both found the same night.

    Built on media.key because that path is already proven on all three OSes
    rather than inventing a fourth audio backend. A delta is expressed as
    repeated volume steps, which is what the hardware keys do anyway.
    """
    try:
        delta = int(float(args.get("delta") or 0))
    except (TypeError, ValueError):
        return {"ok": False, "error": "delta must be a number"}
    if delta == 0:
        return {"ok": True, "delta": 0, "note": "no change requested"}
    r = _pc_call("volume_set", delta=delta)
    if not r.get("ok"):
        # Hardware media keys as the fallback: proven on all three OSes, and
        # a coarse ~2% per press. Better a slightly imprecise nudge than the
        # "unknown tool" error the owner used to hear read aloud.
        key = "volumeup" if delta > 0 else "volumedown"
        steps = max(1, min(25, int(round(abs(delta) / 2.0))))
        last = {}
        for _i in range(steps):
            last = media_key({"key": key})
            if not last.get("ok"):
                return {"ok": False, "delta": delta, "steps_completed": _i,
                        "error": last.get("error", "media_key failed")}
        _audit("volume.adjust", f"{delta:+d} via {steps}x {key}")
        return {"ok": True, "delta": delta, "steps": steps, "via": "media.key"}
    _audit("volume.adjust", f"{delta:+d}")
    return {"ok": True, "delta": delta, "level": r.get("result"),
            "via": "platform_compat"}


def volume_set_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set master volume to an absolute percent. {"percent": 0-100}

    Called from brain/reflexes.py in three places ("max the volume",
    "mute it", "set volume to 40") and never implemented. Same class as
    volume.adjust -- the platform primitive has existed on Windows, macOS
    and Linux this whole time with nothing bound to a tool name.
    """
    try:
        pct = int(float(args.get("percent")))
    except (TypeError, ValueError):
        return {"ok": False, "error": "percent must be a number 0-100"}
    pct = max(0, min(100, pct))
    r = _pc_call("volume_set", level=pct)
    if not r.get("ok"):
        return r
    _audit("volume.set", f"{pct}%")
    return {"ok": True, "percent": pct, "level": r.get("result")}


def volume_mute_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mute / unmute / toggle. {"state": "toggle"|true|false}"""
    state = args.get("state", "toggle")
    r = _pc_call("volume_mute", state)
    if not r.get("ok"):
        return r
    _audit("volume.mute", str(state))
    return {"ok": True, "state": state, "result": r.get("result")}


def volume_get_tool(args: Dict[str, Any]) -> Dict[str, Any]:
    """Read current master volume."""
    r = _pc_call("volume_get")
    if not r.get("ok"):
        return r
    return {"ok": True, "level": r.get("result")}


def audio_stop(args: Dict[str, Any]) -> Dict[str, Any]:
    """Stop whatever is playing. {"": {}}

    claude_api_responder.py calls "audio.stop" when the owner says stop
    talking / stop the music. Never implemented -- so "stop" did nothing
    and said nothing.
    """
    r = media_key({"key": "stop"})
    if not r.get("ok"):
        r = media_key({"key": "pause"})
    if r.get("ok"):
        _audit("audio.stop", "stopped")
    return r


# ── Arbitrary shell — full control, as Dean's desktop user ─────────────────
def shell_exec(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run an arbitrary shell command on the PC as the desktop user.

    {"command": "...", "timeout": 30, "cwd": "..."}

    This is unrestricted by design (Dean asked for full control). It is safe
    ONLY because the relay is localhost-bound + Bearer-authenticated. Every
    invocation is audit-logged. Output is truncated to keep responses sane."""
    cmd = args.get("command") or args.get("cmd")
    if not cmd or not isinstance(cmd, str):
        return {"ok": False, "error": "string 'command' required"}
    timeout = float(args.get("timeout", 30))
    cwd = args.get("cwd") or None
    _audit("shell.exec", cmd)
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=timeout, env=_env(), cwd=cwd)
        return {
            "ok": p.returncode == 0,
            "returncode": p.returncode,
            "stdout": p.stdout[-8000:],
            "stderr": p.stderr[-4000:],
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timed out after {timeout}s", "command": cmd}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


EXTRA_TOOLS: Dict[str, Any] = {
    "system.volume": system_volume,
    "system.mute": system_mute,
    "media.key": media_key,
    "volume.adjust": volume_adjust,
    "volume.set":    volume_set_tool,
    "volume.mute":   volume_mute_tool,
    "volume.get":    volume_get_tool,
    "audio.stop":    audio_stop,
    "shell.exec": shell_exec,
}


# ── Identity learning (Leon builds a memory of people, like a human) ────────
def _leon_id_dir():
    return os.path.expanduser("~/leon-identity")


def identity_learn(args):
    """Enter 'learn this person' mode: for the next N seconds, every face seen
    and voice heard is saved under <name>. Use when Dean says 'it's me' (name=
    dean) or introduces someone ('this is Aiden' -> name=aiden). Have them look
    at the camera and talk. args: {name, seconds?}"""
    name = (args.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name required"}
    seconds = float(args.get("seconds", 90))
    try:
        import sys
        sys.path.insert(0, _leon_id_dir())
        import leon_learn
        leon_learn.set_target(name, seconds)
        _audit("identity.learn", "%s for %ss" % (name, seconds))
        return {"ok": True, "learning": name, "seconds": seconds,
                "note": "Now capturing %s's face + voice. Have them face the "
                        "camera and talk for a bit." % name}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


def _id_db():
    import sqlite3
    db = os.path.join(_leon_id_dir(), "data", "identities.db")
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE IF NOT EXISTS identities(id INTEGER PRIMARY KEY, name TEXT UNIQUE, created_at REAL, notes TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS face_vectors(id INTEGER PRIMARY KEY, identity_id INTEGER, vec BLOB, captured_at REAL, quality REAL)")
    con.execute("CREATE TABLE IF NOT EXISTS voice_vectors(id INTEGER PRIMARY KEY, identity_id INTEGER, vec BLOB, captured_at REAL, quality REAL)")
    return con


def identity_list(args):
    """Who Leon knows: each enrolled person + how many face/voice samples."""
    try:
        con = _id_db()
        rows = con.execute(
            "SELECT i.name,"
            " (SELECT COUNT(*) FROM face_vectors f WHERE f.identity_id=i.id),"
            " (SELECT COUNT(*) FROM voice_vectors v WHERE v.identity_id=i.id)"
            " FROM identities i ORDER BY i.created_at").fetchall()
        return {"ok": True, "people": [
            {"name": r[0], "face_samples": r[1], "voice_samples": r[2]} for r in rows]}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


def identity_forget(args):
    """Forget a person entirely (delete their face + voice). args: {name}"""
    name = (args.get("name") or "").strip().lower()
    if not name:
        return {"ok": False, "error": "name required"}
    try:
        con = _id_db()
        row = con.execute("SELECT id FROM identities WHERE name=?", (name,)).fetchone()
        if not row:
            return {"ok": False, "error": "no one named %s" % name}
        con.execute("DELETE FROM face_vectors WHERE identity_id=?", (row[0],))
        con.execute("DELETE FROM voice_vectors WHERE identity_id=?", (row[0],))
        con.execute("DELETE FROM identities WHERE id=?", (row[0],))
        con.commit()
        _audit("identity.forget", name)
        return {"ok": True, "forgot": name}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


EXTRA_TOOLS.update({
    "identity.learn": identity_learn,
    "identity.list": identity_list,
    "identity.forget": identity_forget,
})
