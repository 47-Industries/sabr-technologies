"""system_tools — Leon's direct control of Dean's PC.

Registered into the actuator's dotted-name dispatch (EXTRA_TOOLS). These run as
Dean's desktop user, reached ONLY through the authenticated localhost relay
(Bearer LEON_API_KEY over the SSH -R 9100 tunnel — not network-exposed). This
is the "real hands on the actual machine" layer: system volume, media keys, and
arbitrary shell.

Every shell.exec and system change is appended to an audit log
(~/.local/share/leon/pc-control.log) so Dean always has a record of what Leon
did to his box.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from typing import Any, Dict

_AUDIT_LOG = os.path.expanduser("~/.local/share/leon/pc-control.log")


def _audit(tool: str, detail: str) -> None:
    try:
        os.makedirs(os.path.dirname(_AUDIT_LOG), exist_ok=True)
        with open(_AUDIT_LOG, "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{tool}\t{detail}\n")
    except Exception:
        pass  # never let logging failure block the action


def _env() -> Dict[str, str]:
    """Environment for desktop/audio subprocesses. The actuator already has
    DISPLAY (via leon-x-env.sh); ensure XDG_RUNTIME_DIR so pactl/wpctl find the
    PipeWire/PulseAudio socket even if the service env is minimal."""
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def _run(cmd: list, timeout: float = 8.0) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True,
                          timeout=timeout, env=_env())


# ── Audio (the thing that just failed: "lower my volume by 10") ────────────
def _pactl_default_sink() -> str:
    return "@DEFAULT_SINK@"


def system_volume(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set or adjust the default sink volume.
      {"level": 0-100}   -> set absolute
      {"delta": -10..10} -> adjust relative (e.g. -10 = "lower by 10")
    Uses pactl (works on both PipeWire-pulse and PulseAudio)."""
    if not shutil.which("pactl"):
        return {"ok": False, "error": "pactl not found on PC"}
    sink = _pactl_default_sink()
    try:
        if "level" in args and args["level"] is not None:
            lvl = max(0, min(150, int(args["level"])))
            _run(["pactl", "set-sink-volume", sink, f"{lvl}%"])
            action = f"set {lvl}%"
        elif "delta" in args and args["delta"] is not None:
            d = int(args["delta"])
            sign = "+" if d >= 0 else "-"
            _run(["pactl", "set-sink-volume", sink, f"{sign}{abs(d)}%"])
            action = f"delta {d}%"
        else:
            return {"ok": False, "error": "need 'level' (0-100) or 'delta' (e.g. -10)"}
        # read back
        vol = _run(["pactl", "get-sink-volume", sink]).stdout.strip().splitlines()
        _audit("system.volume", action)
        return {"ok": True, "action": action, "volume": vol[0] if vol else None}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "pactl timed out"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_mute(args: Dict[str, Any]) -> Dict[str, Any]:
    """Mute/unmute/toggle the default sink. {"mute": true|false} or {} = toggle."""
    if not shutil.which("pactl"):
        return {"ok": False, "error": "pactl not found on PC"}
    sink = _pactl_default_sink()
    if "mute" in args and args["mute"] is not None:
        state = "1" if args["mute"] else "0"
    else:
        state = "toggle"
    try:
        _run(["pactl", "set-sink-mute", sink, state])
        _audit("system.mute", state)
        return {"ok": True, "mute": state}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def media_key(args: Dict[str, Any]) -> Dict[str, Any]:
    """Media transport / hardware keys.
      {"key": "playpause|play|pause|next|previous|stop|volumeup|volumedown|mute"}
    Prefers playerctl for transport; falls back to xdotool XF86 keys."""
    key = (args.get("key") or "").lower()
    transport = {"playpause": "play-pause", "play": "play", "pause": "pause",
                 "next": "next", "previous": "previous", "stop": "stop"}
    try:
        if key in transport and shutil.which("playerctl"):
            _run(["playerctl", transport[key]])
            _audit("media.key", key)
            return {"ok": True, "key": key, "via": "playerctl"}
        xf86 = {"playpause": "XF86AudioPlay", "next": "XF86AudioNext",
                "previous": "XF86AudioPrev", "stop": "XF86AudioStop",
                "volumeup": "XF86AudioRaiseVolume",
                "volumedown": "XF86AudioLowerVolume", "mute": "XF86AudioMute"}
        if key in xf86 and shutil.which("xdotool"):
            _run(["xdotool", "key", xf86[key]])
            _audit("media.key", key)
            return {"ok": True, "key": key, "via": "xdotool"}
        return {"ok": False, "error": f"unsupported key '{key}' or tool missing"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ── Arbitrary shell — full control, as Dean's desktop user ─────────────────
def shell_exec(args: Dict[str, Any]) -> Dict[str, Any]:
    """Run an arbitrary shell command on the PC as the desktop user.

    {"command": "...", "timeout": 30, "cwd": "..."}

    This is unrestricted by design (Dean asked for full control). It is safe
    ONLY because the relay is localhost-bound + Bearer-authenticated. Every
    invocation is audit-logged. Output is truncated to keep responses sane."""
    cmd = args.get("command") or args.get("cmd")
    if not cmd or not isinstance(cmd, str):
        return {"ok": False, "error": "string 'command' required"}
    timeout = float(args.get("timeout", 30))
    cwd = args.get("cwd") or None
    _audit("shell.exec", cmd)
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           timeout=timeout, env=_env(), cwd=cwd)
        return {
            "ok": p.returncode == 0,
            "returncode": p.returncode,
            "stdout": p.stdout[-8000:],
            "stderr": p.stderr[-4000:],
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"timed out after {timeout}s", "command": cmd}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


EXTRA_TOOLS: Dict[str, Any] = {
    "system.volume": system_volume,
    "system.mute": system_mute,
    "media.key": media_key,
    "shell.exec": shell_exec,
}


# ── Identity learning (Leon builds a memory of people, like a human) ────────
def _leon_id_dir():
    return os.path.expanduser("~/leon-identity")


def identity_learn(args):
    """Enter 'learn this person' mode: for the next N seconds, every face seen
    and voice heard is saved under <name>. Use when Dean says 'it's me' (name=
    dean) or introduces someone ('this is Aiden' -> name=aiden). Have them look
    at the camera and talk. args: {name, seconds?}"""
    name = (args.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name required"}
    seconds = float(args.get("seconds", 90))
    try:
        import sys
        sys.path.insert(0, _leon_id_dir())
        import leon_learn
        leon_learn.set_target(name, seconds)
        _audit("identity.learn", "%s for %ss" % (name, seconds))
        return {"ok": True, "learning": name, "seconds": seconds,
                "note": "Now capturing %s's face + voice. Have them face the "
                        "camera and talk for a bit." % name}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


def _id_db():
    import sqlite3
    db = os.path.join(_leon_id_dir(), "data", "identities.db")
    con = sqlite3.connect(db)
    con.execute("CREATE TABLE IF NOT EXISTS identities(id INTEGER PRIMARY KEY, name TEXT UNIQUE, created_at REAL, notes TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS face_vectors(id INTEGER PRIMARY KEY, identity_id INTEGER, vec BLOB, captured_at REAL, quality REAL)")
    con.execute("CREATE TABLE IF NOT EXISTS voice_vectors(id INTEGER PRIMARY KEY, identity_id INTEGER, vec BLOB, captured_at REAL, quality REAL)")
    return con


def identity_list(args):
    """Who Leon knows: each enrolled person + how many face/voice samples."""
    try:
        con = _id_db()
        rows = con.execute(
            "SELECT i.name,"
            " (SELECT COUNT(*) FROM face_vectors f WHERE f.identity_id=i.id),"
            " (SELECT COUNT(*) FROM voice_vectors v WHERE v.identity_id=i.id)"
            " FROM identities i ORDER BY i.created_at").fetchall()
        return {"ok": True, "people": [
            {"name": r[0], "face_samples": r[1], "voice_samples": r[2]} for r in rows]}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


def identity_forget(args):
    """Forget a person entirely (delete their face + voice). args: {name}"""
    name = (args.get("name") or "").strip().lower()
    if not name:
        return {"ok": False, "error": "name required"}
    try:
        con = _id_db()
        row = con.execute("SELECT id FROM identities WHERE name=?", (name,)).fetchone()
        if not row:
            return {"ok": False, "error": "no one named %s" % name}
        con.execute("DELETE FROM face_vectors WHERE identity_id=?", (row[0],))
        con.execute("DELETE FROM voice_vectors WHERE identity_id=?", (row[0],))
        con.execute("DELETE FROM identities WHERE id=?", (row[0],))
        con.commit()
        _audit("identity.forget", name)
        return {"ok": True, "forgot": name}
    except Exception as e:
        return {"ok": False, "error": "%s: %s" % (type(e).__name__, e)}


EXTRA_TOOLS.update({
    "identity.learn": identity_learn,
    "identity.list": identity_list,
    "identity.forget": identity_forget,
})
