"""
Cross-platform transport for the actuator JSON-RPC link.

WHY THIS EXISTS
---------------
The brain and the actuator talked over a Unix domain socket at a hardcoded
path (/tmp/leon-actuator.sock). That path, and socket.AF_UNIX itself, do not
exist on Windows. The listener had platform detection at the top of the file
but still bound AF_UNIX unconditionally, and FIVE separate client-side files
hardcoded the same /tmp path. So a Windows install could boot, talk, and save
its brain -- with no hands at all.

This module is the single place that decides HOW the two halves connect, so
those six call sites can never drift again.

TRANSPORT CHOICE
----------------
  POSIX (Linux, macOS): Unix domain socket, mode 0600. Unchanged behaviour.
  Windows:              loopback TCP on 127.0.0.1, ephemeral port, plus a
                        shared-secret token.

Named pipes would be the "native" Windows answer but need pywin32; loopback
TCP is stdlib-only and works in a bare venv, which is what the installer
actually produces. Loopback is not reachable off-box, and the token stops
another local user's process from driving the actuator.

The port and token live in a small JSON rendezvous file next to the state
dir, written 0600, so the client discovers the listener without a fixed port.
"""

from __future__ import annotations

import json
import os
import socket
import stat
import tempfile

IS_WINDOWS = os.name == "nt"
HAS_AF_UNIX = hasattr(socket, "AF_UNIX")
USE_UNIX_SOCKET = HAS_AF_UNIX and not IS_WINDOWS


def _state_dir() -> str:
    """Where the socket / rendezvous file lives, per-OS.

    Override with LEON_ACTUATOR_DIR. Falls back to the temp dir so this can
    never raise on a machine with an unusual home layout.
    """
    override = os.environ.get("LEON_ACTUATOR_DIR")
    if override:
        d = override
    elif IS_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or tempfile.gettempdir()
        d = os.path.join(base, "SabrSI")
    else:
        d = os.environ.get("XDG_RUNTIME_DIR") or tempfile.gettempdir()
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        d = tempfile.gettempdir()
    return d


SOCKET_PATH = os.path.join(_state_dir(), "leon-actuator.sock")
RENDEZVOUS_PATH = os.path.join(_state_dir(), "leon-actuator.rendezvous.json")

# Legacy POSIX path. Older brains still dial this; keep honouring it on POSIX
# so an upgrade doesn't sever the link mid-flight.
LEGACY_SOCKET_PATH = "/tmp/leon-actuator.sock"


def _chmod_600(path: str) -> None:
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        pass  # best effort; Windows ACLs don't map onto this


def _write_rendezvous(port: int, token: str) -> None:
    tmp = RENDEZVOUS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"port": port, "token": token}, fh)
    _chmod_600(tmp)
    os.replace(tmp, RENDEZVOUS_PATH)  # atomic on both POSIX and Windows


def read_rendezvous() -> dict | None:
    try:
        with open(RENDEZVOUS_PATH, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and data.get("port"):
            return data
    except Exception:
        pass
    return None


def clear_rendezvous() -> None:
    for p in (RENDEZVOUS_PATH, SOCKET_PATH):
        try:
            os.unlink(p)
        except Exception:
            pass


# --------------------------------------------------------------------------
# Listener side
# --------------------------------------------------------------------------

def bind_listener(backlog: int = 8) -> tuple[socket.socket, str]:
    """Bind and listen. Returns (socket, human-readable address)."""
    if USE_UNIX_SOCKET:
        try:
            os.unlink(SOCKET_PATH)
        except FileNotFoundError:
            pass
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.bind(SOCKET_PATH)
        _chmod_600(SOCKET_PATH)
        sock.listen(backlog)
        return sock, SOCKET_PATH

    token = os.urandom(24).hex()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))  # ephemeral -- never collides with a live port
    sock.listen(backlog)
    port = sock.getsockname()[1]
    _write_rendezvous(port, token)
    os.environ["LEON_ACTUATOR_TOKEN"] = token
    return sock, f"127.0.0.1:{port}"


def expected_token() -> str | None:
    """Token the listener should require, or None on POSIX (fs perms suffice)."""
    if USE_UNIX_SOCKET:
        return None
    return os.environ.get("LEON_ACTUATOR_TOKEN") or (read_rendezvous() or {}).get("token")


def check_token(supplied: str | None) -> bool:
    want = expected_token()
    if want is None:
        return True
    if not supplied:
        return False
    try:
        import hmac
        return hmac.compare_digest(str(supplied), str(want))
    except Exception:
        return False


# --------------------------------------------------------------------------
# Client side
# --------------------------------------------------------------------------

def listener_present() -> bool:
    """Is an actuator listening right now? Used to pick local vs relay."""
    if USE_UNIX_SOCKET:
        return os.path.exists(SOCKET_PATH) or os.path.exists(LEGACY_SOCKET_PATH)
    return read_rendezvous() is not None


def connect(timeout: float = 10.0) -> tuple[socket.socket, str | None]:
    """Connect to the actuator. Returns (socket, token-to-send-or-None).

    Raises the underlying OSError if nothing is listening -- callers already
    treat that as 'fall back to the HTTP relay'.
    """
    if USE_UNIX_SOCKET:
        path = SOCKET_PATH if os.path.exists(SOCKET_PATH) else LEGACY_SOCKET_PATH
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect(path)
        return s, None

    rv = read_rendezvous()
    if not rv:
        raise ConnectionRefusedError(
            f"no actuator rendezvous file at {RENDEZVOUS_PATH} "
            "(actuator not running, or started under a different user)"
        )
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(("127.0.0.1", int(rv["port"])))
    return s, rv.get("token")


def describe() -> str:
    kind = "unix-socket" if USE_UNIX_SOCKET else "loopback-tcp"
    return f"{kind} @ {SOCKET_PATH if USE_UNIX_SOCKET else RENDEZVOUS_PATH}"
