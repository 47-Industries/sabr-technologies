"""
tools_extra.py — Extra Leon actuator tools.

This module is imported by actuator.py to keep that file readable. All
functions here follow the same {ok, result|error} contract and are
registered into actuator.TOOLS at the bottom of actuator.py.

Categories:
  - Window management (resize, minimize, maximize, snap, workspace_switch, ...)
  - Mouse/keyboard extensions (double_click, jiggle, press, paste_via_clipboard, ...)
  - Clipboard extensions (clear, image_copy)
  - Spotify (D-Bus / MPRIS)
  - VS Code + terminal + files + screen lock
  - System info (resources, temp, fans, battery, gpu, services, processes, logs)
  - File system extras (delete, copy, move, hash, search, diff, patch, archive,
    pdf, csv, jq, yaml, wordcount)
  - Shell exec extras (streaming, background, kill, status, in_dir)
  - Dotenv read/set, git_status

Each function imports lazily what it needs so module import is cheap.
"""

from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import threading
import time
import zipfile
from typing import Any, Dict, List, Optional


# ── Shared helpers re-exported from actuator (set up by actuator at module load) ──
# We try to fetch them lazily to avoid a circular import.

def _actuator():
    """Lazy reference to the actuator module so we can pull its helpers."""
    import actuator as _act  # noqa: WPS433
    return _act


def _ensure_pyautogui():
    return _actuator()._ensure_pyautogui()


def _list_monitors():
    return _actuator()._list_monitors()


def _file_write_roots():
    return _actuator()._FILE_WRITE_ROOTS


def _file_read_roots():
    return _actuator()._FILE_READ_ROOTS


def _resolve_under(path, roots):
    return _actuator()._resolve_under(path, roots)


def _home():
    return _actuator()._HOME


def _clipboard_copy(args):
    """Re-use the actuator's existing clipboard_copy (xclip-or-xsel logic)."""
    return _actuator().clipboard_copy(args)


# ──────────────────────────────────────────────────────────────────────────
# WINDOW MANAGEMENT
# ──────────────────────────────────────────────────────────────────────────


def window_resize(args: Dict[str, Any]) -> Dict[str, Any]:
    """Resize a window by title substring. Keeps existing x/y (gravity -1)."""
    title = args.get("title_substring") or args.get("title") or ""
    width = args.get("width")
    height = args.get("height")
    if not title or width is None or height is None:
        return {"ok": False, "error": "title_substring, width, height required"}
    try:
        out = subprocess.check_output(["wmctrl", "-l"], timeout=2).decode("utf-8", errors="replace")
        win_id = next((ln.split()[0] for ln in out.splitlines()
                       if len(ln.split(None, 3)) >= 4 and title.lower() in ln.split(None, 3)[3].lower()), None)
        if not win_id:
            return {"ok": False, "error": f"no window matching '{title}'"}
        subprocess.run(["wmctrl", "-ir", win_id, "-b", "remove,maximized_vert,maximized_horz"], timeout=2, check=False)
        subprocess.run(["wmctrl", "-ir", win_id, "-e", f"0,-1,-1,{int(width)},{int(height)}"], timeout=2, check=True)
        return {"ok": True, "result": {"window_id": win_id, "size": [int(width), int(height)]}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_minimize(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    if not title:
        return {"ok": False, "error": "title_substring is required"}
    try:
        r = subprocess.run(["xdotool", "search", "--name", title, "windowminimize"],
                           capture_output=True, timeout=2)
        if r.returncode != 0:
            return {"ok": False, "error": f"xdotool failed: {r.stderr.decode(errors='replace').strip()}"}
        return {"ok": True, "result": {"minimized": title}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_maximize(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    if not title:
        return {"ok": False, "error": "title_substring is required"}
    try:
        subprocess.run(["wmctrl", "-r", title, "-b", "add,maximized_vert,maximized_horz"],
                       timeout=2, check=True)
        return {"ok": True, "result": {"maximized": title}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_unmaximize(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    if not title:
        return {"ok": False, "error": "title_substring is required"}
    try:
        subprocess.run(["wmctrl", "-r", title, "-b", "remove,maximized_vert,maximized_horz"],
                       timeout=2, check=True)
        return {"ok": True, "result": {"unmaximized": title}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_pin_always_on_top(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    pinned = bool(args.get("pinned", True))
    if not title:
        return {"ok": False, "error": "title_substring is required"}
    op = "add" if pinned else "remove"
    try:
        subprocess.run(["wmctrl", "-r", title, "-b", f"{op},above"], timeout=2, check=True)
        return {"ok": True, "result": {"pinned": pinned, "title": title}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_position(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    x, y = args.get("x"), args.get("y")
    if not title or x is None or y is None:
        return {"ok": False, "error": "title_substring, x, y required"}
    try:
        subprocess.run(["wmctrl", "-r", title, "-b", "remove,maximized_vert,maximized_horz"], timeout=2, check=False)
        subprocess.run(["wmctrl", "-r", title, "-e", f"0,{int(x)},{int(y)},-1,-1"], timeout=2, check=True)
        return {"ok": True, "result": {"title": title, "pos": [int(x), int(y)]}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def window_snap(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    side = (args.get("side") or "").lower()
    if not title or side not in ("left", "right", "top", "bottom"):
        return {"ok": False, "error": "title_substring and side (left/right/top/bottom) required"}
    try:
        out = subprocess.check_output(["wmctrl", "-lG"], timeout=2).decode("utf-8", errors="replace")
        win_id = None
        wx = wy = ww = wh = 0
        for line in out.splitlines():
            parts = line.split(None, 7)
            if len(parts) >= 8 and title.lower() in parts[7].lower():
                win_id = parts[0]
                wx, wy, ww, wh = int(parts[2]), int(parts[3]), int(parts[4]), int(parts[5])
                break
        if not win_id:
            return {"ok": False, "error": f"no window matching '{title}'"}
        mons = _list_monitors()
        cx, cy = wx + ww // 2, wy + wh // 2
        mon = next((m for m in mons if m["x"] <= cx < m["x"] + m["w"] and m["y"] <= cy < m["y"] + m["h"]),
                   mons[0] if mons else None)
        if mon is None:
            return {"ok": False, "error": "no monitors detected"}
        if side == "left":
            tx, ty, tw, th = mon["x"], mon["y"], mon["w"] // 2, mon["h"]
        elif side == "right":
            tx, ty, tw, th = mon["x"] + mon["w"] // 2, mon["y"], mon["w"] // 2, mon["h"]
        elif side == "top":
            tx, ty, tw, th = mon["x"], mon["y"], mon["w"], mon["h"] // 2
        else:
            tx, ty, tw, th = mon["x"], mon["y"] + mon["h"] // 2, mon["w"], mon["h"] // 2
        subprocess.run(["wmctrl", "-ir", win_id, "-b", "remove,maximized_vert,maximized_horz"], timeout=2, check=False)
        subprocess.run(["wmctrl", "-ir", win_id, "-e", f"0,{tx},{ty},{tw},{th}"], timeout=2, check=True)
        return {"ok": True, "result": {"window_id": win_id, "side": side,
                                       "rect": [tx, ty, tw, th], "monitor": mon["name"]}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def workspace_switch(args: Dict[str, Any]) -> Dict[str, Any]:
    idx = args.get("index")
    if idx is None:
        return {"ok": False, "error": "index is required"}
    try:
        subprocess.run(["wmctrl", "-s", str(int(idx))], timeout=2, check=True)
        return {"ok": True, "result": {"workspace": int(idx)}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"could not switch to workspace {idx}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def workspace_move_window(args: Dict[str, Any]) -> Dict[str, Any]:
    title = args.get("title_substring") or args.get("title") or ""
    ws = args.get("workspace")
    if not title or ws is None:
        return {"ok": False, "error": "title_substring and workspace required"}
    try:
        subprocess.run(["wmctrl", "-r", title, "-t", str(int(ws))], timeout=2, check=True)
        return {"ok": True, "result": {"title": title, "workspace": int(ws)}}
    except subprocess.CalledProcessError:
        return {"ok": False, "error": f"no window matching '{title}'"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def desktop_show(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        r = subprocess.run(["wmctrl", "-k", "on"], timeout=2, capture_output=True)
        if r.returncode == 0:
            return {"ok": True, "result": {"showed_desktop": True, "via": "wmctrl"}}
        pg = _ensure_pyautogui()
        pg.hotkey("super", "d")
        return {"ok": True, "result": {"showed_desktop": True, "via": "super+d"}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# MOUSE EXTENSIONS
# ──────────────────────────────────────────────────────────────────────────


def mouse_double_click(args: Dict[str, Any]) -> Dict[str, Any]:
    x, y = args.get("x"), args.get("y")
    button = args.get("button", "left")
    if x is None or y is None:
        return {"ok": False, "error": "x and y are required"}
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}
    try:
        pg = _ensure_pyautogui()
        pg.doubleClick(int(x), int(y), button=button)
        return {"ok": True, "result": {"double_clicked": [int(x), int(y)], "button": button}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_triple_click(args: Dict[str, Any]) -> Dict[str, Any]:
    x, y = args.get("x"), args.get("y")
    button = args.get("button", "left")
    if x is None or y is None:
        return {"ok": False, "error": "x and y are required"}
    if button not in ("left", "right", "middle"):
        return {"ok": False, "error": f"invalid button: {button}"}
    try:
        pg = _ensure_pyautogui()
        pg.tripleClick(int(x), int(y), button=button)
        return {"ok": True, "result": {"triple_clicked": [int(x), int(y)], "button": button}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_jiggle(args: Dict[str, Any]) -> Dict[str, Any]:
    duration_s = float(args.get("duration_s", 60))
    interval_s = float(args.get("interval_s", 30))
    if duration_s <= 0 or interval_s <= 0:
        return {"ok": False, "error": "duration_s and interval_s must be > 0"}
    try:
        pg = _ensure_pyautogui()
        def _run():
            end = time.monotonic() + duration_s
            while time.monotonic() < end:
                try:
                    x, y = pg.position()
                    pg.moveTo(x + 5, y, duration=0.05)
                    pg.moveTo(x, y, duration=0.05)
                except Exception:
                    pass
                time.sleep(interval_s)
        threading.Thread(target=_run, daemon=True).start()
        return {"ok": True, "result": {"jiggling_for_s": duration_s, "interval_s": interval_s}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_position(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        pg = _ensure_pyautogui()
        x, y = pg.position()
        return {"ok": True, "result": {"x": int(x), "y": int(y)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def mouse_screen_to_monitor(args: Dict[str, Any]) -> Dict[str, Any]:
    x, y = args.get("x"), args.get("y")
    if x is None or y is None:
        return {"ok": False, "error": "x and y are required"}
    try:
        x, y = int(x), int(y)
        mons = _list_monitors()
        for m in mons:
            if m["x"] <= x < m["x"] + m["w"] and m["y"] <= y < m["y"] + m["h"]:
                return {"ok": True, "result": {"idx": m["idx"], "name": m["name"], "monitor": m}}
        return {"ok": False, "error": f"({x},{y}) not on any monitor"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# KEYBOARD EXTENSIONS
# ──────────────────────────────────────────────────────────────────────────


def keyboard_paste_via_clipboard(args: Dict[str, Any]) -> Dict[str, Any]:
    text = args.get("text", "")
    if not isinstance(text, str):
        return {"ok": False, "error": "text must be a string"}
    if not text:
        return {"ok": False, "error": "text is required"}
    cc = _clipboard_copy({"text": text})
    if not cc.get("ok"):
        return {"ok": False, "error": f"clipboard_copy failed: {cc.get('error')}"}
    try:
        pg = _ensure_pyautogui()
        pg.hotkey("ctrl", "v")
        return {"ok": True, "result": {"pasted_chars": len(text)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def keyboard_press(args: Dict[str, Any]) -> Dict[str, Any]:
    key = (args.get("key") or "").strip().lower()
    presses = int(args.get("presses", 1))
    interval = float(args.get("interval", 0))
    if not key:
        return {"ok": False, "error": "key is required"}
    if presses < 1 or presses > 100:
        return {"ok": False, "error": "presses must be 1-100"}
    try:
        pg = _ensure_pyautogui()
        pg.press(key, presses=presses, interval=interval)
        return {"ok": True, "result": {"key": key, "presses": presses}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def keyboard_down(args: Dict[str, Any]) -> Dict[str, Any]:
    key = (args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key is required"}
    try:
        pg = _ensure_pyautogui()
        pg.keyDown(key)
        return {"ok": True, "result": {"key_down": key}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def keyboard_up(args: Dict[str, Any]) -> Dict[str, Any]:
    key = (args.get("key") or "").strip().lower()
    if not key:
        return {"ok": False, "error": "key is required"}
    try:
        pg = _ensure_pyautogui()
        pg.keyUp(key)
        return {"ok": True, "result": {"key_up": key}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# CLIPBOARD EXTENSIONS
# ──────────────────────────────────────────────────────────────────────────


def clipboard_clear(_args: Dict[str, Any]) -> Dict[str, Any]:
    last_err = "no clipboard backend available"
    for cmd in (["xsel", "-bc"], ["xclip", "-selection", "clipboard"]):
        bin_path = subprocess.run(["which", cmd[0]], capture_output=True, timeout=1).stdout.decode().strip()
        if not bin_path:
            continue
        try:
            if cmd[0] == "xsel":
                subprocess.run(cmd, timeout=2, check=False)
            else:
                p = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     start_new_session=True)
                try:
                    p.stdin.write(b"")
                    p.stdin.close()
                except Exception:
                    pass
            return {"ok": True, "result": {"cleared": True, "via": cmd[0]}}
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
    return {"ok": False, "error": last_err}


def clipboard_image_copy(args: Dict[str, Any]) -> Dict[str, Any]:
    path = (args.get("path") or "").strip()
    if not path:
        return {"ok": False, "error": "path is required"}
    abs_path = os.path.realpath(os.path.expanduser(path))
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"no such file: {abs_path}"}
    try:
        with open(abs_path, "rb") as f:
            data = f.read()
        p = subprocess.Popen(["xclip", "-selection", "clipboard", "-t", "image/png", "-i"],
                             stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        try:
            p.stdin.write(data)
            p.stdin.close()
        except Exception:
            pass
        time.sleep(0.05)
        return {"ok": True, "result": {"copied_image": abs_path, "bytes": len(data)}}
    except FileNotFoundError:
        return {"ok": False, "error": "xclip not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# SPOTIFY (MPRIS over D-Bus)
# ──────────────────────────────────────────────────────────────────────────


def _spotify_call(method: str) -> Dict[str, Any]:
    try:
        subprocess.run(["dbus-send", "--print-reply",
                        "--dest=org.mpris.MediaPlayer2.spotify",
                        "/org/mpris/MediaPlayer2",
                        f"org.mpris.MediaPlayer2.Player.{method}"],
                       timeout=2, check=True, capture_output=True)
        return {"ok": True, "result": {"method": method}}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "error": f"Spotify not running? {e.stderr.decode(errors='replace').strip()}"}
    except FileNotFoundError:
        return {"ok": False, "error": "dbus-send not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def spotify_play_pause(_args): return _spotify_call("PlayPause")
def spotify_next(_args): return _spotify_call("Next")
def spotify_previous(_args): return _spotify_call("Previous")


def spotify_what_is_playing(_args: Dict[str, Any]) -> Dict[str, Any]:
    import re as _re
    try:
        out = subprocess.check_output([
            "gdbus", "call", "--session",
            "--dest", "org.mpris.MediaPlayer2.spotify",
            "--object-path", "/org/mpris/MediaPlayer2",
            "--method", "org.freedesktop.DBus.Properties.Get",
            "org.mpris.MediaPlayer2.Player", "Metadata",
        ], timeout=2, stderr=subprocess.PIPE).decode("utf-8", errors="replace")
        def grab(key):
            m = _re.search(r"'%s':\s*<(?:\[)?'([^']*)'" % _re.escape(key), out)
            return m.group(1) if m else None
        title = grab("xesam:title")
        artists = _re.search(r"'xesam:artist':\s*<\[([^\]]*)\]>", out)
        artist = None
        if artists:
            am = _re.findall(r"'([^']*)'", artists.group(1))
            artist = ", ".join(am) if am else None
        return {"ok": True, "result": {"title": title, "artist": artist,
                                       "album": grab("xesam:album"),
                                       "url": grab("xesam:url")}}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "error": f"Spotify not running: {e.stderr.decode(errors='replace').strip()}"}
    except FileNotFoundError:
        return {"ok": False, "error": "gdbus not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def spotify_volume(args: Dict[str, Any]) -> Dict[str, Any]:
    level = args.get("level")
    if level is None:
        return {"ok": False, "error": "level (0-100) required"}
    try:
        level = int(level)
        if not 0 <= level <= 100:
            return {"ok": False, "error": "level must be 0-100"}
        subprocess.run([
            "gdbus", "call", "--session", "--dest", "org.mpris.MediaPlayer2.spotify",
            "--object-path", "/org/mpris/MediaPlayer2",
            "--method", "org.freedesktop.DBus.Properties.Set",
            "org.mpris.MediaPlayer2.Player", "Volume", f"<double {level/100.0}>",
        ], timeout=2, check=True, capture_output=True)
        return {"ok": True, "result": {"volume": level}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# VS CODE / TERMINAL / FILES / SCREEN LOCK
# ──────────────────────────────────────────────────────────────────────────


def vscode_open_file(args: Dict[str, Any]) -> Dict[str, Any]:
    path = (args.get("path") or "").strip()
    if not path:
        return {"ok": False, "error": "path is required"}
    abs_path = os.path.realpath(os.path.expanduser(path))
    try:
        subprocess.Popen(["code", abs_path], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "result": {"opened": abs_path}}
    except FileNotFoundError:
        return {"ok": False, "error": "`code` CLI not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def vscode_open_folder(args: Dict[str, Any]) -> Dict[str, Any]:
    path = (args.get("path") or "").strip()
    if not path:
        return {"ok": False, "error": "path is required"}
    abs_path = os.path.realpath(os.path.expanduser(path))
    if not os.path.isdir(abs_path):
        return {"ok": False, "error": f"not a directory: {abs_path}"}
    try:
        subprocess.Popen(["code", abs_path], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "result": {"opened_folder": abs_path}}
    except FileNotFoundError:
        return {"ok": False, "error": "`code` CLI not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def terminal_spawn(args: Dict[str, Any]) -> Dict[str, Any]:
    cwd = (args.get("cwd") or "").strip() or os.path.expanduser("~")
    command = (args.get("command") or "").strip()
    cwd_abs = os.path.realpath(os.path.expanduser(cwd))
    if not os.path.isdir(cwd_abs):
        return {"ok": False, "error": f"cwd not a directory: {cwd_abs}"}
    argv = ["gnome-terminal", "--working-directory", cwd_abs]
    if command:
        argv += ["--", "bash", "-c", command + "; exec bash"]
    try:
        subprocess.Popen(argv, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "result": {"spawned": True, "cwd": cwd_abs, "command": command or None}}
    except FileNotFoundError:
        return {"ok": False, "error": "gnome-terminal not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def files_open(args: Dict[str, Any]) -> Dict[str, Any]:
    path = (args.get("path") or "").strip()
    if not path:
        return {"ok": False, "error": "path is required"}
    abs_path = os.path.realpath(os.path.expanduser(path))
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such path: {abs_path}"}
    try:
        subprocess.Popen(["xdg-open", abs_path], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "result": {"opened": abs_path}}
    except FileNotFoundError:
        return {"ok": False, "error": "xdg-open not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def screen_lock(_args: Dict[str, Any]) -> Dict[str, Any]:
    for cmd in (["xdg-screensaver", "lock"], ["gnome-screensaver-command", "-l"],
                ["loginctl", "lock-session"]):
        bin_path = subprocess.run(["which", cmd[0]], capture_output=True, timeout=1).stdout.decode().strip()
        if not bin_path:
            continue
        try:
            r = subprocess.run(cmd, timeout=2, capture_output=True)
            if r.returncode == 0:
                return {"ok": True, "result": {"locked": True, "via": cmd[0]}}
        except Exception:
            continue
    return {"ok": False, "error": "no screen-lock backend available"}


# ──────────────────────────────────────────────────────────────────────────
# SYSTEM INFO
# ──────────────────────────────────────────────────────────────────────────


def system_resource_summary(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.1)
        vm = psutil.virtual_memory()
        du = psutil.disk_usage("/")
        try:
            la = os.getloadavg()
        except Exception:
            la = [0.0, 0.0, 0.0]
        return {"ok": True, "result": {
            "cpu_percent": cpu, "ram_percent": vm.percent,
            "ram_used_gb": round(vm.used / 1e9, 2),
            "ram_total_gb": round(vm.total / 1e9, 2),
            "disk_root_percent": du.percent,
            "disk_root_free_gb": round(du.free / 1e9, 2),
            "load_avg": [round(la[0], 2), round(la[1], 2), round(la[2], 2)],
        }}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_temperature(_args: Dict[str, Any]) -> Dict[str, Any]:
    cpu_c = None; gpu_c = None; raw = []
    try:
        out = subprocess.check_output(["sensors", "-j"], timeout=3,
                                      stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        data = json.loads(out)
        for sensor, body in data.items():
            if not isinstance(body, dict):
                continue
            for label, vals in body.items():
                if not isinstance(vals, dict):
                    continue
                for k, v in vals.items():
                    if "_input" in k and isinstance(v, (int, float)) and "temp" in k:
                        raw.append({"sensor": sensor, "label": label, "value": float(v)})
                        if cpu_c is None and ("core" in label.lower() or "package" in label.lower()
                                              or "tctl" in label.lower() or "cpu" in sensor.lower()):
                            cpu_c = float(v)
    except Exception:
        pass
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"],
            timeout=3, stderr=subprocess.DEVNULL).decode().strip()
        if out:
            gpu_c = float(out.splitlines()[0].strip())
            raw.append({"sensor": "nvidia-smi", "label": "gpu", "value": gpu_c})
    except Exception:
        pass
    return {"ok": True, "result": {"cpu_c": cpu_c, "gpu_c": gpu_c, "raw": raw}}


def system_fan_speed(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        out = subprocess.check_output(["sensors", "-j"], timeout=3,
                                      stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        data = json.loads(out)
        fans = []
        for sensor, body in data.items():
            if not isinstance(body, dict):
                continue
            for label, vals in body.items():
                if not isinstance(vals, dict):
                    continue
                for k, v in vals.items():
                    if k.endswith("_input") and "fan" in k and isinstance(v, (int, float)):
                        fans.append({"sensor": f"{sensor}/{label}", "rpm": int(v)})
        return {"ok": True, "result": fans}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_battery(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import psutil
        bat = psutil.sensors_battery()
        if bat is None:
            return {"ok": False, "error": "no battery (desktop?)"}
        secs = bat.secsleft if bat.secsleft not in (psutil.POWER_TIME_UNLIMITED, psutil.POWER_TIME_UNKNOWN) else None
        return {"ok": True, "result": {"percent": round(bat.percent, 1),
                                       "plugged": bool(bat.power_plugged),
                                       "secs_left": secs}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_uptime(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        with open("/proc/uptime") as f:
            secs = float(f.read().split()[0])
        days, rem = divmod(int(secs), 86400)
        hours, rem = divmod(rem, 3600)
        mins, _ = divmod(rem, 60)
        parts = []
        if days: parts.append(f"{days} day{'s' if days != 1 else ''}")
        if hours: parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if mins and not days: parts.append(f"{mins} min{'s' if mins != 1 else ''}")
        human = ", ".join(parts) or f"{int(secs)} seconds"
        return {"ok": True, "result": {"seconds": int(secs), "human": human}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_users_logged_in(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import psutil
        from datetime import datetime
        users = [{"name": u.name, "terminal": u.terminal or "",
                  "started_iso": datetime.fromtimestamp(u.started).isoformat()}
                 for u in psutil.users()]
        return {"ok": True, "result": users}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_listening_ports(_args: Dict[str, Any]) -> Dict[str, Any]:
    import re
    try:
        out = subprocess.check_output(["ss", "-tlnp"], timeout=3,
                                      stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        entries = []
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 4:
                continue
            local = parts[3]
            if ":" not in local:
                continue
            addr, port = local.rsplit(":", 1)
            proc = ""; pid = None
            m = re.search(r'users:\(\("([^"]+)",pid=(\d+)', line)
            if m:
                proc = m.group(1); pid = int(m.group(2))
            try:
                entries.append({"port": int(port), "addr": addr, "process": proc, "pid": pid})
            except ValueError:
                continue
            if len(entries) >= 30:
                break
        return {"ok": True, "result": entries}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_disk_io(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import psutil
        c = psutil.disk_io_counters()
        if c is None:
            return {"ok": False, "error": "no disk io counters"}
        return {"ok": True, "result": {"read_mb": round(c.read_bytes / 1e6, 2),
                                       "write_mb": round(c.write_bytes / 1e6, 2),
                                       "read_count": c.read_count, "write_count": c.write_count}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_network_io(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        import psutil
        stats = psutil.net_io_counters(pernic=True)
        result = {}
        for iface, c in stats.items():
            if iface == "lo":
                continue
            result[iface] = {"sent_mb": round(c.bytes_sent / 1e6, 2),
                             "recv_mb": round(c.bytes_recv / 1e6, 2),
                             "sent_packets": c.packets_sent,
                             "recv_packets": c.packets_recv,
                             "errs": c.errin + c.errout}
        return {"ok": True, "result": result}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_gpu_state(_args: Dict[str, Any]) -> Dict[str, Any]:
    try:
        out = subprocess.check_output([
            "nvidia-smi",
            "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw",
            "--format=csv,noheader,nounits",
        ], timeout=3, stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        gpus = []
        for line in out.strip().splitlines():
            cols = [c.strip() for c in line.split(",")]
            if len(cols) < 6:
                continue
            def _f(v):
                try: return float(v)
                except ValueError: return None
            gpus.append({"name": cols[0], "util_percent": _f(cols[1]),
                         "mem_used_mb": _f(cols[2]), "mem_total_mb": _f(cols[3]),
                         "temp_c": _f(cols[4]), "power_w": _f(cols[5])})
        return {"ok": True, "result": gpus}
    except FileNotFoundError:
        return {"ok": False, "error": "nvidia-smi not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_diskspace_by_dir(args: Dict[str, Any]) -> Dict[str, Any]:
    root = os.path.expanduser(args.get("root") or "~")
    depth = int(args.get("depth", 1))
    try:
        out = subprocess.check_output(
            ["bash", "-c", f"du -sb --max-depth={depth} {subprocess.list2cmdline([root])}/* 2>/dev/null | sort -rn | head -n 20"],
            timeout=3).decode("utf-8", errors="replace")
        entries = []
        for line in out.splitlines():
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            try:
                b = int(parts[0])
            except ValueError:
                continue
            h = float(b); u = 0
            for unit, div in (("G", 1e9), ("M", 1e6), ("K", 1e3)):
                if b >= div:
                    h = f"{b / div:.1f}{unit}"; break
            else:
                h = f"{b}B"
            entries.append({"path": parts[1], "human_size": h, "bytes": b})
        return {"ok": True, "result": entries}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_largest_files(args: Dict[str, Any]) -> Dict[str, Any]:
    root = os.path.expanduser(args.get("root") or "~")
    limit = int(args.get("limit", 20))
    min_mb = int(args.get("min_size_mb", 10))
    try:
        cmd = f"find {subprocess.list2cmdline([root])} -type f -size +{min_mb}M -printf '%s\\t%p\\n' 2>/dev/null | sort -rn | head -n {limit}"
        out = subprocess.check_output(["bash", "-c", cmd], timeout=5).decode("utf-8", errors="replace")
        entries = []
        for line in out.splitlines():
            parts = line.split("\t", 1)
            if len(parts) != 2:
                continue
            try:
                b = int(parts[0])
            except ValueError:
                continue
            entries.append({"path": parts[1], "bytes": b, "mb": round(b / 1e6, 1)})
        return {"ok": True, "result": entries}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_package_list(args: Dict[str, Any]) -> Dict[str, Any]:
    flt = (args.get("filter") or "").strip().lower()
    try:
        out = subprocess.check_output(
            ["dpkg-query", "-W", "-f=${Package}\t${Version}\n"],
            timeout=3, stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        entries = []
        for line in out.splitlines():
            parts = line.split("\t", 1)
            if len(parts) != 2:
                continue
            name, ver = parts
            if flt and flt not in name.lower():
                continue
            entries.append({"name": name, "version": ver})
            if len(entries) >= 50:
                break
        return {"ok": True, "result": entries}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_service_status(args: Dict[str, Any]) -> Dict[str, Any]:
    name = (args.get("name") or "").strip()
    scope = (args.get("scope") or "user").lower()
    if not name:
        return {"ok": False, "error": "name is required"}
    flag = ["--user"] if scope == "user" else []
    try:
        active = subprocess.run(["systemctl", *flag, "is-active", name],
                                capture_output=True, timeout=3).stdout.decode().strip()
        enabled = subprocess.run(["systemctl", *flag, "is-enabled", name],
                                 capture_output=True, timeout=3).stdout.decode().strip()
        show = subprocess.check_output(
            ["systemctl", *flag, "show", name, "--property=SubState,Description"],
            timeout=3, stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        props = {}
        for line in show.splitlines():
            if "=" in line:
                k, v = line.split("=", 1); props[k] = v
        return {"ok": True, "result": {"active": active, "sub_state": props.get("SubState", ""),
                                       "enabled": enabled, "description": props.get("Description", "")}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_service_start(args):
    name = (args.get("name") or "").strip()
    scope = (args.get("scope") or "user").lower()
    if not name: return {"ok": False, "error": "name required"}
    flag = ["--user"] if scope == "user" else []
    try:
        subprocess.run(["systemctl", *flag, "start", name], timeout=3, check=True)
        return {"ok": True, "result": {"started": name,
                                       "status": system_service_status({"name": name, "scope": scope}).get("result")}}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "error": f"systemctl exit {e.returncode}"}


def system_service_stop(args):
    name = (args.get("name") or "").strip()
    scope = (args.get("scope") or "user").lower()
    if not name: return {"ok": False, "error": "name required"}
    flag = ["--user"] if scope == "user" else []
    try:
        subprocess.run(["systemctl", *flag, "stop", name], timeout=3, check=True)
        return {"ok": True, "result": {"stopped": name,
                                       "status": system_service_status({"name": name, "scope": scope}).get("result")}}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "error": f"systemctl exit {e.returncode}"}


def system_service_restart(args):
    name = (args.get("name") or "").strip()
    scope = (args.get("scope") or "user").lower()
    if not name: return {"ok": False, "error": "name required"}
    flag = ["--user"] if scope == "user" else []
    try:
        subprocess.run(["systemctl", *flag, "restart", name], timeout=3, check=True)
        return {"ok": True, "result": {"restarted": name,
                                       "status": system_service_status({"name": name, "scope": scope}).get("result")}}
    except subprocess.CalledProcessError as e:
        return {"ok": False, "error": f"systemctl exit {e.returncode}"}


def system_service_logs(args: Dict[str, Any]) -> Dict[str, Any]:
    name = (args.get("name") or "").strip()
    scope = (args.get("scope") or "user").lower()
    lines = int(args.get("lines", 50))
    if not name:
        return {"ok": False, "error": "name is required"}
    flag = ["--user"] if scope == "user" else []
    try:
        out = subprocess.check_output(
            ["journalctl", *flag, "-u", name, "-n", str(lines), "--no-pager"],
            timeout=5, stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        return {"ok": True, "result": {"lines": out.splitlines()}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def process_list(args: Dict[str, Any]) -> Dict[str, Any]:
    sort = (args.get("sort") or "cpu").lower()
    limit = int(args.get("limit", 20))
    if sort not in ("cpu", "mem", "name"):
        return {"ok": False, "error": "sort must be cpu|mem|name"}
    try:
        import psutil
        procs = []
        for p in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_info"]):
            try:
                info = p.info
                procs.append({"pid": info["pid"], "name": info["name"] or "",
                              "user": info["username"] or "",
                              "cpu_percent": info["cpu_percent"] or 0.0,
                              "mem_mb": round((info["memory_info"].rss if info["memory_info"] else 0) / 1e6, 1)})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        if sort == "cpu":
            procs.sort(key=lambda x: -x["cpu_percent"])
        elif sort == "mem":
            procs.sort(key=lambda x: -x["mem_mb"])
        else:
            procs.sort(key=lambda x: x["name"].lower())
        return {"ok": True, "result": procs[:limit]}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def process_find_by_name(args: Dict[str, Any]) -> Dict[str, Any]:
    name = (args.get("name") or "").strip().lower()
    if not name:
        return {"ok": False, "error": "name is required"}
    try:
        import psutil
        matches = []
        for p in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_info", "cmdline"]):
            try:
                pname = (p.info["name"] or "").lower()
                cmdline = " ".join(p.info["cmdline"] or [])
                if name in pname or name in cmdline.lower():
                    matches.append({"pid": p.info["pid"], "name": p.info["name"] or "",
                                    "user": p.info["username"] or "",
                                    "cpu_percent": p.info["cpu_percent"] or 0.0,
                                    "mem_mb": round((p.info["memory_info"].rss if p.info["memory_info"] else 0) / 1e6, 1),
                                    "cmdline": cmdline})
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return {"ok": True, "result": matches}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def process_kill(args: Dict[str, Any]) -> Dict[str, Any]:
    import signal as _signal
    pid = args.get("pid")
    name = (args.get("name") or "").strip().lower()
    sig_name = (args.get("signal") or "TERM").upper().lstrip("SIG")
    sig = getattr(_signal, f"SIG{sig_name}", None)
    if sig is None:
        return {"ok": False, "error": f"unknown signal: {sig_name}"}
    if not pid and not name:
        return {"ok": False, "error": "pid or name is required"}
    try:
        import psutil
        results = []
        targets = []
        if pid:
            try:
                targets.append(psutil.Process(int(pid)))
            except psutil.NoSuchProcess:
                return {"ok": False, "error": f"no such pid: {pid}"}
        else:
            for p in psutil.process_iter(["pid", "name", "cmdline"]):
                try:
                    pname = (p.info["name"] or "").lower()
                    cmdline = " ".join(p.info["cmdline"] or []).lower()
                    if name in pname or name in cmdline:
                        targets.append(p)
                        if len(targets) >= 10:
                            break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        for p in targets:
            try:
                p.send_signal(sig)
                results.append({"pid": p.pid, "killed": True, "reason": f"SIG{sig_name}"})
            except Exception as e:
                results.append({"pid": p.pid, "killed": False, "reason": f"{type(e).__name__}: {e}"})
        return {"ok": True, "result": results}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def process_resource_usage(args: Dict[str, Any]) -> Dict[str, Any]:
    pid = args.get("pid")
    if pid is None:
        return {"ok": False, "error": "pid is required"}
    try:
        import psutil
        from datetime import datetime
        p = psutil.Process(int(pid))
        with p.oneshot():
            mi = p.memory_info()
            try:
                num_fds = p.num_fds()
            except Exception:
                num_fds = None
            return {"ok": True, "result": {"pid": p.pid, "name": p.name(),
                                           "cpu_percent": p.cpu_percent(interval=0.1),
                                           "mem_mb": round(mi.rss / 1e6, 1),
                                           "num_threads": p.num_threads(),
                                           "num_fds": num_fds, "status": p.status(),
                                           "started_iso": datetime.fromtimestamp(p.create_time()).isoformat(),
                                           "cmdline": " ".join(p.cmdline())}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_log_tail(args: Dict[str, Any]) -> Dict[str, Any]:
    raw = (args.get("file") or "").strip()
    lines = int(args.get("lines", 100))
    if not raw:
        return {"ok": False, "error": "file is required"}
    allowed_roots = ["/var/log", "/tmp",
                     os.path.expanduser("~/Desktop/NeuroLinked-V1.3-SOURCE"),
                     os.path.expanduser("~/.openclaw/logs")]
    try:
        abs_path = os.path.realpath(os.path.expanduser(raw))
    except Exception:
        return {"ok": False, "error": "invalid path"}
    if not any(abs_path == r or abs_path.startswith(r + os.sep) for r in (os.path.realpath(p) for p in allowed_roots)):
        return {"ok": False, "error": f"path outside log sandbox: {allowed_roots}"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"no such file: {abs_path}"}
    try:
        out = subprocess.check_output(["tail", "-n", str(lines), abs_path],
                                      timeout=3, stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
        return {"ok": True, "result": {"path": abs_path, "lines": out.splitlines()}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def system_cron_list(args: Dict[str, Any]) -> Dict[str, Any]:
    user_scope = bool(args.get("user_scope", True))
    entries = []
    def _parse(text, source):
        for line in text.splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            parts = s.split(None, 5)
            if len(parts) >= 6 and (parts[0].startswith("@") or parts[0][0].isdigit() or parts[0][0] == "*"):
                if parts[0].startswith("@"):
                    schedule = parts[0]; command = " ".join(parts[1:])
                else:
                    schedule = " ".join(parts[:5]); command = parts[5]
                entries.append({"schedule": schedule, "command": command, "source": source})
    if user_scope:
        try:
            out = subprocess.check_output(["crontab", "-l"], timeout=3,
                                          stderr=subprocess.DEVNULL).decode("utf-8", errors="replace")
            _parse(out, "user crontab")
        except Exception:
            pass
    try:
        if os.path.isfile("/etc/crontab"):
            with open("/etc/crontab") as f:
                _parse(f.read(), "/etc/crontab")
    except Exception:
        pass
    for d in ("/etc/cron.hourly", "/etc/cron.daily", "/etc/cron.weekly", "/etc/cron.monthly"):
        try:
            if os.path.isdir(d):
                for n in os.listdir(d):
                    entries.append({"schedule": os.path.basename(d).replace("cron.", "@"),
                                    "command": os.path.join(d, n), "source": d})
        except Exception:
            continue
    return {"ok": True, "result": entries}


# ──────────────────────────────────────────────────────────────────────────
# FILE SYSTEM EXTENSIONS
# ──────────────────────────────────────────────────────────────────────────


def file_delete(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    desktop_roots = write_roots + [os.path.join(_home(), "Desktop")]
    abs_path = _resolve_under(raw_path, desktop_roots)
    if abs_path is None:
        return {"ok": False, "error": f"path outside sandbox: {desktop_roots}"}
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such path: {abs_path}"}
    try:
        r = subprocess.run(["gio", "trash", abs_path], capture_output=True, timeout=10)
        if r.returncode != 0:
            return {"ok": False, "error": f"gio trash failed: {r.stderr.decode('utf-8', 'replace').strip()}"}
        return {"ok": True, "result": {"trashed": abs_path}}
    except FileNotFoundError:
        return {"ok": False, "error": "gio not installed"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_move(args: Dict[str, Any]) -> Dict[str, Any]:
    src = (args.get("src") or "").strip()
    dst = (args.get("dst") or "").strip()
    if not src or not dst:
        return {"ok": False, "error": "src and dst are required"}
    write_roots = _file_write_roots()
    if not os.path.isabs(src) and not src.startswith("~"):
        src = os.path.join(write_roots[0], src)
    if not os.path.isabs(dst) and not dst.startswith("~"):
        dst = os.path.join(write_roots[0], dst)
    abs_src = _resolve_under(src, write_roots)
    if abs_src is None:
        return {"ok": False, "error": f"src outside sandbox: {write_roots}"}
    dst_real = os.path.realpath(os.path.expanduser(dst))
    parent = os.path.dirname(dst_real)
    if _resolve_under(parent, write_roots) is None:
        return {"ok": False, "error": f"dst outside sandbox: {write_roots}"}
    if not os.path.exists(abs_src):
        return {"ok": False, "error": f"no such src: {abs_src}"}
    try:
        os.makedirs(parent, exist_ok=True)
        shutil.move(abs_src, dst_real)
        return {"ok": True, "result": {"src": abs_src, "dst": dst_real}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_copy(args: Dict[str, Any]) -> Dict[str, Any]:
    src = (args.get("src") or "").strip()
    dst = (args.get("dst") or "").strip()
    overwrite = bool(args.get("overwrite", False))
    if not src or not dst:
        return {"ok": False, "error": "src and dst are required"}
    write_roots = _file_write_roots(); read_roots = _file_read_roots()
    if not os.path.isabs(src) and not src.startswith("~"):
        src = os.path.join(write_roots[0], src)
    if not os.path.isabs(dst) and not dst.startswith("~"):
        dst = os.path.join(write_roots[0], dst)
    abs_src = _resolve_under(src, read_roots)
    if abs_src is None:
        return {"ok": False, "error": f"src outside read sandbox"}
    dst_real = os.path.realpath(os.path.expanduser(dst))
    parent = os.path.dirname(dst_real)
    if _resolve_under(parent, write_roots) is None:
        return {"ok": False, "error": f"dst outside write sandbox"}
    if not os.path.exists(abs_src):
        return {"ok": False, "error": f"no such src: {abs_src}"}
    if os.path.exists(dst_real) and not overwrite:
        return {"ok": False, "error": f"dst exists (set overwrite=True): {dst_real}"}
    try:
        os.makedirs(parent, exist_ok=True)
        if os.path.isdir(abs_src):
            if os.path.exists(dst_real) and overwrite:
                shutil.rmtree(dst_real)
            shutil.copytree(abs_src, dst_real)
        else:
            shutil.copy2(abs_src, dst_real)
        return {"ok": True, "result": {"src": abs_src, "dst": dst_real,
                                       "is_dir": os.path.isdir(dst_real)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_chmod(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    mode = (args.get("mode") or "").strip()
    if not raw_path or not mode:
        return {"ok": False, "error": "path and mode required"}
    write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, write_roots)
    if abs_path is None:
        return {"ok": False, "error": f"path outside sandbox"}
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such path: {abs_path}"}
    try:
        mode_int = int(mode, 8)
    except ValueError:
        return {"ok": False, "error": f"mode must be octal string"}
    try:
        os.chmod(abs_path, mode_int)
        return {"ok": True, "result": {"path": abs_path, "mode": oct(mode_int)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_size(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such path: {abs_path}"}
    try:
        n = os.path.getsize(abs_path)
        units = ["B", "KB", "MB", "GB", "TB"]
        h = float(n); u = 0
        while h >= 1024 and u < len(units) - 1:
            h /= 1024; u += 1
        human = f"{h:.2f} {units[u]}" if u > 0 else f"{n} B"
        return {"ok": True, "result": {"path": abs_path, "bytes": n, "human": human}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_modified(args: Dict[str, Any]) -> Dict[str, Any]:
    from datetime import datetime, timezone
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.exists(abs_path):
        return {"ok": False, "error": f"no such path: {abs_path}"}
    try:
        mtime = os.path.getmtime(abs_path)
        iso = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()
        return {"ok": True, "result": {"path": abs_path, "mtime_iso": iso,
                                       "age_seconds": time.time() - mtime}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_hash(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    algo = (args.get("algo") or "sha256").lower()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    if algo not in hashlib.algorithms_available:
        return {"ok": False, "error": f"unknown algo: {algo}"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        h = hashlib.new(algo)
        with open(abs_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return {"ok": True, "result": {"path": abs_path, "algo": algo,
                                       "hexdigest": h.hexdigest()}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_search_content(args: Dict[str, Any]) -> Dict[str, Any]:
    query = args.get("query") or ""
    root = (args.get("root") or "").strip()
    regex = bool(args.get("regex", False))
    max_results = int(args.get("max_results", 30))
    if not query or not root:
        return {"ok": False, "error": "query and root required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(root) and not root.startswith("~"):
        root = os.path.join(write_roots[0], root)
    abs_root = _resolve_under(root, read_roots)
    if abs_root is None:
        return {"ok": False, "error": "root outside sandbox"}
    cmd = ["rg", "--json", "-n"]
    if not regex:
        cmd.append("-F")
    cmd += [query, abs_root]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=20)
    except FileNotFoundError:
        return {"ok": False, "error": "ripgrep (rg) not installed"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "ripgrep timed out"}
    results = []
    for line in r.stdout.decode("utf-8", "replace").splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if obj.get("type") == "match":
            data = obj.get("data", {})
            path = (data.get("path") or {}).get("text", "")
            ln = data.get("line_number")
            match_text = (data.get("lines") or {}).get("text", "").rstrip("\n")
            results.append({"path": path, "line_no": ln, "match": match_text})
            if len(results) >= max_results:
                break
    return {"ok": True, "result": {"matches": results, "truncated": len(results) >= max_results}}


def file_search_name(args: Dict[str, Any]) -> Dict[str, Any]:
    pattern = args.get("pattern") or ""
    root = (args.get("root") or "").strip()
    type_ = (args.get("type") or "any").lower()
    if not pattern or not root:
        return {"ok": False, "error": "pattern and root required"}
    if type_ not in ("f", "d", "any"):
        return {"ok": False, "error": "type must be 'f', 'd', or 'any'"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(root) and not root.startswith("~"):
        root = os.path.join(write_roots[0], root)
    abs_root = _resolve_under(root, read_roots)
    if abs_root is None:
        return {"ok": False, "error": "root outside sandbox"}
    cmd = ["find", abs_root, "-name", pattern]
    if type_ in ("f", "d"):
        cmd += ["-type", type_]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=10)
        lines = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
        return {"ok": True, "result": {"matches": lines[:100], "truncated": len(lines) > 100,
                                       "total_found": len(lines)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_diff(args: Dict[str, Any]) -> Dict[str, Any]:
    f1 = (args.get("file1") or "").strip()
    f2 = (args.get("file2") or "").strip()
    if not f1 or not f2:
        return {"ok": False, "error": "file1 and file2 required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(f1) and not f1.startswith("~"):
        f1 = os.path.join(write_roots[0], f1)
    if not os.path.isabs(f2) and not f2.startswith("~"):
        f2 = os.path.join(write_roots[0], f2)
    abs_f1 = _resolve_under(f1, read_roots)
    abs_f2 = _resolve_under(f2, read_roots)
    if abs_f1 is None or abs_f2 is None:
        return {"ok": False, "error": "one or both files outside sandbox"}
    try:
        r = subprocess.run(["diff", "-u", abs_f1, abs_f2], capture_output=True, timeout=10)
        return {"ok": True, "result": {"diff": r.stdout.decode("utf-8", "replace"),
                                       "identical": r.returncode == 0}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_tail(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    lines = int(args.get("lines", 50))
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        r = subprocess.run(["tail", "-n", str(lines), abs_path], capture_output=True, timeout=5)
        return {"ok": True, "result": {"path": abs_path,
                                       "text": r.stdout.decode("utf-8", "replace"),
                                       "lines_requested": lines}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_head(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    lines = int(args.get("lines", 50))
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        r = subprocess.run(["head", "-n", str(lines), abs_path], capture_output=True, timeout=5)
        return {"ok": True, "result": {"path": abs_path,
                                       "text": r.stdout.decode("utf-8", "replace"),
                                       "lines_requested": lines}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_grep(args: Dict[str, Any]) -> Dict[str, Any]:
    import re as _re
    pattern = args.get("pattern") or ""
    raw_path = (args.get("path") or "").strip()
    regex = bool(args.get("regex", False))
    max_matches = int(args.get("max_matches", 50))
    if not pattern or not raw_path:
        return {"ok": False, "error": "pattern and path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        matcher = _re.compile(pattern) if regex else None
        matches = []
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f, 1):
                hit = bool(matcher.search(line)) if regex else (pattern in line)
                if hit:
                    matches.append({"line_no": i, "text": line.rstrip("\n")})
                    if len(matches) >= max_matches:
                        break
        return {"ok": True, "result": {"path": abs_path, "matches": matches,
                                       "truncated": len(matches) >= max_matches}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_wordcount(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path is required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        lines = words = chars = 0
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                lines += 1
                words += len(line.split())
                chars += len(line)
        return {"ok": True, "result": {"path": abs_path, "lines": lines,
                                       "words": words, "chars": chars}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_pdfread(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    pages = (args.get("pages") or "all").strip()
    if not raw_path:
        return {"ok": False, "error": "path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    cmd = ["pdftotext", "-layout"]
    if pages and pages != "all":
        if "-" in pages:
            try:
                first, last = pages.split("-", 1)
                cmd += ["-f", str(int(first)), "-l", str(int(last))]
            except ValueError:
                return {"ok": False, "error": f"invalid pages range: {pages}"}
        else:
            try:
                p = int(pages); cmd += ["-f", str(p), "-l", str(p)]
            except ValueError:
                return {"ok": False, "error": f"invalid pages: {pages}"}
    cmd += [abs_path, "-"]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=30)
        if r.returncode != 0:
            return {"ok": False, "error": f"pdftotext failed: {r.stderr.decode('utf-8', 'replace').strip()}"}
        text = r.stdout.decode("utf-8", "replace")
        return {"ok": True, "result": {"path": abs_path, "text": text[:50000],
                                       "truncated": len(text) > 50000, "chars": len(text)}}
    except FileNotFoundError:
        return {"ok": False, "error": "pdftotext not installed (apt install poppler-utils)"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_csv_read(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    max_rows = int(args.get("max_rows", 100))
    header = bool(args.get("header", True))
    if not raw_path:
        return {"ok": False, "error": "path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        rows = []; fieldnames = []
        with open(abs_path, "r", encoding="utf-8", errors="replace", newline="") as f:
            if header:
                reader = csv.DictReader(f)
                for i, row in enumerate(reader):
                    if i >= max_rows: break
                    rows.append(dict(row))
                fieldnames = reader.fieldnames or []
            else:
                reader = csv.reader(f)
                for i, row in enumerate(reader):
                    if i >= max_rows: break
                    rows.append(row)
        return {"ok": True, "result": {"path": abs_path, "rows": rows,
                                       "fieldnames": fieldnames,
                                       "truncated": len(rows) >= max_rows}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_json_query(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    query = args.get("query") or "."
    if not raw_path:
        return {"ok": False, "error": "path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        r = subprocess.run(["jq", query, abs_path], capture_output=True, timeout=10)
        if r.returncode != 0:
            return {"ok": False, "error": f"jq failed: {r.stderr.decode('utf-8', 'replace').strip()}"}
        text = r.stdout.decode("utf-8", "replace")
        return {"ok": True, "result": {"path": abs_path, "query": query,
                                       "output": text[:200000],
                                       "truncated": len(text) > 200000}}
    except FileNotFoundError:
        return {"ok": False, "error": "jq not installed (apt install jq)"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def file_yaml_read(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    try:
        import yaml
    except ImportError:
        return {"ok": False, "error": "PyYAML not installed"}
    try:
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            data = yaml.safe_load(f)
        return {"ok": True, "result": {"path": abs_path, "data": data}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# SHELL EXEC EXTENSIONS
# ──────────────────────────────────────────────────────────────────────────


def shell_exec_in_dir(args: Dict[str, Any]) -> Dict[str, Any]:
    cwd = (args.get("cwd") or "").strip()
    command = args.get("command") or ""
    if not cwd or not command:
        return {"ok": False, "error": "cwd and command required"}
    cwd_real = os.path.realpath(os.path.expanduser(cwd))
    if not os.path.isdir(cwd_real):
        return {"ok": False, "error": f"cwd not a directory: {cwd_real}"}
    try:
        r = subprocess.run(command, shell=True, cwd=cwd_real,
                           capture_output=True, timeout=30)
        return {"ok": True, "result": {"cwd": cwd_real, "command": command,
                                       "returncode": r.returncode,
                                       "stdout": r.stdout.decode("utf-8", "replace")[:50000],
                                       "stderr": r.stderr.decode("utf-8", "replace")[:10000]}}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "command timed out after 30s"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def shell_exec_streaming(args: Dict[str, Any]) -> Dict[str, Any]:
    from collections import deque
    command = args.get("command") or ""
    max_lines = int(args.get("max_lines", 100))
    if not command:
        return {"ok": False, "error": "command required"}
    if max_lines <= 0 or max_lines > 10000:
        return {"ok": False, "error": "max_lines must be 1..10000"}
    try:
        p = subprocess.Popen(command, shell=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, bufsize=1)
        tail = deque(maxlen=max_lines)
        start = time.monotonic()
        try:
            for line in p.stdout:
                tail.append(line.rstrip("\n"))
                if time.monotonic() - start > 60:
                    p.kill()
                    return {"ok": False, "error": "streaming exceeded 60s"}
            p.wait(timeout=5)
        finally:
            try: p.stdout.close()
            except Exception: pass
        return {"ok": True, "result": {"command": command, "returncode": p.returncode,
                                       "last_lines": list(tail), "line_count": len(tail)}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def shell_exec_background(args: Dict[str, Any]) -> Dict[str, Any]:
    command = args.get("command") or ""
    if not command:
        return {"ok": False, "error": "command required"}
    try:
        p = subprocess.Popen(command, shell=True, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, start_new_session=True)
        return {"ok": True, "result": {"pid": p.pid, "command": command}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def shell_exec_kill(args: Dict[str, Any]) -> Dict[str, Any]:
    import signal
    pid = args.get("pid")
    if pid is None:
        return {"ok": False, "error": "pid required"}
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return {"ok": False, "error": "pid must be integer"}
    try:
        os.kill(pid_int, 0)
    except ProcessLookupError:
        return {"ok": False, "error": f"no such process: {pid_int}"}
    except PermissionError:
        return {"ok": False, "error": f"no permission for pid {pid_int}"}
    try:
        os.kill(pid_int, signal.SIGTERM)
        return {"ok": True, "result": {"pid": pid_int, "signal": "SIGTERM"}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def shell_exec_status(args: Dict[str, Any]) -> Dict[str, Any]:
    pid = args.get("pid")
    if pid is None:
        return {"ok": False, "error": "pid required"}
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return {"ok": False, "error": "pid must be integer"}
    try:
        import psutil
    except ImportError:
        return {"ok": False, "error": "psutil not installed"}
    try:
        proc = psutil.Process(pid_int)
        with proc.oneshot():
            return {"ok": True, "result": {"pid": pid_int, "name": proc.name(),
                                           "status": proc.status(),
                                           "cpu_percent": proc.cpu_percent(interval=0.1),
                                           "rss_bytes": proc.memory_info().rss,
                                           "cmdline": proc.cmdline()}}
    except psutil.NoSuchProcess:
        return {"ok": False, "error": f"no such process: {pid_int}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# DOTENV / GIT
# ──────────────────────────────────────────────────────────────────────────


def dotenv_read(args: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = (args.get("path") or "").strip()
    if not raw_path:
        return {"ok": False, "error": "path required"}
    read_roots = _file_read_roots(); write_roots = _file_write_roots()
    if not os.path.isabs(raw_path) and not raw_path.startswith("~"):
        raw_path = os.path.join(write_roots[0], raw_path)
    abs_path = _resolve_under(raw_path, read_roots)
    if abs_path is None:
        return {"ok": False, "error": "path outside sandbox"}
    if not os.path.isfile(abs_path):
        return {"ok": False, "error": f"not a file: {abs_path}"}
    sensitive = ("key", "secret", "token", "password")
    try:
        pairs = []
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#") or "=" not in s:
                    continue
                k, _, v = s.partition("=")
                key = k.strip(); val = v.strip().strip('"').strip("'")
                low = key.lower()
                if any(tok in low for tok in sensitive):
                    pairs.append({"key": key, "value_or_redacted": "<REDACTED>", "redacted": True})
                else:
                    pairs.append({"key": key, "value_or_redacted": val, "redacted": False})
        return {"ok": True, "result": {"path": abs_path, "pairs": pairs}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def git_status(args: Dict[str, Any]) -> Dict[str, Any]:
    repo = (args.get("repo") or "").strip()
    if not repo:
        return {"ok": False, "error": "repo required"}
    repo_real = os.path.realpath(os.path.expanduser(repo))
    if not os.path.isdir(repo_real):
        return {"ok": False, "error": f"not a directory: {repo_real}"}
    if not os.path.isdir(os.path.join(repo_real, ".git")):
        return {"ok": False, "error": f"not a git repo: {repo_real}"}
    try:
        r1 = subprocess.run(["git", "-C", repo_real, "status", "--porcelain"],
                            capture_output=True, timeout=10)
        if r1.returncode != 0:
            return {"ok": False, "error": f"git status failed"}
        files = [{"status_code": line[:2], "file": line[3:]}
                 for line in r1.stdout.decode("utf-8", "replace").splitlines() if len(line) >= 3]
        r2 = subprocess.run(["git", "-C", repo_real, "branch", "--show-current"],
                            capture_output=True, timeout=5)
        branch = r2.stdout.decode("utf-8", "replace").strip() if r2.returncode == 0 else ""
        return {"ok": True, "result": {"repo": repo_real, "branch": branch,
                                       "files": files, "clean": len(files) == 0}}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


# ──────────────────────────────────────────────────────────────────────────
# TOOL TABLE — exported for actuator.py
# ──────────────────────────────────────────────────────────────────────────

EXTRA_TOOLS: Dict[str, Any] = {
    # Window
    "window.resize":             window_resize,
    "window.minimize":           window_minimize,
    "window.maximize":           window_maximize,
    "window.unmaximize":         window_unmaximize,
    "window.pin_always_on_top":  window_pin_always_on_top,
    "window.position":           window_position,
    "window.snap":               window_snap,
    "workspace.switch":          workspace_switch,
    "workspace.move_window":     workspace_move_window,
    "desktop.show":              desktop_show,
    # Mouse
    "mouse.double_click":        mouse_double_click,
    "mouse.triple_click":        mouse_triple_click,
    "mouse.jiggle":              mouse_jiggle,
    "mouse.position":            mouse_position,
    "mouse.screen_to_monitor":   mouse_screen_to_monitor,
    # Keyboard
    "keyboard.paste_via_clipboard": keyboard_paste_via_clipboard,
    "keyboard.press":            keyboard_press,
    "keyboard.down":             keyboard_down,
    "keyboard.up":               keyboard_up,
    # Clipboard
    "clipboard.clear":           clipboard_clear,
    "clipboard.image_copy":      clipboard_image_copy,
    # Spotify
    "spotify.play_pause":        spotify_play_pause,
    "spotify.next":              spotify_next,
    "spotify.previous":          spotify_previous,
    "spotify.what_is_playing":   spotify_what_is_playing,
    "spotify.volume":            spotify_volume,
    # Apps
    "vscode.open_file":          vscode_open_file,
    "vscode.open_folder":        vscode_open_folder,
    "terminal.spawn":            terminal_spawn,
    "files.open":                files_open,
    "screen.lock":               screen_lock,
    # System
    "system.resource_summary":   system_resource_summary,
    "system.temperature":        system_temperature,
    "system.fan_speed":          system_fan_speed,
    "system.battery":            system_battery,
    "system.uptime":             system_uptime,
    "system.users_logged_in":    system_users_logged_in,
    "system.listening_ports":    system_listening_ports,
    "system.disk_io":            system_disk_io,
    "system.network_io":         system_network_io,
    "system.gpu_state":          system_gpu_state,
    "system.diskspace_by_dir":   system_diskspace_by_dir,
    "system.largest_files":      system_largest_files,
    "system.package_list":       system_package_list,
    "system.service_status":     system_service_status,
    "system.service_start":      system_service_start,
    "system.service_stop":       system_service_stop,
    "system.service_restart":    system_service_restart,
    "system.service_logs":       system_service_logs,
    "system.log_tail":           system_log_tail,
    "system.cron_list":          system_cron_list,
    # Process
    "process.list":              process_list,
    "process.find_by_name":      process_find_by_name,
    "process.kill":              process_kill,
    "process.resource_usage":    process_resource_usage,
    # File
    "file.delete":               file_delete,
    "file.move":                 file_move,
    "file.copy":                 file_copy,
    "file.chmod":                file_chmod,
    "file.size":                 file_size,
    "file.modified":             file_modified,
    "file.hash":                 file_hash,
    "file.search_content":       file_search_content,
    "file.search_name":          file_search_name,
    "file.diff":                 file_diff,
    "file.tail":                 file_tail,
    "file.head":                 file_head,
    "file.grep":                 file_grep,
    "file.wordcount":            file_wordcount,
    "file.pdfread":              file_pdfread,
    "file.csv_read":             file_csv_read,
    "file.json_query":           file_json_query,
    "file.yaml_read":            file_yaml_read,
    # Shell
    "shell.exec_in_dir":         shell_exec_in_dir,
    "shell.exec_streaming":      shell_exec_streaming,
    "shell.exec_background":     shell_exec_background,
    "shell.exec_kill":           shell_exec_kill,
    "shell.exec_status":         shell_exec_status,
    # Dotenv / git
    "dotenv.read":               dotenv_read,
    "git.status":                git_status,
}
