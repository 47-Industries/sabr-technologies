"""
Platform compatibility layer — abstracts OS-specific desktop control.

Detects the platform at import time and provides unified functions for:
  - Mouse control (click, move, drag, scroll)
  - Keyboard control (type, hotkey)
  - Window management (list, focus, move, minimize, maximize)
  - Clipboard (copy, paste)
  - Monitor detection (list monitors, geometry)
  - Notifications (desktop toast)
  - Screenshot (already cross-platform via mss)

Backends:
  Linux X11:   xdotool + wmctrl (fastest, current Leon default)
  Linux Wayland: ydotool + wlrctl (fallback)
  macOS:       cliclick + AppleScript + pyperclip
  Windows:     pyautogui + pygetwindow + pyperclip

Usage:
  from platform_compat import platform as P
  P.mouse_click(x, y)
  P.keyboard_type("hello")
  P.window_list()
  P.clipboard_copy("text")
"""

import os
import platform as _platform
import shutil
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple

SYSTEM = _platform.system()  # "Linux", "Darwin", "Windows"

# Detect Wayland vs X11 on Linux
_WAYLAND = False
if SYSTEM == "Linux":
    _WAYLAND = bool(os.environ.get("WAYLAND_DISPLAY"))


def _run(cmd: list, timeout: int = 10, **kw) -> subprocess.CompletedProcess:
    """Run a command, return CompletedProcess."""
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)


def _has(binary: str) -> bool:
    return shutil.which(binary) is not None


# ═══════════════════════════════════════════════════════════════════════
# LINUX (X11) — xdotool + wmctrl
# ═══════════════════════════════════════════════════════════════════════

class LinuxX11:
    name = "linux-x11"

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        _run(["xdotool", "mousemove", str(x), str(y)])
        _run(["xdotool", "click", str(button)])

    @staticmethod
    def mouse_move(x: int, y: int):
        _run(["xdotool", "mousemove", str(x), str(y)])

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        _run(["xdotool", "mousemove", str(x), str(y)])
        btn = "5" if direction == "down" else "4"
        for _ in range(abs(clicks)):
            _run(["xdotool", "click", btn])

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        _run(["xdotool", "mousemove", str(x1), str(y1)])
        _run(["xdotool", "mousedown", str(button)])
        _run(["xdotool", "mousemove", "--delay", "50", str(x2), str(y2)])
        _run(["xdotool", "mouseup", str(button)])

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        r = _run(["xdotool", "getmouselocation", "--shell"])
        vals = {}
        for line in r.stdout.strip().split("\n"):
            if "=" in line:
                k, v = line.split("=", 1)
                vals[k] = int(v)
        return vals.get("X", 0), vals.get("Y", 0)

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        _run(["xdotool", "type", "--delay", str(delay_ms), "--clearmodifiers", text])

    @staticmethod
    def keyboard_hotkey(keys: str):
        _run(["xdotool", "key", "--clearmodifiers", keys])

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        r = _run(["wmctrl", "-l"])
        windows = []
        for line in r.stdout.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split(None, 3)
            if len(parts) >= 4:
                windows.append({
                    "id": parts[0],
                    "desktop": parts[1],
                    "host": parts[2],
                    "title": parts[3],
                })
        return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        r = _run(["wmctrl", "-a", title])
        return r.returncode == 0

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close — sends WM_DELETE, same as clicking [X]."""
        r = _run(["wmctrl", "-c", title])
        return r.returncode == 0

    @staticmethod
    def window_minimize(title: str) -> bool:
        r = _run(["xdotool", "search", "--name", title, "windowminimize"])
        return r.returncode == 0

    @staticmethod
    def window_maximize(title: str) -> bool:
        r = _run(["wmctrl", "-r", title, "-b", "add,maximized_vert,maximized_horz"])
        return r.returncode == 0

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            p = subprocess.Popen(["xsel", "-b", "-i"], stdin=subprocess.PIPE)
            p.communicate(text.encode(), timeout=5)
            return p.returncode == 0
        except Exception:
            try:
                p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
                p.communicate(text.encode(), timeout=5)
                return p.returncode == 0
            except Exception:
                return False

    @staticmethod
    def clipboard_paste() -> str:
        try:
            r = _run(["xclip", "-selection", "clipboard", "-o"])
            if r.returncode == 0:
                return r.stdout
        except Exception:
            pass
        try:
            r = _run(["xsel", "-b", "-o"])
            return r.stdout
        except Exception:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        r = _run(["xrandr", "--listmonitors"])
        monitors = []
        for line in r.stdout.strip().split("\n")[1:]:  # skip header
            parts = line.strip().split()
            if len(parts) >= 3:
                geo = parts[2]  # e.g. "1920/509x1080/286+0+0"
                monitors.append({"name": parts[-1], "geometry": geo})
        return monitors

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        _run(["notify-send", "-t", str(timeout_ms), title, body])


# ═══════════════════════════════════════════════════════════════════════
# macOS — cliclick + AppleScript + pyperclip
# ═══════════════════════════════════════════════════════════════════════

class MacOS:
    name = "macos"

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        if _has("cliclick"):
            _run(["cliclick", f"c:{x},{y}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.click(x, y, button="left" if button == 1 else "right")

    @staticmethod
    def mouse_move(x: int, y: int):
        if _has("cliclick"):
            _run(["cliclick", f"m:{x},{y}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.moveTo(x, y)

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        _ensure_pyautogui_global()
        import pyautogui
        pyautogui.moveTo(x, y)
        pyautogui.scroll(-clicks if direction == "down" else clicks)

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        _ensure_pyautogui_global()
        import pyautogui
        pyautogui.moveTo(x1, y1)
        pyautogui.drag(x2 - x1, y2 - y1, duration=0.3)

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        if _has("cliclick"):
            r = _run(["cliclick", "p:."])
            parts = r.stdout.strip().split(",")
            if len(parts) == 2:
                return int(parts[0]), int(parts[1])
        _ensure_pyautogui_global()
        import pyautogui
        pos = pyautogui.position()
        return pos.x, pos.y

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        if _has("cliclick"):
            _run(["cliclick", f"t:{text}"])
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.typewrite(text, interval=delay_ms / 1000)

    @staticmethod
    def keyboard_hotkey(keys: str):
        # Convert "cmd+c" / "ctrl+shift+t" -> cliclick key-down/up sequence.
        # cliclick's kp: only accepts single named keys, NOT combos — so we
        # hold modifiers with kd:, tap the final key, then release with ku:.
        if _has("cliclick"):
            parts = [p.strip().lower() for p in keys.split("+") if p.strip()]
            mod_map = {"cmd": "cmd", "command": "cmd", "win": "cmd", "meta": "cmd",
                       "ctrl": "ctrl", "control": "ctrl", "alt": "alt",
                       "opt": "alt", "option": "alt", "shift": "shift", "fn": "fn"}
            named = {"return", "enter", "esc", "escape", "space", "tab", "delete",
                     "backspace", "up", "down", "left", "right", "home", "end",
                     "pageup", "pagedown", "fwd-delete"}
            mods = [mod_map[p] for p in parts if p in mod_map]
            keys_only = [p for p in parts if p not in mod_map]
            cmds = []
            if mods:
                cmds.append("kd:" + ",".join(mods))
            for k in keys_only:
                cmds.append(f"kp:{k}" if k in named else f"t:{k}")
            if mods:
                cmds.append("ku:" + ",".join(mods))
            if cmds:
                _run(["cliclick"] + cmds)
        else:
            _ensure_pyautogui_global()
            import pyautogui
            pyautogui.hotkey(*keys.split("+"))

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        script = '''
        tell application "System Events"
            set windowList to {}
            repeat with proc in (every process whose visible is true)
                repeat with win in (every window of proc)
                    set end of windowList to (name of proc) & "|" & (name of win)
                end repeat
            end repeat
            return windowList
        end tell
        '''
        r = _run(["osascript", "-e", script])
        windows = []
        for item in r.stdout.strip().split(", "):
            if "|" in item:
                app, title = item.split("|", 1)
                windows.append({"app": app, "title": title})
        return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        script = f'''
        tell application "System Events"
            set frontApp to first process whose visible is true and (name of every window contains "{title}")
            set frontmost of frontApp to true
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close — clicks the real close button so the app can prompt
        to save. Deliberately NOT `quit`, which can discard unsaved work."""
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXCloseButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def window_minimize(title: str) -> bool:
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXMinimizeButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def window_maximize(title: str) -> bool:
        script = f'''
        tell application "System Events"
            click (first button of (first window of (first process whose name contains "{title}")) whose subrole is "AXZoomButton")
        end tell
        '''
        r = _run(["osascript", "-e", script])
        return r.returncode == 0

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            p.communicate(text.encode(), timeout=5)
            return p.returncode == 0
        except Exception:
            return False

    @staticmethod
    def clipboard_paste() -> str:
        try:
            r = _run(["pbpaste"])
            return r.stdout
        except Exception:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        script = 'tell application "Finder" to get bounds of window of desktop'
        r = _run(["osascript", "-e", script])
        # Simplified — just return primary display
        try:
            import AppKit
            screens = AppKit.NSScreen.screens()
            return [{"name": f"display-{i}", "frame": str(s.frame())} for i, s in enumerate(screens)]
        except ImportError:
            return [{"name": "primary", "geometry": r.stdout.strip()}]

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        script = f'display notification "{body}" with title "{title}"'
        _run(["osascript", "-e", script])

    @staticmethod
    def permissions_status() -> Dict[str, Any]:
        """Probe macOS TCC so Leon KNOWS when he's being silently blocked
        instead of clicking into the void. Returns booleans + a tool check."""
        status = {"accessibility": None, "screen_recording": None,
                  "input_tool": bool(_has("cliclick")), "notes": []}
        # Accessibility: System Events UI scripting fails without it.
        try:
            r = _run(["osascript", "-e",
                      'tell application "System Events" to return name of first process'],
                     timeout=5)
            status["accessibility"] = (r.returncode == 0)
            if r.returncode != 0:
                status["notes"].append("Accessibility OFF — mouse/keyboard/windows won't work")
        except Exception:
            status["accessibility"] = False
        # Screen Recording: CGDisplayCreateImage returns None when denied.
        try:
            import Quartz  # type: ignore
            img = Quartz.CGDisplayCreateImage(Quartz.CGMainDisplayID())
            status["screen_recording"] = img is not None
            if img is None:
                status["notes"].append("Screen Recording OFF — Leon sees a black screen")
        except Exception:
            status["screen_recording"] = None  # can't determine without pyobjc-Quartz
        if not status["input_tool"]:
            status["notes"].append("cliclick missing — clicks fall back to pyautogui")
        return status


# ═══════════════════════════════════════════════════════════════════════
# WINDOWS — pyautogui + pygetwindow + pyperclip
# ═══════════════════════════════════════════════════════════════════════

class Windows:
    name = "windows"

    @staticmethod
    def _pag():
        _ensure_pyautogui_global()
        import pyautogui
        return pyautogui

    @staticmethod
    def mouse_click(x: int, y: int, button: int = 1):
        Windows._pag().click(x, y, button="left" if button == 1 else "right")

    @staticmethod
    def mouse_move(x: int, y: int):
        Windows._pag().moveTo(x, y)

    @staticmethod
    def mouse_scroll(x: int, y: int, clicks: int = 3, direction: str = "down"):
        Windows._pag().moveTo(x, y)
        Windows._pag().scroll(-clicks if direction == "down" else clicks)

    @staticmethod
    def mouse_drag(x1: int, y1: int, x2: int, y2: int, button: int = 1):
        Windows._pag().moveTo(x1, y1)
        Windows._pag().drag(x2 - x1, y2 - y1, duration=0.3)

    @staticmethod
    def mouse_get_pos() -> Tuple[int, int]:
        pos = Windows._pag().position()
        return pos.x, pos.y

    @staticmethod
    def keyboard_type(text: str, delay_ms: int = 20):
        Windows._pag().typewrite(text, interval=delay_ms / 1000)

    @staticmethod
    def keyboard_hotkey(keys: str):
        Windows._pag().hotkey(*keys.split("+"))

    @staticmethod
    def window_list() -> List[Dict[str, str]]:
        try:
            import pygetwindow as gw
            return [{"title": w.title, "visible": w.visible} for w in gw.getAllWindows() if w.title]
        except ImportError:
            # Fallback: tasklist
            r = _run(["tasklist", "/v", "/fo", "csv"])
            windows = []
            for line in r.stdout.strip().split("\n")[1:]:
                parts = line.split('","')
                if len(parts) >= 9:
                    title = parts[8].strip('"')
                    if title and title != "N/A":
                        windows.append({"title": title, "process": parts[0].strip('"')})
            return windows

    @staticmethod
    def window_focus(title: str) -> bool:
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].activate()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def window_close(title: str) -> bool:
        """Polite close via pygetwindow's close() — posts WM_CLOSE, so the
        app still gets to show its 'save changes?' prompt."""
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].close()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def window_minimize(title: str) -> bool:
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].minimize()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def window_maximize(title: str) -> bool:
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(title)
            if wins:
                wins[0].maximize()
                return True
        except Exception:
            pass
        return False

    @staticmethod
    def clipboard_copy(text: str) -> bool:
        try:
            import pyperclip
            pyperclip.copy(text)
            return True
        except ImportError:
            Windows._pag().hotkey("ctrl", "c")
            return True

    @staticmethod
    def clipboard_paste() -> str:
        try:
            import pyperclip
            return pyperclip.paste()
        except ImportError:
            return ""

    @staticmethod
    def list_monitors() -> List[Dict]:
        try:
            from screeninfo import get_monitors
            return [{"name": m.name or f"monitor-{i}", "x": m.x, "y": m.y,
                     "width": m.width, "height": m.height}
                    for i, m in enumerate(get_monitors())]
        except ImportError:
            return [{"name": "primary", "width": 1920, "height": 1080}]

    @staticmethod
    def notify(title: str, body: str = "", timeout_ms: int = 5000):
        try:
            from plyer import notification
            notification.notify(title=title, message=body, timeout=timeout_ms // 1000)
        except ImportError:
            # PowerShell fallback
            ps = f'[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms"); ' \
                 f'$n=New-Object System.Windows.Forms.NotifyIcon; ' \
                 f'$n.Icon=[System.Drawing.SystemIcons]::Information; ' \
                 f'$n.Visible=$true; ' \
                 f'$n.ShowBalloonTip({timeout_ms},"{title}","{body}",[System.Windows.Forms.ToolTipIcon]::Info)'
            _run(["powershell", "-Command", ps])


# ═══════════════════════════════════════════════════════════════════════
# Helper
# ═══════════════════════════════════════════════════════════════════════

def _ensure_pyautogui_global():
    try:
        import pyautogui
        pyautogui.FAILSAFE = False
        pyautogui.PAUSE = 0.05
    except ImportError:
        raise RuntimeError("pyautogui not installed. Run: pip install pyautogui")


# ═══════════════════════════════════════════════════════════════════════
# Auto-select platform
# ═══════════════════════════════════════════════════════════════════════

def _detect() -> Any:
    if SYSTEM == "Darwin":
        return MacOS
    elif SYSTEM == "Windows":
        return Windows
    else:
        # Linux — prefer X11 if available
        if _has("xdotool") and not _WAYLAND:
            return LinuxX11
        # Could add LinuxWayland class here later (ydotool + wlrctl)
        return LinuxX11  # best effort


# The singleton — import this
platform = _detect()
# Non-mac platforms don't gate input behind permissions — give a safe stub
# so callers can always ask platform.permissions_status().
if not hasattr(platform, "permissions_status"):
    platform.permissions_status = staticmethod(
        lambda: {"accessibility": True, "screen_recording": True, "notes": []})
print(f"[PLATFORM] Detected: {platform.name} (system={SYSTEM}, wayland={_WAYLAND})")
