"""
Leon's cursor actions — uses the SAME system pointer as Dean, but saves/restores
Dean's position and clamps all Leon actions to the right monitor.

Previous approach (xinput create-master) created a separate X11 master pointer.
That broke KDE/Plasma: when Leon's pointer clicked a window, X11 reassigned the
window's client pointer to Leon's master, which had no physical keyboard slave —
so Dean's typing vanished. NEVER use xinput create-master for this.

Current approach:
  1. Save Dean's cursor position
  2. Move cursor to target on right monitor (HDMI-1, x=3840-5760)
  3. Perform the action (click, type, scroll)
  4. Restore Dean's cursor to where it was

A threading lock prevents Leon and Dean from racing on the pointer during actions.
Actions are fast (<100ms typically) so the borrow is imperceptible.

Usage:
    from leon_cursor import leon_mouse_move, leon_click, leon_type
    leon_mouse_move(4000, 500)
    leon_click(4000, 500)
    leon_type("hello")
"""

from __future__ import annotations

import os
import subprocess
import threading
import time

_DISPLAY = os.environ.get("DISPLAY", ":0")
_lock = threading.Lock()


def _probe_monitor_geometry() -> tuple[int, int, int]:
    """Measure the SI's own monitor instead of assuming Dean's desk.

    These were hardcoded to 3840/5760/1080 — the exact geometry of one
    specific three-screen setup. On any other machine that describes a
    region that doesn't exist, so every click got shoved off-screen.
    Now: rightmost monitor when there are several, the only monitor when
    there's one. LEON_SCREEN_X / LEON_SCREEN_W / LEON_SCREEN_H override.
    """
    import re
    try:
        env = dict(os.environ, DISPLAY=_DISPLAY)
        out = subprocess.run(["xrandr", "--listmonitors"], capture_output=True,
                             text=True, timeout=3, env=env).stdout
        mons = []
        for line in out.splitlines()[1:]:
            m = re.search(r'(\d+)/\d+x(\d+)/\d+\+(\d+)\+(\d+)', line)
            if m:
                w, h, x, y = (int(g) for g in m.groups())
                mons.append((x, w, h))
        if mons:
            x, w, h = max(mons, key=lambda t: t[0])
            return x, x + w, h
    except Exception:
        pass
    return 0, 1920, 1080


def _geo(idx: int, envvar: str) -> int:
    v = os.environ.get(envvar)
    if v and v.strip().lstrip("-").isdigit():
        return int(v.strip())
    return _probe_monitor_geometry()[idx]


_RIGHT_MONITOR_X_START = _geo(0, "LEON_SCREEN_X")
_RIGHT_MONITOR_X_END = _geo(1, "LEON_SCREEN_W")
_MONITOR_Y_MAX = _geo(2, "LEON_SCREEN_H")


def _run(cmd: list[str], timeout: int = 5) -> str:
    """Run a command with DISPLAY set."""
    env = dict(os.environ, DISPLAY=_DISPLAY)
    # Was hardcoded to /home/deansabr/.Xauthority — one specific user's home.
    # Use whoever is actually running this SI.
    if not env.get("XAUTHORITY"):
        for cand in (os.path.expanduser("~/.Xauthority"),
                     "/home/deansabr/.Xauthority"):
            if os.path.exists(cand):
                env["XAUTHORITY"] = cand
                break
    result = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout, env=env)
    return result.stdout.strip()


def _get_cursor_pos() -> tuple[int, int]:
    """Get current cursor position."""
    try:
        out = _run(["xdotool", "getmouselocation", "--shell"])
        pos = {}
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                pos[k.strip()] = v.strip()
        return int(pos.get("X", 0)), int(pos.get("Y", 0))
    except Exception:
        return 0, 0


def _clamp_to_right_monitor(x: int, y: int) -> tuple[int, int]:
    """Ensure coordinates are on the right monitor."""
    x = max(_RIGHT_MONITOR_X_START, min(_RIGHT_MONITOR_X_END - 1, x))
    y = max(0, min(_MONITOR_Y_MAX - 1, y))
    return x, y


def ensure_leon_cursor() -> int | None:
    """No-op for backwards compatibility. Returns None (no separate pointer).

    The old xinput create-master approach is permanently retired.
    All leon_* functions now borrow the system pointer with save/restore.
    """
    return None


def leon_mouse_move(x: int, y: int) -> bool:
    """Move cursor to (x, y) on the right monitor. Saves/restores Dean's position."""
    x, y = _clamp_to_right_monitor(x, y)
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            # Brief pause so the move registers, then restore
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            # Always try to restore even on error
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def leon_click(x: int, y: int, button: int = 1) -> bool:
    """Click at (x, y) on the right monitor. Saves/restores Dean's position."""
    x, y = _clamp_to_right_monitor(x, y)
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            _run(["xdotool", "click", str(button)])
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def leon_type(text: str) -> bool:
    """Type text at current focus. Does NOT move the cursor — types into
    whatever window Leon has focused on the right monitor."""
    with _lock:
        try:
            _run(["xdotool", "type", "--clearmodifiers", "--delay", "20", text])
            return True
        except Exception:
            return False


def leon_key(keys: str) -> bool:
    """Press key combo (e.g. 'Return', 'ctrl+a'). Doesn't move cursor."""
    with _lock:
        try:
            _run(["xdotool", "key", "--clearmodifiers", keys])
            return True
        except Exception:
            return False


def leon_scroll(x: int, y: int, units: int = 3) -> bool:
    """Scroll at (x, y) on the right monitor. Saves/restores Dean's position.
    Positive units = scroll down, negative = scroll up."""
    x, y = _clamp_to_right_monitor(x, y)
    button = "5" if units > 0 else "4"
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            for _ in range(abs(units)):
                _run(["xdotool", "click", button])
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def cleanup():
    """Clean up any leftover Leon master pointers from the old approach."""
    try:
        out = _run(["xinput", "list"])
        for line in out.splitlines():
            if "Leon pointer" in line and "master pointer" in line:
                for part in line.split():
                    if part.startswith("id="):
                        pid = int(part[3:])
                        _run(["xinput", "remove-master", str(pid)])
                        print(f"[LEON_CURSOR] Cleaned up old master pointer id={pid}")
    except Exception:
        pass


def is_on_right_monitor(x: int) -> bool:
    """Check if x coordinate is on Leon's monitor."""
    return _RIGHT_MONITOR_X_START <= x < _RIGHT_MONITOR_X_END
