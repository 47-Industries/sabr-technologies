"""
Leon's cursor actions — uses the SAME system pointer as Dean, but saves/restores
Dean's position and clamps all Leon actions to the right monitor.

Previous approach (xinput create-master) created a separate X11 master pointer.
That broke KDE/Plasma: when Leon's pointer clicked a window, X11 reassigned the
window's client pointer to Leon's master, which had no physical keyboard slave —
so Dean's typing vanished. NEVER use xinput create-master for this.

Current approach:
  1. Save Dean's cursor position
  2. Move cursor to target on right monitor (HDMI-1, x=3840-5760)
  3. Perform the action (click, type, scroll)
  4. Restore Dean's cursor to where it was

A threading lock prevents Leon and Dean from racing on the pointer during actions.
Actions are fast (<100ms typically) so the borrow is imperceptible.

Usage:
    from leon_cursor import leon_mouse_move, leon_click, leon_type
    leon_mouse_move(4000, 500)
    leon_click(4000, 500)
    leon_type("hello")
"""

from __future__ import annotations

import os
import platform as _platform
import subprocess
import sys
import threading
import time

_DISPLAY = os.environ.get("DISPLAY", ":0")
_lock = threading.Lock()


# ── Cross-platform backend ────────────────────────────────────────────────
# Same shape as actuator.py's _pc()/_pc_call(): Linux keeps the hand-written
# xdotool path below byte-for-byte, everything non-Linux dispatches into
# platform_compat instead of shelling out to a binary that isn't there.
_pc_backend = None
_pc_error = None


def _pc():
    """Lazily resolve the platform backend. Returns None if unavailable."""
    global _pc_backend, _pc_error
    if _pc_backend is None and _pc_error is None:
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            import platform_compat  # type: ignore
            _pc_backend = platform_compat._detect()
        except Exception as e:
            _pc_error = f"platform_compat unavailable: {type(e).__name__}: {e}"
    return _pc_backend


def _is_linux() -> bool:
    """Read live so tests can monkeypatch platform.system()."""
    return _platform.system() == "Linux"


def _pc_try(method: str, *a, **kw) -> bool:
    """Call a backend method; True on success, False on any failure."""
    be = _pc()
    if be is None:
        return False
    fn = getattr(be, method, None)
    if fn is None:
        return False
    try:
        fn(*a, **kw)
        return True
    except Exception:
        return False


def _probe_monitor_geometry() -> tuple[int, int, int]:
    """Measure the SI's own monitor instead of assuming Dean's desk.

    These were hardcoded to 3840/5760/1080 — the exact geometry of one
    specific three-screen setup. On any other machine that describes a
    region that doesn't exist, so every click got shoved off-screen.
    Now: rightmost monitor when there are several, the only monitor when
    there's one. LEON_SCREEN_X / LEON_SCREEN_W / LEON_SCREEN_H override.
    """
    import re
    if not _is_linux():
        # macOS / Windows: ask platform_compat for the display list instead of
        # xrandr. Pick the rightmost screen, same rule as the X11 branch.
        try:
            best = None
            for m in (_pc().list_monitors() if _pc() else []):
                x = w = h = None
                if "width" in m:  # Windows/screeninfo shape
                    x, w, h = int(m.get("x", 0)), int(m["width"]), int(m["height"])
                else:  # macOS shape: "{{x, y}, {w, h}}" or an xrandr-ish geometry
                    g = re.search(r'(\d+)/\d+x(\d+)/\d+\+(\d+)\+\d+',
                                  str(m.get("geometry", "")))
                    if g:
                        w, h, x = int(g.group(1)), int(g.group(2)), int(g.group(3))
                    else:
                        f = re.findall(r'-?\d+(?:\.\d+)?', str(m.get("frame", "")))
                        if len(f) >= 4:
                            x, w, h = int(float(f[0])), int(float(f[2])), int(float(f[3]))
                if x is not None and (best is None or x > best[0]):
                    best = (x, w, h)
            if best:
                return best[0], best[0] + best[1], best[2]
        except Exception:
            pass
        return 0, 1920, 1080
    try:
        env = dict(os.environ, DISPLAY=_DISPLAY)
        out = subprocess.run(["xrandr", "--listmonitors"], capture_output=True,
                             text=True, timeout=3, env=env).stdout
        mons = []
        for line in out.splitlines()[1:]:
            m = re.search(r'(\d+)/\d+x(\d+)/\d+\+(\d+)\+(\d+)', line)
            if m:
                w, h, x, y = (int(g) for g in m.groups())
                mons.append((x, w, h))
        if mons:
            x, w, h = max(mons, key=lambda t: t[0])
            return x, x + w, h
    except Exception:
        pass
    return 0, 1920, 1080


def _geo(idx: int, envvar: str) -> int:
    v = os.environ.get(envvar)
    if v and v.strip().lstrip("-").isdigit():
        return int(v.strip())
    return _probe_monitor_geometry()[idx]


_RIGHT_MONITOR_X_START = _geo(0, "LEON_SCREEN_X")
_RIGHT_MONITOR_X_END = _geo(1, "LEON_SCREEN_W")
_MONITOR_Y_MAX = _geo(2, "LEON_SCREEN_H")


def _run(cmd: list[str], timeout: int = 5) -> str:
    """Run a command with DISPLAY set."""
    env = dict(os.environ, DISPLAY=_DISPLAY)
    # Was hardcoded to /home/deansabr/.Xauthority — one specific user's home.
    # Use whoever is actually running this SI.
    if not env.get("XAUTHORITY"):
        for cand in (os.path.expanduser("~/.Xauthority"),
                     "/home/deansabr/.Xauthority"):
            if os.path.exists(cand):
                env["XAUTHORITY"] = cand
                break
    result = subprocess.run(cmd, capture_output=True, text=True,
                            timeout=timeout, env=env)
    return result.stdout.strip()


def _get_cursor_pos() -> tuple[int, int]:
    """Get current cursor position."""
    if not _is_linux():
        try:
            be = _pc()
            x, y = be.mouse_get_pos()
            return int(x), int(y)
        except Exception:
            return 0, 0
    try:
        out = _run(["xdotool", "getmouselocation", "--shell"])
        pos = {}
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                pos[k.strip()] = v.strip()
        return int(pos.get("X", 0)), int(pos.get("Y", 0))
    except Exception:
        return 0, 0


def _clamp_to_right_monitor(x: int, y: int) -> tuple[int, int]:
    """Ensure coordinates are on the right monitor."""
    x = max(_RIGHT_MONITOR_X_START, min(_RIGHT_MONITOR_X_END - 1, x))
    y = max(0, min(_MONITOR_Y_MAX - 1, y))
    return x, y


def ensure_leon_cursor() -> int | None:
    """No-op for backwards compatibility. Returns None (no separate pointer).

    The old xinput create-master approach is permanently retired.
    All leon_* functions now borrow the system pointer with save/restore.
    """
    return None


def leon_mouse_move(x: int, y: int) -> bool:
    """Move cursor to (x, y) on the right monitor. Saves/restores Dean's position."""
    x, y = _clamp_to_right_monitor(x, y)
    if not _is_linux():
        with _lock:
            owner_x, owner_y = _get_cursor_pos()
            ok = _pc_try("mouse_move", x, y)
            time.sleep(0.05)
            _pc_try("mouse_move", owner_x, owner_y)
            return ok
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            # Brief pause so the move registers, then restore
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            # Always try to restore even on error
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def leon_click(x: int, y: int, button: int = 1) -> bool:
    """Click at (x, y) on the right monitor. Saves/restores Dean's position."""
    x, y = _clamp_to_right_monitor(x, y)
    if not _is_linux():
        with _lock:
            owner_x, owner_y = _get_cursor_pos()
            ok = _pc_try("mouse_click", x, y, button)
            time.sleep(0.05)
            _pc_try("mouse_move", owner_x, owner_y)
            return ok
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            _run(["xdotool", "click", str(button)])
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def leon_type(text: str) -> bool:
    """Type text at current focus. Does NOT move the cursor — types into
    whatever window Leon has focused on the right monitor."""
    if not _is_linux():
        with _lock:
            return _pc_try("keyboard_type", text, 20)
    with _lock:
        try:
            _run(["xdotool", "type", "--clearmodifiers", "--delay", "20", text])
            return True
        except Exception:
            return False


def leon_key(keys: str) -> bool:
    """Press key combo (e.g. 'Return', 'ctrl+a'). Doesn't move cursor."""
    if not _is_linux():
        with _lock:
            return _pc_try("keyboard_hotkey", keys)
    with _lock:
        try:
            _run(["xdotool", "key", "--clearmodifiers", keys])
            return True
        except Exception:
            return False


def leon_scroll(x: int, y: int, units: int = 3) -> bool:
    """Scroll at (x, y) on the right monitor. Saves/restores Dean's position.
    Positive units = scroll down, negative = scroll up."""
    x, y = _clamp_to_right_monitor(x, y)
    button = "5" if units > 0 else "4"
    if not _is_linux():
        with _lock:
            owner_x, owner_y = _get_cursor_pos()
            ok = _pc_try("mouse_scroll", x, y, abs(units),
                         "down" if units > 0 else "up")
            time.sleep(0.05)
            _pc_try("mouse_move", owner_x, owner_y)
            return ok
    with _lock:
        dean_x, dean_y = _get_cursor_pos()
        try:
            _run(["xdotool", "mousemove", str(x), str(y)])
            for _ in range(abs(units)):
                _run(["xdotool", "click", button])
            time.sleep(0.05)
            _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            return True
        except Exception:
            try:
                _run(["xdotool", "mousemove", str(dean_x), str(dean_y)])
            except Exception:
                pass
            return False


def cleanup():
    """Clean up any leftover Leon master pointers from the old approach."""
    if not _is_linux():
        return  # xinput master pointers are an X11-only concept
    try:
        out = _run(["xinput", "list"])
        for line in out.splitlines():
            if "Leon pointer" in line and "master pointer" in line:
                for part in line.split():
                    if part.startswith("id="):
                        pid = int(part[3:])
                        _run(["xinput", "remove-master", str(pid)])
                        print(f"[LEON_CURSOR] Cleaned up old master pointer id={pid}")
    except Exception:
        pass


def is_on_right_monitor(x: int) -> bool:
    """Check if x coordinate is on Leon's monitor."""
    return _RIGHT_MONITOR_X_START <= x < _RIGHT_MONITOR_X_END
