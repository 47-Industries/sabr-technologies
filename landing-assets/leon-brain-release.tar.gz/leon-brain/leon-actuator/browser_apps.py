"""
App-specific browser helpers for Leon — Gmail, YouTube, Google Search, Twitter/X,
Google Docs / Sheets, Notion, and a universal "what's Dean looking at?" probe.

These are all thin wrappers around the CDP primitives in `browser_cdp.py`:
  _open_session()  → WebSocket against a specific tab (matched by URL substring)
  _evaluate()      → run JS in that tab
  _list_tabs()     → enumerate page-type targets
  _http_get_json() → /json HTTP endpoints (used for tab create/close/activate)

────────────────────────────────────────────────────────────────────────────
FRAGILITY WARNING — read before debugging.
────────────────────────────────────────────────────────────────────────────
Almost every function here pokes at the *internal DOM* of a third-party web
app. Gmail, YouTube, Twitter, Notion, Docs, Sheets all use obfuscated /
generated class names (e.g. Gmail's `.bsU`, `.T-Jo`) that the vendor is free
to rename whenever they ship a redesign. When something stops working:

  1. Open the app in Brave manually.
  2. F12 → Elements → inspect the control that broke.
  3. Update the selector here. The function names and call shapes stay the
     same so callers don't have to change.

The CDP primitives in browser_cdp.py are stable — anything that breaks here
is almost always a selector that the upstream app renamed. Don't blame CDP.

The "best-effort" doc tools (docs_insert_text, sheets_set_cell,
notion_create_block) are *especially* fragile and lean heavily on synthetic
events. If a vendor switches off accepting synthetic input (which Google has
threatened to do for years), those will need a fallback to pyautogui-typed
input via the actuator's keyboard.* tools.
────────────────────────────────────────────────────────────────────────────

Conventions:
  - Every tool takes args: Dict[str, Any] and returns {"ok": bool,
    "result"|"error": ...}.
  - CDPUnreachable is caught and surfaced as a clean error so Leon can fall
    back to other tools instead of crashing.
  - Tools that mutate (delete, archive, post, send) NEVER auto-send a final
    irreversible action — they prep the UI and return ready_to_send=true so
    a human (or Leon's higher-level reasoning) approves the actual fire.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict
from urllib.parse import quote

from browser_cdp import (
    _open_session,
    _evaluate,
    CDPUnreachable,
    _list_tabs,
    _http_get_json,
    _pick_tab,
)


# ──────────────────────────────────────────────────────────────────────────
# Small internal helpers
# ──────────────────────────────────────────────────────────────────────────


def _err(e: Exception) -> Dict[str, Any]:
    """Standard error envelope. CDPUnreachable gets its full message
    (it already explains how to fix it); other exceptions are wrapped
    with their type so debugging is one step easier."""
    if isinstance(e, CDPUnreachable):
        return {"ok": False, "error": str(e)}
    return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def _new_tab(url: str) -> Dict[str, Any]:
    """Create a new tab pointing at `url` and return its CDP target dict.
    Uses Brave's /json/new HTTP endpoint."""
    return _http_get_json(f"/json/new?{quote(url, safe='')}")


def _close_tab(tab_id: str) -> None:
    """Best-effort close; ignore errors (the tab may already be gone)."""
    try:
        _http_get_json(f"/json/close/{tab_id}")
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────
# YOUTUBE
# ──────────────────────────────────────────────────────────────────────────
# All YouTube functions target a tab whose URL contains "youtube.com".
# If multiple YT tabs are open, _pick_tab takes the most-recently-active
# match — which is usually what Dean means by "the video".


def youtube_play_video(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open YouTube search results for `query` in a new tab, then click the
    first video thumbnail. FRAGILE — depends on `ytd-video-renderer` custom
    element existing in YT's polymer-based UI."""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    try:
        url = f"https://www.youtube.com/results?search_query={quote(query)}"
        tab = _new_tab(url)
        time.sleep(3)  # let results render
        s = _open_session("youtube.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const r = document.querySelector('ytd-video-renderer a#thumbnail');
                    if (!r) return {ok: false, err: 'no ytd-video-renderer thumbnail'};
                    r.click();
                    return {ok: true, href: r.href, title: (r.getAttribute('title') || '').slice(0, 200)};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "no thumbnail to click")}
        return {"ok": True, "result": {"tab_id": tab.get("id"), "query": query,
                                       "video_url": res.get("href"), "title": res.get("title")}}
    except Exception as e:
        return _err(e)


def youtube_play_pause(args: Dict[str, Any]) -> Dict[str, Any]:
    """Toggle play/pause on the current YT video element."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const v = document.querySelector('video');
                    if (!v) return {ok: false, err: 'no <video> element'};
                    if (v.paused) { v.play(); return {ok: true, state: 'playing'}; }
                    v.pause(); return {ok: true, state: 'paused'};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "toggle failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def youtube_play(args: Dict[str, Any]) -> Dict[str, Any]:
    """Force-play the current YT video."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, "(() => { const v=document.querySelector('video'); if(!v) return {ok:false,err:'no video'}; v.play(); return {ok:true}; })()")
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "play failed")}
        return {"ok": True, "result": {"state": "playing"}}
    except Exception as e:
        return _err(e)


def youtube_pause(args: Dict[str, Any]) -> Dict[str, Any]:
    """Force-pause the current YT video."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, "(() => { const v=document.querySelector('video'); if(!v) return {ok:false,err:'no video'}; v.pause(); return {ok:true}; })()")
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "pause failed")}
        return {"ok": True, "result": {"state": "paused"}}
    except Exception as e:
        return _err(e)


def youtube_skip(args: Dict[str, Any]) -> Dict[str, Any]:
    """Seek the current YT video forward (or backward, with negative) by
    `seconds`. Default +10s."""
    seconds = float(args.get("seconds", 10))
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const v = document.querySelector('video');
                    if (!v) return {{ok: false, err: 'no video'}};
                    v.currentTime += {seconds};
                    return {{ok: true, current_time: v.currentTime}};
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "skip failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def youtube_speed(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set playback rate. rate=1.0 normal, 2.0 = 2x, 0.5 = half. YT itself
    clamps to [0.25, 2.0] under the hood for most videos."""
    rate = float(args.get("rate", 1.0))
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const v = document.querySelector('video');
                    if (!v) return {{ok: false, err: 'no video'}};
                    v.playbackRate = {rate};
                    return {{ok: true, playback_rate: v.playbackRate}};
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "speed failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def youtube_volume(args: Dict[str, Any]) -> Dict[str, Any]:
    """Set HTML5 video volume (0-100 range, normalized to 0.0-1.0)."""
    try:
        level = int(args.get("level", 50))
    except Exception:
        return {"ok": False, "error": "level must be 0-100"}
    if not 0 <= level <= 100:
        return {"ok": False, "error": "level must be 0-100"}
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const v = document.querySelector('video');
                    if (!v) return {{ok: false, err: 'no video'}};
                    v.volume = {level / 100.0};
                    return {{ok: true, volume: v.volume}};
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "volume failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def youtube_mute_toggle(args: Dict[str, Any]) -> Dict[str, Any]:
    """Toggle the video element's `muted` property."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const v = document.querySelector('video');
                    if (!v) return {ok: false, err: 'no video'};
                    v.muted = !v.muted;
                    return {ok: true, muted: v.muted};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "mute toggle failed")}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


def youtube_pip(args: Dict[str, Any]) -> Dict[str, Any]:
    """Pop the video into Picture-in-Picture. Brave/Chromium support this
    on YT; the user gesture requirement is sometimes a problem for
    headless calls — if this fails, fall back to clicking the PiP control."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, """
                (async () => {
                    const v = document.querySelector('video');
                    if (!v) return {ok: false, err: 'no video'};
                    try {
                        await v.requestPictureInPicture();
                        return {ok: true};
                    } catch (e) {
                        return {ok: false, err: String(e).slice(0, 200)};
                    }
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "pip failed")}
        return {"ok": True, "result": {"pip": "active"}}
    except Exception as e:
        return _err(e)


def youtube_get_current_video(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return metadata for the currently-loaded YT video."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const v = document.querySelector('video');
                    const ch = document.querySelector('ytd-channel-name a, ytd-channel-name yt-formatted-string');
                    const title = (document.title || '').replace(/ - YouTube$/, '');
                    return {
                        title: title,
                        url: location.href,
                        channel: ch ? (ch.innerText || ch.textContent || '').trim() : null,
                        duration: v ? v.duration : null,
                        current_time: v ? v.currentTime : null,
                        paused: v ? v.paused : null,
                        playback_rate: v ? v.playbackRate : null,
                    };
                })()
            """)
        finally:
            s.close()
        return {"ok": True, "result": res or {}}
    except Exception as e:
        return _err(e)


def youtube_get_transcript(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open YT's transcript panel, then scrape every line. FRAGILE — relies
    on the "more actions" (...) button + "Show transcript" menu item +
    the `ytd-transcript-segment-renderer` custom element. If YT renames
    any of those, this errors with a hint pointing to the manual fallback
    (right-click video → Show transcript → copy lines)."""
    try:
        s = _open_session(args.get("url_contains") or "youtube.com")
        try:
            # First, try to open the transcript panel via the menu.
            _evaluate(s, """
                (() => {
                    const moreBtns = Array.from(document.querySelectorAll('button[aria-label="More actions"], tp-yt-paper-button#expand'));
                    if (moreBtns.length) moreBtns[0].click();
                })()
            """)
            time.sleep(0.8)
            _evaluate(s, """
                (() => {
                    const items = Array.from(document.querySelectorAll('ytd-menu-service-item-renderer, tp-yt-paper-item'));
                    for (const it of items) {
                        const t = (it.innerText || it.textContent || '').trim();
                        if (/show transcript/i.test(t)) { it.click(); return true; }
                    }
                    return false;
                })()
            """)
            time.sleep(1.5)
            res = _evaluate(s, """
                (() => {
                    const rows = Array.from(document.querySelectorAll('ytd-transcript-segment-renderer'));
                    if (!rows.length) return {ok: false, err: 'no transcript rows — panel may not have opened'};
                    const out = [];
                    for (const r of rows) {
                        const ts = r.querySelector('.segment-timestamp');
                        const tx = r.querySelector('.segment-text, yt-formatted-string.segment-text');
                        out.push({
                            timestamp: ts ? (ts.innerText || ts.textContent || '').trim() : null,
                            text: tx ? (tx.innerText || tx.textContent || '').trim() : null,
                        });
                    }
                    return {ok: true, segments: out};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error":
                    (res or {}).get("err", "could not scrape transcript")
                    + " — fallback: open the video in Brave, click ... → Show transcript, copy manually."}
        segs = res.get("segments", []) or []
        return {"ok": True, "result": {"count": len(segs), "segments": segs}}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GMAIL
# ──────────────────────────────────────────────────────────────────────────
# Target url_contains="mail.google.com". Gmail's class names are
# obfuscated 3-char tokens (.bsU, .T-Jo, .zA, etc.) — these are baked into
# Gmail's source-map so they tend to be stable for *months* at a time, but
# every redesign breaks them. The aria-label selectors below are slightly
# more durable; class names are the fallback when aria-label isn't enough.


def gmail_inbox_state(args: Dict[str, Any]) -> Dict[str, Any]:
    """Count unread badge + return top 10 visible thread rows
    (from/subject/snippet). FRAGILE — depends on `.zA` row selector and
    `.bsU` / inbox aria-label. If unread count is null, Gmail is probably
    in a non-default view (e.g. snoozed/labels). Re-navigate to inbox."""
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            res = _evaluate(s, """
                (() => {
                    // Unread: try the nav-link aria-label "Inbox 12,345 unread", fall back to .bsU
                    let unread = null;
                    const inboxNav = document.querySelector('a[aria-label*="Inbox"][href*="#inbox"], a[href*="#inbox"][aria-label]');
                    if (inboxNav) {
                        const m = inboxNav.getAttribute('aria-label').match(/([\\d,]+)\\s*unread/i);
                        if (m) unread = parseInt(m[1].replace(/,/g,''), 10);
                    }
                    if (unread === null) {
                        const badge = document.querySelector('.bsU');
                        if (badge) unread = parseInt((badge.innerText || '').replace(/[^\\d]/g,''), 10) || null;
                    }
                    // Threads: row class .zA is the canonical Gmail row.
                    // Within each row: .yX/.yW span = from, .y6 span = subject+snippet
                    const rows = Array.from(document.querySelectorAll('tr.zA')).slice(0, 10);
                    const threads = rows.map(r => {
                        const from = r.querySelector('.yX, .yW span[email], .yW');
                        const subj = r.querySelector('.y6 span, .bog');
                        const snip = r.querySelector('.y2');
                        const unr = r.classList.contains('zE');  // .zE = unread row
                        return {
                            from: from ? (from.getAttribute('email') || from.innerText || from.textContent || '').trim() : null,
                            subject: subj ? (subj.innerText || subj.textContent || '').trim() : null,
                            snippet: snip ? (snip.innerText || snip.textContent || '').trim().slice(0, 200) : null,
                            unread: unr,
                        };
                    });
                    return {unread_count: unread, visible_threads: threads};
                })()
            """)
        finally:
            s.close()
        return {"ok": True, "result": res or {}}
    except Exception as e:
        return _err(e)


def gmail_open_thread(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Gmail by typing into the search bar, hitting Enter, waiting,
    and clicking the first result row. Returns the opened thread's subject
    and from. FRAGILE — uses `input[aria-label="Search mail"]` and
    `tr.zA` for results."""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            _evaluate(s, f"""
                (() => {{
                    const inp = document.querySelector('input[aria-label="Search mail"], input[name="q"]');
                    if (!inp) return {{ok: false, err: 'search input not found'}};
                    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                    setter.call(inp, {json.dumps(query)});
                    inp.dispatchEvent(new Event('input', {{bubbles: true}}));
                    inp.focus();
                    inp.dispatchEvent(new KeyboardEvent('keydown', {{key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}}));
                    return {{ok: true}};
                }})()
            """)
            time.sleep(2)
            res = _evaluate(s, """
                (() => {
                    const row = document.querySelector('tr.zA');
                    if (!row) return {ok: false, err: 'no results'};
                    row.click();
                    return {ok: true};
                })()
            """)
            time.sleep(1.2)
            meta = _evaluate(s, """
                (() => {
                    const subj = document.querySelector('h2.hP, [data-thread-perm-id] h2');
                    const from = document.querySelector('.gD, span[email]');
                    return {
                        thread_subject: subj ? (subj.innerText || subj.textContent || '').trim() : null,
                        thread_from: from ? (from.getAttribute('email') || from.innerText || from.textContent || '').trim() : null,
                    };
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "could not open thread")}
        return {"ok": True, "result": meta or {}}
    except Exception as e:
        return _err(e)


def gmail_archive_current(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click the Archive button on the currently-open thread."""
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const btn = document.querySelector('[aria-label^="Archive"], [data-tooltip^="Archive"]');
                    if (!btn) return {ok: false, err: 'no archive button (thread open?)'};
                    btn.click();
                    return {ok: true};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "archive failed")}
        return {"ok": True, "result": {"archived": True}}
    except Exception as e:
        return _err(e)


def gmail_delete_current(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click the Delete button on the currently-open thread. HIGH risk —
    deletes immediately. Gmail's trash holds for 30 days so it's not truly
    irreversible, but treat it as such."""
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const btn = document.querySelector('[aria-label^="Delete"], [data-tooltip^="Delete"]');
                    if (!btn) return {ok: false, err: 'no delete button (thread open?)'};
                    btn.click();
                    return {ok: true};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "delete failed")}
        return {"ok": True, "result": {"deleted": True}}
    except Exception as e:
        return _err(e)


def gmail_mark_read(args: Dict[str, Any]) -> Dict[str, Any]:
    """Click "Mark as read" on the current thread."""
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const btn = document.querySelector('[aria-label="Mark as read"], [data-tooltip="Mark as read"]');
                    if (!btn) return {ok: false, err: 'no "Mark as read" button'};
                    btn.click();
                    return {ok: true};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "mark read failed")}
        return {"ok": True, "result": {"marked_read": True}}
    except Exception as e:
        return _err(e)


def gmail_star_toggle(args: Dict[str, Any]) -> Dict[str, Any]:
    """Toggle the star on the current thread by clicking `.T-Jo`. The Gmail
    star button is a `<span class="T-Jo ...">`; the class is one of Gmail's
    oldest obfuscated tokens so it's pretty stable, but it's still classes."""
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            res = _evaluate(s, """
                (() => {
                    const star = document.querySelector('.T-Jo, [aria-label*="Star"]:not([aria-label*="Starred"])');
                    if (!star) return {ok: false, err: 'no star control'};
                    star.click();
                    return {ok: true};
                })()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "star toggle failed")}
        return {"ok": True, "result": {"starred_toggled": True}}
    except Exception as e:
        return _err(e)


def gmail_reply_to_current(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open the reply composer on the current thread, fill in `body`, but
    DO NOT click Send. Returns ready_to_send=true so the caller can confirm
    before firing the actual send. FRAGILE — uses aria-label="Reply" and
    `[contenteditable=true][aria-label*="Message Body"]`."""
    body = args.get("body", "")
    try:
        s = _open_session(args.get("url_contains") or "mail.google.com")
        try:
            click = _evaluate(s, """
                (() => {
                    const btn = document.querySelector('[aria-label="Reply"], [data-tooltip="Reply"], div[role="button"][aria-label*="Reply"]');
                    if (!btn) return {ok: false, err: 'no Reply button (thread open?)'};
                    btn.click();
                    return {ok: true};
                })()
            """)
            if not click or not click.get("ok"):
                return {"ok": False, "error": (click or {}).get("err", "reply click failed")}
            time.sleep(1.2)
            fill = _evaluate(s, f"""
                (() => {{
                    const ta = document.querySelector('[contenteditable=true][aria-label*="Message Body"], div[role="textbox"][aria-label*="Body"]');
                    if (!ta) return {{ok: false, err: 'no message body textarea'}};
                    ta.focus();
                    ta.innerHTML = '';
                    ta.innerText = {json.dumps(str(body))};
                    ta.dispatchEvent(new InputEvent('input', {{bubbles: true}}));
                    return {{ok: true}};
                }})()
            """)
        finally:
            s.close()
        if not fill or not fill.get("ok"):
            return {"ok": False, "error": (fill or {}).get("err", "fill failed — composer may not have opened")}
        return {"ok": True, "result": {"ready_to_send": True,
                                       "note": "reply composer filled; caller must click Send manually."}}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE SEARCH
# ──────────────────────────────────────────────────────────────────────────


def google_search_in_tab(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open a new tab with Google search results for `query` and return the
    tab info. Leaves the tab open — Dean (or Leon) can read it visually."""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    try:
        url = f"https://www.google.com/search?q={quote(query)}"
        tab = _new_tab(url)
        time.sleep(1)
        return {"ok": True, "result": {"tab_id": tab.get("id"),
                                       "url": tab.get("url") or url,
                                       "query": query}}
    except Exception as e:
        return _err(e)


def google_search_silent(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open a Google search in a new tab, scrape results, then close the tab.
    Returns up to `max_results` items as {title, url, snippet}. FRAGILE —
    Google's SERP markup changes every few months. Tries `.g` (classic),
    `[data-sokoban-container]` (modern), and falls back to `h3` siblings."""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    max_results = int(args.get("max_results", 10))
    tab_id = None
    try:
        url = f"https://www.google.com/search?q={quote(query)}"
        tab = _new_tab(url)
        tab_id = tab.get("id")
        time.sleep(2)  # let SERP render
        s = _open_session(query[:20])  # crude; fall through to .com matcher below
        # Actually re-open against the URL we just created to be safe:
        s.close()
        s = _open_session("google.com/search")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const limit = {max_results};
                    const out = [];
                    // Primary: each .g block is one result.
                    let blocks = Array.from(document.querySelectorAll('div.g'));
                    if (!blocks.length) {{
                        blocks = Array.from(document.querySelectorAll('[data-sokoban-container] > div'));
                    }}
                    if (!blocks.length) {{
                        // Last-resort: every h3 with a parent <a>
                        blocks = Array.from(document.querySelectorAll('h3')).map(h => h.closest('a')?.parentElement).filter(Boolean);
                    }}
                    for (const b of blocks) {{
                        if (out.length >= limit) break;
                        const a = b.querySelector('a[href^="http"]');
                        const h3 = b.querySelector('h3');
                        const snip = b.querySelector('[data-sncf], .VwiC3b, .lEBKkf, span.aCOpRe');
                        if (!a || !h3) continue;
                        out.push({{
                            title: (h3.innerText || h3.textContent || '').trim(),
                            url: a.href,
                            snippet: snip ? (snip.innerText || snip.textContent || '').trim().slice(0, 400) : '',
                        }});
                    }}
                    return out;
                }})()
            """)
        finally:
            s.close()
        return {"ok": True, "result": {"query": query,
                                       "count": len(res) if isinstance(res, list) else 0,
                                       "results": res or []}}
    except Exception as e:
        return _err(e)
    finally:
        if tab_id:
            _close_tab(tab_id)


# ──────────────────────────────────────────────────────────────────────────
# TWITTER / X
# ──────────────────────────────────────────────────────────────────────────


def twitter_post_compose(args: Dict[str, Any]) -> Dict[str, Any]:
    """Open x.com's compose page in a new tab, fill the textarea with `text`,
    but DO NOT auto-publish. Returns ready_to_publish=true. FRAGILE — uses
    `[data-testid="tweetTextarea_0"]`, X's stable-ish test ID."""
    text = args.get("text", "")
    if not isinstance(text, str) or not text.strip():
        return {"ok": False, "error": "text is required"}
    try:
        tab = _new_tab("https://x.com/compose/post")
        time.sleep(2.5)
        s = _open_session("x.com")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const ta = document.querySelector('[data-testid="tweetTextarea_0"]');
                    if (!ta) return {{ok: false, err: 'no compose textarea'}};
                    ta.focus();
                    // X uses a Draft.js-style contenteditable. Pasting via beforeinput
                    // is the cleanest way to get the text in without simulating each key.
                    document.execCommand('insertText', false, {json.dumps(text)});
                    return {{ok: true}};
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False, "error": (res or {}).get("err", "compose fill failed"),
                    "tab_id": tab.get("id")}
        return {"ok": True, "result": {"tab_id": tab.get("id"),
                                       "ready_to_publish": True,
                                       "note": "tweet draft filled; caller must click Post manually."}}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# GOOGLE DOCS / SHEETS / NOTION
# ──────────────────────────────────────────────────────────────────────────
# These are the most fragile tools in the file. Google Docs renders into a
# canvas-backed editor that intercepts synthetic events aggressively; Sheets
# is similar. Notion at least uses contenteditable divs but its block model
# means simple .innerText assignments don't always commit.
#
# Treat all three as best-effort. If they fail, the fallback is to focus the
# tab and use the actuator's keyboard.paste_via_clipboard tool with
# Ctrl+A → typed input. That's outside this module's scope.


def docs_insert_text(args: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort: insert `text` into the active Google Docs tab by firing
    an InputEvent('beforeinput', {data, inputType:'insertText'}) at the
    canvas. FRAGILE — Google has actively worked to break synthetic input
    here. If this fails, the recommended fallback is keyboard.paste_via_clipboard."""
    text = args.get("text", "")
    if not isinstance(text, str):
        return {"ok": False, "error": "text must be a string"}
    try:
        s = _open_session(args.get("url_contains") or "docs.google.com/document")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    // Docs renders into .docs-texteventtarget-iframe / .kix-canvas-tile-content
                    const target = document.querySelector('.docs-texteventtarget-iframe')?.contentDocument?.activeElement
                                  || document.querySelector('iframe.docs-texteventtarget-iframe')?.contentDocument?.body
                                  || document.activeElement;
                    if (!target) return {{ok: false, err: 'no active doc target'}};
                    try {{
                        target.dispatchEvent(new InputEvent('beforeinput', {{
                            bubbles: true, cancelable: true,
                            data: {json.dumps(text)}, inputType: 'insertText',
                        }}));
                        target.dispatchEvent(new InputEvent('input', {{
                            bubbles: true,
                            data: {json.dumps(text)}, inputType: 'insertText',
                        }}));
                        return {{ok: true, note: 'synthetic event fired — may or may not have committed'}};
                    }} catch (e) {{
                        return {{ok: false, err: String(e).slice(0, 200)}};
                    }}
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False,
                    "error": (res or {}).get("err", "docs insert failed")
                    + " — fallback: focus tab and use keyboard.paste_via_clipboard."}
        return {"ok": True, "result": {**res,
                                       "fallback_hint": "if text didn't appear, use keyboard.paste_via_clipboard."}}
    except Exception as e:
        return _err(e)


def sheets_set_cell(args: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort: navigate to `cell` (e.g. "A1") via the Name Box, then
    type `value` + Enter. FRAGILE — same canvas-editor problem as Docs.
    Uses the Name Box (`#t-name-box`) which is one of the few accessible
    DOM nodes in Sheets."""
    cell = (args.get("cell") or "").strip()
    value = args.get("value", "")
    if not cell:
        return {"ok": False, "error": "cell is required (e.g. 'A1')"}
    try:
        s = _open_session(args.get("url_contains") or "docs.google.com/spreadsheets")
        try:
            nav = _evaluate(s, f"""
                (() => {{
                    const nb = document.querySelector('#t-name-box');
                    if (!nb) return {{ok: false, err: 'no Name Box (#t-name-box) — Sheets may have redesigned'}};
                    nb.focus();
                    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                    setter.call(nb, {json.dumps(cell)});
                    nb.dispatchEvent(new Event('input', {{bubbles: true}}));
                    nb.dispatchEvent(new KeyboardEvent('keydown', {{key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}}));
                    return {{ok: true}};
                }})()
            """)
            if not nav or not nav.get("ok"):
                return {"ok": False, "error": (nav or {}).get("err", "Name Box nav failed")}
            time.sleep(0.6)
            # Typing into a Sheets cell triggers the formula-bar input.
            fill = _evaluate(s, f"""
                (() => {{
                    const fb = document.querySelector('#t-formula-bar-input .cell-input, .cell-input[contenteditable]')
                            || document.querySelector('[contenteditable=true].cell-input');
                    if (!fb) return {{ok: false, err: 'no formula-bar input — Sheets may have redesigned'}};
                    fb.focus();
                    fb.textContent = {json.dumps(str(value))};
                    fb.dispatchEvent(new InputEvent('input', {{bubbles: true, data: {json.dumps(str(value))}, inputType: 'insertText'}}));
                    fb.dispatchEvent(new KeyboardEvent('keydown', {{key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true}}));
                    return {{ok: true}};
                }})()
            """)
        finally:
            s.close()
        if not fill or not fill.get("ok"):
            return {"ok": False,
                    "error": (fill or {}).get("err", "cell fill failed")
                    + " — fallback: focus tab, use keyboard.paste_via_clipboard."}
        return {"ok": True, "result": {"cell": cell, "value": value,
                                       "note": "best-effort; verify with screenshot."}}
    except Exception as e:
        return _err(e)


def notion_create_block(args: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort: append `text` to the active Notion page by finding the
    empty trailing block and setting its content. FRAGILE — Notion uses
    `.notion-page-content` and individual `.notranslate[contenteditable]`
    blocks. If Notion's block engine doesn't recognize the synthetic edit,
    fall back to keyboard.paste_via_clipboard."""
    text = args.get("text", "")
    if not isinstance(text, str) or not text.strip():
        return {"ok": False, "error": "text is required"}
    try:
        s = _open_session(args.get("url_contains") or "notion.so")
        try:
            res = _evaluate(s, f"""
                (() => {{
                    const page = document.querySelector('.notion-page-content');
                    if (!page) return {{ok: false, err: 'no .notion-page-content — not a Notion page?'}};
                    // Find the last empty editable block, or the page itself.
                    const blocks = Array.from(page.querySelectorAll('[contenteditable=true]'));
                    const target = blocks.reverse().find(b => !(b.innerText || '').trim()) || blocks[0];
                    if (!target) return {{ok: false, err: 'no editable block found'}};
                    target.focus();
                    document.execCommand('insertText', false, {json.dumps(text)});
                    return {{ok: true, blocks_seen: blocks.length}};
                }})()
            """)
        finally:
            s.close()
        if not res or not res.get("ok"):
            return {"ok": False,
                    "error": (res or {}).get("err", "notion insert failed")
                    + " — fallback: focus the page and use keyboard.paste_via_clipboard."}
        return {"ok": True, "result": res}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# UNIVERSAL
# ──────────────────────────────────────────────────────────────────────────


def web_app_active_tab(args: Dict[str, Any]) -> Dict[str, Any]:
    """Return {url, title, hostname} for the tab Dean is most likely looking
    at. CDP's /json endpoint orders page-type tabs roughly by recency, so
    the first one is usually the active one. (NB: _list_tabs already filters
    to type=='page', so we don't have to.)"""
    try:
        tabs = _list_tabs()
        if not tabs:
            return {"ok": False, "error":
                    "no CDP tabs — Brave probably needs a restart with --remote-debugging-port=9222."}
        top = tabs[0]
        url = top.get("url", "") or ""
        # Cheap hostname extract without importing urlparse for one field.
        host = ""
        if "://" in url:
            host = url.split("://", 1)[1].split("/", 1)[0]
        return {"ok": True, "result": {
            "url": url,
            "title": top.get("title", ""),
            "hostname": host,
            "tab_id": top.get("id"),
        }}
    except Exception as e:
        return _err(e)


# ──────────────────────────────────────────────────────────────────────────
# EXTRA_TOOLS — dotted-name registration table
# ──────────────────────────────────────────────────────────────────────────
# The actuator's central dispatcher merges this into its main tool map.
# Names use "browser.<verb>" so they namespace cleanly alongside
# browser_dom_* in browser_cdp.py and browser_* in tools_extra.py.


EXTRA_TOOLS: Dict[str, Any] = {
    # YouTube
    "browser.youtube_play_video":         youtube_play_video,
    "browser.youtube_play_pause":         youtube_play_pause,
    "browser.youtube_play":               youtube_play,
    "browser.youtube_pause":              youtube_pause,
    "browser.youtube_skip":               youtube_skip,
    "browser.youtube_speed":              youtube_speed,
    "browser.youtube_volume":             youtube_volume,
    "browser.youtube_mute_toggle":        youtube_mute_toggle,
    "browser.youtube_pip":                youtube_pip,
    "browser.youtube_get_current_video": youtube_get_current_video,
    "browser.youtube_get_transcript":     youtube_get_transcript,
    # Gmail
    "browser.gmail_inbox_state":          gmail_inbox_state,
    "browser.gmail_open_thread":          gmail_open_thread,
    "browser.gmail_archive_current":      gmail_archive_current,
    "browser.gmail_delete_current":       gmail_delete_current,
    "browser.gmail_mark_read":            gmail_mark_read,
    "browser.gmail_star_toggle":          gmail_star_toggle,
    "browser.gmail_reply_to_current":     gmail_reply_to_current,
    # Google Search
    "browser.google_search_in_tab":       google_search_in_tab,
    "browser.google_search_silent":       google_search_silent,
    # Twitter / X
    "browser.twitter_post_compose":       twitter_post_compose,
    # Docs / Sheets / Notion
    "browser.docs_insert_text":           docs_insert_text,
    "browser.sheets_set_cell":            sheets_set_cell,
    "browser.notion_create_block":        notion_create_block,
    # Universal
    "browser.web_app_active_tab":         web_app_active_tab,
}
