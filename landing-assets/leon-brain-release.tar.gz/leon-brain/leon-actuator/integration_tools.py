"""
Integration tools — connect Leon to external services.

Each integration is a thin API wrapper exposed as an actuator tool.
API keys are read from environment variables (set in .env).

Integrations:
  - youtube.search: Search YouTube videos
  - youtube.get_transcript: Get video transcript/captions
  - spotify.search: Search Spotify tracks/artists/playlists
  - spotify.now_playing: Current playback state
  - slack.send: Send a Slack message
  - slack.channels: List Slack channels
  - notion.search: Search Notion pages
  - notion.create_page: Create a Notion page
  - discord.send: Send a Discord webhook message
  - reddit.search: Search Reddit posts
  - weather.get: Get current weather for a location
  - news.search: Search recent news articles
"""

import json
import os
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Dict

# API keys from environment
_YOUTUBE_API_KEY = os.environ.get("YOUTUBE_API_KEY", "")
_SPOTIFY_CLIENT_ID = os.environ.get("SPOTIFY_CLIENT_ID", "")
_SPOTIFY_CLIENT_SECRET = os.environ.get("SPOTIFY_CLIENT_SECRET", "")
_SLACK_BOT_TOKEN = os.environ.get("SLACK_BOT_TOKEN", "")
_NOTION_TOKEN = os.environ.get("NOTION_TOKEN", "")
_DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")
_OPENWEATHER_KEY = os.environ.get("OPENWEATHER_API_KEY", "")
_NEWS_API_KEY = os.environ.get("NEWS_API_KEY", "")
_REDDIT_CLIENT_ID = os.environ.get("REDDIT_CLIENT_ID", "")
_REDDIT_CLIENT_SECRET = os.environ.get("REDDIT_CLIENT_SECRET", "")

# Spotify token cache
_spotify_token = {"token": "", "expires": 0}


def _get(url: str, headers: dict = None, timeout: int = 15) -> dict:
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.read().decode()[:300]}"}
    except Exception as e:
        return {"error": str(e)}


def _post(url: str, data: dict, headers: dict = None, timeout: int = 15) -> dict:
    body = json.dumps(data).encode()
    h = {"Content-Type": "application/json"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.read().decode()[:300]}"}
    except Exception as e:
        return {"error": str(e)}


# ── YOUTUBE ──────────────────────────────────────────────────────────

def youtube_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search YouTube videos. Args: query, max_results (default 5)"""
    if not _YOUTUBE_API_KEY:
        return {"ok": False, "error": "Set YOUTUBE_API_KEY in .env"}
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    max_r = min(int(args.get("max_results", 5)), 20)
    params = urllib.parse.urlencode({
        "part": "snippet", "q": query, "type": "video",
        "maxResults": max_r, "key": _YOUTUBE_API_KEY,
    })
    data = _get(f"https://www.googleapis.com/youtube/v3/search?{params}")
    if "error" in data:
        return {"ok": False, "error": data["error"]}
    results = []
    for item in data.get("items", []):
        s = item.get("snippet", {})
        results.append({
            "title": s.get("title"),
            "channel": s.get("channelTitle"),
            "video_id": item.get("id", {}).get("videoId"),
            "url": f"https://youtube.com/watch?v={item['id']['videoId']}",
            "published": s.get("publishedAt"),
            "description": (s.get("description") or "")[:200],
        })
    return {"ok": True, "results": results, "count": len(results)}


# ── SPOTIFY ──────────────────────────────────────────────────────────

def _spotify_auth() -> str:
    """Get a Spotify access token via client credentials."""
    import base64, time
    if _spotify_token["token"] and time.time() < _spotify_token["expires"]:
        return _spotify_token["token"]
    if not _SPOTIFY_CLIENT_ID or not _SPOTIFY_CLIENT_SECRET:
        return ""
    creds = base64.b64encode(f"{_SPOTIFY_CLIENT_ID}:{_SPOTIFY_CLIENT_SECRET}".encode()).decode()
    body = "grant_type=client_credentials".encode()
    req = urllib.request.Request("https://accounts.spotify.com/api/token",
        data=body, headers={"Authorization": f"Basic {creds}",
                            "Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            d = json.loads(r.read().decode())
            _spotify_token["token"] = d["access_token"]
            _spotify_token["expires"] = time.time() + d.get("expires_in", 3600) - 60
            return _spotify_token["token"]
    except Exception:
        return ""


def spotify_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Spotify. Args: query, type (track/artist/album/playlist), limit"""
    token = _spotify_auth()
    if not token:
        return {"ok": False, "error": "Set SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET in .env"}
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    stype = args.get("type", "track")
    limit = min(int(args.get("limit", 5)), 20)
    params = urllib.parse.urlencode({"q": query, "type": stype, "limit": limit})
    data = _get(f"https://api.spotify.com/v1/search?{params}",
                {"Authorization": f"Bearer {token}"})
    if "error" in data:
        return {"ok": False, "error": data["error"]}
    return {"ok": True, "results": data}


# ── SLACK ────────────────────────────────────────────────────────────

def slack_send(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a Slack message. Args: channel, text"""
    if not _SLACK_BOT_TOKEN:
        return {"ok": False, "error": "Set SLACK_BOT_TOKEN in .env"}
    channel = (args.get("channel") or "").strip()
    text = (args.get("text") or "").strip()
    if not channel or not text:
        return {"ok": False, "error": "channel and text are required"}
    return _post("https://slack.com/api/chat.postMessage",
                 {"channel": channel, "text": text},
                 {"Authorization": f"Bearer {_SLACK_BOT_TOKEN}"})


def slack_channels(args: Dict[str, Any]) -> Dict[str, Any]:
    """List Slack channels."""
    if not _SLACK_BOT_TOKEN:
        return {"ok": False, "error": "Set SLACK_BOT_TOKEN in .env"}
    return _get("https://slack.com/api/conversations.list?limit=100",
                {"Authorization": f"Bearer {_SLACK_BOT_TOKEN}"})


# ── NOTION ───────────────────────────────────────────────────────────

def notion_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Notion pages. Args: query"""
    if not _NOTION_TOKEN:
        return {"ok": False, "error": "Set NOTION_TOKEN in .env"}
    query = (args.get("query") or "").strip()
    return _post("https://api.notion.com/v1/search",
                 {"query": query, "page_size": 10},
                 {"Authorization": f"Bearer {_NOTION_TOKEN}",
                  "Notion-Version": "2022-06-28"})


def notion_create_page(args: Dict[str, Any]) -> Dict[str, Any]:
    """Create a Notion page. Args: parent_id, title, content"""
    if not _NOTION_TOKEN:
        return {"ok": False, "error": "Set NOTION_TOKEN in .env"}
    parent_id = (args.get("parent_id") or "").strip()
    title = (args.get("title") or "").strip()
    content = (args.get("content") or "").strip()
    if not parent_id or not title:
        return {"ok": False, "error": "parent_id and title required"}
    data = {
        "parent": {"page_id": parent_id},
        "properties": {"title": {"title": [{"text": {"content": title}}]}},
        "children": [{"object": "block", "type": "paragraph",
                       "paragraph": {"rich_text": [{"text": {"content": content}}]}}] if content else [],
    }
    return _post("https://api.notion.com/v1/pages", data,
                 {"Authorization": f"Bearer {_NOTION_TOKEN}",
                  "Notion-Version": "2022-06-28"})


# ── DISCORD ──────────────────────────────────────────────────────────

def discord_send(args: Dict[str, Any]) -> Dict[str, Any]:
    """Send a Discord webhook message. Args: content, webhook_url (optional, uses env default)"""
    url = args.get("webhook_url") or _DISCORD_WEBHOOK_URL
    if not url:
        return {"ok": False, "error": "Set DISCORD_WEBHOOK_URL in .env or pass webhook_url"}
    content = (args.get("content") or "").strip()
    if not content:
        return {"ok": False, "error": "content is required"}
    return _post(url, {"content": content[:2000]})


# ── WEATHER ──────────────────────────────────────────────────────────

def weather_get(args: Dict[str, Any]) -> Dict[str, Any]:
    """Get current weather. Args: location (city name or 'lat,lon')"""
    if not _OPENWEATHER_KEY:
        return {"ok": False, "error": "Set OPENWEATHER_API_KEY in .env"}
    loc = (args.get("location") or "").strip()
    if not loc:
        return {"ok": False, "error": "location is required"}
    params = urllib.parse.urlencode({"q": loc, "appid": _OPENWEATHER_KEY, "units": "imperial"})
    data = _get(f"https://api.openweathermap.org/data/2.5/weather?{params}")
    if "error" in data:
        return {"ok": False, "error": data["error"]}
    return {"ok": True, "weather": data}


# ── NEWS ─────────────────────────────────────────────────────────────

def news_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search recent news. Args: query, language (default en)"""
    if not _NEWS_API_KEY:
        return {"ok": False, "error": "Set NEWS_API_KEY in .env (newsapi.org)"}
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    lang = args.get("language", "en")
    params = urllib.parse.urlencode({"q": query, "language": lang, "pageSize": 10, "apiKey": _NEWS_API_KEY})
    data = _get(f"https://newsapi.org/v2/everything?{params}")
    if "error" in data:
        return {"ok": False, "error": data["error"]}
    articles = []
    for a in data.get("articles", [])[:10]:
        articles.append({
            "title": a.get("title"),
            "source": a.get("source", {}).get("name"),
            "url": a.get("url"),
            "published": a.get("publishedAt"),
            "description": (a.get("description") or "")[:200],
        })
    return {"ok": True, "articles": articles, "count": len(articles)}


# ── REDDIT ───────────────────────────────────────────────────────────

def reddit_search(args: Dict[str, Any]) -> Dict[str, Any]:
    """Search Reddit posts. Args: query, subreddit (optional), limit"""
    query = (args.get("query") or "").strip()
    if not query:
        return {"ok": False, "error": "query is required"}
    sub = args.get("subreddit", "all")
    limit = min(int(args.get("limit", 10)), 25)
    params = urllib.parse.urlencode({"q": query, "limit": limit, "sort": "relevance"})
    data = _get(f"https://www.reddit.com/r/{sub}/search.json?{params}&restrict_sr=on",
                {"User-Agent": "Leon/1.3 (by /u/leon-si)"})
    if "error" in data:
        return {"ok": False, "error": data["error"]}
    posts = []
    for child in data.get("data", {}).get("children", []):
        d = child.get("data", {})
        posts.append({
            "title": d.get("title"),
            "subreddit": d.get("subreddit"),
            "score": d.get("score"),
            "url": f"https://reddit.com{d.get('permalink', '')}",
            "author": d.get("author"),
            "comments": d.get("num_comments"),
        })
    return {"ok": True, "posts": posts, "count": len(posts)}


# ── Export ────────────────────────────────────────────────────────────

EXTRA_TOOLS = {
    "youtube.search":       youtube_search,
    "spotify.search":       spotify_search,
    "slack.send":           slack_send,
    "slack.channels":       slack_channels,
    "notion.search":        notion_search,
    "notion.create_page":   notion_create_page,
    "discord.send":         discord_send,
    "weather.get":          weather_get,
    "news.search":          news_search,
    "reddit.search":        reddit_search,
}
