"""
Creative tools — image generation, video generation, music generation.

Leon can now create media on demand using external APIs:
  - image.generate: Replicate (Flux/SDXL) or OpenAI (DALL-E 3)
  - video.generate: Replicate (Minimax, AnimateDiff) or fal.ai
  - music.generate: Replicate (MusicGen)
  - image.edit: Background removal, upscale, style transfer

All outputs save to ~/Desktop/leon-out/ by default.
"""

import base64
import json
import os
import re
import subprocess
import time
import urllib.request
import urllib.error
from typing import Any, Dict

_OUT_DIR = os.path.expanduser("~/Desktop/leon-out")
os.makedirs(_OUT_DIR, exist_ok=True)

# API keys from environment
_REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN", "")
_OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
_FAL_KEY = os.environ.get("FAL_KEY", "")


def _api_call(url: str, data: dict, headers: dict, timeout: int = 120) -> dict:
    """Make a JSON API call and return the parsed response."""
    body = json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err_body = e.read().decode() if e.fp else ""
        return {"error": f"HTTP {e.code}: {err_body[:500]}"}
    except Exception as e:
        return {"error": str(e)}


def _api_get(url: str, headers: dict, timeout: int = 120) -> dict:
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err_body = e.read().decode() if e.fp else ""
        return {"error": f"HTTP {e.code}: {err_body[:500]}"}
    except Exception as e:
        return {"error": str(e)}


def _download_file(url: str, path: str) -> bool:
    """Download a URL to a local file."""
    try:
        urllib.request.urlretrieve(url, path)
        return True
    except Exception as e:
        print(f"[CREATIVE] Download failed: {e}")
        return False


def _safe_filename(prompt: str, ext: str) -> str:
    """Generate a safe filename from a prompt."""
    clean = re.sub(r'[^\w\s-]', '', prompt[:40]).strip().replace(' ', '_')
    ts = int(time.time())
    return f"{clean}_{ts}.{ext}"


# ── IMAGE GENERATION ─────────────────────────────────────────────────

def image_generate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate an image from a text prompt.

    Args:
        prompt: Text description of the image to generate
        model: Optional model choice: "flux" (default, best quality),
               "sdxl" (fast), "dalle3" (OpenAI)
        size: Optional size: "1024x1024" (default), "1024x1792", "1792x1024"
        output: Optional output filename (saved to ~/Desktop/leon-out/)
    """
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return {"ok": False, "error": "prompt is required"}

    model = (args.get("model") or "flux").lower()
    size = args.get("size", "1024x1024")
    output = args.get("output") or _safe_filename(prompt, "png")
    out_path = os.path.join(_OUT_DIR, output)

    # Route to the right backend
    if model == "dalle3" and _OPENAI_API_KEY:
        return _image_dalle3(prompt, size, out_path)
    elif _REPLICATE_API_TOKEN:
        return _image_replicate(prompt, model, size, out_path)
    else:
        return {"ok": False, "error": "No API key set. Set REPLICATE_API_TOKEN or OPENAI_API_KEY in .env"}


def _image_replicate(prompt: str, model: str, size: str, out_path: str) -> dict:
    """Generate via Replicate (Flux or SDXL)."""
    headers = {
        "Authorization": f"Bearer {_REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",  # Synchronous mode — wait for result
    }

    # Model versions
    models = {
        "flux": "black-forest-labs/flux-1.1-pro",
        "flux-schnell": "black-forest-labs/flux-schnell",
        "sdxl": "stability-ai/sdxl:7762fd07cf82c948538e41f63f77d685e02b063e37e496e96eefd46c929f9bdc",
    }
    model_id = models.get(model, models["flux"])

    # Parse size
    w, h = 1024, 1024
    if "x" in size:
        parts = size.split("x")
        w, h = int(parts[0]), int(parts[1])

    data = {
        "input": {
            "prompt": prompt,
            "width": w,
            "height": h,
        }
    }

    # Flux uses /models/ endpoint, SDXL uses /predictions/
    if ":" in model_id:
        url = "https://api.replicate.com/v1/predictions"
        data["version"] = model_id.split(":")[1]
    else:
        url = f"https://api.replicate.com/v1/models/{model_id}/predictions"

    result = _api_call(url, data, headers, timeout=180)

    if "error" in result and isinstance(result["error"], str):
        return {"ok": False, "error": result["error"]}

    # Poll if not using Prefer: wait
    if result.get("status") in ("starting", "processing"):
        poll_url = result.get("urls", {}).get("get", "")
        if poll_url:
            for _ in range(60):
                time.sleep(2)
                poll = _api_get(poll_url, {"Authorization": f"Bearer {_REPLICATE_API_TOKEN}"})
                if poll.get("status") == "succeeded":
                    result = poll
                    break
                if poll.get("status") == "failed":
                    return {"ok": False, "error": poll.get("error", "Generation failed")}

    # Extract output URL
    output_data = result.get("output")
    if isinstance(output_data, list) and output_data:
        img_url = output_data[0]
    elif isinstance(output_data, str):
        img_url = output_data
    else:
        return {"ok": False, "error": f"Unexpected response: {json.dumps(result)[:300]}"}

    if _download_file(img_url, out_path):
        return {"ok": True, "path": out_path, "url": img_url, "model": model}
    return {"ok": False, "error": "Failed to download generated image"}


def _image_dalle3(prompt: str, size: str, out_path: str) -> dict:
    """Generate via OpenAI DALL-E 3."""
    headers = {
        "Authorization": f"Bearer {_OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    data = {
        "model": "dall-e-3",
        "prompt": prompt,
        "n": 1,
        "size": size,
        "quality": "hd",
    }
    result = _api_call("https://api.openai.com/v1/images/generations", data, headers, timeout=120)

    if "error" in result:
        return {"ok": False, "error": result["error"]}

    img_data = result.get("data", [{}])
    if not img_data:
        return {"ok": False, "error": "No image returned"}

    img_url = img_data[0].get("url", "")
    revised_prompt = img_data[0].get("revised_prompt", "")

    if img_url and _download_file(img_url, out_path):
        return {"ok": True, "path": out_path, "url": img_url,
                "revised_prompt": revised_prompt, "model": "dalle3"}
    return {"ok": False, "error": "Failed to download image"}


# ── VIDEO GENERATION ─────────────────────────────────────────────────

def video_generate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a video from a text prompt or image.

    Args:
        prompt: Text description of the video
        image: Optional path to input image (for image-to-video)
        duration: Optional duration in seconds (default: 5)
        output: Optional output filename
    """
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return {"ok": False, "error": "prompt is required"}

    if not _REPLICATE_API_TOKEN:
        return {"ok": False, "error": "Set REPLICATE_API_TOKEN in .env for video generation"}

    output = args.get("output") or _safe_filename(prompt, "mp4")
    out_path = os.path.join(_OUT_DIR, output)
    image_path = args.get("image")

    headers = {
        "Authorization": f"Bearer {_REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }

    # Use minimax video-01-live for text-to-video
    model_id = "minimax/video-01-live"
    input_data = {
        "prompt": prompt,
    }

    # If image provided, encode as data URI for image-to-video
    if image_path and os.path.isfile(image_path):
        with open(image_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
        ext = os.path.splitext(image_path)[1].lstrip(".")
        input_data["first_frame_image"] = f"data:image/{ext};base64,{img_b64}"

    data = {"input": input_data}
    url = f"https://api.replicate.com/v1/models/{model_id}/predictions"

    result = _api_call(url, data, headers, timeout=300)

    if "error" in result and isinstance(result["error"], str):
        return {"ok": False, "error": result["error"]}

    # Poll for completion (video takes longer)
    if result.get("status") in ("starting", "processing"):
        poll_url = result.get("urls", {}).get("get", "")
        if poll_url:
            for _ in range(120):  # Up to 4 minutes
                time.sleep(3)
                poll = _api_get(poll_url, {"Authorization": f"Bearer {_REPLICATE_API_TOKEN}"})
                if poll.get("status") == "succeeded":
                    result = poll
                    break
                if poll.get("status") == "failed":
                    return {"ok": False, "error": poll.get("error", "Video generation failed")}

    output_data = result.get("output")
    if isinstance(output_data, str):
        vid_url = output_data
    elif isinstance(output_data, list) and output_data:
        vid_url = output_data[0]
    else:
        return {"ok": False, "error": f"Unexpected response: {json.dumps(result)[:300]}"}

    if _download_file(vid_url, out_path):
        return {"ok": True, "path": out_path, "url": vid_url}
    return {"ok": False, "error": "Failed to download video"}


# ── MUSIC GENERATION ─────────────────────────────────────────────────

def music_generate(args: Dict[str, Any]) -> Dict[str, Any]:
    """Generate music from a text prompt.

    Args:
        prompt: Description of the music (e.g. "upbeat electronic track, 120bpm")
        duration: Duration in seconds (default: 15, max: 30)
        output: Optional output filename
    """
    prompt = (args.get("prompt") or "").strip()
    if not prompt:
        return {"ok": False, "error": "prompt is required"}

    if not _REPLICATE_API_TOKEN:
        return {"ok": False, "error": "Set REPLICATE_API_TOKEN in .env for music generation"}

    duration = min(int(args.get("duration", 15)), 30)
    output = args.get("output") or _safe_filename(prompt, "wav")
    out_path = os.path.join(_OUT_DIR, output)

    headers = {
        "Authorization": f"Bearer {_REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }

    # MusicGen Large via Replicate
    data = {
        "input": {
            "prompt": prompt,
            "duration": duration,
            "model_version": "large",
            "output_format": "wav",
        }
    }
    url = "https://api.replicate.com/v1/models/meta/musicgen/predictions"

    result = _api_call(url, data, headers, timeout=180)

    if "error" in result and isinstance(result["error"], str):
        return {"ok": False, "error": result["error"]}

    # Poll
    if result.get("status") in ("starting", "processing"):
        poll_url = result.get("urls", {}).get("get", "")
        if poll_url:
            for _ in range(60):
                time.sleep(2)
                poll = _api_get(poll_url, {"Authorization": f"Bearer {_REPLICATE_API_TOKEN}"})
                if poll.get("status") == "succeeded":
                    result = poll
                    break
                if poll.get("status") == "failed":
                    return {"ok": False, "error": poll.get("error", "Music generation failed")}

    output_data = result.get("output")
    if isinstance(output_data, str):
        audio_url = output_data
    elif isinstance(output_data, list) and output_data:
        audio_url = output_data[0]
    else:
        return {"ok": False, "error": f"Unexpected response: {json.dumps(result)[:300]}"}

    if _download_file(audio_url, out_path):
        return {"ok": True, "path": out_path, "url": audio_url, "duration": duration}
    return {"ok": False, "error": "Failed to download audio"}


# ── IMAGE EDITING ────────────────────────────────────────────────────

def image_upscale(args: Dict[str, Any]) -> Dict[str, Any]:
    """Upscale an image to higher resolution.

    Args:
        image: Path to the image file
        scale: Upscale factor (default: 4)
        output: Optional output filename
    """
    image_path = (args.get("image") or "").strip()
    if not image_path or not os.path.isfile(image_path):
        return {"ok": False, "error": "Valid image path required"}

    if not _REPLICATE_API_TOKEN:
        return {"ok": False, "error": "Set REPLICATE_API_TOKEN in .env"}

    scale = int(args.get("scale", 4))
    output = args.get("output") or _safe_filename("upscaled", "png")
    out_path = os.path.join(_OUT_DIR, output)

    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()
    ext = os.path.splitext(image_path)[1].lstrip(".") or "png"

    headers = {
        "Authorization": f"Bearer {_REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }
    data = {
        "input": {
            "image": f"data:image/{ext};base64,{img_b64}",
            "scale": scale,
        }
    }
    url = "https://api.replicate.com/v1/models/nightmareai/real-esrgan/predictions"
    result = _api_call(url, data, headers, timeout=120)

    if "error" in result and isinstance(result["error"], str):
        return {"ok": False, "error": result["error"]}

    # Poll
    if result.get("status") in ("starting", "processing"):
        poll_url = result.get("urls", {}).get("get", "")
        if poll_url:
            for _ in range(60):
                time.sleep(2)
                poll = _api_get(poll_url, {"Authorization": f"Bearer {_REPLICATE_API_TOKEN}"})
                if poll.get("status") == "succeeded":
                    result = poll
                    break
                if poll.get("status") == "failed":
                    return {"ok": False, "error": poll.get("error", "Upscale failed")}

    output_data = result.get("output")
    img_url = output_data if isinstance(output_data, str) else (output_data[0] if output_data else "")

    if img_url and _download_file(img_url, out_path):
        return {"ok": True, "path": out_path, "url": img_url, "scale": scale}
    return {"ok": False, "error": "Failed to download upscaled image"}


def image_remove_bg(args: Dict[str, Any]) -> Dict[str, Any]:
    """Remove background from an image.

    Args:
        image: Path to the image file
        output: Optional output filename
    """
    image_path = (args.get("image") or "").strip()
    if not image_path or not os.path.isfile(image_path):
        return {"ok": False, "error": "Valid image path required"}

    if not _REPLICATE_API_TOKEN:
        return {"ok": False, "error": "Set REPLICATE_API_TOKEN in .env"}

    output = args.get("output") or _safe_filename("nobg", "png")
    out_path = os.path.join(_OUT_DIR, output)

    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()
    ext = os.path.splitext(image_path)[1].lstrip(".") or "png"

    headers = {
        "Authorization": f"Bearer {_REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
        "Prefer": "wait",
    }
    data = {
        "input": {
            "image": f"data:image/{ext};base64,{img_b64}",
        }
    }
    url = "https://api.replicate.com/v1/models/cjwbw/rembg/predictions"
    result = _api_call(url, data, headers, timeout=120)

    if "error" in result and isinstance(result["error"], str):
        return {"ok": False, "error": result["error"]}

    if result.get("status") in ("starting", "processing"):
        poll_url = result.get("urls", {}).get("get", "")
        if poll_url:
            for _ in range(60):
                time.sleep(2)
                poll = _api_get(poll_url, {"Authorization": f"Bearer {_REPLICATE_API_TOKEN}"})
                if poll.get("status") == "succeeded":
                    result = poll
                    break
                if poll.get("status") == "failed":
                    return {"ok": False, "error": poll.get("error", "BG removal failed")}

    output_data = result.get("output")
    img_url = output_data if isinstance(output_data, str) else (output_data[0] if output_data else "")

    if img_url and _download_file(img_url, out_path):
        return {"ok": True, "path": out_path, "url": img_url}
    return {"ok": False, "error": "Failed to download result"}


# ── Export ────────────────────────────────────────────────────────────

EXTRA_TOOLS = {
    "image.generate":     image_generate,
    "image.upscale":      image_upscale,
    "image.remove_bg":    image_remove_bg,
    "video.generate":     video_generate,
    "music.generate":     music_generate,
}
