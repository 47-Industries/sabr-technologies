"""music_tools — Leon plays music on Dean's PC (browser-driven, no API keys).

play_soundcloud_likes: navigate Leon's Brave to Dean's SoundCloud likes and
click the newest (top) track's play button. Requires Leon's Brave to be
logged into Dean's SoundCloud once (a browser login, not an API credential).
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict

_AUDIT_LOG = os.path.expanduser("~/.local/share/leon/pc-control.log")


def _audit(tool: str, detail: str) -> None:
    try:
        os.makedirs(os.path.dirname(_AUDIT_LOG), exist_ok=True)
        with open(_AUDIT_LOG, "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}\t{tool}\t{detail}\n")
    except Exception:
        pass


def play_soundcloud_likes(args: Dict[str, Any]) -> Dict[str, Any]:
    """Play Dean's most recent SoundCloud like. args: optional {url, wait}."""
    try:
        from browser_cdp import _open_session, _evaluate
    except Exception as e:
        return {"ok": False, "error": f"browser CDP unavailable: {e}"}

    url = args.get("url") or "https://soundcloud.com/you/likes"
    # Navigate via JS (sidesteps browser_open's login-wall guard). The WS
    # session detaches on navigation, so fire-and-close, then reconnect.
    try:
        s = _open_session()
        try:
            _evaluate(s, f"window.location.href = {url!r}")
        finally:
            s.close()
    except Exception as e:
        return {"ok": False, "error": f"navigate failed: {e}"}

    time.sleep(float(args.get("wait", 5)))

    # Click the first (newest) like's play button. Multiple selectors because
    # SoundCloud's markup shifts; the first .sc-button-play in the like list
    # is the most recent liked track.
    click_js = r"""(function(){
      var sels=['.soundList__item .sc-button-play','.sound__body .sc-button-play',
                'button.sc-button-play.playButton','button[title="Play"]',
                '.soundBadge__playButton .sc-button-play','.playButton'];
      for(var i=0;i<sels.length;i++){var b=document.querySelector(sels[i]);
        if(b){b.click(); return 'played';}}
      return 'no-track (title='+document.title+' url='+location.href+')';
    })()"""
    try:
        s = _open_session("soundcloud")
        try:
            r = _evaluate(s, click_js)
        finally:
            s.close()
    except Exception as e:
        return {"ok": False, "error": f"play-click failed: {e}"}

    played = isinstance(r, str) and r.startswith("played")
    _audit("music.play_soundcloud_likes", "played" if played else str(r)[:80])
    out = {"ok": played, "result": r}
    if not played:
        out["hint"] = ("Leon's Brave isn't showing tracks — most likely it "
                       "isn't logged into Dean's SoundCloud yet. Log in once "
                       "at soundcloud.com in Leon's browser, then retry.")
    return out


EXTRA_TOOLS: Dict[str, Any] = {
    "music.play_soundcloud_likes": play_soundcloud_likes,
}
