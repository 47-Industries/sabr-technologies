# Test script for Windows Terminal Service API
$baseUrl = "http://127.0.0.1:9101"

Write-Host "Testing Windows Terminal Service API..." -ForegroundColor Cyan

# Test 1: Health
Write-Host "`n[1] Testing /health endpoint..." -ForegroundColor Yellow
try {
    $health = Invoke-RestMethod -Uri "$baseUrl/health" -ErrorAction Stop
    Write-Host "✓ Health check passed" -ForegroundColor Green
    Write-Host "  Status: $($health.status)"
    Write-Host "  ConPTY available: $($health.conpty_available)"
} catch {
    Write-Host "✗ Health check failed: $_" -ForegroundColor Red
    exit 1
}

# Test 2: Spawn terminal
Write-Host "`n[2] Testing /spawn endpoint..." -ForegroundColor Yellow
try {
    $spawnBody = @{
        cwd = "C:\Users\Mr. Sabr"
    } | ConvertTo-Json

    $spawn = Invoke-RestMethod -Uri "$baseUrl/spawn" `
        -Method Post `
        -ContentType "application/json" `
        -Body $spawnBody `
        -ErrorAction Stop

    $sessionId = $spawn.session_id
    Write-Host "✓ Terminal spawned successfully" -ForegroundColor Green
    Write-Host "  Session ID: $sessionId"
} catch {
    Write-Host "✗ Spawn failed: $_" -ForegroundColor Red
    exit 1
}

# Test 3: Write to terminal
Write-Host "`n[3] Testing /terminal/:id/write endpoint..." -ForegroundColor Yellow
try {
    $writeBody = @{
        data = "echo Test from API`r`n"
    } | ConvertTo-Json

    $write = Invoke-RestMethod -Uri "$baseUrl/terminal/$sessionId/write" `
        -Method Post `
        -ContentType "application/json" `
        -Body $writeBody `
        -ErrorAction Stop

    Write-Host "✓ Write succeeded" -ForegroundColor Green
} catch {
    Write-Host "✗ Write failed: $_" -ForegroundColor Red
    exit 1
}

# Test 4: Read from terminal
Write-Host "`n[4] Testing /terminal/:id/read endpoint..." -ForegroundColor Yellow
try {
    Start-Sleep -Milliseconds 500  # Give terminal time to process

    $read = Invoke-RestMethod -Uri "$baseUrl/terminal/$sessionId/read" `
        -ErrorAction Stop

    Write-Host "✓ Read succeeded" -ForegroundColor Green
    if ($read.data) {
        Write-Host "  Output (first 200 chars):" -ForegroundColor Gray
        Write-Host "  $($read.data.Substring(0, [Math]::Min(200, $read.data.Length)))" -ForegroundColor Gray
    }
} catch {
    Write-Host "✗ Read failed: $_" -ForegroundColor Red
    exit 1
}

Write-Host "`n✓ All tests passed! API is working." -ForegroundColor Green
