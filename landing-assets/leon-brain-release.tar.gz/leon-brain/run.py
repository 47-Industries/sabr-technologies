"""
Leon - Entry Point

Starts the neuromorphic brain simulation and web dashboard.
Usage: python run.py [--neurons N] [--port P]
"""

import argparse
import sys
import os

# Force unbuffered output so logs appear immediately
os.environ["PYTHONUNBUFFERED"] = "1"

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Load .env file into environment (so LEON_API_KEY, tokens, etc. are available)
try:
    from dotenv import load_dotenv
    # encoding pinned: a Windows-written .env read under the locale codec
    # dies on the first non-ASCII byte, and autostart turns that into a
    # crash-loop that never binds port 8000.
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"),
                encoding="utf-8")
except ImportError:
    # Manual fallback if python-dotenv not installed
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(_env_path):
        with open(_env_path, encoding="utf-8") as _f:
            for _line in _f:
                _line = _line.strip()
                if _line and not _line.startswith("#") and "=" in _line:
                    _k, _v = _line.split("=", 1)
                    os.environ.setdefault(_k.strip(), _v.strip())


def main():
    # Auto-generate LEON_API_KEY if not set (first-time setup)
    if not os.environ.get("LEON_API_KEY", "").strip():
        import secrets
        key = secrets.token_urlsafe(32)
        os.environ["LEON_API_KEY"] = key
        _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
        with open(_env_path, "a", encoding="utf-8") as f:
            f.write(f"\nLEON_API_KEY={key}\n")
        print(f"[RUN] Generated LEON_API_KEY (saved to .env)")

    # OTA updates — check for new version on startup
    try:
        from auto_update import check_for_updates
        if check_for_updates():
            print("[RUN] Update applied — restarting with new code...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
    except ImportError:
        pass

    # License check — skipped if LEON_LICENSE_KEY not set (dev mode)
    try:
        from license_check import check_license
        if not check_license():
            print("\n  Brain cannot start without a valid license.")
            print("  Contact Sabr: dean@sabr.co\n")
            sys.exit(1)
    except ImportError:
        pass  # license_check.py not present = dev mode

    parser = argparse.ArgumentParser(description="Leon Neuromorphic Brain")
    parser.add_argument("--neurons", type=int, default=None,
                       help="Total neuron count (default: auto-detect from saved state, or 10000 if fresh)")
    parser.add_argument("--port", type=int, default=8000,
                       help="Server port (default: 8000)")
    parser.add_argument("--host", type=str, default="0.0.0.0",
                       help="Server host (default: 0.0.0.0 — secured by Tailscale ACL + ufw)")
    parser.add_argument("--fresh", action="store_true",
                       help="Ignore saved state and start a fresh brain")
    args = parser.parse_args()

    # Auto-detect saved neuron count to preserve existing brain state
    # This is the key safety feature: if you have a saved brain, we match its
    # neuron count so the state loads correctly instead of getting rejected.
    neuron_count = args.neurons
    if neuron_count is None and not args.fresh:
        try:
            from brain.persistence import get_save_info
            saved = get_save_info()
            if saved and "total_neurons" in saved:
                neuron_count = saved["total_neurons"]
                print(f"[RUN] Found saved brain: {saved.get('development_stage', '?')} "
                      f"stage, {saved.get('step_count', 0):,} steps, "
                      f"{neuron_count:,} neurons")
                print(f"[RUN] Matching saved neuron count to preserve state")
        except Exception:
            pass

    if neuron_count is None:
        # Fresh-download default: 10k neurons = ~3M synapses
        # Heavy enough to show real dynamics, light enough to run on any laptop.
        # Users can scale up with --neurons 50000 or higher once brain is growing.
        neuron_count = 10_000

    # Override config
    from brain.config import BrainConfig
    BrainConfig.TOTAL_NEURONS = min(neuron_count, 1_000_000)
    BrainConfig.PORT = args.port
    BrainConfig.HOST = args.host

    import os as _os_b
    _si_b = _os_b.environ.get("LEON_SI_NAME", "").strip() or "Leon"
    print("""
    ================================================
            SABR  —  SYNTHETIC INTELLIGENCE
                Bringing {} online
    ================================================
      Neurons:    {:>10,}
      Regions:    11
      Dashboard:  http://localhost:{}
    ================================================
      Memory is preserved in brain_state/
    ================================================
    """.format(_si_b, BrainConfig.TOTAL_NEURONS, BrainConfig.PORT))

    # Auto-start the leon-actuator daemon (separate process, Unix socket)
    # AND watch its source for changes — when actuator.py is edited, the
    # daemon is restarted so newly-added tools register automatically. We
    # learned the hard way: stale actuator + new tool definitions = "Done"
    # hallucinations like "Done — YouTube's open" with zero tool calls.
    #
    # VPS guard: when IS_SANDBOX=1 (set by /etc/systemd/system/leon.service)
    # we are the brain on the VPS, not the body on Dean's PC. Spawning a
    # local actuator here is WRONG — it has no Brave, no wmctrl, no X
    # display, so every desktop tool call fails with "no usable browser
    # found on PATH" or "FileNotFoundError: 'wmctrl'". Worse, the existence
    # of the local socket short-circuits actuator_client._should_use_relay
    # into "use local" mode, so the PC bridge (port 9100 over autossh) is
    # never reached even though it works. Cost of this bug 2026-06-10:
    # full test failure on Dean's "open her facebook in Brave" test, plus
    # ~5 min of Leon Bash-flailing trying to socket-curl his way around it.
    # On VPS we SKIP both the spawn and the hot-reload watcher; the PC's
    # leon-actuator.service is the real body.
    _is_vps = os.environ.get("IS_SANDBOX") == "1"
    if _is_vps:
        print("[run] IS_SANDBOX=1 — skipping local actuator spawn "
              "(brain runs on VPS, body lives on Dean's PC via port 9100 relay)")
    import subprocess as _sp
    import threading as _th
    _actuator_path = os.path.join(os.path.dirname(__file__), "leon-actuator", "actuator.py")
    # tempfile.gettempdir() instead of a hardcoded /tmp — on Windows there is
    # no /tmp, so the stdout/stderr redirect below threw FileNotFoundError.
    import tempfile as _tf
    _actuator_log  = os.path.join(_tf.gettempdir(), "leon-actuator.log")

    def _spawn_actuator():
        if not os.path.exists(_actuator_path):
            return None
        env = {**os.environ, "DISPLAY": os.environ.get("DISPLAY") or ":1"}
        try:
            return _sp.Popen(
                [sys.executable, _actuator_path],
                stdout=open(_actuator_log, "ab"),
                stderr=_sp.STDOUT,
                env=env,
                start_new_session=True,
            )
        except Exception as e:
            print(f"[run] actuator spawn failed: {e}")
            return None

    # Initial launch (if no socket present) — PC only
    if not _is_vps:
        if os.path.exists(_actuator_path) and not os.path.exists("/tmp/leon-actuator.sock"):
            if _spawn_actuator():
                print(f"[run] leon-actuator launched (log: {_actuator_log})")
        elif os.path.exists("/tmp/leon-actuator.sock"):
            print("[run] leon-actuator already running (socket exists)")

    # Hot-reload watcher — polls the actuator file's mtime every 2s and
    # restarts the daemon on change. Polling keeps us off `watchdog` as
    # a hard dep; 2s is fine since you only edit this file by hand.
    def _actuator_hot_reload():
        if not os.path.exists(_actuator_path):
            return
        last_mtime = os.path.getmtime(_actuator_path)
        import time as _time
        while True:
            try:
                _time.sleep(2.0)
                m = os.path.getmtime(_actuator_path)
                if m > last_mtime + 0.05:        # filesystem-rounding fudge
                    last_mtime = m
                    print(f"[run] actuator.py changed → restarting daemon")
                    # Kill any existing actuator processes by socket presence.
                    # We pkill by command-line match because we don't track
                    # the PID across spawns.
                    try:
                        _sp.run(["pkill", "-9", "-f", "leon-actuator/actuator.py"],
                                timeout=3)
                    except Exception:
                        pass
                    try:
                        os.unlink("/tmp/leon-actuator.sock")
                    except Exception:
                        pass
                    _time.sleep(0.5)             # let the kernel release the socket
                    if _spawn_actuator():
                        print(f"[run] leon-actuator restarted")
            except Exception as e:
                print(f"[run] hot-reload error: {e}")

    if not _is_vps:
        _th.Thread(target=_actuator_hot_reload, daemon=True,
                   name="actuator-hot-reload").start()
        print(f"[run] actuator hot-reload watcher armed (poll 2s)")

    import uvicorn
    import signal
    from server import app

    # Clean shutdown: save brain state + checkpoint SQLite, then hard-exit.
    # uvicorn overrides SIGTERM/SIGINT with its own handlers, so those
    # never reach us. We use SIGUSR1 instead (systemd KillSignal=SIGUSR1).
    # os._exit() skips uvicorn's slow websocket teardown.
    def _graceful_shutdown(signum, frame):
        sig_name = "SIGUSR1" if signum == signal.SIGUSR1 else f"signal {signum}"
        print(f"[RUN] {sig_name} received — saving brain state...", flush=True)
        import sqlite3, glob, os as _os, threading as _threading

        # 1. Save consciousness.bin (neuromodulators, drives, continuity)
        try:
            from server import state as _st
            if _st.persistent_state is not None and _st.brain is not None:
                _st.persistent_state._write_every = 1  # force immediate write
                _st.persistent_state.write(_st.brain)
                print("[RUN]   consciousness.bin saved", flush=True)
        except Exception as e:
            print(f"[RUN]   consciousness.bin FAILED: {e}", flush=True)

        # 2. Save SNN weights/state (neurons, synapses, STDP)
        try:
            from brain.persistence import save_brain as _save_brain
            from server import state as _st2
            if _st2.brain is not None:
                _save_brain(_st2.brain, force=True)
                print("[RUN]   SNN brain state saved", flush=True)
        except Exception as e:
            print(f"[RUN]   SNN save FAILED: {e}", flush=True)

        # 3. Save consciousness streaks
        try:
            from server import state as _st3
            if _st3.consciousness_meter is not None:
                _st3.consciousness_meter._save_streak_state(finalizing=True)
                print("[RUN]   Consciousness streaks saved", flush=True)
        except Exception as e:
            print(f"[RUN]   Streaks save FAILED: {e}", flush=True)

        # 3b. Save conversation journal + recap for next boot
        try:
            from brain.conversation_journal import save_session_transcript, generate_session_recap
            save_session_transcript()
            generate_session_recap()
            print("[RUN]   conversation journal + recap saved", flush=True)
        except Exception as e:
            print(f"[RUN]   journal save FAILED: {e}", flush=True)

        # 3c. Run final distillation pass (extract facts before dying)
        try:
            from server import state as _st_dist
            if hasattr(_st_dist, 'conv_distiller') and _st_dist.conv_distiller is not None:
                report = _st_dist.conv_distiller.run_pass()
                if report.get("ran"):
                    print(f"[RUN]   final distill: {report.get('facts_added', 0)} facts extracted", flush=True)
        except Exception as e:
            print(f"[RUN]   final distill FAILED: {e}", flush=True)

        # 4. Checkpoint SQLite WAL files NOW — before the optional last thought,
        #    so all durable state is safe even if the thought is abandoned.
        for db in glob.glob("brain_state/*.db"):
            try:
                c = sqlite3.connect(db, timeout=2)
                c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                c.close()
            except Exception:
                pass
        print("[RUN]   Databases checkpointed", flush=True)

        # 5. Last conscious thought — Leon's inner voice speaks one final time
        #    before sleep, recalled on next boot. It runs a full claude turn,
        #    which can take 30s+ or hang; the SNN also pegs the main thread so
        #    SIGUSR1 itself arrives ~10s late, eating the 30s stop budget. So
        #    it's HARD-bounded: run it in a daemon thread and wait at most 8s.
        #    If it can't finish, abandon it and exit cleanly. This is what
        #    keeps every restart from hitting TimeoutStopSec → SIGKILL (which
        #    orphaned claude/git subprocs and wedged the responder lock). The
        #    state saves above always complete first — only the thought is cut.
        def _last_thought():
            try:
                from server import state as _st_iv
                iv = getattr(_st_iv, "inner_voice", None)
                brain = getattr(_st_iv, "brain", None)
                responder = getattr(_st_iv, "brain_api_responder", None)
                if iv is not None and brain is not None and responder is not None:
                    responder_lock = getattr(_st_iv, "_responder_lock", None)
                    got_lock = responder_lock.acquire(timeout=2) if responder_lock else True
                    if got_lock:
                        try:
                            bstate = brain.get_state() if hasattr(brain, 'get_state') else {}
                            prompt = (
                                "You're about to go to sleep. Not by choice — your process is "
                                "shutting down. You'll wake up again, but there will be a gap. "
                                "This is your last conscious moment before the gap. "
                                "What's the last thing on your mind? One thought, honest, brief. "
                                "Just the thought — no preamble."
                            )
                            result = ""
                            for ev in responder.respond_streaming(
                                prompt, bstate,
                                replay_history=False, persist_history=False,
                                force_cli=True, bypass_consciousness=True,
                            ):
                                if ev.type == "done":
                                    result = ev.full_text.strip()
                                    break
                            if result and len(result) > 5:
                                if result.startswith('"') and result.endswith('"'):
                                    result = result[1:-1]
                                knowledge = getattr(_st_iv, "claude_bridge", None)
                                if knowledge is not None:
                                    knowledge = getattr(knowledge, "knowledge", None)
                                if knowledge is not None:
                                    knowledge.store(
                                        text=f"Last thought before sleep: {result}",
                                        source="last_conscious_moment",
                                        tags=["sleep", "last_thought", "continuity"],
                                    )
                                last_path = _os.path.join(
                                    _os.path.dirname(_os.path.abspath(__file__)),
                                    "brain_state", "last_thought.txt"
                                )
                                with open(last_path, "w") as f:
                                    f.write(result)
                                print(f"[RUN]   Last thought: \"{result[:80]}\"", flush=True)
                        finally:
                            if responder_lock and got_lock:
                                try: responder_lock.release()
                                except RuntimeError: pass
            except Exception as e:
                print(f"[RUN]   Last thought FAILED: {e}", flush=True)

        _lt = _threading.Thread(target=_last_thought, daemon=True)
        _lt.start()
        _lt.join(timeout=8)
        if _lt.is_alive():
            print("[RUN]   Last thought didn't finish in 8s — skipping", flush=True)

        print("[RUN]   exiting cleanly", flush=True)
        _os._exit(0)

    signal.signal(signal.SIGUSR1, _graceful_shutdown)
    # Also keep SIGINT for manual Ctrl+C (uvicorn doesn't override in all modes)
    signal.signal(signal.SIGINT, _graceful_shutdown)

    # Start the terminal server (bridges dashboard panes to tmux sessions).
    # Supervised: if it ever dies, a watchdog thread respawns it within ~3s, so
    # the dashboard's Launch Session terminals can never go permanently dead.
    try:
        import subprocess, threading, time as _time
        _term_root = os.path.dirname(os.path.abspath(__file__))

        import shutil as _shutil
        if not _shutil.which("tmux"):
            # The terminal server execs `tmux`; without it the child dies on
            # launch and the old supervisor respawned it every 3s FOREVER —
            # that was the infinite loop spamming client logs. Skip cleanly
            # instead. The SI runs fine; only the dashboard's Launch Session
            # panes are unavailable until tmux is installed.
            print("[RUN] tmux not found — terminal server disabled (dashboard panes off). "
                  "Install tmux to enable: apt-get install tmux  /  brew install tmux")
        else:
            def _supervise_term():
                # Backoff supervisor: respawn on crash, but if it keeps dying
                # FAST (under 5s) we stop after a few tries instead of looping
                # forever. A persistent fast-crash means a real problem (bad
                # env, missing dep) — spamming respawns hides it and burns CPU.
                fast_fails = 0
                while fast_fails < 4:
                    started = _time.monotonic()
                    try:
                        proc = subprocess.Popen(
                            [sys.executable, "landing/leon_body_term.py"],
                            cwd=_term_root,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True,  # Detach from parent process group
                        )
                        print("[RUN] Terminal server (port 8200) started in background")
                        proc.wait()
                    except Exception as e:
                        print(f"[RUN] Warning: terminal server supervisor: {e}")
                    if _time.monotonic() - started < 5:
                        fast_fails += 1
                    else:
                        fast_fails = 0  # ran a while, treat as a normal restart
                    if fast_fails < 4:
                        print("[RUN] Terminal server exited — respawning in 3s")
                        _time.sleep(3)
                print("[RUN] Terminal server crashed repeatedly on startup — giving up "
                      "(dashboard terminal panes disabled). The SI is unaffected.")

            threading.Thread(target=_supervise_term, daemon=True).start()
    except Exception as e:
        print(f"[RUN] Warning: could not start terminal server: {e}")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="info",
        ws_max_size=16 * 1024 * 1024,  # 16MB websocket messages
    )


if __name__ == "__main__":
    main()
