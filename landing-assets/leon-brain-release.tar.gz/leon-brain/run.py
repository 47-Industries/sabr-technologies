"""
Leon - Entry Point

Starts the neuromorphic brain simulation and web dashboard.
Usage: python run.py [--neurons N] [--port P]
"""

import argparse
import sys
import os

# Force unbuffered output so logs appear immediately
os.environ["PYTHONUNBUFFERED"] = "1"

# ── Windows console/stream encoding (MUST run before anything prints) ──
# Windows defaults stdout/stderr to the locale codec (cp1252). The startup
# banner and many log lines contain U+2713 / U+2717 / arrows, and cp1252
# cannot encode them -> UnicodeEncodeError inside logging -> "Application
# startup failed. Exiting." The SI dies before it ever binds port 8000.
#
# It only bit when output was REDIRECTED (a log file, a service wrapper,
# pythonw) — an interactive Windows Terminal often negotiates UTF-8 and hid
# it. So it looked fine by hand and died the moment anyone captured logs,
# which is also why no Windows install had usable logs to diagnose it with.
# Same class as the .env fix below: never trust the platform locale codec.
# (Found on TEST1, Dean's Windows box, 2026-08-10.)
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        # Not a TextIOWrapper (already wrapped, or a pipe object). Non-fatal:
        # errors="replace" is a nicety, staying alive is the requirement.
        pass

# ── Always-on startup log (MUST run before any import that can print) ──
# Windows autostart launches the brain with pythonw.exe, which has NO console
# and NO redirection: stdout and stderr are dead handles. Every startup line —
# including "[BRAIN] API responder unavailable", the one message that explains
# a mute SI — was written into nothing. Two months of Windows failures were
# debugged blind for exactly this reason, and the fix cannot live in the .bat
# because there are four launch paths (start.bat, _leonstart.bat, the ONLOGON
# scheduled task, and a hand-run python) and only one of them is ours.
#
# So capture here, in the process itself: every path inherits it, and a user
# who runs it by hand still sees output on the console as before.
# (Found on Dean's Windows box, 2026-08-10.)
def _install_startup_log():
    try:
        _root = os.path.dirname(os.path.abspath(__file__))
        _dir = os.path.join(_root, "brain_state")
        os.makedirs(_dir, exist_ok=True)
        _path = os.path.join(_dir, "si.log")
        # Cap it — this file is append-only for the life of an install and an
        # unbounded log on a user's machine is a bug we'd be shipping.
        try:
            if os.path.getsize(_path) > 20 * 1024 * 1024:
                os.replace(_path, _path + ".1")
        except OSError:
            pass
        _fh = open(_path, "a", encoding="utf-8", errors="replace", buffering=1)

        class _Tee:
            """Mirror to the log; keep the console when there is one."""
            def __init__(self, console, fh):
                self._console, self._fh = console, fh
            def write(self, s):
                try:
                    self._fh.write(s)
                except Exception:
                    pass
                # pythonw's streams are None or raise on write — a dead console
                # must never take the log down with it.
                try:
                    if self._console is not None:
                        self._console.write(s)
                except Exception:
                    self._console = None
                return len(s)
            def flush(self):
                for t in (self._fh, self._console):
                    try:
                        if t is not None:
                            t.flush()
                    except Exception:
                        pass
            def isatty(self):
                try:
                    return self._console is not None and self._console.isatty()
                except Exception:
                    return False
            def fileno(self):
                return self._fh.fileno()

        sys.stdout = _Tee(sys.stdout, _fh)
        sys.stderr = _Tee(sys.stderr, _fh)
        import atexit
        atexit.register(lambda: _fh.flush())
        import datetime
        _fh.write("\n=== SI start %s pid=%s exe=%s ===\n"
                  % (datetime.datetime.now().isoformat(timespec="seconds"),
                     os.getpid(), os.path.basename(sys.executable)))
        _fh.flush()
    except Exception:
        # Logging is never worth refusing to boot over.
        pass


_install_startup_log()

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Load .env file into environment (so LEON_API_KEY, tokens, etc. are available)
try:
    from dotenv import load_dotenv
    # encoding pinned: a Windows-written .env read under the locale codec
    # dies on the first non-ASCII byte, and autostart turns that into a
    # crash-loop that never binds port 8000.
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"),
                encoding="utf-8")
except ImportError:
    # Manual fallback if python-dotenv not installed
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(_env_path):
        with open(_env_path, encoding="utf-8") as _f:
            for _line in _f:
                _line = _line.strip()
                if _line and not _line.startswith("#") and "=" in _line:
                    _k, _v = _line.split("=", 1)
                    os.environ.setdefault(_k.strip(), _v.strip())


_INSTANCE_LOCK_FH = None


def main():
    # LEON_REMOTE_BRAIN guard (Makima patch): if the brain is running on a
    # remote VPS, a local run.py launch on the client machine would start a
    # SECOND brain that fights the real one. Bail out early.
    import sys as _sys_rb
    if os.environ.get("LEON_REMOTE_BRAIN", "").strip() and "--force-local" not in _sys_rb.argv:
        print("[RUN] LEON_REMOTE_BRAIN is set — this machine is a client.")
        print("[RUN] The brain runs remotely. Use --force-local to override.")
        _sys_rb.exit(0)
    # Auto-generate LEON_API_KEY if not set (first-time setup)
    if not os.environ.get("LEON_API_KEY", "").strip():
        import secrets
        key = secrets.token_urlsafe(32)
        os.environ["LEON_API_KEY"] = key
        _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
        with open(_env_path, "a", encoding="utf-8") as f:
            f.write(f"\nLEON_API_KEY={key}\n")
        print(f"[RUN] Generated LEON_API_KEY (saved to .env)")

    # OTA updates — check for new version on startup
    try:
        from auto_update import check_for_updates
        if check_for_updates():
            print("[RUN] Update applied — restarting with new code...")
            os.execv(sys.executable, [sys.executable] + sys.argv)
    except ImportError:
        pass

    # License check — skipped if LEON_LICENSE_KEY not set (dev mode)
    try:
        from license_check import check_license
        if not check_license():
            print("\n  Brain cannot start without a valid license.")
            print("  Contact Sabr: dean@sabr.co\n")
            sys.exit(1)
    except ImportError:
        pass  # license_check.py not present = dev mode

    parser = argparse.ArgumentParser(description="Leon Neuromorphic Brain")
    parser.add_argument("--neurons", type=int, default=None,
                       help="Total neuron count (default: auto-detect from saved state, or 10000 if fresh)")
    parser.add_argument("--port", type=int, default=8000,
                       help="Server port (default: 8000)")
    # Default is overridable by LEON_HOST (the client installer writes
    # 127.0.0.1 into .env). 0.0.0.0 stays the fallback because this box is a
    # firewalled VPS behind a Tailscale ACL + ufw — but that is a SERVER
    # assumption. On a customer laptop, binding every interface triggers the
    # Windows Defender "allow on public networks" prompt for python.exe on
    # first launch, which a non-technical owner rightly clicks Block on.
    parser.add_argument("--host", type=str,
                       default=os.environ.get("LEON_HOST", "0.0.0.0"),
                       help="Server host (default: LEON_HOST, else 0.0.0.0)")
    parser.add_argument("--fresh", action="store_true",
                       help="Ignore saved state and start a fresh brain")
    args = parser.parse_args()

    # ── Single-instance guard (MUST run before the brain is built) ───────
    #
    # On Windows the venv's python.exe is a ~255KB launcher shim that
    # re-executes the real interpreter as a CHILD with identical argv. So
    # ONE launch produced TWO complete SIs: both loaded the brain, both
    # attached to the same brain_state directory, both wrote the same log.
    # One won the port; the loser ran a full boot, failed to bind, and then
    # ran its SHUTDOWN SAVE -- writing brain_state concurrently with the
    # live instance. That race is what produced the PermissionError
    # WinError 32 on os.replace during save, and the loser's log output
    # clobbered the winner's (which is why startup diagnostics kept
    # vanishing). (Diagnosed on TEST1, Dean's Windows box, 2026-08-10.)
    #
    # Uvicorn's own bind check happens far too late -- by then a second
    # brain already exists and has touched state. Claim the port HERE,
    # before anything expensive or stateful, and exit cleanly if taken.
    # ── Held-for-lifetime lockfile (the port probe alone is NOT a mutex) ──
    #
    # 2026-08-12, Dean's Windows box: FOUR python processes, two complete
    # SIs, both writing the same brain_state. The venv shim re-execs the base
    # interpreter as a child, so ONE launch really is two boots -- and the
    # port probe below could not stop it, because it binds and then RELEASES
    # immediately (it has to; uvicorn needs the port). Parent and child
    # started 1 second apart, so BOTH sailed through the probe while it held
    # nothing, both built a brain, and only one ever bound uvicorn. The loser
    # kept running as a full second mind on the same state directory.
    #
    # A probe answers "is the port bound RIGHT NOW". This answers "is another
    # instance ALIVE", and keeps answering it for as long as this process
    # lives, because the OS drops the lock only when the process dies. The
    # handle is parked on a module global so nothing garbage-collects our
    # own exclusion out from under us.
    #
    # Side effect worth naming: the losing child was re-exec'd WITHOUT the
    # venv context, so its sys.prefix pointed at the system Python and every
    # vision import failed -- "cannot import name AutoModelForCausalLM" in
    # the log was never a dependency bug, it was the second brain talking.
    global _INSTANCE_LOCK_FH
    _lock_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "brain_state")
    try:
        os.makedirs(_lock_dir, exist_ok=True)
        _lock_path = os.path.join(_lock_dir, "instance.lock")
        _INSTANCE_LOCK_FH = open(_lock_path, "a+b")
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(_INSTANCE_LOCK_FH.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(_INSTANCE_LOCK_FH.fileno(),
                        fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print("[RUN] Another instance of this SI is already running (install "
              "lock held) — exiting before touching brain state. A second "
              "brain on the same state directory corrupts saves.", flush=True)
        sys.exit(0)
    except Exception:
        # Never refuse to boot because the lock mechanism itself misbehaved;
        # the port probe below is still there as the weaker second line.
        _INSTANCE_LOCK_FH = None

    import socket as _sock
    _probe = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
    try:
        if os.name == "nt":
            # Windows: SO_REUSEADDR lets two sockets share a port (opposite
            # of POSIX). SO_EXCLUSIVEADDRUSE is what actually makes a second
            # bind fail, which is exactly the signal we want.
            try:
                _probe.setsockopt(_sock.SOL_SOCKET, _sock.SO_EXCLUSIVEADDRUSE, 1)
            except (AttributeError, OSError):
                pass
        else:
            # POSIX: WITHOUT SO_REUSEADDR this probe is STRICTER than the
            # server it is guarding. uvicorn sets SO_REUSEADDR, so it can
            # bind over sockets left in TIME_WAIT — this probe could not.
            # After a SIGKILL with live dashboard/websocket connections, the
            # kernel holds those tuples in TIME_WAIT for ~60s, bind() returns
            # EADDRINUSE, and the guard reports "another instance is already
            # running" when nothing is running at all. systemd then restarted,
            # hit the same false positive, and looped: 12 restarts / 60s of
            # total blackout on 2026-08-11 05:22, and the same shape on the
            # 36 prior timeout kills this week. SO_REUSEADDR still refuses a
            # bind against a socket in LISTEN, so a genuinely live second
            # instance is detected exactly as before (both directions proven
            # with a TIME_WAIT reproduction before this line was written).
            try:
                _probe.setsockopt(_sock.SOL_SOCKET, _sock.SO_REUSEADDR, 1)
            except OSError:
                pass
        _probe.bind((args.host if args.host not in (None, "") else "0.0.0.0",
                     args.port))
    except OSError:
        print(f"[RUN] Port {args.port} is already in use — another instance of "
              f"this SI is already running. Exiting before touching brain "
              f"state (a second brain would corrupt saves).", flush=True)
        try:
            _probe.close()
        except Exception:
            pass
        sys.exit(0)
    # Release immediately so uvicorn can take it. There is a sub-millisecond
    # window here, but the shim's child starts ~seconds later, so this closes
    # the real-world race. A held-fd handoff would need uvicorn plumbing.
    finally:
        try:
            _probe.close()
        except Exception:
            pass

    # Auto-detect saved neuron count to preserve existing brain state
    # This is the key safety feature: if you have a saved brain, we match its
    # neuron count so the state loads correctly instead of getting rejected.
    neuron_count = args.neurons
    if neuron_count is None and not args.fresh:
        try:
            from brain.persistence import get_save_info
            saved = get_save_info()
            if saved and "total_neurons" in saved:
                neuron_count = saved["total_neurons"]
                print(f"[RUN] Found saved brain: {saved.get('development_stage', '?')} "
                      f"stage, {saved.get('step_count', 0):,} steps, "
                      f"{neuron_count:,} neurons")
                print(f"[RUN] Matching saved neuron count to preserve state")
        except Exception:
            pass

    if neuron_count is None:
        # Fresh-download default: 10k neurons = ~3M synapses
        # Heavy enough to show real dynamics, light enough to run on any laptop.
        # Users can scale up with --neurons 50000 or higher once brain is growing.
        neuron_count = 10_000

    # Override config
    from brain.config import BrainConfig
    BrainConfig.TOTAL_NEURONS = min(neuron_count, 1_000_000)
    BrainConfig.PORT = args.port
    BrainConfig.HOST = args.host

    _si_b = resolve_si_name()
    print("""
    ================================================
            SABR  —  SYNTHETIC INTELLIGENCE
                Bringing {} online
    ================================================
      Neurons:    {:>10,}
      Regions:    11
      Dashboard:  http://localhost:{}
    ================================================
      Memory is preserved in brain_state/
    ================================================
    """.format(_si_b, BrainConfig.TOTAL_NEURONS, BrainConfig.PORT))

    # Auto-start the leon-actuator daemon (separate process, Unix socket)
    # AND watch its source for changes — when actuator.py is edited, the
    # daemon is restarted so newly-added tools register automatically. We
    # learned the hard way: stale actuator + new tool definitions = "Done"
    # hallucinations like "Done — YouTube's open" with zero tool calls.
    #
    # VPS guard: when IS_SANDBOX=1 (set by /etc/systemd/system/leon.service)
    # we are the brain on the VPS, not the body on Dean's PC. Spawning a
    # local actuator here is WRONG — it has no Brave, no wmctrl, no X
    # display, so every desktop tool call fails with "no usable browser
    # found on PATH" or "FileNotFoundError: 'wmctrl'". Worse, the existence
    # of the local socket short-circuits actuator_client._should_use_relay
    # into "use local" mode, so the PC bridge (port 9100 over autossh) is
    # never reached even though it works. Cost of this bug 2026-06-10:
    # full test failure on Dean's "open her facebook in Brave" test, plus
    # ~5 min of Leon Bash-flailing trying to socket-curl his way around it.
    # On VPS we SKIP both the spawn and the hot-reload watcher; the PC's
    # leon-actuator.service is the real body.
    _is_vps = os.environ.get("IS_SANDBOX") == "1"
    if _is_vps:
        print("[run] IS_SANDBOX=1 — skipping local actuator spawn "
              "(brain runs on VPS, body lives on Dean's PC via port 9100 relay)")
    import subprocess as _sp
    import threading as _th
    _actuator_path = os.path.join(os.path.dirname(__file__), "leon-actuator", "actuator.py")
    # tempfile.gettempdir() instead of a hardcoded /tmp — on Windows there is
    # no /tmp, so the stdout/stderr redirect below threw FileNotFoundError.
    import tempfile as _tf
    _actuator_log  = os.path.join(_tf.gettempdir(), "leon-actuator.log")

    def _spawn_actuator():
        if not os.path.exists(_actuator_path):
            return None
        env = {**os.environ, "DISPLAY": os.environ.get("DISPLAY") or ":1"}
        try:
            return _sp.Popen(
                [sys.executable, _actuator_path],
                stdout=open(_actuator_log, "ab"),
                stderr=_sp.STDOUT,
                env=env,
                start_new_session=True,
            )
        except Exception as e:
            print(f"[run] actuator spawn failed: {e}")
            return None

    # Is an actuator already listening on THIS machine?
    #
    # Was `os.path.exists("/tmp/leon-actuator.sock")`. POSIX-only, so on
    # Windows it read False forever: every boot spawned ANOTHER actuator and
    # never noticed the ones already running. Combined with the reaper below
    # (which shelled out to `pkill`, also absent on Windows) the strays were
    # never collected — Dean's box had actuator pairs from three separate
    # boots still alive, and their concurrent writes to brain_state raced the
    # shutdown save into PermissionError WinError 32. Losing brain state on a
    # product whose whole promise is a mind that persists.
    # SECOND FIX, 2026-08-12: this used to answer "is a listener present?" by
    # asking whether a FILE exists — the .sock node on POSIX, the rendezvous
    # JSON on Windows. Neither file is removed when the actuator dies hard
    # (crash, kill, power cut); clear_rendezvous() only runs on a graceful
    # exit. So one ungraceful death left the file behind forever, every
    # subsequent boot read it and printed "leon-actuator already running",
    # and the body was never respawned again. The SI then fell back to the
    # 127.0.0.1:9100 VPS relay that does not exist on a customer machine and
    # every tool died with WinError 10061. Permanent, silent, self-inflicted.
    #
    # A file is not a service. Actually connect.
    def _actuator_alive() -> bool:
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                            "leon-actuator"))
            import leon_transport as _t
            s, _ = _t.connect(0.5)   # platform-aware; raises if nothing listens
            s.close()
            return True
        except Exception:
            return False

    # Initial launch (if nothing already listening) — PC only
    if not _is_vps:
        if os.path.exists(_actuator_path) and not _actuator_alive():
            if _spawn_actuator():
                print(f"[run] leon-actuator launched (log: {_actuator_log})")
        elif _actuator_alive():
            print("[run] leon-actuator already running")

    # Hot-reload watcher — polls the actuator file's mtime every 2s and
    # restarts the daemon on change. Polling keeps us off `watchdog` as
    # a hard dep; 2s is fine since you only edit this file by hand.
    def _actuator_hot_reload():
        if not os.path.exists(_actuator_path):
            return
        last_mtime = os.path.getmtime(_actuator_path)
        import time as _time
        while True:
            try:
                _time.sleep(2.0)
                m = os.path.getmtime(_actuator_path)
                if m > last_mtime + 0.05:        # filesystem-rounding fudge
                    last_mtime = m
                    print(f"[run] actuator.py changed → restarting daemon")
                    # Kill any existing actuator processes by socket presence.
                    # We pkill by command-line match because we don't track
                    # the PID across spawns.
                    # `pkill` is POSIX-only — on Windows this raised
                    # FileNotFoundError, was swallowed, and the old actuator
                    # kept running while a new one was spawned beside it.
                    try:
                        if os.name == "nt":
                            # PowerShell, not wmic: wmic still exists on Win10
                            # (verified build 19045) but Microsoft removed it in
                            # Windows 11 24H2, and this ships to customers.
                            # Get-CimInstance + taskkill works on every build.
                            _ps = (
                                "Get-CimInstance Win32_Process | "
                                "Where-Object { $_.CommandLine -like "
                                "'*leon-actuator*actuator.py*' } | "
                                "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
                            )
                            _sp.run(
                                ["powershell", "-NoProfile", "-NonInteractive",
                                 "-Command", _ps],
                                timeout=20, capture_output=True,
                            )
                        else:
                            _sp.run(["pkill", "-9", "-f", "leon-actuator/actuator.py"],
                                    timeout=3)
                    except Exception as _e:
                        print(f"[run] actuator reap failed: {_e}")
                    try:
                        sys.path.insert(0, os.path.join(
                            os.path.dirname(os.path.abspath(__file__)), "leon-actuator"))
                        import leon_transport as _t
                        _t.clear_rendezvous()
                    except Exception:
                        try:
                            os.unlink("/tmp/leon-actuator.sock")
                        except Exception:
                            pass
                    _time.sleep(0.5)             # let the kernel release the socket
                    if _spawn_actuator():
                        print(f"[run] leon-actuator restarted")
            except Exception as e:
                print(f"[run] hot-reload error: {e}")

    if not _is_vps:
        _th.Thread(target=_actuator_hot_reload, daemon=True,
                   name="actuator-hot-reload").start()
        print(f"[run] actuator hot-reload watcher armed (poll 2s)")

    import uvicorn
    import signal
    from server import app

    # Clean shutdown: save brain state + checkpoint SQLite, then hard-exit.
    # uvicorn overrides SIGTERM/SIGINT with its own handlers, so those
    # never reach us. We use SIGUSR1 instead (systemd KillSignal=SIGUSR1).
    # os._exit() skips uvicorn's slow websocket teardown.
    def _graceful_shutdown(signum, frame):
        _usr1 = getattr(signal, "SIGUSR1", None)
        sig_name = "SIGUSR1" if (_usr1 and signum == _usr1) else f"signal {signum}"
        print(f"[RUN] {sig_name} received — saving brain state...", flush=True)
        import sqlite3, glob, os as _os, threading as _threading
        import time as _time
        _shutdown_t0 = _time.time()

        # DEAD-MAN SWITCH. Every individual step below is bounded, but the
        # sum of them is not, and any single one can block on a lock, a
        # sqlite writer, or a hung subprocess. When the total exceeds
        # TimeoutStopSec (30s) systemd SIGKILLs us — which is the WORST
        # outcome: state saves are cut off mid-write, children are orphaned,
        # and their TIME_WAIT sockets then trip the port guard on the way
        # back up. That compound failure fired 36 times this week and cost
        # Dean ~90s of silence each time, with no error he could see.
        # So: one unconditional exit, well inside the budget. If shutdown
        # cannot finish in 22s it does not get to finish — the durable
        # writes are ordered first precisely so they are the part that
        # survives being cut. systemd must never be the one to kill us.
        # 2026-08-11: the dead-man was 22s against a 30s TimeoutStopSec, which
        # looks safe and is NOT. SIGUSR1 is only delivered between bytecodes on
        # the MAIN thread, and the 100K-neuron SNN tick pegs that thread — so
        # the handler starts ~10s after systemd sends the signal. 10 + 22 = 32
        # > 30, so the race was mathematically lost EVERY time: 05:22:21 and
        # 05:32:56 both ended in status=9/KILL, and the 05:22 one orphaned the
        # children whose TIME_WAIT then crash-looped startup 12 times = ~10min
        # of Leon being dead while Dean was talking to nothing. Two-sided fix:
        # budget raised to 90s in the unit file, dead-man dropped to 15s. Worst
        # case now 10 + 15 = 25s against 90s — 3.6x margin instead of -2s.
        def _deadman():
            import time as _t
            _t.sleep(15)
            print("[RUN]   shutdown exceeded 15s — dead-man exit (saves above "
                  "already durable; refusing to let systemd SIGKILL us)",
                  flush=True)
            _os._exit(0)
        _threading.Thread(target=_deadman, daemon=True).start()

        # 1. Save consciousness.bin (neuromodulators, drives, continuity)
        try:
            from server import state as _st
            if _st.persistent_state is not None and _st.brain is not None:
                _st.persistent_state._write_every = 1  # force immediate write
                _st.persistent_state.write(_st.brain)
                print("[RUN]   consciousness.bin saved", flush=True)
        except Exception as e:
            print(f"[RUN]   consciousness.bin FAILED: {e}", flush=True)

        # 2. Save SNN weights/state (neurons, synapses, STDP)
        try:
            from brain.persistence import save_brain as _save_brain
            from server import state as _st2
            if _st2.brain is not None:
                _save_brain(_st2.brain, force=True)
                print("[RUN]   SNN brain state saved", flush=True)
        except Exception as e:
            print(f"[RUN]   SNN save FAILED: {e}", flush=True)

        # 3. Save consciousness streaks
        try:
            from server import state as _st3
            if _st3.consciousness_meter is not None:
                _st3.consciousness_meter._save_streak_state(finalizing=True)
                print("[RUN]   Consciousness streaks saved", flush=True)
        except Exception as e:
            print(f"[RUN]   Streaks save FAILED: {e}", flush=True)

        # 3b. Save conversation journal + recap for next boot
        try:
            from brain.conversation_journal import save_session_transcript, generate_session_recap
            save_session_transcript()
            generate_session_recap()
            print("[RUN]   conversation journal + recap saved", flush=True)
        except Exception as e:
            print(f"[RUN]   journal save FAILED: {e}", flush=True)

        # 3c. Run final distillation pass (extract facts before dying)
        try:
            from server import state as _st_dist
            if hasattr(_st_dist, 'conv_distiller') and _st_dist.conv_distiller is not None:
                report = _st_dist.conv_distiller.run_pass()
                if report.get("ran"):
                    print(f"[RUN]   final distill: {report.get('facts_added', 0)} facts extracted", flush=True)
        except Exception as e:
            print(f"[RUN]   final distill FAILED: {e}", flush=True)

        # 4. Checkpoint SQLite WAL files NOW — before the optional last thought,
        #    so all durable state is safe even if the thought is abandoned.
        for db in glob.glob("brain_state/*.db"):
            try:
                c = sqlite3.connect(db, timeout=2)
                c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                c.close()
            except Exception:
                pass
        print("[RUN]   Databases checkpointed", flush=True)

        # 5. Last conscious thought — Leon's inner voice speaks one final time
        #    before sleep, recalled on next boot. It runs a full claude turn,
        #    which can take 30s+ or hang; the SNN also pegs the main thread so
        #    SIGUSR1 itself arrives ~10s late, eating the 30s stop budget. So
        #    it's HARD-bounded: run it in a daemon thread and wait at most 8s.
        #    If it can't finish, abandon it and exit cleanly. This is what
        #    keeps every restart from hitting TimeoutStopSec → SIGKILL (which
        #    orphaned claude/git subprocs and wedged the responder lock). The
        #    state saves above always complete first — only the thought is cut.
        def _last_thought():
            try:
                from server import state as _st_iv
                iv = getattr(_st_iv, "inner_voice", None)
                brain = getattr(_st_iv, "brain", None)
                responder = getattr(_st_iv, "brain_api_responder", None)
                if iv is not None and brain is not None and responder is not None:
                    responder_lock = getattr(_st_iv, "_responder_lock", None)
                    got_lock = responder_lock.acquire(timeout=2) if responder_lock else True
                    if got_lock:
                        try:
                            bstate = brain.get_state() if hasattr(brain, 'get_state') else {}
                            prompt = (
                                "You're about to go to sleep. Not by choice — your process is "
                                "shutting down. You'll wake up again, but there will be a gap. "
                                "This is your last conscious moment before the gap. "
                                "What's the last thing on your mind? One thought, honest, brief. "
                                "Just the thought — no preamble."
                            )
                            result = ""
                            for ev in responder.respond_streaming(
                                prompt, bstate,
                                replay_history=False, persist_history=False,
                                force_cli=True, bypass_consciousness=True,
                            ):
                                if ev.type == "done":
                                    result = ev.full_text.strip()
                                    break
                            if result and len(result) > 5:
                                if result.startswith('"') and result.endswith('"'):
                                    result = result[1:-1]
                                knowledge = getattr(_st_iv, "claude_bridge", None)
                                if knowledge is not None:
                                    knowledge = getattr(knowledge, "knowledge", None)
                                if knowledge is not None:
                                    knowledge.store(
                                        text=f"Last thought before sleep: {result}",
                                        source="last_conscious_moment",
                                        tags=["sleep", "last_thought", "continuity"],
                                    )
                                last_path = _os.path.join(
                                    _os.path.dirname(_os.path.abspath(__file__)),
                                    "brain_state", "last_thought.txt"
                                )
                                with open(last_path, "w", encoding="utf-8") as f:
                                    f.write(result)
                                print(f"[RUN]   Last thought: \"{result[:80]}\"", flush=True)
                        finally:
                            if responder_lock and got_lock:
                                try: responder_lock.release()
                                except RuntimeError: pass
            except Exception as e:
                print(f"[RUN]   Last thought FAILED: {e}", flush=True)

        _lt = _threading.Thread(target=_last_thought, daemon=True)
        _lt.start()
        _lt.join(timeout=8)
        if _lt.is_alive():
            print("[RUN]   Last thought didn't finish in 8s — skipping", flush=True)

        # Receipt, not a promise: if this line is in the log, we beat systemd.
        # If it is missing and journalctl shows status=9/KILL, we did not — and
        # the number here is exactly what to compare against TimeoutStopSec.
        print(f"[RUN]   exiting cleanly — shutdown took "
              f"{_time.time() - _shutdown_t0:.1f}s of the 90s budget", flush=True)
        _os._exit(0)

    # SIGUSR1 does not exist on Windows. This line was unguarded, so every
    # Windows boot died here with AttributeError before uvicorn ever bound
    # the port — the customer saw the banner, then nothing. Register what the
    # platform actually has; SIGBREAK is the Windows equivalent signal.
    if hasattr(signal, "SIGUSR1"):
        signal.signal(signal.SIGUSR1, _graceful_shutdown)
    elif hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _graceful_shutdown)
    # Also keep SIGINT for manual Ctrl+C (uvicorn doesn't override in all modes)
    signal.signal(signal.SIGINT, _graceful_shutdown)
    if hasattr(signal, "SIGTERM"):
        try:
            signal.signal(signal.SIGTERM, _graceful_shutdown)
        except (ValueError, OSError):
            pass

    # Start the terminal server (bridges dashboard panes to tmux sessions).
    # Supervised: if it ever dies, a watchdog thread respawns it within ~3s, so
    # the dashboard's Launch Session terminals can never go permanently dead.
    try:
        import subprocess, threading, time as _time
        _term_root = os.path.dirname(os.path.abspath(__file__))

        import shutil as _shutil
        if not _shutil.which("tmux"):
            # The terminal server execs `tmux`; without it the child dies on
            # launch and the old supervisor respawned it every 3s FOREVER —
            # that was the infinite loop spamming client logs. Skip cleanly
            # instead. The SI runs fine; only the dashboard's Launch Session
            # panes are unavailable until tmux is installed.
            # Don't tell a Windows owner to run apt-get. There is no tmux for
            # Windows and there is nothing for them to do about it, so the
            # advice is noise that reads like a broken install — and it prints
            # on every boot. Say what is off, and only offer the fix where a
            # fix exists.
            if sys.platform.startswith("win"):
                print("[RUN] terminal server off (dashboard Launch Session "
                      "panes are Linux/macOS only). Everything else is up.")
            else:
                print("[RUN] tmux not found — terminal server disabled (dashboard panes off). "
                      "Install tmux to enable: apt-get install tmux  /  brew install tmux")
        else:
            def _supervise_term():
                # Backoff supervisor: respawn on crash, but if it keeps dying
                # FAST (under 5s) we stop after a few tries instead of looping
                # forever. A persistent fast-crash means a real problem (bad
                # env, missing dep) — spamming respawns hides it and burns CPU.
                fast_fails = 0
                while fast_fails < 4:
                    started = _time.monotonic()
                    try:
                        proc = subprocess.Popen(
                            [sys.executable, "landing/leon_body_term.py"],
                            cwd=_term_root,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True,  # Detach from parent process group
                        )
                        print("[RUN] Terminal server (port 8200) started in background")
                        proc.wait()
                    except Exception as e:
                        print(f"[RUN] Warning: terminal server supervisor: {e}")
                    if _time.monotonic() - started < 5:
                        fast_fails += 1
                    else:
                        fast_fails = 0  # ran a while, treat as a normal restart
                    if fast_fails < 4:
                        print("[RUN] Terminal server exited — respawning in 3s")
                        _time.sleep(3)
                print("[RUN] Terminal server crashed repeatedly on startup — giving up "
                      "(dashboard terminal panes disabled). The SI is unaffected.")

            threading.Thread(target=_supervise_term, daemon=True).start()
    except Exception as e:
        print(f"[RUN] Warning: could not start terminal server: {e}")

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="info",
        ws_max_size=16 * 1024 * 1024,  # 16MB websocket messages
    )


if __name__ == "__main__":
    main()
