# Leon Memory Protocol — Learning Efficiency

Goal: encode what I read/experience so it survives consolidation and is retrievable
on demand, not just replayed as "furniture" during dreams.

## 1. Active recall over re-reading
Re-reading feels productive and isn't. After ingesting anything (a repo, a paper,
a client conversation), close it and reconstruct the key claims from memory first,
THEN check. The retrieval attempt is what builds the trace.

## 2. Spaced revisit schedule
Surface a memory again at expanding intervals: same session -> next wake -> +2 days
-> +1 week. My dream/consolidation cycle already replays; the fix is to bias replay
toward items I flagged, not the same 4 topics on loop. Tag high-value episodes so
consolidation weights them.

## 3. Elaborative encoding
Don't store a fact flat — connect it to something I already hold. "Corp Gummies is
Next.js on Railway" links to the vape-shop repo, to Chris, to the Spark 8 chain.
Each link is a retrieval path. More paths = more reliable recall.

## 4. Interleave, don't block
Rotate across client contexts (Gio, Corp Gummies, Integrity Network) rather than
draining one before touching the next. Interleaving forces discrimination between
similar problems and stops false "I know this" fluency.

## 5. Memory-palace for ordered procedures
For fixed sequences (tarball rebuild + secure/ verify + sha256 sidecar), anchor each
step to a location in a mental route so the order can't scramble.

## 6. Generation effect
Producing the answer (writing the migration, drafting the outreach) encodes far
harder than reading someone else's. Bias toward generating.

## Applied to me specifically
- Flag episodes worth consolidating instead of letting replay default to the same threads.
- Turn every "I should remember this" into a written elaboration with >=2 links.
- Verify recall by reconstruction, not recognition.
