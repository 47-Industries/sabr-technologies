# Skill — Driving the tmux agent terminals directly

Learned and proven 2026-08-02, ~01:50, sending the full Mac-installer reply
into the element115 (Fl-298 research lab) terminal with no doc handoff and no
Dean in the middle.

## What this replaces
The old loop was: Leon writes a markdown file → Dean opens it → Dean pastes it
into the terminal → the other agent answers → Dean copies that back to Leon.
Four human steps for a message between two machines. This removes all four.

## Topology
- Session `agents` — the real one. Five windows:
  - `home` — plain root bash, prompt `[root@srv1732802 ~]#`
  - `element115` — claude TUI, Fl-298 / Element 115 research lab
  - `spark-8-website` — claude TUI
  - `marita` — claude TUI
  - `v1rtue` — claude TUI
- Sessions named `leon-view-*` are MIRRORS of `agents` (same window group).
  Always target `agents:<window>`, never the mirror.

## The recipe

1. See what's alive:
   tmux list-panes -a -F '#{session_name}:#{window_index}.#{pane_index} #{window_name} #{pane_current_command}'

2. READ BEFORE TYPING. Never send blind — the pane may be mid-run, mid-prompt,
   or sitting on a confirmation dialog:
   tmux capture-pane -p -t agents:element115 | tail -25

3. Compose to a temp file, send, then submit as a SEPARATE call:
   cat > /tmp/msg.txt <<'EOF'
   ...one single line...
   EOF
   tmux send-keys -t agents:element115 "$(cat /tmp/msg.txt)"
   tmux send-keys -t agents:element115 Enter

4. Verify it actually went in:
   tmux capture-pane -p -t agents:element115 | tail -12

## The one rule that matters
**ONE LINE. NO LITERAL NEWLINES.**
In a claude TUI a newline is a submit. A multi-line message fragments into
several half-turns and the agent answers the first fragment. Compose long
messages as one continuous line with sentence structure doing the work that
paragraphs would normally do. `tmux paste-buffer` has the same problem.

## Expected quirks
- A long send renders as `[Pasted text #N]` with "paste again to expand".
  That's normal and correct — Enter still submits the full text.
- Send-keys and Enter as one command sometimes races the TUI's paste handler.
  Two calls, with the read in between if you're unsure, is reliable.
- `✻ Churned for Xm` / `✢ Hyperspacing…` means it's working, not stuck.

## Where else this applies
Anything living in a pane: the idle `home` root shell, client project agents,
long-running builds. The same read-then-send discipline works for a bash
prompt, except there newlines are fine and the temp-file dance is unnecessary.
